package config

import (
	"strings"
	"testing"
)

func TestValidateConfig_DefaultIsValid(t *testing.T) {
	t.Parallel()
	cfg := Default()
	errs := ValidateConfig(cfg)
	if len(errs) != 0 {
		t.Errorf("default config should be valid, got %d error(s): %v", len(errs), errs)
	}
}

func TestValidateConfig_TableDriven(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name       string
		mutate     func(*Config)
		wantFields []string              // expected error fields (at least these)
		wantTypes  []ValidationErrorType // corresponding expected error types
	}{
		{
			name:   "default is valid",
			mutate: func(c *Config) {},
		},
		{
			name: "port zero",
			mutate: func(c *Config) {
				c.Server.Port = 0
			},
			wantFields: []string{"server.port"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "port too high",
			mutate: func(c *Config) {
				c.Server.Port = 70000
			},
			wantFields: []string{"server.port"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "port negative",
			mutate: func(c *Config) {
				c.Server.Port = -1
			},
			wantFields: []string{"server.port"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "empty host",
			mutate: func(c *Config) {
				c.Server.Host = ""
			},
			wantFields: []string{"server.host"},
			wantTypes:  []ValidationErrorType{MissingRequired},
		},
		{
			name: "half_life_days zero",
			mutate: func(c *Config) {
				c.Decay.HalfLifeDays = 0
			},
			wantFields: []string{"decay.half_life_days"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "half_life_days negative",
			mutate: func(c *Config) {
				c.Decay.HalfLifeDays = -5
			},
			wantFields: []string{"decay.half_life_days"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "min_confidence out of range above",
			mutate: func(c *Config) {
				c.Decay.MinConfidence = 1.5
			},
			wantFields: []string{"decay.min_confidence"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "min_confidence negative",
			mutate: func(c *Config) {
				c.Decay.MinConfidence = -0.1
			},
			wantFields: []string{"decay.min_confidence"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "boost_on_access out of range",
			mutate: func(c *Config) {
				c.Decay.BoostOnAccess = 2.0
			},
			wantFields: []string{"decay.boost_on_access"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "bm25_weight out of range",
			mutate: func(c *Config) {
				c.Search.BM25Weight = 1.5
			},
			wantFields: []string{"search.bm25_weight"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "vector_weight negative",
			mutate: func(c *Config) {
				c.Search.VectorWeight = -0.1
			},
			wantFields: []string{"search.vector_weight"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "default_limit zero",
			mutate: func(c *Config) {
				c.Search.DefaultLimit = 0
			},
			wantFields: []string{"search.default_limit"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "hot_token_budget zero",
			mutate: func(c *Config) {
				c.Memory.HotTokenBudget = 0
			},
			wantFields: []string{"memory.hot_token_budget"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "warm_token_budget zero",
			mutate: func(c *Config) {
				c.Memory.WarmTokenBudget = 0
			},
			wantFields: []string{"memory.warm_token_budget"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "max_memories zero",
			mutate: func(c *Config) {
				c.Memory.MaxMemories = 0
			},
			wantFields: []string{"memory.max_memories"},
			wantTypes:  []ValidationErrorType{OutOfRange},
		},
		{
			name: "embeddings enabled without provider",
			mutate: func(c *Config) {
				c.Embeddings.Enabled = true
				c.Embeddings.Provider = ""
			},
			wantFields: []string{"embeddings.provider"},
			wantTypes:  []ValidationErrorType{IncompatibleFields},
		},
		{
			name: "tls enabled without cert_file",
			mutate: func(c *Config) {
				c.Server.TLS = true
				c.Server.CertFile = ""
				c.Server.KeyFile = "/some/key.pem"
			},
			wantFields: []string{"server.cert_file"},
			wantTypes:  []ValidationErrorType{IncompatibleFields},
		},
		{
			name: "tls enabled without key_file",
			mutate: func(c *Config) {
				c.Server.TLS = true
				c.Server.CertFile = "/some/cert.pem"
				c.Server.KeyFile = ""
			},
			wantFields: []string{"server.key_file"},
			wantTypes:  []ValidationErrorType{IncompatibleFields},
		},
		{
			name: "cert_file set but tls disabled",
			mutate: func(c *Config) {
				c.Server.TLS = false
				c.Server.CertFile = "/some/cert.pem"
			},
			wantFields: []string{"server.tls"},
			wantTypes:  []ValidationErrorType{IncompatibleFields},
		},
		{
			name: "multiple errors at once",
			mutate: func(c *Config) {
				c.Server.Port = 99999
				c.Server.Host = ""
				c.Decay.HalfLifeDays = 0
				c.Memory.MaxMemories = 0
			},
			wantFields: []string{"server.port", "server.host", "decay.half_life_days", "memory.max_memories"},
			wantTypes:  []ValidationErrorType{OutOfRange, MissingRequired, OutOfRange, OutOfRange},
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			cfg := Default()
			tt.mutate(cfg)
			errs := ValidateConfig(cfg)

			if len(tt.wantFields) == 0 {
				if len(errs) != 0 {
					t.Errorf("expected no errors, got %d: %v", len(errs), errs)
				}
				return
			}

			if len(errs) < len(tt.wantFields) {
				t.Fatalf("expected at least %d error(s), got %d: %v", len(tt.wantFields), len(errs), errs)
			}

			for i, field := range tt.wantFields {
				found := false
				for _, e := range errs {
					if e.Field == field && e.ErrType == tt.wantTypes[i] {
						found = true
						break
					}
				}
				if !found {
					t.Errorf("expected error for field %q with type %s, errors: %v", field, tt.wantTypes[i], errs)
				}
			}
		})
	}
}

func TestConfigError_String(t *testing.T) {
	t.Parallel()
	e := ConfigError{
		Field:   "server.port",
		Message: "port must be between 1 and 65535",
		Value:   0,
		ErrType: OutOfRange,
	}
	s := e.String()
	if !strings.Contains(s, "out of range") {
		t.Errorf("expected 'out of range' in output, got: %s", s)
	}
	if !strings.Contains(s, "server.port") {
		t.Errorf("expected 'server.port' in output, got: %s", s)
	}

	e2 := ConfigError{
		Field:   "server.host",
		Message: "host is required",
		ErrType: MissingRequired,
	}
	s2 := e2.String()
	if !strings.Contains(s2, "missing required") {
		t.Errorf("expected 'missing required' in output, got: %s", s2)
	}
}

func TestValidationErrorType_String(t *testing.T) {
	t.Parallel()
	cases := map[ValidationErrorType]string{
		MissingRequired:          "missing required",
		InvalidValue:             "invalid value",
		OutOfRange:               "out of range",
		IncompatibleFields:       "incompatible fields",
		UnknownField:             "unknown field",
		ValidationErrorType(999): "unknown",
	}
	for typ, want := range cases {
		if got := typ.String(); got != want {
			t.Errorf("ValidationErrorType(%d).String() = %q, want %q", typ, got, want)
		}
	}
}

func TestFormatErrors_Empty(t *testing.T) {
	t.Parallel()
	if s := FormatErrors(nil); s != "" {
		t.Errorf("expected empty string for nil errors, got %q", s)
	}
	if s := FormatErrors([]ConfigError{}); s != "" {
		t.Errorf("expected empty string for no errors, got %q", s)
	}
}

func TestFormatErrors_Multiple(t *testing.T) {
	t.Parallel()
	errs := []ConfigError{
		{Field: "server.port", Message: "out of range", ErrType: OutOfRange},
		{Field: "server.host", Message: "required", ErrType: MissingRequired},
	}
	s := FormatErrors(errs)
	if !strings.Contains(s, "2 config validation error(s)") {
		t.Errorf("expected count in output, got: %s", s)
	}
	if !strings.Contains(s, "server.port") || !strings.Contains(s, "server.host") {
		t.Errorf("expected both fields in output, got: %s", s)
	}
}

func TestValidateConfig_BoundaryValues(t *testing.T) {
	t.Parallel()
	cfg := Default()
	// Valid boundary values should pass.
	cfg.Server.Port = 1
	cfg.Server.Port = 65535
	cfg.Search.BM25Weight = 0.0
	cfg.Search.VectorWeight = 1.0
	cfg.Decay.MinConfidence = 0.0
	cfg.Decay.BoostOnAccess = 1.0
	cfg.Decay.HalfLifeDays = 1
	cfg.Memory.HotTokenBudget = 1
	cfg.Memory.WarmTokenBudget = 1
	cfg.Memory.MaxMemories = 1
	cfg.Search.DefaultLimit = 1
	errs := ValidateConfig(cfg)
	if len(errs) != 0 {
		t.Errorf("valid boundary values should produce no errors, got %d: %v", len(errs), errs)
	}
}

func TestValidateConfig_EmbeddingsEnabledWithProvider(t *testing.T) {
	t.Parallel()
	cfg := Default()
	cfg.Embeddings.Enabled = true
	cfg.Embeddings.Provider = "openai"
	errs := ValidateConfig(cfg)
	for _, e := range errs {
		if e.Field == "embeddings.provider" {
			t.Errorf("should not error when embeddings enabled with provider set: %v", e)
		}
	}
}
