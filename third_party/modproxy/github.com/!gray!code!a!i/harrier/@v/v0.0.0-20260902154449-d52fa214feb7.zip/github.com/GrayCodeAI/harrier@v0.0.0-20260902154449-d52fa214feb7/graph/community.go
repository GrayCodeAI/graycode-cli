package graph

import (
	"fmt"
	"math"
	"sort"

	"github.com/GrayCodeAI/harrier/storage"
)

// Community represents a detected group of densely-connected nodes in the memory graph.
// Level 0 = finest granularity; higher levels = coarser groupings.
type Community struct {
	ID       string
	Level    int
	NodeIDs  []string
	Summary  string
	Keywords []string
	Strength float64 // internal edge density relative to expected
}

// CommunityDetector implements Louvain-style modularity-optimizing community detection.
// It operates on in-memory node/edge slices — no database access required.
type CommunityDetector struct {
	// MinCommunitySize excludes communities smaller than this from results.
	MinCommunitySize int
}

// NewCommunityDetector creates a detector with sensible defaults.
func NewCommunityDetector() *CommunityDetector {
	return &CommunityDetector{MinCommunitySize: 1}
}

// Detect partitions nodes into communities using Louvain modularity optimization.
// It treats edges as undirected (both directions count) and uses edge Weight as
// the connection strength. Returns a flat slice of Level-0 communities.
func (cd *CommunityDetector) Detect(nodes []*storage.Node, edges []*storage.Edge) []Community {
	if len(nodes) == 0 {
		return nil
	}

	// Build adjacency: for modularity we need an undirected weighted graph.
	nodeIndex := make(map[string]int, len(nodes))
	for i, n := range nodes {
		nodeIndex[n.ID] = i
	}

	n := len(nodes)
	// adjacency[i][j] = weight of edge between node i and node j
	adj := make([]map[int]float64, n)
	for i := range adj {
		adj[i] = make(map[int]float64)
	}

	totalWeight := 0.0
	for _, e := range edges {
		fi, fOK := nodeIndex[e.FromID]
		ti, tOK := nodeIndex[e.ToID]
		if !fOK || !tOK {
			continue
		}
		w := e.Weight
		if w <= 0 {
			w = 1.0
		}
		adj[fi][ti] += w
		adj[ti][fi] += w
		totalWeight += w
	}

	if totalWeight == 0 {
		// No edges: each node is its own community.
		communities := make([]Community, 0, n)
		for i, node := range nodes {
			communities = append(communities, Community{
				ID:       communityID(0, i),
				Level:    0,
				NodeIDs:  []string{node.ID},
				Strength: 0,
			})
		}
		return communities
	}

	// Degree of each node (sum of edge weights).
	degree := make([]float64, n)
	for i := 0; i < n; i++ {
		for _, w := range adj[i] {
			degree[i] += w
		}
	}

	// Initialize: each node starts in its own community.
	community := make([]int, n)
	for i := range community {
		community[i] = i
	}

	// Louvain Phase 1: iteratively move nodes to maximize modularity gain.
	m2 := 2.0 * totalWeight
	improved := true
	maxIterations := 100

	for iter := 0; iter < maxIterations && improved; iter++ {
		improved = false
		for i := 0; i < n; i++ {
			bestComm := community[i]
			bestGain := 0.0

			// Calculate weight from node i to each neighboring community.
			commWeights := make(map[int]float64)
			for j, w := range adj[i] {
				commWeights[community[j]] += w
			}

			// Weight to own community (for removal calculation).
			ki := degree[i]
			ownComm := community[i]

			// Sum of degrees in own community (excluding self).
			sigmaTotOwn := communityDegreeSum(community, degree, ownComm, i)

			// Remove i from its community: modularity change component.
			kiIn := commWeights[ownComm]
			removeGain := -(kiIn/m2 - (sigmaTotOwn*ki)/(m2*m2)*2)

			for c, wc := range commWeights {
				if c == ownComm {
					continue
				}
				sigmaTot := communityDegreeSum(community, degree, c, -1)
				// Gain from adding i to community c.
				addGain := wc/m2 - (sigmaTot*ki)/(m2*m2)*2
				totalGain := removeGain + addGain
				if totalGain > bestGain {
					bestGain = totalGain
					bestComm = c
				}
			}

			if bestComm != community[i] {
				community[i] = bestComm
				improved = true
			}
		}
	}

	// Collect communities.
	commNodes := make(map[int][]string)
	for i, c := range community {
		commNodes[c] = append(commNodes[c], nodes[i].ID)
	}

	communities := make([]Community, 0, len(commNodes))
	idx := 0
	for _, nodeIDs := range commNodes {
		if len(nodeIDs) < cd.MinCommunitySize {
			continue
		}
		strength := cd.communityStrength(nodeIDs, nodeIndex, adj, totalWeight, degree)
		communities = append(communities, Community{
			ID:       communityID(0, idx),
			Level:    0,
			NodeIDs:  nodeIDs,
			Strength: strength,
		})
		idx++
	}

	// Sort by descending strength for deterministic ordering.
	sort.Slice(communities, func(i, j int) bool {
		return communities[i].Strength > communities[j].Strength
	})

	return communities
}

// HierarchicalCommunities produces multi-level community hierarchy by repeatedly
// merging communities from finer levels. Level 0 = Detect() output. Level 1 merges
// Level 0 communities that share edges, and so on up to the requested depth.
func (cd *CommunityDetector) HierarchicalCommunities(nodes []*storage.Node, edges []*storage.Edge, levels int) [][]Community {
	if levels < 1 {
		levels = 1
	}

	result := make([][]Community, 0, levels)

	// Level 0: base detection.
	level0 := cd.Detect(nodes, edges)
	result = append(result, level0)

	if levels == 1 || len(level0) <= 1 {
		return result
	}

	// For higher levels, we build a "super-graph" where each community becomes a node,
	// and edges between communities are the sum of cross-community edge weights.
	prevCommunities := level0

	for lv := 1; lv < levels; lv++ {
		if len(prevCommunities) <= 1 {
			break
		}

		// Map each original node to its community index at the previous level.
		nodeToComm := make(map[string]int)
		for ci, c := range prevCommunities {
			for _, nid := range c.NodeIDs {
				nodeToComm[nid] = ci
			}
		}

		// Build super-graph adjacency.
		nc := len(prevCommunities)
		superAdj := make([]map[int]float64, nc)
		for i := range superAdj {
			superAdj[i] = make(map[int]float64)
		}
		superDegree := make([]float64, nc)
		superTotalWeight := 0.0

		for _, e := range edges {
			ci, ok1 := nodeToComm[e.FromID]
			cj, ok2 := nodeToComm[e.ToID]
			if !ok1 || !ok2 || ci == cj {
				continue
			}
			w := e.Weight
			if w <= 0 {
				w = 1.0
			}
			superAdj[ci][cj] += w
			superAdj[cj][ci] += w
			superTotalWeight += w
		}

		if superTotalWeight == 0 {
			break
		}

		for i := 0; i < nc; i++ {
			for _, w := range superAdj[i] {
				superDegree[i] += w
			}
		}

		// Run Louvain on super-graph.
		superComm := make([]int, nc)
		for i := range superComm {
			superComm[i] = i
		}

		m2 := 2.0 * superTotalWeight
		improved := true
		for iter := 0; iter < 50 && improved; iter++ {
			improved = false
			for i := 0; i < nc; i++ {
				bestComm := superComm[i]
				bestGain := 0.0

				commWeights := make(map[int]float64)
				for j, w := range superAdj[i] {
					commWeights[superComm[j]] += w
				}

				ki := superDegree[i]
				ownComm := superComm[i]
				sigmaTotOwn := communityDegreeSum(superComm, superDegree, ownComm, i)
				kiIn := commWeights[ownComm]
				removeGain := -(kiIn/m2 - (sigmaTotOwn*ki)/(m2*m2)*2)

				for c, wc := range commWeights {
					if c == ownComm {
						continue
					}
					sigmaTot := communityDegreeSum(superComm, superDegree, c, -1)
					addGain := wc/m2 - (sigmaTot*ki)/(m2*m2)*2
					totalGain := removeGain + addGain
					if totalGain > bestGain {
						bestGain = totalGain
						bestComm = c
					}
				}

				if bestComm != superComm[i] {
					superComm[i] = bestComm
					improved = true
				}
			}
		}

		// Collect merged communities.
		mergedComm := make(map[int][]int)
		for ci, sc := range superComm {
			mergedComm[sc] = append(mergedComm[sc], ci)
		}

		levelCommunities := make([]Community, 0, len(mergedComm))
		idx := 0
		for _, subCommIdxs := range mergedComm {
			var allNodeIDs []string
			for _, sci := range subCommIdxs {
				allNodeIDs = append(allNodeIDs, prevCommunities[sci].NodeIDs...)
			}
			if len(allNodeIDs) < cd.MinCommunitySize {
				continue
			}
			levelCommunities = append(levelCommunities, Community{
				ID:       communityID(lv, idx),
				Level:    lv,
				NodeIDs:  allNodeIDs,
				Strength: float64(len(allNodeIDs)),
			})
			idx++
		}

		sort.Slice(levelCommunities, func(i, j int) bool {
			return len(levelCommunities[i].NodeIDs) > len(levelCommunities[j].NodeIDs)
		})

		result = append(result, levelCommunities)
		prevCommunities = levelCommunities
	}

	return result
}

// Modularity computes Newman-Girvan modularity Q for the given partition.
// Q = (1/2m) * sum_ij [ A_ij - ki*kj/(2m) ] * delta(ci, cj)
// where m = total edge weight, A_ij = adjacency weight, ki = degree of i.
// The sum is over all ordered pairs (i,j), not just existing edges.
func Modularity(communities []Community, edges []*storage.Edge) float64 {
	if len(edges) == 0 {
		return 0
	}

	// Map node -> community index.
	nodeComm := make(map[string]int)
	for ci, c := range communities {
		for _, nid := range c.NodeIDs {
			nodeComm[nid] = ci
		}
	}

	// Total weight (m = sum of all edge weights, treating graph as undirected).
	totalWeight := 0.0
	for _, e := range edges {
		w := e.Weight
		if w <= 0 {
			w = 1.0
		}
		totalWeight += w
	}
	if totalWeight == 0 {
		return 0
	}
	m2 := 2.0 * totalWeight

	// Degree of each node (sum of weights of incident edges, undirected).
	degree := make(map[string]float64)
	for _, e := range edges {
		w := e.Weight
		if w <= 0 {
			w = 1.0
		}
		degree[e.FromID] += w
		degree[e.ToID] += w
	}

	// Q = (1/2m) * [ sum of A_ij for same-community edges - sum of ki*kj/(2m) for same-community pairs ]
	// First term: sum of edge weights within same community (count each edge once, multiply by 2 for the pair sum).
	internalEdgeWeight := 0.0
	for _, e := range edges {
		ci, ok1 := nodeComm[e.FromID]
		cj, ok2 := nodeComm[e.ToID]
		if !ok1 || !ok2 {
			continue
		}
		w := e.Weight
		if w <= 0 {
			w = 1.0
		}
		if ci == cj {
			internalEdgeWeight += 2 * w // both (i,j) and (j,i)
		}
	}

	// Second term: for each community, sum of (ki * kj) / (2m) over all pairs in that community.
	// This equals (Sigma_c)^2 / (2m) where Sigma_c = sum of degrees in community c.
	commDegreeSum := make(map[int]float64)
	for nid, ki := range degree {
		if ci, ok := nodeComm[nid]; ok {
			commDegreeSum[ci] += ki
		}
	}
	expectedInternal := 0.0
	for _, sigma := range commDegreeSum {
		expectedInternal += sigma * sigma / m2
	}

	return (internalEdgeWeight - expectedInternal) / m2
}

// communityDegreeSum returns the sum of degrees of all nodes in community c,
// optionally excluding node 'exclude' (pass -1 to not exclude any).
func communityDegreeSum(community []int, degree []float64, c int, exclude int) float64 {
	sum := 0.0
	for i, comm := range community {
		if comm == c && i != exclude {
			sum += degree[i]
		}
	}
	return sum
}

// communityStrength computes internal density / expected density for a community.
func (cd *CommunityDetector) communityStrength(nodeIDs []string, nodeIndex map[string]int, adj []map[int]float64, totalWeight float64, degree []float64) float64 {
	if len(nodeIDs) < 2 {
		return 1.0
	}

	memberSet := make(map[int]bool, len(nodeIDs))
	for _, nid := range nodeIDs {
		if idx, ok := nodeIndex[nid]; ok {
			memberSet[idx] = true
		}
	}

	// Internal edge weight.
	internalWeight := 0.0
	for idx := range memberSet {
		for j, w := range adj[idx] {
			if memberSet[j] && j > idx { // count each edge once
				internalWeight += w
			}
		}
	}

	// Expected internal weight if edges were random: sum_pairs (ki*kj) / (2m)
	sumDeg := 0.0
	sumDegSq := 0.0
	for idx := range memberSet {
		sumDeg += degree[idx]
		sumDegSq += degree[idx] * degree[idx]
	}
	m2 := 2.0 * totalWeight
	expected := (sumDeg*sumDeg - sumDegSq) / (2.0 * m2)

	if expected == 0 {
		return 1.0
	}
	return math.Min(internalWeight/expected, 10.0) // cap at 10x
}

// communityID generates a deterministic community ID from level and index.
func communityID(level, index int) string {
	return fmt.Sprintf("community-L%d-%d", level, index)
}
