package graph

import (
	"math"
	"sort"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// CommunitySearcher provides search operations over detected communities.
// It implements keyword-based ranking (BM25) and token-budgeted context building,
// inspired by GraphRAG's global search over community summaries.
type CommunitySearcher struct {
	// NodeLookup maps node IDs to their full Node data for expansion.
	NodeLookup map[string]*storage.Node
}

// NewCommunitySearcher creates a searcher with the given node lookup table.
func NewCommunitySearcher(nodes []*storage.Node) *CommunitySearcher {
	lookup := make(map[string]*storage.Node, len(nodes))
	for _, n := range nodes {
		lookup[n.ID] = n
	}
	return &CommunitySearcher{NodeLookup: lookup}
}

// SearchByCommunity finds communities whose summaries or keywords match the query.
// Returns communities sorted by relevance (descending).
func (cs *CommunitySearcher) SearchByCommunity(query string, communities []Community) []Community {
	if query == "" || len(communities) == 0 {
		return nil
	}

	return cs.RankCommunitiesByRelevance(query, communities)
}

// ExpandCommunity returns all nodes belonging to the given community ID.
func (cs *CommunitySearcher) ExpandCommunity(communityID string, communities []Community) []*storage.Node {
	for _, c := range communities {
		if c.ID == communityID {
			nodes := make([]*storage.Node, 0, len(c.NodeIDs))
			for _, nid := range c.NodeIDs {
				if n, ok := cs.NodeLookup[nid]; ok {
					nodes = append(nodes, n)
				}
			}
			return nodes
		}
	}
	return nil
}

// CommunitySummaryForContext formats the top communities into a context string
// that fits within the given token budget. Each token is approximated as 4 characters.
func (cs *CommunitySearcher) CommunitySummaryForContext(communities []Community, tokenBudget int) string {
	if len(communities) == 0 || tokenBudget <= 0 {
		return ""
	}

	const charsPerToken = 4
	charBudget := tokenBudget * charsPerToken

	var sb strings.Builder
	sb.WriteString("## Community Context\n\n")
	headerLen := sb.Len()

	for i, c := range communities {
		var entry strings.Builder
		entry.WriteString("### ")
		if c.Summary != "" {
			entry.WriteString(c.Summary)
		} else {
			entry.WriteString(c.ID)
		}
		entry.WriteString("\n")

		if len(c.Keywords) > 0 {
			entry.WriteString("Keywords: ")
			entry.WriteString(strings.Join(c.Keywords, ", "))
			entry.WriteString("\n")
		}

		entry.WriteString("Nodes: ")
		nodeNames := cs.nodeNames(c.NodeIDs)
		entry.WriteString(strings.Join(nodeNames, ", "))
		entry.WriteString("\n\n")

		entryStr := entry.String()
		if sb.Len()+len(entryStr) > charBudget {
			// If we haven't added anything yet, try to fit at least a truncated version.
			if i == 0 {
				remaining := charBudget - headerLen
				if remaining > 20 {
					sb.WriteString(entryStr[:remaining])
				}
			}
			break
		}
		sb.WriteString(entryStr)
	}

	return sb.String()
}

// RankCommunitiesByRelevance ranks communities using BM25-style scoring on their
// summaries and keywords. Returns a new slice sorted by descending relevance score.
func (cs *CommunitySearcher) RankCommunitiesByRelevance(query string, communities []Community) []Community {
	if len(communities) == 0 {
		return nil
	}

	queryTerms := tokenize(query)
	if len(queryTerms) == 0 {
		return nil
	}

	// Build corpus: each community's text = summary + keywords + node content summaries.
	type scoredCommunity struct {
		community Community
		score     float64
	}

	// Compute average document length and document frequencies.
	docs := make([][]string, len(communities))
	totalLen := 0
	df := make(map[string]int) // document frequency per term
	for i, c := range communities {
		doc := cs.communityDocument(c)
		docs[i] = doc
		totalLen += len(doc)
		seen := make(map[string]bool)
		for _, term := range doc {
			if !seen[term] {
				df[term]++
				seen[term] = true
			}
		}
	}

	avgDL := float64(totalLen) / float64(len(communities))
	n := float64(len(communities))

	// BM25 parameters.
	const k1 = 1.2
	const b = 0.75

	scored := make([]scoredCommunity, 0, len(communities))
	for i, c := range communities {
		score := 0.0
		dl := float64(len(docs[i]))

		// Count term frequencies in this document.
		tf := make(map[string]int)
		for _, term := range docs[i] {
			tf[term]++
		}

		for _, qt := range queryTerms {
			termDF := float64(df[qt])
			if termDF == 0 {
				continue
			}
			// Inverse document frequency, BM25 form: the log of
			// (N minus df plus 0.5) over (df plus 0.5), plus one.
			idf := math.Log((n-termDF+0.5)/(termDF+0.5) + 1.0)

			termTF := float64(tf[qt])
			// BM25 TF component.
			tfNorm := (termTF * (k1 + 1)) / (termTF + k1*(1-b+b*dl/avgDL))
			score += idf * tfNorm
		}

		if score > 0 {
			scored = append(scored, scoredCommunity{community: c, score: score})
		}
	}

	sort.Slice(scored, func(i, j int) bool {
		return scored[i].score > scored[j].score
	})

	result := make([]Community, len(scored))
	for i, sc := range scored {
		result[i] = sc.community
	}
	return result
}

// communityDocument builds the text tokens for a community for BM25 scoring.
func (cs *CommunitySearcher) communityDocument(c Community) []string {
	var parts []string

	// Include summary.
	if c.Summary != "" {
		parts = append(parts, tokenize(c.Summary)...)
	}

	// Include keywords.
	for _, kw := range c.Keywords {
		parts = append(parts, tokenize(kw)...)
	}

	// Include node content (first 50 chars each to keep manageable).
	for _, nid := range c.NodeIDs {
		if n, ok := cs.NodeLookup[nid]; ok {
			content := n.Content
			if len(content) > 100 {
				content = content[:100]
			}
			parts = append(parts, tokenize(content)...)
		}
	}

	return parts
}

// nodeNames returns display names (Content trimmed to 40 chars) for a list of node IDs.
func (cs *CommunitySearcher) nodeNames(nodeIDs []string) []string {
	names := make([]string, 0, len(nodeIDs))
	for _, nid := range nodeIDs {
		if n, ok := cs.NodeLookup[nid]; ok {
			name := n.Content
			if len(name) > 40 {
				name = name[:40] + "..."
			}
			names = append(names, name)
		} else {
			names = append(names, nid)
		}
	}
	return names
}

// tokenize splits text into lowercase terms, stripping basic punctuation.
func tokenize(text string) []string {
	text = strings.ToLower(text)
	// Replace common punctuation with spaces.
	replacer := strings.NewReplacer(
		",", " ", ".", " ", ";", " ", ":", " ",
		"(", " ", ")", " ", "[", " ", "]", " ",
		"{", " ", "}", " ", "\"", " ", "'", " ",
		"\n", " ", "\t", " ", "/", " ", "-", " ",
		"_", " ",
	)
	text = replacer.Replace(text)

	words := strings.Fields(text)
	// Filter out very short terms.
	result := make([]string, 0, len(words))
	for _, w := range words {
		if len(w) >= 2 {
			result = append(result, w)
		}
	}
	return result
}
