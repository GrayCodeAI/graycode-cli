package hooks

import "testing"

func TestScoreRelevance_Errors(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Bash", "npm install", "", "exit code 1")
	if score < 0.9 {
		t.Errorf("errors should score 0.9, got %f", score)
	}
}

func TestScoreRelevance_FileModifications(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Write", "src/components/auth/main.go", "file written successfully to disk", "")
	if score < 0.7 {
		t.Errorf("Write tool should score >= 0.7, got %f", score)
	}
}

func TestScoreRelevance_ReadLowSignal(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Read", "src/main.go", "package main...", "")
	if score > 0.5 {
		t.Errorf("Read tool should be low signal, got %f", score)
	}
}

func TestScoreRelevance_BashInstall(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Bash", "npm install express morgan helmet", "added 50 packages in 3.2s", "")
	if score < 0.7 {
		t.Errorf("install commands should score >= 0.7, got %f", score)
	}
}

func TestScoreRelevance_BashNavigation(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Bash", "ls src/", "main.go utils.go", "")
	if score > 0.3 {
		t.Errorf("navigation commands should be low signal, got %f", score)
	}
}

func TestScoreRelevance_DecisionSignal(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Bash", "decided to use jose", "switched to jose library", "")
	if score < 0.5 {
		t.Errorf("decision signals should boost score, got %f", score)
	}
}

func TestShouldCapture_HighSignal(t *testing.T) {
	t.Parallel()
	if !ShouldCapture("Write", "writing config", "done", "") {
		t.Error("Write tool should pass capture threshold")
	}
}

func TestShouldCapture_LowSignal(t *testing.T) {
	t.Parallel()
	if ShouldCapture("Read", "x", "y", "") {
		t.Error("short Read output should not pass capture threshold")
	}
}

func TestScoreRelevance_CappedAt1(t *testing.T) {
	t.Parallel()
	score := ScoreRelevance("Write", "decided to always enforce convention required", "written pattern", "")
	if score > 1.0 {
		t.Errorf("score should never exceed 1.0, got %f", score)
	}
}

func TestContainsDecisionSignal(t *testing.T) {
	t.Parallel()
	if !containsDecisionSignal("we decided to use postgres") {
		t.Error("should detect 'decided'")
	}
	if containsDecisionSignal("the weather is nice") {
		t.Error("should not detect false positives")
	}
}

func TestContainsConventionSignal(t *testing.T) {
	t.Parallel()
	if !containsConventionSignal("always use camelCase") {
		t.Error("should detect 'always'")
	}
	if !containsConventionSignal("this is required for deployment") {
		t.Error("should detect 'required'")
	}
}
