package engine

import (
	"strconv"
	"sync"
	"time"
)

// QueryCache is an LRU cache for recall results. Eliminates redundant
// SQLite queries for frequently-asked questions within a session.
// Auto-invalidates on writes (Remember, Forget, Feedback).
type QueryCache struct {
	mu      sync.RWMutex
	entries map[string]*cacheEntry
	order   []string // LRU order (most recent at end)
	maxSize int
	ttl     time.Duration
	version uint64 // bumped on every write, invalidates all entries
}

type cacheEntry struct {
	result  *RecallResult
	version uint64
	created time.Time
}

// NewQueryCache creates a cache with configurable size and TTL.
func NewQueryCache(maxSize int, ttl time.Duration) *QueryCache {
	if maxSize <= 0 {
		maxSize = 64
	}
	if ttl <= 0 {
		ttl = 5 * time.Minute
	}
	return &QueryCache{
		entries: make(map[string]*cacheEntry),
		order:   make([]string, 0, maxSize),
		maxSize: maxSize,
		ttl:     ttl,
	}
}

// Get retrieves a cached result. Returns nil if miss or stale.
func (c *QueryCache) Get(key string) *RecallResult {
	c.mu.RLock()
	defer c.mu.RUnlock()

	entry, ok := c.entries[key]
	if !ok {
		return nil
	}
	// Check version (invalidated by writes)
	if entry.version != c.version {
		return nil
	}
	// Check TTL
	if time.Since(entry.created) > c.ttl {
		return nil
	}
	return entry.result
}

// Put stores a result in the cache.
func (c *QueryCache) Put(key string, result *RecallResult) {
	c.mu.Lock()
	defer c.mu.Unlock()

	// Evict if at capacity
	if len(c.entries) >= c.maxSize {
		c.evictOldest()
	}

	c.entries[key] = &cacheEntry{
		result:  result,
		version: c.version,
		created: time.Now(),
	}
	c.order = append(c.order, key)
}

// Invalidate bumps the version, making all cached entries stale.
// Called after any write operation (Remember, Forget, Feedback, etc).
func (c *QueryCache) Invalidate() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.version++
}

// Stats returns cache hit/miss info.
func (c *QueryCache) Stats() (size int, version uint64) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.entries), c.version
}

// Clear empties the cache entirely.
func (c *QueryCache) Clear() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.entries = make(map[string]*cacheEntry)
	c.order = c.order[:0]
}

func (c *QueryCache) evictOldest() {
	if len(c.order) == 0 {
		return
	}
	oldest := c.order[0]
	c.order = c.order[1:]
	delete(c.entries, oldest)
}

// CacheKey builds a cache key from recall options.
func CacheKey(opts RecallOpts) string {
	return opts.Query + "|" + opts.Type + "|" + opts.Project + "|" + strconv.Itoa(opts.Limit) + "|" + strconv.Itoa(opts.Depth)
}
