package engine

import (
	"math"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// ScoringConfig holds tunable parameters for retrieval scoring.
type ScoringConfig struct {
	BM25Weight     float64 // weight for BM25 signal in fusion (default 0.4)
	VectorWeight   float64 // weight for vector signal (default 0.3)
	GraphWeight    float64 // weight for graph signal (default 0.2)
	RecencyWeight  float64 // weight for recency signal (default 0.1)
	EntityBoostCap float64 // max entity boost multiplier (default 2.0)
	MMRLambda      float64 // diversity vs relevance tradeoff (default 0.85)
	SpreadDecay    float64 // entity spread attenuation factor (default 0.001)
}

// DefaultScoringConfig returns production-tuned scoring parameters.
func DefaultScoringConfig() ScoringConfig {
	return ScoringConfig{
		BM25Weight:     0.4,
		VectorWeight:   0.3,
		GraphWeight:    0.2,
		RecencyWeight:  0.1,
		EntityBoostCap: 2.0,
		MMRLambda:      0.85,
		SpreadDecay:    0.001,
	}
}

// NormalizeBM25 applies sigmoid normalization to raw BM25 scores with
// query-length-adaptive parameters. Based on Mem0 v3's approach.
//
// Short queries (1-3 terms): midpoint=5.0, steepness=0.7
// Medium queries (4-6 terms): midpoint=7.0, steepness=0.6
// Long queries (7-14 terms): midpoint=10.0, steepness=0.5
// Very long queries (15+): midpoint=12.0, steepness=0.4
func NormalizeBM25(rawScore float64, queryTermCount int) float64 {
	midpoint, steepness := bm25SigmoidParams(queryTermCount)
	return 1.0 / (1.0 + math.Exp(-steepness*(rawScore-midpoint)))
}

func bm25SigmoidParams(termCount int) (midpoint, steepness float64) {
	switch {
	case termCount <= 3:
		return 5.0, 0.7
	case termCount <= 6:
		return 7.0, 0.6
	case termCount <= 14:
		return 10.0, 0.5
	default:
		return 12.0, 0.4
	}
}

// QueryTermCount counts significant terms in a query (for BM25 normalization).
func QueryTermCount(query string) int {
	terms := strings.Fields(query)
	count := 0
	for _, t := range terms {
		if len(t) >= 3 {
			count++
		}
	}
	return count
}

// SpreadAttenuatedBoost computes entity boost with spread attenuation.
// Penalizes entities that link to many memories (too generic).
// Based on Mem0 v3: boost = similarity * 0.5 * 1/(1 + decay*(numLinked-1)²)
func SpreadAttenuatedBoost(similarity float64, numLinked int, decay float64) float64 {
	if numLinked <= 0 {
		return 0
	}
	spread := 1.0 / (1.0 + decay*math.Pow(float64(numLinked-1), 2))
	return similarity * 0.5 * spread
}

// MMRRerank applies Maximal Marginal Relevance to diversify results.
// MMR = λ * relevance(doc) - (1-λ) * max_sim(doc, selected)
// Prevents near-duplicate results from dominating the output.
func MMRRerank(nodes []*storage.Node, scores map[string]float64, lambda float64, k int) []*storage.Node {
	if len(nodes) <= 1 || k <= 0 {
		return nodes
	}
	if k > len(nodes) {
		k = len(nodes)
	}

	selected := make([]*storage.Node, 0, k)
	remaining := make([]*storage.Node, len(nodes))
	copy(remaining, nodes)

	// Pre-compute term sets for all nodes to avoid repeated tokenization
	termSets := make([]map[string]bool, len(nodes))
	for i, n := range nodes {
		termSets[i] = termSetFromContent(n.Content)
	}

	// Select first by pure relevance
	bestIdx := 0
	bestScore := -1.0
	for i, n := range remaining {
		if s, ok := scores[n.ID]; ok && s > bestScore {
			bestScore = s
			bestIdx = i
		}
	}
	selected = append(selected, remaining[bestIdx])
	selectedTermSets := []map[string]bool{termSets[bestIdx]}
	remaining = append(remaining[:bestIdx], remaining[bestIdx+1:]...)
	remainingTermSets := make([]map[string]bool, len(termSets)-1)
	copy(remainingTermSets[:bestIdx], termSets[:bestIdx])
	copy(remainingTermSets[bestIdx:], termSets[bestIdx+1:])

	// Select remaining by MMR
	for len(selected) < k && len(remaining) > 0 {
		bestMMR := math.Inf(-1)
		bestIdx = 0

		for i, candidate := range remaining {
			relevance := scores[candidate.ID]

			// Max similarity to already-selected documents (using pre-computed term sets)
			maxSim := 0.0
			for _, selTerms := range selectedTermSets {
				sim := jaccardFromSets(remainingTermSets[i], selTerms)
				if sim > maxSim {
					maxSim = sim
				}
			}

			mmr := lambda*relevance - (1-lambda)*maxSim
			if mmr > bestMMR {
				bestMMR = mmr
				bestIdx = i
			}
		}

		selected = append(selected, remaining[bestIdx])
		selectedTermSets = append(selectedTermSets, remainingTermSets[bestIdx])
		remaining = append(remaining[:bestIdx], remaining[bestIdx+1:]...)
		remainingTermSets = append(remainingTermSets[:bestIdx], remainingTermSets[bestIdx+1:]...)
	}

	return selected
}

// termSetFromContent tokenizes content and returns a term set for pre-computation.
func termSetFromContent(content string) map[string]bool {
	terms := make(map[string]bool)
	for _, t := range tokenize(content) {
		terms[t] = true
	}
	return terms
}

// jaccardFromSets computes Jaccard similarity from pre-computed term sets.
func jaccardFromSets(a, b map[string]bool) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	intersection := 0
	for t := range a {
		if b[t] {
			intersection++
		}
	}
	union := len(a) + len(b) - intersection
	if union == 0 {
		return 0
	}
	return float64(intersection) / float64(union)
}
