package engine

import (
	"math/rand"
	"testing"
)

func TestHNSW_InsertAndSearch(t *testing.T) {
	t.Parallel()
	h := NewHNSW(4) // 4-dimensional for testing

	// Insert vectors
	h.Insert("a", []float32{1, 0, 0, 0})
	h.Insert("b", []float32{0, 1, 0, 0})
	h.Insert("c", []float32{0, 0, 1, 0})
	h.Insert("d", []float32{0.9, 0.1, 0, 0}) // close to "a"

	if h.Size() != 4 {
		t.Fatalf("Size = %d, want 4", h.Size())
	}

	// Search for vector close to "a"
	ids, dists := h.Search([]float32{0.95, 0.05, 0, 0}, 2)
	if len(ids) < 2 {
		t.Fatalf("expected at least 2 results, got %d", len(ids))
	}

	// First result should be "a" or "d" (both close)
	if ids[0] != "a" && ids[0] != "d" {
		t.Errorf("expected 'a' or 'd' as closest, got %q", ids[0])
	}

	// Distances should be sorted ascending
	if len(dists) >= 2 && dists[0] > dists[1] {
		t.Error("distances should be sorted ascending")
	}
}

func TestHNSW_SearchEmpty(t *testing.T) {
	t.Parallel()
	h := NewHNSW(4)
	ids, dists := h.Search([]float32{1, 0, 0, 0}, 5)
	if ids != nil || dists != nil {
		t.Error("empty index should return nil")
	}
}

func TestHNSW_DuplicateInsert(t *testing.T) {
	t.Parallel()
	h := NewHNSW(4)
	h.Insert("x", []float32{1, 0, 0, 0})
	h.Insert("x", []float32{0, 1, 0, 0}) // duplicate ID
	if h.Size() != 1 {
		t.Errorf("duplicate insert should be ignored, Size = %d", h.Size())
	}
}

func TestHNSW_Remove(t *testing.T) {
	t.Parallel()
	h := NewHNSW(4)
	h.Insert("a", []float32{1, 0, 0, 0})
	h.Insert("b", []float32{0, 1, 0, 0})

	h.Remove("a")
	if h.Contains("a") {
		t.Error("'a' should be removed")
	}
	if !h.Contains("b") {
		t.Error("'b' should still exist")
	}
}

func TestHNSW_LargeIndex(t *testing.T) {
	t.Parallel()
	h := NewHNSW(32)
	dim := 32

	// Insert 500 random vectors
	for i := 0; i < 500; i++ {
		vec := make([]float32, dim)
		for j := range vec {
			vec[j] = rand.Float32()
		}
		h.Insert(string(rune('A'+i%26))+string(rune('0'+i/26)), vec)
	}

	if h.Size() != 500 {
		t.Fatalf("Size = %d, want 500", h.Size())
	}

	// Search should return results
	query := make([]float32, dim)
	for j := range query {
		query[j] = rand.Float32()
	}
	ids, dists := h.Search(query, 10)
	if len(ids) != 10 {
		t.Errorf("expected 10 results, got %d", len(ids))
	}
	// Verify sorted
	for i := 1; i < len(dists); i++ {
		if dists[i] < dists[i-1] {
			t.Errorf("distances not sorted at index %d: %f < %f", i, dists[i], dists[i-1])
		}
	}
}

func TestHNSW_WrongDimension(t *testing.T) {
	t.Parallel()
	h := NewHNSW(4)
	h.Insert("a", []float32{1, 0, 0}) // wrong dim, should be ignored
	if h.Size() != 0 {
		t.Error("wrong dimension should be rejected")
	}

	h.Insert("b", []float32{1, 0, 0, 0})
	ids, _ := h.Search([]float32{1, 0, 0}, 1) // wrong dim query
	if ids != nil {
		t.Error("wrong dim query should return nil")
	}
}
