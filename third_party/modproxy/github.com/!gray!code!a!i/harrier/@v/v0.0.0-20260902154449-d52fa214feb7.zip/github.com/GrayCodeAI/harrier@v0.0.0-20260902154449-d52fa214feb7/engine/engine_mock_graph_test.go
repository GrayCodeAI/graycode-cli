//nolint:gocritic
package engine

import (
	"context"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/intent"
	"github.com/GrayCodeAI/harrier/storage"
)

// This file is part of package engine tests. It holds mockGraph (the
// in-memory graph.Graph test double) and newTestEngine, moved verbatim out
// of engine_test.go for readability; behavior is unchanged.

// ---------------------------------------------------------------------------
// mockGraph — in-memory implementation of graph.Graph backed by storage
// ---------------------------------------------------------------------------

type mockGraph struct {
	store storage.Storage
}

func newMockGraph(store storage.Storage) *mockGraph {
	return &mockGraph{store: store}
}

func (g *mockGraph) AddNode(ctx context.Context, n *storage.Node) error {
	return g.store.CreateNode(ctx, n)
}

func (g *mockGraph) AddEdge(ctx context.Context, e *storage.Edge) error {
	return g.store.CreateEdge(ctx, e)
}

func (g *mockGraph) RemoveNode(ctx context.Context, id string) error {
	return g.store.DeleteNode(ctx, id)
}

func (g *mockGraph) RemoveEdge(ctx context.Context, id string) error {
	return g.store.DeleteEdge(ctx, id)
}

func (g *mockGraph) ExtractSubgraph(ctx context.Context, startID string, maxDepth int) (*graph.Subgraph, error) {
	ids, err := g.BFS(ctx, startID, maxDepth)
	if err != nil {
		return nil, err
	}
	sg := &graph.Subgraph{}
	for _, id := range ids {
		n, err := g.store.GetNode(ctx, id)
		if err == nil {
			sg.Nodes = append(sg.Nodes, n)
		}
	}
	idSet := make(map[string]bool, len(ids))
	for _, id := range ids {
		idSet[id] = true
	}
	for _, id := range ids {
		edges, _ := g.store.GetEdgesFrom(ctx, id)
		for _, e := range edges {
			if idSet[e.ToID] {
				sg.Edges = append(sg.Edges, e)
			}
		}
	}
	return sg, nil
}

func (g *mockGraph) BFS(ctx context.Context, startID string, maxDepth int) ([]string, error) {
	_, err := g.store.GetNode(ctx, startID)
	if err != nil {
		return nil, nil
	}
	visited := map[string]bool{startID: true}
	queue := []struct {
		id    string
		depth int
	}{{startID, 0}}
	var result []string
	result = append(result, startID)

	for len(queue) > 0 {
		curr := queue[0]
		queue = queue[1:]
		if curr.depth >= maxDepth {
			continue
		}
		edges, _ := g.store.GetEdgesFrom(ctx, curr.id)
		edgesTo, _ := g.store.GetEdgesTo(ctx, curr.id)
		allEdges := append(edges, edgesTo...)
		for _, e := range allEdges {
			var next string
			if e.FromID == curr.id {
				next = e.ToID
			} else {
				next = e.FromID
			}
			if !visited[next] {
				visited[next] = true
				result = append(result, next)
				queue = append(queue, struct {
					id    string
					depth int
				}{next, curr.depth + 1})
			}
		}
	}
	return result, nil
}

func (g *mockGraph) IntentBFS(ctx context.Context, startID string, maxDepth int, queryIntent intent.Intent) ([]string, error) {
	// For mock, delegate to plain BFS (intent weights are ignored)
	return g.BFS(ctx, startID, maxDepth)
}

func (g *mockGraph) Impact(ctx context.Context, filePath string, maxDepth int) ([]string, error) {
	return nil, nil
}

func (g *mockGraph) Ancestors(ctx context.Context, id string) ([]string, error) {
	return nil, nil
}

func (g *mockGraph) Descendants(ctx context.Context, id string) ([]string, error) {
	return nil, nil
}

// ---------------------------------------------------------------------------
// helper
// ---------------------------------------------------------------------------

func newTestEngine() *Engine {
	ms := newMockStorage()
	return New(ms, newMockGraph(ms))
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------
