package engine

import (
	"fmt"
	"sync"
	"testing"
)

func TestMinHashLSH_NearDuplicateDetection(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	// Insert documents with known similarities.
	termsA := map[string]bool{"use": true, "jose": true, "library": true, "jwt": true, "tokens": true}
	termsB := map[string]bool{"use": true, "jose": true, "library": true, "jwt": true, "authentication": true, "tokens": true}
	termsC := map[string]bool{"deploy": true, "docker": true, "fly.io": true}

	lsh.Insert("a", termsA)
	lsh.Insert("b", termsB)
	lsh.Insert("c", termsC)

	// Query for "a" should return "b" as a candidate (similar content).
	candidates := lsh.Query(termsA)
	found := false
	for _, id := range candidates {
		if id == "b" {
			found = true
		}
		if id == "c" {
			t.Error("dissimilar document 'c' should not be a candidate for 'a'")
		}
	}
	if !found {
		t.Error("similar document 'b' should be a candidate for 'a'")
	}
}

func TestMinHashLSH_IdenticalDocuments(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	terms := map[string]bool{"hello": true, "world": true, "test": true}
	lsh.Insert("x", terms)
	lsh.Insert("y", terms)

	candidates := lsh.Query(terms)
	if len(candidates) < 2 {
		t.Errorf("identical documents should both be candidates, got %d", len(candidates))
	}
}

func TestMinHashLSH_EmptyTerms(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	empty := map[string]bool{}
	lsh.Insert("empty", empty)

	candidates := lsh.Query(empty)
	// Should at least return the document itself (or nothing if empty terms produce
	// all-max signatures that hash to a single bucket).
	if len(candidates) > 1 {
		t.Logf("empty terms returned %d candidates (acceptable)", len(candidates))
	}
}

func TestMinHashLSH_Size(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	for i := 0; i < 100; i++ {
		terms := map[string]bool{fmt.Sprintf("term%d", i): true}
		lsh.Insert(fmt.Sprintf("doc%d", i), terms)
	}

	if lsh.Size() != 100 {
		t.Errorf("expected size 100, got %d", lsh.Size())
	}
}

func TestMinHashLSH_ConcurrentSafety(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	var wg sync.WaitGroup
	// Concurrent inserts.
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			terms := map[string]bool{fmt.Sprintf("term%d", id): true, "common": true}
			lsh.Insert(fmt.Sprintf("doc%d", id), terms)
		}(i)
	}
	wg.Wait()

	// Concurrent queries.
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			terms := map[string]bool{fmt.Sprintf("term%d", id): true, "common": true}
			_ = lsh.Query(terms)
		}(i)
	}
	wg.Wait()

	if lsh.Size() != 50 {
		t.Errorf("expected 50 documents, got %d", lsh.Size())
	}
}

func TestMinHashLSH_NoCrossTypeLeakage(t *testing.T) {
	t.Parallel()
	// The sparsify code creates separate LSH per type.
	// This test verifies that the LSH itself does not filter by type
	// (type filtering happens in mergeNearDuplicates, not in LSH).
	lsh := NewMinHashLSH(0.85)

	terms := map[string]bool{"shared": true, "terms": true, "here": true}
	lsh.Insert("typeA_1", terms)
	lsh.Insert("typeB_1", terms)

	candidates := lsh.Query(terms)
	if len(candidates) < 2 {
		t.Errorf("LSH does not filter by type; expected both, got %d", len(candidates))
	}
}

func TestMinHashLSH_HighSimilarityDetection(t *testing.T) {
	t.Parallel()
	lsh := NewMinHashLSH(0.85)

	// Generate 20 near-duplicate documents (Jaccard > 0.85 with base).
	base := map[string]bool{
		"alpha": true, "bravo": true, "charlie": true, "delta": true,
		"echo": true, "foxtrot": true, "golf": true, "hotel": true,
		"india": true, "juliet": true, "kilo": true, "lima": true,
		"mike": true, "november": true, "oscar": true, "papa": true,
		"quebec": true, "romeo": true, "sierra": true, "tango": true,
	}
	lsh.Insert("base", base)

	// Each variant replaces one term with a new one -> Jaccard = 19/21 = 0.905.
	for i := 0; i < 20; i++ {
		variant := make(map[string]bool)
		for k := range base {
			variant[k] = true
		}
		// Remove one old term, add one new.
		delete(variant, fmt.Sprintf("term_%d", i)) // won't exist, harmless
		variant[fmt.Sprintf("extra%d", i)] = true
		lsh.Insert(fmt.Sprintf("v%d", i), variant)
	}

	candidates := lsh.Query(base)
	if len(candidates) < 2 {
		t.Errorf("expected multiple candidates for high-similarity set, got %d", len(candidates))
	}
}
