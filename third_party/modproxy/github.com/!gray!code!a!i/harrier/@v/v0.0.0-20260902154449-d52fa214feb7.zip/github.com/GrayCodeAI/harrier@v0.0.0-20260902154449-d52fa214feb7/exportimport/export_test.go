package exportimport

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

func setupStore(t *testing.T) storage.Storage {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })
	return store
}

func TestExportJSON_EmptyProject(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	data, err := ExportJSON(ctx, store, "empty-project")
	if err != nil {
		t.Fatalf("ExportJSON: %v", err)
	}

	var export GraphExport
	if err := json.Unmarshal(data, &export); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if export.Version != "1.0" {
		t.Errorf("expected version 1.0, got %s", export.Version)
	}
	if len(export.Nodes) != 0 {
		t.Errorf("expected 0 nodes, got %d", len(export.Nodes))
	}
}

func TestExportJSON_WithNodes(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        "decision",
		Content:     "Use SQLite for persistence",
		ContentHash: "hash1",
		Scope:       "project",
		Project:     "myproj",
		Confidence:  0.9,
		Version:     1,
	}
	if err := store.CreateNode(ctx, node); err != nil {
		t.Fatal(err)
	}

	data, err := ExportJSON(ctx, store, "myproj")
	if err != nil {
		t.Fatalf("ExportJSON: %v", err)
	}

	var export GraphExport
	if err := json.Unmarshal(data, &export); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(export.Nodes) != 1 {
		t.Fatalf("expected 1 node, got %d", len(export.Nodes))
	}
	if export.Nodes[0].Content != "Use SQLite for persistence" {
		t.Errorf("unexpected content: %s", export.Nodes[0].Content)
	}
}

func TestImportJSON_RoundTrip(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	// Create a node and export
	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        "convention",
		Content:     "Always use gofmt",
		ContentHash: "hash2",
		Scope:       "project",
		Project:     "proj1",
		Confidence:  0.8,
		Version:     1,
	}
	store.CreateNode(ctx, node)

	data, _ := ExportJSON(ctx, store, "proj1")

	// Import into a fresh store
	store2 := setupStore(t)
	nodes, edges, err := ImportJSON(ctx, store2, data)
	if err != nil {
		t.Fatalf("ImportJSON: %v", err)
	}
	if nodes != 1 {
		t.Errorf("expected 1 node imported, got %d", nodes)
	}
	if edges != 0 {
		t.Errorf("expected 0 edges imported, got %d", edges)
	}

	// Verify node exists in store2
	got, err := store2.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if got.Content != "Always use gofmt" {
		t.Errorf("unexpected content: %s", got.Content)
	}
}

func TestImportJSON_InvalidJSON(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	_, _, err := ImportJSON(ctx, store, []byte("not json"))
	if err == nil {
		t.Error("expected error for invalid JSON")
	}
}

func TestImportJSON_DuplicateSkipped(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        "decision",
		Content:     "duplicate test",
		ContentHash: "hash3",
		Scope:       "project",
		Project:     "proj1",
		Version:     1,
	}
	store.CreateNode(ctx, node)

	data, _ := ExportJSON(ctx, store, "proj1")

	// Import the same data again - duplicates should be skipped
	nodes, _, err := ImportJSON(ctx, store, data)
	if err != nil {
		t.Fatalf("ImportJSON: %v", err)
	}
	if nodes != 0 {
		t.Errorf("expected 0 nodes on re-import (duplicates), got %d", nodes)
	}
}

func TestExportMarkdown_EmptyProject(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	md, err := ExportMarkdown(ctx, store, "empty")
	if err != nil {
		t.Fatalf("ExportMarkdown: %v", err)
	}
	if !strings.Contains(md, "# Harrier Memory Export") {
		t.Error("expected header in markdown output")
	}
	if !strings.Contains(md, "empty") {
		t.Error("expected project name in markdown output")
	}
}

func TestExportMarkdown_WithNodes(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	store.CreateNode(ctx, &storage.Node{
		ID:          uuid.New().String(),
		Type:        "convention",
		Content:     "Use tabs not spaces",
		ContentHash: "hash4",
		Scope:       "project",
		Project:     "proj1",
		Confidence:  0.75,
		Tags:        "style,format",
		Version:     1,
	})

	md, err := ExportMarkdown(ctx, store, "proj1")
	if err != nil {
		t.Fatalf("ExportMarkdown: %v", err)
	}
	if !strings.Contains(md, "Conventions") {
		t.Error("expected Conventions section header")
	}
	if !strings.Contains(md, "Use tabs not spaces") {
		t.Error("expected node content in markdown")
	}
	if !strings.Contains(md, "style,format") {
		t.Error("expected tags in markdown")
	}
}

func TestExportObsidian_CreatesFiles(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	store.CreateNode(ctx, &storage.Node{
		ID:          uuid.New().String(),
		Type:        "decision",
		Content:     "Use Obsidian for notes",
		ContentHash: "hash5",
		Scope:       "project",
		Project:     "proj1",
		Confidence:  0.8,
		Version:     1,
	})

	vaultDir := filepath.Join(t.TempDir(), "vault")
	written, err := ExportObsidian(ctx, store, "proj1", vaultDir)
	if err != nil {
		t.Fatalf("ExportObsidian: %v", err)
	}
	if written != 1 {
		t.Errorf("expected 1 file written, got %d", written)
	}

	// Verify the vault directory was created
	entries, err := os.ReadDir(vaultDir)
	if err != nil {
		t.Fatalf("ReadDir: %v", err)
	}
	if len(entries) != 1 {
		t.Errorf("expected 1 file in vault, got %d", len(entries))
	}
}

func TestExportObsidian_RelativePathError(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	_, err := ExportObsidian(ctx, store, "proj1", "relative/path")
	if err == nil {
		t.Error("expected error for relative path")
	}
}

func TestExportObsidian_EmptyProject(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	vaultDir := filepath.Join(t.TempDir(), "vault")
	written, err := ExportObsidian(ctx, store, "empty", vaultDir)
	if err != nil {
		t.Fatalf("ExportObsidian: %v", err)
	}
	if written != 0 {
		t.Errorf("expected 0 files for empty project, got %d", written)
	}
}
