# Harrier Examples

Harrier gives your coding agent persistent memory across sessions via MCP.

> **Note:** Harrier is a Go library, not a standalone binary. It ships no `harrier`
> command of its own. Memory is accessed through hawk's built-in MCP tools or
> by embedding the `engine` package in your own Go application.

## Setup (via hawk)

Harrier is integrated into hawk. Enable it in your hawk config:

```bash
hawk config set memory.enabled true
```

Your agent can now remember things across sessions:

```
You: Remember that this project uses PostgreSQL 15 with TimescaleDB
Agent: [stores in harrier] Got it, I'll remember that.

# Later session...
You: What database are we using?
Agent: [queries harrier] PostgreSQL 15 with TimescaleDB
```

## MCP Tools

Harrier exposes these MCP tools to your agent:

### `remember`

Store a fact or context:

```json
{
  "name": "remember",
  "arguments": {
    "content": "This API uses JWT with RS256",
    "tags": ["auth", "security"]
  }
}
```

### `recall`

Retrieve relevant memories:

```json
{
  "name": "recall",
  "arguments": {
    "query": "authentication method"
  }
}
```

### `forget`

Remove outdated memories:

```json
{
  "name": "forget",
  "arguments": {
    "id": "mem_abc123"
  }
}
```

## Go Library Usage

Embed harrier in your own Go application:

```go
import "github.com/GrayCodeAI/harrier/engine"

eng, err := engine.New(engine.Config{
    DataDir: "~/.harrier",
})
if err != nil {
    log.Fatal(err)
}
defer eng.Close()

// Store a memory
err = eng.Remember(ctx, engine.Memory{
    Content: "Project uses PostgreSQL 15",
    Tags:    []string{"database"},
})

// Recall relevant memories
results, err := eng.Recall(ctx, "database configuration")
```

## Demo TUI

A demo TUI is available for exploring harrier interactively:

```bash
cd cmd/harrier-tui
go run .
```

See the [main README](../README.md) for full documentation.
