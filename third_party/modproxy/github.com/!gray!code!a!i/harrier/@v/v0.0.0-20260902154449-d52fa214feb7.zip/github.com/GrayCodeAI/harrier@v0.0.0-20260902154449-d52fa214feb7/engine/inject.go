package engine

import (
	"context"
	"sort"
	"strings"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// InjectConfig controls proactive context injection behavior.
type InjectConfig struct {
	// Threshold is the minimum combined score (recency + relevance) a memory
	// must reach to be auto-injected into the conversation context.
	// Range: 0.0-1.0. Default: 0.3.
	Threshold float64

	// MaxInject is the maximum number of memories to inject per check.
	// Default: 5.
	MaxInject int

	// TokenBudget is the maximum tokens for injected context.
	// Default: 1000.
	TokenBudget int

	// Cooldown is the minimum time between injection rounds to avoid flooding.
	// Default: 30s.
	Cooldown time.Duration

	// RecencyWeight controls how much recency influences the combined score.
	// RelevanceWeight is (1 - RecencyWeight). Default: 0.4.
	RecencyWeight float64
}

// DefaultInjectConfig returns production-tuned injection parameters.
func DefaultInjectConfig() InjectConfig {
	return InjectConfig{
		Threshold:     0.3,
		MaxInject:     5,
		TokenBudget:   1000,
		Cooldown:      30 * time.Second,
		RecencyWeight: 0.4,
	}
}

// InjectedMemory is a memory selected for proactive injection along with its
// score and the reason it was surfaced.
type InjectedMemory struct {
	Node   *storage.Node
	Score  float64 // combined recency + relevance score
	Reason string  // human-readable explanation (e.g., "recently accessed + high relevance")
}

// InjectionResult holds the output of a proactive injection check.
type InjectionResult struct {
	Injected []InjectedMemory
	Skipped  int           // memories that were candidates but below threshold
	Duration time.Duration // how long the injection check took
}

// ProactiveInjector monitors conversation context and proactively surfaces
// relevant memories using recency + relevance scoring.
type ProactiveInjector struct {
	eng          *Engine
	cfg          InjectConfig
	lastInjectAt time.Time
}

// NewProactiveInjector creates a proactive injector with the given config.
func NewProactiveInjector(eng *Engine, cfg InjectConfig) *ProactiveInjector {
	if cfg.Threshold <= 0 {
		cfg.Threshold = 0.3
	}
	if cfg.MaxInject <= 0 {
		cfg.MaxInject = 5
	}
	if cfg.TokenBudget <= 0 {
		cfg.TokenBudget = 1000
	}
	if cfg.Cooldown <= 0 {
		cfg.Cooldown = 30 * time.Second
	}
	if cfg.RecencyWeight <= 0 || cfg.RecencyWeight >= 1 {
		cfg.RecencyWeight = 0.4
	}
	return &ProactiveInjector{eng: eng, cfg: cfg}
}

// Inject evaluates the current conversation context and proactively surfaces
// relevant memories that exceed the configured threshold. The conversationText
// is the recent conversation content used to find relevant memories.
func (pi *ProactiveInjector) Inject(ctx context.Context, conversationText string, project string) (*InjectionResult, error) {
	start := time.Now()

	// Cooldown check: avoid flooding the context
	if time.Since(pi.lastInjectAt) < pi.cfg.Cooldown {
		return &InjectionResult{Duration: time.Since(start)}, nil
	}

	result := &InjectionResult{}

	// Step 1: Find memories relevant to the conversation context via FTS
	query := extractKeyTerms(conversationText)
	if query == "" {
		result.Duration = time.Since(start)
		return result, nil
	}

	bm25Nodes, err := pi.eng.store.SearchNodes(ctx, query, pi.cfg.MaxInject*4)
	if err != nil {
		return nil, err
	}

	// Step 2: Load recent nodes (for recency scoring)
	recentNodes, err := pi.eng.store.ListNodes(ctx, storage.NodeFilter{
		Project: project,
		Limit:   pi.cfg.MaxInject * 4,
	})
	if err != nil {
		return nil, err
	}

	// Step 3: Build candidate set from both sources
	candidates := pi.mergeCandidates(bm25Nodes, recentNodes)

	// Step 4: Score each candidate with recency + relevance
	scored := pi.scoreCandidates(candidates, conversationText)

	// Step 5: Filter by threshold and limit
	sort.Slice(scored, func(i, j int) bool {
		return scored[i].Score > scored[j].Score
	})

	injectedCount := 0
	for _, s := range scored {
		if s.Score < pi.cfg.Threshold {
			result.Skipped++
			continue
		}
		if injectedCount >= pi.cfg.MaxInject {
			result.Skipped += len(scored) - injectedCount - result.Skipped
			break
		}
		// Check token budget
		nodeTokens := (len(s.Node.Content) + len(s.Node.Summary) + 50) / 4
		if result.totalTokens()+nodeTokens > pi.cfg.TokenBudget {
			result.Skipped++
			continue
		}
		mem := InjectedMemory{
			Node:   s.Node,
			Score:  s.Score,
			Reason: pi.buildReason(s.Node, s.Score),
		}
		result.Injected = append(result.Injected, mem)
		injectedCount++
	}

	pi.lastInjectAt = time.Now()
	atomic.AddInt64(&pi.eng.metrics.InjectChecks, 1)
	atomic.AddInt64(&pi.eng.metrics.InjectsPerformed, int64(len(result.Injected)))

	result.Duration = time.Since(start)
	return result, nil
}

// mergeCandidates deduplicates nodes from BM25 results and recent nodes.
func (pi *ProactiveInjector) mergeCandidates(bm25, recent []*storage.Node) []*storage.Node {
	seen := map[string]*storage.Node{}
	for _, n := range bm25 {
		seen[n.ID] = n
	}
	for _, n := range recent {
		if _, exists := seen[n.ID]; !exists {
			seen[n.ID] = n
		}
	}
	nodes := make([]*storage.Node, 0, len(seen))
	for _, n := range seen {
		nodes = append(nodes, n)
	}
	return nodes
}

// scoreCandidates computes a combined recency + relevance score for each node.
func (pi *ProactiveInjector) scoreCandidates(nodes []*storage.Node, conversationText string) []scoredCandidate {
	now := time.Now()
	var scored []scoredCandidate

	for _, n := range nodes {
		// Skip archived nodes
		if n.Confidence <= 0 {
			continue
		}

		recency := recencyScore(n, now)
		relevance := relevanceScore(n, conversationText)
		combined := pi.cfg.RecencyWeight*recency + (1-pi.cfg.RecencyWeight)*relevance

		// Apply type priority boost (conventions and decisions are more actionable)
		combined *= typePriorityBoost(n.Type)

		scored = append(scored, scoredCandidate{
			Node:  n,
			Score: combined,
		})
	}
	return scored
}

// buildReason explains why a memory was injected.
func (pi *ProactiveInjector) buildReason(n *storage.Node, score float64) string {
	var reasons []string

	// Recency check
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if !ref.IsZero() && time.Since(ref) < 24*time.Hour {
		reasons = append(reasons, "recently accessed")
	} else if !ref.IsZero() && time.Since(ref) < 7*24*time.Hour {
		reasons = append(reasons, "accessed this week")
	}

	// Confidence check
	if n.Confidence >= 0.8 {
		reasons = append(reasons, "high confidence")
	}

	// Type check
	if n.Pinned {
		reasons = append(reasons, "pinned")
	}
	if n.Type == "convention" || n.Type == "preference" {
		reasons = append(reasons, "always-follow")
	}

	if len(reasons) == 0 {
		reasons = append(reasons, "relevance match")
	}

	return strings.Join(reasons, " + ")
}

// scoredCandidate pairs a node with its injection score.
type scoredCandidate struct {
	Node  *storage.Node
	Score float64
}

// recencyScore computes a 0-1 recency score based on last access time.
func recencyScore(n *storage.Node, now time.Time) float64 {
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if ref.IsZero() {
		return 0.1
	}
	days := now.Sub(ref).Hours() / 24
	if days <= 0 {
		return 1.0
	}
	// Exponential decay: half-life of 14 days for injection scoring
	return 1.0 / (1.0 + days/14.0)
}

// relevanceScore computes a 0-1 relevance score using term overlap.
func relevanceScore(n *storage.Node, conversationText string) float64 {
	// Combine all searchable text from the node
	nodeText := n.Content + " " + n.Summary + " " + n.Tags
	overlap := termOverlap(strings.ToLower(nodeText), strings.ToLower(conversationText))
	confidenceBoost := n.Confidence * 0.3
	accessBoost := float64(n.AccessCount) * 0.02
	if accessBoost > 0.3 {
		accessBoost = 0.3
	}
	score := overlap + confidenceBoost + accessBoost
	if score > 1.0 {
		score = 1.0
	}
	return score
}

// typePriorityBoost returns a multiplier for actionable memory types.
func typePriorityBoost(nodeType string) float64 {
	switch nodeType {
	case "convention", "preference":
		return 1.4
	case "decision":
		return 1.2
	case "task":
		return 1.3
	case "bug":
		return 1.1
	case "spec":
		return 1.1
	default:
		return 1.0
	}
}

// extractKeyTerms pulls significant terms from conversation text for FTS query.
func extractKeyTerms(text string) string {
	words := strings.Fields(text)
	var terms []string
	seen := map[string]bool{}
	for _, w := range words {
		w = strings.ToLower(strings.Trim(w, ".,;:!?\"'()[]{}"))
		if len(w) >= 4 && !seen[w] && !stopWord(w) {
			seen[w] = true
			terms = append(terms, w)
			if len(terms) >= 10 {
				break
			}
		}
	}
	return strings.Join(terms, " ")
}

// stopWord identifies common English stop words to exclude from queries.
func stopWord(w string) bool {
	stop := map[string]bool{
		"this": true, "that": true, "with": true, "from": true,
		"have": true, "been": true, "were": true, "they": true,
		"will": true, "would": true, "could": true, "should": true,
		"about": true, "which": true, "there": true, "their": true,
		"what": true, "when": true, "where": true, "some": true,
		"into": true, "also": true, "just": true, "then": true,
		"than": true, "more": true, "very": true, "much": true,
		"does": true, "done": true, "like": true, "well": true,
		"your": true, "them": true, "each": true, "make": true,
	}
	return stop[w]
}

// totalTokens returns the estimated token count of the injection result.
func (r *InjectionResult) totalTokens() int {
	total := 0
	for _, m := range r.Injected {
		total += (len(m.Node.Content) + len(m.Node.Summary) + 50) / 4
	}
	return total
}
