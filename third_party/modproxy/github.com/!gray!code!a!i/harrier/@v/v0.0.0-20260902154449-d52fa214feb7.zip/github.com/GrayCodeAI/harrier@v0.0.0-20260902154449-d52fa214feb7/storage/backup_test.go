package storage

import (
	"context"
	"os"
	"path/filepath"
	"testing"
)

func TestBackup(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Seed some data so the backup is non-trivial.
	if err := s.CreateNode(ctx, &Node{
		ID: "backup-node", Type: "convention", Content: "backup me",
		ContentHash: "h-backup", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}

	backupPath := filepath.Join(t.TempDir(), "sub", "backup.db")
	if err := s.Backup(ctx, backupPath); err != nil {
		t.Fatalf("Backup: %v", err)
	}

	fi, err := os.Stat(backupPath)
	if err != nil {
		t.Fatalf("backup file not created: %v", err)
	}
	if fi.Size() == 0 {
		t.Error("backup file is empty")
	}
	// Owner-only permissions (mask umask for strictness).
	if perm := fi.Mode().Perm() & 0o777; perm != 0o600 {
		t.Errorf("backup permissions = %o, want 600", perm)
	}

	// The backup must be a standalone, consistent database: opening it and
	// reading the seeded node should work.
	restore, err := NewStore(backupPath)
	if err != nil {
		t.Fatalf("open backup: %v", err)
	}
	defer restore.Close()
	n, err := restore.GetNode(ctx, "backup-node")
	if err != nil {
		t.Fatalf("GetNode from backup: %v", err)
	}
	if n.Content != "backup me" {
		t.Errorf("backup content = %q, want %q", n.Content, "backup me")
	}
}

func TestBackupEmptyPath(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.Backup(context.Background(), ""); err == nil {
		t.Error("expected error for empty backup path")
	}
}

func TestBackupInsideTx(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	err := s.WithTx(ctx, func(tx Storage) error {
		return tx.Backup(ctx, filepath.Join(t.TempDir(), "nope.db"))
	})
	if err == nil {
		t.Error("expected error backing up inside a transaction")
	}
}
