package skill

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func setupEngine(t *testing.T) (*engine.Engine, storage.Storage) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })

	g := graph.New(store, store.DB())
	eng := engine.New(store, g)
	t.Cleanup(func() { eng.Close() })
	return eng, store
}

func TestStore_CreatesSkillNode(t *testing.T) {
	t.Parallel()
	eng, store := setupEngine(t)
	ctx := context.Background()

	s := &Skill{
		Name:        "deploy",
		Description: "Deploy the application",
		Steps: []Step{
			{Order: 1, Description: "Build binary", Command: "go build ./..."},
			{Order: 2, Description: "Run tests", Command: "go test ./..."},
			{Order: 3, Description: "Push to registry"},
		},
		Tags: "ops",
	}

	node, err := Store(ctx, eng, s, "proj1")
	if err != nil {
		t.Fatalf("Store: %v", err)
	}
	if node == nil {
		t.Fatal("expected non-nil node")
	}
	if node.Type != "skill" {
		t.Errorf("expected type=skill, got %s", node.Type)
	}

	// Verify stored in DB
	got, err := store.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if !strings.Contains(got.Content, "deploy") {
		t.Error("expected skill name in content")
	}
}

func TestLoad_FindsSkillByName(t *testing.T) {
	t.Parallel()
	eng, store := setupEngine(t)
	ctx := context.Background()

	s := &Skill{
		Name:        "test-skill",
		Description: "A test skill",
		Steps: []Step{
			{Order: 1, Description: "Step one"},
		},
	}

	_, err := Store(ctx, eng, s, "proj1")
	if err != nil {
		t.Fatalf("Store: %v", err)
	}

	loaded, err := Load(ctx, store, "test-skill", "proj1")
	if err != nil {
		t.Fatalf("Load: %v", err)
	}
	if loaded.Name != "test-skill" {
		t.Errorf("expected name=test-skill, got %s", loaded.Name)
	}
	if loaded.Description != "A test skill" {
		t.Errorf("unexpected description: %s", loaded.Description)
	}
	if len(loaded.Steps) != 1 {
		t.Errorf("expected 1 step, got %d", len(loaded.Steps))
	}
}

func TestLoad_NotFound(t *testing.T) {
	t.Parallel()
	_, store := setupEngine(t)
	ctx := context.Background()

	_, err := Load(ctx, store, "nonexistent", "proj1")
	if err == nil {
		t.Error("expected error for non-existent skill")
	}
	if !strings.Contains(err.Error(), "not found") {
		t.Errorf("expected 'not found' in error, got: %v", err)
	}
}

func TestListSkills_Empty(t *testing.T) {
	t.Parallel()
	_, store := setupEngine(t)
	ctx := context.Background()

	skills, err := ListSkills(ctx, store, "empty-proj")
	if err != nil {
		t.Fatalf("ListSkills: %v", err)
	}
	if len(skills) != 0 {
		t.Errorf("expected 0 skills, got %d", len(skills))
	}
}

func TestListSkills_MultipleSkills(t *testing.T) {
	t.Parallel()
	eng, store := setupEngine(t)
	ctx := context.Background()

	skills := []*Skill{
		{Name: "build", Description: "Build project", Steps: []Step{{Order: 1, Description: "compile"}}},
		{Name: "deploy", Description: "Deploy project", Steps: []Step{{Order: 1, Description: "push"}}},
		{Name: "test", Description: "Test project", Steps: []Step{{Order: 1, Description: "run tests"}}},
	}

	for _, s := range skills {
		if _, err := Store(ctx, eng, s, "proj1"); err != nil {
			t.Fatalf("Store %s: %v", s.Name, err)
		}
	}

	loaded, err := ListSkills(ctx, store, "proj1")
	if err != nil {
		t.Fatalf("ListSkills: %v", err)
	}
	if len(loaded) != 3 {
		t.Errorf("expected 3 skills, got %d", len(loaded))
	}
}

func TestReplay_FormatsCorrectly(t *testing.T) {
	t.Parallel()
	s := &Skill{
		Name:        "release",
		Description: "Release a new version",
		Steps: []Step{
			{Order: 1, Description: "Update changelog"},
			{Order: 2, Description: "Tag release", Command: "git tag v1.0.0"},
			{Order: 3, Description: "Push tags", Command: "git push --tags"},
		},
	}

	output := Replay(s)
	if !strings.Contains(output, "## Skill: release") {
		t.Error("expected skill header in replay output")
	}
	if !strings.Contains(output, "Release a new version") {
		t.Error("expected description in replay output")
	}
	if !strings.Contains(output, "1. Update changelog") {
		t.Error("expected step 1 in replay output")
	}
	if !strings.Contains(output, "git tag v1.0.0") {
		t.Error("expected command in replay output")
	}
}

func TestReplay_EmptySteps(t *testing.T) {
	t.Parallel()
	s := &Skill{
		Name:        "empty",
		Description: "No steps",
		Steps:       []Step{},
	}
	output := Replay(s)
	if !strings.Contains(output, "## Skill: empty") {
		t.Error("expected header even with no steps")
	}
}

func TestAddTag(t *testing.T) {
	t.Parallel()
	tests := []struct {
		tags, tag, want string
	}{
		{"", "new", "new"},
		{"existing", "new", "existing,new"},
		{"a,b", "c", "a,b,c"},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.tags+"_"+tt.tag, func(t *testing.T) {
			t.Parallel()
			got := addTag(tt.tags, tt.tag)
			if got != tt.want {
				t.Errorf("addTag(%q, %q) = %q, want %q", tt.tags, tt.tag, got, tt.want)
			}
		})
	}
}

func TestSkill_Validate(t *testing.T) {
	t.Parallel()
	invalidName := &Skill{Name: "", Steps: []Step{{Order: 1, Description: "step"}}}
	if err := invalidName.Validate(); err == nil {
		t.Error("expected error for empty skill name")
	}

	invalidSteps := &Skill{Name: "test", Steps: []Step{}}
	if err := invalidSteps.Validate(); err == nil {
		t.Error("expected error for empty steps")
	}

	valid := &Skill{Name: "test", Steps: []Step{{Order: 1, Description: "step"}}}
	if err := valid.Validate(); err != nil {
		t.Errorf("unexpected error for valid skill: %v", err)
	}
}

func TestSkill_SubstituteParams(t *testing.T) {
	t.Parallel()
	s := &Skill{
		Name:        "deploy",
		Description: "Deploy service",
		Params:      map[string]string{"env": "staging", "region": "us-east-1"},
		Steps: []Step{
			{Order: 1, Description: "Deploying to {{env}} in {{region}}", Command: "deploy --env={{env}} --region={{region}}"},
		},
	}

	substituted := s.SubstituteParams(map[string]string{"env": "production"})
	if substituted.Steps[0].Description != "Deploying to production in us-east-1" {
		t.Errorf("unexpected substituted description: %s", substituted.Steps[0].Description)
	}
	if substituted.Steps[0].Command != "deploy --env=production --region=us-east-1" {
		t.Errorf("unexpected substituted command: %s", substituted.Steps[0].Command)
	}
}
