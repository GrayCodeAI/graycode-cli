package engine

import (
	"context"
	"math"
	"sort"

	"github.com/GrayCodeAI/harrier/storage"
)

// PageRank computes importance scores for memory nodes based on graph structure.
// Nodes with more inbound links from important nodes score higher.
// Used to surface the most "central" memories in the graph.
//
// Algorithm: iterative power method with damping factor 0.85.
// Converges in ~20 iterations for typical memory graphs (<10K nodes).
type PageRank struct {
	store   storage.Storage
	damping float64
	maxIter int
	epsilon float64
}

// NewPageRank creates a PageRank computer.
func NewPageRank(store storage.Storage) *PageRank {
	return &PageRank{
		store:   store,
		damping: 0.85,
		maxIter: 30,
		epsilon: 1e-6,
	}
}

// Compute runs PageRank and returns nodes sorted by importance.
func (pr *PageRank) Compute(ctx context.Context, limit int) ([]RankedNode, error) {
	nodes, err := pr.store.ListNodes(ctx, storage.NodeFilter{Limit: 5000})
	if err != nil {
		return nil, err
	}
	if len(nodes) == 0 {
		return nil, nil
	}

	n := len(nodes)
	idToIdx := make(map[string]int, n)
	for i, node := range nodes {
		idToIdx[node.ID] = i
	}

	// Build adjacency: outLinks[i] = list of indices that node i links TO
	outLinks := make([][]int, n)
	inLinks := make([][]int, n)

	// Batch edge retrieval: single query instead of N+1
	nodeIDs := make([]string, len(nodes))
	for i, n := range nodes {
		nodeIDs[i] = n.ID
	}
	allEdges, err := pr.store.GetAllEdgesFor(ctx, nodeIDs)
	if err != nil {
		return nil, err
	}
	edgesByFrom := make(map[string][]*storage.Edge, len(nodes))
	for _, e := range allEdges {
		edgesByFrom[e.FromID] = append(edgesByFrom[e.FromID], e)
	}
	for i, node := range nodes {
		for _, e := range edgesByFrom[node.ID] {
			if j, ok := idToIdx[e.ToID]; ok {
				outLinks[i] = append(outLinks[i], j)
				inLinks[j] = append(inLinks[j], i)
			}
		}
	}

	// Initialize scores uniformly
	scores := make([]float64, n)
	for i := range scores {
		scores[i] = 1.0 / float64(n)
	}

	// Iterate until convergence
	newScores := make([]float64, n)
	for iter := 0; iter < pr.maxIter; iter++ {
		maxDiff := 0.0

		// Dangling-node mass: rank held by nodes with no out-links would
		// otherwise vanish each iteration, so scores wouldn't sum to 1. Collect
		// it and redistribute uniformly across all nodes (standard PageRank).
		dangling := 0.0
		for j := range scores {
			if len(outLinks[j]) == 0 {
				dangling += scores[j]
			}
		}
		danglingShare := pr.damping * dangling / float64(n)

		for i := range newScores {
			// Sum contributions from inbound links
			sum := 0.0
			for _, j := range inLinks[i] {
				outDeg := len(outLinks[j])
				if outDeg > 0 {
					sum += scores[j] / float64(outDeg)
				}
			}
			newScores[i] = (1-pr.damping)/float64(n) + danglingShare + pr.damping*sum

			diff := math.Abs(newScores[i] - scores[i])
			if diff > maxDiff {
				maxDiff = diff
			}
		}

		copy(scores, newScores)
		if maxDiff < pr.epsilon {
			break
		}
	}

	// Build ranked results
	ranked := make([]RankedNode, n)
	for i := range nodes {
		ranked[i] = RankedNode{Node: nodes[i], Score: scores[i]}
	}
	sort.Slice(ranked, func(i, j int) bool {
		return ranked[i].Score > ranked[j].Score
	})

	if limit > 0 && limit < len(ranked) {
		ranked = ranked[:limit]
	}
	return ranked, nil
}

// ShortestPath finds the shortest path between two nodes using BFS.
// Returns the path as a list of node IDs, or nil if no path exists.
//
// BFS proceeds one frontier level at a time and fetches every edge touching the
// whole frontier in a single GetAllEdgesFor call, rather than two queries
// (GetEdgesFrom + GetEdgesTo) per node. That turns O(V) round-trips into
// O(depth), matching the batched pattern already used by IntentBFS/PageRank.
func ShortestPath(ctx context.Context, store storage.Storage, fromID, toID string) ([]string, error) {
	if fromID == toID {
		return []string{fromID}, nil
	}

	const maxVisited = 1000
	visited := map[string]bool{fromID: true}
	parent := map[string]string{} // child -> parent, for path reconstruction
	frontier := []string{fromID}

	for len(frontier) > 0 && len(visited) < maxVisited {
		edges, err := store.GetAllEdgesFor(ctx, frontier)
		if err != nil {
			return nil, err
		}
		inFrontier := make(map[string]bool, len(frontier))
		for _, id := range frontier {
			inFrontier[id] = true
		}

		var next []string
		for _, e := range edges {
			// Undirected traversal: step to whichever endpoint is outside the frontier.
			var from, to string
			switch {
			case inFrontier[e.FromID]:
				from, to = e.FromID, e.ToID
			case inFrontier[e.ToID]:
				from, to = e.ToID, e.FromID
			default:
				continue
			}
			if visited[to] {
				continue
			}
			visited[to] = true
			parent[to] = from
			if to == toID {
				return reconstructPath(parent, fromID, toID), nil
			}
			next = append(next, to)
		}
		frontier = next
	}

	return nil, nil // no path found
}

// reconstructPath walks parent pointers from toID back to fromID and reverses.
func reconstructPath(parent map[string]string, fromID, toID string) []string {
	path := []string{toID}
	for cur := toID; cur != fromID; {
		p := parent[cur]
		path = append(path, p)
		cur = p
	}
	// reverse
	for i, j := 0, len(path)-1; i < j; i, j = i+1, j-1 {
		path[i], path[j] = path[j], path[i]
	}
	return path
}

// GraphDiff shows what memories changed between two points in time.
type GraphDiff struct {
	Added    []*storage.Node
	Modified []*storage.Node
	Removed  []string // IDs of removed/archived nodes
}

// DiffSince returns nodes added or modified since the given node count snapshot.
func DiffSince(ctx context.Context, store storage.Storage, sinceVersion int) (*GraphDiff, error) {
	diff := &GraphDiff{}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: 5000})
	if err != nil {
		return nil, err
	}

	for _, n := range nodes {
		if n.Version > sinceVersion {
			if n.Version == 1 {
				diff.Added = append(diff.Added, n)
			} else {
				diff.Modified = append(diff.Modified, n)
			}
		}
	}

	return diff, nil
}

// SuggestLinks finds orphan nodes and suggests edges to connect them.
func SuggestLinks(ctx context.Context, store storage.Storage) ([]SuggestedEdge, error) {
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: 1000})
	if err != nil {
		return nil, err
	}

	var suggestions []SuggestedEdge
	for _, n := range nodes {
		in, out, _ := store.CountEdges(ctx, n.ID)
		if in+out > 0 {
			continue // not an orphan
		}

		// Find potential connections by searching for related nodes
		related, err := store.SearchNodes(ctx, n.Content, 3)
		if err != nil || len(related) == 0 {
			continue
		}
		for _, r := range related {
			if r.ID == n.ID {
				continue
			}
			suggestions = append(suggestions, SuggestedEdge{
				FromID:   n.ID,
				FromType: n.Type,
				ToID:     r.ID,
				ToType:   r.Type,
				EdgeType: suggestEdgeType(n.Type, r.Type),
				Reason:   "Orphan node shares content with existing node",
			})
			break // one suggestion per orphan
		}
	}

	return suggestions, nil
}

// SuggestedEdge is a recommended edge to create.
type SuggestedEdge struct {
	FromID   string `json:"from_id"`
	FromType string `json:"from_type"`
	ToID     string `json:"to_id"`
	ToType   string `json:"to_type"`
	EdgeType string `json:"edge_type"`
	Reason   string `json:"reason"`
}

func suggestEdgeType(fromType, toType string) string {
	switch {
	case fromType == "decision" && toType == "convention":
		return "led_to"
	case fromType == "bug" && toType == "decision":
		return "caused_by"
	case fromType == "convention" && toType == "spec":
		return "part_of"
	default:
		return "relates_to"
	}
}
