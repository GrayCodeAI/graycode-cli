package engine

import "regexp"

// Entity represents an auto-extracted entity from content.
type Entity struct {
	Name string
	Type string // "file", "entity", "person", "project", "technology"
}

var (
	fileRe   = regexp.MustCompile(`(?:^|[\s"'` + "`" + `(])([a-zA-Z0-9_./-]+\.(?:go|ts|tsx|js|jsx|py|rs|java|rb|sql|yaml|yml|toml|json|md|css|html|sh|c|cpp|h))\b`)
	urlRe    = regexp.MustCompile(`https?://[^\s"'` + "`" + `)<>]+`)
	pkgGoRe  = regexp.MustCompile(`github\.com/[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+`)
	pkgNpmRe = regexp.MustCompile(`@[a-z0-9_.-]+/[a-z0-9_.-]+`)
	funcRe   = regexp.MustCompile(`\b([a-z][a-zA-Z0-9]{2,})\(`)
	classRe  = regexp.MustCompile(`\b([A-Z][a-zA-Z0-9]{2,})\b`)

	// Extended entity patterns for people, projects, and technologies.
	personRe = regexp.MustCompile(`\b([A-Z][a-z]+ [A-Z][a-z]+)\b`)
	techRe   = regexp.MustCompile(`(?i)\b(kubernetes|docker|terraform|postgres|redis|graphql|grpc|nginx|aws|gcp|azure|react|vue|angular|svelte|nextjs|fastapi|django|flask|spring|rails|kafka|elasticsearch|mongodb|cassandra|mysql|sqlite|rabbitmq|prometheus|grafana|datadog|sentry|github|gitlab|bitbucket|circleci|jenkins|argocd|helm|istio|envoy|consul|vault|nomad|pulumi|deno|bun|tailwind|prisma|drizzle|typeorm|sequelize|mocha|jest|pytest|playwright|cypress|selenium|webpack|vite|esbuild|rollup|babel|eslint|prettier|golangci)\b`)
	projRe   = regexp.MustCompile(`(?i)\b(project|initiative|platform|service|system|framework|library|sdk|api|tool|product)\s*[:=]?\s*([A-Za-z][A-Za-z0-9_.-]+)\b`)
)

// ExtractEntities pulls file paths, packages, functions, classes, people,
// technologies, and projects from content.
func ExtractEntities(content string) []Entity {
	seen := map[string]bool{}
	var out []Entity
	add := func(name, typ string) {
		if !seen[name] {
			seen[name] = true
			out = append(out, Entity{Name: name, Type: typ})
		}
	}
	for _, m := range fileRe.FindAllStringSubmatch(content, -1) {
		add(m[1], "file")
	}
	for _, m := range pkgGoRe.FindAllString(content, -1) {
		add(m, "entity")
	}
	for _, m := range pkgNpmRe.FindAllString(content, -1) {
		add(m, "entity")
	}
	for _, m := range urlRe.FindAllString(content, -1) {
		add(m, "entity")
	}
	// Only extract functions/classes if fewer than 10 already found (avoid noise)
	if len(out) < 10 {
		for _, m := range funcRe.FindAllStringSubmatch(content, 5) {
			add(m[1], "entity")
		}
		for _, m := range classRe.FindAllStringSubmatch(content, 5) {
			add(m[1], "entity")
		}
	}

	// Extract technologies (known tool/platform names)
	for _, m := range techRe.FindAllString(content, -1) {
		add(m, "technology")
	}

	// Extract project references
	for _, m := range projRe.FindAllStringSubmatch(content, -1) {
		if len(m) > 2 && len(m[2]) > 2 {
			add(m[2], "project")
		}
	}

	// Extract person names (conservative: only in structured contexts)
	for _, m := range personRe.FindAllStringSubmatch(content, -1) {
		name := m[1]
		// Skip common false positives
		if isCommonNoun(name) {
			continue
		}
		add(name, "person")
	}

	return out
}

// isCommonNoun filters out capitalized word pairs that are not person names.
func isCommonNoun(s string) bool {
	common := map[string]bool{
		"Pull Request": true, "Code Review": true, "Merge Request": true,
		"Pull Requests": true, "Code Reviews": true, "Merge Requests": true,
		"File System": true, "Type Script": true, "Java Script": true,
		"Open Source": true, "Web Socket": true, "Look Ahead": true,
		"Set Up": true, "Get Started": true, "Make Sure": true,
		"Take Away": true, "Best Practice": true, "Best Practices": true,
		"Real Time": true, "High Level": true, "Low Level": true,
		"Side Effect": true, "Side Effects": true, "End Point": true,
		"End Points": true, "Break Point": true, "Break Points": true,
		"Run Time": true, "Build Time": true, "Start Up": true,
		"Shut Down": true, "Roll Back": true, "Roll Out": true,
		"Plug In": true, "Plug Ins": true, "Mark Down": true,
		"Back End": true, "Front End": true, "Back Ground": true,
		"Over View": true, "Work Flow": true, "Work Flows": true,
		"Sign Up": true, "Log In": true, "Sign In": true,
		"Data Base": true, "Data Bases": true, "Key Board": true,
		"Source Code": true, "Test Case": true, "Test Cases": true,
	}
	return common[s]
}
