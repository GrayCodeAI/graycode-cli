package engine

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func setupConsolidationStore(t *testing.T) *storage.Store {
	t.Helper()
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "test.db")
	store, err := storage.NewStore(dbPath)
	if err != nil {
		t.Fatalf("failed to create test store: %v", err)
	}
	return store
}

func TestTopicConsolidator_Consolidate(t *testing.T) {
	t.Parallel()
	store := setupConsolidationStore(t)
	ctx := context.Background()

	// Insert related nodes
	for _, content := range []string{
		"Use PostgreSQL for the database with proper indexing",
		"PostgreSQL schema should use foreign keys for referential integrity",
		"Database migrations use golang-migrate for version control",
		"React components use TypeScript for type safety",
		"React hooks should follow the rules of hooks pattern",
	} {
		_ = store.CreateNode(ctx, &storage.Node{
			ID:         content[:8],
			Type:       "convention",
			Content:    content,
			Summary:    content[:30],
			Scope:      "project",
			Project:    "test",
			Tier:       2,
			Tags:       "",
			Confidence: 1.0,
		})
	}

	tc := NewTopicConsolidator(store, DefaultConsolidationConfig())
	clusters, err := tc.Consolidate(ctx, "test")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if len(clusters) == 0 {
		t.Log("No clusters formed (may be expected with small data set)")
	}

	for _, c := range clusters {
		if c.Size < 2 {
			t.Errorf("cluster size should be >= 2, got %d", c.Size)
		}
		if c.Coherence < 0 || c.Coherence > 1 {
			t.Errorf("coherence out of range: %f", c.Coherence)
		}
	}
}

func TestTopicConsolidator_Disabled(t *testing.T) {
	t.Parallel()
	store := setupConsolidationStore(t)
	cfg := DefaultConsolidationConfig()
	cfg.Enabled = false
	tc := NewTopicConsolidator(store, cfg)

	clusters, err := tc.Consolidate(context.Background(), "test")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if clusters != nil {
		t.Error("expected nil when disabled")
	}
}

func TestKeywordOverlap(t *testing.T) {
	t.Parallel()
	a := map[string]bool{"hello": true, "world": true, "test": true}
	b := map[string]bool{"hello": true, "world": true, "other": true}

	overlap := keywordOverlap(a, b)
	if overlap < 0.5 || overlap > 1.0 {
		t.Errorf("expected overlap ~0.67, got %f", overlap)
	}

	// Empty sets
	overlap = keywordOverlap(map[string]bool{}, a)
	if overlap != 0 {
		t.Errorf("expected 0 for empty set, got %f", overlap)
	}
}

func TestExtractClusterKeywords(t *testing.T) {
	t.Parallel()
	kw := extractClusterKeywords("Use PostgreSQL for the database with proper indexing")
	if len(kw) == 0 {
		t.Error("expected keywords")
	}
	// "the" should be filtered
	if kw["the"] {
		t.Error("'the' should be filtered")
	}
	// "postgresql" should be included
	if !kw["postgresql"] {
		t.Error("'postgresql' should be included")
	}
}

func TestUnionFind(t *testing.T) {
	t.Parallel()
	uf := newUnionFind(5)
	uf.union(0, 1)
	uf.union(2, 3)

	if uf.find(0) != uf.find(1) {
		t.Error("0 and 1 should be in the same group")
	}
	if uf.find(2) != uf.find(3) {
		t.Error("2 and 3 should be in the same group")
	}
	if uf.find(0) == uf.find(2) {
		t.Error("0 and 2 should be in different groups")
	}

	groups := uf.groups()
	if len(groups) != 3 { // {0,1}, {2,3}, {4}
		t.Errorf("expected 3 groups, got %d", len(groups))
	}
}
