package hooks

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/privacy"
	"github.com/GrayCodeAI/harrier/storage"
)

// GitHookType defines the type of git hook triggered.
type GitHookType string

const (
	GitPreCommit  GitHookType = "pre-commit"
	GitPostMerge  GitHookType = "post-merge"
	GitPostCommit GitHookType = "post-commit"
)

// GitHookInput represents git hook payload context.
type GitHookInput struct {
	Type          GitHookType `json:"type"`
	Project       string      `json:"project"`
	CommitMessage string      `json:"commit_message,omitempty"`
	ChangedFiles  []string    `json:"changed_files,omitempty"`
	Branch        string      `json:"branch,omitempty"`
}

// GitHookRunner processes git events and updates Harrier memory.
type GitHookRunner struct {
	eng     *engine.Engine
	project string
}

// NewGitHookRunner creates a git hook runner.
func NewGitHookRunner(eng *engine.Engine, project string) *GitHookRunner {
	return &GitHookRunner{eng: eng, project: project}
}

// Run executes the git hook logic based on the event type.
func (g *GitHookRunner) Run(ctx context.Context, in *GitHookInput) error {
	if in == nil {
		return nil
	}

	switch in.Type {
	case GitPreCommit, GitPostCommit:
		return g.handleCommit(ctx, in)
	case GitPostMerge:
		return g.handleMerge(ctx, in)
	default:
		return nil
	}
}

func (g *GitHookRunner) handleCommit(ctx context.Context, in *GitHookInput) error {
	if in.CommitMessage == "" {
		return nil
	}

	content := privacy.Filter(in.CommitMessage)
	summary := content
	if len(summary) > 80 {
		summary = summary[:80] + "..."
	}

	nodeType := "decision"
	lower := strings.ToLower(content)
	if strings.Contains(lower, "fix") || strings.Contains(lower, "bug") || strings.Contains(lower, "patch") {
		nodeType = "bug"
	} else if strings.Contains(lower, "convention") || strings.Contains(lower, "style") || strings.Contains(lower, "refactor") {
		nodeType = "convention"
	}

	// Ingest commit as memory node
	node, err := g.eng.Remember(ctx, engine.RememberInput{
		Type:    nodeType,
		Content: fmt.Sprintf("Git commit [%s]: %s", in.Branch, content),
		Summary: summary,
		Scope:   "project",
		Project: g.project,
		Tags:    "git,commit",
	})
	if err != nil {
		return err
	}

	// Link file nodes if changed files were provided
	for _, file := range in.ChangedFiles {
		fileNodes, err := g.eng.Store().SearchNodes(ctx, file, 1)
		if err == nil && len(fileNodes) > 0 && node != nil {
			_ = g.eng.Graph().AddEdge(ctx, &storage.Edge{
				FromID: node.ID,
				ToID:   fileNodes[0].ID,
				Type:   "relates_to",
			})
		}
	}

	return nil
}

func (g *GitHookRunner) handleMerge(ctx context.Context, in *GitHookInput) error {
	// Flag memories affected by merged files as stale
	sm, err := engine.NewStalenessManager(g.eng.Store(), g.eng.Graph(), g.project)
	if err != nil {
		return err
	}
	_, err = sm.MarkStale(ctx, time.Now().Add(-24*time.Hour), 0.15)
	return err
}
