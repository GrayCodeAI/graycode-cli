// This file is part of package server. It holds the export/import, skill,
// version-history, confidence, compression, bridge, and advanced-feature
// REST handlers split verbatim out of rest.go for readability; behavior
// is unchanged.

package server

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"path/filepath"
	"strings"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/exportimport"
	"github.com/GrayCodeAI/harrier/internal/bench"
	"github.com/GrayCodeAI/harrier/skill"
	"github.com/GrayCodeAI/harrier/storage"
)

func (s *RESTServer) handleExportJSON(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	data, err := exportimport.ExportJSON(r.Context(), s.eng.Store(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(200)
	_, _ = w.Write(data)
}

func (s *RESTServer) handleExportMarkdown(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	md, err := exportimport.ExportMarkdown(r.Context(), s.eng.Store(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	w.Header().Set("Content-Type", "text/markdown")
	w.WriteHeader(200)
	_, _ = fmt.Fprint(w, md)
}

func (s *RESTServer) handleExportObsidian(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Project  string `json:"project"`
		VaultDir string `json:"vault_dir"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if body.VaultDir == "" {
		httpErr(w, fmt.Errorf("vault_dir is required"), 400)
		return
	}
	// Prevent path traversal — vault_dir must be absolute and not contain ..
	cleanPath := filepath.Clean(body.VaultDir)
	if cleanPath != body.VaultDir || !filepath.IsAbs(cleanPath) {
		httpErr(w, fmt.Errorf("vault_dir must be a clean absolute path"), 400)
		return
	}
	// Restrict to project directory if one is configured
	if s.projectDir != "" {
		projClean := filepath.Clean(s.projectDir)
		if !strings.HasPrefix(cleanPath, projClean+string(filepath.Separator)) && cleanPath != projClean {
			httpErr(w, fmt.Errorf("vault_dir must be within the project directory"), 400)
			return
		}
	}
	n, err := exportimport.ExportObsidian(r.Context(), s.eng.Store(), body.Project, cleanPath)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]int{"written": n}, 200)
}

func (s *RESTServer) handleImportJSON(w http.ResponseWriter, r *http.Request) {
	data, err := io.ReadAll(io.LimitReader(r.Body, maxRequestBodySize))
	if err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, fmt.Errorf("request body exceeds %d bytes", maxRequestBodySize), 413)
			return
		}
		httpErr(w, err, 400)
		return
	}
	nodes, edges, err := exportimport.ImportJSON(r.Context(), s.eng.Store(), data)
	if err != nil {
		httpErr(w, err, 400)
		return
	}
	httpJSON(w, map[string]int{"nodes": nodes, "edges": edges}, 200)
}

func (s *RESTServer) handleSkillStore(w http.ResponseWriter, r *http.Request) {
	var sk skill.Skill
	if err := decodeJSON(r, &sk); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	project := r.URL.Query().Get("project")
	node, err := skill.Store(r.Context(), s.eng, &sk, project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, node, 201)
}

func (s *RESTServer) handleSkillList(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	skills, err := skill.ListSkills(r.Context(), s.eng.Store(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, skills, 200)
}

func (s *RESTServer) handleSkillGet(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	project := r.URL.Query().Get("project")
	sk, err := skill.Load(r.Context(), s.eng.Store(), name, project)
	if err != nil {
		httpErr(w, err, 404)
		return
	}
	httpJSON(w, map[string]string{"replay": skill.Replay(sk)}, 200)
}

func (s *RESTServer) handleBench(w http.ResponseWriter, r *http.Request) {
	result := bench.Run(r.Context(), s.eng, bench.DefaultQAs(), 2, 10)
	httpJSON(w, map[string]string{"report": result.String()}, 200)
}

func (s *RESTServer) handleCompact(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	n, err := s.eng.Compact(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]int{"compacted": n}, 200)
}

func (s *RESTServer) handleMentalModel(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	model, err := s.eng.MentalModel(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"model": model, "formatted": model.Format()}, 200)
}

func (s *RESTServer) handleProfile(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	p, err := s.eng.Profile(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"profile": p, "formatted": p.Format()}, 200)
}

// --- Version history handlers ---

func (s *RESTServer) handleVersions(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	history, err := s.eng.GetNodeHistory(r.Context(), id)
	if err != nil {
		httpErr(w, err, 404)
		return
	}
	httpJSON(w, map[string]any{"node_id": id, "versions": history}, 200)
}

func (s *RESTServer) handleRollback(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	id := r.PathValue("id")
	var body struct {
		Version int `json:"version"`
	}
	if err := decodeJSON(r, &body); err != nil {
		httpErr(w, err, 400)
		return
	}
	if body.Version <= 0 {
		httpErr(w, fmt.Errorf("version must be positive"), 400)
		return
	}
	if err := s.eng.Rollback(r.Context(), id, body.Version); err != nil {
		httpErr(w, err, 400)
		return
	}
	httpJSON(w, map[string]any{"status": "rolled_back", "node_id": id, "version": body.Version}, 200)
}

func (s *RESTServer) handleDiff(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	v1 := intQuery(r, "v1", 0)
	v2 := intQuery(r, "v2", 0)
	if v1 <= 0 || v2 <= 0 {
		httpErr(w, fmt.Errorf("v1 and v2 query params required (positive integers)"), 400)
		return
	}
	c1, c2, err := s.eng.DiffVersions(r.Context(), id, v1, v2)
	if err != nil {
		httpErr(w, err, 400)
		return
	}
	httpJSON(w, map[string]any{
		"node_id": id,
		"v1":      map[string]any{"version": v1, "content": c1},
		"v2":      map[string]any{"version": v2, "content": c2},
	}, 200)
}

// --- Confidence-scored recall handler ---

func (s *RESTServer) handleRecallConfidence(w http.ResponseWriter, r *http.Request) {
	var opts engine.RecallOpts
	if err := decodeJSON(r, &opts); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if opts.Depth > maxGraphDepth {
		httpErr(w, fmt.Errorf("depth exceeds maximum of %d", maxGraphDepth), 400)
		return
	}
	result, err := s.eng.RecallWithConfidence(r.Context(), opts)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, result, 200)
}

// --- Session compression handler ---

func (s *RESTServer) handleSessionCompress(w http.ResponseWriter, r *http.Request) {
	var body struct {
		SessionID string `json:"session_id"`
	}
	if err := decodeJSON(r, &body); err != nil {
		httpErr(w, err, 400)
		return
	}
	if body.SessionID == "" {
		httpErr(w, fmt.Errorf("session_id is required"), 400)
		return
	}
	n, err := s.eng.CompressSessionEvents(r.Context(), body.SessionID)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"compressed": n}, 200)
}

// --- Agent file bridge handlers ---

func (s *RESTServer) handleBridgeImport(w http.ResponseWriter, r *http.Request) {
	if s.projectDir == "" {
		httpErr(w, fmt.Errorf("no project directory configured"), 400)
		return
	}
	bridge := engine.NewAgentFileBridge(s.projectDir)
	rules, err := bridge.Import()
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"rules": rules, "count": len(rules)}, 200)
}

func (s *RESTServer) handleBridgeExport(w http.ResponseWriter, r *http.Request) {
	if s.projectDir == "" {
		httpErr(w, fmt.Errorf("no project directory configured"), 400)
		return
	}
	var body struct {
		Rules    []engine.AgentRule   `json:"rules"`
		FileType engine.AgentFileType `json:"file_type"`
	}
	if err := decodeJSON(r, &body); err != nil {
		httpErr(w, err, 400)
		return
	}
	if body.FileType == "" {
		body.FileType = engine.FileClaudeMD
	}
	bridge := engine.NewAgentFileBridge(s.projectDir)
	if err := bridge.Export(body.Rules, body.FileType); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]string{"status": "exported"}, 200)
}

func (s *RESTServer) handleBridgeSync(w http.ResponseWriter, r *http.Request) {
	if s.projectDir == "" {
		httpErr(w, fmt.Errorf("no project directory configured"), 400)
		return
	}
	var body struct {
		Conventions []string `json:"conventions"`
	}
	if err := decodeJSON(r, &body); err != nil {
		httpErr(w, err, 400)
		return
	}
	bridge := engine.NewAgentFileBridge(s.projectDir)
	if err := bridge.Sync(body.Conventions); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]string{"status": "synced"}, 200)
}

// --- Advanced feature handlers ---

func (s *RESTServer) handleCommunities(w http.ResponseWriter, r *http.Request) {
	cd := engine.NewCommunityDetector(s.eng.Store())
	communities, err := cd.Detect(r.Context(), 10)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	communities = cd.Summarize(r.Context(), communities)
	httpJSON(w, communities, 200)
}

func (s *RESTServer) handleHierarchy(w http.ResponseWriter, r *http.Request) {
	hm := engine.NewHierarchicalMemory(s.eng.Store())
	if err := hm.Build(r.Context()); err != nil {
		httpErr(w, err, 500)
		return
	}

	var req struct {
		Query string `json:"query"`
		Level int    `json:"level"`
	}
	req.Level = -1
	_ = decodeJSON(r, &req)

	if req.Level < 0 && req.Query != "" {
		req.Level = hm.RetrieveAdaptive(req.Query)
	}
	if req.Level < 0 {
		req.Level = 1
	}

	if req.Query != "" {
		clusters := hm.RetrieveAtLevel(req.Query, req.Level)
		httpJSON(w, map[string]interface{}{
			"level": req.Level, "query": req.Query, "clusters": clusters,
		}, 200)
		return
	}

	httpJSON(w, map[string]interface{}{
		"level": req.Level, "content": hm.FormatLevel(req.Level),
	}, 200)
}

func (s *RESTServer) handleSparsify(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	sp := engine.NewSparsifier(s.eng.Store())
	result, err := sp.Run(r.Context())
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]interface{}{
		"merged": result.Merged, "compressed": result.Compressed,
		"pruned": result.Pruned, "total": result.Merged + result.Compressed + result.Pruned,
	}, 200)
}

func (s *RESTServer) handleVerify(w http.ResponseWriter, r *http.Request) {
	harrierDir := filepath.Join(s.projectDir, ".harrier")
	if s.projectDir == "" {
		harrierDir = ".harrier"
	}
	mi, err := engine.NewMemoryIntegrity(harrierDir)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	nodes, err := s.eng.Store().ListNodes(r.Context(), storage.NodeFilter{Limit: 10000})
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	storedSigs, err := s.eng.Store().GetAllSignatures(r.Context())
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	tampered := mi.VerifyBatch(nodes, storedSigs)
	status := "ok"
	if len(tampered) > 0 {
		status = "tampered"
	}
	httpJSON(w, map[string]interface{}{
		"status": status, "nodes_verified": len(nodes), "tampered": len(tampered),
	}, 200)
}

func (s *RESTServer) handleEntities(w http.ResponseWriter, r *http.Request) {
	// Build entity index and return stats
	idx := engine.NewEntityIndex()
	nodes, err := s.eng.Store().ListNodes(r.Context(), storage.NodeFilter{Limit: 5000})
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	for _, n := range nodes {
		idx.IndexNode(n)
	}
	httpJSON(w, map[string]interface{}{
		"unique_entities": idx.Size(),
		"nodes_indexed":   len(nodes),
	}, 200)
}

func (s *RESTServer) handleDoctor(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	store := s.eng.Store()

	// Graph health — use SQL aggregation instead of loading all nodes
	types, _, _ := store.NodeStats(ctx)
	ds, _ := store.DoctorStats(ctx)
	totalNodes := ds.TotalNodes
	orphanCount := ds.Orphans
	lowConfCount := ds.LowConfidence
	pinnedCount := ds.Pinned
	staleCount := 0
	totalEdges, _ := store.CountAllEdges(ctx)
	coverage := 0
	if types["convention"] > 0 {
		coverage += 20
	}
	if types["decision"] > 0 {
		coverage += 20
	}
	if types["spec"] > 0 {
		coverage += 20
	}
	if types["task"] > 0 {
		coverage += 15
	}
	if types["bug"] > 0 {
		coverage += 15
	}
	if types["preference"] > 0 {
		coverage += 10
	}

	// Recommendations
	var recs []string
	if orphanCount > totalNodes/4 {
		recs = append(recs, "High orphan count — run 'harrier sparsify' to clean up disconnected memories")
	}
	if lowConfCount > totalNodes/3 {
		recs = append(recs, "Many low-confidence memories — run 'harrier decay' and 'harrier gc'")
	}
	if types["convention"] == 0 {
		recs = append(recs, "No conventions stored — teach your agent coding rules")
	}
	if types["decision"] == 0 {
		recs = append(recs, "No decisions stored — record architecture choices")
	}
	if types["spec"] == 0 {
		recs = append(recs, "No specs stored — document subsystem designs")
	}
	if pinnedCount == 0 {
		recs = append(recs, "No pinned memories — pin critical conventions with 'harrier pin <id>'")
	}
	if len(recs) == 0 {
		recs = append(recs, "Memory graph looks healthy!")
	}

	httpJSON(w, map[string]interface{}{
		"nodes":           totalNodes,
		"edges":           totalEdges,
		"orphans":         orphanCount,
		"low_confidence":  lowConfCount,
		"pinned":          pinnedCount,
		"stale":           staleCount,
		"coverage_score":  coverage,
		"types":           types,
		"recommendations": recs,
	}, 200)
}
