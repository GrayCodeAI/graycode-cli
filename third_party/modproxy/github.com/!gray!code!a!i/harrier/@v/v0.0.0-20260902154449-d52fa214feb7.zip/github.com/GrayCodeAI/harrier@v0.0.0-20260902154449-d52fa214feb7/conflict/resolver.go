// Package conflict detects and resolves contradictory memories.
// When a new memory contradicts an existing one (same entity/topic, different fact),
// the old memory is auto-superseded. Based on Mem0's conflict resolution approach.
package conflict

import (
	"context"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// ContradictionDetail provides structured information about a detected contradiction.
type ContradictionDetail struct {
	OldNodeID    string   `json:"old_node_id"`
	NewNodeID    string   `json:"new_node_id"`
	OverlapRatio float64  `json:"overlap_ratio"`
	Signals      []string `json:"signals"`
	Confidence   float64  `json:"confidence"`
}

// Resolver detects and resolves memory conflicts.
type Resolver struct {
	store storage.Storage
}

func New(store storage.Storage) *Resolver {
	return &Resolver{store: store}
}

// CheckAndResolve checks if a new node contradicts existing nodes.
// If a contradiction is found, creates a supersedes edge and lowers the old node's confidence.
// Returns the list of superseded node IDs.
func (r *Resolver) CheckAndResolve(ctx context.Context, newNode *storage.Node) ([]string, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	// Find existing nodes of the same type in the same project
	existing, err := r.store.ListNodes(ctx, storage.NodeFilter{
		Type:    newNode.Type,
		Project: newNode.Project,
		Scope:   newNode.Scope,
	})
	if err != nil {
		return nil, err
	}

	var superseded []string
	for _, old := range existing {
		if old.ID == newNode.ID || old.Confidence <= 0 {
			continue
		}
		if isContradiction(newNode, old) {
			// Create supersedes edge. CreateEdge stamps valid_at = now.
			_ = r.store.CreateEdge(ctx, &storage.Edge{
				ID:      uuid.New().String(),
				FromID:  newNode.ID,
				ToID:    old.ID,
				Type:    "supersedes",
				Acyclic: true,
				Weight:  1.0,
			})
			// Close the temporal validity window on the superseded node's
			// outgoing factual edges: they stopped being true the moment the
			// contradiction was recorded. Non-destructive (sets invalid_at = now).
			if oldEdges, err := r.store.GetEdgesFrom(ctx, old.ID); err == nil {
				for _, oe := range oldEdges {
					if oe.Type == "supersedes" {
						continue // don't invalidate supersession links themselves
					}
					_ = r.store.InvalidateEdge(ctx, oe.ID)
				}
			}
			// Lower old node confidence
			old.Confidence *= 0.3
			_ = r.store.UpdateNode(ctx, old)
			// Save version for audit trail
			_ = r.store.SaveVersion(ctx, old.ID, old.Content, "conflict-resolver",
				"superseded by "+newNode.ID[:8])
			superseded = append(superseded, old.ID)
		}
	}
	return superseded, nil
}

// DetectContradictions performs deep contradiction analysis between a new node
// and existing nodes. Unlike CheckAndResolve (which auto-supersedes), this
// method returns structured details about each detected contradiction for
// callers that need richer information (e.g., UI display, audit logging).
func (r *Resolver) DetectContradictions(ctx context.Context, newNode *storage.Node) ([]ContradictionDetail, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	existing, err := r.store.ListNodes(ctx, storage.NodeFilter{
		Project: newNode.Project,
		Scope:   newNode.Scope,
	})
	if err != nil {
		return nil, err
	}

	var details []ContradictionDetail
	for _, old := range existing {
		if old.ID == newNode.ID || old.Confidence <= 0 {
			continue
		}
		detail := analyzeContradiction(newNode, old)
		if detail != nil {
			details = append(details, *detail)
		}
	}
	return details, nil
}

// analyzeContradiction performs multi-signal contradiction analysis.
func analyzeContradiction(newNode, oldNode *storage.Node) *ContradictionDetail {
	newTerms := extractKeyTerms(newNode.Content)
	oldTerms := extractKeyTerms(oldNode.Content)

	shared := 0
	for term := range newTerms {
		if oldTerms[term] {
			shared++
		}
	}

	minSet := len(newTerms)
	if len(oldTerms) < minSet {
		minSet = len(oldTerms)
	}
	if minSet == 0 {
		return nil
	}
	overlapRatio := float64(shared) / float64(minSet)

	// Signal 1: Explicit negation/replacement
	signals := detectContradictionSignals(newNode.Content, oldNode.Content)

	// Signal 2: Same-type high-overlap update
	if overlapRatio >= 0.5 && newNode.Content != oldNode.Content {
		if newNode.Type == "decision" || newNode.Type == "convention" {
			signals = append(signals, "same_type_high_overlap_update")
		}
	}

	// Signal 3: Temporal ordering (newer memory with same subject, different object)
	if newNode.Type == oldNode.Type && overlapRatio >= 0.4 && newNode.Content != oldNode.Content {
		if newNode.CreatedAt.After(oldNode.CreatedAt) {
			signals = append(signals, "temporal_supersession")
		}
	}

	// Signal 4: Explicit value negation (e.g., "X is good" vs "X is bad")
	if hasNegationPattern(newNode.Content, oldNode.Content) {
		signals = append(signals, "value_negation")
	}

	// Require at least one signal and sufficient overlap
	if len(signals) == 0 {
		return nil
	}
	if shared < 3 && overlapRatio < 0.4 {
		return nil
	}

	confidence := overlapRatio * 0.4
	if len(signals) > 0 {
		confidence += 0.3
	}
	if len(signals) > 1 {
		confidence += 0.2
	}
	if confidence > 1.0 {
		confidence = 1.0
	}

	return &ContradictionDetail{
		OldNodeID:    oldNode.ID,
		NewNodeID:    newNode.ID,
		OverlapRatio: overlapRatio,
		Signals:      signals,
		Confidence:   confidence,
	}
}

// detectContradictionSignals returns the specific contradiction signals found.
func detectContradictionSignals(newContent, oldContent string) []string {
	var signals []string
	newLower := strings.ToLower(newContent)
	oldLower := strings.ToLower(oldContent)

	// Explicit replacement/negation patterns
	replacementSignals := []struct {
		pattern string
		name    string
	}{
		{"instead of", "explicit_replacement"},
		{"replaced", "replaced"},
		{"switched from", "switched"},
		{"migrated from", "migrated"},
		{"no longer", "no_longer"},
		{"changed from", "changed"},
		{"deprecated", "deprecated"},
		{"obsolete", "obsolete"},
		{"removed in favor", "removed_in_favor"},
		{"use X instead", "use_instead"},
	}
	for _, s := range replacementSignals {
		if strings.Contains(newLower, s.pattern) {
			signals = append(signals, s.name)
		}
	}

	// Contradictory adjectives (good/bad, fast/slow, etc.)
	contradictoryPairs := []struct {
		a, b string
	}{
		{"good", "bad"},
		{"fast", "slow"},
		{"safe", "unsafe"},
		{"correct", "incorrect"},
		{"valid", "invalid"},
		{"working", "broken"},
		{"stable", "unstable"},
		{"secure", "insecure"},
		{"optimal", "suboptimal"},
	}
	for _, pair := range contradictoryPairs {
		if (strings.Contains(newLower, pair.a) && strings.Contains(oldLower, pair.b)) ||
			(strings.Contains(newLower, pair.b) && strings.Contains(oldLower, pair.a)) {
			signals = append(signals, "contradictory_adjectives")
			break
		}
	}

	return signals
}

// hasNegationPattern checks if two texts contain opposing value statements
// about the same subject.
func hasNegationPattern(newContent, oldContent string) bool {
	newLower := strings.ToLower(newContent)
	oldLower := strings.ToLower(oldContent)

	// "prefer X" vs "don't prefer X" or "avoid X"
	contradictoryVerbs := []struct {
		affirm, neg string
	}{
		{"prefer", "avoid"},
		{"use", "don't use"},
		{"enable", "disable"},
		{"allow", "disallow"},
		{"require", "forbid"},
		{"accept", "reject"},
		{"include", "exclude"},
		{"keep", "remove"},
		{"add", "remove"},
	}
	for _, v := range contradictoryVerbs {
		if (strings.Contains(newLower, v.affirm) && strings.Contains(oldLower, v.neg)) ||
			(strings.Contains(newLower, v.neg) && strings.Contains(oldLower, v.affirm)) {
			return true
		}
	}
	return false
}

// isContradiction detects if two nodes about the same topic say different things.
// Conservative: requires high term overlap AND explicit contradiction signals.
func isContradiction(newNode, oldNode *storage.Node) bool {
	newEntities := extractKeyTerms(newNode.Content)
	oldEntities := extractKeyTerms(oldNode.Content)

	// Must share significant key terms (prevents false positives on loosely related content)
	shared := 0
	for term := range newEntities {
		if oldEntities[term] {
			shared++
		}
	}

	// Require at least 3 shared terms, or >40% overlap with the smaller set
	minSet := len(newEntities)
	if len(oldEntities) < minSet {
		minSet = len(oldEntities)
	}
	if minSet == 0 {
		return false
	}
	overlapRatio := float64(shared) / float64(minSet)
	if shared < 3 && overlapRatio < 0.4 {
		return false
	}

	// Check for explicit negation/replacement patterns
	newLower := strings.ToLower(newNode.Content)
	hasContradictionSignal := strings.Contains(newLower, "instead of") ||
		strings.Contains(newLower, "replaced") ||
		strings.Contains(newLower, "switched from") ||
		strings.Contains(newLower, "migrated from") ||
		strings.Contains(newLower, "no longer")

	if hasContradictionSignal {
		return true
	}

	// Same decision/convention topic (high overlap) with different content = updated
	if overlapRatio >= 0.5 && newNode.Content != oldNode.Content {
		if newNode.Type == "decision" || newNode.Type == "convention" {
			return true
		}
	}

	// Enhanced: check for contradictory adjectives and verb patterns
	signals := detectContradictionSignals(newNode.Content, oldNode.Content)
	if len(signals) > 0 && overlapRatio >= 0.3 {
		return true
	}

	return false
}

func extractKeyTerms(content string) map[string]bool {
	terms := map[string]bool{}
	words := strings.Fields(strings.ToLower(content))
	for _, w := range words {
		w = strings.Trim(w, ".,;:!?\"'()[]{}")
		if len(w) > 3 && !isStopWord(w) {
			terms[w] = true
		}
	}
	return terms
}

var stopWords = map[string]bool{
	"the": true, "and": true, "for": true, "are": true, "but": true,
	"not": true, "you": true, "all": true, "can": true, "had": true,
	"was": true, "one": true, "our": true, "use": true, "with": true,
	"this": true, "that": true, "from": true, "they": true, "will": true,
	"have": true, "been": true, "should": true, "would": true, "could": true,
	"also": true, "than": true, "then": true, "into": true, "over": true,
}

func isStopWord(w string) bool { return stopWords[w] }
