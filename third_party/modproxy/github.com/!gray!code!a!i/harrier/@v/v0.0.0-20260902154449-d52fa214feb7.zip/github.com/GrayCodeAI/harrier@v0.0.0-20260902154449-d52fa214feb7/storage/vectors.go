package storage

import (
	"context"
	"encoding/binary"
	"math"
	"time"
)

// EncodeVector encodes a float32 slice to a byte slice for SQLite BLOB storage.
func EncodeVector(v []float32) []byte {
	b := make([]byte, len(v)*4)
	for i, f := range v {
		binary.LittleEndian.PutUint32(b[i*4:], math.Float32bits(f))
	}
	return b
}

// DecodeVector decodes a byte slice from SQLite BLOB to a float32 slice.
func DecodeVector(b []byte) []float32 {
	if len(b)%4 != 0 {
		return nil
	}
	v := make([]float32, len(b)/4)
	for i := range v {
		v[i] = math.Float32frombits(binary.LittleEndian.Uint32(b[i*4:]))
	}
	return v
}

// SaveEmbedding stores a vector embedding for a node and keeps the HNSW
// index up to date incrementally: if an index for the embedding's model is
// built, only the affected node and its neighbors are re-linked and
// persisted (no full rebuild). A failed index update does not fail the save
// — the embeddings table is the source of truth and a later
// BuildHNSWIndex/SearchHNSW will reconcile the index.
//
// Like every other write path it retries on SQLITE_BUSY: embedding writes run
// outside the engine's write lock and can briefly contend with the async
// ingestion goroutine for the single SQLite writer.
func (s *Store) SaveEmbedding(ctx context.Context, nodeID, model string, vector []float32) error {
	err := retryOnBusy(func() error {
		qctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return saveEmbeddingQ(qctx, s.q(), nodeID, model, vector)
	}, 5, 50*time.Millisecond)
	if err != nil {
		return err
	}
	s.hnswMu.Lock()
	idx := s.hnswIndexes[model]
	s.hnswMu.Unlock()
	if idx != nil {
		_ = idx.Upsert(ctx, s, model, nodeID, vector) // best-effort; next Build reconciles
	}
	return nil
}

func saveEmbeddingQ(ctx context.Context, q queryable, nodeID, model string, vector []float32) error {
	_, err := q.ExecContext(ctx,
		`INSERT INTO embeddings(node_id, vector, model) VALUES(?,?,?)
		 ON CONFLICT(node_id) DO UPDATE SET vector=excluded.vector, model=excluded.model`,
		nodeID, EncodeVector(vector), model)
	return err
}

// GetEmbedding retrieves the embedding for a node.
func (s *Store) GetEmbedding(ctx context.Context, nodeID string) ([]float32, string, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return getEmbeddingQ(ctx, s.q(), nodeID)
}

func getEmbeddingQ(ctx context.Context, q queryable, nodeID string) ([]float32, string, error) {
	var blob []byte
	var model string
	err := q.QueryRowContext(ctx, `SELECT vector, model FROM embeddings WHERE node_id=?`, nodeID).Scan(&blob, &model)
	if err != nil {
		return nil, "", err
	}
	return DecodeVector(blob), model, nil
}

// DeleteEmbedding removes a vector embedding for a node and detaches the
// node from the built HNSW index for its model (link pruning + entry-point
// repair). If no index is built, any stale persisted graph row is still
// cleared so the DB stays consistent. The index is best-effort: a failed
// detach is reconciled by the next BuildHNSWIndex/SearchHNSW.
func (s *Store) DeleteEmbedding(ctx context.Context, nodeID string) error {
	model, _ := s.embeddingModel(ctx, nodeID) // empty when no embedding is stored

	// embeddings_hnsw.node_id references embeddings.node_id (no cascade in
	// the base schema), so the graph row must be removed before the
	// embedding row itself.
	if model != "" {
		s.hnswMu.Lock()
		idx := s.hnswIndexes[model]
		s.hnswMu.Unlock()
		if idx != nil {
			_ = idx.Remove(ctx, s, model, nodeID) // best-effort; next Build reconciles
		} else {
			qctx, cancel := s.withTimeout(ctx)
			_, _ = s.q().ExecContext(qctx, `DELETE FROM embeddings_hnsw WHERE node_id=?`, nodeID)
			cancel()
		}
	}

	return retryOnBusy(func() error {
		qctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return deleteEmbeddingQ(qctx, s.q(), nodeID)
	}, 5, 50*time.Millisecond)
}

// embeddingModel returns the model that produced a node's embedding, or an
// error (sql.ErrNoRows when none is stored).
func (s *Store) embeddingModel(ctx context.Context, nodeID string) (string, error) {
	qctx, cancel := s.withTimeout(ctx)
	defer cancel()
	var model string
	err := s.q().QueryRowContext(qctx, `SELECT model FROM embeddings WHERE node_id=?`, nodeID).Scan(&model)
	if err != nil {
		return "", err
	}
	return model, nil
}

func deleteEmbeddingQ(ctx context.Context, q queryable, nodeID string) error {
	_, err := q.ExecContext(ctx, `DELETE FROM embeddings WHERE node_id=?`, nodeID)
	return err
}

// GetEmbeddingsBatch returns a paginated batch of embeddings. When model is
// non-empty, only embeddings produced by that model are returned — vectors from a
// different model live in an incompatible vector space and must never be mixed
// into a single cosine/ANN comparison. Pass "" to retrieve all models (e.g. for
// maintenance or migration).
func (s *Store) GetEmbeddingsBatch(ctx context.Context, model string, offset, limit int) (map[string][]float32, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return getEmbeddingsBatchQ(ctx, s.q(), model, offset, limit)
}

func getEmbeddingsBatchQ(ctx context.Context, q queryable, model string, offset, limit int) (map[string][]float32, error) {
	query := `SELECT node_id, vector FROM embeddings LIMIT ? OFFSET ?`
	args := []any{limit, offset}
	if model != "" {
		query = `SELECT node_id, vector FROM embeddings WHERE model = ? LIMIT ? OFFSET ?`
		args = []any{model, limit, offset}
	}
	rows, err := q.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	result := map[string][]float32{}
	for rows.Next() {
		var nodeID string
		var blob []byte
		if err := rows.Scan(&nodeID, &blob); err != nil {
			return nil, err
		}
		result[nodeID] = DecodeVector(blob)
	}
	return result, rows.Err()
}

// AllEmbeddings returns all stored embeddings as (nodeID, vector) pairs. When
// model is non-empty, only that model's embeddings are returned; pass "" to
// retrieve every model. See GetEmbeddingsBatch for why mixing models is unsafe.
func (s *Store) AllEmbeddings(ctx context.Context, model string) (map[string][]float32, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return allEmbeddingsQ(ctx, s.q(), model)
}

func allEmbeddingsQ(ctx context.Context, q queryable, model string) (map[string][]float32, error) {
	query := `SELECT node_id, vector FROM embeddings`
	var args []any
	if model != "" {
		query = `SELECT node_id, vector FROM embeddings WHERE model = ?`
		args = []any{model}
	}
	rows, err := q.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	result := map[string][]float32{}
	for rows.Next() {
		var nodeID string
		var blob []byte
		if err := rows.Scan(&nodeID, &blob); err != nil {
			return nil, err
		}
		result[nodeID] = DecodeVector(blob)
	}
	return result, rows.Err()
}

// BuildHNSWIndex rebuilds the HNSW index for the given embedding model
// from the embeddings table, ignoring any persisted graph. Use it to force a
// fresh index after out-of-band embedding changes; the search path restores
// persisted graphs automatically and only falls back to a build when the
// stored graph is missing or stale.
func (s *Store) BuildHNSWIndex(ctx context.Context, model string) error {
	idx := NewHNSWIndex(200, 16, 50) // efConstruction=200, m=16, efSearch=50
	if err := idx.Build(ctx, s, model); err != nil {
		return err
	}
	s.hnswMu.Lock()
	s.hnswIndexes[model] = idx
	s.hnswMu.Unlock()
	return nil
}

// acquireHNSWIndex loads the index for a model on first use: it restores the
// graph persisted in embeddings_hnsw (covering process restarts) and falls
// back to a full Build when nothing usable is stored.
func (s *Store) acquireHNSWIndex(ctx context.Context, model string) error {
	idx := NewHNSWIndex(200, 16, 50)
	restored, err := idx.Restore(ctx, s, model)
	if err != nil {
		return err
	}
	if !restored {
		if err := idx.Build(ctx, s, model); err != nil {
			return err
		}
	}
	s.hnswMu.Lock()
	s.hnswIndexes[model] = idx
	s.hnswMu.Unlock()
	return nil
}

// invalidateHNSWIndex drops the built index for a model so that the next
// SearchHNSW rebuilds it from the embeddings table. Used after transactional
// embedding writes, which bypass the incremental Upsert/Remove path.
func (s *Store) invalidateHNSWIndex(model string) {
	s.hnswMu.Lock()
	delete(s.hnswIndexes, model)
	s.hnswMu.Unlock()
}

// SearchHNSW searches the HNSW index for the given model, loading it on
// first use: a persisted graph is restored from embeddings_hnsw (so a
// restart does not recompute the index), with a full Build fallback when no
// usable graph is stored.
func (s *Store) SearchHNSW(ctx context.Context, model string, query []float32, k, ef int) ([]string, []float32, error) {
	s.hnswMu.Lock()
	idx := s.hnswIndexes[model]
	s.hnswMu.Unlock()
	if idx == nil {
		if err := s.acquireHNSWIndex(ctx, model); err != nil {
			return nil, nil, err
		}
		s.hnswMu.Lock()
		idx = s.hnswIndexes[model]
		s.hnswMu.Unlock()
	}
	ids, scores := idx.Search(query, k, ef)
	return ids, scores, nil
}
