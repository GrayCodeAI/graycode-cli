package git

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

func setupTestRepo(t *testing.T) (string, storage.Storage, graph.Graph) {
	t.Helper()
	dir := t.TempDir()

	runGit := func(args ...string) {
		t.Helper()
		cmd := exec.Command("git", args...)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("git %v: %s: %v", args, out, err)
		}
	}

	cmd := exec.Command("git", "init", dir)
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("git init: %s: %v", out, err)
	}

	runGit("-C", dir, "config", "user.email", "test@test.com")
	runGit("-C", dir, "config", "user.name", "Test")
	runGit("-C", dir, "config", "commit.gpgsign", "false")

	if err := os.WriteFile(filepath.Join(dir, "main.go"), []byte("package main\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	runGit("-C", dir, "add", ".")
	runGit("-C", dir, "commit", "-m", "init")

	dbDir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dbDir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })

	g := graph.New(store, store.DB())
	return dir, store, g
}

func TestNew_ValidDirectory(t *testing.T) {
	t.Parallel()
	dir, store, g := setupTestRepo(t)

	w, err := New(store, g, dir)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if w == nil {
		t.Error("expected non-nil watcher")
	}
}

func TestNew_NonExistentDirectory(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	store, _ := storage.NewStore(filepath.Join(dir, "test.db"))
	defer func() { store.Close() }()
	g := graph.New(store, store.DB())

	_, err := New(store, g, "/nonexistent/path/xyz123")
	if err == nil {
		t.Error("expected error for non-existent directory")
	}
}

func TestNew_FileNotDirectory(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	filePath := filepath.Join(dir, "file.txt")
	_ = os.WriteFile(filePath, []byte("hello"), 0o644)

	store, _ := storage.NewStore(filepath.Join(dir, "test.db"))
	defer func() { store.Close() }()
	g := graph.New(store, store.DB())

	_, err := New(store, g, filePath)
	if err == nil {
		t.Error("expected error for file (not directory)")
	}
}

func TestCurrentHash_ValidRepo(t *testing.T) {
	t.Parallel()
	dir, _, _ := setupTestRepo(t)

	hash := CurrentHash(dir)
	if hash == "" {
		t.Error("expected non-empty hash for valid git repo")
	}
	if len(hash) != 40 {
		t.Errorf("expected 40-char git hash, got %d chars: %s", len(hash), hash)
	}
}

func TestCurrentHash_NonGitDir(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	hash := CurrentHash(dir)
	if hash != "" {
		t.Errorf("expected empty hash for non-git dir, got %s", hash)
	}
}

func TestWatchFile(t *testing.T) {
	t.Parallel()
	dir, store, g := setupTestRepo(t)

	w, err := New(store, g, dir)
	if err != nil {
		t.Fatal(err)
	}

	ctx := context.Background()
	nodeID := uuid.New().String()
	// Create a node first — the file_watch table has a FOREIGN KEY constraint
	// on node_id that was never enforced before (the DSN format silently
	// ignored _foreign_keys=on). Now that _pragma=foreign_keys(ON) works,
	// the constraint actually fires.
	if err := store.CreateNode(ctx, &storage.Node{
		ID: nodeID, Type: "file", Content: "main.go",
		ContentHash: "h" + nodeID, Scope: "project", Project: "test",
	}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}
	err = w.WatchFile(ctx, "main.go", nodeID, "abc123")
	if err != nil {
		t.Fatalf("WatchFile: %v", err)
	}
}

func TestStalesSince_NoChanges(t *testing.T) {
	t.Parallel()
	dir, store, g := setupTestRepo(t)

	w, err := New(store, g, dir)
	if err != nil {
		t.Fatal(err)
	}

	ctx := context.Background()
	// Use a time in the future so no commits qualify
	reports, err := w.StalesSince(ctx, time.Now().Add(time.Hour))
	if err != nil {
		t.Fatalf("StalesSince: %v", err)
	}
	if len(reports) != 0 {
		t.Errorf("expected 0 stale reports for future time, got %d", len(reports))
	}
}

func TestStalesSince_WithRecentChange(t *testing.T) {
	t.Parallel()
	dir, store, g := setupTestRepo(t)

	ctx := context.Background()

	// Add a node related to main.go
	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        "file",
		Content:     "main.go",
		ContentHash: "fhash1",
		Scope:       "project",
		Project:     "proj1",
		Version:     1,
	}
	store.CreateNode(ctx, node)
	_ = g.AddNode(ctx, node)

	w, err := New(store, g, dir)
	if err != nil {
		t.Fatal(err)
	}

	// Check stale since before the initial commit
	since := time.Now().Add(-time.Hour)
	reports, err := w.StalesSince(ctx, since)
	if err != nil {
		t.Fatalf("StalesSince: %v", err)
	}
	// Reports depend on graph.Impact matching file names to nodes
	// The test verifies the function runs without error
	_ = reports
}
