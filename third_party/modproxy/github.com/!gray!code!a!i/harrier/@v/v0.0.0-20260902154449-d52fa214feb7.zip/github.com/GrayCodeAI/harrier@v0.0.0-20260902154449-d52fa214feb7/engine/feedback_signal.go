package engine

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// FeedbackSignal tracks which memories were useful vs irrelevant.
// Enables: demote nodes explicitly marked irrelevant, boost nodes that led
// to successful outcomes. Learns over time which memories matter.
type FeedbackSignal struct {
	store    storage.Storage
	positive map[string]int // nodeID → positive feedback count
	negative map[string]int // nodeID → negative feedback count
	mu       sync.RWMutex
}

// NewFeedbackSignal creates a feedback tracker.
func NewFeedbackSignal(store storage.Storage) *FeedbackSignal {
	return &FeedbackSignal{
		store:    store,
		positive: make(map[string]int),
		negative: make(map[string]int),
	}
}

// MarkRelevant indicates a memory was useful in context.
func (fs *FeedbackSignal) MarkRelevant(nodeID string) {
	fs.mu.Lock()
	defer fs.mu.Unlock()
	fs.positive[nodeID]++
}

// MarkIrrelevant indicates a memory was not useful (noise).
func (fs *FeedbackSignal) MarkIrrelevant(nodeID string) {
	fs.mu.Lock()
	defer fs.mu.Unlock()
	fs.negative[nodeID]++
}

// BoostMultiplier returns a score multiplier based on feedback history.
// Positive feedback → boost (up to 1.5x), negative → penalty (down to 0.5x).
func (fs *FeedbackSignal) BoostMultiplier(nodeID string) float64 {
	fs.mu.RLock()
	defer fs.mu.RUnlock()

	pos := fs.positive[nodeID]
	neg := fs.negative[nodeID]

	if pos == 0 && neg == 0 {
		return 1.0 // no signal
	}

	// Net sentiment: positive - negative
	net := pos - neg
	switch {
	case net >= 3:
		return 1.5
	case net >= 1:
		return 1.2
	case net <= -3:
		return 0.5
	case net <= -1:
		return 0.7
	default:
		return 1.0
	}
}

// ApplyToNodes adjusts confidence based on accumulated feedback.
func (fs *FeedbackSignal) ApplyToNodes(ctx context.Context) int {
	// Snapshot negative entries under read lock, then release before store writes.
	fs.mu.RLock()
	negative := make(map[string]int, len(fs.negative))
	for id, neg := range fs.negative {
		negative[id] = neg
	}
	fs.mu.RUnlock()

	applied := 0
	for id, neg := range negative {
		if neg < 3 {
			continue // only apply strong signals
		}
		node, err := fs.store.GetNode(ctx, id)
		if err != nil || node == nil || node.Pinned {
			continue
		}
		// Reduce confidence for consistently irrelevant memories
		newConf := node.Confidence - 0.1*float64(neg)
		if newConf < 0.1 {
			newConf = 0.1
		}
		if newConf != node.Confidence {
			node.Confidence = newConf
			_ = fs.store.UpdateNode(ctx, node)
			applied++
		}
	}
	return applied
}

// ContextualScoring boosts memories that match the current session's topic.
// Detects the session topic from recent queries and boosts related content.
type ContextualScoring struct {
	mu           sync.RWMutex
	recentTopics []string
	maxTopics    int
}

// NewContextualScoring creates a contextual scorer.
func NewContextualScoring() *ContextualScoring {
	return &ContextualScoring{
		recentTopics: make([]string, 0, 10),
		maxTopics:    10,
	}
}

// RecordQuery adds a query to the topic window.
func (cs *ContextualScoring) RecordQuery(query string) {
	cs.mu.Lock()
	defer cs.mu.Unlock()
	cs.recentTopics = append(cs.recentTopics, query)
	if len(cs.recentTopics) > cs.maxTopics {
		cs.recentTopics = cs.recentTopics[1:]
	}
}

// TopicBoost returns a multiplier for nodes that relate to recent session topics.
func (cs *ContextualScoring) TopicBoost(node *storage.Node) float64 {
	cs.mu.RLock()
	defer cs.mu.RUnlock()

	if len(cs.recentTopics) == 0 {
		return 1.0
	}

	// Check if node content overlaps with recent topics
	contentLower := strings.ToLower(node.Content)
	matches := 0
	for _, topic := range cs.recentTopics {
		topicTerms := strings.Fields(strings.ToLower(topic))
		for _, term := range topicTerms {
			if len(term) >= 4 && strings.Contains(contentLower, term) {
				matches++
				break
			}
		}
	}

	if matches == 0 {
		return 1.0
	}
	// Up to 1.4x boost for highly contextual memories
	boost := 1.0 + float64(matches)*0.1
	if boost > 1.4 {
		boost = 1.4
	}
	return boost
}

// Reset clears topic history (call at session start).
func (cs *ContextualScoring) Reset() {
	cs.mu.Lock()
	defer cs.mu.Unlock()
	cs.recentTopics = cs.recentTopics[:0]
}

// LastActivity returns when the last query was recorded.
func (cs *ContextualScoring) LastActivity() time.Time {
	return time.Now() // simplified
}
