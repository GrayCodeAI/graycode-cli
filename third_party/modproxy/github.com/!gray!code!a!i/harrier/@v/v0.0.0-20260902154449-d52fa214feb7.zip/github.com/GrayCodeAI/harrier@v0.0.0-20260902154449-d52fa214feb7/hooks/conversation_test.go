package hooks

import (
	"testing"
)

func TestExtractMemory_Decision(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "user",
		Content: "We decided to use PostgreSQL instead of MySQL for the main database because of better JSON support",
	}
	nodeType, content := cc.extractMemory(msg)
	if nodeType != "decision" {
		t.Errorf("expected 'decision', got %q", nodeType)
	}
	if content == "" {
		t.Error("expected non-empty content")
	}
}

func TestExtractMemory_Convention(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "assistant",
		Content: "Always use context.Context as the first parameter in Go functions - this is our convention",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "convention" {
		t.Errorf("expected 'convention', got %q", nodeType)
	}
}

func TestExtractMemory_Bug(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "assistant",
		Content: "Bug: the login endpoint returns 500 when the email field is empty, this is a regression from the last deploy",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "bug" {
		t.Errorf("expected 'bug', got %q", nodeType)
	}
}

func TestExtractMemory_Task(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "user",
		Content: "Todo: need to implement the OAuth2 flow for the API, this is the next step after the auth refactor",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "task" {
		t.Errorf("expected 'task', got %q", nodeType)
	}
}

func TestExtractMemory_Preference(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "user",
		Content: "I prefer using table-driven tests in Go instead of subtests for simple cases",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "preference" {
		t.Errorf("expected 'preference', got %q", nodeType)
	}
}

func TestExtractMemory_Spec(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "user",
		Content: "Requirement: the API should support pagination with cursor-based navigation",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "spec" {
		t.Errorf("expected 'spec', got %q", nodeType)
	}
}

func TestExtractMemory_ShortMessage(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "user",
		Content: "ok",
	}
	nodeType, content := cc.extractMemory(msg)
	if nodeType != "" || content != "" {
		t.Error("expected empty result for short message")
	}
}

func TestExtractMemory_SystemMessage(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "system",
		Content: "We decided to use PostgreSQL for the database with proper indexing and foreign keys",
	}
	nodeType, _ := cc.extractMemory(msg)
	// System messages are filtered at the caller level, not in extractMemory
	// but the function should still work
	_ = nodeType
}

func TestExtractMemory_NoSignal(t *testing.T) {
	t.Parallel()
	cc := &ConversationCapture{}
	msg := ConversationMessage{
		Role:    "assistant",
		Content: "The weather is nice today and I had a great lunch at the new restaurant downtown",
	}
	nodeType, _ := cc.extractMemory(msg)
	if nodeType != "" {
		t.Errorf("expected empty type for non-technical content, got %q", nodeType)
	}
}

func TestContainsAny(t *testing.T) {
	t.Parallel()
	if !containsAny("hello world", "hello", "foo") {
		t.Error("expected true for matching keyword")
	}
	if containsAny("hello world", "foo", "bar") {
		t.Error("expected false for no matching keyword")
	}
}

func TestConversationCaptureSummary_FormatSummary(t *testing.T) {
	t.Parallel()
	s := ConversationCaptureSummary{
		TotalMessages:  10,
		MemoriesStored: 3,
		ByType:         map[string]int{"decision": 2, "convention": 1},
	}
	out := s.FormatSummary()
	if out == "" {
		t.Error("expected non-empty summary")
	}
}

func TestConversationCaptureSummary_NoMemories(t *testing.T) {
	t.Parallel()
	s := ConversationCaptureSummary{
		TotalMessages: 5,
		ByType:        map[string]int{},
	}
	out := s.FormatSummary()
	if out == "" {
		t.Error("expected non-empty summary")
	}
}
