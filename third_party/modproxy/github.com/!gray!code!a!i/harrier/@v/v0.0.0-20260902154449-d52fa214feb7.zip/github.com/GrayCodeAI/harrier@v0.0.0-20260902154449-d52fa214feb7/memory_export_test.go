package harrier

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"
	"time"
)

func TestNewMemoryExport(t *testing.T) {
	t.Parallel()
	t.Run("creates export with version and timestamp", func(t *testing.T) {
		now := time.Now().UTC()
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: now,
			Entries:    []MemoryEntry{},
			Stats:      make(TierStatsMap),
		}

		if me.Version != "1.0" {
			t.Errorf("expected version 1.0, got %s", me.Version)
		}
		if !me.ExportedAt.Equal(now) {
			t.Errorf("expected ExportedAt %v, got %v", now, me.ExportedAt)
		}
	})
}

func TestMemoryExportWriteTo(t *testing.T) {
	t.Parallel()
	t.Run("writes valid JSON", func(t *testing.T) {
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{
					ID:           "m1",
					Content:      "Test memory",
					Tier:         TierHot,
					AccessCount:  5,
					LastAccessed: time.Now().UTC(),
					CreatedAt:    time.Now().UTC(),
					TokenCount:   10,
				},
			},
			Stats: TierStatsMap{
				TierHot: {Count: 1, Tokens: 10},
			},
		}

		var buf bytes.Buffer
		n, err := me.WriteTo(&buf)
		if err != nil {
			t.Fatalf("WriteTo failed: %v", err)
		}

		if n == 0 {
			t.Error("expected non-zero bytes written")
		}

		// Verify it's valid JSON
		var parsed map[string]interface{}
		if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
			t.Fatalf("Output is not valid JSON: %v", err)
		}

		if parsed["version"] != "1.0" {
			t.Errorf("expected version 1.0, got %v", parsed["version"])
		}
	})

	t.Run("writes empty entries list", func(t *testing.T) {
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries:    []MemoryEntry{},
			Stats:      make(TierStatsMap),
		}

		var buf bytes.Buffer
		_, err := me.WriteTo(&buf)
		if err != nil {
			t.Fatalf("WriteTo failed: %v", err)
		}

		output := buf.String()
		if !strings.Contains(output, "\"entries\": []") {
			t.Error("expected empty entries array in output")
		}
	})

	t.Run("writes multiple tiers", func(t *testing.T) {
		now := time.Now().UTC()
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: now,
			Entries: []MemoryEntry{
				{ID: "h1", Content: "Hot", Tier: TierHot, LastAccessed: now, CreatedAt: now, TokenCount: 10},
				{ID: "w1", Content: "Warm", Tier: TierWarm, LastAccessed: now, CreatedAt: now, TokenCount: 20},
				{ID: "c1", Content: "Cold", Tier: TierCold, LastAccessed: now, CreatedAt: now, TokenCount: 30},
			},
			Stats: TierStatsMap{
				TierHot:  {Count: 1, Tokens: 10},
				TierWarm: {Count: 1, Tokens: 20},
				TierCold: {Count: 1, Tokens: 30},
			},
		}

		var buf bytes.Buffer
		_, err := me.WriteTo(&buf)
		if err != nil {
			t.Fatalf("WriteTo failed: %v", err)
		}

		// Parse and verify
		var parsed map[string]interface{}
		if err := json.Unmarshal(buf.Bytes(), &parsed); err != nil {
			t.Fatalf("Output is not valid JSON: %v", err)
		}

		entries, ok := parsed["entries"].([]interface{})
		if !ok {
			t.Fatal("expected entries array")
		}
		if len(entries) != 3 {
			t.Errorf("expected 3 entries, got %d", len(entries))
		}
	})
}

func TestReadMemoryExport(t *testing.T) {
	t.Parallel()
	t.Run("reads valid JSON", func(t *testing.T) {
		jsonData := `{
			"version": "1.0",
			"exported_at": "2026-01-15T10:30:00Z",
			"entries": [
				{
					"id": "m1",
					"content": "Test memory",
					"tier": 0,
					"access_count": 5,
					"last_accessed": "2026-01-15T10:30:00Z",
					"created_at": "2026-01-15T10:00:00Z",
					"token_count": 10
				}
			],
			"stats": {
				"0": {"count": 1, "tokens": 10}
			}
		}`

		reader := strings.NewReader(jsonData)
		me, err := ReadMemoryExport(reader)
		if err != nil {
			t.Fatalf("ReadMemoryExport failed: %v", err)
		}

		if me.Version != "1.0" {
			t.Errorf("expected version 1.0, got %s", me.Version)
		}
		if len(me.Entries) != 1 {
			t.Errorf("expected 1 entry, got %d", len(me.Entries))
		}
		if me.Entries[0].ID != "m1" {
			t.Errorf("expected entry ID m1, got %s", me.Entries[0].ID)
		}
	})

	t.Run("reads empty entries list", func(t *testing.T) {
		jsonData := `{
			"version": "1.0",
			"exported_at": "2026-01-15T10:30:00Z",
			"entries": [],
			"stats": {}
		}`

		reader := strings.NewReader(jsonData)
		me, err := ReadMemoryExport(reader)
		if err != nil {
			t.Fatalf("ReadMemoryExport failed: %v", err)
		}

		if len(me.Entries) != 0 {
			t.Errorf("expected 0 entries, got %d", len(me.Entries))
		}
	})

	t.Run("fails on invalid JSON", func(t *testing.T) {
		reader := strings.NewReader("{invalid json")
		_, err := ReadMemoryExport(reader)
		if err == nil {
			t.Error("expected error for invalid JSON")
		}
	})
}

func TestExportMemory(t *testing.T) {
	t.Parallel()
	t.Run("exports all tiers by default", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)
		now := time.Now().UTC()

		// Populate entries directly so Add() forcing Cold doesn't interfere;
		// this test verifies ExportMemory, not Add().
		sm.entries["h1"] = &MemoryEntry{
			ID:           "h1",
			Content:      "Hot memory",
			Tier:         TierHot,
			AccessCount:  10,
			LastAccessed: now,
			CreatedAt:    now,
			TokenCount:   100,
		}

		sm.entries["w1"] = &MemoryEntry{
			ID:           "w1",
			Content:      "Warm memory",
			Tier:         TierWarm,
			AccessCount:  3,
			LastAccessed: now,
			CreatedAt:    now,
			TokenCount:   50,
		}

		sm.entries["c1"] = &MemoryEntry{
			ID:           "c1",
			Content:      "Cold memory",
			Tier:         TierCold,
			AccessCount:  1,
			LastAccessed: now,
			CreatedAt:    now,
			TokenCount:   20,
		}

		config := ExportConfig{
			IncludeColdTier: true,
		}

		export, err := ExportMemory(sm, config)
		if err != nil {
			t.Fatalf("ExportMemory failed: %v", err)
		}

		if len(export.Entries) != 3 {
			t.Errorf("expected 3 entries, got %d", len(export.Entries))
		}

		// Verify stats
		if export.Stats[TierHot].Count != 1 {
			t.Errorf("expected 1 hot entry, got %d", export.Stats[TierHot].Count)
		}
		if export.Stats[TierWarm].Count != 1 {
			t.Errorf("expected 1 warm entry, got %d", export.Stats[TierWarm].Count)
		}
		if export.Stats[TierCold].Count != 1 {
			t.Errorf("expected 1 cold entry, got %d", export.Stats[TierCold].Count)
		}
	})

	t.Run("excludes cold tier when configured", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		// Populate entries directly; export test, not Add() test.
		now := time.Now()
		sm.entries["h1"] = &MemoryEntry{ID: "h1", Content: "Hot", Tier: TierHot, LastAccessed: now, CreatedAt: now, TokenCount: 10}
		sm.entries["w1"] = &MemoryEntry{ID: "w1", Content: "Warm", Tier: TierWarm, LastAccessed: now, CreatedAt: now, TokenCount: 20}
		sm.entries["c1"] = &MemoryEntry{ID: "c1", Content: "Cold", Tier: TierCold, LastAccessed: now, CreatedAt: now, TokenCount: 30}

		config := ExportConfig{
			IncludeColdTier: false,
		}

		export, err := ExportMemory(sm, config)
		if err != nil {
			t.Fatalf("ExportMemory failed: %v", err)
		}

		if len(export.Entries) != 2 {
			t.Errorf("expected 2 entries (cold excluded), got %d", len(export.Entries))
		}

		for _, entry := range export.Entries {
			if entry.Tier == TierCold {
				t.Error("found cold tier entry when it should be excluded")
			}
		}
	})

	t.Run("respects max entries limit", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)
		now := time.Now().UTC()

		// Add 10 entries
		for i := 0; i < 10; i++ {
			sm.Add(MemoryEntry{
				ID:           string(rune('A' + i)),
				Content:      "Memory",
				Tier:         TierHot,
				LastAccessed: now.Add(time.Duration(i) * time.Minute),
				CreatedAt:    now,
				TokenCount:   10,
			})
		}

		config := ExportConfig{
			MaxEntries:      5,
			IncludeColdTier: true,
		}

		export, err := ExportMemory(sm, config)
		if err != nil {
			t.Fatalf("ExportMemory failed: %v", err)
		}

		if len(export.Entries) != 5 {
			t.Errorf("expected 5 entries (limited), got %d", len(export.Entries))
		}
	})

	t.Run("accepts valid format values", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		formats := []string{"", "json", "gzipped"}
		for _, format := range formats {
			config := ExportConfig{
				Format:          format,
				IncludeColdTier: true,
			}

			_, err := ExportMemory(sm, config)
			if err != nil {
				t.Errorf("format %q should be accepted, got error: %v", format, err)
			}
		}
	})

	t.Run("rejects invalid format", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		config := ExportConfig{
			Format:          "invalid",
			IncludeColdTier: true,
		}

		_, err := ExportMemory(sm, config)
		if err == nil {
			t.Error("expected error for invalid format")
		}
	})

	t.Run("preserves entry data", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)
		now := time.Now().UTC()

		// Populate entry directly so Add() forcing Cold/AccessCount=0 doesn't
		// interfere; this test verifies that export preserves entry fields verbatim.
		original := MemoryEntry{
			ID:           "test",
			Content:      "Test content",
			Tier:         TierHot,
			AccessCount:  42,
			LastAccessed: now,
			CreatedAt:    now.Add(-time.Hour),
			TokenCount:   100,
		}

		sm.entries[original.ID] = &original

		config := ExportConfig{IncludeColdTier: true}
		export, err := ExportMemory(sm, config)
		if err != nil {
			t.Fatalf("ExportMemory failed: %v", err)
		}

		if len(export.Entries) != 1 {
			t.Fatalf("expected 1 entry, got %d", len(export.Entries))
		}

		exported := export.Entries[0]
		if exported.ID != original.ID {
			t.Errorf("ID mismatch: %s != %s", exported.ID, original.ID)
		}
		if exported.Content != original.Content {
			t.Errorf("Content mismatch: %s != %s", exported.Content, original.Content)
		}
		if exported.AccessCount != original.AccessCount {
			t.Errorf("AccessCount mismatch: %d != %d", exported.AccessCount, original.AccessCount)
		}
		if exported.TokenCount != original.TokenCount {
			t.Errorf("TokenCount mismatch: %d != %d", exported.TokenCount, original.TokenCount)
		}
	})
}

func TestImportMemory(t *testing.T) {
	t.Parallel()
	t.Run("imports entries into empty spatial memory", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		export := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{ID: "h1", Content: "Hot", Tier: TierHot, LastAccessed: time.Now(), CreatedAt: time.Now(), TokenCount: 10},
				{ID: "w1", Content: "Warm", Tier: TierWarm, LastAccessed: time.Now(), CreatedAt: time.Now(), TokenCount: 20},
				{ID: "c1", Content: "Cold", Tier: TierCold, LastAccessed: time.Now(), CreatedAt: time.Now(), TokenCount: 30},
			},
			Stats: TierStatsMap{
				TierHot:  {Count: 1, Tokens: 10},
				TierWarm: {Count: 1, Tokens: 20},
				TierCold: {Count: 1, Tokens: 30},
			},
		}

		imported, err := ImportMemory(sm, export)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 3 {
			t.Errorf("expected 3 imported, got %d", imported)
		}
	})

	t.Run("skips entries with empty ID", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		export := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{ID: "valid", Content: "Valid", Tier: TierHot, LastAccessed: time.Now(), CreatedAt: time.Now()},
				{ID: "", Content: "No ID", Tier: TierHot, LastAccessed: time.Now(), CreatedAt: time.Now()},
			},
		}

		imported, err := ImportMemory(sm, export)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 1 {
			t.Errorf("expected 1 imported (skipping empty ID), got %d", imported)
		}
	})

	t.Run("skips entries with invalid tier", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		export := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{ID: "valid", Content: "Valid", Tier: TierHot, LastAccessed: time.Now(), CreatedAt: time.Now()},
				{ID: "invalid", Content: "Invalid Tier", Tier: 999, LastAccessed: time.Now(), CreatedAt: time.Now()},
			},
		}

		imported, err := ImportMemory(sm, export)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 1 {
			t.Errorf("expected 1 imported (skipping invalid tier), got %d", imported)
		}
	})

	t.Run("returns error for nil export", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		_, err := ImportMemory(sm, nil)
		if err == nil {
			t.Error("expected error for nil export")
		}
	})

	t.Run("overwrites existing entries with same ID", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		// Add initial entry
		sm.Add(MemoryEntry{
			ID:          "test",
			Content:     "Original",
			Tier:        TierHot,
			AccessCount: 5,
		})

		// Import with same ID but different data
		export := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{
					ID:           "test",
					Content:      "Updated",
					Tier:         TierWarm,
					AccessCount:  10,
					LastAccessed: time.Now(),
					CreatedAt:    time.Now(),
					TokenCount:   100,
				},
			},
		}

		imported, err := ImportMemory(sm, export)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 1 {
			t.Errorf("expected 1 imported, got %d", imported)
		}

		// Verify the entry was updated
		stats := sm.TierStats()
		if stats[TierWarm].Count != 1 {
			t.Errorf("expected 1 warm entry after overwrite, got %d", stats[TierWarm].Count)
		}
	})

	t.Run("imports empty export", func(t *testing.T) {
		sm := NewSpatialMemory(1000, 1000, 1000)

		export := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries:    []MemoryEntry{},
		}

		imported, err := ImportMemory(sm, export)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 0 {
			t.Errorf("expected 0 imported, got %d", imported)
		}
	})
}

func TestMemoryExportRoundTrip(t *testing.T) {
	t.Parallel()
	t.Run("export and import preserves data", func(t *testing.T) {
		// Create source spatial memory
		sm1 := NewSpatialMemory(1000, 1000, 1000)
		now := time.Now().UTC()

		sm1.Add(MemoryEntry{
			ID:           "h1",
			Content:      "Hot memory",
			Tier:         TierHot,
			AccessCount:  10,
			LastAccessed: now,
			CreatedAt:    now.Add(-time.Hour),
			TokenCount:   100,
		})

		sm1.Add(MemoryEntry{
			ID:           "w1",
			Content:      "Warm memory",
			Tier:         TierWarm,
			AccessCount:  5,
			LastAccessed: now,
			CreatedAt:    now.Add(-2 * time.Hour),
			TokenCount:   200,
		})

		// Export
		config := ExportConfig{IncludeColdTier: true}
		export, err := ExportMemory(sm1, config)
		if err != nil {
			t.Fatalf("ExportMemory failed: %v", err)
		}

		// Serialize to JSON
		var buf bytes.Buffer
		_, err = export.WriteTo(&buf)
		if err != nil {
			t.Fatalf("WriteTo failed: %v", err)
		}

		// Deserialize from JSON
		export2, err := ReadMemoryExport(&buf)
		if err != nil {
			t.Fatalf("ReadMemoryExport failed: %v", err)
		}

		// Import into new spatial memory
		sm2 := NewSpatialMemory(1000, 1000, 1000)
		imported, err := ImportMemory(sm2, export2)
		if err != nil {
			t.Fatalf("ImportMemory failed: %v", err)
		}

		if imported != 2 {
			t.Errorf("expected 2 imported, got %d", imported)
		}

		// Verify data integrity
		stats1 := sm1.TierStats()
		stats2 := sm2.TierStats()

		if stats1[TierHot].Count != stats2[TierHot].Count {
			t.Errorf("hot tier count mismatch: %d != %d", stats1[TierHot].Count, stats2[TierHot].Count)
		}
		if stats1[TierWarm].Count != stats2[TierWarm].Count {
			t.Errorf("warm tier count mismatch: %d != %d", stats1[TierWarm].Count, stats2[TierWarm].Count)
		}
	})
}

func TestMemoryExportSummary(t *testing.T) {
	t.Parallel()
	t.Run("generates summary for non-empty export", func(t *testing.T) {
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries: []MemoryEntry{
				{ID: "h1", Tier: TierHot},
				{ID: "h2", Tier: TierHot},
				{ID: "w1", Tier: TierWarm},
				{ID: "c1", Tier: TierCold},
			},
			Stats: TierStatsMap{
				TierHot:  {Count: 2, Tokens: 100},
				TierWarm: {Count: 1, Tokens: 50},
				TierCold: {Count: 1, Tokens: 20},
			},
		}

		summary := me.Summary()

		// Verify summary contains key information
		if !strings.Contains(summary, "memory export") {
			t.Error("summary should contain 'memory export'")
		}
		if !strings.Contains(summary, "1.0") {
			t.Error("summary should contain version")
		}
		if !strings.Contains(summary, "4 entries") {
			t.Error("summary should contain entry count")
		}
	})

	t.Run("generates summary for empty export", func(t *testing.T) {
		me := &MemoryExport{
			Version:    "1.0",
			ExportedAt: time.Now().UTC(),
			Entries:    []MemoryEntry{},
			Stats:      make(TierStatsMap),
		}

		summary := me.Summary()

		if !strings.Contains(summary, "empty memory export") {
			t.Errorf("expected 'empty memory export', got: %s", summary)
		}
	})

	t.Run("generates summary for nil export", func(t *testing.T) {
		var me *MemoryExport

		summary := me.Summary()

		if !strings.Contains(summary, "empty memory export") {
			t.Errorf("expected 'empty memory export', got: %s", summary)
		}
	})
}
