package engine

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestMemoryIntegrity_SignAndVerify(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	mi, err := NewMemoryIntegrity(dir)
	if err != nil {
		t.Fatalf("NewMemoryIntegrity failed: %v", err)
	}

	node := &storage.Node{
		ID:      "test-node-1",
		Type:    "convention",
		Content: "Always use jose for JWT",
		Scope:   "project",
		Project: "my-app",
	}

	sig := mi.Sign(node)
	if sig == "" {
		t.Fatal("signature should not be empty")
	}

	// Verify should pass
	if !mi.Verify(node, sig) {
		t.Error("verification should pass for unmodified node")
	}

	// Tamper with content
	tampered := *node
	tampered.Content = "Use jsonwebtoken instead"
	if mi.Verify(&tampered, sig) {
		t.Error("verification should FAIL for tampered content")
	}

	// Unsigned nodes should pass (backward compat)
	if !mi.Verify(node, "") {
		t.Error("empty signature should pass (unsigned)")
	}
}

func TestMemoryIntegrity_VerifyBatch(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	mi, err := NewMemoryIntegrity(dir)
	if err != nil {
		t.Fatalf("NewMemoryIntegrity failed: %v", err)
	}

	nodes := []*storage.Node{
		{ID: "n1", Type: "convention", Content: "Rule 1", Scope: "project"},
		{ID: "n2", Type: "decision", Content: "Decision 1", Scope: "project"},
		{ID: "n3", Type: "bug", Content: "Bug 1", Scope: "project"},
	}

	sigs := make(map[string]string)
	for _, n := range nodes {
		sigs[n.ID] = mi.Sign(n)
	}

	// No tampering → no results
	tampered := mi.VerifyBatch(nodes, sigs)
	if len(tampered) != 0 {
		t.Errorf("expected 0 tampered, got %d", len(tampered))
	}

	// Tamper n2
	nodes[1].Content = "HACKED"
	tampered = mi.VerifyBatch(nodes, sigs)
	if len(tampered) != 1 || tampered[0] != "n2" {
		t.Errorf("expected n2 to be tampered, got %v", tampered)
	}
}

func TestMemoryIntegrity_KeyPersistence(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()

	// First instance generates key
	mi1, err := NewMemoryIntegrity(dir)
	if err != nil {
		t.Fatal(err)
	}
	node := &storage.Node{ID: "p1", Type: "convention", Content: "test", Scope: "project"}
	sig := mi1.Sign(node)

	// Second instance loads same key
	mi2, err := NewMemoryIntegrity(dir)
	if err != nil {
		t.Fatal(err)
	}

	// Signature from mi1 should verify with mi2 (same key)
	if !mi2.Verify(node, sig) {
		t.Error("second instance should verify signatures from first (same key)")
	}

	// Key file should exist
	keyPath := filepath.Join(dir, "integrity.key")
	if _, err := os.Stat(keyPath); os.IsNotExist(err) {
		t.Error("integrity.key should exist on disk")
	}
}

func TestMemoryIntegrity_TamperDetectionWithStore(t *testing.T) {
	t.Parallel()
	// This test verifies the full tamper detection flow:
	// 1. Create a node → signature is stored
	// 2. Modify content directly (simulating SQLite tampering)
	// 3. VerifyBatch detects the mismatch
	dir := t.TempDir()
	mi, err := NewMemoryIntegrity(dir)
	if err != nil {
		t.Fatalf("NewMemoryIntegrity: %v", err)
	}

	nodes := []*storage.Node{
		{ID: "n1", Type: "convention", Content: "use gofmt", Scope: "project", Project: "/app"},
		{ID: "n2", Type: "decision", Content: "postgres over mysql", Scope: "project", Project: "/app"},
		{ID: "n3", Type: "bug", Content: "nil pointer in handler", Scope: "project", Project: "/app"},
	}

	// Simulate what the engine does: sign each node and persist signatures
	storedSigs := make(map[string]string)
	for _, n := range nodes {
		storedSigs[n.ID] = mi.Sign(n)
	}

	// No tampering: all should pass
	tampered := mi.VerifyBatch(nodes, storedSigs)
	if len(tampered) != 0 {
		t.Errorf("expected 0 tampered before modification, got %d", len(tampered))
	}

	// Simulate direct DB edit (tampering): change n2's content without updating sig
	nodes[1].Content = "mysql over postgres"

	// Now verify should detect the tampered node
	tampered = mi.VerifyBatch(nodes, storedSigs)
	if len(tampered) != 1 {
		t.Fatalf("expected 1 tampered node, got %d", len(tampered))
	}
	if tampered[0] != "n2" {
		t.Errorf("expected n2 to be tampered, got %s", tampered[0])
	}

	// Tamper another node too
	nodes[2].Content = "different bug"
	tampered = mi.VerifyBatch(nodes, storedSigs)
	if len(tampered) != 2 {
		t.Errorf("expected 2 tampered nodes, got %d", len(tampered))
	}
}
