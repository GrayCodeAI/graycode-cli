package conflict

import (
	"context"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// TestCheckAndResolve_InvalidatesSupersededEdges verifies that when a new node
// supersedes an old one, the old node's outgoing factual edges have their
// temporal validity window closed (invalid_at set), while the new "supersedes"
// edge remains valid.
func TestCheckAndResolve_InvalidatesSupersededEdges(t *testing.T) {
	t.Parallel()
	store := storage.NewMockStorage()
	ctx := context.Background()
	r := New(store)

	old := &storage.Node{
		ID:         uuid.New().String(),
		Type:       "decision",
		Content:    "Authentication uses HS256 algorithm with static secret for token signing",
		Scope:      "project",
		Project:    "p",
		Confidence: 1.0,
	}
	if err := store.CreateNode(ctx, old); err != nil {
		t.Fatalf("CreateNode old: %v", err)
	}
	// A factual outgoing edge from the old node; it should be invalidated.
	factEdge := &storage.Edge{ID: "fact", FromID: old.ID, ToID: uuid.New().String(), Type: "relates_to", Weight: 1.0}
	if err := store.CreateEdge(ctx, factEdge); err != nil {
		t.Fatalf("CreateEdge fact: %v", err)
	}
	if factEdge.ValidAt.IsZero() {
		t.Fatal("expected CreateEdge to stamp valid_at on the fact edge")
	}

	newNode := &storage.Node{
		ID:         uuid.New().String(),
		Type:       "decision",
		Content:    "Authentication uses RS256 algorithm with rotating keys for token signing",
		Scope:      "project",
		Project:    "p",
		Confidence: 1.0,
	}
	if err := store.CreateNode(ctx, newNode); err != nil {
		t.Fatalf("CreateNode new: %v", err)
	}

	superseded, err := r.CheckAndResolve(ctx, newNode)
	if err != nil {
		t.Fatalf("CheckAndResolve: %v", err)
	}
	if len(superseded) != 1 || superseded[0] != old.ID {
		t.Fatalf("expected old node %s superseded, got %v", old.ID, superseded)
	}

	got, err := store.GetEdge(ctx, "fact")
	if err != nil {
		t.Fatalf("GetEdge fact: %v", err)
	}
	if got.InvalidAt.IsZero() {
		t.Error("expected superseded node's outgoing edge to be invalidated")
	}

	// The new supersedes edge must still be currently valid.
	valid, err := store.GetValidEdgesFrom(ctx, newNode.ID, time.Time{})
	if err != nil {
		t.Fatalf("GetValidEdgesFrom: %v", err)
	}
	foundSupersedes := false
	for _, e := range valid {
		if e.Type == "supersedes" && e.ToID == old.ID {
			foundSupersedes = true
		}
	}
	if !foundSupersedes {
		t.Error("expected a currently-valid supersedes edge from the new node")
	}
}
