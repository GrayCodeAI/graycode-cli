package engine

import (
	"context"
	"sort"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// Rerank re-scores nodes combining RRF score, graph centrality, recency, and confidence.
func Rerank(ctx context.Context, nodes []*ScoredNode, store storage.Storage) []*ScoredNode {
	now := time.Now()
	// Batch-fetch edge counts to avoid N+1 queries.
	ids := make([]string, 0, len(nodes))
	for _, sn := range nodes {
		ids = append(ids, sn.Node.ID)
	}
	edgeCounts, _ := store.CountEdgesBatch(ctx, ids)
	for _, sn := range nodes {
		sn.Score = combinedScore(sn, edgeCounts, now)
	}
	sort.Slice(nodes, func(i, j int) bool {
		return nodes[i].Score > nodes[j].Score
	})
	return nodes
}

func combinedScore(sn *ScoredNode, edgeCounts map[string][2]int, now time.Time) float64 {
	n := sn.Node

	// Centrality: count inbound edges (more connections = more important)
	inboundCount := 0
	if ec, ok := edgeCounts[n.ID]; ok {
		inboundCount = ec[0]
	}
	centrality := 1.0 + float64(inboundCount)*0.1

	// Recency: exponential decay over 30 days
	recency := 1.0
	ref := n.UpdatedAt
	if !n.AccessedAt.IsZero() && n.AccessedAt.After(ref) {
		ref = n.AccessedAt
	}
	if !ref.IsZero() {
		days := now.Sub(ref).Hours() / 24
		recency = 1.0 / (1.0 + days/30.0)
	}

	// Tier boost: hot tier nodes rank higher
	tierBoost := 1.0
	switch n.Tier {
	case 1:
		tierBoost = 2.0
	case 2:
		tierBoost = 1.5
	}

	return sn.Score * n.Confidence * centrality * recency * tierBoost
}
