//go:build !windows

package storage

import (
	"os"

	"golang.org/x/sys/unix"
)

// acquireOSLock takes a non-blocking exclusive flock(2) on the lock file.
func acquireOSLock(fd *os.File) error {
	return unix.Flock(int(fd.Fd()), unix.LOCK_EX|unix.LOCK_NB)
}

// releaseOSLock releases the flock; a subsequent Close releases it anyway.
func releaseOSLock(fd *os.File) {
	_ = unix.Flock(int(fd.Fd()), unix.LOCK_UN)
}
