package engine

import (
	"context"
	"strings"
	"sync"

	"github.com/GrayCodeAI/harrier/storage"
)

// EntityIndex maintains a parallel index of entities (functions, files, libraries,
// classes, APIs) extracted from memory content. During retrieval, query entities
// are matched against this index to boost relevant memories.
//
// Based on Mem0 v3's approach: extract entities on ingestion, boost on retrieval.
// But faster: regex-based extraction (no LLM call), O(1) lookup via map.
type EntityIndex struct {
	mu       sync.RWMutex
	entities map[string][]string // entity → []nodeID
	nodeEnts map[string][]string // nodeID → []entity
}

// NewEntityIndex creates a new entity index.
func NewEntityIndex() *EntityIndex {
	return &EntityIndex{
		entities: make(map[string][]string),
		nodeEnts: make(map[string][]string),
	}
}

// IndexNode extracts entities from a node and adds them to the index.
func (ei *EntityIndex) IndexNode(node *storage.Node) {
	if node == nil || node.Content == "" {
		return
	}

	rawEntities := ExtractEntities(node.Content)
	if len(rawEntities) == 0 {
		return
	}

	ei.mu.Lock()
	defer ei.mu.Unlock()

	var names []string
	for _, ent := range rawEntities {
		names = append(names, ent.Name)
		key := strings.ToLower(ent.Name)
		ei.entities[key] = appendUnique(ei.entities[key], node.ID)
	}
	ei.nodeEnts[node.ID] = names
}

// RemoveNode removes a node from the entity index.
func (ei *EntityIndex) RemoveNode(nodeID string) {
	ei.mu.Lock()
	defer ei.mu.Unlock()

	ents, ok := ei.nodeEnts[nodeID]
	if !ok {
		return
	}
	for _, ent := range ents {
		key := strings.ToLower(ent)
		ei.entities[key] = removeFromSlice(ei.entities[key], nodeID)
		if len(ei.entities[key]) == 0 {
			delete(ei.entities, key)
		}
	}
	delete(ei.nodeEnts, nodeID)
}

// BoostScores takes a query, extracts entities from it, and returns
// boost multipliers for node IDs that share entities with the query.
// Returns map[nodeID] → boost factor (1.0 = no boost, higher = more entity overlap).
func (ei *EntityIndex) BoostScores(query string) map[string]float64 {
	queryEntities := ExtractEntities(query)
	if len(queryEntities) == 0 {
		return nil
	}

	ei.mu.RLock()
	defer ei.mu.RUnlock()

	boosts := make(map[string]float64)
	for _, qe := range queryEntities {
		key := strings.ToLower(qe.Name)
		nodeIDs, ok := ei.entities[key]
		if !ok {
			continue
		}
		numLinked := len(nodeIDs)
		for _, id := range nodeIDs {
			// Spread-attenuated boost (Mem0 v3 technique):
			// Penalizes entities linking to many nodes (too generic)
			boost := SpreadAttenuatedBoost(1.0, numLinked, 0.001)
			boosts[id] += boost
		}
	}

	// Convert to multipliers (1.0 base + boost), cap at 2.0
	for id, boost := range boosts {
		mult := 1.0 + boost
		if mult > 2.0 {
			mult = 2.0
		}
		boosts[id] = mult
	}
	return boosts
}

// LoadFromStore rebuilds the entity index from all nodes in the store.
func (ei *EntityIndex) LoadFromStore(ctx context.Context, store storage.Storage) error {
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: 10000})
	if err != nil {
		return err
	}
	for _, n := range nodes {
		ei.IndexNode(n)
	}
	return nil
}

// Size returns the number of unique entities tracked.
func (ei *EntityIndex) Size() int {
	ei.mu.RLock()
	defer ei.mu.RUnlock()
	return len(ei.entities)
}

func appendUnique(slice []string, item string) []string {
	for _, s := range slice {
		if s == item {
			return slice
		}
	}
	return append(slice, item)
}

func removeFromSlice(slice []string, item string) []string {
	for i, s := range slice {
		if s == item {
			return append(slice[:i], slice[i+1:]...)
		}
	}
	return slice
}
