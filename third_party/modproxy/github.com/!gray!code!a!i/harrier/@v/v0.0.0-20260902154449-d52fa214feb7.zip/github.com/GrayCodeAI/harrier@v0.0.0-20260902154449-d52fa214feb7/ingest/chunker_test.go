package ingest

import (
	"strings"
	"testing"
)

func TestChunkGoFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `package main

import (
	"fmt"
	"os"
)

const Version = "1.0.0"

type Server struct {
	Port int
	Host string
}

func (s *Server) Start() error {
	fmt.Println("starting")
	return nil
}

func (s *Server) Stop() {
	fmt.Println("stopping")
}

func main() {
	s := &Server{Port: 8080}
	s.Start()
}
`
	chunks, err := chunker.ChunkFile("main.go", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from Go file, got none")
	}

	// Verify we have the expected chunk types
	types := map[string]bool{}
	names := map[string]bool{}
	for _, c := range chunks {
		types[c.Type] = true
		names[c.Name] = true
		if c.Language != "go" {
			t.Errorf("expected language 'go', got %q", c.Language)
		}
		if c.FilePath != "main.go" {
			t.Errorf("expected FilePath 'main.go', got %q", c.FilePath)
		}
	}

	if !types["import"] {
		t.Error("expected import chunk")
	}
	if !types["function"] {
		t.Error("expected function chunk")
	}
	if !types["type"] {
		t.Error("expected type chunk")
	}
	if !types["method"] {
		t.Error("expected method chunk")
	}
	if !names["main"] {
		t.Error("expected 'main' function chunk")
	}
	if !names["Server"] {
		t.Error("expected 'Server' type chunk")
	}
}

func TestChunkGoFileSingleFunction(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `package util

func Add(a, b int) int {
	return a + b
}
`
	chunks, err := chunker.ChunkFile("util.go", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected at least one chunk")
	}

	found := false
	for _, c := range chunks {
		if c.Type == "function" && c.Name == "Add" {
			found = true
			if !strings.Contains(c.Content, "return a + b") {
				t.Error("function chunk missing body content")
			}
		}
	}
	if !found {
		t.Error("expected function chunk named 'Add'")
	}
}

func TestChunkPythonFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `import os
import sys
from pathlib import Path

class Server:
    def __init__(self, port):
        self.port = port

    def start(self):
        print("starting")

    def stop(self):
        print("stopping")

def main():
    s = Server(8080)
    s.start()

def helper():
    return 42
`
	chunks, err := chunker.ChunkFile("server.py", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from Python file, got none")
	}

	types := map[string]bool{}
	names := map[string]bool{}
	for _, c := range chunks {
		types[c.Type] = true
		names[c.Name] = true
		if c.Language != "python" {
			t.Errorf("expected language 'python', got %q", c.Language)
		}
	}

	if !types["import"] {
		t.Error("expected import chunk")
	}
	if !types["class"] || !types["function"] {
		t.Errorf("expected class and function chunks, got types: %v", types)
	}
	if !names["main"] {
		t.Error("expected 'main' function chunk")
	}
	if !names["helper"] {
		t.Error("expected 'helper' function chunk")
	}
}

func TestChunkPythonClassSplit(t *testing.T) {
	t.Parallel()
	// Create a class that exceeds MaxChunkTokens
	chunker := NewChunker()
	chunker.MaxChunkTokens = 100 // deliberately low to trigger splitting

	var methods strings.Builder
	methods.WriteString("class BigClass:\n")
	for i := 0; i < 10; i++ {
		methods.WriteString("    def method_" + string(rune('a'+i)) + "(self):\n")
		methods.WriteString("        " + strings.Repeat("x", 80) + "\n")
		methods.WriteString("        return None\n\n")
	}

	chunks, err := chunker.ChunkFile("big.py", methods.String())
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) < 2 {
		t.Errorf("expected large class to be split into multiple chunks, got %d", len(chunks))
	}

	// Should have method chunks
	hasMethod := false
	for _, c := range chunks {
		if c.Type == "method" {
			hasMethod = true
			break
		}
	}
	if !hasMethod {
		t.Error("expected method chunks when splitting large Python class")
	}
}

func TestChunkTypeScriptFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `import { Request, Response } from 'express';
import { User } from './models';

export interface Config {
  port: number;
  host: string;
}

export type Handler = (req: Request) => Response;

export class Server {
  private port: number;

  constructor(port: number) {
    this.port = port;
  }

  start() {
    console.log("starting");
  }
}

export function createServer(config: Config): Server {
  return new Server(config.port);
}

export const DEFAULT_PORT = 3000;
`
	chunks, err := chunker.ChunkFile("server.ts", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from TypeScript file, got none")
	}

	types := map[string]bool{}
	names := map[string]bool{}
	for _, c := range chunks {
		types[c.Type] = true
		names[c.Name] = true
		if c.Language != "typescript" {
			t.Errorf("expected language 'typescript', got %q", c.Language)
		}
	}

	if !types["import"] {
		t.Error("expected import chunk")
	}
	if !types["type"] {
		t.Error("expected type/interface chunk")
	}
	if !types["class"] {
		t.Error("expected class chunk")
	}
	if !types["function"] {
		t.Error("expected function chunk")
	}
	if !names["Config"] {
		t.Error("expected 'Config' interface chunk")
	}
	if !names["createServer"] {
		t.Error("expected 'createServer' function chunk")
	}
}

func TestChunkTypeScriptExports(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `export function greet(name: string): string {
  return "Hello " + name;
}

export function farewell(name: string): string {
  return "Goodbye " + name;
}
`
	chunks, err := chunker.ChunkFile("utils.ts", src)
	if err != nil {
		t.Fatal(err)
	}

	funcCount := 0
	for _, c := range chunks {
		if c.Type == "function" {
			funcCount++
		}
	}
	if funcCount != 2 {
		t.Errorf("expected 2 function chunks, got %d", funcCount)
	}
}

func TestChunkGenericFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `first block line 1
first block line 2

second block line 1
second block line 2
second block line 3

third block line 1
`
	chunks, err := chunker.ChunkFile("config.txt", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) < 3 {
		t.Errorf("expected at least 3 chunks from blank-line-separated blocks, got %d", len(chunks))
	}

	for _, c := range chunks {
		if c.Language != "generic" {
			t.Errorf("expected language 'generic', got %q", c.Language)
		}
		if c.Type != "module" {
			t.Errorf("expected type 'module' for generic chunks, got %q", c.Type)
		}
	}
}

func TestChunkRustFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `use std::collections::HashMap;

pub struct Point {
    x: f64,
    y: f64,
}

impl Point {
    pub fn new(x: f64, y: f64) -> Self {
        Point { x, y }
    }
}

pub fn distance(a: &Point, b: &Point) -> f64 {
    ((a.x - b.x).powi(2) + (a.y - b.y).powi(2)).sqrt()
}
`
	chunks, err := chunker.ChunkFile("geo.rs", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from Rust file, got none")
	}
	names := map[string]bool{}
	for _, c := range chunks {
		names[c.Name] = true
		if c.Language != "rust" {
			t.Errorf("expected language 'rust', got %q", c.Language)
		}
		// The brace splitter must keep whole top-level blocks together, not
		// fragment them at blank lines as the generic fallback would.
		if c.Type == "module" {
			t.Errorf("rust should use brace-block chunking, not generic 'module' chunks: %+v", c)
		}
	}
	for _, want := range []string{"Point", "distance"} {
		if !names[want] {
			t.Errorf("expected a chunk named %q, got names=%v", want, names)
		}
	}
}

func TestChunkJavaFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `package com.example;

public class Calculator {
    private int total;

    public int add(int a, int b) {
        return a + b;
    }
}
`
	chunks, err := chunker.ChunkFile("Calculator.java", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from Java file, got none")
	}
	found := false
	for _, c := range chunks {
		if c.Language != "java" {
			t.Errorf("expected language 'java', got %q", c.Language)
		}
		if c.Name == "Calculator" {
			found = true
		}
	}
	if !found {
		t.Error("expected a chunk named 'Calculator'")
	}
}

func TestChunkCppFile(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `#include <vector>

struct Node {
    int value;
};

int sum(const std::vector<int>& xs) {
    int total = 0;
    for (int x : xs) {
        total += x;
    }
    return total;
}
`
	chunks, err := chunker.ChunkFile("util.cpp", src)
	if err != nil {
		t.Fatal(err)
	}
	if len(chunks) == 0 {
		t.Fatal("expected chunks from C++ file, got none")
	}
	for _, c := range chunks {
		if c.Language != "cpp" {
			t.Errorf("expected language 'cpp', got %q", c.Language)
		}
	}
}

func TestChunkBraceLang_AllmanBraces(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	// Allman style: opening brace on its own line — idiomatic in Java/C/C++.
	src := `package com.example;

public class Service
{
    public void run()
    {
        System.out.println("go");
    }
}

class Helper
{
    int value;
}
`
	chunks, err := chunker.ChunkFile("Service.java", src)
	if err != nil {
		t.Fatal(err)
	}
	names := map[string]bool{}
	for _, c := range chunks {
		names[c.Name] = true
		if c.Type == "module" {
			t.Errorf("Allman-brace Java must not degrade to generic 'module' chunks: %+v", c)
		}
	}
	for _, want := range []string{"Service", "Helper"} {
		if !names[want] {
			t.Errorf("expected top-level block %q, got names=%v", want, names)
		}
	}
}

func TestChunkBraceLang_RustLifetimes(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `use std::fmt;

impl<'a> Parser<'a> {
    fn parse(&self) -> &'a str {
        self.input
    }
}

pub fn build<'a, T>(x: &'a T) -> Wrapper<'a, T> {
    Wrapper { inner: x }
}
`
	chunks, err := chunker.ChunkFile("parser.rs", src)
	if err != nil {
		t.Fatal(err)
	}
	names := map[string]bool{}
	for _, c := range chunks {
		names[c.Name] = true
	}
	// The lifetime 'a must never be captured as the declaration name.
	if names["a"] || names["impl"] {
		t.Errorf("regex captured a lifetime/keyword as the name: %v", names)
	}
	if !names["Parser"] {
		t.Errorf("expected 'Parser' impl block (lifetime in leading generics), got %v", names)
	}
	if !names["build"] {
		t.Errorf("expected 'build' fn, got %v", names)
	}
}

func TestChunkBraceLang_ExtensionRouting(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	cases := []struct {
		file string
		lang string
		src  string
	}{
		{"App.kt", "kotlin", "fun main() {\n    println(\"hi\")\n}\n"},
		{"App.swift", "swift", "func greet() -> String {\n    return \"hi\"\n}\n"},
		{"App.cs", "csharp", "public class App {\n    void Run() {}\n}\n"},
		{"mod.cppm", "cpp", "export module app;\nint compute() {\n    return 1;\n}\n"},
	}
	for _, tc := range cases {
		chunks, err := chunker.ChunkFile(tc.file, tc.src)
		if err != nil {
			t.Fatalf("%s: %v", tc.file, err)
		}
		if len(chunks) == 0 {
			t.Errorf("%s: expected chunks, got none", tc.file)
			continue
		}
		for _, c := range chunks {
			if c.Language != tc.lang {
				t.Errorf("%s: expected language %q, got %q", tc.file, tc.lang, c.Language)
			}
			// These languages must reach chunkBraceLang, not the generic fallback.
			if c.Type == "module" {
				t.Errorf("%s: should use brace chunking, got generic 'module' chunk", tc.file)
			}
		}
	}
}

func TestDetectLanguage_BraceExtensions(t *testing.T) {
	t.Parallel()
	want := map[string]string{
		"a.rs": "rust", "A.java": "java", "a.c": "c", "a.h": "c",
		"a.cpp": "cpp", "a.hh": "cpp", "a.hxx": "cpp", "a.cppm": "cpp", "a.tcc": "cpp",
		"a.cs": "csharp", "a.kt": "kotlin", "a.kts": "kotlin",
		"a.swift": "swift", "a.scala": "scala",
		"a.rb": "ruby", "a.txt": "generic",
	}
	for path, lang := range want {
		if got := detectLanguage(path); got != lang {
			t.Errorf("detectLanguage(%q) = %q, want %q", path, got, lang)
		}
	}
	// Every brace-routed language must be recognized as such.
	for _, lang := range braceLangExts {
		if !isBraceLang(lang) {
			t.Errorf("braceLangExts maps to %q but isBraceLang(%q) is false", lang, lang)
		}
	}
}

func TestMergeSmallChunks(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunker.MinChunkTokens = 50

	chunks := []Chunk{
		{StartLine: 1, EndLine: 2, Content: "small1", Type: "const", Name: "A", TokenEstimate: 10, FilePath: "x.go"},
		{StartLine: 3, EndLine: 4, Content: "small2", Type: "const", Name: "B", TokenEstimate: 10, FilePath: "x.go"},
		{StartLine: 5, EndLine: 6, Content: "small3", Type: "const", Name: "C", TokenEstimate: 10, FilePath: "x.go"},
		{StartLine: 7, EndLine: 20, Content: strings.Repeat("big function ", 50), Type: "function", Name: "Big", TokenEstimate: 200, FilePath: "x.go"},
	}

	merged := chunker.MergeSmallChunks(chunks)

	// The three small const chunks should be merged into one
	if len(merged) >= len(chunks) {
		t.Errorf("expected fewer chunks after merging, got %d (original %d)", len(merged), len(chunks))
	}

	// The big function should remain separate
	foundBig := false
	for _, c := range merged {
		if c.Name == "Big" || strings.Contains(c.Name, "Big") {
			foundBig = true
		}
	}
	if !foundBig {
		t.Error("expected 'Big' function chunk to remain after merge")
	}
}

func TestMergeSmallChunksRespectTypeBoundaries(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunker.MinChunkTokens = 50

	chunks := []Chunk{
		{StartLine: 1, EndLine: 2, Content: "import x", Type: "import", Name: "imports", TokenEstimate: 5, FilePath: "x.go"},
		{StartLine: 3, EndLine: 4, Content: "func small() {}", Type: "function", Name: "small", TokenEstimate: 10, FilePath: "x.go"},
	}

	merged := chunker.MergeSmallChunks(chunks)

	// Should NOT merge import with function despite both being small
	if len(merged) < 2 {
		t.Error("should not merge chunks of different types")
	}
}

func TestMaxChunkTokensSplitsLargeFunctions(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunker.MaxChunkTokens = 100

	// Create a Go file with a very large function
	var lines []string
	lines = append(lines, "package main")
	lines = append(lines, "")
	lines = append(lines, "func bigFunc() {")
	for i := 0; i < 100; i++ {
		lines = append(lines, "\tfmt.Println(\""+strings.Repeat("x", 60)+"\")")
	}
	lines = append(lines, "}")
	src := strings.Join(lines, "\n")

	chunks, err := chunker.ChunkFile("big.go", src)
	if err != nil {
		t.Fatal(err)
	}

	// The large function should have been split
	if len(chunks) < 2 {
		t.Errorf("expected large function to be split into multiple chunks, got %d", len(chunks))
	}
}

func TestAddOverlap(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunks := []Chunk{
		{
			StartLine:     1,
			EndLine:       5,
			Content:       "line1\nline2\nline3\nline4\nline5",
			Type:          "function",
			Name:          "first",
			FilePath:      "test.go",
			TokenEstimate: 20,
		},
		{
			StartLine:     6,
			EndLine:       10,
			Content:       "line6\nline7\nline8\nline9\nline10",
			Type:          "function",
			Name:          "second",
			FilePath:      "test.go",
			TokenEstimate: 20,
		},
		{
			StartLine:     11,
			EndLine:       15,
			Content:       "line11\nline12\nline13\nline14\nline15",
			Type:          "function",
			Name:          "third",
			FilePath:      "test.go",
			TokenEstimate: 20,
		},
	}

	result := chunker.AddOverlap(chunks, 2)

	// First chunk should be unchanged
	if result[0].Content != chunks[0].Content {
		t.Error("first chunk should not have overlap added")
	}

	// Second chunk should start with last 2 lines of first chunk
	if !strings.Contains(result[1].Content, "line4") || !strings.Contains(result[1].Content, "line5") {
		t.Error("second chunk should contain overlap lines from first chunk")
	}

	// Third chunk should start with last 2 lines of second chunk
	if !strings.Contains(result[2].Content, "line9") || !strings.Contains(result[2].Content, "line10") {
		t.Error("third chunk should contain overlap lines from second chunk")
	}
}

func TestEmptyFileHandling(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()

	chunks, err := chunker.ChunkFile("empty.go", "")
	if err != nil {
		t.Fatalf("empty file should not error: %v", err)
	}
	if chunks != nil {
		t.Errorf("expected nil chunks for empty file, got %d", len(chunks))
	}
}

func TestLanguageDetection(t *testing.T) {
	t.Parallel()
	cases := []struct {
		path     string
		expected string
	}{
		{"main.go", "go"},
		{"server.py", "python"},
		{"app.ts", "typescript"},
		{"app.tsx", "typescript"},
		{"index.js", "javascript"},
		{"module.mjs", "javascript"},
		{"lib.rs", "rust"},
		{"app.rb", "ruby"},
		{"Main.java", "java"},
		{"config.yaml", "generic"},
		{"README.md", "generic"},
		{".env", "generic"},
	}

	for _, tc := range cases {
		got := detectLanguage(tc.path)
		if got != tc.expected {
			t.Errorf("detectLanguage(%q) = %q, want %q", tc.path, got, tc.expected)
		}
	}
}

func TestEstimateTokens(t *testing.T) {
	t.Parallel()
	// 100 chars of 'a' — BPE compresses repeated chars efficiently
	content := strings.Repeat("a", 100)
	est := EstimateTokens(content)
	if est < 10 || est > 40 {
		t.Errorf("EstimateTokens(100 chars) = %d, want between 10 and 40 (BPE-compressed)", est)
	}

	// Empty string should be 0
	if EstimateTokens("") != 0 {
		t.Error("EstimateTokens('') should be 0")
	}
}

func TestChunkIDDeterministic(t *testing.T) {
	t.Parallel()
	id1 := chunkID("main.go", 1, 10)
	id2 := chunkID("main.go", 1, 10)
	id3 := chunkID("main.go", 1, 11)

	if id1 != id2 {
		t.Error("chunkID should be deterministic for same inputs")
	}
	if id1 == id3 {
		t.Error("chunkID should differ for different inputs")
	}
	if len(id1) != 32 {
		t.Errorf("expected 32 hex chars, got %d", len(id1))
	}
}

func TestChunkGoConstants(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `package config

const (
	DefaultPort = 8080
	DefaultHost = "localhost"
	MaxConns    = 100
)

var (
	GlobalLogger = nil
)
`
	chunks, err := chunker.ChunkFile("config.go", src)
	if err != nil {
		t.Fatal(err)
	}

	hasConst := false
	for _, c := range chunks {
		if c.Type == "const" {
			hasConst = true
		}
	}
	if !hasConst {
		t.Error("expected const chunk from Go const block")
	}
}

func TestChunkGoMethodParentChunk(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	src := `package main

type Handler struct{}

func (h *Handler) ServeHTTP() {}

func (h *Handler) Close() {}
`
	chunks, err := chunker.ChunkFile("handler.go", src)
	if err != nil {
		t.Fatal(err)
	}

	for _, c := range chunks {
		if c.Type == "method" {
			if c.ParentChunk == "" {
				t.Errorf("method %q should have a ParentChunk set", c.Name)
			}
			if !strings.Contains(c.Name, "Handler.") {
				t.Errorf("method name %q should contain receiver type", c.Name)
			}
		}
	}
}

func TestAddOverlapWithZeroLines(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunks := []Chunk{
		{Content: "a", StartLine: 1, EndLine: 1},
		{Content: "b", StartLine: 2, EndLine: 2},
	}
	result := chunker.AddOverlap(chunks, 0)
	if result[1].Content != "b" {
		t.Error("overlap of 0 should not modify chunks")
	}
}

func TestAddOverlapSingleChunk(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunks := []Chunk{
		{Content: "only one", StartLine: 1, EndLine: 1},
	}
	result := chunker.AddOverlap(chunks, 3)
	if len(result) != 1 || result[0].Content != "only one" {
		t.Error("single chunk should be returned unchanged")
	}
}

func TestGenericChunkingLargeBlock(t *testing.T) {
	t.Parallel()
	chunker := NewChunker()
	chunker.MaxChunkTokens = 50

	// A single large block without blank lines
	var lines []string
	for i := 0; i < 100; i++ {
		lines = append(lines, strings.Repeat("word ", 10))
	}
	src := strings.Join(lines, "\n")

	chunks, err := chunker.ChunkFile("data.txt", src)
	if err != nil {
		t.Fatal(err)
	}

	// Should be split into multiple chunks
	if len(chunks) < 2 {
		t.Errorf("expected large block to be split, got %d chunks", len(chunks))
	}

	// Each chunk should respect MaxChunkTokens (approximately)
	for _, c := range chunks {
		if c.TokenEstimate > chunker.MaxChunkTokens*2 {
			t.Errorf("chunk exceeds 2x MaxChunkTokens: %d tokens", c.TokenEstimate)
		}
	}
}

func TestNewChunkerDefaults(t *testing.T) {
	t.Parallel()
	c := NewChunker()
	if c.MaxChunkTokens != 500 {
		t.Errorf("expected MaxChunkTokens=500, got %d", c.MaxChunkTokens)
	}
	if c.MinChunkTokens != 50 {
		t.Errorf("expected MinChunkTokens=50, got %d", c.MinChunkTokens)
	}
	if c.OverlapLines != 2 {
		t.Errorf("expected OverlapLines=2, got %d", c.OverlapLines)
	}
}
