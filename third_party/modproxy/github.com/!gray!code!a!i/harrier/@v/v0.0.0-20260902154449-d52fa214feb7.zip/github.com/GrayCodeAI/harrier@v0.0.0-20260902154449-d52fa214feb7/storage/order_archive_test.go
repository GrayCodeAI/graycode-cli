package storage

import (
	"context"
	"path/filepath"
	"testing"
	"time"
)

func newOrderTestStore(t *testing.T) *Store {
	t.Helper()
	store, err := NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	return store
}

func seedNode(t *testing.T, store *Store, id, project string, updatedAt time.Time) {
	t.Helper()
	if err := store.CreateNode(context.Background(), &Node{
		ID:          id,
		Type:        "idea",
		Content:     "content " + id,
		ContentHash: "hash-" + id,
		Scope:       "global",
		Project:     project,
		Confidence:  0.8,
		CreatedAt:   updatedAt,
		UpdatedAt:   updatedAt,
	}); err != nil {
		t.Fatal(err)
	}
}

// TestListNodes_OrdersByUpdatedAtDesc pins the deterministic recency order:
// list queries with a Limit must return the most recently updated nodes, and
// pagination must be stable.
func TestListNodes_OrdersByUpdatedAtDesc(t *testing.T) {
	t.Parallel()
	store := newOrderTestStore(t)
	ctx := context.Background()

	base := time.Now().Add(-24 * time.Hour)
	seedNode(t, store, "oldest", "p1", base)
	seedNode(t, store, "middle", "p1", base.Add(1*time.Hour))
	seedNode(t, store, "newest", "p1", base.Add(2*time.Hour))

	nodes, err := store.ListNodes(ctx, NodeFilter{Project: "p1", Limit: 2})
	if err != nil {
		t.Fatal(err)
	}
	if len(nodes) != 2 {
		t.Fatalf("expected 2 nodes, got %d", len(nodes))
	}
	if nodes[0].ID != "newest" || nodes[1].ID != "middle" {
		t.Errorf("expected [newest middle], got [%s %s]", nodes[0].ID, nodes[1].ID)
	}

	// Page 2 continues deterministically.
	page2, err := store.ListNodes(ctx, NodeFilter{Project: "p1", Limit: 1, Offset: 2})
	if err != nil {
		t.Fatal(err)
	}
	if len(page2) != 1 || page2[0].ID != "oldest" {
		t.Errorf("expected page 2 = [oldest], got %+v", page2)
	}
}

// TestArchiveNode_OnlyArchivesLiveNodes pins the CAS semantics behind Forget:
// archiving is a confidence>0-guarded single-column write, and re-archiving is
// an idempotent no-op rather than a full-node write-back.
func TestArchiveNode_OnlyArchivesLiveNodes(t *testing.T) {
	t.Parallel()
	store := newOrderTestStore(t)
	ctx := context.Background()

	seedNode(t, store, "live", "p1", time.Now())
	seedNode(t, store, "gone", "p1", time.Now())

	archived, err := store.ArchiveNode(ctx, "live")
	if err != nil {
		t.Fatal(err)
	}
	if !archived {
		t.Error("expected live node to be archived")
	}
	got, err := store.GetNode(ctx, "live")
	if err != nil {
		t.Fatal(err)
	}
	if got.Confidence != 0 {
		t.Errorf("confidence = %f, want 0", got.Confidence)
	}
	if got.Content != "content live" {
		t.Errorf("archiving must not touch other fields, content = %q", got.Content)
	}

	// Idempotent: already archived is a no-op, not an error.
	again, err := store.ArchiveNode(ctx, "live")
	if err != nil {
		t.Fatal(err)
	}
	if again {
		t.Error("expected already-archived node to report not archived")
	}

	// Missing node: no-op, no error.
	missing, err := store.ArchiveNode(ctx, "does-not-exist")
	if err != nil {
		t.Fatal(err)
	}
	if missing {
		t.Error("expected missing node to report not archived")
	}
}
