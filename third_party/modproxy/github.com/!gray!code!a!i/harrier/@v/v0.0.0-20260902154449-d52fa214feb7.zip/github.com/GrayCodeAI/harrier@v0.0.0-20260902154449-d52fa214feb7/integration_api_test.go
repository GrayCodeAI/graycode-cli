//go:build integration

//nolint:noctx
package harrier_test

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/config"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/internal/server"
	harriertls "github.com/GrayCodeAI/harrier/internal/tls"
	"github.com/GrayCodeAI/harrier/profile"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/GrayCodeAI/harrier/utils"
)

// This file is part of the harrier_test integration suite. It holds the utils,
// edge-case, profile-merge, TLS, config, storage, REST API, and concurrency
// tests moved verbatim out of integration_test.go for readability; behavior
// is unchanged.

func TestUtilsShortID(t *testing.T) {
	cases := []struct{ input, expected string }{
		{"abcdefghijklmnop", "abcdefgh"},
		{"short", "short"},
		{"12345678", "12345678"},
		{"", ""},
		{"ab", "ab"},
	}
	for _, c := range cases {
		got := utils.ShortID(c.input)
		if got != c.expected {
			t.Errorf("ShortID(%q) = %q, want %q", c.input, got, c.expected)
		}
	}
}

func TestEdgeCaseEmptyRecall(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// Recall on empty DB should return empty, not error
	result, err := eng.Recall(context.Background(), engine.RecallOpts{Query: "nonexistent", Limit: 5})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Nodes) != 0 {
		t.Errorf("empty recall: expected 0 nodes, got %d", len(result.Nodes))
	}
}

func TestEdgeCaseContextEmpty(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// Context on empty DB should return empty, not error
	result, err := eng.Context(context.Background(), "")
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Error("context: should return empty result, not nil")
	}
}

func TestEdgeCaseForgetNonexistent(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// Forget nonexistent node should error gracefully
	err := eng.Forget(context.Background(), "nonexistent-id-12345678")
	if err == nil {
		t.Error("forget: should error on nonexistent node")
	}
}

func TestProfileMerge(t *testing.T) {
	a := &profile.Profile{
		Project: "test",
		Static:  []string{"Use jose", "Use NATS"},
		Dynamic: []string{"[task] rate limiting"},
		Stack:   []string{"TypeScript", "NATS"},
	}
	b := &profile.Profile{
		Static:  []string{"Prefer tabs", "Use jose"}, // "Use jose" is duplicate
		Dynamic: []string{"[bug] auth race"},
		Stack:   []string{"PostgreSQL", "NATS"}, // "NATS" is duplicate
	}
	merged := profile.Merge(a, b)
	// Static should be deduped
	if len(merged.Static) != 3 { // jose, NATS, tabs
		t.Errorf("merge: expected 3 static, got %d: %v", len(merged.Static), merged.Static)
	}
	// Stack should be deduped
	if len(merged.Stack) != 3 { // TypeScript, NATS, PostgreSQL
		t.Errorf("merge: expected 3 stack, got %d: %v", len(merged.Stack), merged.Stack)
	}
	// Dynamic should be combined (not deduped)
	if len(merged.Dynamic) != 2 {
		t.Errorf("merge: expected 2 dynamic, got %d", len(merged.Dynamic))
	}
}

func TestMultipleRememberAndRecall(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// Store 20 memories of different types
	types := []string{"convention", "decision", "bug", "spec", "task"}
	for i := 0; i < 20; i++ {
		eng.Remember(context.Background(), engine.RememberInput{
			Type:    types[i%len(types)],
			Content: fmt.Sprintf("Memory item %d about topic %d", i, i%5),
			Scope:   "project",
		})
	}

	// Recall should find results
	result, err := eng.Recall(context.Background(), engine.RecallOpts{Query: "topic", Limit: 10})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Nodes) == 0 {
		t.Error("bulk recall: expected nodes")
	}
	t.Logf("Stored 20, recalled %d nodes", len(result.Nodes))

	// Status should show correct counts
	st, _ := eng.Status(context.Background(), "")
	if st.Nodes < 20 {
		t.Errorf("status: expected ≥20 nodes, got %d", st.Nodes)
	}
}

func TestTLSCertGeneration(t *testing.T) {
	dir := t.TempDir()
	cfg := harriertls.Config{Enabled: true}

	tlsCfg, err := harriertls.TLSConfig(cfg, dir)
	if err != nil {
		t.Fatal(err)
	}
	if tlsCfg == nil {
		t.Fatal("tls: nil config returned")
	}
	if len(tlsCfg.Certificates) == 0 {
		t.Error("tls: no certificates generated")
	}

	// Verify cert files were created
	if _, err := os.Stat(filepath.Join(dir, "cert.pem")); err != nil {
		t.Error("tls: cert.pem not created")
	}
	if _, err := os.Stat(filepath.Join(dir, "key.pem")); err != nil {
		t.Error("tls: key.pem not created")
	}
}

func TestConfigDefaults(t *testing.T) {
	cfg := config.Default()
	if cfg.Server.Port != 3456 {
		t.Errorf("config: expected port 3456, got %d", cfg.Server.Port)
	}
	if cfg.Decay.HalfLifeDays != 30 {
		t.Errorf("config: expected half_life 30, got %d", cfg.Decay.HalfLifeDays)
	}
}

func TestStorageCreateAndQuery(t *testing.T) {
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer func() { store.Close() }()

	ctx := context.Background()

	// Create node
	node := &storage.Node{
		ID: "test-node-1", Type: "convention", Content: "Test content",
		ContentHash: "hash1", Scope: "project", Tier: 1, Confidence: 1.0, Version: 1,
	}
	if err := store.CreateNode(ctx, node); err != nil {
		t.Fatal(err)
	}

	// Get node
	got, err := store.GetNode(ctx, "test-node-1")
	if err != nil {
		t.Fatal(err)
	}
	if got.Content != "Test content" {
		t.Errorf("storage: expected 'Test content', got '%s'", got.Content)
	}

	// Create edge
	edge := &storage.Edge{
		ID: "test-edge-1", FromID: "test-node-1", ToID: "test-node-1",
		Type: "relates_to", Acyclic: false, Weight: 1.0,
	}
	if err := store.CreateEdge(ctx, edge); err != nil {
		t.Fatal(err)
	}

	// Get neighbors
	neighbors, err := store.GetNeighbors(ctx, "test-node-1")
	if err != nil {
		t.Fatal(err)
	}
	if len(neighbors) == 0 {
		t.Error("storage: expected neighbors")
	}

	// Version history
	if err := store.SaveVersion(ctx, "test-node-1", "old content", "test", "test update"); err != nil {
		t.Fatal(err)
	}
	versions, err := store.GetVersions(ctx, "test-node-1")
	if err != nil {
		t.Fatal(err)
	}
	if len(versions) == 0 {
		t.Error("storage: expected version history")
	}
}

func TestRESTAPI(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	mux := http.NewServeMux()
	rest := server.NewRESTServer(eng, "")
	rest.RegisterRoutes(mux)
	ts := httptest.NewServer(mux)
	defer ts.Close()

	// POST /harrier/remember
	body, _ := json.Marshal(engine.RememberInput{
		Type: "convention", Content: "Always use TypeScript strict mode", Scope: "project",
	})
	resp, err := http.Post(ts.URL+"/harrier/remember", "application/json", bytes.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 201 {
		t.Errorf("remember: expected 201, got %d", resp.StatusCode)
	}
	var node storage.Node
	json.NewDecoder(resp.Body).Decode(&node)
	resp.Body.Close()
	if node.ID == "" {
		t.Error("remember: empty node ID")
	}

	// POST /harrier/recall
	body, _ = json.Marshal(engine.RecallOpts{Query: "TypeScript", Limit: 5})
	resp, err = http.Post(ts.URL+"/harrier/recall", "application/json", bytes.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != 200 {
		t.Errorf("recall: expected 200, got %d", resp.StatusCode)
	}
	var result engine.RecallResult
	json.NewDecoder(resp.Body).Decode(&result)
	resp.Body.Close()
	if len(result.Nodes) == 0 {
		t.Error("recall: expected nodes, got none")
	}

	// GET /harrier/health
	resp, _ = http.Get(ts.URL + "/harrier/health")
	if resp.StatusCode != 200 {
		t.Errorf("health: expected 200, got %d", resp.StatusCode)
	}
	resp.Body.Close()

	// GET /harrier/context
	resp, _ = http.Get(ts.URL + "/harrier/context")
	if resp.StatusCode != 200 {
		t.Errorf("context: expected 200, got %d", resp.StatusCode)
	}
	resp.Body.Close()
}

// TestConcurrentSQLiteAccess verifies that concurrent Remember and Recall operations
// against the real SQLite backend do not race or corrupt data.
func TestConcurrentSQLiteAccess(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	var wg sync.WaitGroup
	numWriters := 5
	numReaders := 5
	opsPerGoroutine := 10

	// Writers
	for i := 0; i < numWriters; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			for j := 0; j < opsPerGoroutine; j++ {
				_, err := eng.Remember(context.Background(), engine.RememberInput{
					Type:    "convention",
					Content: fmt.Sprintf("writer-%d-op-%d", idx, j),
					Scope:   "project",
					Project: "concurrent-test",
				})
				if err != nil {
					// Under CI load, occasional SQLITE_BUSY is expected even with
					// _busy_timeout. Skip individual operations rather than failing.
					if strings.Contains(err.Error(), "database is locked") {
						time.Sleep(10 * time.Millisecond)
						continue
					}
					t.Errorf("writer %d op %d failed: %v", idx, j, err)
				}
			}
		}(i)
	}

	// Readers
	for i := 0; i < numReaders; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			for j := 0; j < opsPerGoroutine; j++ {
				_, err := eng.Recall(context.Background(), engine.RecallOpts{
					Query:   "writer",
					Project: "concurrent-test",
					Limit:   10,
				})
				if err != nil {
					t.Errorf("reader %d op %d failed: %v", idx, j, err)
				}
			}
		}(i)
	}

	wg.Wait()

	st, err := eng.Status(context.Background(), "concurrent-test")
	if err != nil {
		t.Fatalf("status failed: %v", err)
	}
	expectedNodes := numWriters * opsPerGoroutine
	if st.Nodes < expectedNodes {
		t.Errorf("expected at least %d nodes, got %d", expectedNodes, st.Nodes)
	}
}
