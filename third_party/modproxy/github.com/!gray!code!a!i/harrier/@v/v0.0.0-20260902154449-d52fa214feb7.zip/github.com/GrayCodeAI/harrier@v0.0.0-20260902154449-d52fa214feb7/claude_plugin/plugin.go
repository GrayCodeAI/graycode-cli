// Package claudeplugin implements the Claude Code plugin pattern for harrier.
//
// This package provides session capture and sync integration between
// Claude Code (Anthropic's agent) and harrier's persistent memory engine.
// It follows the cognee Claude Code plugin pattern:
//
//  1. Session capture: intercepts Claude Code's conversation turns and
//     stores them as structured memory entries (QAEntry, TraceEntry)
//  2. Session sync: at session end, syncs session-scoped memories to
//     the permanent graph via SyncSessionToPermanent
//  3. Memory injection: at session start, retrieves relevant memories
//     from the permanent graph for context injection
//
// The plugin is designed to be embedded in a Claude Code extension or
// MCP server that wraps Claude Code's tool execution.
package claudeplugin

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
)

// PluginConfig configures the Claude Code plugin.
type PluginConfig struct {
	// ProjectPath is the project directory being worked on.
	ProjectPath string

	// SessionID is the Claude Code session identifier.
	// If empty, a new session ID is generated.
	SessionID string

	// AutoSync determines whether to automatically sync session
	// memories to the permanent graph at session end.
	// Default: true
	AutoSync bool

	// CaptureQA determines whether to store Q&A turns as QAEntry nodes.
	// Default: true
	CaptureQA bool

	// CaptureTrace determines whether to store tool/function calls
	// as TraceEntry nodes.
	// Default: true
	CaptureTrace bool

	// MemoryProject is the project name used for memory storage.
	// If empty, defaults to the project directory basename.
	MemoryProject string

	// SourceAgent is the agent identifier for stored memories.
	// Default: "claude-code"
	SourceAgent string
}

// Plugin implements the Claude Code plugin pattern for harrier.
type Plugin struct {
	eng  *engine.Engine
	cfg  PluginConfig
	sess *SessionCapture
}

// New creates a new Claude Code plugin instance.
func New(eng *engine.Engine, cfg PluginConfig) *Plugin {
	if cfg.SessionID == "" {
		cfg.SessionID = generateSessionID()
	}
	if cfg.MemoryProject == "" {
		cfg.MemoryProject = filepath.Base(cfg.ProjectPath)
	}
	if cfg.SourceAgent == "" {
		cfg.SourceAgent = "claude-code"
	}
	if !cfg.AutoSync {
		cfg.AutoSync = true
	}
	if !cfg.CaptureQA {
		cfg.CaptureQA = true
	}
	if !cfg.CaptureTrace {
		cfg.CaptureTrace = true
	}

	return &Plugin{
		eng:  eng,
		cfg:  cfg,
		sess: NewSessionCapture(cfg.SessionID, cfg.MemoryProject, cfg.SourceAgent),
	}
}

// SessionCapture tracks the current Claude Code session's interactions.
type SessionCapture struct {
	sessionID   string
	project     string
	sourceAgent string
	startTime   time.Time
	turns       []Turn
}

// Turn represents a single Q&A turn in a Claude Code session.
type Turn struct {
	Question  string     `json:"question"`
	Answer    string     `json:"answer"`
	ToolCalls []ToolCall `json:"tool_calls,omitempty"`
	Timestamp time.Time  `json:"timestamp"`
}

// ToolCall represents a tool invocation in a Claude Code session.
type ToolCall struct {
	Name       string `json:"name"`
	Input      string `json:"input,omitempty"`
	Output     string `json:"output,omitempty"`
	Status     string `json:"status"` // "success" | "error"
	DurationMs int64  `json:"duration_ms,omitempty"`
}

// NewSessionCapture creates a new session capture tracker.
func NewSessionCapture(sessionID, project, sourceAgent string) *SessionCapture {
	return &SessionCapture{
		sessionID:   sessionID,
		project:     project,
		sourceAgent: sourceAgent,
		startTime:   time.Now(),
	}
}

// CaptureTurn records a Q&A turn from the Claude Code session.
// If CaptureQA is enabled, it stores the turn as a QAEntry node.
func (p *Plugin) CaptureTurn(ctx context.Context, question, answer string) error {
	if !p.cfg.CaptureQA {
		return nil
	}

	turn := Turn{
		Question:  question,
		Answer:    answer,
		Timestamp: time.Now(),
	}
	p.sess.turns = append(p.sess.turns, turn)

	qa := engine.QAEntry{
		Question:    question,
		Answer:      answer,
		Project:     p.cfg.MemoryProject,
		SessionID:   p.cfg.SessionID,
		SourceAgent: p.cfg.SourceAgent,
	}

	_, err := p.eng.RememberWithSession(ctx, engine.RememberInput{
		Type:    string(engine.EntryQA),
		Content: question + "\n---\n" + answer,
		Summary: question,
		Scope:   "project",
		Project: qa.Project,
		Session: qa.SessionID,
		Agent:   qa.SourceAgent,
		Tags:    "qa,claude-code",
	}, p.cfg.SessionID)
	return err
}

// CaptureToolCall records a tool invocation from the Claude Code session.
// If CaptureTrace is enabled, it stores the call as a TraceEntry node.
func (p *Plugin) CaptureToolCall(ctx context.Context, tc ToolCall) error {
	if !p.cfg.CaptureTrace {
		return nil
	}

	te := engine.TraceEntry{
		OriginFunction:    tc.Name,
		Status:            tc.Status,
		MethodParams:      tc.Input,
		MethodReturnValue: tc.Output,
		Project:           p.cfg.MemoryProject,
		SessionID:         p.cfg.SessionID,
		SourceAgent:       p.cfg.SourceAgent,
	}

	_, err := p.eng.RememberWithSession(ctx, engine.RememberInput{
		Type:    string(engine.EntryTrace),
		Content: tc.Name,
		Summary: tc.Name,
		Scope:   "project",
		Project: te.Project,
		Session: te.SessionID,
		Agent:   te.SourceAgent,
		Tags:    "trace,claude-code",
	}, p.cfg.SessionID)
	return err
}

// InjectMemory retrieves relevant memories from the permanent graph
// for context injection at session start.
func (p *Plugin) InjectMemory(ctx context.Context, query string, limit int) (string, error) {
	result, err := p.eng.RecallWithSession(ctx, engine.RecallOpts{
		Query:   query,
		Project: p.cfg.MemoryProject,
		Limit:   limit,
	}, p.cfg.SessionID)
	if err != nil {
		return "", fmt.Errorf("inject memory: %w", err)
	}
	return engine.FormatContext(result.Nodes), nil
}

// EndSession syncs session-scoped memories to the permanent graph.
// This should be called when the Claude Code session ends.
func (p *Plugin) EndSession(ctx context.Context) (int, error) {
	if !p.cfg.AutoSync {
		return 0, nil
	}
	return p.eng.SyncSessionToPermanent(ctx, p.cfg.SessionID)
}

// SessionInfo returns metadata about the current session.
func (p *Plugin) SessionInfo() map[string]any {
	return map[string]any{
		"session_id":     p.cfg.SessionID,
		"project":        p.cfg.MemoryProject,
		"source_agent":   p.cfg.SourceAgent,
		"start_time":     p.sess.startTime.Format(time.RFC3339),
		"turns_captured": len(p.sess.turns),
		"duration":       time.Since(p.sess.startTime).String(),
	}
}

// generateSessionID creates a unique session ID.
func generateSessionID() string {
	return fmt.Sprintf("claude-%d", time.Now().UnixNano())
}

// SaveSessionLog writes the session capture log to a file.
func (p *Plugin) SaveSessionLog(dir string) error {
	if dir == "" {
		dir = os.TempDir()
	}
	path := filepath.Join(dir, p.cfg.SessionID+".json")
	log := map[string]interface{}{
		"session_id": p.cfg.SessionID,
		"project":    p.cfg.MemoryProject,
		"turns":      len(p.sess.turns),
	}
	data, err := json.Marshal(log)
	if err != nil {
		return fmt.Errorf("marshal session log: %w", err)
	}
	return os.WriteFile(path, data, 0o644)
}
