package engine

import (
	"context"
	"fmt"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// RuleInput stores a rule file as a harrier convention node with glob metadata.
type RuleInput struct {
	Path        string   // file path of the rule file
	Content     string   // markdown content (body, without frontmatter)
	Description string   // from frontmatter
	Globs       []string // glob patterns from frontmatter
	AlwaysApply bool     // from frontmatter
	Project     string   // project scope
}

// RememberRule stores a rule file as a harrier convention node.
// Uses keyed upsert (Key: "rule:<path>") so re-reading the same file updates rather than duplicates.
// Globs are stored in Tags for searchability.
func (e *Engine) RememberRule(ctx context.Context, input RuleInput) (*storage.Node, error) {
	// Build tags: include globs as tags for searchability (comma-separated string)
	tagParts := make([]string, 0, len(input.Globs)+1)
	tagParts = append(tagParts, "rule")
	for _, g := range input.Globs {
		tagParts = append(tagParts, "glob:"+g)
	}
	tags := strings.Join(tagParts, ",")

	// Build content with metadata
	content := input.Content
	if input.Description != "" {
		content = fmt.Sprintf("Description: %s\n\n%s", input.Description, content)
	}
	if len(input.Globs) > 0 {
		content += "\n\nGlobs:"
		for _, g := range input.Globs {
			content += "\n  - " + g
		}
	}

	ri := RememberInput{
		Type:    "convention",
		Content: content,
		Scope:   "project",
		Project: input.Project,
		Tier:    1, // rules are hot-tier
		Tags:    tags,
		Key:     "rule:" + input.Path,
	}
	return e.Remember(ctx, ri)
}
