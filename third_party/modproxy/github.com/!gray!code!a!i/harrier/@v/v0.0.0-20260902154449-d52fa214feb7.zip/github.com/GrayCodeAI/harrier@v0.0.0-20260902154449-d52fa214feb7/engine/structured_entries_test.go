package engine

import (
	"context"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// TestQAEntryRoundTrip verifies that a QAEntry can be stored and retrieved
// as a structured memory node with all fields preserved.
func TestQAEntryRoundTrip(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	qa := QAEntry{
		Question:      "What is the capital of France?",
		Answer:        "Paris is the capital of France.",
		Context:       "Geography quiz",
		Project:       "test-project",
		SessionID:     "test-session",
		SourceAgent:   "test-agent",
		FeedbackText:  "Good answer",
		FeedbackScore: intPtr(5),
		UsedGraphIDs:  []string{"node1", "node2"},
	}

	node, err := eng.RememberQA(ctx, qa)
	if err != nil {
		t.Fatalf("RememberQA failed: %v", err)
	}
	if node == nil {
		t.Fatal("expected non-nil node")
	}
	if node.Type != string(EntryQA) {
		t.Errorf("expected type %q, got %q", EntryQA, node.Type)
	}
	if node.Metadata["entry_type"] != string(EntryQA) {
		t.Errorf("expected entry_type %q, got %q", EntryQA, node.Metadata["entry_type"])
	}
	if node.Metadata["question"] != qa.Question {
		t.Errorf("expected question %q, got %q", qa.Question, node.Metadata["question"])
	}
	if node.Metadata["answer"] != qa.Answer {
		t.Errorf("expected answer %q, got %q", qa.Answer, node.Metadata["answer"])
	}
	if node.Metadata["feedback_text"] != qa.FeedbackText {
		t.Errorf("expected feedback_text %q, got %q", qa.FeedbackText, node.Metadata["feedback_text"])
	}
	if node.Metadata["feedback_score"] != "5" {
		t.Errorf("expected feedback_score '5', got %q", node.Metadata["feedback_score"])
	}
}

// TestQAEntryValidation verifies that RememberQA rejects empty question/answer.
func TestQAEntryValidation(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	_, err := eng.RememberQA(ctx, QAEntry{
		Answer:  "some answer",
		Project: "test",
	})
	if err == nil {
		t.Error("expected error for empty question")
	}

	_, err = eng.RememberQA(ctx, QAEntry{
		Question: "some question",
		Project:  "test",
	})
	if err == nil {
		t.Error("expected error for empty answer")
	}
}

// TestTraceEntryStorage verifies that a TraceEntry is stored with all fields.
func TestTraceEntryStorage(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	te := TraceEntry{
		OriginFunction:    "search_codebase",
		Status:            "success",
		MethodParams:      `{"query": "test"}`,
		MethodReturnValue: "found 3 results",
		Project:           "test-project",
		SessionID:         "test-session",
		SourceAgent:       "test-agent",
	}

	node, err := eng.RememberTrace(ctx, te)
	if err != nil {
		t.Fatalf("RememberTrace failed: %v", err)
	}
	if node == nil {
		t.Fatal("expected non-nil node")
	}
	if node.Metadata["origin_function"] != "search_codebase" {
		t.Errorf("expected origin_function 'search_codebase', got %q", node.Metadata["origin_function"])
	}
	if node.Metadata["status"] != "success" {
		t.Errorf("expected status 'success', got %q", node.Metadata["status"])
	}
}

// TestTraceEntryValidation verifies that RememberTrace rejects empty origin_function.
func TestTraceEntryValidation(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	_, err := eng.RememberTrace(ctx, TraceEntry{
		Status:  "success",
		Project: "test",
	})
	if err == nil {
		t.Error("expected error for empty origin_function")
	}
}

// TestFeedbackEntryStorage verifies that a FeedbackEntry updates the target QA node.
func TestFeedbackEntryStorage(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	// First, create a QA entry
	qa := QAEntry{
		Question: "What is Go?",
		Answer:   "Go is a programming language.",
		Project:  "test-project",
	}
	qaNode, err := eng.RememberQA(ctx, qa)
	if err != nil {
		t.Fatalf("RememberQA failed: %v", err)
	}

	// Now add feedback
	fe := FeedbackEntry{
		TargetNodeID: qaNode.ID,
		FeedbackText: "This was helpful",
		Score:        intPtr(4),
		Project:      "test-project",
	}
	fbNode, err := eng.RememberFeedback(ctx, fe)
	if err != nil {
		t.Fatalf("RememberFeedback failed: %v", err)
	}
	if fbNode == nil {
		t.Fatal("expected non-nil node")
	}

	// Verify the QA node was updated
	updatedQA, err := eng.Store().GetNode(ctx, qaNode.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	if updatedQA.Metadata["feedback_text"] != "This was helpful" {
		t.Errorf("expected feedback_text 'This was helpful', got %q", updatedQA.Metadata["feedback_text"])
	}
	if updatedQA.Metadata["feedback_score"] != "4" {
		t.Errorf("expected feedback_score '4', got %q", updatedQA.Metadata["feedback_score"])
	}
}

// TestSkillRunEntryStorage verifies that a SkillRunEntry is stored correctly.
func TestSkillRunEntryStorage(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	sr := SkillRunEntry{
		SkillName:    "code-review",
		SkillVersion: "1.0",
		Params:       `{"file": "main.go"}`,
		Result:       "Reviewed 5 files",
		Status:       "success",
		DurationMs:   1500,
		Project:      "test-project",
	}

	node, err := eng.RememberSkillRun(ctx, sr)
	if err != nil {
		t.Fatalf("RememberSkillRun failed: %v", err)
	}
	if node == nil {
		t.Fatal("expected non-nil node")
	}
	if node.Metadata["skill_name"] != "code-review" {
		t.Errorf("expected skill_name 'code-review', got %q", node.Metadata["skill_name"])
	}
	if node.Metadata["status"] != "success" {
		t.Errorf("expected status 'success', got %q", node.Metadata["status"])
	}
	if node.Metadata["duration_ms"] != "1500" {
		t.Errorf("expected duration_ms '1500', got %q", node.Metadata["duration_ms"])
	}
}

// TestSkillRunEntryValidation verifies that RememberSkillRun rejects empty skill_name.
func TestSkillRunEntryValidation(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	_, err := eng.RememberSkillRun(ctx, SkillRunEntry{
		Status:  "success",
		Project: "test",
	})
	if err == nil {
		t.Error("expected error for empty skill_name")
	}
}

// TestImprove verifies that the Improve operation runs without errors
// and returns a result with the expected fields.
func TestImprove(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	// Store a node to improve
	_, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "Always write tests",
		Project: "test-project",
	})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	result, err := eng.Improve(ctx, ImproveOpts{
		Project:               "test-project",
		RegenerateSummaries:   true,
		ConsolidateDuplicates: true,
		Limit:                 100,
	})
	if err != nil {
		t.Fatalf("Improve failed: %v", err)
	}
	if result.NodesProcessed < 1 {
		t.Errorf("expected at least 1 node processed, got %d", result.NodesProcessed)
	}
}

// TestSessionTierCache verifies that the SessionTier cache stores and retrieves nodes.
func TestSessionTierCache(t *testing.T) {
	t.Parallel()
	st := NewSessionTier()

	node := &storage.Node{
		ID:            "test-node",
		Type:          "convention",
		Content:       "test content",
		SourceSession: "session-1",
	}

	st.Put(node)

	retrieved, ok := st.Get("test-node")
	if !ok {
		t.Fatal("expected to find node in session cache")
	}
	if retrieved.ID != "test-node" {
		t.Errorf("expected ID 'test-node', got %q", retrieved.ID)
	}

	// Test List
	nodes := st.List("session-1")
	if len(nodes) != 1 {
		t.Errorf("expected 1 node for session-1, got %d", len(nodes))
	}

	// Test Clear
	cleared := st.Clear("session-1")
	if cleared != 1 {
		t.Errorf("expected 1 node cleared, got %d", cleared)
	}

	// Verify it's gone
	_, ok = st.Get("test-node")
	if ok {
		t.Error("expected node to be cleared from session cache")
	}
}

// TestSessionTierMultipleSessions verifies that the SessionTier correctly
// separates nodes by session.
func TestSessionTierMultipleSessions(t *testing.T) {
	t.Parallel()
	st := NewSessionTier()

	st.Put(&storage.Node{ID: "node-1", SourceSession: "session-a"})
	st.Put(&storage.Node{ID: "node-2", SourceSession: "session-b"})
	st.Put(&storage.Node{ID: "node-3", SourceSession: "session-a"})

	aNodes := st.List("session-a")
	if len(aNodes) != 2 {
		t.Errorf("expected 2 nodes for session-a, got %d", len(aNodes))
	}

	bNodes := st.List("session-b")
	if len(bNodes) != 1 {
		t.Errorf("expected 1 node for session-b, got %d", len(bNodes))
	}
}

// TestRecallWithSession verifies that RecallWithSession falls through to
// the permanent graph when the session cache is empty.
func TestRecallWithSession(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	// Store a node in the permanent graph
	_, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "Always use context.Context",
		Project: "test-project",
	})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// Recall with session should find it via fallthrough
	result, err := eng.RecallWithSession(ctx, RecallOpts{
		Query:   "context",
		Project: "test-project",
		Limit:   10,
	}, "test-session")
	if err != nil {
		t.Fatalf("RecallWithSession failed: %v", err)
	}
	if len(result.Nodes) < 1 {
		t.Error("expected at least 1 result from permanent graph")
	}
}

// TestSyncSessionToPermanent verifies that session nodes are promoted to
// permanent status (SourceSession cleared).
func TestSyncSessionToPermanent(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx := context.Background()

	// Store a node with a session ID
	node, err := eng.RememberWithSession(ctx, RememberInput{
		Type:    "convention",
		Content: "Session memory",
		Project: "test-project",
	}, "test-session")
	if err != nil {
		t.Fatalf("RememberWithSession failed: %v", err)
	}
	if node.SourceSession != "test-session" {
		t.Errorf("expected SourceSession 'test-session', got %q", node.SourceSession)
	}

	// Sync to permanent
	promoted, err := eng.SyncSessionToPermanent(ctx, "test-session")
	if err != nil {
		t.Fatalf("SyncSessionToPermanent failed: %v", err)
	}
	if promoted < 1 {
		t.Errorf("expected at least 1 promoted node, got %d", promoted)
	}

	// Verify the node no longer has a session ID
	updated, err := eng.Store().GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	if updated.SourceSession != "" {
		t.Errorf("expected empty SourceSession after sync, got %q", updated.SourceSession)
	}
}

// TestEntryTypeConstants verifies that entry type constants have correct values.
func TestEntryTypeConstants(t *testing.T) {
	t.Parallel()
	if EntryQA != "qa" {
		t.Errorf("expected EntryQA 'qa', got %q", EntryQA)
	}
	if EntryTrace != "trace" {
		t.Errorf("expected EntryTrace 'trace', got %q", EntryTrace)
	}
	if EntryFeedback != "feedback" {
		t.Errorf("expected EntryFeedback 'feedback', got %q", EntryFeedback)
	}
	if EntrySkillRun != "skill_run" {
		t.Errorf("expected EntrySkillRun 'skill_run', got %q", EntrySkillRun)
	}
}

// TestImproveOptsDefaults verifies that ImproveOpts has sensible zero values.
func TestImproveOptsDefaults(t *testing.T) {
	t.Parallel()
	opts := ImproveOpts{}
	if opts.Limit != 0 {
		t.Errorf("expected default Limit 0, got %d", opts.Limit)
	}
	if opts.MinConfidence != 0 {
		t.Errorf("expected default MinConfidence 0, got %f", opts.MinConfidence)
	}
}

// TestImproveResultFields verifies that ImproveResult has all expected fields.
func TestImproveResultFields(t *testing.T) {
	t.Parallel()
	result := ImproveResult{
		NodesProcessed:      10,
		NodesImproved:       5,
		SummariesGenerated:  3,
		EmbeddingsRefreshed: 2,
		DuplicatesMerged:    1,
		Errors:              0,
		Duration:            100 * time.Millisecond,
	}
	if result.NodesProcessed != 10 {
		t.Errorf("expected NodesProcessed 10, got %d", result.NodesProcessed)
	}
	if result.Duration != 100*time.Millisecond {
		t.Errorf("expected Duration 100ms, got %v", result.Duration)
	}
}

// TestMetadataToQA verifies the metadata deserialization helper.
func TestMetadataToQA(t *testing.T) {
	t.Parallel()
	meta := map[string]string{
		"entry_type":     "qa",
		"question":       "What is Go?",
		"answer":         "A language",
		"context":        "quiz",
		"feedback_text":  "good",
		"feedback_score": "5",
		"session_id":     "sess-1",
		"project":        "proj",
		"source_agent":   "agent",
	}

	qa, err := metadataToQA(meta)
	if err != nil {
		t.Fatalf("metadataToQA failed: %v", err)
	}
	if qa.Question != "What is Go?" {
		t.Errorf("expected question 'What is Go?', got %q", qa.Question)
	}
	if qa.Answer != "A language" {
		t.Errorf("expected answer 'A language', got %q", qa.Answer)
	}
	if qa.FeedbackScore == nil || *qa.FeedbackScore != 5 {
		t.Errorf("expected feedback_score 5, got %v", qa.FeedbackScore)
	}
}

// TestMetadataToQANil verifies that nil metadata returns an error.
func TestMetadataToQANil(t *testing.T) {
	t.Parallel()
	_, err := metadataToQA(nil)
	if err == nil {
		t.Error("expected error for nil metadata")
	}
}

// intPtr is a test helper that returns a pointer to an int.
func intPtr(v int) *int {
	return &v
}
