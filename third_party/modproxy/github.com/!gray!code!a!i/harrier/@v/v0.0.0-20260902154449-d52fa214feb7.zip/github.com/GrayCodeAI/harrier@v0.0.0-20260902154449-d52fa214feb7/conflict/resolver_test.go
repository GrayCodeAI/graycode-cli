package conflict

import (
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestIsContradiction_ExplicitSignal(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "Use jose library instead of jsonwebtoken for JWT validation",
		Type:       "convention",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "Use jsonwebtoken library for JWT validation in the auth service",
		Type:       "convention",
		Confidence: 1.0,
	}
	if !isContradiction(newNode, oldNode) {
		t.Error("expected contradiction: 'instead of' signal with shared terms")
	}
}

func TestIsContradiction_NoOverlap(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "Deploy using Docker containers",
		Type:       "decision",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "Use PostgreSQL for the main database",
		Type:       "decision",
		Confidence: 1.0,
	}
	if isContradiction(newNode, oldNode) {
		t.Error("no shared terms should not be a contradiction")
	}
}

func TestIsContradiction_SameDecisionUpdated(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "Authentication uses RS256 algorithm with rotating keys for token signing",
		Type:       "decision",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "Authentication uses HS256 algorithm with static secret for token signing",
		Type:       "decision",
		Confidence: 1.0,
	}
	if !isContradiction(newNode, oldNode) {
		t.Error("same-topic decisions with different content should be contradictions")
	}
}

func TestIsContradiction_LowOverlap(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "The server runs on port 8080",
		Type:       "spec",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "The database schema has 12 tables",
		Type:       "spec",
		Confidence: 1.0,
	}
	if isContradiction(newNode, oldNode) {
		t.Error("low overlap specs should not be contradictions")
	}
}

func TestExtractKeyTerms(t *testing.T) {
	t.Parallel()
	terms := extractKeyTerms("Use the jose library for JWT validation")
	if !terms["jose"] {
		t.Error("expected 'jose' in key terms")
	}
	if !terms["library"] {
		t.Error("expected 'library' in key terms")
	}
	if terms["the"] {
		t.Error("stop word 'the' should be excluded")
	}
	if terms["for"] {
		t.Error("stop word 'for' should be excluded")
	}
}

func TestIsStopWord(t *testing.T) {
	t.Parallel()
	if !isStopWord("the") {
		t.Error("'the' should be a stop word")
	}
	if isStopWord("database") {
		t.Error("'database' should not be a stop word")
	}
}

func TestIsContradiction_ContradictoryAdjectives(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "The authentication service is fast and stable",
		Type:       "decision",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "The authentication service is slow and unstable",
		Type:       "decision",
		Confidence: 1.0,
	}
	if !isContradiction(newNode, oldNode) {
		t.Error("expected contradiction: contradictory adjectives with shared terms")
	}
}

func TestIsContradiction_VerbPatterns(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		Content:    "Use React for the frontend components, prefer this framework",
		Type:       "decision",
		Confidence: 1.0,
	}
	oldNode := &storage.Node{
		Content:    "Avoid React for the frontend components, don't use this framework",
		Type:       "decision",
		Confidence: 1.0,
	}
	if !isContradiction(newNode, oldNode) {
		t.Error("expected contradiction: prefer vs avoid pattern")
	}
}

func TestDetectContradictionSignals(t *testing.T) {
	t.Parallel()
	signals := detectContradictionSignals(
		"Use jose instead of jsonwebtoken",
		"Use jsonwebtoken for JWT validation",
	)
	if len(signals) == 0 {
		t.Error("expected at least one contradiction signal")
	}

	found := false
	for _, s := range signals {
		if s == "explicit_replacement" {
			found = true
		}
	}
	if !found {
		t.Error("expected 'explicit_replacement' signal")
	}
}

func TestDetectContradictionSignals_Adjectives(t *testing.T) {
	t.Parallel()
	signals := detectContradictionSignals(
		"The API response is fast and correct",
		"The API response is slow and incorrect",
	)
	if len(signals) == 0 {
		t.Error("expected contradiction signal for opposing adjectives")
	}
}

func TestDetectContradictionSignals_NoSignals(t *testing.T) {
	t.Parallel()
	signals := detectContradictionSignals(
		"Use Docker for deployment",
		"Use PostgreSQL for the database",
	)
	if len(signals) != 0 {
		t.Errorf("expected no signals for unrelated content, got %v", signals)
	}
}

func TestHasNegationPattern(t *testing.T) {
	t.Parallel()
	if !hasNegationPattern("prefer TypeScript", "avoid TypeScript") {
		t.Error("expected negation pattern: prefer vs avoid")
	}
	if !hasNegationPattern("enable caching", "disable caching") {
		t.Error("expected negation pattern: enable vs disable")
	}
	if hasNegationPattern("use React", "use Vue") {
		t.Error("no negation pattern expected for different preferences")
	}
}

func TestAnalyzeContradiction(t *testing.T) {
	t.Parallel()
	newNode := &storage.Node{
		ID:         "new-1",
		Content:    "Use jose library instead of jsonwebtoken for JWT validation",
		Type:       "convention",
		Confidence: 1.0,
		CreatedAt:  time.Now(),
	}
	oldNode := &storage.Node{
		ID:         "old-1",
		Content:    "Use jsonwebtoken library for JWT validation",
		Type:       "convention",
		Confidence: 1.0,
		CreatedAt:  time.Now().Add(-24 * time.Hour),
	}
	detail := analyzeContradiction(newNode, oldNode)
	if detail == nil {
		t.Fatal("expected contradiction detail")
	}
	if detail.OldNodeID != "old-1" {
		t.Errorf("expected old-1, got %s", detail.OldNodeID)
	}
	if detail.Confidence < 0.5 {
		t.Errorf("expected confidence >= 0.5, got %f", detail.Confidence)
	}
	if len(detail.Signals) == 0 {
		t.Error("expected at least one signal")
	}
}
