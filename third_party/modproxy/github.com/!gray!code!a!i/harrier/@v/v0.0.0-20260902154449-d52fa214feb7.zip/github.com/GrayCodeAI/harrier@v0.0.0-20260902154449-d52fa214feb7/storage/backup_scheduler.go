package storage

import (
	"context"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// BackupScheduler produces periodic VACUUM INTO snapshots of the database
// into dir and rotates them with Store.RotateBackups. Start a scheduler
// once per store; Stop releases its goroutine. Schedulers are safe to run
// concurrently with reads and writes — VACUUM INTO takes a brief WAL read
// lock but does not block writers beyond it.
type BackupScheduler struct {
	store    *Store
	dir      string
	interval time.Duration
	keep     int
	maxAge   time.Duration

	mu       sync.Mutex // guards started/stopped
	started  bool
	stopped  bool
	stop     chan struct{}
	stoppedW chan struct{} // closed when the run loop returns

	statusMu      sync.Mutex // guards the fields below
	lastSuccessAt time.Time
	lastError     error
	lastErrorAt   time.Time
	snapshotCount int64
	snapshotFails int64
}

// BackupStatus reports the outcome of the scheduler's snapshots so callers
// (and health checks) can tell whether backups are actually succeeding.
type BackupStatus struct {
	LastSuccessAt time.Time // zero until the first successful snapshot
	LastError     error     // nil until the first failed snapshot
	LastErrorAt   time.Time // zero until the first failed snapshot
	Snapshots     int64     // successful snapshot count
	Failures      int64     // failed snapshot count
}

// Status returns the scheduler's snapshot history. Safe to call from any
// goroutine; also valid before Start (all counters zero).
func (b *BackupScheduler) Status() BackupStatus {
	b.statusMu.Lock()
	defer b.statusMu.Unlock()
	return BackupStatus{
		LastSuccessAt: b.lastSuccessAt,
		LastError:     b.lastError,
		LastErrorAt:   b.lastErrorAt,
		Snapshots:     b.snapshotCount,
		Failures:      b.snapshotFails,
	}
}

// recordResult updates the scheduler status for one snapshot attempt.
func (b *BackupScheduler) recordResult(err error) {
	b.statusMu.Lock()
	defer b.statusMu.Unlock()
	if err != nil {
		b.lastError = err
		b.lastErrorAt = time.Now().UTC()
		b.snapshotFails++
		return
	}
	b.lastError = nil
	b.lastSuccessAt = time.Now().UTC()
	b.snapshotCount++
}

// ScheduleBackups registers a scheduler that snapshots the store into dir
// every interval, keeping at most keep backups and pruning backups older
// than maxAge (0 = no age limit, 0 keep = no count limit). The directory is
// created on first use with owner-only permissions. The scheduler does not
// start until Start is called; RunNow takes an immediate snapshot.
//
// interval must be positive. A negative keep or maxAge is rejected.
func (s *Store) ScheduleBackups(dir string, interval time.Duration, keep int, maxAge time.Duration) (*BackupScheduler, error) {
	if interval <= 0 {
		return nil, fmt.Errorf("backup interval must be positive")
	}
	if keep < 0 || maxAge < 0 {
		return nil, fmt.Errorf("backup retention must not be negative")
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, fmt.Errorf("create backup directory: %w", err)
	}
	return &BackupScheduler{
		store:    s,
		dir:      dir,
		interval: interval,
		keep:     keep,
		maxAge:   maxAge,
		stop:     make(chan struct{}),
		stoppedW: make(chan struct{}),
	}, nil
}

// Start launches the periodic backup loop. Subsequent calls are no-ops.
func (b *BackupScheduler) Start() {
	b.mu.Lock()
	if b.started || b.stopped {
		b.mu.Unlock()
		return
	}
	b.started = true
	b.mu.Unlock()

	go b.run()
}

// Stop halts the scheduler and waits for the run loop to exit. If Start was
// never called, Stop simply marks the scheduler stopped. Safe to call
// multiple times.
func (b *BackupScheduler) Stop() {
	b.mu.Lock()
	if b.stopped {
		b.mu.Unlock()
		return
	}
	b.stopped = true
	done := b.stoppedW
	if b.started {
		close(b.stop)
	} else {
		done = nil // no run loop to drain
	}
	b.mu.Unlock()

	if done != nil {
		<-done
	}
}

// RunNow takes an immediate snapshot and rotates the directory. Names are
// UTC-timestamp based with a nano-second suffix so snapshots taken within
// the same second never collide (VACUUM INTO refuses existing targets).
// The outcome is recorded in Status().
func (b *BackupScheduler) RunNow(ctx context.Context) error {
	now := time.Now().UTC()
	name := filepath.Join(b.dir,
		fmt.Sprintf("harrier-%s-%d.db", now.Format("20060102T150405Z"), now.UnixNano()))
	if err := b.store.Backup(ctx, name); err != nil {
		b.recordResult(err)
		return err
	}
	if err := b.store.RotateBackups(ctx, b.dir, b.keep, b.maxAge); err != nil {
		b.recordResult(err)
		return err
	}
	b.recordResult(nil)
	return nil
}

// run takes an initial snapshot, then ticks every interval until Stop is
// called. Each snapshot is best-effort: a failed attempt is skipped rather
// than retry-looping; the next tick tries again. Failures are logged and
// recorded in Status() so silent backup death is observable.
func (b *BackupScheduler) run() {
	defer close(b.stoppedW)

	// Snapshot once immediately so a short-lived host still leaves a
	// backup behind; rotation prunes duplicates from frequent restarts.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	b.snapshot(ctx)
	cancel()

	ticker := time.NewTicker(b.interval)
	defer ticker.Stop()

	for {
		select {
		case <-b.stop:
			return
		case <-ticker.C:
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
			b.snapshot(ctx)
			cancel()
		}
	}
}

// snapshot runs one RunNow attempt, logging failures; RunNow records the
// outcome either way.
func (b *BackupScheduler) snapshot(ctx context.Context) {
	if err := b.RunNow(ctx); err != nil {
		slog.Warn("backup scheduler: snapshot failed", "dir", b.dir, "error", err)
	}
}
