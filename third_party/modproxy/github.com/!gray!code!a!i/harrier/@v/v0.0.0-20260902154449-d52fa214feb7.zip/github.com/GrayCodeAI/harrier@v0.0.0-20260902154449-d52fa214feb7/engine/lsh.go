package engine

import (
	"hash/fnv"
	"sync"
)

const (
	lshNumHash     = 128                      // number of MinHash permutations
	lshNumBands    = 16                       // number of bands for LSH
	lshRowsPerBand = lshNumHash / lshNumBands // 8 rows per band
)

// MinHashLSH implements Locality-Sensitive Hashing using MinHash with banding.
// Uses 128 MinHash permutations divided into 16 bands of 8 rows each.
// For a threshold of 0.85, this gives ~97% probability of being a candidate
// for true positives and ~0.01% for items below threshold.
type MinHashLSH struct {
	mu        sync.RWMutex
	threshold float64
	// Per-document MinHash signatures: id -> [128]uint64
	signatures map[string][]uint64
	// Band buckets: bandIndex -> bucketHash -> set of document IDs
	buckets [lshNumBands]map[uint64]map[string]bool
}

// NewMinHashLSH creates a MinHash LSH index with the given Jaccard similarity threshold.
// A threshold of 0.85 is standard for near-duplicate detection.
func NewMinHashLSH(threshold float64) *MinHashLSH {
	lsh := &MinHashLSH{
		threshold:  threshold,
		signatures: make(map[string][]uint64),
	}
	for i := range lsh.buckets {
		lsh.buckets[i] = make(map[uint64]map[string]bool)
	}
	return lsh
}

// Insert computes the MinHash signature for a set of terms and adds the ID
// to the appropriate band buckets.
func (lsh *MinHashLSH) Insert(id string, terms map[string]bool) {
	sig := lsh.minHashSignature(terms)

	lsh.mu.Lock()
	defer lsh.mu.Unlock()

	lsh.signatures[id] = sig

	// Insert into each band's bucket
	for band := 0; band < lshNumBands; band++ {
		bucketHash := lsh.bandHash(sig, band)
		bkt := lsh.buckets[band]
		if bkt[bucketHash] == nil {
			bkt[bucketHash] = make(map[string]bool)
		}
		bkt[bucketHash][id] = true
	}
}

// Query returns candidate IDs whose term sets are likely above the similarity threshold.
// The candidates may include false positives but will have very few false negatives.
func (lsh *MinHashLSH) Query(terms map[string]bool) []string {
	sig := lsh.minHashSignature(terms)

	lsh.mu.RLock()
	defer lsh.mu.RUnlock()

	seen := make(map[string]bool)
	for band := 0; band < lshNumBands; band++ {
		bucketHash := lsh.bandHash(sig, band)
		if ids, ok := lsh.buckets[band][bucketHash]; ok {
			for id := range ids {
				seen[id] = true
			}
		}
	}

	candidates := make([]string, 0, len(seen))
	for id := range seen {
		candidates = append(candidates, id)
	}
	return candidates
}

// minHashSignature computes 128 MinHash values for the given term set.
// Each permutation uses FNV-64a with a distinct seed derived from the
// golden ratio multiplier to ensure good distribution.
func (lsh *MinHashLSH) minHashSignature(terms map[string]bool) []uint64 {
	sig := make([]uint64, lshNumHash)
	// Initialize with max uint64 (we're taking minimum)
	for i := range sig {
		sig[i] = ^uint64(0)
	}

	for term := range terms {
		for i := 0; i < lshNumHash; i++ {
			h := lsh.hashTerm(term, i)
			if h < sig[i] {
				sig[i] = h
			}
		}
	}
	return sig
}

// hashTerm hashes a term with a permutation-specific seed using FNV-64a.
func (lsh *MinHashLSH) hashTerm(term string, perm int) uint64 {
	h := fnv.New64a()
	// Write permutation seed as 8 bytes
	seed := uint64(perm) * 0x9e3779b97f4a7c15 // #nosec G115 -- perm is a bounded non-negative loop index; hash-mixing conversion
	var buf [8]byte
	buf[0] = byte(seed)
	buf[1] = byte(seed >> 8)
	buf[2] = byte(seed >> 16)
	buf[3] = byte(seed >> 24)
	buf[4] = byte(seed >> 32)
	buf[5] = byte(seed >> 40)
	buf[6] = byte(seed >> 48)
	buf[7] = byte(seed >> 56)
	_, _ = h.Write(buf[:])       // #nosec G104 -- hash.Hash.Write never returns an error
	_, _ = h.Write([]byte(term)) // #nosec G104 -- hash.Hash.Write never returns an error
	return h.Sum64()
}

// bandHash hashes a band of MinHash values into a single bucket key.
func (lsh *MinHashLSH) bandHash(sig []uint64, band int) uint64 {
	start := band * lshRowsPerBand
	h := fnv.New64a()
	var buf [8]byte
	for i := 0; i < lshRowsPerBand; i++ {
		v := sig[start+i]
		buf[0] = byte(v)
		buf[1] = byte(v >> 8)
		buf[2] = byte(v >> 16)
		buf[3] = byte(v >> 24)
		buf[4] = byte(v >> 32)
		buf[5] = byte(v >> 40)
		buf[6] = byte(v >> 48)
		buf[7] = byte(v >> 56)
		_, _ = h.Write(buf[:]) // #nosec G104 -- hash.Hash.Write never returns an error
	}
	return h.Sum64()
}

// Size returns the number of indexed documents.
func (lsh *MinHashLSH) Size() int {
	lsh.mu.RLock()
	defer lsh.mu.RUnlock()
	return len(lsh.signatures)
}
