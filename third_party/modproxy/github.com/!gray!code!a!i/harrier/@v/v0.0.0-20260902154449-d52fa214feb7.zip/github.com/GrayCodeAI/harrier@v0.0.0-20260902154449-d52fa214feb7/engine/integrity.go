package engine

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"os/user"
	"path/filepath"

	"github.com/GrayCodeAI/harrier/storage"
)

// MemoryIntegrity provides HMAC-SHA256 signing and verification for memory nodes.
// Detects if memories were tampered with outside harrier (e.g., direct SQLite edits).
// The signing key is stored in .harrier/integrity.key (auto-generated on first use).
// The key is immutable after construction, so no mutex is needed.
type MemoryIntegrity struct {
	key []byte
}

// NewMemoryIntegrity creates an integrity checker, loading or generating the key.
// The raw key material is stored on disk, but the actual HMAC key is derived
// from it using HKDF-SHA256 with the machine's hostname and username as
// context. This binds the key to the originating machine so the on-disk bytes
// are not directly usable elsewhere.
func NewMemoryIntegrity(harrierDir string) (*MemoryIntegrity, error) {
	mi := &MemoryIntegrity{}

	keyPath := filepath.Join(harrierDir, "integrity.key")
	rawKey, err := os.ReadFile(keyPath) // #nosec G304 -- keyPath is joined from the caller-supplied harrierDir (the .harrier project data directory), a trusted internal path
	if err != nil {
		// Generate new key
		rawKey = make([]byte, 32)
		if _, err := rand.Read(rawKey); err != nil {
			return nil, fmt.Errorf("failed to generate integrity key: %w", err)
		}
		_ = os.MkdirAll(harrierDir, 0o700)
		if err := os.WriteFile(keyPath, rawKey, 0o600); err != nil {
			return nil, fmt.Errorf("failed to write integrity key: %w", err)
		}
	}

	// Derive the actual HMAC key from the raw material using machine identity
	// as additional context. This way the on-disk key alone is insufficient.
	derived, err := deriveMachineBoundKey(rawKey)
	if err != nil {
		return nil, fmt.Errorf("failed to derive integrity key: %w", err)
	}

	mi.key = derived
	return mi, nil
}

// deriveMachineBoundKey uses HKDF-SHA256 to derive a 32-byte key from the
// raw key material, using hostname + username as the info parameter. The
// resulting key is only valid on the machine where it was derived.
// Since we only need 32 bytes (one SHA-256 block), the expand step is a
// single HMAC computation: T(1) = HMAC-Hash(PRK, info || 0x01).
func deriveMachineBoundKey(rawKey []byte) ([]byte, error) {
	hostname, _ := os.Hostname()
	username := ""
	if u, err := user.Current(); err == nil {
		username = u.Username
	}
	info := []byte("harrier-integrity:" + hostname + ":" + username)

	// HKDF-Extract: PRK = HMAC-Hash(salt="", IKM=rawKey)
	prk := hmacSHA256(nil, rawKey)

	// HKDF-Expand (single block): T(1) = HMAC-Hash(PRK, info || 0x01)
	expandInput := make([]byte, len(info)+1)
	copy(expandInput, info)
	expandInput[len(info)] = 0x01
	derived := hmacSHA256(prk, expandInput)

	return derived, nil
}

func hmacSHA256(key, data []byte) []byte {
	mac := hmac.New(sha256.New, key)
	mac.Write(data)
	return mac.Sum(nil)
}

// Sign generates an HMAC-SHA256 signature for a memory node's content.
func (mi *MemoryIntegrity) Sign(node *storage.Node) string {
	payload := mi.buildPayload(node)
	mac := hmac.New(sha256.New, mi.key)
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}

// Verify checks if a node's content matches its expected signature.
func (mi *MemoryIntegrity) Verify(node *storage.Node, expectedSig string) bool {
	if expectedSig == "" {
		return true // unsigned nodes pass (backward compat)
	}

	actualSig := mi.computeSig(node)
	return hmac.Equal([]byte(actualSig), []byte(expectedSig))
}

// VerifyBatch checks multiple nodes and returns IDs of tampered ones.
func (mi *MemoryIntegrity) VerifyBatch(nodes []*storage.Node, signatures map[string]string) []string {
	var tampered []string
	for _, n := range nodes {
		sig, ok := signatures[n.ID]
		if !ok {
			continue // unsigned, skip
		}
		if !mi.Verify(n, sig) {
			tampered = append(tampered, n.ID)
		}
	}
	return tampered
}

func (mi *MemoryIntegrity) computeSig(node *storage.Node) string {
	payload := mi.buildPayload(node)
	mac := hmac.New(sha256.New, mi.key)
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}

func (mi *MemoryIntegrity) buildPayload(node *storage.Node) string {
	// Sign: ID + Type + Content + Scope + Project (immutable fields)
	// Use record separator (0x1E) to avoid collision with field content.
	const sep = "\x1e"
	return node.ID + sep + node.Type + sep + node.Content + sep + node.Scope + sep + node.Project
}
