package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/embeddings"
)

// fakeProvider returns caller-supplied vectors keyed by exact text, so tests can
// construct deterministic topic clusters independent of any real model.
type fakeProvider struct {
	vecs map[string][]float32
	dims int
}

func (f *fakeProvider) Embed(_ context.Context, text string) ([]float32, error) {
	if v, ok := f.vecs[text]; ok {
		return v, nil
	}
	// Unknown text → zero vector (cosine 0 against everything).
	return make([]float32, f.dims), nil
}

func (f *fakeProvider) EmbedBatch(ctx context.Context, texts []string) ([][]float32, error) {
	out := make([][]float32, len(texts))
	for i, t := range texts {
		out[i], _ = f.Embed(ctx, t)
	}
	return out, nil
}

func (f *fakeProvider) EmbedWithMode(ctx context.Context, text string, _ embeddings.EmbedMode) ([]float32, error) {
	return f.Embed(ctx, text)
}
func (f *fakeProvider) Dims() int    { return f.dims }
func (f *fakeProvider) Name() string { return "fake" }

func TestDetectBoundary_Lexical(t *testing.T) {
	t.Parallel()
	det := NewBoundaryDetector(nil, DefaultBoundaryConfig())
	tests := []struct {
		name     string
		prev     string
		next     string
		boundary bool
	}{
		{
			name:     "same topic high overlap",
			prev:     "the authentication service uses jwt tokens for sessions",
			next:     "jwt tokens for the authentication service expire after sessions end",
			boundary: false,
		},
		{
			name:     "clear topic shift",
			prev:     "the authentication service uses jwt tokens for sessions",
			next:     "lunch plans tomorrow involve pizza and sandwiches downtown",
			boundary: true,
		},
		{
			name:     "empty prev never boundary",
			prev:     "",
			next:     "anything goes here",
			boundary: false,
		},
		{
			name:     "empty next never boundary",
			prev:     "anything goes here",
			next:     "",
			boundary: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := det.DetectBoundary(tt.prev, tt.next)
			if got != tt.boundary {
				t.Errorf("DetectBoundary(%q, %q) = %v, want %v (sim=%.3f)",
					tt.prev, tt.next, got, tt.boundary, det.Similarity(tt.prev, tt.next))
			}
		})
	}
}

func TestDetectBoundary_Embedding(t *testing.T) {
	t.Parallel()
	// Two orthogonal-ish clusters: A vectors near (1,0,...), B near (0,1,...).
	prov := &fakeProvider{dims: 4, vecs: map[string][]float32{
		"a1": {1, 0, 0, 0},
		"a2": {0.96, 0.1, 0, 0},
		"b1": {0, 1, 0, 0},
	}}
	det := NewBoundaryDetector(prov, DefaultBoundaryConfig())

	if det.DetectBoundary("a1", "a2") {
		t.Errorf("a1→a2 same cluster should not be a boundary (sim=%.3f)", det.Similarity("a1", "a2"))
	}
	if !det.DetectBoundary("a1", "b1") {
		t.Errorf("a1→b1 different cluster should be a boundary (sim=%.3f)", det.Similarity("a1", "b1"))
	}
}

func TestTracker_Lexical(t *testing.T) {
	t.Parallel()
	tr := NewTracker(NewBoundaryDetector(nil, DefaultBoundaryConfig()))

	// Continuous same-topic stream: no boundaries after the baseline.
	stream := []string{
		"the database migration adds an index to the users table",
		"adding an index to the users table speeds up the database query",
		"the users table index makes database lookups much faster now",
	}
	for i, s := range stream {
		if got := tr.Observe(s); got {
			t.Errorf("same-topic observe[%d] flagged a boundary: %q", i, s)
		}
	}

	// Hard topic shift should be flagged.
	if !tr.Observe("weekend hiking trail recommendations near the mountain lake") {
		t.Error("clear topic shift was not flagged as a boundary")
	}
}

func TestTracker_Embedding(t *testing.T) {
	t.Parallel()
	prov := &fakeProvider{dims: 4, vecs: map[string][]float32{
		"a1": {1, 0, 0, 0},
		"a2": {0.98, 0.05, 0, 0},
		"a3": {0.95, 0.1, 0, 0},
		"b1": {0, 0, 1, 0},
	}}
	tr := NewTracker(NewBoundaryDetector(prov, DefaultBoundaryConfig()))

	for i, s := range []string{"a1", "a2", "a3"} {
		if got := tr.Observe(s); got {
			t.Errorf("same-cluster observe[%d]=%q flagged a boundary", i, s)
		}
	}
	if !tr.Observe("b1") {
		t.Error("cross-cluster observation b1 was not flagged as a boundary")
	}
}

func TestTracker_ResetAndEmptyInput(t *testing.T) {
	t.Parallel()
	tr := NewTracker(NewBoundaryDetector(nil, DefaultBoundaryConfig()))
	if tr.Observe("") {
		t.Error("empty content should never be a boundary")
	}
	if tr.Observe("first real topic about kubernetes pod scheduling") {
		t.Error("first observation must establish baseline, not flag a boundary")
	}
	tr.Reset()
	// After reset, the next observation is again a baseline.
	if tr.Observe("entirely different subject matter about cooking recipes") {
		t.Error("first observation after Reset must not be a boundary")
	}
}
