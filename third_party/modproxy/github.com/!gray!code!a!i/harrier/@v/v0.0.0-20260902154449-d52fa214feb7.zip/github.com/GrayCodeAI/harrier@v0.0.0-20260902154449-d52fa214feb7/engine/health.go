package engine

import (
	"context"
	"fmt"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// HealthStatus represents the overall system health.
type HealthStatus string

const (
	HealthHealthy   HealthStatus = "healthy"
	HealthDegraded  HealthStatus = "degraded"
	HealthUnhealthy HealthStatus = "unhealthy"
)

// HealthReport provides detailed system health information.
type HealthReport struct {
	Status     HealthStatus  `json:"status"`
	Uptime     time.Duration `json:"uptime"`
	Checks     []HealthCheck `json:"checks"`
	NodeCount  int           `json:"node_count"`
	EdgeCount  int           `json:"edge_count"`
	DBSize     int64         `json:"db_size_bytes"`
	CacheHits  int           `json:"cache_hits"`
	LastRecall time.Duration `json:"last_recall_latency"`
}

// HealthCheck is an individual health check result.
type HealthCheck struct {
	Name    string        `json:"name"`
	Status  HealthStatus  `json:"status"`
	Message string        `json:"message,omitempty"`
	Latency time.Duration `json:"latency"`
}

// HealthChecker runs diagnostic checks on the system.
type HealthChecker struct {
	store   storage.Storage
	started time.Time
}

// NewHealthChecker creates a health checker.
func NewHealthChecker(store storage.Storage) *HealthChecker {
	return &HealthChecker{store: store, started: time.Now()}
}

// Check runs all health checks and returns a report.
func (hc *HealthChecker) Check(ctx context.Context) *HealthReport {
	report := &HealthReport{
		Status: HealthHealthy,
		Uptime: time.Since(hc.started),
	}

	// Check 1: Database read
	dbCheck := hc.checkDB(ctx)
	report.Checks = append(report.Checks, dbCheck)

	// Check 2: FTS5 search
	ftsCheck := hc.checkFTS(ctx)
	report.Checks = append(report.Checks, ftsCheck)

	// Check 3: Node count
	countCheck := hc.checkNodeCount(ctx)
	report.Checks = append(report.Checks, countCheck.HealthCheck)
	report.NodeCount = countCheck.count

	// Check 4: Edge count
	edges, _ := hc.store.CountAllEdges(ctx)
	report.EdgeCount = edges

	// Determine overall status
	for _, c := range report.Checks {
		if c.Status == HealthUnhealthy {
			report.Status = HealthUnhealthy
			break
		}
		if c.Status == HealthDegraded && report.Status != HealthUnhealthy {
			report.Status = HealthDegraded
		}
	}

	return report
}

func (hc *HealthChecker) checkDB(ctx context.Context) HealthCheck {
	start := time.Now()
	_, err := hc.store.ListNodes(ctx, storage.NodeFilter{Limit: 1})
	latency := time.Since(start)

	if err != nil {
		return HealthCheck{Name: "database", Status: HealthUnhealthy, Message: err.Error(), Latency: latency}
	}
	if latency > 500*time.Millisecond {
		return HealthCheck{Name: "database", Status: HealthDegraded, Message: "slow response", Latency: latency}
	}
	return HealthCheck{Name: "database", Status: HealthHealthy, Latency: latency}
}

func (hc *HealthChecker) checkFTS(ctx context.Context) HealthCheck {
	start := time.Now()
	_, err := hc.store.SearchNodes(ctx, "test", 1)
	latency := time.Since(start)

	if err != nil {
		return HealthCheck{Name: "fts5_search", Status: HealthDegraded, Message: err.Error(), Latency: latency}
	}
	if latency > time.Second {
		return HealthCheck{Name: "fts5_search", Status: HealthDegraded, Message: "slow search", Latency: latency}
	}
	return HealthCheck{Name: "fts5_search", Status: HealthHealthy, Latency: latency}
}

type nodeCountCheck struct {
	HealthCheck
	count int
}

func (hc *HealthChecker) checkNodeCount(ctx context.Context) nodeCountCheck {
	start := time.Now()
	nodes, err := hc.store.ListNodes(ctx, storage.NodeFilter{Limit: 10001})
	latency := time.Since(start)

	check := nodeCountCheck{
		HealthCheck: HealthCheck{Name: "node_count", Status: HealthHealthy, Latency: latency},
		count:       len(nodes),
	}

	if err != nil {
		check.Status = HealthUnhealthy
		check.Message = err.Error()
		return check
	}

	if len(nodes) > 10000 {
		check.Status = HealthDegraded
		check.Message = fmt.Sprintf("%d nodes — consider running 'harrier sparsify'", len(nodes))
	}

	return check
}

// StartupSelfTest runs quick smoke tests to verify system integrity.
// Returns nil if all checks pass, error describing what's wrong otherwise.
func StartupSelfTest(ctx context.Context, store storage.Storage) error {
	// Test 1: Can we read from the database?
	_, err := store.ListNodes(ctx, storage.NodeFilter{Limit: 1})
	if err != nil {
		return fmt.Errorf("database read failed: %w", err)
	}

	// Test 2: Can we search?
	_, err = store.SearchNodes(ctx, "selftest", 1)
	if err != nil {
		return fmt.Errorf("FTS5 search failed: %w", err)
	}

	// Test 3: Can we count edges?
	_, err = store.CountAllEdges(ctx)
	if err != nil {
		return fmt.Errorf("edge count failed: %w", err)
	}

	return nil
}

// GracefulShutdown flushes all pending operations before closing.
func GracefulShutdown(e *Engine) {
	if e == nil {
		return
	}
	// Flush access tracker
	if e.access != nil {
		e.access.Stop()
		e.access.Flush(context.Background())
	}
	// Close store
	if e.store != nil {
		_ = e.store.Close()
	}
}
