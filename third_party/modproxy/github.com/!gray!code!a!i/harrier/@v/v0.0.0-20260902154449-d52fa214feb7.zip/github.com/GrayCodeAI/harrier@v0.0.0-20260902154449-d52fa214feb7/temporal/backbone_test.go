package temporal

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

func setupStore(t *testing.T) storage.Storage {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	return store
}

func createNode(t *testing.T, store storage.Storage, project string) *storage.Node {
	t.Helper()
	ctx := context.Background()
	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        "decision",
		Content:     "test node " + uuid.New().String()[:8],
		ContentHash: uuid.New().String(),
		Scope:       "project",
		Project:     project,
		Confidence:  0.8,
		Version:     1,
	}
	if err := store.CreateNode(ctx, node); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}
	return node
}

func TestNew(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	if b == nil {
		t.Fatal("expected non-nil Backbone")
	}
}

func TestLink_FirstNode(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	node := createNode(t, store, "proj1")
	err := b.Link(ctx, node.ID, "proj1")
	if err != nil {
		t.Fatalf("Link first node: %v", err)
	}

	// No edge expected for the first node (no predecessor)
	edges, _ := store.GetEdgesTo(ctx, node.ID)
	learnedIn := 0
	for _, e := range edges {
		if e.Type == "learned_in" {
			learnedIn++
		}
	}
	if learnedIn != 0 {
		t.Errorf("first node should have no inbound learned_in edges, got %d", learnedIn)
	}
}

func TestLink_ChainCreatesEdges(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	node1 := createNode(t, store, "proj1")
	node2 := createNode(t, store, "proj1")
	node3 := createNode(t, store, "proj1")

	if err := b.Link(ctx, node1.ID, "proj1"); err != nil {
		t.Fatalf("Link node1: %v", err)
	}
	if err := b.Link(ctx, node2.ID, "proj1"); err != nil {
		t.Fatalf("Link node2: %v", err)
	}
	if err := b.Link(ctx, node3.ID, "proj1"); err != nil {
		t.Fatalf("Link node3: %v", err)
	}

	// Verify edge from node1 → node2
	edges, _ := store.GetEdgesFrom(ctx, node1.ID)
	found12 := false
	for _, e := range edges {
		if e.ToID == node2.ID && e.Type == "learned_in" {
			found12 = true
		}
	}
	if !found12 {
		t.Error("expected learned_in edge from node1 to node2")
	}

	// Verify edge from node2 → node3
	edges, _ = store.GetEdgesFrom(ctx, node2.ID)
	found23 := false
	for _, e := range edges {
		if e.ToID == node3.ID && e.Type == "learned_in" {
			found23 = true
		}
	}
	if !found23 {
		t.Error("expected learned_in edge from node2 to node3")
	}
}

func TestLink_IndependentProjects(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	nodeA1 := createNode(t, store, "projA")
	nodeB1 := createNode(t, store, "projB")
	nodeA2 := createNode(t, store, "projA")

	_ = b.Link(ctx, nodeA1.ID, "projA")
	_ = b.Link(ctx, nodeB1.ID, "projB")
	_ = b.Link(ctx, nodeA2.ID, "projA")

	// Edge from nodeA1 → nodeA2 (same project)
	edges, _ := store.GetEdgesFrom(ctx, nodeA1.ID)
	found := false
	for _, e := range edges {
		if e.ToID == nodeA2.ID && e.Type == "learned_in" {
			found = true
		}
	}
	if !found {
		t.Error("expected temporal edge within projA")
	}

	// No edge from nodeA1 → nodeB1 (different projects)
	for _, e := range edges {
		if e.ToID == nodeB1.ID {
			t.Error("unexpected cross-project temporal edge")
		}
	}
}

func TestLink_CancelledContext(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	err := b.Link(ctx, "some-id", "proj1")
	if err == nil {
		t.Error("expected error from cancelled context")
	}
}

func TestTimeline_Forward(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	node1 := createNode(t, store, "proj1")
	node2 := createNode(t, store, "proj1")
	node3 := createNode(t, store, "proj1")

	_ = b.Link(ctx, node1.ID, "proj1")
	_ = b.Link(ctx, node2.ID, "proj1")
	_ = b.Link(ctx, node3.ID, "proj1")

	nodes, err := b.Timeline(ctx, node1.ID, "forward", 10)
	if err != nil {
		t.Fatalf("Timeline: %v", err)
	}
	if len(nodes) < 2 {
		t.Errorf("expected at least 2 nodes in forward timeline, got %d", len(nodes))
	}
	// First node should be node1
	if nodes[0].ID != node1.ID {
		t.Errorf("first timeline node should be node1, got %s", nodes[0].ID)
	}
}

func TestTimeline_Backward(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	node1 := createNode(t, store, "proj1")
	node2 := createNode(t, store, "proj1")
	node3 := createNode(t, store, "proj1")

	_ = b.Link(ctx, node1.ID, "proj1")
	_ = b.Link(ctx, node2.ID, "proj1")
	_ = b.Link(ctx, node3.ID, "proj1")

	nodes, err := b.Timeline(ctx, node3.ID, "backward", 10)
	if err != nil {
		t.Fatalf("Timeline backward: %v", err)
	}
	if len(nodes) < 2 {
		t.Errorf("expected at least 2 nodes in backward timeline, got %d", len(nodes))
	}
	if nodes[0].ID != node3.ID {
		t.Errorf("first backward timeline node should be node3, got %s", nodes[0].ID)
	}
}

func TestTimeline_NonexistentNode(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	nodes, err := b.Timeline(ctx, "nonexistent-id", "forward", 10)
	if err != nil {
		t.Fatalf("Timeline: %v", err)
	}
	if len(nodes) != 0 {
		t.Errorf("expected 0 nodes for nonexistent start, got %d", len(nodes))
	}
}

func TestTimeline_DefaultLimit(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	b := New(store)
	ctx := context.Background()

	node := createNode(t, store, "proj1")
	_ = b.Link(ctx, node.ID, "proj1")

	// limit 0 should default to 20
	nodes, err := b.Timeline(ctx, node.ID, "forward", 0)
	if err != nil {
		t.Fatalf("Timeline: %v", err)
	}
	// Should still return at least the start node
	if len(nodes) < 1 {
		t.Error("expected at least 1 node with default limit")
	}
}
