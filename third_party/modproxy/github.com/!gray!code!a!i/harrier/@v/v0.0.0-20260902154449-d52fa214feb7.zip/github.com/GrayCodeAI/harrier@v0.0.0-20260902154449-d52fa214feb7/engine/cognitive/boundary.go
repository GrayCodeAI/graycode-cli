// Package cognitive implements harrier's higher-level memory subsystems —
// epistemic state, curiosity, boundary detection, reconsolidation, and
// related processes layered on top of the core engine.
package cognitive

import (
	"math"
	"strings"
	"time"
)

// TopicBoundary represents a detected shift in conversation topic.
type TopicBoundary struct {
	Position    int       `json:"position"`     // message index where the shift occurs
	Score       float64   `json:"score"`        // confidence of the boundary (0.0-1.0)
	BeforeTopic string    `json:"before_topic"` // inferred topic before the boundary
	AfterTopic  string    `json:"after_topic"`  // inferred topic after the boundary
	DetectedAt  time.Time `json:"detected_at"`
}

// BoundaryConfig holds configuration for semantic boundary detection.
type BoundaryConfig struct {
	Enabled        bool    `json:"enabled"`
	WindowSize     int     `json:"window_size"`     // number of messages per comparison window
	ShiftThreshold float64 `json:"shift_threshold"` // minimum score to declare a boundary
	MinMessages    int     `json:"min_messages"`    // minimum messages before detection activates
}

// DefaultBoundaryConfig returns production-tuned defaults.
func DefaultBoundaryConfig() BoundaryConfig {
	return BoundaryConfig{
		Enabled:        true,
		WindowSize:     3,
		ShiftThreshold: 0.5,
		MinMessages:    4,
	}
}

// BoundaryDetector detects topic boundaries in a sequence of messages
// using lexical overlap analysis. When the vocabulary of a sliding window
// diverges sharply from the preceding window, a topic boundary is declared.
type BoundaryDetector struct {
	config BoundaryConfig
}

// NewBoundaryDetector creates a boundary detector with the given config.
func NewBoundaryDetector(config BoundaryConfig) *BoundaryDetector {
	return &BoundaryDetector{config: config}
}

// DetectBoundaries scans a slice of message texts and returns detected
// topic boundaries. Each boundary indicates a position where the conversation
// shifted to a new topic.
func (bd *BoundaryDetector) DetectBoundaries(messages []string) []TopicBoundary {
	if !bd.config.Enabled || len(messages) < bd.config.MinMessages {
		return nil
	}

	ws := bd.config.WindowSize
	if ws < 1 {
		ws = 1
	}

	var boundaries []TopicBoundary
	for i := ws; i < len(messages)-ws+1; i++ {
		before := mergeWindow(messages[i-ws : i])
		after := mergeWindow(messages[i : i+ws])

		shiftScore := bd.computeShift(before, after)
		if shiftScore >= bd.config.ShiftThreshold {
			boundaries = append(boundaries, TopicBoundary{
				Position:    i,
				Score:       shiftScore,
				BeforeTopic: extractBoundaryTopic(before),
				AfterTopic:  extractBoundaryTopic(after),
				DetectedAt:  time.Now(),
			})
		}
	}

	return boundaries
}

// SegmentByBoundaries splits messages into segments based on detected boundaries.
// Each segment represents a coherent topic segment suitable for memory chunking.
func (bd *BoundaryDetector) SegmentByBoundaries(messages []string) [][]string {
	boundaries := bd.DetectBoundaries(messages)
	if len(boundaries) == 0 {
		return [][]string{messages}
	}

	var segments [][]string
	prev := 0
	for _, b := range boundaries {
		if b.Position > prev && b.Position <= len(messages) {
			segments = append(segments, messages[prev:b.Position])
			prev = b.Position
		}
	}
	if prev < len(messages) {
		segments = append(segments, messages[prev:])
	}
	return segments
}

// computeShift measures vocabulary divergence between two text windows.
// Returns a score 0.0 (identical vocabulary) to 1.0 (completely different).
func (bd *BoundaryDetector) computeShift(before, after string) float64 {
	termsBefore := extractSignificantTerms(before)
	termsAfter := extractSignificantTerms(after)

	if len(termsBefore) == 0 && len(termsAfter) == 0 {
		return 0
	}
	if len(termsBefore) == 0 || len(termsAfter) == 0 {
		return 1.0
	}

	// Compute Jaccard distance (1 - Jaccard similarity)
	shared := 0
	for t := range termsBefore {
		if termsAfter[t] > 0 {
			shared++
		}
	}
	union := len(termsBefore) + len(termsAfter) - shared
	if union == 0 {
		return 0
	}
	jaccardSim := float64(shared) / float64(union)

	// Also consider KL-divergence-like term frequency shift
	tfShift := bd.termFrequencyShift(termsBefore, termsAfter)

	// Combine: high Jaccard distance + high TF shift = strong boundary
	return math.Min(1.0, (1.0-jaccardSim)*0.6+tfShift*0.4)
}

// termFrequencyShift measures how differently terms are weighted between windows.
func (bd *BoundaryDetector) termFrequencyShift(a, b map[string]int) float64 {
	// Normalize to probability distributions
	totalA, totalB := 0, 0
	for _, v := range a {
		totalA += v
	}
	for _, v := range b {
		totalB += v
	}
	if totalA == 0 || totalB == 0 {
		return 0
	}

	// Collect all terms
	allTerms := make(map[string]bool)
	for t := range a {
		allTerms[t] = true
	}
	for t := range b {
		allTerms[t] = true
	}

	// Jensen-Shannon divergence approximation
	var divergence float64
	for t := range allTerms {
		pa := float64(a[t]) / float64(totalA)
		pb := float64(b[t]) / float64(totalB)
		avg := (pa + pb) / 2.0
		if pa > 0 && avg > 0 {
			divergence += pa * math.Log2(pa/avg)
		}
		if pb > 0 && avg > 0 {
			divergence += pb * math.Log2(pb/avg)
		}
	}
	// Normalize to 0-1 range (JS divergence max is ln(2))
	return math.Min(1.0, divergence/2.0)
}

// extractSignificantTerms tokenizes text into significant terms with frequency counts.
func extractSignificantTerms(text string) map[string]int {
	terms := make(map[string]int)
	for _, w := range strings.Fields(strings.ToLower(text)) {
		w = strings.Trim(w, ".,;:!?\"'()[]{}`")
		if len(w) > 3 && !BoundaryStopWord(w) {
			terms[w]++
		}
	}
	return terms
}

// extractBoundaryTopic returns a representative topic string from a text window.
// Uses the most frequent significant terms.
func extractBoundaryTopic(text string) string {
	terms := extractSignificantTerms(text)
	if len(terms) == 0 {
		return "general"
	}
	type termFreq struct {
		term string
		freq int
	}
	var tf []termFreq
	for t, f := range terms {
		tf = append(tf, termFreq{t, f})
	}
	// Simple selection of top 3 terms by frequency (no sort needed for small sets)
	var top []string
	for i := 0; i < 3 && i < len(tf); i++ {
		best := 0
		for j := 1; j < len(tf); j++ {
			if tf[j].freq > tf[best].freq {
				best = j
			}
		}
		top = append(top, tf[best].term)
		tf[best].freq = 0 // mark as used
	}
	return strings.Join(top, "_")
}

// mergeWindow joins multiple messages into a single text block.
func mergeWindow(msgs []string) string {
	return strings.Join(msgs, " ")
}

var boundaryStopWords = map[string]bool{
	"the": true, "and": true, "for": true, "are": true, "but": true,
	"not": true, "you": true, "all": true, "can": true, "had": true,
	"was": true, "one": true, "our": true, "use": true, "with": true,
	"this": true, "that": true, "from": true, "they": true, "will": true,
	"have": true, "been": true, "should": true, "would": true, "could": true,
	"also": true, "than": true, "then": true, "into": true, "over": true,
	"about": true, "just": true, "like": true, "what": true, "when": true,
	"there": true, "their": true, "some": true, "very": true, "here": true,
}

func BoundaryStopWord(w string) bool {
	return boundaryStopWords[w]
}
