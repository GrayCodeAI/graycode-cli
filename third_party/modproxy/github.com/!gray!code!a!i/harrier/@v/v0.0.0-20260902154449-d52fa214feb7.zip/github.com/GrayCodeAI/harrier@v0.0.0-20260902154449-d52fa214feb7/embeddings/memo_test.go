package embeddings

import (
	"context"
	"sync/atomic"
	"testing"
)

func TestEmbeddingMemo_GetPut(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemo(10)
	if _, ok := m.Get("hello"); ok {
		t.Fatal("expected miss on empty cache")
	}
	m.Put("hello", []float32{1, 2, 3})
	vec, ok := m.Get("hello")
	if !ok || len(vec) != 3 || vec[0] != 1 {
		t.Fatalf("expected hit, got ok=%v vec=%v", ok, vec)
	}
}

func TestEmbeddingMemo_LRUEviction(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemo(3)
	m.Put("a", []float32{1})
	m.Put("b", []float32{2})
	m.Put("c", []float32{3})
	// Access "a" to promote it
	m.Get("a")
	// Adding "d" should evict "b" (oldest unused)
	m.Put("d", []float32{4})
	if _, ok := m.Get("b"); ok {
		t.Fatal("expected 'b' to be evicted")
	}
	if _, ok := m.Get("a"); !ok {
		t.Fatal("expected 'a' to survive (was promoted)")
	}
}

// countingProvider tracks how many Embed/EmbedBatch calls hit the inner provider.
type countingProvider struct {
	localStub
	embedCalls int64
	batchCalls int64
	modeCalls  int64
}

func (c *countingProvider) Embed(ctx context.Context, text string) ([]float32, error) {
	atomic.AddInt64(&c.embedCalls, 1)
	return c.localStub.Embed(ctx, text)
}

func (c *countingProvider) EmbedBatch(ctx context.Context, texts []string) ([][]float32, error) {
	atomic.AddInt64(&c.batchCalls, 1)
	return c.localStub.EmbedBatch(ctx, texts)
}

func (c *countingProvider) EmbedWithMode(ctx context.Context, text string, mode EmbedMode) ([]float32, error) {
	atomic.AddInt64(&c.modeCalls, 1)
	return c.localStub.EmbedWithMode(ctx, text, mode)
}

func TestMemoizedProvider_Embed(t *testing.T) {
	t.Parallel()
	inner := &countingProvider{}
	p := NewMemoizedProvider(inner, 100)
	ctx := context.Background()

	v1, err := p.Embed(ctx, "foo")
	if err != nil || v1 == nil {
		t.Fatalf("first embed failed: %v", err)
	}
	v2, err := p.Embed(ctx, "foo")
	if err != nil || v2 == nil {
		t.Fatalf("second embed failed: %v", err)
	}
	if inner.embedCalls != 1 {
		t.Fatalf("expected 1 inner call, got %d", inner.embedCalls)
	}
}

func TestMemoizedProvider_EmbedBatch(t *testing.T) {
	t.Parallel()
	inner := &countingProvider{}
	p := NewMemoizedProvider(inner, 100)
	ctx := context.Background()

	// Pre-cache one
	p.Embed(ctx, "a")

	// Batch with one cached, one new
	vecs, err := p.EmbedBatch(ctx, []string{"a", "b"})
	if err != nil || len(vecs) != 2 {
		t.Fatalf("batch failed: %v", err)
	}
	// Inner batch should only have been called for "b"
	if inner.batchCalls != 1 {
		t.Fatalf("expected 1 batch call, got %d", inner.batchCalls)
	}

	// Now both cached — no more inner calls
	vecs2, err := p.EmbedBatch(ctx, []string{"a", "b"})
	if err != nil || len(vecs2) != 2 {
		t.Fatalf("second batch failed: %v", err)
	}
	if inner.batchCalls != 1 {
		t.Fatalf("expected still 1 batch call, got %d", inner.batchCalls)
	}
}

// namedProvider lets a test override the reported model name.
type namedProvider struct {
	localStub
	name string
}

func (p *namedProvider) Name() string { return p.name }

// TestMemoizedProvider_ModelSwapInvalidates pins the core #1 fix: a memo built
// for one model must not serve its vectors to a different model. Since the memo
// is namespaced by Name(), each model has its own key space.
func TestEmbeddingMemoLen(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemo(10)
	if m.Len() != 0 {
		t.Fatalf("expected empty memo, got %d entries", m.Len())
	}
	m.Put("a", []float32{1})
	if m.Len() != 1 {
		t.Fatalf("expected 1 entry, got %d", m.Len())
	}
	m.Put("b", []float32{2})
	if m.Len() != 2 {
		t.Fatalf("expected 2 entries, got %d", m.Len())
	}
}

func TestEmbeddingMemoPutModeUpdate(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemo(10)
	m.Put("a", []float32{1, 2, 3})
	if m.Len() != 1 {
		t.Fatalf("expected 1 entry after put, got %d", m.Len())
	}
	// Update existing entry
	m.Put("a", []float32{4, 5, 6})
	if m.Len() != 1 {
		t.Fatalf("expected still 1 entry after update, got %d", m.Len())
	}
	vec, ok := m.Get("a")
	if !ok || vec[0] != 4 {
		t.Errorf("expected updated vector [4 5 6], got %v", vec)
	}
}

func TestEmbeddingMemoNewWithZeroEntries(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemoNS("test", 0)
	if m.max != 1024 {
		t.Errorf("expected default 1024 max for zero input, got %d", m.max)
	}
}

func TestMemoizedProviderNameAndDims(t *testing.T) {
	t.Parallel()
	inner := NewLocal()
	p := NewMemoizedProvider(inner, 10)
	if p.Name() != inner.Name() {
		t.Errorf("expected Name=%q, got %q", inner.Name(), p.Name())
	}
	if p.Dims() != inner.Dims() {
		t.Errorf("expected Dims=%d, got %d", inner.Dims(), p.Dims())
	}
}

func TestMemoizedProvider_ModelSwapInvalidates(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	old := NewMemoizedProvider(&namedProvider{name: "modelA"}, 100)
	v1, _ := old.Embed(ctx, "foo")

	// Same content, a different model identity → different namespace → miss.
	newer := NewMemoizedProvider(&namedProvider{name: "modelB"}, 100)
	if _, ok := newer.Memo().Get("foo"); ok {
		t.Fatal("modelB memo should not contain modelA's content")
	}
	// Within the same model, content still hits.
	if _, ok := old.Memo().Get("foo"); !ok {
		t.Fatal("modelA memo should still contain its own content")
	}
	_ = v1
}

// TestEmbeddingMemo_ModeIsolation pins the #2-supporting behavior: document- and
// query-mode vectors for identical text occupy distinct keys.
func TestEmbeddingMemo_ModeIsolation(t *testing.T) {
	t.Parallel()
	m := NewEmbeddingMemoNS("model", 100)
	m.PutMode("q", ModeDocument, []float32{1, 0})
	m.PutMode("q", ModeQuery, []float32{0, 1})

	doc, ok := m.GetMode("q", ModeDocument)
	if !ok || doc[0] != 1 {
		t.Fatalf("document-mode vector wrong: %v ok=%v", doc, ok)
	}
	qry, ok := m.GetMode("q", ModeQuery)
	if !ok || qry[1] != 1 {
		t.Fatalf("query-mode vector wrong: %v ok=%v", qry, ok)
	}
}

// TestMemoizedProvider_EmbedWithModeMemoizes pins that mode-aware calls are now
// cached (previously they bypassed the memo entirely).
func TestMemoizedProvider_EmbedWithModeMemoizes(t *testing.T) {
	t.Parallel()
	inner := &countingProvider{}
	p := NewMemoizedProvider(inner, 100)
	ctx := context.Background()

	if _, err := p.EmbedWithMode(ctx, "x", ModeQuery); err != nil {
		t.Fatalf("first mode embed failed: %v", err)
	}
	if _, err := p.EmbedWithMode(ctx, "x", ModeQuery); err != nil {
		t.Fatalf("second mode embed failed: %v", err)
	}
	if inner.modeCalls != 1 {
		t.Fatalf("expected 1 inner mode call, got %d", inner.modeCalls)
	}
	// A different mode for the same text must miss and call inner again.
	if _, err := p.EmbedWithMode(ctx, "x", ModeDocument); err != nil {
		t.Fatalf("doc-mode embed failed: %v", err)
	}
	if inner.modeCalls != 2 {
		t.Fatalf("expected 2 inner mode calls after mode switch, got %d", inner.modeCalls)
	}
}
