//nolint:gocritic
package graph

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

// buildThreeClusterGraph creates a test graph with 3 clear clusters:
//
//	Cluster A: a1-a2-a3 (tightly connected)
//	Cluster B: b1-b2-b3 (tightly connected)
//	Cluster C: c1-c2-c3 (tightly connected)
//	Weak cross-links: a1-b1, b1-c1 (single edges between clusters)
func buildThreeClusterGraph() ([]*storage.Node, []*storage.Edge) {
	nodes := []*storage.Node{
		{ID: "a1", Type: "decision", Content: "use postgres for main database", Confidence: 0.9, Tier: 1},
		{ID: "a2", Type: "decision", Content: "postgres connection pooling with pgbouncer", Confidence: 0.8, Tier: 1},
		{ID: "a3", Type: "convention", Content: "database migrations use golang-migrate", Confidence: 0.85, Tier: 1},
		{ID: "b1", Type: "decision", Content: "authentication uses JWT tokens", Confidence: 0.9, Tier: 1},
		{ID: "b2", Type: "convention", Content: "auth middleware validates bearer tokens", Confidence: 0.85, Tier: 1},
		{ID: "b3", Type: "decision", Content: "refresh tokens stored in httponly cookies", Confidence: 0.8, Tier: 1},
		{ID: "c1", Type: "decision", Content: "frontend uses React with TypeScript", Confidence: 0.9, Tier: 1},
		{ID: "c2", Type: "convention", Content: "components follow atomic design pattern", Confidence: 0.85, Tier: 2},
		{ID: "c3", Type: "convention", Content: "state management with zustand", Confidence: 0.8, Tier: 2},
	}

	edges := []*storage.Edge{
		// Cluster A: database decisions (strong internal links)
		{ID: "ea12", FromID: "a1", ToID: "a2", Type: "relates_to", Weight: 2.0},
		{ID: "ea13", FromID: "a1", ToID: "a3", Type: "relates_to", Weight: 2.0},
		{ID: "ea23", FromID: "a2", ToID: "a3", Type: "relates_to", Weight: 1.5},
		// Cluster B: auth decisions (strong internal links)
		{ID: "eb12", FromID: "b1", ToID: "b2", Type: "relates_to", Weight: 2.0},
		{ID: "eb13", FromID: "b1", ToID: "b3", Type: "relates_to", Weight: 2.0},
		{ID: "eb23", FromID: "b2", ToID: "b3", Type: "relates_to", Weight: 1.5},
		// Cluster C: frontend decisions (strong internal links)
		{ID: "ec12", FromID: "c1", ToID: "c2", Type: "relates_to", Weight: 2.0},
		{ID: "ec13", FromID: "c1", ToID: "c3", Type: "relates_to", Weight: 2.0},
		{ID: "ec23", FromID: "c2", ToID: "c3", Type: "relates_to", Weight: 1.5},
		// Weak cross-cluster links
		{ID: "eab", FromID: "a1", ToID: "b1", Type: "relates_to", Weight: 0.3},
		{ID: "ebc", FromID: "b1", ToID: "c1", Type: "relates_to", Weight: 0.3},
	}

	return nodes, edges
}

func TestDetectThreeClusters(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()

	communities := cd.Detect(nodes, edges)

	// Should detect 3 communities.
	if len(communities) != 3 {
		t.Fatalf("expected 3 communities, got %d", len(communities))
	}

	// Each community should have exactly 3 nodes.
	for _, c := range communities {
		if len(c.NodeIDs) != 3 {
			t.Errorf("community %s has %d nodes, expected 3", c.ID, len(c.NodeIDs))
		}
	}

	// Verify nodes within each community belong to the same cluster.
	clusterOf := func(id string) string {
		return string(id[0]) // "a", "b", or "c"
	}
	for _, c := range communities {
		first := clusterOf(c.NodeIDs[0])
		for _, nid := range c.NodeIDs[1:] {
			if clusterOf(nid) != first {
				t.Errorf("community %s mixes clusters: has %s and %s", c.ID, first, clusterOf(nid))
			}
		}
	}
}

func TestDetectNoEdges(t *testing.T) {
	t.Parallel()
	nodes := []*storage.Node{
		{ID: "x1", Type: "decision", Content: "isolated node 1"},
		{ID: "x2", Type: "decision", Content: "isolated node 2"},
	}
	var edges []*storage.Edge

	cd := NewCommunityDetector()
	communities := cd.Detect(nodes, edges)

	// Each node should be its own community.
	if len(communities) != 2 {
		t.Errorf("expected 2 singleton communities, got %d", len(communities))
	}
}

func TestDetectEmptyGraph(t *testing.T) {
	t.Parallel()
	cd := NewCommunityDetector()
	communities := cd.Detect(nil, nil)
	if communities != nil {
		t.Errorf("expected nil for empty graph, got %v", communities)
	}
}

func TestModularityPositiveForGoodPartition(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()
	communities := cd.Detect(nodes, edges)

	q := Modularity(communities, edges)

	// A good partition should have positive modularity.
	if q <= 0 {
		t.Errorf("expected positive modularity for well-clustered graph, got %f", q)
	}

	// Modularity should be less than 1.
	if q >= 1 {
		t.Errorf("modularity should be < 1, got %f", q)
	}
}

func TestModularityBadPartitionLower(t *testing.T) {
	t.Parallel()
	_, edges := buildThreeClusterGraph()

	// A bad partition: put all nodes in one community.
	badPartition := []Community{
		{ID: "all", NodeIDs: []string{"a1", "a2", "a3", "b1", "b2", "b3", "c1", "c2", "c3"}},
	}
	qBad := Modularity(badPartition, edges)

	// All in one community => Q = 0 (every edge is internal, but so is the expected).
	if qBad > 0.001 || qBad < -0.001 {
		t.Errorf("expected modularity ~0 for single-community partition, got %f", qBad)
	}
}

func TestHierarchicalCommunities(t *testing.T) {
	t.Parallel()
	// Build a graph with moderate cross-links so hierarchical merging can occur.
	// Two sub-clusters within cluster A, two within cluster B, connected moderately.
	nodes := []*storage.Node{
		{ID: "a1", Type: "decision", Content: "node a1", Confidence: 0.9, Tier: 1},
		{ID: "a2", Type: "decision", Content: "node a2", Confidence: 0.9, Tier: 1},
		{ID: "a3", Type: "decision", Content: "node a3", Confidence: 0.9, Tier: 1},
		{ID: "b1", Type: "decision", Content: "node b1", Confidence: 0.9, Tier: 1},
		{ID: "b2", Type: "decision", Content: "node b2", Confidence: 0.9, Tier: 1},
		{ID: "b3", Type: "decision", Content: "node b3", Confidence: 0.9, Tier: 1},
	}

	edges := []*storage.Edge{
		// Sub-cluster 1: a1-a2 (very tight)
		{ID: "e1", FromID: "a1", ToID: "a2", Type: "relates_to", Weight: 3.0},
		// Sub-cluster 2: a3-b1 (very tight)
		{ID: "e2", FromID: "a3", ToID: "b1", Type: "relates_to", Weight: 3.0},
		// Sub-cluster 3: b2-b3 (very tight)
		{ID: "e3", FromID: "b2", ToID: "b3", Type: "relates_to", Weight: 3.0},
		// Moderate links between sub-clusters within same "super-cluster"
		{ID: "e4", FromID: "a1", ToID: "a3", Type: "relates_to", Weight: 1.5},
		{ID: "e5", FromID: "a2", ToID: "a3", Type: "relates_to", Weight: 1.5},
		{ID: "e6", FromID: "b1", ToID: "b2", Type: "relates_to", Weight: 1.5},
		{ID: "e7", FromID: "b1", ToID: "b3", Type: "relates_to", Weight: 1.5},
	}

	cd := NewCommunityDetector()
	hierarchy := cd.HierarchicalCommunities(nodes, edges, 3)

	// Should have at least 1 level.
	if len(hierarchy) < 1 {
		t.Fatalf("expected at least 1 level, got %d", len(hierarchy))
	}

	// Level 0 should have some communities.
	if len(hierarchy[0]) == 0 {
		t.Fatal("level 0 has no communities")
	}

	// All levels should cover all nodes.
	allNodeIDs := map[string]bool{
		"a1": true, "a2": true, "a3": true,
		"b1": true, "b2": true, "b3": true,
	}
	for lv, levelComms := range hierarchy {
		covered := make(map[string]bool)
		for _, c := range levelComms {
			for _, nid := range c.NodeIDs {
				covered[nid] = true
			}
		}
		for nid := range allNodeIDs {
			if !covered[nid] {
				t.Errorf("level %d missing node %s", lv, nid)
			}
		}
	}

	// If multiple levels exist, higher levels should have <= communities than lower.
	for lv := 1; lv < len(hierarchy); lv++ {
		if len(hierarchy[lv]) > len(hierarchy[lv-1]) {
			t.Errorf("level %d has %d communities, should be <= level %d (%d)",
				lv, len(hierarchy[lv]), lv-1, len(hierarchy[lv-1]))
		}
	}
}

func TestSearchByCommunityRelevance(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()
	communities := cd.Detect(nodes, edges)

	// Add summaries and keywords to make search meaningful.
	for i := range communities {
		nodeSet := make(map[string]bool)
		for _, nid := range communities[i].NodeIDs {
			nodeSet[nid] = true
		}
		if nodeSet["a1"] {
			communities[i].Summary = "Database architecture and migration decisions"
			communities[i].Keywords = []string{"postgres", "database", "migration", "pgbouncer"}
		} else if nodeSet["b1"] {
			communities[i].Summary = "Authentication and token management"
			communities[i].Keywords = []string{"JWT", "auth", "tokens", "middleware"}
		} else if nodeSet["c1"] {
			communities[i].Summary = "Frontend React architecture"
			communities[i].Keywords = []string{"React", "TypeScript", "components", "zustand"}
		}
	}

	cs := NewCommunitySearcher(nodes)

	// Search for "database" should rank the DB community first.
	results := cs.SearchByCommunity("database migration", communities)
	if len(results) == 0 {
		t.Fatal("expected results for 'database migration'")
	}

	// First result should be the database community.
	firstNodeSet := make(map[string]bool)
	for _, nid := range results[0].NodeIDs {
		firstNodeSet[nid] = true
	}
	if !firstNodeSet["a1"] {
		t.Error("expected database community to rank first for 'database migration' query")
	}

	// Search for "JWT auth" should rank auth community first.
	results = cs.SearchByCommunity("JWT auth tokens", communities)
	if len(results) == 0 {
		t.Fatal("expected results for 'JWT auth tokens'")
	}
	firstNodeSet = make(map[string]bool)
	for _, nid := range results[0].NodeIDs {
		firstNodeSet[nid] = true
	}
	if !firstNodeSet["b1"] {
		t.Error("expected auth community to rank first for 'JWT auth tokens' query")
	}
}

func TestCommunitySummaryTokenBudget(t *testing.T) {
	t.Parallel()
	nodes, _ := buildThreeClusterGraph()

	communities := []Community{
		{
			ID:       "c1",
			Summary:  "Database architecture decisions",
			Keywords: []string{"postgres", "migration"},
			NodeIDs:  []string{"a1", "a2", "a3"},
		},
		{
			ID:       "c2",
			Summary:  "Authentication and security",
			Keywords: []string{"JWT", "tokens"},
			NodeIDs:  []string{"b1", "b2", "b3"},
		},
		{
			ID:       "c3",
			Summary:  "Frontend architecture",
			Keywords: []string{"React", "TypeScript"},
			NodeIDs:  []string{"c1", "c2", "c3"},
		},
	}

	cs := NewCommunitySearcher(nodes)

	// With a large budget, all communities should be included.
	result := cs.CommunitySummaryForContext(communities, 1000)
	if !strings.Contains(result, "Database architecture") {
		t.Error("expected database community in large-budget context")
	}
	if !strings.Contains(result, "Frontend architecture") {
		t.Error("expected frontend community in large-budget context")
	}

	// With a very small budget, output should be truncated.
	small := cs.CommunitySummaryForContext(communities, 10)
	// 10 tokens = ~40 chars, should be much shorter than full output.
	if len(small) > 80 { // some grace for the header
		t.Errorf("expected truncated output for 10-token budget, got %d chars", len(small))
	}

	// Zero budget should return empty.
	empty := cs.CommunitySummaryForContext(communities, 0)
	if empty != "" {
		t.Error("expected empty string for 0 token budget")
	}
}

func TestExpandCommunity(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()
	communities := cd.Detect(nodes, edges)

	cs := NewCommunitySearcher(nodes)

	// Expand first community should return its nodes.
	if len(communities) == 0 {
		t.Fatal("no communities detected")
	}

	expanded := cs.ExpandCommunity(communities[0].ID, communities)
	if len(expanded) != len(communities[0].NodeIDs) {
		t.Errorf("expanded %d nodes, expected %d", len(expanded), len(communities[0].NodeIDs))
	}

	// Expand non-existent community.
	missing := cs.ExpandCommunity("non-existent", communities)
	if len(missing) != 0 {
		t.Errorf("expected 0 nodes for non-existent community, got %d", len(missing))
	}
}

func TestDriftSearch(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()

	hierarchy := cd.HierarchicalCommunities(nodes, edges, 3)

	// Add summaries for searchability.
	for lv := range hierarchy {
		for i := range hierarchy[lv] {
			nodeSet := make(map[string]bool)
			for _, nid := range hierarchy[lv][i].NodeIDs {
				nodeSet[nid] = true
			}
			if nodeSet["a1"] && !nodeSet["b1"] {
				hierarchy[lv][i].Summary = "Database architecture and migration"
				hierarchy[lv][i].Keywords = []string{"postgres", "database", "migration"}
			} else if nodeSet["b1"] && !nodeSet["a1"] {
				hierarchy[lv][i].Summary = "Authentication and tokens"
				hierarchy[lv][i].Keywords = []string{"JWT", "auth", "tokens"}
			} else if nodeSet["c1"] && !nodeSet["a1"] {
				hierarchy[lv][i].Summary = "Frontend React development"
				hierarchy[lv][i].Keywords = []string{"React", "TypeScript", "frontend"}
			}
		}
	}

	ds := NewDriftSearcher(nodes, 10)

	// Search for "postgres database" should return DB-related nodes.
	results := ds.DriftSearch("postgres database", hierarchy)
	if len(results) == 0 {
		t.Fatal("DriftSearch returned no results for 'postgres database'")
	}

	// The top result should be from the database cluster.
	foundDB := false
	for _, n := range results {
		if strings.Contains(n.Content, "postgres") || strings.Contains(n.Content, "database") {
			foundDB = true
			break
		}
	}
	if !foundDB {
		t.Error("DriftSearch for 'postgres database' should include database-related nodes")
	}

	// Search for "React TypeScript" should return frontend nodes.
	results = ds.DriftSearch("React TypeScript", hierarchy)
	if len(results) == 0 {
		t.Fatal("DriftSearch returned no results for 'React TypeScript'")
	}

	foundFE := false
	for _, n := range results {
		if strings.Contains(n.Content, "React") || strings.Contains(n.Content, "TypeScript") {
			foundFE = true
			break
		}
	}
	if !foundFE {
		t.Error("DriftSearch for 'React TypeScript' should include frontend nodes")
	}
}

func TestDriftSearchEmptyQuery(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()
	hierarchy := cd.HierarchicalCommunities(nodes, edges, 2)

	ds := NewDriftSearcher(nodes, 10)
	results := ds.DriftSearch("", hierarchy)
	if results != nil {
		t.Error("expected nil for empty query")
	}
}

func TestDriftSearchEmptyHierarchy(t *testing.T) {
	t.Parallel()
	nodes, _ := buildThreeClusterGraph()
	ds := NewDriftSearcher(nodes, 10)
	results := ds.DriftSearch("test", nil)
	if results != nil {
		t.Error("expected nil for empty hierarchy")
	}
}

func TestRankCommunitiesByRelevanceBM25(t *testing.T) {
	t.Parallel()
	nodes, _ := buildThreeClusterGraph()
	cs := NewCommunitySearcher(nodes)

	communities := []Community{
		{
			ID:       "db",
			Summary:  "Database postgres migration schema",
			Keywords: []string{"postgres", "database", "SQL"},
			NodeIDs:  []string{"a1", "a2", "a3"},
		},
		{
			ID:       "auth",
			Summary:  "Authentication JWT bearer tokens",
			Keywords: []string{"JWT", "auth", "security"},
			NodeIDs:  []string{"b1", "b2", "b3"},
		},
		{
			ID:       "fe",
			Summary:  "Frontend React components UI",
			Keywords: []string{"React", "TypeScript", "UI"},
			NodeIDs:  []string{"c1", "c2", "c3"},
		},
	}

	// "postgres SQL migration" should rank DB community first.
	ranked := cs.RankCommunitiesByRelevance("postgres SQL migration", communities)
	if len(ranked) == 0 {
		t.Fatal("expected ranked results")
	}
	if ranked[0].ID != "db" {
		t.Errorf("expected 'db' first, got %s", ranked[0].ID)
	}

	// "React UI components" should rank frontend first.
	ranked = cs.RankCommunitiesByRelevance("React UI components", communities)
	if len(ranked) == 0 {
		t.Fatal("expected ranked results")
	}
	if ranked[0].ID != "fe" {
		t.Errorf("expected 'fe' first, got %s", ranked[0].ID)
	}
}

func TestCommunityStrength(t *testing.T) {
	t.Parallel()
	nodes, edges := buildThreeClusterGraph()
	cd := NewCommunityDetector()
	communities := cd.Detect(nodes, edges)

	// All detected communities should have positive strength.
	for _, c := range communities {
		if c.Strength <= 0 {
			t.Errorf("community %s has non-positive strength %f", c.ID, c.Strength)
		}
	}
}
