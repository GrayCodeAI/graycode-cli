// Package tls builds the server's TLS configuration, generating and
// auto-renewing a self-signed localhost certificate when none is supplied.
package tls

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"time"
)

// Config holds TLS configuration.
type Config struct {
	Enabled  bool
	CertFile string
	KeyFile  string
}

// TLSConfig returns a *tls.Config, generating a self-signed cert if needed.
func TLSConfig(cfg Config, dataDir string) (*tls.Config, error) {
	cert, key := cfg.CertFile, cfg.KeyFile
	if cert == "" {
		cert = filepath.Join(dataDir, "cert.pem")
	}
	if key == "" {
		key = filepath.Join(dataDir, "key.pem")
	}

	// Generate a self-signed cert if the files are missing OR the existing cert
	// is expired/near expiry. Without the expiry check an aged cert on disk
	// would load happily and then fail every TLS handshake with no auto-renew.
	if needsRegen(cert) {
		if err := generateSelfSigned(cert, key); err != nil {
			return nil, err
		}
	}

	tlsCert, err := tls.LoadX509KeyPair(cert, key)
	if err != nil {
		return nil, err
	}
	return &tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		MinVersion:   tls.VersionTLS12,
	}, nil
}

// needsRegen reports whether the cert file is missing, unreadable/unparseable,
// or within one day of expiry — any of which warrants regenerating it.
func needsRegen(certFile string) bool {
	pemBytes, err := os.ReadFile(certFile) // #nosec G304 -- certFile is derived from configured dataDir or CertFile config option, not externally supplied
	if err != nil {
		return true // missing or unreadable
	}
	block, _ := pem.Decode(pemBytes)
	if block == nil {
		return true // not valid PEM
	}
	crt, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		return true // unparseable
	}
	return time.Now().Add(24 * time.Hour).After(crt.NotAfter)
}

func generateSelfSigned(certFile, keyFile string) error {
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}

	serialNumber, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 64))
	if err != nil {
		return err
	}
	tmpl := &x509.Certificate{
		SerialNumber: serialNumber,
		Subject:      pkix.Name{Organization: []string{"harrier"}},
		NotBefore:    time.Now(),
		NotAfter:     time.Now().Add(365 * 24 * time.Hour),
		KeyUsage:     x509.KeyUsageKeyEncipherment | x509.KeyUsageDigitalSignature,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		IPAddresses:  []net.IP{net.ParseIP("127.0.0.1")},
		DNSNames:     []string{"localhost"},
	}

	certDER, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &priv.PublicKey, priv)
	if err != nil {
		return err
	}
	keyDER, err := x509.MarshalECPrivateKey(priv)
	if err != nil {
		return err
	}

	// Write both PEM files atomically (temp file + rename) so a crash mid-write
	// can never leave a half-written cert paired with a stale key — which would
	// load fine via needsRegen yet fail every handshake. Encode each fully to a
	// temp file in the same directory, then rename into place.
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})
	if err := writeFileAtomic(certFile, certPEM, 0o644); err != nil {
		return err
	}
	return writeFileAtomic(keyFile, keyPEM, 0o600)
}

// writeFileAtomic writes data to a temp file in the destination directory, then
// renames it over path. rename(2) within a filesystem is atomic, so readers
// observe either the old file or the fully-written new one — never a partial.
func writeFileAtomic(path string, data []byte, perm os.FileMode) error {
	dir := filepath.Dir(path)
	tmp, err := os.CreateTemp(dir, "."+filepath.Base(path)+".tmp-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	// Best-effort cleanup if we bail before the rename succeeds.
	defer func() { _ = os.Remove(tmpName) }()

	if err := tmp.Chmod(perm); err != nil {
		_ = tmp.Close()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmpName, path)
}
