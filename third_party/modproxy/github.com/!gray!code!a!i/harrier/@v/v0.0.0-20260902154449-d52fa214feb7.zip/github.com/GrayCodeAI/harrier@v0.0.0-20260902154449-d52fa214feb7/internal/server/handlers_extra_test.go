package server

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/storage"
)

// newMux builds a fresh server + routed mux for handler-level tests.
func newMux(t *testing.T) (*RESTServer, *engine.Engine, *http.ServeMux, func()) {
	t.Helper()
	srv, eng, cleanup := setupTestServer(t)
	mux := http.NewServeMux()
	srv.RegisterRoutes(mux)
	return srv, eng, mux, cleanup
}

func TestHandleGetNode(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	node, err := eng.Remember(ctx, engine.RememberInput{Type: "decision", Content: "Adopt Go modules", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// Existing node -> 200 with node + neighbors keys.
	req := httptest.NewRequest("GET", "/harrier/node/"+node.ID, nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("get node: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var resp struct {
		Node      *storage.Node   `json:"node"`
		Neighbors []*storage.Node `json:"neighbors"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp.Node == nil || resp.Node.ID != node.ID {
		t.Errorf("expected node id %q, got %+v", node.ID, resp.Node)
	}
	if resp.Node.Content != "Adopt Go modules" {
		t.Errorf("content mismatch: got %q", resp.Node.Content)
	}

	// Missing node -> 404.
	req = httptest.NewRequest("GET", "/harrier/node/does-not-exist", nil)
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 404 {
		t.Errorf("missing node: expected 404, got %d", rr.Code)
	}
}

func TestHandleUpdateNode(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	node, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "original", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// Valid PATCH: change content and pin. Version increments.
	patch := map[string]any{"content": "updated content", "pinned": true}
	body, _ := json.Marshal(patch)
	req := httptest.NewRequest("PATCH", "/harrier/node/"+node.ID, bytes.NewReader(body))
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("update: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var updated storage.Node
	if err := json.Unmarshal(rr.Body.Bytes(), &updated); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if updated.Content != "updated content" {
		t.Errorf("content: expected %q, got %q", "updated content", updated.Content)
	}
	if !updated.Pinned {
		t.Error("expected pinned=true after update")
	}
	if updated.Version != node.Version+1 {
		t.Errorf("version: expected %d, got %d", node.Version+1, updated.Version)
	}

	// Invalid type in patch -> 400.
	body, _ = json.Marshal(map[string]any{"type": "not_a_real_type"})
	req = httptest.NewRequest("PATCH", "/harrier/node/"+node.ID, bytes.NewReader(body))
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 400 {
		t.Errorf("invalid type: expected 400, got %d", rr.Code)
	}

	// Missing node -> 404 (lookup happens before body decode).
	body, _ = json.Marshal(map[string]any{"content": "x"})
	req = httptest.NewRequest("PATCH", "/harrier/node/missing-id", bytes.NewReader(body))
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 404 {
		t.Errorf("missing node: expected 404, got %d", rr.Code)
	}
}

func TestHandleForget(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	node, err := eng.Remember(ctx, engine.RememberInput{Type: "task", Content: "ephemeral task", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// Existing node -> 200, status "forgotten".
	req := httptest.NewRequest("DELETE", "/harrier/forget/"+node.ID, nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("forget: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var resp map[string]string
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp["status"] != "forgotten" {
		t.Errorf("status: expected 'forgotten', got %q", resp["status"])
	}

	// Forget sets confidence to 0 rather than deleting; node still readable.
	got, err := eng.Store().GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("get after forget: %v", err)
	}
	if got.Confidence != 0 {
		t.Errorf("expected confidence 0 after forget, got %v", got.Confidence)
	}

	// Missing node -> 404.
	req = httptest.NewRequest("DELETE", "/harrier/forget/missing-id", nil)
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 404 {
		t.Errorf("missing node: expected 404, got %d", rr.Code)
	}
}

func TestHandleStats(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	// Empty graph -> all zero counts.
	req := httptest.NewRequest("GET", "/harrier/graph/stats", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("stats empty: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var st engine.Status
	if err := json.Unmarshal(rr.Body.Bytes(), &st); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if st.Nodes != 0 {
		t.Errorf("empty graph: expected 0 nodes, got %d", st.Nodes)
	}

	// Seed two nodes -> node count reflects them.
	if _, err := eng.Remember(ctx, engine.RememberInput{Type: "decision", Content: "n1", Scope: "project"}); err != nil {
		t.Fatal(err)
	}
	settleSelfLink()
	if _, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "n2", Scope: "project"}); err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	req = httptest.NewRequest("GET", "/harrier/graph/stats", nil)
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("stats: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &st); err != nil {
		t.Fatalf("decode: %v", err)
	}
	// Two Remember calls produce at least two nodes (the engine may also derive
	// extra nodes). Assert the count grew from the empty baseline of 0.
	if st.Nodes < 2 {
		t.Errorf("expected at least 2 nodes after seeding, got %d", st.Nodes)
	}
}

func TestHandleVersions(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	node, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "v1 content", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// No versions saved yet -> 200, empty list, node_id echoed.
	req := httptest.NewRequest("GET", "/harrier/node/"+node.ID+"/versions", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("versions: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var resp struct {
		NodeID   string                    `json:"node_id"`
		Versions []engine.NodeHistoryEntry `json:"versions"`
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp.NodeID != node.ID {
		t.Errorf("node_id: expected %q, got %q", node.ID, resp.NodeID)
	}
	if len(resp.Versions) != 0 {
		t.Errorf("expected 0 versions initially, got %d", len(resp.Versions))
	}

	// A PATCH that changes content saves a version; versions list then grows.
	body, _ := json.Marshal(map[string]any{"content": "v2 content"})
	preq := httptest.NewRequest("PATCH", "/harrier/node/"+node.ID, bytes.NewReader(body))
	prr := httptest.NewRecorder()
	mux.ServeHTTP(prr, preq)
	if prr.Code != 200 {
		t.Fatalf("patch: expected 200, got %d: %s", prr.Code, prr.Body.String())
	}

	req = httptest.NewRequest("GET", "/harrier/node/"+node.ID+"/versions", nil)
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("versions after patch: expected 200, got %d", rr.Code)
	}
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if len(resp.Versions) != 1 {
		t.Errorf("expected 1 saved version after content patch, got %d", len(resp.Versions))
	}
	if len(resp.Versions) == 1 && resp.Versions[0].Content != "v1 content" {
		t.Errorf("saved version should hold prior content, got %q", resp.Versions[0].Content)
	}
}

func TestHandleRollback(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	node, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "original content", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// Create a saved version by changing content via PATCH.
	body, _ := json.Marshal(map[string]any{"content": "changed content"})
	preq := httptest.NewRequest("PATCH", "/harrier/node/"+node.ID, bytes.NewReader(body))
	prr := httptest.NewRecorder()
	mux.ServeHTTP(prr, preq)
	if prr.Code != 200 {
		t.Fatalf("patch: expected 200, got %d", prr.Code)
	}

	// Non-positive version -> 400 (validated before engine call).
	body, _ = json.Marshal(map[string]any{"version": 0})
	req := httptest.NewRequest("POST", "/harrier/node/"+node.ID+"/rollback", bytes.NewReader(body))
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 400 {
		t.Errorf("version=0: expected 400, got %d", rr.Code)
	}

	// Unknown version -> 400 (engine returns "version not found").
	body, _ = json.Marshal(map[string]any{"version": 999})
	req = httptest.NewRequest("POST", "/harrier/node/"+node.ID+"/rollback", bytes.NewReader(body))
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 400 {
		t.Errorf("unknown version: expected 400, got %d", rr.Code)
	}

	// Valid rollback to the saved version 1 -> 200, status rolled_back.
	body, _ = json.Marshal(map[string]any{"version": 1})
	req = httptest.NewRequest("POST", "/harrier/node/"+node.ID+"/rollback", bytes.NewReader(body))
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("rollback: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var resp map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if resp["status"] != "rolled_back" {
		t.Errorf("status: expected 'rolled_back', got %v", resp["status"])
	}

	// Content was restored to the original.
	got, err := eng.Store().GetNode(ctx, node.ID)
	if err != nil {
		t.Fatal(err)
	}
	if got.Content != "original content" {
		t.Errorf("rollback content: expected %q, got %q", "original content", got.Content)
	}
}

func TestHandleContext(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	if _, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "ctx node", Scope: "project", Project: "proj"}); err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	req := httptest.NewRequest("GET", "/harrier/context?project=proj", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("context: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	// Response is a RecallResult; just confirm it decodes as a JSON object.
	var obj map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &obj); err != nil {
		t.Fatalf("context decode: %v", err)
	}
}

func TestHandleRecallSeeded(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	a, err := eng.Remember(ctx, engine.RememberInput{Type: "decision", Content: "use postgres for storage", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()
	b, err := eng.Remember(ctx, engine.RememberInput{Type: "convention", Content: "postgres connection pooling", Scope: "project"})
	if err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// Seed an explicit edge between the two nodes.
	edge := storage.Edge{FromID: a.ID, ToID: b.ID, Type: "relates_to"}
	ebody, _ := json.Marshal(edge)
	ereq := httptest.NewRequest("POST", "/harrier/link", bytes.NewReader(ebody))
	err2 := func() error {
		errr := httptest.NewRecorder()
		mux.ServeHTTP(errr, ereq)
		if errr.Code != 201 {
			t.Logf("link seed returned %d (edge type may differ): %s", errr.Code, errr.Body.String())
		}
		return nil
	}()
	_ = err2
	settleSelfLink()

	// Recall with a query at a valid depth -> 200.
	body, _ := json.Marshal(engine.RecallOpts{Query: "postgres", Depth: 2})
	req := httptest.NewRequest("POST", "/harrier/recall", bytes.NewReader(body))
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("recall: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	var obj map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &obj); err != nil {
		t.Fatalf("recall decode: %v", err)
	}
}

func TestHandleImpact(t *testing.T) {
	t.Parallel()
	_, eng, mux, cleanup := newMux(t)
	defer cleanup()
	ctx := context.Background()

	if _, err := eng.Remember(ctx, engine.RememberInput{Type: "decision", Content: "impact seed", Scope: "project"}); err != nil {
		t.Fatal(err)
	}
	settleSelfLink()

	// No file_watch entries for this path -> empty result, but still 200.
	req := httptest.NewRequest("GET", "/harrier/impact/src/main.go", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 200 {
		t.Fatalf("impact: expected 200, got %d: %s", rr.Code, rr.Body.String())
	}
	// Body is a JSON array (possibly null) of nodes.
	var nodes []*storage.Node
	if err := json.Unmarshal(rr.Body.Bytes(), &nodes); err != nil {
		t.Fatalf("impact decode: %v", err)
	}

	// Depth over the max -> 400.
	req = httptest.NewRequest("GET", "/harrier/impact/src/main.go?depth=10", nil)
	rr = httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != 400 {
		t.Errorf("impact depth=10: expected 400, got %d", rr.Code)
	}
}
