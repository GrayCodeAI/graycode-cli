package ingest

import (
	"testing"
)

func TestExtractFacts(t *testing.T) {
	text := `
use jose library for JWT handling
decided to use D1 SQLite for Cloudflare Workers
`

	facts := ExtractFacts(text)
	if len(facts) < 2 {
		t.Fatalf("expected at least 2 extracted facts, got %d", len(facts))
	}

	foundConvention := false
	foundDecision := false

	for _, f := range facts {
		if f.Category == "convention" {
			foundConvention = true
		}
		if f.Category == "decision" {
			foundDecision = true
		}
	}

	if !foundConvention {
		t.Errorf("expected to extract a convention fact")
	}
	if !foundDecision {
		t.Errorf("expected to extract a decision fact")
	}
}
