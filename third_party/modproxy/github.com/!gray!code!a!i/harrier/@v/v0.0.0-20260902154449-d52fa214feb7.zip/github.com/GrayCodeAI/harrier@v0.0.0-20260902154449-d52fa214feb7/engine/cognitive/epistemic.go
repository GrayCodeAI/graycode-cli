package cognitive

import (
	"sync"
	"time"

	"github.com/google/uuid"
)

type DirectiveType string

const (
	DirectiveContradiction DirectiveType = "contradiction"
	DirectiveKnowledgeGap  DirectiveType = "knowledge_gap"
	DirectiveLowConfidence DirectiveType = "low_confidence"
	DirectiveStaleFact     DirectiveType = "stale_fact"
)

type EpistemicDirective struct {
	ID              string        `json:"id"`
	Type            DirectiveType `json:"type"`
	Question        string        `json:"question"`
	Context         string        `json:"context"`
	Priority        float64       `json:"priority"`
	CreatedAt       time.Time     `json:"created_at"`
	ResolvedAt      *time.Time    `json:"resolved_at,omitempty"`
	Resolution      string        `json:"resolution,omitempty"`
	SourceEntityIDs []string      `json:"source_entity_ids"`
	Attempts        int           `json:"attempts"`
}

type EpistemicConfig struct {
	Enabled             bool    `json:"enabled"`
	MaxActiveDirectives int     `json:"max_active_directives"`
	MaxPerSession       int     `json:"max_per_session"`
	MinPriority         float64 `json:"min_priority"`
	ExpiryDays          int     `json:"expiry_days"`
}

func DefaultEpistemicConfig() EpistemicConfig {
	return EpistemicConfig{
		Enabled:             true,
		MaxActiveDirectives: 20,
		MaxPerSession:       2,
		MinPriority:         0.3,
		ExpiryDays:          30,
	}
}

type EpistemicEngine struct {
	mu         sync.RWMutex
	directives []*EpistemicDirective
	config     EpistemicConfig
}

func NewEpistemicEngine(config EpistemicConfig) *EpistemicEngine {
	return &EpistemicEngine{
		directives: make([]*EpistemicDirective, 0),
		config:     config,
	}
}

func (e *EpistemicEngine) CreateDirective(dtype DirectiveType, question, context string, priority float64, sourceEntityIDs []string) *EpistemicDirective {
	if !e.config.Enabled {
		return nil
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	active := e.activeCount()
	if active >= e.config.MaxActiveDirectives {
		return nil
	}

	// Dedup
	for _, d := range e.directives {
		if d.ResolvedAt == nil && d.Question == question {
			if priority > d.Priority {
				d.Priority = priority
			}
			return d
		}
	}

	if priority <= 0 {
		priority = 0.5
	}

	directive := &EpistemicDirective{
		ID:              uuid.New().String()[:12],
		Type:            dtype,
		Question:        question,
		Context:         context,
		Priority:        priority,
		CreatedAt:       time.Now(),
		SourceEntityIDs: sourceEntityIDs,
	}
	e.directives = append(e.directives, directive)
	return directive
}

func (e *EpistemicEngine) GetForSession() []*EpistemicDirective {
	if !e.config.Enabled {
		return nil
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	var results []*EpistemicDirective
	for _, d := range e.directives {
		if d.ResolvedAt != nil || d.Priority < e.config.MinPriority {
			continue
		}
		d.Attempts++
		results = append(results, d)
		if len(results) >= e.config.MaxPerSession {
			break
		}
	}
	return results
}

func (e *EpistemicEngine) Resolve(directiveID, resolution string) bool {
	e.mu.Lock()
	defer e.mu.Unlock()

	for _, d := range e.directives {
		if d.ID == directiveID {
			now := time.Now()
			d.ResolvedAt = &now
			d.Resolution = resolution
			return true
		}
	}
	return false
}

func (e *EpistemicEngine) ExpireOld() int {
	e.mu.Lock()
	defer e.mu.Unlock()

	cutoff := time.Now().Add(-time.Duration(e.config.ExpiryDays) * 24 * time.Hour)
	expired := 0
	kept := make([]*EpistemicDirective, 0, len(e.directives))

	for _, d := range e.directives {
		if d.ResolvedAt == nil && d.CreatedAt.Before(cutoff) {
			expired++
			continue
		}
		kept = append(kept, d)
	}

	e.directives = kept
	return expired
}

func (e *EpistemicEngine) activeCount() int {
	count := 0
	for _, d := range e.directives {
		if d.ResolvedAt == nil {
			count++
		}
	}
	return count
}
