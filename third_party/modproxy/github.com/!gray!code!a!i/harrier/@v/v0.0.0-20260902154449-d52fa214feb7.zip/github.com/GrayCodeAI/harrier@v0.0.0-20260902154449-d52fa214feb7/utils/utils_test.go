package utils

import "testing"

func TestShortID(t *testing.T) {
	t.Parallel()
	tests := []struct {
		input  string
		expect string
	}{
		{"abcdefghijklmnop", "abcdefgh"},
		{"abcdefgh", "abcdefgh"},
		{"short", "short"},
		{"", ""},
		{"12345678", "12345678"},
		{"123456789", "12345678"},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.input, func(t *testing.T) {
			t.Parallel()
			got := ShortID(tt.input)
			if got != tt.expect {
				t.Errorf("ShortID(%q) = %q, want %q", tt.input, got, tt.expect)
			}
		})
	}
}
