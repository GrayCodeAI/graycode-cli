package cognitive

import (
	"testing"
	"time"
)

// ---------------------------------------------------------------------------
// Zeigarnik Engine Tests
// ---------------------------------------------------------------------------

func TestZeigarnikEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultZeigarnikConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.DecayResistance != 1.5 {
			t.Errorf("expected DecayResistance=1.5, got %f", cfg.DecayResistance)
		}
		if cfg.MinTextLength != 20 {
			t.Errorf("expected MinTextLength=20, got %d", cfg.MinTextLength)
		}
	})

	t.Run("MarkAndCloseLoop", func(t *testing.T) {
		e := NewZeigarnikEngine(DefaultZeigarnikConfig())
		e.MarkOpenLoop("c1", "working on the auth module")

		loops := e.GetActiveLoops(10)
		if len(loops) != 1 {
			t.Fatalf("expected 1 active loop, got %d", len(loops))
		}
		if loops[0].ChunkID != "c1" {
			t.Errorf("expected chunk c1, got %s", loops[0].ChunkID)
		}
		if loops[0].Resolved {
			t.Error("expected loop to not be resolved")
		}

		e.CloseLoop("c1")
		loops = e.GetActiveLoops(10)
		if len(loops) != 0 {
			t.Errorf("expected 0 active loops after close, got %d", len(loops))
		}
	})

	t.Run("CloseNonExistent", func(t *testing.T) {
		e := NewZeigarnikEngine(DefaultZeigarnikConfig())
		e.CloseLoop("nonexistent") // should not panic
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultZeigarnikConfig()
		cfg.Enabled = false
		e := NewZeigarnikEngine(cfg)
		e.MarkOpenLoop("c1", "working on auth")
		loops := e.GetActiveLoops(10)
		if len(loops) != 0 {
			t.Errorf("expected 0 loops when disabled, got %d", len(loops))
		}
	})

	t.Run("GetActiveLoopsLimit", func(t *testing.T) {
		e := NewZeigarnikEngine(DefaultZeigarnikConfig())
		e.MarkOpenLoop("c1", "todo: fix bug")
		e.MarkOpenLoop("c2", "todo: add tests")
		e.MarkOpenLoop("c3", "todo: refactor")

		loops := e.GetActiveLoops(2)
		if len(loops) != 2 {
			t.Errorf("expected 2 loops with limit=2, got %d", len(loops))
		}
	})

	t.Run("DecayMultiplier", func(t *testing.T) {
		e := NewZeigarnikEngine(DefaultZeigarnikConfig())
		e.MarkOpenLoop("c1", "working on feature")

		mult := e.DecayMultiplier("c1")
		if mult != 1.5 {
			t.Errorf("expected 1.5 for active loop, got %f", mult)
		}

		mult = e.DecayMultiplier("unknown")
		if mult != 1.0 {
			t.Errorf("expected 1.0 for unknown loop, got %f", mult)
		}

		e.CloseLoop("c1")
		mult = e.DecayMultiplier("c1")
		if mult != 1.0 {
			t.Errorf("expected 1.0 for resolved loop, got %f", mult)
		}
	})

	t.Run("ScanChunks", func(t *testing.T) {
		e := NewZeigarnikEngine(DefaultZeigarnikConfig())
		chunks := []ZeigarnikChunk{
			{ID: "c1", Text: "I need to fix the authentication bug later"},
			{ID: "c2", Text: "This is just a normal description of things"},
			{ID: "c3", Text: "Working on the new dashboard feature"},
		}
		marked := e.ScanChunks(chunks)
		if marked < 1 {
			t.Errorf("expected at least 1 marked chunk, got %d", marked)
		}
	})

	t.Run("ScanChunksDisabled", func(t *testing.T) {
		cfg := DefaultZeigarnikConfig()
		cfg.Enabled = false
		e := NewZeigarnikEngine(cfg)
		chunks := []ZeigarnikChunk{
			{ID: "c1", Text: "I need to fix the authentication bug later"},
		}
		e.ScanChunks(chunks)
		// MarkOpenLoop is a no-op when disabled, so no loops stored
		if len(e.GetActiveLoops(100)) != 0 {
			t.Errorf("expected 0 active loops when disabled")
		}
	})
}

func TestDetectOpenLoop(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name    string
		text    string
		minLen  int
		wantHit bool
	}{
		{"todo_later", "Need to fix the auth module later", 5, true},
		{"wip", "Working on the new dashboard", 5, true},
		{"question", "How does this component work?", 5, true},
		{"bug_still", "The bug is still unfixed in production", 5, true},
		{"will_do", "Will do the migration next week", 5, true},
		{"remind", "Remind me to check the logs", 5, true},
		{"short_text", "hi", 5, false},
		{"no_pattern", "The system processes requests efficiently", 5, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := DetectOpenLoop(tt.text, tt.minLen)
			if tt.wantHit && result == "" {
				t.Errorf("expected match for %q, got empty", tt.text)
			}
			if !tt.wantHit && result != "" {
				t.Errorf("expected no match for %q, got %q", tt.text, result)
			}
		})
	}
}

func TestDetectResolution(t *testing.T) {
	t.Parallel()
	tests := []struct {
		text string
		want bool
	}{
		{"The bug is now fixed", true},
		{"Task completed successfully", true},
		{"All tests passing now", false},
		{"Working on the feature", false},
		{"Random text about nothing", false},
	}
	for _, tt := range tests {
		if got := DetectResolution(tt.text); got != tt.want {
			t.Errorf("DetectResolution(%q) = %v, want %v", tt.text, got, tt.want)
		}
	}
}

// ---------------------------------------------------------------------------
// Prospective Engine Tests
// ---------------------------------------------------------------------------

func TestProspectiveEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.TriggerThreshold != 0.75 {
			t.Errorf("expected TriggerThreshold=0.75, got %f", cfg.TriggerThreshold)
		}
		if cfg.MaxActive != 50 {
			t.Errorf("expected MaxActive=50, got %d", cfg.MaxActive)
		}
	})

	t.Run("Create", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		mem := e.Create("when deployment fails", "check logs", "sess1", nil, 0.8)
		if mem == nil {
			t.Fatal("expected non-nil memory")
		}
		if mem.TriggerCondition != "when deployment fails" {
			t.Errorf("wrong trigger: %s", mem.TriggerCondition)
		}
		if mem.Action != "check logs" {
			t.Errorf("wrong action: %s", mem.Action)
		}
		if mem.Priority != 0.8 {
			t.Errorf("expected priority 0.8, got %f", mem.Priority)
		}
	})

	t.Run("CreateDefaultPriority", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		mem := e.Create("trigger", "action", "sess1", nil, 0)
		if mem == nil {
			t.Fatal("expected non-nil")
		}
		if mem.Priority != 0.5 {
			t.Errorf("expected default priority 0.5, got %f", mem.Priority)
		}
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		cfg.Enabled = false
		e := NewProspectiveEngine(cfg)
		mem := e.Create("trigger", "action", "sess1", nil, 0.5)
		if mem != nil {
			t.Error("expected nil when disabled")
		}
	})

	t.Run("MaxActiveLimit", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		cfg.MaxActive = 2
		e := NewProspectiveEngine(cfg)
		e.Create("trigger1", "action1", "sess1", nil, 0.5)
		e.Create("trigger2", "action2", "sess1", nil, 0.5)
		mem := e.Create("trigger3", "action3", "sess1", nil, 0.5)
		if mem != nil {
			t.Error("expected nil when at max active")
		}
	})

	t.Run("CheckTriggersKeyword", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		e.Create("deployment fails in production", "check server logs", "sess1", nil, 0.5)

		triggered := e.CheckTriggers("The deployment fails in production environment", nil)
		if len(triggered) != 1 {
			t.Fatalf("expected 1 triggered, got %d", len(triggered))
		}
		if triggered[0].TriggeredAt == nil {
			t.Error("expected TriggeredAt to be set")
		}
	})

	t.Run("CheckTriggersNoMatch", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		e.Create("deployment fails", "check logs", "sess1", nil, 0.5)

		triggered := e.CheckTriggers("Everything is working perfectly", nil)
		if len(triggered) != 0 {
			t.Errorf("expected 0 triggered, got %d", len(triggered))
		}
	})

	t.Run("CheckTriggersCosine", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		embedding := []float32{1.0, 0.0, 0.0}
		e.Create("semantic trigger", "action", "sess1", embedding, 0.5)

		// High similarity
		triggered := e.CheckTriggers("", []float32{0.95, 0.1, 0.05})
		if len(triggered) != 1 {
			t.Errorf("expected 1 triggered with high sim, got %d", len(triggered))
		}
	})

	t.Run("CheckTriggersSkipsExpired", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		cfg.DefaultTTL = 1 * time.Millisecond
		e := NewProspectiveEngine(cfg)
		e.Create("trigger", "action", "sess1", nil, 0.5)
		time.Sleep(5 * time.Millisecond)

		triggered := e.CheckTriggers("trigger", nil)
		if len(triggered) != 0 {
			t.Errorf("expected 0 triggered (expired), got %d", len(triggered))
		}
	})

	t.Run("CleanExpired", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		cfg.DefaultTTL = 1 * time.Millisecond
		e := NewProspectiveEngine(cfg)
		e.Create("t1", "a1", "sess1", nil, 0.5)
		e.Create("t2", "a2", "sess1", nil, 0.5)
		time.Sleep(5 * time.Millisecond)

		cleaned := e.CleanExpired()
		if cleaned != 2 {
			t.Errorf("expected 2 cleaned, got %d", cleaned)
		}
		if len(e.GetActive()) != 0 {
			t.Errorf("expected 0 active after clean, got %d", len(e.GetActive()))
		}
	})

	t.Run("CleanExpiredKeepsTriggered", func(t *testing.T) {
		cfg := DefaultProspectiveConfig()
		cfg.DefaultTTL = 1 * time.Millisecond
		e := NewProspectiveEngine(cfg)
		e.Create("trigger word", "action", "sess1", nil, 0.5)
		e.CheckTriggers("trigger word", nil) // marks as triggered
		time.Sleep(5 * time.Millisecond)

		cleaned := e.CleanExpired()
		if cleaned != 0 {
			t.Errorf("expected 0 cleaned (triggered should be kept), got %d", cleaned)
		}
	})

	t.Run("GetActive", func(t *testing.T) {
		e := NewProspectiveEngine(DefaultProspectiveConfig())
		// Use longer trigger conditions so keywordMatch (>3 char words) can match
		e.Create("deploy the authentication fix", "a1", "sess1", nil, 0.5)
		e.Create("review the pull request changes", "a2", "sess1", nil, 0.5)
		e.CheckTriggers("deploy the authentication fix now", nil) // trigger first one

		active := e.GetActive()
		if len(active) != 1 {
			t.Errorf("expected 1 active, got %d", len(active))
		}
	})
}

// ---------------------------------------------------------------------------
// Epistemic Engine Tests
// ---------------------------------------------------------------------------

func TestEpistemicEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultEpistemicConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.MaxActiveDirectives != 20 {
			t.Errorf("expected MaxActiveDirectives=20, got %d", cfg.MaxActiveDirectives)
		}
		if cfg.MaxPerSession != 2 {
			t.Errorf("expected MaxPerSession=2, got %d", cfg.MaxPerSession)
		}
		if cfg.MinPriority != 0.3 {
			t.Errorf("expected MinPriority=0.3, got %f", cfg.MinPriority)
		}
	})

	t.Run("CreateDirective", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d := e.CreateDirective(DirectiveKnowledgeGap, "How does auth work?", "context", 0.8, []string{"e1"})
		if d == nil {
			t.Fatal("expected non-nil directive")
		}
		if d.Type != DirectiveKnowledgeGap {
			t.Errorf("expected type knowledge_gap, got %s", d.Type)
		}
		if d.Priority != 0.8 {
			t.Errorf("expected priority 0.8, got %f", d.Priority)
		}
	})

	t.Run("CreateDirectiveDefaultPriority", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d := e.CreateDirective(DirectiveStaleFact, "Is X still true?", "ctx", 0, nil)
		if d == nil {
			t.Fatal("expected non-nil")
		}
		if d.Priority != 0.5 {
			t.Errorf("expected default priority 0.5, got %f", d.Priority)
		}
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultEpistemicConfig()
		cfg.Enabled = false
		e := NewEpistemicEngine(cfg)
		d := e.CreateDirective(DirectiveKnowledgeGap, "question", "ctx", 0.5, nil)
		if d != nil {
			t.Error("expected nil when disabled")
		}
	})

	t.Run("MaxActiveDirectives", func(t *testing.T) {
		cfg := DefaultEpistemicConfig()
		cfg.MaxActiveDirectives = 2
		e := NewEpistemicEngine(cfg)
		e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.5, nil)
		e.CreateDirective(DirectiveKnowledgeGap, "q2", "ctx", 0.5, nil)
		d := e.CreateDirective(DirectiveKnowledgeGap, "q3", "ctx", 0.5, nil)
		if d != nil {
			t.Error("expected nil at max active")
		}
	})

	t.Run("DedupBumpsPriority", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d1 := e.CreateDirective(DirectiveKnowledgeGap, "How does auth work?", "ctx", 0.5, nil)
		d2 := e.CreateDirective(DirectiveKnowledgeGap, "How does auth work?", "ctx", 0.9, nil)
		if d1.ID != d2.ID {
			t.Error("expected dedup: same ID returned")
		}
		if d1.Priority != 0.9 {
			t.Errorf("expected priority bumped to 0.9, got %f", d1.Priority)
		}
	})

	t.Run("GetForSession", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.8, nil)
		e.CreateDirective(DirectiveKnowledgeGap, "q2", "ctx", 0.9, nil)
		e.CreateDirective(DirectiveKnowledgeGap, "q3", "ctx", 0.1, nil) // below MinPriority

		results := e.GetForSession()
		if len(results) != 2 {
			t.Errorf("expected 2 results (MaxPerSession=2), got %d", len(results))
		}
		// Check attempts incremented
		for _, r := range results {
			if r.Attempts != 1 {
				t.Errorf("expected Attempts=1, got %d", r.Attempts)
			}
		}
	})

	t.Run("GetForSessionSkipsResolved", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d1 := e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.8, nil)
		e.CreateDirective(DirectiveKnowledgeGap, "q2", "ctx", 0.8, nil)
		e.Resolve(d1.ID, "answered")

		results := e.GetForSession()
		if len(results) != 1 {
			t.Errorf("expected 1 (resolved skipped), got %d", len(results))
		}
	})

	t.Run("Resolve", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d := e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.8, nil)
		ok := e.Resolve(d.ID, "The answer is X")
		if !ok {
			t.Error("expected resolve to succeed")
		}
		if d.ResolvedAt == nil {
			t.Error("expected ResolvedAt to be set")
		}
		if d.Resolution != "The answer is X" {
			t.Errorf("wrong resolution: %s", d.Resolution)
		}
	})

	t.Run("ResolveNonExistent", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		ok := e.Resolve("nonexistent", "answer")
		if ok {
			t.Error("expected false for nonexistent")
		}
	})

	t.Run("ExpireOld", func(t *testing.T) {
		cfg := DefaultEpistemicConfig()
		cfg.ExpiryDays = 0 // expire immediately (0 days = everything older than now)
		e := NewEpistemicEngine(cfg)
		e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.5, nil)

		// The directive was just created, so it's not older than 0 days.
		// Let's test with a directive whose CreatedAt is in the past.
		// We need to manipulate the CreatedAt manually.
		e2 := NewEpistemicEngine(DefaultEpistemicConfig())
		e2.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.5, nil)
		e2.directives[0].CreatedAt = time.Now().Add(-31 * 24 * time.Hour) // 31 days ago
		expired := e2.ExpireOld()
		if expired != 1 {
			t.Errorf("expected 1 expired, got %d", expired)
		}
		if len(e2.directives) != 0 {
			t.Errorf("expected 0 directives after expiry, got %d", len(e2.directives))
		}
	})

	t.Run("ExpireOldKeepsResolved", func(t *testing.T) {
		e := NewEpistemicEngine(DefaultEpistemicConfig())
		d := e.CreateDirective(DirectiveKnowledgeGap, "q1", "ctx", 0.5, nil)
		e.Resolve(d.ID, "answered")
		d.CreatedAt = time.Now().Add(-31 * 24 * time.Hour)

		expired := e.ExpireOld()
		if expired != 0 {
			t.Errorf("expected 0 expired (resolved kept), got %d", expired)
		}
	})
}

// ---------------------------------------------------------------------------
// Somatic Engine Tests
// ---------------------------------------------------------------------------

func TestSomaticEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultSomaticConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.SkipThreshold != -0.5 {
			t.Errorf("expected SkipThreshold=-0.5, got %f", cfg.SkipThreshold)
		}
		if cfg.BoostThreshold != 0.5 {
			t.Errorf("expected BoostThreshold=0.5, got %f", cfg.BoostThreshold)
		}
	})

	t.Run("RecordOutcomeSuccess", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		e.RecordOutcome("region-a", true)

		m := e.GetMarker("region-a")
		if m == nil {
			t.Fatal("expected marker")
		}
		if m.Accesses != 1 {
			t.Errorf("expected 1 access, got %d", m.Accesses)
		}
		// valence = 0*0.8 + 0.2 = 0.2
		if m.Valence < 0.19 || m.Valence > 0.21 {
			t.Errorf("expected valence ~0.2, got %f", m.Valence)
		}
	})

	t.Run("RecordOutcomeFailure", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		e.RecordOutcome("region-b", false)

		m := e.GetMarker("region-b")
		if m == nil {
			t.Fatal("expected marker")
		}
		// valence = 0*0.8 - 0.2 = -0.2
		if m.Valence < -0.21 || m.Valence > -0.19 {
			t.Errorf("expected valence ~-0.2, got %f", m.Valence)
		}
	})

	t.Run("EMAUpdate", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		e.RecordOutcome("r1", true)  // valence = 0.2
		e.RecordOutcome("r1", true)  // valence = 0.2*0.8 + 0.2 = 0.36
		e.RecordOutcome("r1", false) // valence = 0.36*0.8 - 0.2 = 0.088

		m := e.GetMarker("r1")
		if m.Accesses != 3 {
			t.Errorf("expected 3 accesses, got %d", m.Accesses)
		}
		if m.Valence < 0.08 || m.Valence > 0.10 {
			t.Errorf("expected valence ~0.088, got %f", m.Valence)
		}
	})

	t.Run("ConfidenceGrows", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		e.RecordOutcome("r1", true)
		m1 := e.GetMarker("r1")
		conf1 := m1.Confidence // 1 - 1/(1+1) = 0.5

		e.RecordOutcome("r1", true)
		m2 := e.GetMarker("r1")
		conf2 := m2.Confidence // 1 - 1/(2+1) = 0.666...

		if conf2 <= conf1 {
			t.Errorf("expected confidence to grow: %f -> %f", conf1, conf2)
		}
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultSomaticConfig()
		cfg.Enabled = false
		e := NewSomaticEngine(cfg)
		e.RecordOutcome("r1", true)
		if e.GetMarker("r1") != nil {
			t.Error("expected nil marker when disabled")
		}
	})

	t.Run("ShouldSkip", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		// Build up negative valence with enough accesses for confidence
		for i := 0; i < 10; i++ {
			e.RecordOutcome("bad-region", false)
		}
		if !e.ShouldSkip("bad-region") {
			t.Error("expected ShouldSkip=true for negative valence region")
		}
		if e.ShouldSkip("unknown-region") {
			t.Error("expected ShouldSkip=false for unknown region")
		}
	})

	t.Run("ShouldBoost", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		// Build up positive valence
		for i := 0; i < 10; i++ {
			e.RecordOutcome("good-region", true)
		}
		if !e.ShouldBoost("good-region") {
			t.Error("expected ShouldBoost=true for positive valence region")
		}
		if e.ShouldBoost("unknown-region") {
			t.Error("expected ShouldBoost=false for unknown region")
		}
	})

	t.Run("GetMarkerUnknown", func(t *testing.T) {
		e := NewSomaticEngine(DefaultSomaticConfig())
		if e.GetMarker("nonexistent") != nil {
			t.Error("expected nil for unknown region")
		}
	})
}

// ---------------------------------------------------------------------------
// Curiosity Engine Tests
// ---------------------------------------------------------------------------

func TestCuriosityEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultCuriosityConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.MaxTargets != 20 {
			t.Errorf("expected MaxTargets=20, got %d", cfg.MaxTargets)
		}
	})

	t.Run("AddTarget", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		target := e.AddTarget("Go generics", "knowledge_gap", 0.8)
		if target == nil {
			t.Fatal("expected non-nil target")
		}
		if target.Topic != "Go generics" {
			t.Errorf("wrong topic: %s", target.Topic)
		}
		if target.Priority != 0.8 {
			t.Errorf("wrong priority: %f", target.Priority)
		}
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultCuriosityConfig()
		cfg.Enabled = false
		e := NewCuriosityEngine(cfg)
		target := e.AddTarget("topic", "gap", 0.5)
		if target != nil {
			t.Error("expected nil when disabled")
		}
	})

	t.Run("DedupBumpsPriority", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		t1 := e.AddTarget("Go generics", "gap", 0.5)
		t2 := e.AddTarget("Go generics", "gap", 0.9)
		if t1.ID != t2.ID {
			t.Error("expected dedup: same target returned")
		}
		if t1.Priority != 0.9 {
			t.Errorf("expected priority bumped to 0.9, got %f", t1.Priority)
		}
	})

	t.Run("DedupOnlyForUnexplored", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		t1 := e.AddTarget("topic", "gap", 0.5)
		e.MarkExplored(t1.ID, "found stuff")
		t2 := e.AddTarget("topic", "gap", 0.9)
		if t1.ID == t2.ID {
			t.Error("expected new target (old one was explored)")
		}
	})

	t.Run("MaxTargetsEviction", func(t *testing.T) {
		cfg := DefaultCuriosityConfig()
		cfg.MaxTargets = 2
		e := NewCuriosityEngine(cfg)
		t1 := e.AddTarget("t1", "gap", 0.3)
		e.AddTarget("t2", "gap", 0.5)
		e.MarkExplored(t1.ID, "done") // mark lowest priority as explored

		t3 := e.AddTarget("t3", "gap", 0.7)
		if t3 == nil {
			t.Error("expected eviction to make room")
		}
	})

	t.Run("MaxTargetsNoEviction", func(t *testing.T) {
		cfg := DefaultCuriosityConfig()
		cfg.MaxTargets = 2
		e := NewCuriosityEngine(cfg)
		e.AddTarget("t1", "gap", 0.3)
		e.AddTarget("t2", "gap", 0.5)
		// Neither explored, so no eviction possible
		t3 := e.AddTarget("t3", "gap", 0.7)
		if t3 != nil {
			t.Error("expected nil when full and nothing to evict")
		}
	})

	t.Run("GetTopTargets", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		e.AddTarget("low", "gap", 0.3)
		e.AddTarget("high", "gap", 0.9)
		e.AddTarget("mid", "gap", 0.6)

		top := e.GetTopTargets(10)
		if len(top) != 3 {
			t.Fatalf("expected 3 targets, got %d", len(top))
		}
		if top[0].Topic != "high" {
			t.Errorf("expected high first, got %s", top[0].Topic)
		}
		if top[1].Topic != "mid" {
			t.Errorf("expected mid second, got %s", top[1].Topic)
		}
		if top[2].Topic != "low" {
			t.Errorf("expected low third, got %s", top[2].Topic)
		}
	})

	t.Run("GetTopTargetsExcludesExplored", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		t1 := e.AddTarget("explored", "gap", 0.9)
		e.AddTarget("unexplored", "gap", 0.5)
		e.MarkExplored(t1.ID, "findings")

		top := e.GetTopTargets(10)
		if len(top) != 1 {
			t.Errorf("expected 1 (explored excluded), got %d", len(top))
		}
		if top[0].Topic != "unexplored" {
			t.Errorf("expected unexplored, got %s", top[0].Topic)
		}
	})

	t.Run("GetTopTargetsLimit", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		e.AddTarget("t1", "gap", 0.5)
		e.AddTarget("t2", "gap", 0.6)
		e.AddTarget("t3", "gap", 0.7)

		top := e.GetTopTargets(2)
		if len(top) != 2 {
			t.Errorf("expected 2 with limit, got %d", len(top))
		}
	})

	t.Run("MarkExplored", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		target := e.AddTarget("topic", "gap", 0.5)
		ok := e.MarkExplored(target.ID, "learned X, Y, Z")
		if !ok {
			t.Error("expected MarkExplored to succeed")
		}
		if target.ExploredAt == nil {
			t.Error("expected ExploredAt to be set")
		}
		if target.Findings != "learned X, Y, Z" {
			t.Errorf("wrong findings: %s", target.Findings)
		}
	})

	t.Run("MarkExploredNonExistent", func(t *testing.T) {
		e := NewCuriosityEngine(DefaultCuriosityConfig())
		ok := e.MarkExplored("nonexistent", "findings")
		if ok {
			t.Error("expected false for nonexistent")
		}
	})
}

// ---------------------------------------------------------------------------
// Reconsolidation Engine Tests
// ---------------------------------------------------------------------------

func TestReconsolidationEngine(t *testing.T) {
	t.Parallel()
	t.Run("DefaultConfig", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		if !cfg.Enabled {
			t.Error("expected Enabled=true")
		}
		if cfg.LabileWindow != 30*time.Minute {
			t.Errorf("expected LabileWindow=30m, got %v", cfg.LabileWindow)
		}
		if cfg.StrengthBonus != 0.2 {
			t.Errorf("expected StrengthBonus=0.2, got %f", cfg.StrengthBonus)
		}
	})

	t.Run("OnRecallAndIsLabile", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.OnRecall("chunk1")

		if !e.IsLabile("chunk1") {
			t.Error("expected chunk1 to be labile")
		}
		if e.IsLabile("chunk2") {
			t.Error("expected chunk2 to not be labile")
		}
	})

	t.Run("DisabledEngine", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		cfg.Enabled = false
		e := NewReconsolidationEngine(cfg)
		e.OnRecall("chunk1")
		if e.IsLabile("chunk1") {
			t.Error("expected not labile when disabled")
		}
	})

	t.Run("Strengthen", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.OnRecall("chunk1")

		bonus := e.Strengthen("chunk1")
		if bonus != 0.2 {
			t.Errorf("expected bonus 0.2, got %f", bonus)
		}

		// Strengthening again should still return bonus (still labile)
		bonus2 := e.Strengthen("chunk1")
		if bonus2 != 0.2 {
			t.Errorf("expected bonus 0.2 on re-strengthen, got %f", bonus2)
		}
	})

	t.Run("StrengthenNonLabile", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		bonus := e.Strengthen("nonexistent")
		if bonus != 0 {
			t.Errorf("expected 0 for non-labile, got %f", bonus)
		}
	})

	t.Run("StrengthenExpired", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		cfg.LabileWindow = 1 * time.Millisecond
		e := NewReconsolidationEngine(cfg)
		e.OnRecall("chunk1")
		time.Sleep(5 * time.Millisecond)

		bonus := e.Strengthen("chunk1")
		if bonus != 0 {
			t.Errorf("expected 0 for expired, got %f", bonus)
		}
	})

	t.Run("FlagContradiction", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.OnRecall("chunk1")
		e.FlagContradiction("chunk1")

		contradicted := e.GetContradicted()
		if len(contradicted) != 1 {
			t.Fatalf("expected 1 contradicted, got %d", len(contradicted))
		}
		if contradicted[0] != "chunk1" {
			t.Errorf("expected chunk1, got %s", contradicted[0])
		}
	})

	t.Run("FlagContradictionNonExistent", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.FlagContradiction("nonexistent") // should not panic
	})

	t.Run("GetContradictedExcludesExpired", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		cfg.LabileWindow = 1 * time.Millisecond
		e := NewReconsolidationEngine(cfg)
		e.OnRecall("chunk1")
		e.FlagContradiction("chunk1")
		time.Sleep(5 * time.Millisecond)

		contradicted := e.GetContradicted()
		if len(contradicted) != 0 {
			t.Errorf("expected 0 contradicted (expired), got %d", len(contradicted))
		}
	})

	t.Run("IsLabileExpired", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		cfg.LabileWindow = 1 * time.Millisecond
		e := NewReconsolidationEngine(cfg)
		e.OnRecall("chunk1")
		time.Sleep(5 * time.Millisecond)

		if e.IsLabile("chunk1") {
			t.Error("expected not labile after window expires")
		}
	})

	t.Run("Cleanup", func(t *testing.T) {
		cfg := DefaultReconsolidationConfig()
		cfg.LabileWindow = 1 * time.Millisecond
		e := NewReconsolidationEngine(cfg)
		e.OnRecall("chunk1")
		e.OnRecall("chunk2")
		// Wait for 2x labile window to pass
		time.Sleep(10 * time.Millisecond)

		cleaned := e.Cleanup()
		if cleaned != 2 {
			t.Errorf("expected 2 cleaned, got %d", cleaned)
		}
	})

	t.Run("CleanupKeepsRecent", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.OnRecall("chunk1")

		cleaned := e.Cleanup()
		if cleaned != 0 {
			t.Errorf("expected 0 cleaned (recent), got %d", cleaned)
		}
		if !e.IsLabile("chunk1") {
			t.Error("expected chunk1 to still be labile")
		}
	})

	t.Run("MultipleContradicted", func(t *testing.T) {
		e := NewReconsolidationEngine(DefaultReconsolidationConfig())
		e.OnRecall("c1")
		e.OnRecall("c2")
		e.OnRecall("c3")
		e.FlagContradiction("c1")
		e.FlagContradiction("c3")

		contradicted := e.GetContradicted()
		if len(contradicted) != 2 {
			t.Errorf("expected 2 contradicted, got %d", len(contradicted))
		}
	})
}
