package engine

import (
	"math"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// SearchTimeDecay applies non-destructive decay scoring at query time.
// Unlike RunDecay which modifies stored confidence values, SearchTimeDecay
// computes decay-adjusted scores purely at retrieval time, leaving stored
// data untouched. This allows different queries to use different decay
// profiles and preserves the original confidence for audit and export.
type SearchTimeDecay struct {
	HalfLife time.Duration
}

// DefaultSearchTimeDecay returns a SearchTimeDecay with a 30-day half-life,
// matching the default destructive decay configuration.
func DefaultSearchTimeDecay() SearchTimeDecay {
	return SearchTimeDecay{HalfLife: 30 * 24 * time.Hour}
}

// ApplySearchTimeDecay computes decay-adjusted scores for a set of nodes
// at query time WITHOUT modifying stored confidence values.
//
// Uses the half-life exponential decay formula:
//
//	adjustedScore = confidence * exp(-lambda * age)
//
// where:
//   - lambda = ln(2) / halfLife
//   - age = time since the most recent of AccessedAt or UpdatedAt
//   - confidence = the node's stored Confidence value (never mutated)
//
// Returns a slice of ScoredMemory (reusing the type from confidence.go).
// The Confidence field holds the decay-adjusted score; Trust holds the
// original stored confidence. Nodes with zero confidence or nodes whose
// reference time is in the future (clock skew) are assigned age=0 so they
// receive no penalty.
func (d SearchTimeDecay) ApplySearchTimeDecay(nodes []*storage.Node, now time.Time) []ScoredMemory {
	if d.HalfLife <= 0 {
		// Degenerate: no decay, pass through raw confidence.
		results := make([]ScoredMemory, len(nodes))
		for i, n := range nodes {
			results[i] = ScoredMemory{Node: n, Confidence: n.Confidence, Trust: n.Confidence}
		}
		return results
	}

	lambda := math.Ln2 / d.HalfLife.Seconds()

	results := make([]ScoredMemory, len(nodes))
	for i, n := range nodes {
		conf := n.Confidence
		if conf <= 0 {
			results[i] = ScoredMemory{Node: n, Confidence: 0, Trust: conf}
			continue
		}

		// Pick the most recent reference time (same logic as RunDecay).
		ref := n.UpdatedAt
		if !n.AccessedAt.IsZero() && n.AccessedAt.After(ref) {
			ref = n.AccessedAt
		}

		age := now.Sub(ref)
		if age <= 0 {
			// Clock skew or future timestamp: no penalty.
			results[i] = ScoredMemory{Node: n, Confidence: conf, Trust: conf}
			continue
		}

		decay := math.Exp(-lambda * age.Seconds())
		results[i] = ScoredMemory{Node: n, Confidence: conf * decay, Trust: conf}
	}
	return results
}
