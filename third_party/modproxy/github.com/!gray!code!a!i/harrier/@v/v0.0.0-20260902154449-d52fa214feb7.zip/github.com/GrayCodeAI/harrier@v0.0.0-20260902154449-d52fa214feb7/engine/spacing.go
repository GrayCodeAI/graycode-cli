package engine

import (
	"math"
	"time"
)

type SpacingConfig struct {
	OptimalInterval time.Duration `json:"optimal_interval"`
	MaxBonus        float64       `json:"max_bonus"`
	CrammingPenalty float64       `json:"cramming_penalty"`
}

func DefaultSpacingConfig() SpacingConfig {
	return SpacingConfig{
		OptimalInterval: 24 * time.Hour,
		MaxBonus:        0.3,
		CrammingPenalty: 0.5,
	}
}

func SpacingScore(accessTimes []time.Time, config SpacingConfig) float64 {
	if len(accessTimes) < 2 {
		return 0
	}

	var totalScore float64
	optimal := config.OptimalInterval.Seconds()

	for i := 1; i < len(accessTimes); i++ {
		interval := accessTimes[i].Sub(accessTimes[i-1]).Seconds()

		if interval < optimal*0.1 {
			// Cramming: very short interval
			totalScore += config.CrammingPenalty
		} else {
			// Score based on how close to optimal the spacing is
			ratio := interval / optimal
			// Bell curve around ratio=1
			score := math.Exp(-0.5 * math.Pow(math.Log(ratio), 2))
			totalScore += score * config.MaxBonus
		}
	}

	return totalScore / float64(len(accessTimes)-1)
}

func IsWellSpaced(accessTimes []time.Time, config SpacingConfig) bool {
	score := SpacingScore(accessTimes, config)
	return score > config.MaxBonus*0.5
}

// MemoryStability calculates cognitive memory strength based on base half-life, access count, and spacing quality.
func MemoryStability(baseHalfLifeDays float64, accessCount int, spacingScore float64) float64 {
	if baseHalfLifeDays <= 0 {
		baseHalfLifeDays = 30
	}
	if accessCount <= 1 {
		return baseHalfLifeDays
	}
	// Stability increases with square root of access count and spacing bonus
	countMultiplier := math.Sqrt(float64(accessCount))
	spacingMultiplier := 1.0 + math.Max(0, spacingScore)
	return baseHalfLifeDays * countMultiplier * spacingMultiplier
}

// EbbinghausRetention calculates memory retention score R(t) = e^(-elapsedDays / stability).
func EbbinghausRetention(elapsedDays float64, stability float64) float64 {
	if stability <= 0 {
		stability = 30.0
	}
	if elapsedDays <= 0 {
		return 1.0
	}
	return math.Exp(-elapsedDays / stability)
}
