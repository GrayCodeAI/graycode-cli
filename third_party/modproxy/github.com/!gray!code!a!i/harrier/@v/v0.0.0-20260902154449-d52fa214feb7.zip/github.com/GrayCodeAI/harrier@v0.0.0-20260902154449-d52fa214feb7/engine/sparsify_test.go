package engine

import (
	"context"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestSparsifier_MergeNearDuplicates(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()
	// Create near-duplicate memories
	_ = store.CreateNode(ctx, &storage.Node{ID: "d1", Type: "convention", Content: "Always use jose library for JWT tokens", Scope: "project", Confidence: 0.9})
	_ = store.CreateNode(ctx, &storage.Node{ID: "d2", Type: "convention", Content: "Always use jose library for JWT authentication tokens", Scope: "project", Confidence: 0.7})
	// Different enough to not merge
	_ = store.CreateNode(ctx, &storage.Node{ID: "d3", Type: "convention", Content: "Deploy using Docker and fly.io", Scope: "project", Confidence: 0.8})

	sp := NewSparsifier(store)
	result, err := sp.Run(ctx)
	if err != nil {
		t.Fatalf("Sparsify failed: %v", err)
	}

	// d1 and d2 are near-duplicates (same terms)
	if result.Merged < 1 {
		t.Logf("Merged = %d (may not merge if similarity < threshold)", result.Merged)
	}
	t.Logf("SparsifyResult: merged=%d, compressed=%d, pruned=%d", result.Merged, result.Compressed, result.Pruned)
}

func TestSparsifier_PruneOrphans(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()
	now := time.Now()
	// Orphan: no edges, low confidence, low access
	_ = store.CreateNode(ctx, &storage.Node{ID: "orphan1", Type: "task", Content: "old task nobody cares about", ContentHash: "hash_orphan1", Scope: "project", Confidence: 0.05, AccessCount: 0, CreatedAt: now, UpdatedAt: now})
	// Not an orphan: has confidence
	_ = store.CreateNode(ctx, &storage.Node{ID: "keep1", Type: "convention", Content: "important rule", ContentHash: "hash_keep1", Scope: "project", Confidence: 0.8, CreatedAt: now, UpdatedAt: now})
	// Not an orphan: pinned
	_ = store.CreateNode(ctx, &storage.Node{ID: "keep2", Type: "decision", Content: "pinned decision", ContentHash: "hash_keep2", Scope: "project", Confidence: 0.05, Pinned: true, CreatedAt: now, UpdatedAt: now})

	// Verify nodes were created
	if n, err := store.GetNode(ctx, "keep1"); err != nil || n == nil {
		t.Fatalf("keep1 creation failed: err=%v, node=%v", err, n)
	}

	sp := NewSparsifier(store)
	result, err := sp.Run(ctx)
	if err != nil {
		t.Fatalf("Run failed: %v", err)
	}

	t.Logf("Pruned: %d", result.Pruned)

	// Verify keep1 still exists (confidence 0.8 > 0.2 threshold)
	node, err := store.GetNode(ctx, "keep1")
	if err != nil || node == nil {
		t.Error("keep1 should not be pruned (high confidence)")
	}

	// Verify pinned node still exists
	node2, err := store.GetNode(ctx, "keep2")
	if err != nil || node2 == nil {
		t.Error("keep2 should not be pruned (pinned)")
	}
}

func TestContentSimilarity(t *testing.T) {
	t.Parallel()
	tests := []struct {
		a, b   string
		minSim float64
		maxSim float64
	}{
		{"use jose for jwt tokens", "use jose for jwt authentication tokens", 0.6, 1.0},
		{"deploy to fly.io", "use jose for jwt", 0.0, 0.2},
		{"same exact content", "same exact content", 1.0, 1.0},
		{"", "something", 0.0, 0.0},
	}

	for _, tt := range tests {
		sim := contentSimilarity(tt.a, tt.b)
		if sim < tt.minSim || sim > tt.maxSim {
			t.Errorf("contentSimilarity(%q, %q) = %f, want [%f, %f]", tt.a, tt.b, sim, tt.minSim, tt.maxSim)
		}
	}
}
