package engine

import (
	"context"
	"strings"
)

// KeygenLLM is the interface a caller implements to let harrier rewrite a natural-
// language query into retrieval keywords with an LLM before searching. Like
// ConsolidationLLM, it keeps harrier free of any direct LLM dependency — the engine
// only ever sees this small interface.
//
// GenerateKeywords receives the user's raw query and returns a space-separated
// (or newline-separated) set of keywords/phrases to search for. Returning an
// empty string or an error signals "no rewrite"; the caller falls back to the
// query unchanged (after synonym expansion).
type KeygenLLM interface {
	GenerateKeywords(ctx context.Context, query string) (string, error)
}

// KeygenStrategy controls how RewriteQuery turns a raw query into search terms.
type KeygenStrategy int

const (
	// KeygenSynonyms uses only the built-in dependency-free synonym expansion
	// (ExpandQuery). This is the default and requires no LLM.
	KeygenSynonyms KeygenStrategy = iota
	// KeygenLLMThenSynonyms asks the LLM to extract keywords first, then unions
	// the result with synonym expansion of the original query. This mirrors the
	// "generate keywords before retrieval" pattern: separate the LLM-driven
	// keyword step from the retrieval step so a verbose question becomes tight
	// search terms without the retriever ever seeing the prose.
	KeygenLLMThenSynonyms
	// KeygenLLMOnly uses only the LLM keyword output, falling back to synonym
	// expansion if the LLM is absent or returns nothing.
	KeygenLLMOnly
)

// RewriteQuery turns a raw user query into the search string used for recall,
// applying the given strategy. llm may be nil; when it is, the function behaves
// exactly as KeygenSynonyms regardless of strategy, so callers can wire an LLM
// optionally without branching. The returned string is always non-empty as long
// as query is non-empty.
//
// Defaults here are harrier's own — deliberately not borrowed from any external
// framework's RAG config — and the whole step is best-effort: any LLM failure
// degrades gracefully to local synonym expansion rather than erroring out of a
// recall.
func RewriteQuery(ctx context.Context, llm KeygenLLM, strategy KeygenStrategy, query string) string {
	q := strings.TrimSpace(query)
	if q == "" {
		return ""
	}

	synonyms := ExpandQuery(q)

	if llm == nil || strategy == KeygenSynonyms {
		return synonyms
	}

	kw, err := llm.GenerateKeywords(ctx, q)
	kw = strings.TrimSpace(kw)
	if err != nil || kw == "" {
		// Best-effort: fall back to local expansion.
		return synonyms
	}

	if strategy == KeygenLLMOnly {
		return kw
	}

	// KeygenLLMThenSynonyms: union the LLM keywords with synonym expansion,
	// de-duplicated, preserving first-seen order (LLM terms first).
	return unionTerms(kw, synonyms)
}

// RecallWithKeygen rewrites opts.Query via RewriteQuery and then runs Recall on
// the rewritten query, leaving every other RecallOpts field untouched. It is a
// thin convenience over Recall for callers that have an LLM available; callers
// without one can keep using Recall directly.
func (e *Engine) RecallWithKeygen(ctx context.Context, llm KeygenLLM, strategy KeygenStrategy, opts RecallOpts) (*RecallResult, error) {
	if opts.Query != "" {
		opts.Query = RewriteQuery(ctx, llm, strategy, opts.Query)
	}
	return e.Recall(ctx, opts)
}

// unionTerms merges two whitespace-separated term lists, lower-casing for the
// dedup key but emitting the first-seen surface form, preserving order.
func unionTerms(a, b string) string {
	seen := make(map[string]bool)
	var out []string
	for _, field := range strings.Fields(a + " " + b) {
		key := strings.ToLower(field)
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, field)
	}
	return strings.Join(out, " ")
}
