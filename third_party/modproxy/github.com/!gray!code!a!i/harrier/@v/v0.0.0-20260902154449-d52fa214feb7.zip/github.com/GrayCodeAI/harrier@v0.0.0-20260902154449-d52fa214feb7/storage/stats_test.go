package storage

import (
	"context"
	"testing"
	"time"
)

// seedGraph creates a small graph used by the stats tests:
//   - a, b: type "decision"; c: type "convention"
//   - low-confidence node "lc" (conf 0.1), pinned node "pin"
//   - edges a->b, b->c making "b" the most connected (degree 2)
//   - "iso" is an orphan (no edges)
func seedGraph(t *testing.T, s *Store) {
	t.Helper()
	ctx := context.Background()
	nodes := []*Node{
		{ID: "a", Type: "decision", Content: "alpha", ContentHash: "ha", Scope: "project", Confidence: 1.0},
		{ID: "b", Type: "decision", Content: "bravo", ContentHash: "hb", Scope: "project", Confidence: 1.0},
		{ID: "c", Type: "convention", Content: "charlie", ContentHash: "hc", Scope: "project", Confidence: 1.0},
		{ID: "lc", Type: "convention", Content: "lowconf", ContentHash: "hlc", Scope: "project", Confidence: 0.1},
		{ID: "pin", Type: "decision", Content: "pinned", ContentHash: "hpin", Scope: "project", Confidence: 1.0, Pinned: true},
		{ID: "iso", Type: "convention", Content: "isolated", ContentHash: "hiso", Scope: "project", Confidence: 1.0},
	}
	for _, n := range nodes {
		if err := s.CreateNode(ctx, n); err != nil {
			t.Fatalf("CreateNode(%s): %v", n.ID, err)
		}
	}
	for _, e := range []*Edge{
		{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1},
		{ID: "e2", FromID: "b", ToID: "c", Type: "led_to", Weight: 1},
	} {
		if err := s.CreateEdge(ctx, e); err != nil {
			t.Fatalf("CreateEdge(%s): %v", e.ID, err)
		}
	}
}

func TestNodeStats(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedGraph(t, s)
	stats, total, err := s.NodeStats(ctx)
	if err != nil {
		t.Fatalf("NodeStats: %v", err)
	}
	if total != 6 {
		t.Errorf("total = %d, want 6", total)
	}
	// decision: a, b, pin = 3; convention: c, lc, iso = 3.
	if stats["decision"] != 3 {
		t.Errorf("decision count = %d, want 3", stats["decision"])
	}
	if stats["convention"] != 3 {
		t.Errorf("convention count = %d, want 3", stats["convention"])
	}
}

func TestDoctorStats(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedGraph(t, s)
	r, err := s.DoctorStats(ctx)
	if err != nil {
		t.Fatalf("DoctorStats: %v", err)
	}
	if r.TotalNodes != 6 {
		t.Errorf("TotalNodes = %d, want 6", r.TotalNodes)
	}
	if r.LowConfidence != 1 {
		t.Errorf("LowConfidence = %d, want 1 (lc)", r.LowConfidence)
	}
	if r.Pinned != 1 {
		t.Errorf("Pinned = %d, want 1 (pin)", r.Pinned)
	}
	// Orphans: lc, pin, iso have no edges (a,b,c are connected).
	if r.Orphans != 3 {
		t.Errorf("Orphans = %d, want 3", r.Orphans)
	}
}

func TestLastUpdated(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Empty store: zero time, no error.
	zero, err := s.LastUpdated(ctx)
	if err != nil {
		t.Fatalf("LastUpdated empty: %v", err)
	}
	if !zero.IsZero() {
		t.Errorf("expected zero time for empty store, got %v", zero)
	}

	// With rows present, LastUpdated parses the stored MAX(updated_at) text
	// timestamp and returns it (no error). Regression guard for the prior bug
	// where the value was scanned straight into sql.NullTime and failed.
	older := time.Date(2020, 1, 1, 0, 0, 0, 0, time.UTC)
	newer := time.Date(2024, 6, 1, 12, 0, 0, 0, time.UTC)
	if err := s.CreateNode(ctx, &Node{ID: "n1", Type: "convention", Content: "a", ContentHash: "h1", Scope: "project", UpdatedAt: older}); err != nil {
		t.Fatalf("CreateNode n1: %v", err)
	}
	if err := s.CreateNode(ctx, &Node{ID: "n2", Type: "convention", Content: "b", ContentHash: "h2", Scope: "project", UpdatedAt: newer}); err != nil {
		t.Fatalf("CreateNode n2: %v", err)
	}

	got, err := s.LastUpdated(ctx)
	if err != nil {
		t.Fatalf("LastUpdated with rows: unexpected error: %v", err)
	}
	if got.IsZero() {
		t.Error("expected a non-zero last-updated time when rows exist")
	}
}

func TestTopConnected(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedGraph(t, s)
	// "b" participates in both edges (degree 2); a and c have degree 1 each.
	top, err := s.TopConnected(ctx, 1)
	if err != nil {
		t.Fatalf("TopConnected: %v", err)
	}
	if len(top) != 1 {
		t.Fatalf("expected 1 result, got %d", len(top))
	}
	if top[0] != "bravo" {
		t.Errorf("most-connected content = %q, want bravo", top[0])
	}

	// Larger limit returns only nodes that have at least one edge (a, b, c).
	top3, err := s.TopConnected(ctx, 10)
	if err != nil {
		t.Fatalf("TopConnected(10): %v", err)
	}
	if len(top3) != 3 {
		t.Errorf("expected 3 connected nodes, got %d (%v)", len(top3), top3)
	}
}
