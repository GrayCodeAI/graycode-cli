package engine

import (
	"context"
	"fmt"
	"math"
	"sort"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/intent"
	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"github.com/GrayCodeAI/harrier/storage"
)

// fusedRRFK is the standard RRF constant used for fused recall scoring.
// A value of 60 is the canonical default from the Reciprocal Rank Fusion
// literature (Cormack et al. 2009), balancing emphasis between top-ranked
// and lower-ranked results across heterogeneous retrieval signals.
const fusedRRFK = 60

// FusedRecall performs multi-signal retrieval combining:
//  1. BM25 keyword search (via existing SearchNodes FTS5)
//  2. Graph traversal (via existing IntentBFS from seed nodes)
//  3. Recency signal (recently accessed/modified nodes)
//
// Then fuses results using Reciprocal Rank Fusion (RRF).
//
// This is inspired by mem0's multi-signal retrieval architecture which
// combines semantic search, BM25, and entity-graph traversal with RRF
// to produce higher-quality recall than any single signal alone.
//
// Unlike the existing Recall method (which uses BM25 seeds then graph
// expansion with a confidence*recency heuristic), FusedRecall treats each
// signal as an independent ranked list and merges them with a principled
// rank-fusion algorithm. This avoids the score-space mismatch problem
// where BM25 scores, graph distances, and timestamps are on different
// scales.
func (e *Engine) FusedRecall(ctx context.Context, opts RecallOpts) (*RecallResult, error) {
	start := time.Now()
	atomic.AddInt64(&e.metrics.Recalls, 1)
	if err := ctx.Err(); err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		telemetry.MemoryFusedRecallDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}

	// Apply defaults
	if opts.Depth == 0 {
		opts.Depth = defaultRecallDepth
	}
	if opts.Limit == 0 {
		opts.Limit = defaultRecallLimit
	}

	// Query planner: decide which signals to use based on query characteristics
	planner := NewQueryPlanner(int(atomic.LoadInt64(&e.metrics.NodesStored)), e.hnsw != nil && e.hnsw.Size() > 0, true)
	plan := planner.Plan(opts.Query, opts)
	_ = plan.BM25Limit // Use planner's recommended over-fetch limit

	// Pre-check: bloom filter fast negative (skip FTS5 if definitely no results)
	if e.bloom != nil && e.bloom.Count() > 100 && !e.bloom.MayContainAny(opts.Query) {
		return &RecallResult{}, nil
	}

	// Override depth from query planner if set
	if plan.GraphDepth > 0 {
		opts.Depth = plan.GraphDepth
	}

	// --- Signal 1: BM25 keyword search (with query expansion) ---
	expandedQuery := ExpandQuery(opts.Query)
	bm25Limit := opts.Limit * 3
	if plan.BM25Limit > 0 {
		bm25Limit = plan.BM25Limit
	}
	bm25Nodes, err := e.store.SearchNodes(ctx, expandedQuery, bm25Limit)
	if err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		return nil, fmt.Errorf("fused recall bm25: %w", err)
	}
	bm25Nodes = filterNodes(bm25Nodes, opts)
	bm25Ranks := fusedRankMap(bm25Nodes)

	// Early exit: if BM25 finds nothing, there is nothing to fuse.
	if len(bm25Ranks) == 0 {
		telemetry.MemoryFusedRecallDuration.Record(ctx, time.Since(start).Seconds())
		return &RecallResult{}, nil
	}

	// --- Signal 2: Graph traversal (intent-aware BFS from top-5 BM25 seeds) ---
	queryIntent := intent.Classify(opts.Query)
	graphRanks := map[string]int{}
	graphRank := 1
	graphSeeds := bm25Nodes
	if len(graphSeeds) > 5 {
		graphSeeds = graphSeeds[:5] // only expand top-5 for performance
	}
	if plan.UseGraph {
		for _, seed := range graphSeeds {
			if ctx.Err() != nil {
				break
			}
			ids, err := e.graph.IntentBFS(ctx, seed.ID, opts.Depth, queryIntent)
			if err != nil {
				continue
			}
			for _, id := range ids {
				if _, seen := graphRanks[id]; !seen {
					graphRanks[id] = graphRank
					graphRank++
				}
			}
		}
	}

	// --- Signal 3: Recency (recently accessed/modified nodes) ---
	recencyRanks := map[string]int{}
	if plan.UseRecency {
		recentNodes, err := e.store.ListNodes(ctx, storage.NodeFilter{
			Project:         opts.Project,
			Limit:           opts.Limit * 5,
			MetadataFilters: opts.MetadataFilters,
		})
		if err == nil && len(recentNodes) > 0 {
			sort.Slice(recentNodes, func(i, j int) bool {
				ai := recentNodes[i].AccessedAt
				if ai.IsZero() {
					ai = recentNodes[i].UpdatedAt
				}
				aj := recentNodes[j].AccessedAt
				if aj.IsZero() {
					aj = recentNodes[j].UpdatedAt
				}
				return ai.After(aj)
			})
			cap := opts.Limit * 3
			if cap > len(recentNodes) {
				cap = len(recentNodes)
			}
			for i := 0; i < cap; i++ {
				n := recentNodes[i]
				if opts.Type != "" && n.Type != opts.Type {
					continue
				}
				recencyRanks[n.ID] = i + 1
			}
		}
	}

	// --- Signal 4 (optional): HNSW vector search ---
	vectorRanks := map[string]int{}
	if plan.UseVector && e.hnsw != nil && e.hnsw.Size() > 0 && len(bm25Nodes) > 0 {
		qvec := e.queryVector(ctx, opts.Query, bm25Nodes[0].ID)
		if len(qvec) == e.hnsw.dim {
			vecIDs, _ := e.hnsw.Search(qvec, opts.Limit*2)
			for rank, id := range vecIDs {
				vectorRanks[id] = rank + 1
			}
		}
	}

	// --- Fusion: Reciprocal Rank Fusion (all active signals) ---
	allIDs := fusedMergeKeys(bm25Ranks, graphRanks, recencyRanks, vectorRanks)

	// Batch-fetch all candidate nodes
	nodes, err := e.store.GetNodesBatch(ctx, allIDs)
	if err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		telemetry.MemoryFusedRecallDuration.Record(ctx, time.Since(start).Seconds())
		return nil, fmt.Errorf("fused recall batch fetch: %w", err)
	}
	nodeByID := make(map[string]*storage.Node, len(nodes))
	for _, n := range nodes {
		nodeByID[n.ID] = n
	}

	// --- Signal 4: Entity boost (Mem0 v3 style) ---
	var entityBoosts map[string]float64
	if e.entities != nil {
		entityBoosts = e.entities.BoostScores(opts.Query)
	}

	// Score each candidate via RRF + confidence re-ranking + intent-type boost + entity boost
	type scoredEntry struct {
		node  *storage.Node
		score float64
	}
	scored := make([]scoredEntry, 0, len(allIDs))
	for _, id := range allIDs {
		node, ok := nodeByID[id]
		if !ok {
			continue
		}
		// Apply type/tier/project filters
		if opts.Type != "" && node.Type != opts.Type {
			continue
		}
		if opts.Tier != 0 && node.Tier != opts.Tier {
			continue
		}
		if opts.Project != "" && node.Project != opts.Project {
			continue
		}
		// Metadata key-value filters (AND semantics).
		if len(opts.MetadataFilters) > 0 {
			match := true
			for k, v := range opts.MetadataFilters {
				if node.Metadata == nil || node.Metadata[k] != v {
					match = false
					break
				}
			}
			if !match {
				continue
			}
		}
		// Skip archived nodes (confidence == 0)
		if node.Confidence <= 0 {
			continue
		}

		s := fusedRRFScore(bm25Ranks[id], graphRanks[id], recencyRanks[id], vectorRanks[id])

		// Apply alpha blend when configured (overrides pure RRF).
		if opts.Alpha >= 0 {
			bm25Rank := bm25Ranks[id]
			vecRank := vectorRanks[id]
			bm25Score := 0.0
			vecScore := 0.0
			if bm25Rank > 0 {
				bm25Score = 1.0 / float64(fusedRRFK+bm25Rank)
			}
			if vecRank > 0 {
				vecScore = 1.0 / float64(fusedRRFK+vecRank)
			}
			a := opts.Alpha
			if a < 0 {
				a = 0
			} else if a > 1 {
				a = 1
			}
			s = (1-a)*bm25Score + a*vecScore
		}

		// Re-rank boost: confidence (high-confidence memories are more reliable)
		s *= (0.5 + node.Confidence*0.5)

		// Re-rank boost: intent-type alignment
		s *= intentTypeBoost(queryIntent, node.Type)

		// Re-rank boost: pinned nodes always rank higher
		if node.Pinned {
			s *= 2.0
		}

		// Re-rank boost: tier 1 (hot) nodes get priority
		if node.Tier == 1 {
			s *= 1.3
		}

		// Re-rank boost: entity overlap (Mem0 v3 style)
		if entityBoosts != nil {
			if boost, ok := entityBoosts[id]; ok {
				s *= boost
			}
		}

		scored = append(scored, scoredEntry{node: node, score: s})
	}

	// Sort by fused RRF score descending
	sort.Slice(scored, func(i, j int) bool {
		return scored[i].score > scored[j].score
	})

	// Apply limit
	if len(scored) > opts.Limit {
		scored = scored[:opts.Limit]
	}

	// --- Graph enrichment: traverse related nodes ---
	if opts.GraphTraverseDepth > 0 && len(scored) > 0 {
		seedIDs := make([]string, 0, len(scored))
		for _, s := range scored {
			seedIDs = append(seedIDs, s.node.ID)
		}
		allEdges, err := e.store.GetAllEdgesFor(ctx, seedIDs)
		if err == nil {
			connected := map[string]bool{}
			for _, ed := range allEdges {
				var other string
				switch {
				case ed.FromID != "" && contains(seedIDs, ed.FromID):
					other = ed.ToID
				case ed.ToID != "" && contains(seedIDs, ed.ToID):
					other = ed.FromID
				}
				if other != "" && !contains(seedIDs, other) {
					connected[other] = true
				}
			}
			if len(connected) > 0 {
				connectedIDs := make([]string, 0, len(connected))
				for id := range connected {
					connectedIDs = append(connectedIDs, id)
				}
				enriched, err := e.store.GetNodesBatch(ctx, connectedIDs)
				if err == nil && len(enriched) > 0 {
					minScore := scored[len(scored)-1].score
					enrichScore := minScore * 0.9
					for _, n := range enriched {
						scored = append(scored, scoredEntry{node: n, score: enrichScore})
					}
					sort.Slice(scored, func(i, j int) bool {
						return scored[i].score > scored[j].score
					})
				}
			}
		}
	}

	// --- Post-fusion re-ranking: search-time non-destructive decay ---
	// Apply half-life exponential decay to scores at query time without
	// modifying stored confidence values. Older memories score lower.
	if e.searchDecay != nil {
		now := time.Now()
		for i := range scored {
			ref := scored[i].node.UpdatedAt
			if !scored[i].node.AccessedAt.IsZero() && scored[i].node.AccessedAt.After(ref) {
				ref = scored[i].node.AccessedAt
			}
			age := now.Sub(ref)
			if age > 0 && e.searchDecay.HalfLife > 0 {
				lambda := math.Ln2 / e.searchDecay.HalfLife.Seconds()
				scored[i].score *= math.Exp(-lambda * age.Seconds())
			}
		}
		// Re-sort after decay adjustment
		sort.Slice(scored, func(i, j int) bool {
			return scored[i].score > scored[j].score
		})
	}

	// Collect result nodes
	resultNodes := make([]*storage.Node, len(scored))
	scoreMap := make(map[string]float64, len(scored))
	for i, s := range scored {
		resultNodes[i] = s.node
		scoreMap[s.node.ID] = s.score
	}

	// MMR diversity reranking: prevent near-duplicate results from dominating
	if len(resultNodes) > 2 {
		resultNodes = MMRRerank(resultNodes, scoreMap, e.scoring.MMRLambda, opts.Limit)
	}

	// Log access for returned nodes
	for _, n := range resultNodes {
		e.access.Log(ctx, n.ID)
	}

	// Collect edges between result nodes for subgraph context
	resultIDs := make([]string, len(resultNodes))
	for i, n := range resultNodes {
		resultIDs[i] = n.ID
	}
	edges, _ := e.store.GetEdgesBetween(ctx, resultIDs)

	// Enforce token budget if specified
	if opts.Budget > 0 {
		resultNodes = TrimToTokenBudget(resultNodes, opts.Budget)
	}

	telemetry.MemoryFusedRecallDuration.Record(ctx, time.Since(start).Seconds())
	return &RecallResult{Nodes: resultNodes, Edges: edges}, nil
}

// intentTypeBoost returns a multiplier that boosts nodes whose type aligns with the query intent.
// E.g., "Why" queries boost decisions, "How" queries boost skills/specs.
func intentTypeBoost(queryIntent intent.Intent, nodeType string) float64 {
	switch queryIntent {
	case intent.IntentWhy:
		switch nodeType {
		case "decision":
			return 1.5
		case "convention":
			return 1.3
		}
	case intent.IntentHow:
		switch nodeType {
		case "skill":
			return 1.5
		case "spec":
			return 1.3
		case "convention":
			return 1.2
		}
	case intent.IntentWhen:
		switch nodeType {
		case "task":
			return 1.4
		case "bug":
			return 1.3
		}
	case intent.IntentWhat:
		switch nodeType {
		case "spec":
			return 1.5
		case "convention":
			return 1.3
		case "decision":
			return 1.2
		}
	case intent.IntentWho:
		switch nodeType {
		case "entity":
			return 1.5
		case "file":
			return 1.3
		}
	}
	return 1.0
}

// fusedRRFScore computes the Reciprocal Rank Fusion score from three signals.
// For each signal where the item appears at rank r (1-based), the contribution
// is 1/(k+r). A rank of 0 means the item did not appear in that signal.
func fusedRRFScore(ranks ...int) float64 {
	score := 0.0
	for _, r := range ranks {
		if r > 0 {
			score += 1.0 / float64(fusedRRFK+r)
		}
	}
	return score
}

// fusedRankMap converts a slice of nodes into a 1-based rank map keyed by ID.
func fusedRankMap(nodes []*storage.Node) map[string]int {
	m := make(map[string]int, len(nodes))
	for i, n := range nodes {
		m[n.ID] = i + 1
	}
	return m
}

// fusedMergeKeys returns the deduplicated union of keys from multiple rank maps,
// preserving first-seen order.
func fusedMergeKeys(maps ...map[string]int) []string {
	seen := map[string]bool{}
	var keys []string
	for _, m := range maps {
		for k := range m {
			if !seen[k] {
				seen[k] = true
				keys = append(keys, k)
			}
		}
	}
	return keys
}

// queryVector returns the embedding to drive the vector signal of fused recall.
//
// When an embedder is wired (WithEmbedder), it embeds the query text directly —
// true semantic retrieval independent of the keyword path. Otherwise it falls
// back to the stored embedding of the top BM25 hit (proxySeedID): a re-ranking
// signal biased toward what BM25 already surfaced, not independent retrieval.
// Returns nil if neither source yields a usable vector; the caller dimension-
// checks the result before searching.
func (e *Engine) queryVector(ctx context.Context, query, proxySeedID string) []float32 {
	if e.embedder != nil {
		// Query mode: asymmetric models embed queries (search_query) differently
		// from stored documents (search_document).
		if vec, err := e.embedder.EmbedWithMode(ctx, query, embeddings.ModeQuery); err == nil && len(vec) > 0 {
			return vec
		} else if err != nil {
			atomic.AddInt64(&e.metrics.Errors, 1)
		}
	}
	vec, _, err := e.store.GetEmbedding(ctx, proxySeedID)
	if err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		return nil
	}
	return vec
}

// contains reports whether s contains v.
func contains(s []string, v string) bool {
	for _, e := range s {
		if e == v {
			return true
		}
	}
	return false
}
