package storage

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
)

// MockStorage is a public, concurrency-safe, in-memory implementation of the
// Storage interface. It is designed for use in unit tests across packages
// (engine/, cmd/, etc.) without requiring SQLite.
//
// All methods honour the error injected via SetError when non-nil.
type MockStorage struct {
	mu sync.RWMutex

	// primary stores
	nodes       map[string]*Node
	edges       map[string]*Edge
	sessions    map[string]*Session
	versions    map[string][]*NodeVersion  // nodeID -> versions
	embeddings  map[string]*embeddingEntry // nodeID -> entry
	replays     map[string][]*ReplayEvent  // sessionID -> events
	signatures  map[string]string          // nodeID -> signature
	fileWatches []fileWatchEntry
	accessLog   map[string]int               // nodeID -> count (buffered)
	accessTotal int                          // total flushed
	nodeMeta    map[string]map[string]string // nodeID -> key -> value

	// nextIDs for auto-generation
	nextVersionID int

	// Error injection: when set, all mutating methods return this error.
	injectedErr error
}

type embeddingEntry struct {
	model  string
	vector []float32
}

type fileWatchEntry struct {
	filePath string
	nodeID   string
	gitHash  string
}

// NewMockStorage returns a ready-to-use MockStorage.
func NewMockStorage() *MockStorage {
	return &MockStorage{
		nodes:      make(map[string]*Node),
		edges:      make(map[string]*Edge),
		sessions:   make(map[string]*Session),
		versions:   make(map[string][]*NodeVersion),
		embeddings: make(map[string]*embeddingEntry),
		replays:    make(map[string][]*ReplayEvent),
		signatures: make(map[string]string),
		accessLog:  make(map[string]int),
		nodeMeta:   make(map[string]map[string]string),
	}
}

// SetError configures a non-nil error that every method will return.
// Pass nil to clear the injected error.
func (m *MockStorage) SetError(err error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.injectedErr = err
}

// err returns the currently injected error (must be called with lock held).
func (m *MockStorage) err() error {
	return m.injectedErr
}

// IsAcyclic returns true if the edge type enforces DAG constraint.
func IsAcyclic(edgeType string) bool {
	return edgeType == "caused_by" || edgeType == "led_to" || edgeType == "supersedes" ||
		edgeType == "learned_in" || edgeType == "part_of"
}

// compile-time check
var _ Storage = (*MockStorage)(nil)

// ───────────────────── Nodes ─────────────────────

func (m *MockStorage) CreateNode(_ context.Context, n *Node) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.nodes[n.ID] = n
	return nil
}

func (m *MockStorage) GetNode(_ context.Context, id string) (*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	if n, ok := m.nodes[id]; ok {
		return n, nil
	}
	return nil, sql.ErrNoRows
}

func (m *MockStorage) GetNodeByKey(_ context.Context, key, project string) (*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	for _, n := range m.nodes {
		if n.Key == key && n.Project == project {
			return n, nil
		}
	}
	return nil, nil
}

func (m *MockStorage) GetNodesBatch(_ context.Context, ids []string) ([]*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	out := make([]*Node, 0, len(ids))
	for _, id := range ids {
		if n, ok := m.nodes[id]; ok {
			out = append(out, n)
		}
	}
	return out, nil
}

func (m *MockStorage) UpdateNode(_ context.Context, n *Node) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.nodes[n.ID] = n
	return nil
}

func (m *MockStorage) UpdateNodeContent(_ context.Context, id, newContent string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	if n, ok := m.nodes[id]; ok {
		n.Content = newContent
		return nil
	}
	return sql.ErrNoRows
}

func (m *MockStorage) ArchiveNode(_ context.Context, id string) (bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return false, err
	}
	n, ok := m.nodes[id]
	if !ok || n.Confidence <= 0 {
		return false, nil
	}
	n.Confidence = 0
	return true, nil
}

func (m *MockStorage) DeleteNode(_ context.Context, id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	delete(m.nodes, id)
	return nil
}

func (m *MockStorage) ListNodes(_ context.Context, f NodeFilter) ([]*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	var out []*Node
	for _, n := range m.nodes {
		if f.Type != "" && n.Type != f.Type {
			continue
		}
		if f.Scope != "" && n.Scope != f.Scope {
			continue
		}
		if f.Project != "" && n.Project != f.Project {
			continue
		}
		if f.Tier > 0 && n.Tier != f.Tier {
			continue
		}
		if f.MinConfidence > 0 && n.Confidence < f.MinConfidence {
			continue
		}
		if f.Pinned != nil && n.Pinned != *f.Pinned {
			continue
		}
		if f.SourceSession != "" && n.SourceSession != f.SourceSession {
			continue
		}
		if f.Tag != "" && !csvHasTag(n.Tags, f.Tag) {
			continue
		}
		// Metadata key-value filters (AND semantics).
		if len(f.MetadataFilters) > 0 {
			meta := m.nodeMeta[n.ID]
			match := true
			for k, v := range f.MetadataFilters {
				if meta == nil || meta[k] != v {
					match = false
					break
				}
			}
			if !match {
				continue
			}
		}
		out = append(out, n)
	}
	// deterministic ordering
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	if f.Offset > 0 {
		if f.Offset >= len(out) {
			return nil, nil
		}
		out = out[f.Offset:]
	}
	limit := f.Limit
	if limit <= 0 {
		limit = 1000
	}
	if len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func (m *MockStorage) SearchNodes(_ context.Context, query string, limit int) ([]*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	q := strings.ToLower(query)
	var out []*Node
	for _, n := range m.nodes {
		if strings.Contains(strings.ToLower(n.Content), q) ||
			strings.Contains(strings.ToLower(n.Summary), q) ||
			strings.Contains(strings.ToLower(n.Key), q) {
			out = append(out, n)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

func (m *MockStorage) SearchNodeByHash(_ context.Context, hash, scope, project string) (*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	for _, n := range m.nodes {
		if n.ContentHash == hash && n.Scope == scope && n.Project == project {
			return n, nil
		}
	}
	return nil, sql.ErrNoRows
}

func (m *MockStorage) GetNeighbors(_ context.Context, nodeID string) ([]*Node, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	neighborIDs := map[string]bool{}
	for _, e := range m.edges {
		if e.InvalidAt != (time.Time{}) {
			continue
		}
		if e.FromID == nodeID {
			neighborIDs[e.ToID] = true
		}
		if e.ToID == nodeID {
			neighborIDs[e.FromID] = true
		}
	}
	out := make([]*Node, 0, len(neighborIDs))
	for id := range neighborIDs {
		if n, ok := m.nodes[id]; ok {
			out = append(out, n)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out, nil
}

// ───────────────────── Edges ─────────────────────

func (m *MockStorage) CreateEdge(_ context.Context, e *Edge) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	// Mirror the SQLite store: an edge is valid from creation unless the caller
	// supplied an explicit valid_at.
	now := time.Now().UTC()
	if e.ValidAt.IsZero() {
		e.ValidAt = now
	}
	if e.CreatedAt.IsZero() {
		e.CreatedAt = now
	}
	m.edges[e.ID] = e
	return nil
}

func (m *MockStorage) GetEdge(_ context.Context, id string) (*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	if e, ok := m.edges[id]; ok {
		return e, nil
	}
	return nil, sql.ErrNoRows
}

func (m *MockStorage) InvalidateEdge(_ context.Context, id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	if e, ok := m.edges[id]; ok {
		e.InvalidAt = time.Now()
		return nil
	}
	return sql.ErrNoRows
}

func (m *MockStorage) DeleteEdge(_ context.Context, id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	delete(m.edges, id)
	return nil
}

func (m *MockStorage) GetEdgesFrom(_ context.Context, nodeID string) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	var out []*Edge
	for _, e := range m.edges {
		if e.FromID == nodeID {
			out = append(out, e)
		}
	}
	return out, nil
}

func (m *MockStorage) GetEdgesTo(_ context.Context, nodeID string) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	var out []*Edge
	for _, e := range m.edges {
		if e.ToID == nodeID {
			out = append(out, e)
		}
	}
	return out, nil
}

func (m *MockStorage) GetValidEdgesFrom(_ context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	at = validityInstant(at)
	var out []*Edge
	for _, e := range m.edges {
		if e.FromID == nodeID && edgeValidAt(e, at) {
			out = append(out, e)
		}
	}
	return out, nil
}

func (m *MockStorage) GetValidEdgesTo(_ context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	at = validityInstant(at)
	var out []*Edge
	for _, e := range m.edges {
		if e.ToID == nodeID && edgeValidAt(e, at) {
			out = append(out, e)
		}
	}
	return out, nil
}

// edgeValidAt reports whether e was valid at instant `at`.
func edgeValidAt(e *Edge, at time.Time) bool {
	if !e.ValidAt.IsZero() && e.ValidAt.After(at) {
		return false
	}
	if !e.InvalidAt.IsZero() && !e.InvalidAt.After(at) {
		return false
	}
	return true
}

func (m *MockStorage) GetEdgesBetween(_ context.Context, nodeIDs []string) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	idSet := make(map[string]bool, len(nodeIDs))
	for _, id := range nodeIDs {
		idSet[id] = true
	}
	var out []*Edge
	for _, e := range m.edges {
		if idSet[e.FromID] && idSet[e.ToID] {
			out = append(out, e)
		}
	}
	return out, nil
}

func (m *MockStorage) GetAllEdgesFor(_ context.Context, nodeIDs []string) ([]*Edge, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	idSet := make(map[string]bool, len(nodeIDs))
	for _, id := range nodeIDs {
		idSet[id] = true
	}
	var out []*Edge
	for _, e := range m.edges {
		if idSet[e.FromID] || idSet[e.ToID] {
			out = append(out, e)
		}
	}
	return out, nil
}

func (m *MockStorage) CountEdges(_ context.Context, nodeID string) (int, int, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return 0, 0, err
	}
	inbound, outbound := 0, 0
	for _, e := range m.edges {
		if e.FromID == nodeID {
			outbound++
		}
		if e.ToID == nodeID {
			inbound++
		}
	}
	return inbound, outbound, nil
}

func (m *MockStorage) CountEdgesBatch(_ context.Context, nodeIDs []string) (map[string][2]int, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	result := make(map[string][2]int, len(nodeIDs))
	for _, id := range nodeIDs {
		inbound, outbound := 0, 0
		for _, e := range m.edges {
			if e.FromID == id {
				outbound++
			}
			if e.ToID == id {
				inbound++
			}
		}
		result[id] = [2]int{inbound, outbound}
	}
	return result, nil
}

func (m *MockStorage) CountAllEdges(_ context.Context) (int, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return 0, err
	}
	return len(m.edges), nil
}

// ───────────────────── Stats ─────────────────────

func (m *MockStorage) NodeStats(_ context.Context) (map[string]int, int, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, 0, err
	}
	stats := make(map[string]int)
	total := 0
	for _, n := range m.nodes {
		stats[n.Type]++
		total++
	}
	return stats, total, nil
}

func (m *MockStorage) DoctorStats(_ context.Context) (DoctorStatsResult, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return DoctorStatsResult{}, err
	}
	var r DoctorStatsResult
	for _, n := range m.nodes {
		r.TotalNodes++
		if n.Confidence < 0.2 {
			r.LowConfidence++
		}
		if n.Pinned {
			r.Pinned++
		}
	}
	// count orphans
	hasEdge := map[string]bool{}
	for _, e := range m.edges {
		hasEdge[e.FromID] = true
		hasEdge[e.ToID] = true
	}
	for id := range m.nodes {
		if !hasEdge[id] {
			r.Orphans++
		}
	}
	return r, nil
}

func (m *MockStorage) LastUpdated(_ context.Context) (time.Time, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return time.Time{}, err
	}
	var latest time.Time
	for _, n := range m.nodes {
		if n.UpdatedAt.After(latest) {
			latest = n.UpdatedAt
		}
	}
	for _, e := range m.edges {
		if e.CreatedAt.After(latest) {
			latest = e.CreatedAt
		}
	}
	return latest, nil
}

func (m *MockStorage) TopConnected(_ context.Context, limit int) ([]string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	counts := map[string]int{}
	for _, e := range m.edges {
		counts[e.FromID]++
		counts[e.ToID]++
	}
	type kv struct {
		id    string
		count int
	}
	var sorted []kv
	for id, c := range counts {
		sorted = append(sorted, kv{id, c})
	}
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].count > sorted[j].count })
	if limit > len(sorted) {
		limit = len(sorted)
	}
	out := make([]string, limit)
	for i := 0; i < limit; i++ {
		out[i] = sorted[i].id
	}
	return out, nil
}

// ───────────────────── Graph queries ─────────────

func (m *MockStorage) CheckCycle(_ context.Context, fromID, toID string) (bool, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return false, err
	}
	// Walk backwards from fromID; if we reach toID there's a cycle.
	seen := map[string]bool{}
	var walk func(id string) bool
	walk = func(id string) bool {
		if id == toID {
			return true
		}
		if seen[id] {
			return false
		}
		seen[id] = true
		for _, e := range m.edges {
			if e.ToID == id && IsAcyclic(e.Type) {
				if walk(e.FromID) {
					return true
				}
			}
		}
		return false
	}
	return walk(fromID), nil
}

// ───────────────────── Sessions ──────────────────

func (m *MockStorage) CreateSession(_ context.Context, sess *Session) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.sessions[sess.ID] = sess
	return nil
}

func (m *MockStorage) EndSession(_ context.Context, id string, summary string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	if sess, ok := m.sessions[id]; ok {
		sess.Summary = summary
		sess.EndedAt = time.Now()
		return nil
	}
	return sql.ErrNoRows
}

func (m *MockStorage) ListSessions(_ context.Context, project string, limit int) ([]*Session, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	var out []*Session
	for _, s := range m.sessions {
		if project != "" && s.Project != project {
			continue
		}
		out = append(out, s)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].StartedAt.After(out[j].StartedAt) })
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out, nil
}

// ───────────────────── Versions ──────────────────

func (m *MockStorage) SaveVersion(_ context.Context, nodeID string, content, changedBy, reason string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.nextVersionID++
	m.versions[nodeID] = append(m.versions[nodeID], &NodeVersion{
		NodeID:    nodeID,
		Content:   content,
		ChangedBy: changedBy,
		Reason:    reason,
		Version:   m.nextVersionID,
		ChangedAt: time.Now(),
	})
	return nil
}

func (m *MockStorage) GetVersions(_ context.Context, nodeID string) ([]*NodeVersion, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	return m.versions[nodeID], nil
}

// ───────────────────── Embeddings ────────────────

func (m *MockStorage) SaveEmbedding(_ context.Context, nodeID, model string, vector []float32) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	// Copy vector so caller can't mutate internal state.
	v := make([]float32, len(vector))
	copy(v, vector)
	m.embeddings[nodeID] = &embeddingEntry{model: model, vector: v}
	return nil
}

func (m *MockStorage) GetEmbedding(_ context.Context, nodeID string) ([]float32, string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, "", err
	}
	if e, ok := m.embeddings[nodeID]; ok {
		return e.vector, e.model, nil
	}
	return nil, "", sql.ErrNoRows
}

func (m *MockStorage) DeleteEmbedding(_ context.Context, nodeID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	delete(m.embeddings, nodeID)
	return nil
}

func (m *MockStorage) AllEmbeddings(_ context.Context, model string) (map[string][]float32, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	out := make(map[string][]float32, len(m.embeddings))
	for id, e := range m.embeddings {
		if model != "" && e.model != model {
			continue
		}
		out[id] = e.vector
	}
	return out, nil
}

func (m *MockStorage) GetEmbeddingsBatch(_ context.Context, model string, offset, limit int) (map[string][]float32, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	// deterministic order, applying the model filter before pagination so offsets
	// are stable for a given model.
	ids := make([]string, 0, len(m.embeddings))
	for id, e := range m.embeddings {
		if model != "" && e.model != model {
			continue
		}
		ids = append(ids, id)
	}
	sort.Strings(ids)
	if offset >= len(ids) {
		return map[string][]float32{}, nil
	}
	end := offset + limit
	if end > len(ids) {
		end = len(ids)
	}
	out := make(map[string][]float32, end-offset)
	for _, id := range ids[offset:end] {
		out[id] = m.embeddings[id].vector
	}
	return out, nil
}

// ───────────────────── HNSW ──────────────────────

func (m *MockStorage) BuildHNSWIndex(_ context.Context, model string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	// Mock implementation: just return success
	return nil
}

func (m *MockStorage) SearchHNSW(_ context.Context, model string, query []float32, k, ef int) ([]string, []float32, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, nil, err
	}
	// Mock implementation: return empty results
	return nil, nil, nil
}

// ───────────────────── Replay ────────────────────

func (m *MockStorage) AddReplayEvent(_ context.Context, sessionID, data string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.replays[sessionID] = append(m.replays[sessionID], &ReplayEvent{
		SessionID: sessionID,
		Data:      data,
		CreatedAt: time.Now(),
	})
	return nil
}

func (m *MockStorage) GetReplayEvents(_ context.Context, sessionID string) ([]*ReplayEvent, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	return m.replays[sessionID], nil
}

// ───────────────────── FileWatch ─────────────────

func (m *MockStorage) AddFileWatch(_ context.Context, filePath, nodeID, gitHash string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.fileWatches = append(m.fileWatches, fileWatchEntry{filePath: filePath, nodeID: nodeID, gitHash: gitHash})
	return nil
}

// ───────────────────── AccessLog ─────────────────

func (m *MockStorage) LogAccess(_ context.Context, nodeID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.accessLog[nodeID]++
	return nil
}

func (m *MockStorage) FlushAccessLog(_ context.Context) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return 0, err
	}
	count := len(m.accessLog)
	// Apply buffered counts to node AccessCount fields.
	for id, n := range m.nodes {
		if c, ok := m.accessLog[id]; ok {
			n.AccessCount += c
		}
	}
	m.accessLog = make(map[string]int)
	m.accessTotal += count
	return count, nil
}

// ───────────────────── Metadata ─────────────────

func (m *MockStorage) SaveNodeMetadata(_ context.Context, nodeID string, meta map[string]string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	if meta == nil {
		delete(m.nodeMeta, nodeID)
	} else {
		m.nodeMeta[nodeID] = meta
	}
	return nil
}

func (m *MockStorage) LoadNodeMetadata(_ context.Context, nodeIDs []string) (map[string]map[string]string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	result := make(map[string]map[string]string)
	for _, id := range nodeIDs {
		if meta, ok := m.nodeMeta[id]; ok {
			result[id] = meta
		}
	}
	return result, nil
}

// ───────────────────── Signatures ────────────────

func (m *MockStorage) SaveSignature(_ context.Context, nodeID, signature string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if err := m.err(); err != nil {
		return err
	}
	m.signatures[nodeID] = signature
	return nil
}

func (m *MockStorage) GetAllSignatures(_ context.Context) (map[string]string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if err := m.err(); err != nil {
		return nil, err
	}
	out := make(map[string]string, len(m.signatures))
	for k, v := range m.signatures {
		out[k] = v
	}
	return out, nil
}

// ───────────────────── Transactions ──────────────

// WithTx executes fn with m itself as the "transaction". In-memory maps are
// already consistent so no real txn boundary is needed.
func (m *MockStorage) WithTx(_ context.Context, fn func(Storage) error) error {
	if err := m.err(); err != nil {
		return err
	}
	return fn(m)
}

// ───────────────────── Backup ─────────────────────

// Backup writes an empty file at backupPath to simulate a snapshot.
func (m *MockStorage) Backup(_ context.Context, backupPath string) error {
	if err := m.err(); err != nil {
		return err
	}
	if backupPath == "" {
		return fmt.Errorf("backup path must not be empty")
	}
	return os.WriteFile(backupPath, nil, 0o600)
}

// ───────────────────── Close ─────────────────────

func (m *MockStorage) Close() error {
	return nil
}

// ───────────────────── Test helpers ──────────────

// InjectNodes seeds the mock with pre-built nodes (bypasses error check).
func (m *MockStorage) InjectNodes(nodes ...*Node) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, n := range nodes {
		m.nodes[n.ID] = n
	}
}

// InjectEdges seeds the mock with pre-built edges (bypasses error check).
func (m *MockStorage) InjectEdges(edges ...*Edge) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, e := range edges {
		m.edges[e.ID] = e
	}
}

// NodeCount returns the number of stored nodes (for quick assertions).
func (m *MockStorage) NodeCount() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.nodes)
}

// EdgeCount returns the number of stored edges (for quick assertions).
func (m *MockStorage) EdgeCount() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.edges)
}

// String returns a human-readable summary useful in test failure output.
func (m *MockStorage) String() string {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return fmt.Sprintf("MockStorage{nodes=%d, edges=%d, sessions=%d, embeddings=%d}",
		len(m.nodes), len(m.edges), len(m.sessions), len(m.embeddings))
}

// csvHasTag reports whether the comma-separated tags string contains tag as an
// exact element (delimiter-aware), mirroring the SQL Tag filter in listNodesQ.
func csvHasTag(tags, tag string) bool {
	for _, t := range strings.Split(tags, ",") {
		if strings.TrimSpace(t) == tag {
			return true
		}
	}
	return false
}
