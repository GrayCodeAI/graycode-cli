/**
 * Harrier TypeScript SDK — Give your coding agent persistent memory.
 */

export interface HarrierConfig {
  host?: string;
  port?: number;
  project?: string;
  timeout?: number;
}

export interface Memory {
  id: string;
  type: string;
  content: string;
  confidence: number;
  pinned: boolean;
  tier: number;
  tags: string;
  accessCount: number;
}

export interface RecallResult {
  nodes: Memory[];
  edges: Array<{ fromId: string; toId: string; type: string; weight: number }>;
}

export interface RememberOptions {
  type?: string;
  tags?: string;
  pinned?: boolean;
}

export interface RecallOptions {
  limit?: number;
  depth?: number;
  type?: string;
}

export class Harrier {
  private baseUrl: string;
  private project: string;
  private timeout: number;

  constructor(config: HarrierConfig = {}) {
    const host = config.host || "127.0.0.1";
    const port = config.port || 3456;
    this.baseUrl = `http://${host}:${port}`;
    this.project = config.project || "";
    this.timeout = config.timeout || 10000;
  }

  /**
   * Store a memory in the graph.
   */
  async remember(content: string, options: RememberOptions = {}): Promise<Memory> {
    const body = {
      content,
      type: options.type || "decision",
      scope: "project",
      project: this.project,
      tags: options.tags || "",
      pinned: options.pinned || false,
    };
    const resp = await this.post("/harrier/remember", body);
    return {
      id: resp.id || "",
      type: body.type,
      content,
      confidence: resp.confidence || 0.8,
      pinned: body.pinned,
      tier: 1,
      tags: body.tags,
      accessCount: 0,
    };
  }

  /**
   * Search the memory graph.
   */
  async recall(query: string, options: RecallOptions = {}): Promise<RecallResult> {
    const body: Record<string, unknown> = {
      query,
      limit: options.limit || 10,
      depth: options.depth || 3,
    };
    if (options.type) body.type = options.type;
    if (this.project) body.project = this.project;

    const resp = await this.post("/harrier/recall", body);
    const nodes: Memory[] = (resp.nodes || []).map((n: any) => ({
      id: n.id || "",
      type: n.type || "",
      content: n.content || "",
      confidence: n.confidence || 0.5,
      pinned: n.pinned || false,
      tier: n.tier || 2,
      tags: n.tags || "",
      accessCount: n.access_count || 0,
    }));
    return { nodes, edges: resp.edges || [] };
  }

  /**
   * Get hot-tier context for session injection.
   */
  async context(budget: number = 2000): Promise<string> {
    let params = `?budget=${budget}`;
    if (this.project) params += `&project=${this.project}`;
    const resp = await this.get(`/harrier/context${params}`);
    return (resp.nodes || [])
      .map((n: any) => `[${n.type}] ${n.content}`)
      .join("\n");
  }

  /**
   * Archive a memory (sets confidence to 0).
   */
  async forget(nodeId: string): Promise<void> {
    await this.delete(`/harrier/forget/${nodeId}`);
  }

  /**
   * Create a typed edge between two memories.
   */
  async link(fromId: string, toId: string, type: string = "relates_to"): Promise<void> {
    await this.post("/harrier/link", { from_id: fromId, to_id: toId, type });
  }

  /**
   * Get graph statistics.
   */
  async status(): Promise<{ nodes: number; edges: number; sessions: number }> {
    return this.get("/harrier/graph/stats");
  }

  /**
   * Check what memories are affected by a file change.
   */
  async impact(filePath: string): Promise<string[]> {
    const resp = await this.get(`/harrier/impact/${encodeURIComponent(filePath)}`);
    return resp.affected || [];
  }

  /**
   * Health check.
   */
  async health(): Promise<Record<string, unknown>> {
    return this.get("/harrier/health");
  }

  // --- Private methods ---

  private async post(path: string, body: Record<string, unknown>): Promise<any> {
    const resp = await fetch(`${this.baseUrl}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(this.timeout),
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new HarrierError(`HTTP ${resp.status}: ${text}`);
    }
    return resp.json();
  }

  private async get(path: string): Promise<any> {
    const resp = await fetch(`${this.baseUrl}${path}`, {
      signal: AbortSignal.timeout(this.timeout),
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new HarrierError(`HTTP ${resp.status}: ${text}`);
    }
    return resp.json();
  }

  private async delete(path: string): Promise<any> {
    const resp = await fetch(`${this.baseUrl}${path}`, {
      method: "DELETE",
      signal: AbortSignal.timeout(this.timeout),
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new HarrierError(`HTTP ${resp.status}: ${text}`);
    }
    return resp.json();
  }
}

export class HarrierError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "HarrierError";
  }
}

export default Harrier;
