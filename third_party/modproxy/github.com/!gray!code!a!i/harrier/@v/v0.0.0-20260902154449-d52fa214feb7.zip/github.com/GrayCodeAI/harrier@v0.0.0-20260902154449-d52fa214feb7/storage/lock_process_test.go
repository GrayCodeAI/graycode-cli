package storage

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// TestProcessLockSameProcessSharing is a regression test for hosts that open
// several stores against one database within a single process (e.g. hawk's
// HarrierBridge is constructed from multiple callsites). The OS lock is shared
// via reference counting instead of rejecting the second store.
func TestProcessLockSameProcessSharing(t *testing.T) {
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "shared.db")

	stores := make([]*Store, 0, 4)
	for i := 0; i < 4; i++ {
		s, err := NewStore(dbPath)
		if err != nil {
			t.Fatalf("NewStore #%d in same process: %v", i+1, err)
		}
		stores = append(stores, s)
	}

	// Closing stores early must not release the OS lock while others hold it.
	stores[0].Close()
	stores[1].Close()

	if s, err := NewStore(dbPath); err != nil {
		t.Fatalf("NewStore while refcount > 0: %v", err)
	} else {
		stores = append(stores, s)
	}

	for _, s := range stores[2:] {
		s.Close()
	}
}

// TestProcessLockRefcountRelease verifies the lock file is only removed once
// the last in-process holder releases, and that repeated Release calls are
// safe.
func TestProcessLockRefcountRelease(t *testing.T) {
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "ref.db")
	lockPath := dbPath + ".lock"

	l1, err := AcquireProcessLock(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	l2, err := AcquireProcessLock(dbPath)
	if err != nil {
		t.Fatal(err)
	}

	if err := l1.Release(); err != nil {
		t.Fatalf("Release #1: %v", err)
	}
	if err := l1.Release(); err != nil {
		t.Fatalf("repeat Release must be safe: %v", err)
	}
	// l2 still holds the lock; the file must remain.
	if _, err := os.Stat(lockPath); err != nil {
		t.Errorf("lock file disappeared while a holder remains: %v", err)
	}

	if err := l2.Release(); err != nil {
		t.Fatalf("Release #2: %v", err)
	}
	if _, err := os.Stat(lockPath); !os.IsNotExist(err) {
		t.Errorf("lock file should be removed after last release, stat err = %v", err)
	}
}

// TestProcessLockCrossProcess verifies that a store in a *separate* process
// is rejected while this process holds the lock. The child re-runs this test
// binary with the lock-held database path and prints a sentinel:
// "LOCKBLOCKED" when NewStore fails (correct), "LOCKACQUIRED" if it ever
// grabs the lock (bug). The parent asserts the child saw the block.
func TestProcessLockCrossProcess(t *testing.T) {
	if os.Getenv("HARRIER_LOCK_CHILD") == "1" {
		runLockChild()
		return // unreachable: runLockChild exits
	}

	dir := t.TempDir()
	dbPath := filepath.Join(dir, "cross.db")
	s, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()

	cmd := exec.Command(os.Args[0], "-test.run=TestProcessLockCrossProcess")
	cmd.Env = append(os.Environ(), "HARRIER_LOCK_CHILD=1", "HARRIER_LOCK_DB="+dbPath)
	out, err := cmd.CombinedOutput()
	got := string(out)

	if err != nil {
		t.Fatalf("child process error: %v\noutput:\n%s", err, got)
	}
	switch {
	case containsLockSentinel(got, "LOCKACQUIRED"):
		t.Fatalf("child acquired the lock while parent holds it:\n%s", got)
	case !containsLockSentinel(got, "LOCKBLOCKED"):
		t.Fatalf("child did not report being blocked by the lock:\n%s", got)
	}
}

func containsLockSentinel(out, sentinel string) bool {
	return strings.Contains(out, sentinel)
}

func runLockChild() {
	dbPath := os.Getenv("HARRIER_LOCK_DB")
	if _, err := NewStore(dbPath); err == nil {
		fmt.Println("LOCKACQUIRED")
		os.Exit(1)
	}
	fmt.Println("LOCKBLOCKED")
	os.Exit(0)
}

// TestProcessLockPathNormalization verifies that equivalent spellings of the
// same database path share one lock entry: without normalization, opening
// "dir/db" and "dir/./db" created two procHolders entries pointing at the
// same lock file, and the second flock failed as if another process held it.
func TestProcessLockPathNormalization(t *testing.T) {
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "norm.db")

	s1, err := NewStore(dbPath)
	if err != nil {
		t.Fatalf("NewStore(clean path): %v", err)
	}
	defer s1.Close()

	// Same database through lexically unclean absolute paths (constructed
	// via concatenation because filepath.Join cleans them away).
	s2, err := NewStore(dir + "/./norm.db")
	if err != nil {
		t.Fatalf("NewStore(dot-segment path): %v", err)
	}
	defer s2.Close()
	s3, err := NewStore(dir + "/junk/../norm.db")
	if err != nil {
		t.Fatalf("NewStore(parent-ref path): %v", err)
	}
	defer s3.Close()

	procMu.Lock()
	holders := len(procHolders)
	procMu.Unlock()
	if holders != 1 {
		t.Errorf("expected 1 lock holder after 3 equivalent paths, got %d", holders)
	}
}
