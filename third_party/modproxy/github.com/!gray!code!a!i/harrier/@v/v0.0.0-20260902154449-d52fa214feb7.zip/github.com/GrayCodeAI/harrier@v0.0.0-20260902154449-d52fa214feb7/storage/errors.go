package storage

import "errors"

// Domain-specific errors for the storage layer.
// Callers should use errors.Is() to check for specific error conditions.
//
// Error return conventions:
//   - GetNode, GetEdge: returns the sentinel error wrapped with the ID when not found
//   - SearchNodeByHash, GetNodeByKey: returns (nil, nil) when not found (dedup/upsert pattern)
var (
	ErrNodeNotFound      = errors.New("node not found")
	ErrEdgeNotFound      = errors.New("edge not found")
	ErrSessionNotFound   = errors.New("session not found")
	ErrCycleDetected     = errors.New("cycle detected")
	ErrDuplicateNode     = errors.New("duplicate node")
	ErrDuplicateEdge     = errors.New("duplicate edge")
	ErrInvalidNodeType   = errors.New("invalid node type")
	ErrInvalidEdgeType   = errors.New("invalid edge type")
	ErrContentTooLong    = errors.New("content exceeds maximum length")
	ErrEmptyContent      = errors.New("content cannot be empty")
	ErrDatabaseLocked    = errors.New("database is locked")
	ErrBatchTooLarge     = errors.New("batch size exceeds database limit")
	ErrVersionNotFound   = errors.New("version not found")
	ErrEmbeddingNotFound = errors.New("embedding not found")

	ErrKeyMaterial         = errors.New("encryption key material unavailable")
	ErrUnknownKeyVersion   = errors.New("unknown encryption key version")
	ErrMalformedCiphertext = errors.New("malformed ciphertext")
	ErrDecryptionFailed    = errors.New("decryption failed")
)
