//go:build windows

package storage

import (
	"os"

	"golang.org/x/sys/windows"
)

// acquireOSLock takes a non-blocking exclusive LockFileEx on the lock file.
func acquireOSLock(fd *os.File) error {
	handle := windows.Handle(fd.Fd())
	return windows.LockFileEx(
		handle,
		windows.LOCKFILE_EXCLUSIVE_LOCK|windows.LOCKFILE_FAIL_IMMEDIATELY,
		0,
		0xFFFFFFFF,
		0xFFFFFFFF,
		&windows.Overlapped{},
	)
}

// releaseOSLock releases the file lock; a subsequent Close releases it anyway.
func releaseOSLock(fd *os.File) {
	handle := windows.Handle(fd.Fd())
	_ = windows.UnlockFileEx(handle, 0, 0xFFFFFFFF, 0xFFFFFFFF, &windows.Overlapped{})
}
