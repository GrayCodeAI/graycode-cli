package ingest

import (
	"context"
	"path/filepath"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func setupEngine(t *testing.T) (*engine.Engine, storage.Storage) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })

	g := graph.New(store, store.DB())
	eng := engine.New(store, g)
	t.Cleanup(func() { eng.Close() })
	return eng, store
}

func TestNew_CreatesStream(t *testing.T) {
	t.Parallel()
	eng, _ := setupEngine(t)
	ds := New(eng)
	if ds == nil {
		t.Fatal("expected non-nil DualStream")
	}
	ds.Stop()
}

func TestRemember_FastPath(t *testing.T) {
	t.Parallel()
	eng, store := setupEngine(t)
	ds := New(eng)
	defer ds.Stop()

	ctx := context.Background()
	node, err := ds.Remember(ctx, engine.RememberInput{
		Type:    "decision",
		Content: "Use PostgreSQL for production",
		Scope:   "project",
		Project: "proj1",
	})
	if err != nil {
		t.Fatalf("Remember: %v", err)
	}
	if node == nil {
		t.Fatal("expected non-nil node")
	}
	if node.ID == "" {
		t.Error("expected non-empty node ID")
	}

	// Verify node was stored
	got, err := store.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if got.Content != "Use PostgreSQL for production" {
		t.Errorf("unexpected content: %s", got.Content)
	}
}

func TestRemember_TemporalEdge(t *testing.T) {
	t.Parallel()
	eng, store := setupEngine(t)
	ds := New(eng)
	defer ds.Stop()

	ctx := context.Background()

	// First node - no temporal edge expected
	node1, err := ds.Remember(ctx, engine.RememberInput{
		Type:    "decision",
		Content: "First decision",
		Scope:   "project",
		Project: "proj1",
	})
	if err != nil {
		t.Fatalf("Remember first: %v", err)
	}

	// Second node - temporal edge from node1 → node2 expected
	node2, err := ds.Remember(ctx, engine.RememberInput{
		Type:    "convention",
		Content: "Second convention",
		Scope:   "project",
		Project: "proj1",
	})
	if err != nil {
		t.Fatalf("Remember second: %v", err)
	}

	// Verify temporal edge exists
	edges, err := store.GetEdgesFrom(ctx, node1.ID)
	if err != nil {
		t.Fatalf("GetEdgesFrom: %v", err)
	}

	found := false
	for _, e := range edges {
		if e.ToID == node2.ID && e.Type == "learned_in" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected temporal backbone edge (learned_in) from node1 to node2")
	}
}

func TestRemember_MultipleProjects(t *testing.T) {
	t.Parallel()
	eng, _ := setupEngine(t)
	ds := New(eng)
	defer ds.Stop()

	ctx := context.Background()

	// Nodes in different projects should have independent temporal chains
	n1, _ := ds.Remember(ctx, engine.RememberInput{
		Type: "decision", Content: "proj1 first", Scope: "project", Project: "proj1",
	})
	n2, _ := ds.Remember(ctx, engine.RememberInput{
		Type: "decision", Content: "proj2 first", Scope: "project", Project: "proj2",
	})
	n3, _ := ds.Remember(ctx, engine.RememberInput{
		Type: "decision", Content: "proj1 second", Scope: "project", Project: "proj1",
	})

	if n1 == nil || n2 == nil || n3 == nil {
		t.Fatal("expected all nodes to be created")
	}

	// proj1's second node should link from proj1's first node, not proj2's
	ds.mu.Lock()
	lastProj1 := ds.lastNode["proj1"]
	lastProj2 := ds.lastNode["proj2"]
	ds.mu.Unlock()

	if lastProj1 != n3.ID {
		t.Errorf("proj1 last node should be n3, got %s", lastProj1)
	}
	if lastProj2 != n2.ID {
		t.Errorf("proj2 last node should be n2, got %s", lastProj2)
	}
}

func TestStop_GracefulShutdown(t *testing.T) {
	t.Parallel()
	eng, _ := setupEngine(t)
	ds := New(eng)

	ctx := context.Background()
	// Add some work
	_, _ = ds.Remember(ctx, engine.RememberInput{
		Type: "decision", Content: "test stop", Scope: "project", Project: "proj1",
	})

	// Stop should not hang
	done := make(chan struct{})
	go func() {
		ds.Stop()
		close(done)
	}()

	select {
	case <-done:
		// OK
	case <-time.After(5 * time.Second):
		t.Fatal("Stop() timed out")
	}
}

func TestRemember_EmptyContent(t *testing.T) {
	t.Parallel()
	eng, _ := setupEngine(t)
	ds := New(eng)
	defer ds.Stop()

	ctx := context.Background()
	// Engine may reject empty content
	_, err := ds.Remember(ctx, engine.RememberInput{
		Type:    "decision",
		Content: "",
		Scope:   "project",
		Project: "proj1",
	})
	// This may either error or succeed depending on engine validation
	// Just ensure no panic
	_ = err
}
