package ingest

import (
	"regexp"
	"strings"
)

// Fact represents an extracted atomic piece of information or rule from text.
type Fact struct {
	Subject    string `json:"subject"`
	Predicate  string `json:"predicate"`
	Object     string `json:"object"`
	Category   string `json:"category"`
	Normalized string `json:"normalized"`
}

var (
	conventionRegex = regexp.MustCompile(`(?i)(?:use|always|never|prefer|must|should|convention|rule|standard)\s+([^.\n]+)`)
	decisionRegex   = regexp.MustCompile(`(?i)(?:decided\s+(?:to|on|that)?|chose|selected|switched\s+to|migrated\s+to|using)\s+([^.\n]+)`)
	dependsRegex    = regexp.MustCompile(`(?i)(?:depends\s+on|requires|requires\s+module|needs)\s+([^.\n]+)`)
	supersedesRegex = regexp.MustCompile(`(?i)(?:replaces|supersedes|deprecates|obsoletes)\s+([^.\n]+)`)
)

// ExtractFacts parses raw session text or tool outputs and distills atomic facts.
func ExtractFacts(text string) []Fact {
	var facts []Fact
	seen := make(map[string]bool)

	lines := strings.Split(text, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		if match := decisionRegex.FindStringSubmatch(line); len(match) > 1 {
			norm := cleanFactText(line)
			if !seen[norm] {
				seen[norm] = true
				facts = append(facts, Fact{
					Subject:    "decision",
					Predicate:  "adopted",
					Object:     strings.TrimSpace(match[1]),
					Category:   "decision",
					Normalized: norm,
				})
			}
		} else if match := conventionRegex.FindStringSubmatch(line); len(match) > 1 {
			norm := cleanFactText(line)
			if !seen[norm] {
				seen[norm] = true
				facts = append(facts, Fact{
					Subject:    "convention",
					Predicate:  "enforce",
					Object:     strings.TrimSpace(match[1]),
					Category:   "convention",
					Normalized: norm,
				})
			}
		} else if match := dependsRegex.FindStringSubmatch(line); len(match) > 1 {
			norm := cleanFactText(line)
			if !seen[norm] {
				seen[norm] = true
				facts = append(facts, Fact{
					Subject:    "dependency",
					Predicate:  "depends_on",
					Object:     strings.TrimSpace(match[1]),
					Category:   "relation",
					Normalized: norm,
				})
			}
		} else if match := supersedesRegex.FindStringSubmatch(line); len(match) > 1 {
			norm := cleanFactText(line)
			if !seen[norm] {
				seen[norm] = true
				facts = append(facts, Fact{
					Subject:    "supersedes",
					Predicate:  "supersedes",
					Object:     strings.TrimSpace(match[1]),
					Category:   "relation",
					Normalized: norm,
				})
			}
		}
	}

	return facts
}

func cleanFactText(s string) string {
	s = strings.TrimPrefix(s, "-")
	s = strings.TrimPrefix(s, "*")
	s = strings.TrimPrefix(s, "#")
	return strings.TrimSpace(s)
}
