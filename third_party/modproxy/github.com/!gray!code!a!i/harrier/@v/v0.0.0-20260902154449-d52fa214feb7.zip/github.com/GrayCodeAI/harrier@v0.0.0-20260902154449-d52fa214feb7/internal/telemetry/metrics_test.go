package telemetry

import (
	"context"
	"os"
	"testing"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/metric"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/metric/metricdata"
)

// reader is the in-memory metric reader installed in TestMain. The package-level
// instruments in metrics.go are created from the OTel *global* meter at import
// time (before any SDK provider exists). The global meter is a delegating
// implementation: once otel.SetMeterProvider installs a real provider, the
// already-created instruments forward their recordings to it. So installing the
// SDK provider in TestMain (after import, before any test records) is sufficient
// to capture writes into the package vars.
var reader *sdkmetric.ManualReader

func TestMain(m *testing.M) {
	reader = sdkmetric.NewManualReader()
	provider := sdkmetric.NewMeterProvider(sdkmetric.WithReader(reader))
	otel.SetMeterProvider(provider)

	code := m.Run()

	_ = provider.Shutdown(context.Background())
	os.Exit(code)
}

// collectMetricNames runs a collection and returns the set of metric names the
// reader observed.
func collectMetricNames(t *testing.T) map[string]struct{} {
	t.Helper()
	var rm metricdata.ResourceMetrics
	if err := reader.Collect(context.Background(), &rm); err != nil {
		t.Fatalf("reader.Collect: %v", err)
	}
	names := make(map[string]struct{})
	for _, sm := range rm.ScopeMetrics {
		for _, md := range sm.Metrics {
			names[md.Name] = struct{}{}
		}
	}
	return names
}

// TestInstrumentsRecord records a value into every instrument declared in
// metrics.go and asserts that each metric name surfaces through the SDK reader.
// This exercises the instrument declarations and confirms they are bound to a
// live meter via the global delegating provider.
func TestInstrumentsRecord(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	histograms := []struct {
		name string
		inst metric.Float64Histogram
	}{
		{"harrier.http.request.duration", HTTPRequestDuration},
		{"harrier.memory.remember.duration", MemoryRememberDuration},
		{"harrier.memory.recall.duration", MemoryRecallDuration},
		{"harrier.memory.retrieve.duration", MemoryRetrieveDuration},
		{"harrier.memory.fused_recall.duration", MemoryFusedRecallDuration},
		{"harrier.sqlite.query.duration", SQLiteQueryDuration},
		{"harrier.hnsw.search.duration", HNSWSearchDuration},
	}
	for _, h := range histograms {
		if h.inst == nil {
			t.Fatalf("histogram %q is nil", h.name)
		}
		h.inst.Record(ctx, 0.01)
	}

	counters := []struct {
		name string
		inst metric.Int64Counter
	}{
		{"harrier.http.request.count", HTTPRequestCount},
		{"harrier.sqlite.query.count", SQLiteQueryCount},
		{"harrier.hnsw.search.count", HNSWSearchCount},
	}
	for _, c := range counters {
		if c.inst == nil {
			t.Fatalf("counter %q is nil", c.name)
		}
		c.inst.Add(ctx, 1)
	}

	names := collectMetricNames(t)

	for _, h := range histograms {
		if _, ok := names[h.name]; !ok {
			t.Errorf("histogram metric %q not present after Record; collected: %v", h.name, names)
		}
	}
	for _, c := range counters {
		if _, ok := names[c.name]; !ok {
			t.Errorf("counter metric %q not present after Add; collected: %v", c.name, names)
		}
	}
}

// TestCounterAccumulates verifies that successive Add calls on a counter sum,
// confirming the counter instrument is wired to a real aggregator (not the
// no-op meter).
func TestCounterAccumulates(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	HNSWSearchCount.Add(ctx, 2)
	HNSWSearchCount.Add(ctx, 3)

	var rm metricdata.ResourceMetrics
	if err := reader.Collect(ctx, &rm); err != nil {
		t.Fatalf("reader.Collect: %v", err)
	}

	var found bool
	var total int64
	for _, sm := range rm.ScopeMetrics {
		for _, md := range sm.Metrics {
			if md.Name != "harrier.hnsw.search.count" {
				continue
			}
			sum, ok := md.Data.(metricdata.Sum[int64])
			if !ok {
				t.Fatalf("harrier.hnsw.search.count: unexpected data type %T", md.Data)
			}
			for _, dp := range sum.DataPoints {
				total += dp.Value
			}
			found = true
		}
	}
	if !found {
		t.Fatal("harrier.hnsw.search.count not collected")
	}
	// Counter is cumulative; this test may run in any order relative to
	// TestInstrumentsRecord (which adds 1). Assert the value is at least the
	// amount this test contributed.
	if total < 5 {
		t.Errorf("expected cumulative count >= 5 from this test's Adds, got %d", total)
	}
}

// TestScopeName asserts the package meter is registered under the expected
// instrumentation scope name from metrics.go.
func TestScopeName(t *testing.T) {
	t.Parallel()
	ctx := context.Background()
	// Ensure at least one instrument has recorded so a scope exists.
	HTTPRequestCount.Add(ctx, 1)

	var rm metricdata.ResourceMetrics
	if err := reader.Collect(ctx, &rm); err != nil {
		t.Fatalf("reader.Collect: %v", err)
	}

	var found bool
	for _, sm := range rm.ScopeMetrics {
		if sm.Scope.Name == meterName {
			found = true
		}
	}
	if !found {
		t.Errorf("instrumentation scope %q not found in collected metrics", meterName)
	}
}
