package hooks

import (
	"context"
	"fmt"
	"strings"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/privacy"
)

// BashExecutionInput represents terminal command execution payload.
type BashExecutionInput struct {
	Command  string `json:"command"`
	ExitCode int    `json:"exit_code"`
	Output   string `json:"output"`
	Error    string `json:"error,omitempty"`
	Project  string `json:"project"`
}

// BashHookRunner handles command line execution events.
type BashHookRunner struct {
	eng     *engine.Engine
	project string
}

// NewBashHookRunner creates a bash execution hook handler.
func NewBashHookRunner(eng *engine.Engine, project string) *BashHookRunner {
	return &BashHookRunner{eng: eng, project: project}
}

// PostExecution processes command execution results.
func (b *BashHookRunner) PostExecution(ctx context.Context, in *BashExecutionInput) error {
	if in == nil || strings.TrimSpace(in.Command) == "" {
		return nil
	}

	// Capture failed commands or build/test commands
	if in.ExitCode != 0 || isHighSignalCommand(in.Command) {
		content := fmt.Sprintf("Command `%s` exited with code %d", in.Command, in.ExitCode)
		if in.Error != "" {
			content += fmt.Sprintf("\nError: %s", truncate(in.Error, 300))
		} else if in.Output != "" {
			content += fmt.Sprintf("\nOutput: %s", truncate(in.Output, 300))
		}

		content = privacy.Filter(content)
		nodeType := "decision"
		if in.ExitCode != 0 {
			nodeType = "bug"
		}

		_, err := b.eng.Remember(ctx, engine.RememberInput{
			Type:    nodeType,
			Content: content,
			Summary: fmt.Sprintf("Command execution: %s (exit %d)", truncate(in.Command, 50), in.ExitCode),
			Scope:   "project",
			Project: b.project,
			Tags:    "bash,cli",
		})
		return err
	}
	return nil
}

func isHighSignalCommand(cmd string) bool {
	lower := strings.ToLower(cmd)
	signals := []string{"go test", "make ", "npm test", "npm run build", "docker build", "pytest", "cargo test"}
	for _, sig := range signals {
		if strings.Contains(lower, sig) {
			return true
		}
	}
	return false
}
