package storage

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func writeBackupFile(t *testing.T, dir string, name string, age time.Duration) string {
	t.Helper()
	path := filepath.Join(dir, name)
	if err := os.WriteFile(path, []byte("backup"+name), 0o600); err != nil {
		t.Fatal(err)
	}
	if age > 0 {
		older := time.Now().Add(-age)
		if err := os.Chtimes(path, older, older); err != nil {
			t.Fatal(err)
		}
	}
	return path
}

func exists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func TestRotateBackupsCount(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	old1 := writeBackupFile(t, dir, "harrier-1.db", 3*time.Hour)
	old2 := writeBackupFile(t, dir, "harrier-2.db", 2*time.Hour)
	old3 := writeBackupFile(t, dir, "harrier-3.db", 1*time.Hour)
	newest := writeBackupFile(t, dir, "harrier-4.db", 0)

	if err := s.RotateBackups(context.Background(), dir, 2, 0); err != nil {
		t.Fatalf("RotateBackups: %v", err)
	}
	if !exists(newest) || !exists(old3) {
		t.Errorf("newest two backups must survive: %v %v", exists(newest), exists(old3))
	}
	if exists(old1) || exists(old2) {
		t.Error("excess backups should be removed")
	}
}

func TestRotateBackupsAge(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	stale := writeBackupFile(t, dir, "harrier-old.db", 48*time.Hour)
	recent := writeBackupFile(t, dir, "harrier-mid.db", 30*time.Minute)
	newest := writeBackupFile(t, dir, "harrier-new.db", 0)

	if err := s.RotateBackups(context.Background(), dir, 0, time.Hour); err != nil {
		t.Fatalf("RotateBackups: %v", err)
	}
	if exists(stale) {
		t.Error("backup older than maxAge should be removed")
	}
	if !exists(recent) || !exists(newest) {
		t.Error("recent backups must survive age-based rotation")
	}
}

func TestRotateBackupsNewestNeverDeletedByAge(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	// A single old backup must never be deleted by age: the store must
	// not end up with zero backups just because it has been idle.
	solo := writeBackupFile(t, dir, "harrier-solo.db", 72*time.Hour)

	if err := s.RotateBackups(context.Background(), dir, 0, time.Hour); err != nil {
		t.Fatalf("RotateBackups: %v", err)
	}
	if !exists(solo) {
		t.Error("the newest backup must survive age-based rotation")
	}
}

func TestRotateBackupsNoLimits(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	for i := 0; i < 5; i++ {
		writeBackupFile(t, dir, fmt.Sprintf("harrier-%d.db", i), time.Duration(i)*time.Hour)
	}
	if err := s.RotateBackups(context.Background(), dir, 0, 0); err != nil {
		t.Fatalf("RotateBackups: %v", err)
	}
	for i := 0; i < 5; i++ {
		if !exists(filepath.Join(dir, fmt.Sprintf("harrier-%d.db", i))) {
			t.Fatalf("backup %d should survive with no limits", i)
		}
	}
}

func TestRotateBackupsSweepsStaleTmp(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	staleTmp := writeBackupFile(t, dir, "harrier.db.123.tmp", 48*time.Hour) // aborted Backup left this
	freshTmp := writeBackupFile(t, dir, "harrier.db.456.tmp", 1*time.Minute)

	if err := s.RotateBackups(context.Background(), dir, 0, 0); err != nil {
		t.Fatalf("RotateBackups: %v", err)
	}
	if exists(staleTmp) {
		t.Error("stale .tmp from an aborted backup should be swept")
	}
	if !exists(freshTmp) {
		t.Error("fresh .tmp must be left alone (its backup may still be writing)")
	}
}

func TestRotateBackupsEmptyDir(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.RotateBackups(context.Background(), t.TempDir(), 2, time.Hour); err != nil {
		t.Fatalf("RotateBackups on empty dir: %v", err)
	}
	if err := s.RotateBackups(context.Background(), "", 2, time.Hour); err == nil {
		t.Error("expected error for empty backup directory")
	}
}

// TestBackupRotationEndToEnd runs Backup a few times with rotation, keeping
// the configured window.
func TestBackupRotationEndToEnd(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{
		ID: "rot-node", Type: "convention", Content: "rotate me",
		ContentHash: "h-rotate", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}

	dir := t.TempDir()
	for i := 0; i < 6; i++ {
		name := filepath.Join(dir, fmt.Sprintf("harrier-%d.db", i))
		if err := s.Backup(ctx, name); err != nil {
			t.Fatalf("Backup #%d: %v", i, err)
		}
		// Ensure distinct mtimes so ordering is unambiguous.
		mt := time.Now().Add(time.Duration(i) * time.Second)
		if err := os.Chtimes(name, mt, mt); err != nil {
			t.Fatal(err)
		}
		if err := s.RotateBackups(ctx, dir, 3, 0); err != nil {
			t.Fatalf("RotateBackups #%d: %v", i, err)
		}
	}

	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	var names []string
	for _, e := range entries {
		names = append(names, e.Name())
	}
	if len(names) != 3 {
		t.Fatalf("expected 3 backups kept, got %d: %v", len(names), names)
	}
	for _, want := range []string{"harrier-3.db", "harrier-4.db", "harrier-5.db"} {
		if !exists(filepath.Join(dir, want)) {
			t.Errorf("expected newest backup %s to be kept: %v", want, names)
		}
	}
}
