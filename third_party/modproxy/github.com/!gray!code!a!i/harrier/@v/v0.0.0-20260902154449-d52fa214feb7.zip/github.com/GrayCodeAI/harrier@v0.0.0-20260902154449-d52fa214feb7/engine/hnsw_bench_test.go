package engine

import (
	"math/rand"
	"testing"
)

func BenchmarkHNSWSearch(b *testing.B) {
	h := NewHNSW(128)
	rng := rand.New(rand.NewSource(42))

	// Insert 1000 random vectors
	for i := 0; i < 1000; i++ {
		vec := make([]float32, 128)
		for j := range vec {
			vec[j] = rng.Float32()
		}
		h.Insert(string(rune('a'+i%26))+string(rune('0'+i/26%10)), vec)
	}

	query := make([]float32, 128)
	for j := range query {
		query[j] = rng.Float32()
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.Search(query, 10)
	}
}

func BenchmarkHNSWInsert(b *testing.B) {
	h := NewHNSW(128)
	rng := rand.New(rand.NewSource(42))

	vecs := make([][]float32, b.N)
	for i := range vecs {
		vec := make([]float32, 128)
		for j := range vec {
			vec[j] = rng.Float32()
		}
		vecs[i] = vec
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.Insert(string(rune('a'+i%26))+string(rune('0'+i/26%10)), vecs[i])
	}
}

func BenchmarkHNSWDistance(b *testing.B) {
	h := NewHNSW(384)
	a := make([]float32, 384)
	bb := make([]float32, 384)
	rng := rand.New(rand.NewSource(42))
	for i := range a {
		a[i] = rng.Float32()
		bb[i] = rng.Float32()
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.distance(a, bb)
	}
}
