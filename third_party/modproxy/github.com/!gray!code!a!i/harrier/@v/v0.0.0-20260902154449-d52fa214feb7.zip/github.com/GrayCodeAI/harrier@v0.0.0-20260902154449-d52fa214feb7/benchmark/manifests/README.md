# Harrier Benchmark Manifests

This directory is the machine-readable registry for Harrier benchmark suites.

Rules:

- manifests must match the suite ids documented in `../README.md`
- `published: false` means the suite is official but no committed run is present yet
- publication directories referenced by manifests must exist
