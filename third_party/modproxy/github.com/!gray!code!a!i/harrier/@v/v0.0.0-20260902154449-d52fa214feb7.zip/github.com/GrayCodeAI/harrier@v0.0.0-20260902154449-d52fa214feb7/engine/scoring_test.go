package engine

import (
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestNormalizeBM25(t *testing.T) {
	t.Parallel()
	// Short query: midpoint=5, steepness=0.7
	score1 := NormalizeBM25(10.0, 2) // high raw score, short query
	if score1 < 0.9 {
		t.Errorf("high BM25 + short query should give >0.9, got %f", score1)
	}

	score2 := NormalizeBM25(1.0, 2) // low raw score
	if score2 > 0.1 {
		t.Errorf("low BM25 + short query should give <0.1, got %f", score2)
	}

	// Long query: midpoint=12, steepness=0.4
	score3 := NormalizeBM25(10.0, 20)
	if score3 > 0.7 {
		t.Errorf("medium BM25 + long query should be moderate, got %f", score3)
	}

	// All normalized scores should be in [0, 1]
	for _, raw := range []float64{0, 1, 5, 10, 20, 50, 100} {
		for _, terms := range []int{1, 3, 6, 10, 20} {
			s := NormalizeBM25(raw, terms)
			if s < 0 || s > 1 {
				t.Errorf("NormalizeBM25(%f, %d) = %f, want [0,1]", raw, terms, s)
			}
		}
	}
}

func TestQueryTermCount(t *testing.T) {
	t.Parallel()
	tests := []struct {
		query string
		want  int
	}{
		{"auth library", 2},
		{"a b c", 0},                            // all too short
		{"what is the auth library we use?", 5}, // what(4), the(3), auth(4), library(7), use?(4)
		{"", 0},
	}
	for _, tt := range tests {
		got := QueryTermCount(tt.query)
		if got != tt.want {
			t.Errorf("QueryTermCount(%q) = %d, want %d", tt.query, got, tt.want)
		}
	}
}

func TestSpreadAttenuatedBoost(t *testing.T) {
	t.Parallel()
	// Single link: no spread penalty
	boost1 := SpreadAttenuatedBoost(1.0, 1, 0.001)
	if boost1 < 0.49 || boost1 > 0.51 {
		t.Errorf("single link boost should be ~0.5, got %f", boost1)
	}

	// Many links: heavy spread penalty
	boost10 := SpreadAttenuatedBoost(1.0, 50, 0.001)
	if boost10 >= boost1 {
		t.Errorf("50-link boost (%f) should be less than single-link (%f)", boost10, boost1)
	}

	// Zero links: no boost
	boost0 := SpreadAttenuatedBoost(1.0, 0, 0.001)
	if boost0 != 0 {
		t.Errorf("zero links should give 0 boost, got %f", boost0)
	}
}

func TestMMRRerank(t *testing.T) {
	t.Parallel()
	nodes := []*storage.Node{
		{ID: "n1", Content: "Use jose library for JWT authentication tokens"},
		{ID: "n2", Content: "Use jose library for JWT auth (duplicate-ish)"},
		{ID: "n3", Content: "Deploy to fly.io using Docker containers"},
		{ID: "n4", Content: "PostgreSQL for database with JSONB support"},
	}

	scores := map[string]float64{
		"n1": 0.95,
		"n2": 0.93, // very similar to n1 but slightly lower score
		"n3": 0.70,
		"n4": 0.60,
	}

	// With MMR (lambda=0.5, strong diversity preference)
	reranked := MMRRerank(nodes, scores, 0.5, 3)
	if len(reranked) != 3 {
		t.Fatalf("expected 3 results, got %d", len(reranked))
	}

	// n1 should still be first (highest relevance)
	if reranked[0].ID != "n1" {
		t.Errorf("first result should be n1 (highest relevance), got %s", reranked[0].ID)
	}

	// n2 should be penalized for being similar to n1
	// So n3 or n4 should come before n2 with strong diversity
	hasN2InTop2 := reranked[1].ID == "n2"
	if hasN2InTop2 {
		t.Log("n2 in position 2 — MMR diversity may be weak for this test case")
	}
}

func TestMMRRerank_SingleNode(t *testing.T) {
	t.Parallel()
	nodes := []*storage.Node{{ID: "only", Content: "test"}}
	scores := map[string]float64{"only": 1.0}

	result := MMRRerank(nodes, scores, 0.7, 5)
	if len(result) != 1 {
		t.Errorf("single node should return 1 result, got %d", len(result))
	}
}

func TestMMRRerank_EmptyInput(t *testing.T) {
	t.Parallel()
	result := MMRRerank(nil, nil, 0.7, 5)
	if result != nil {
		t.Error("nil input should return nil")
	}
}
