package engine

import (
	"github.com/GrayCodeAI/harrier/privacy"
)

// PrivacyConfig holds the privacy filtering configuration for the engine.
// Controls how aggressively sensitive information is redacted from memories
// before they are stored.
type PrivacyConfig struct {
	Level        privacy.FilterLevel `json:"level"`
	StripPrivate bool                `json:"strip_private"` // strip <private>...</private> tags
}

// DefaultPrivacyConfig returns the standard configuration (moderate filtering).
func DefaultPrivacyConfig() PrivacyConfig {
	return PrivacyConfig{
		Level:        privacy.Moderate,
		StripPrivate: true,
	}
}

// WithPrivacyLevel sets the privacy filter level on the engine.
// Levels: privacy.Strict, privacy.Moderate, privacy.Minimal.
func (e *Engine) WithPrivacyLevel(level privacy.FilterLevel) *Engine {
	e.privacyCfg = PrivacyConfig{
		Level:        level,
		StripPrivate: true,
	}
	return e
}

// WithPrivacyConfig sets the full privacy configuration on the engine.
func (e *Engine) WithPrivacyConfig(cfg PrivacyConfig) *Engine {
	e.privacyCfg = cfg
	return e
}

// PrivacyLevel returns the current privacy filter level.
func (e *Engine) PrivacyLevel() privacy.FilterLevel {
	return e.privacyCfg.Level
}

// FilterContent applies the engine's privacy filter to content.
// Uses the engine's configured privacy level rather than the package default.
func (e *Engine) FilterContent(content string) string {
	result := privacy.FilterWithLevel(content, e.privacyCfg.Level)
	if e.privacyCfg.StripPrivate {
		result = stripPrivateTags(result)
	}
	return result
}
