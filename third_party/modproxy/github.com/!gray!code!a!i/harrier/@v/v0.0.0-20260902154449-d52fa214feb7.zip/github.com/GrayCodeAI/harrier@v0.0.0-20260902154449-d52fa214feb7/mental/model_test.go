package mental

import (
	"strings"
	"testing"
)

func TestModel_Format_Empty(t *testing.T) {
	t.Parallel()
	m := &Model{Project: "test"}
	out := m.Format()
	if !strings.Contains(out, "## Project Mental Model") {
		t.Error("expected header in format output")
	}
}

func TestModel_Format_WithData(t *testing.T) {
	t.Parallel()
	m := &Model{
		Project:     "myapp",
		Summary:     "Stack: Go, PostgreSQL. 2 conventions.",
		Stack:       []string{"Go", "PostgreSQL"},
		Conventions: []string{"Use camelCase", "Always run tests"},
		ActiveTasks: []string{"Add rate limiting"},
	}
	out := m.Format()
	if !strings.Contains(out, "**Stack**: Go, PostgreSQL") {
		t.Errorf("expected stack in output, got: %s", out)
	}
	if !strings.Contains(out, "- Use camelCase") {
		t.Error("expected conventions in output")
	}
	if !strings.Contains(out, "- Add rate limiting") {
		t.Error("expected active tasks in output")
	}
}

func TestBuildSummary_Empty(t *testing.T) {
	t.Parallel()
	m := &Model{}
	s := buildSummary(m)
	if s != "No memories yet." {
		t.Errorf("expected 'No memories yet.', got %q", s)
	}
}

func TestBuildSummary_WithData(t *testing.T) {
	t.Parallel()
	m := &Model{
		Stack:        []string{"Go", "Redis"},
		Conventions:  []string{"a", "b"},
		KeyDecisions: []string{"x"},
		ActiveTasks:  []string{"y", "z"},
	}
	s := buildSummary(m)
	if !strings.Contains(s, "Stack: Go, Redis") {
		t.Error("expected stack in summary")
	}
	if !strings.Contains(s, "2 conventions") {
		t.Error("expected convention count")
	}
	if !strings.Contains(s, "1 key decisions") {
		t.Error("expected decision count")
	}
	if !strings.Contains(s, "2 active tasks") {
		t.Error("expected task count")
	}
}

func TestIsStackTech(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name   string
		expect bool
	}{
		{"Go", true},
		{"go", true},
		{"React", true},
		{"PostgreSQL", true},
		{"Docker", true},
		{"randomlib", false},
		{"MyCustomPkg", false},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := isStackTech(tt.name); got != tt.expect {
				t.Errorf("isStackTech(%q) = %v, want %v", tt.name, got, tt.expect)
			}
		})
	}
}
