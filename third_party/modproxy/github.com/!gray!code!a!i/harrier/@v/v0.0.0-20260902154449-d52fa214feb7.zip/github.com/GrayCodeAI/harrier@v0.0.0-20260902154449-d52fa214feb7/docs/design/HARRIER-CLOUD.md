# Harrier Cloud — Managed Memory Platform

**Status:** Draft design doc (for team execution, multi-quarter)
**Author:** Platform / Memory team
**Last updated:** 2026-06-06
**Scope:** Turn harrier from a local-only, single-user SQLite memory engine into a hosted, multi-tenant managed memory platform — without compromising the privacy-first, local-first guarantees that define the hawk-eco ecosystem.

---

## 1. Overview & Competitive Context

harrier today is a local, single-process, graph-native memory engine. It ships a CGO-free SQLite store (`harrier/storage/sqlite.go`), an FTS5 + vector hybrid recall pipeline, a REST API (`harrier/internal/server/rest.go`), an MCP server (`harrier/internal/server/mcp_*.go`), and a standalone D3 force-graph HTML export (`harrier/engine/export_html.go`). It is fast, private, and architecturally ahead of competitors on graph semantics. What it lacks is a **product surface and managed plane**.

The Top-20 gap analysis (`TOP20_COMPARISON.md`) calls this out explicitly. The single harrier **P0** gap is:

> **Managed cloud platform with dashboard/UI for memory inspection** — *"Mem0 (app.mem0.ai: managed platform with audit logs, workspace governance, webhooks, multimodal support), Letta Cloud. Harrier is local-only SQLite."* (`TOP20_COMPARISON.md:134`)

And several harrier **P1/P2** gaps are sub-features of the same managed-platform story:

- **Memory search UI / inspector** for human-readable exploration — Mem0 Cloud dashboard, Letta memory inspection UI (`TOP20_COMPARISON.md:147`).
- **Auth & API keys management for harrier server** — *"Currently harrier is unauth'd local-only — this is [a gap]"* (`TOP20_COMPARISON.md:146`). (Partially closed already; see §4.)
- **Official client libraries (Mem0-compatible) for Python (pip) and TypeScript (npm)** — *"Publish official harrier client libraries... that implement the Mem0-compatible interface"* (`TOP20_COMPARISON.md:145`).
- **Published benchmark numbers (LongMemEval, LoCoMo, BEAM)** — *"harrier's benchmark harness exists but is not yet executed and published"* (`TOP20_COMPARISON.md:144`).
- **Multi-modal memory support (images, diagrams, code screenshots)** — *"Phase 5 in harrier's roadmap with no timeline"* (`TOP20_COMPARISON.md:157`).
- **Proactive memory / intent prediction** — memU's core differentiator; *"Phase 3 in harrier's PLAN.md"* (`TOP20_COMPARISON.md:159`).
- **Shared memory across parallel user experiences (Letta Conversations API pattern)** — *"Harrier's multi-agent support uses WAL-based isolation"* (`TOP20_COMPARISON.md:156`).

**Which Top-20 repos ship this today:** Mem0 (app.mem0.ai — managed dashboard, workspace governance, audit logs, webhooks, multimodal), Letta Cloud (memory inspection UI, Conversations API for shared parallel memory), Zep/Graphiti (hosted temporal graph). harrier currently ships none of the hosted pieces but already has the *engine primitives* most of them require — which makes this a packaging and platform effort more than a from-scratch build.

This doc treats "Harrier Cloud" as one coherent product made of seven workstreams: hosted dashboard/UI, workspace governance + audit, webhooks, multimodal memory, official client libraries, a published benchmark plan, and a shared-memory Conversations API. Each is grounded in existing harrier packages.

---

## 2. Goals / Non-Goals

### Goals

1. **A hosted, multi-tenant control plane** that runs the existing harrier engine per-workspace, reachable over the internet, with API-key auth and workspace isolation.
2. **A web dashboard** for memory inspection — graph visualization, search, manual curation (edit/pin/forget) — built on the existing D3 force-graph (`engine/export_html.go`) and dashboard (`internal/server/dashboard.html`), not a greenfield SPA.
3. **Workspace governance**: organizations, workspaces, members, roles, and a durable, queryable audit log (today's `engine/audit.go` is local append-only JSONL — must become per-workspace and queryable).
4. **Webhooks** so external systems are notified on memory mutations, reusing the existing in-process event bus (`engine/events.go`).
5. **Multimodal memory**: image embeddings stored and recalled alongside text, reusing the `embeddings.Provider` interface (`embeddings/provider.go`).
6. **Official Mem0-compatible client libraries** for Python (pip) and TypeScript (npm) wrapping the REST API, replacing today's thin hand-rolled SDKs (`sdk/python`, `sdk/typescript`).
7. **A published benchmark report** (LongMemEval, LoCoMo, BEAM) built on the existing harness (`internal/bench/bench.go`).
8. **Proactive memory / intent prediction** surfaced as a first-class API + dashboard panel, building on `engine/proactive.go` and `intent/intent.go`.
9. **A shared-memory Conversations API** (Letta-style) that lets multiple concurrent agent sessions read/write a shared memory scope, building on the existing `source_session` / `source_agent` tagging (`storage/sqlite.go:93`) and WAL single-writer model.

### Non-Goals

- **Replacing the local mode.** Local-first, offline, zero-network harrier remains the default and a first-class product. Cloud is opt-in.
- **Building our own LLM inference or embedding hosting.** We call existing providers via `embeddings.Provider` and eyrie.
- **A billing/metering system in P0.** Usage accounting hooks are designed in but billing is deferred (see Open Questions).
- **Migrating the storage engine off SQLite in P0.** We scale horizontally via per-workspace SQLite databases first; Postgres/distributed storage is a P2 investigation, not a commitment.
- **Self-serve enterprise SSO/SAML in P0.** API keys + OIDC for the dashboard only; SAML is P2.
- **Server-side data mining of customer memory.** Privacy-first means we do not read, embed for our own models, or analytics-mine tenant content (see §7).

---

## 3. Architecture

### 3.1 Components

```
                          ┌─────────────────────────────────────────┐
                          │              Harrier Cloud                  │
                          │                                          │
  Browser  ──── HTTPS ───►│  Dashboard (static, served by gateway)   │
                          │     │ D3 graph (from export_html.go)      │
                          │     │ search / curate / audit / proactive │
                          │     ▼                                     │
  pip / npm ─── HTTPS ───►│  API Gateway (new)                       │
  client libs             │   - TLS, API-key & OIDC auth             │
                          │   - org/workspace/member/role model      │
                          │   - per-workspace routing                │
                          │   - audit sink + webhook dispatcher      │
                          │   - usage accounting hooks               │
                          │            │                             │
                          │            ▼                             │
                          │  Engine Pool (existing harrier engine)      │
                          │   one Engine + Storage per workspace     │
                          │   - REST handlers (rest.go, reused)      │
                          │   - SSE event bus (events.go)            │
                          │   - hybrid recall / graph                │
                          │            │                             │
                          │            ▼                             │
                          │  Per-workspace SQLite (storage/sqlite.go)│
                          │   on durable volume / object store       │
                          └─────────────────────────────────────────┘
                                       │
                                       ▼
                          External webhook receivers (CRM, Slack, CI)
```

Key design choice: **the control plane wraps the existing engine; it does not rewrite it.** The gateway is a thin multi-tenant front that authenticates, resolves a workspace, and dispatches to a per-workspace `engine.Engine`/`storage.Storage` instance — the same types used in local mode. This keeps the recall/graph/decay logic single-sourced and lets the same binary run locally or hosted.

### 3.2 Data Model

**New control-plane tables** (separate metadata DB, not the per-workspace memory DBs):

| Table | Columns (sketch) | Purpose |
|-------|------------------|---------|
| `organizations` | `id, name, created_at` | Billing/governance boundary |
| `workspaces` | `id, org_id, name, db_path, embed_provider, created_at` | One memory engine each; maps to a harrier SQLite file |
| `members` | `id, org_id, user_id, role` | role ∈ {owner, admin, member, viewer} |
| `api_keys` | `id, workspace_id, hash, scopes, rate_limit, created_at, revoked_at` | Per-workspace keys; hashed at rest |
| `audit_log` | `id, workspace_id, actor, op, node_id, node_type, details, ts` | Queryable governance audit (see §3.5) |
| `webhooks` | `id, workspace_id, url, secret, events[], active` | Webhook subscriptions |
| `webhook_deliveries` | `id, webhook_id, event, status, attempts, last_error, ts` | Delivery log + retry state |

**Reused per-workspace memory schema** — no change required for governance; the existing `nodes` table already carries the columns the Conversations API needs:

- `source_session TEXT, source_agent TEXT` (`storage/sqlite.go:93,405-406`) — already written on every `CreateNode` (`sqlite.go:526-529`) and filterable via `NodeFilter.SourceSession` (`sqlite.go:722-724`). This is the substrate for shared-conversation attribution.
- `Edge.ValidAt / Edge.InvalidAt` (`storage/sqlite.go:103-104`) — temporal validity windows already in the edge model, surfaced in the dashboard timeline.
- `Node.Metadata map[string]string` (`sqlite.go:95`, stored in `node_metadata`) — where multimodal references (image URI, mime, embedding dims) are attached.

**New per-workspace columns for multimodal** (additive migration):

- `nodes.modality TEXT DEFAULT 'text'` — `'text' | 'image'`.
- An image blob/URI is stored out-of-row (object store) and referenced via `node_metadata` (`image_uri`, `image_mime`, `embed_model`). The vector goes in the existing `vectors` table (`storage/vectors.go`) — embeddings are already `[]float32` regardless of source modality.

### 3.3 API Surface

The hosted REST API is the **same `/harrier/*` surface** already implemented in `rest.go` (routes registered at `rest.go:242-316`), namespaced per workspace and authenticated. The gateway adds a thin control-plane surface and a Mem0-compatible alias surface:

**Reused (already implemented):** `POST /harrier/remember`, `POST /harrier/recall`, `GET /harrier/context`, `POST /harrier/link`, `GET /harrier/node/{id}`, `GET /harrier/subgraph/{id}`, `GET /harrier/proactive` (`rest.go:262`), `GET /harrier/stream/memories` (SSE, `rest.go:312`), `POST /harrier/export/json`, `POST /harrier/bench` (`rest.go:275`), plus the agent-file bridge (`rest.go:300-302`).

**New control-plane endpoints:**

```
POST   /v1/orgs/{org}/workspaces                  create workspace
GET    /v1/workspaces/{ws}/members                list / manage members + roles
POST   /v1/workspaces/{ws}/api-keys               mint key (returns once)
DELETE /v1/workspaces/{ws}/api-keys/{id}          revoke
GET    /v1/workspaces/{ws}/audit?op=&actor=&since= query audit log
POST   /v1/workspaces/{ws}/webhooks               subscribe (url, events[], secret)
GET    /v1/workspaces/{ws}/webhooks/{id}/deliveries
```

**Mem0-compatible alias surface** (for drop-in client libs and migration):

```
POST   /v1/memories         → maps to /harrier/remember (messages[] → nodes)
GET    /v1/memories/search  → maps to /harrier/recall
GET    /v1/memories         → maps to /harrier/context / ListNodes
DELETE /v1/memories/{id}    → maps to /harrier/forget/{id}
```

The alias layer lives in the gateway and translates Mem0's request/response shape into harrier's `engine.RememberInput` / `engine.RecallOpts` (the structs `rest.go:319,346` already decode).

### 3.4 Key Flow Sequences

**(a) Authenticated recall (hosted):**

```
client lib → gateway: GET /v1/memories/search  (Authorization: Bearer <key>)
gateway: hash key → lookup api_keys → resolve workspace + scopes + rate limit
gateway: rate-limit check (reuse engine.RateLimiter, rest.go:56)
gateway → engine[ws].Recall(ctx, opts)        (existing handler logic)
engine → storage[ws]: FTS5 + vector hybrid recall
gateway: write audit_log row (op=recall, actor=key-id)
gateway → client: results (Mem0-shaped)
```

**(b) Memory mutation → webhook fan-out:**

```
client → gateway → engine.Remember()           (rest.go:319 handler)
engine.emitMemoryEvent(MemoryCreated, node)     (events.go:101)  → eventBus.publish
  ├─► SSE subscribers (dashboard live view; handleWatchMemories rest.go:312)
  └─► webhook dispatcher (NEW subscriber on the same bus)
        dispatcher: match event kind ∈ webhook.events
        dispatcher: POST signed payload (HMAC-SHA256 of body with webhook.secret)
        dispatcher: record webhook_deliveries; retry w/ backoff on non-2xx
```

The webhook dispatcher is just **another `SubscribeMemoryEvents()` consumer** (`events.go:95`). No engine changes; the bus already fans out `created/updated/deleted` (`events.go:13-20`).

**(c) Multimodal remember:**

```
client → gateway: POST /v1/memories  { image: <bytes|uri>, ... }
gateway: store blob in object store → image_uri
gateway → embeddings.Provider.Embed(image-derived input)   (provider.go:36)
gateway → engine.Remember(modality=image, metadata{image_uri,...})
storage: node row + vectors row (same vector path as text)
```

**(d) Shared-conversation write (Conversations API):**

```
agent A (session=s1) → POST /v1/conversations/{cid}/memories
agent B (session=s2) → POST /v1/conversations/{cid}/memories  (concurrent)
gateway: map conversation cid → shared workspace scope
engine.Remember(SourceSession=s1|s2, SourceAgent=A|B)   (sqlite.go:526-529)
  WAL single-writer serializes writes; readers never block (sqlite.go:252-254)
recall within conversation: NodeFilter{...} unioned across sessions of cid
```

### 3.5 Audit Log (governance-grade)

Today's `engine/audit.go` is a **local append-only JSONL file** (`audit.jsonl`, `audit.go:34`) with `Log(op, nodeID, nodeType, agent, details)` (`audit.go:46`). For the cloud it must become:

- **Per-workspace and queryable** (control-plane `audit_log` table, indexed by `workspace_id, op, actor, ts`).
- **Actor-aware** — `actor` = API-key id or dashboard user, not just `agent`.
- **Written on every governed op** — the gateway wraps each handler; the existing `AuditEntry` shape (`audit.go:23-30`) is the row schema, extended with `workspace_id` and `actor`.

The local JSONL audit stays as-is for local mode; the cloud sink is an additional implementation behind a small `AuditSink` interface.

---

## 4. Integration With Existing hawk-eco Code (what's reusable today)

This is the crux: **most primitives already exist.** Harrier Cloud is largely packaging + a multi-tenant front, not new memory science.

| Cloud feature | Already in repo | Reuse / change needed |
|---------------|-----------------|------------------------|
| Graph dashboard | `engine/export_html.go` `ExportHTML` (D3 force-graph, `export_html.go:14-104`) + `internal/server/dashboard.html` served at `/harrier/ui` (`dashboard.go`) | Promote from static export to a live, auth'd, multi-workspace dashboard; wire to SSE (`rest.go:312`) for live updates. The D3 rendering, color map, zoom/drag are done. |
| REST API surface | `internal/server/rest.go` (full `/harrier/*` surface, `rest.go:242-316`) | Wrap with per-workspace routing; add Mem0 alias translation. Handlers (`Remember`/`Recall`) reused verbatim. |
| API-key auth | `RESTServer.apiKey` + `WithAPIKey` + Bearer/X-API-Key middleware w/ constant-time compare (`rest.go:52,80-84,171-176`) | Generalize from one static key to a per-workspace `api_keys` table with scopes + rotation. The auth *plumbing* (header parsing, `crypto/subtle`) is already correct. |
| Audit log | `engine/audit.go` (`AuditLog`, `AuditEntry`, `Log()`) | Add a queryable per-workspace sink behind an `AuditSink` interface; keep JSONL for local. |
| Webhooks | `engine/events.go` (`eventBus`, `SubscribeMemoryEvents`, `emitMemoryEvent`, kinds `created/updated/deleted`) | Add a webhook dispatcher that subscribes to the bus. SSE already proves the fan-out works (`handleWatchMemories`, `rest.go:312`). **No engine change.** |
| Multimodal embeddings | `embeddings/provider.go` `Provider` interface (`provider.go:36-42`); Cohere (`embeddings/cohere.go`), OpenAI, Voyage impls; `EmbedMode` doc/query asymmetry | Add an image-capable provider impl (e.g. Cohere multimodal / a vision embedder) behind the *same interface*. Vectors stored via existing `storage/vectors.go`; recall path is modality-agnostic. |
| Client libraries | `sdk/python/harrier/client.py`, `sdk/typescript/src/index.ts` (thin, hand-rolled, **no auth header, no Mem0 shape**) | Rewrite as Mem0-compatible, auth-aware, packaged for pip/npm. Current SDKs are a starting skeleton, not shippable (e.g. `client.py` sends no `Authorization` header). |
| Benchmark report | `internal/bench/bench.go` (LongMemEval-style harness: `QA`, `Result` with R@K/MRR/tokens, `bench.go:1-2,14-44`) + `benchmark/benchmark_test.go` (Go perf benches) + `POST /harrier/bench` (`rest.go:275`) | Wire real LongMemEval/LoCoMo/BEAM datasets into the harness, run, publish. Metrics shape (R@1/3/5/10, MRR) already implemented. |
| Proactive prediction | `engine/proactive.go` `ProactiveContext.Predict` (recent + task-deps + centrality, `proactive.go:26-103`) + `intent/intent.go` `Classify`/`Weights` (MAGMA-based) + `GET /harrier/proactive` (`rest.go:262`) | Surface as a dashboard panel + dedicated API. Algorithm exists; needs productization (per-conversation context, ranking explanation). |
| Conversations API | `source_session`/`source_agent` columns + `NodeFilter.SourceSession` (`sqlite.go:93,722-724`); WAL single-writer (`sqlite.go:244-254`) | Add a conversation scope (set of sessions) + union recall + shared-write semantics. The attribution + concurrency substrate is in place. |
| Temporal timeline | `Edge.ValidAt`/`InvalidAt` (`sqlite.go:103-104`), `engine/temporal_validity.go` | Render fact-validity windows in the dashboard timeline view. |
| Telemetry | `internal/telemetry` (OTel attrs/metrics imported in `sqlite.go:15-17`, `rest.go:24,31-32`) | Reuse for per-workspace usage accounting + observability. |

**Net assessment:** of the seven workstreams, five (dashboard, webhooks, audit, client libs, benchmark) are mostly *surfacing existing engine capability*; two (multimodal, Conversations API) need modest engine additions; and the genuinely new build is the **multi-tenant gateway** (auth, org/workspace model, routing, accounting). That gateway is the single largest piece of new code.

---

## 5. Phased Rollout

### P0 — Foundation & Self-Host (≈ first quarter)

**Milestone P0.1 — Multi-tenant gateway skeleton.** New control-plane metadata DB (`organizations`, `workspaces`, `members`, `api_keys`). Gateway resolves Bearer key → workspace → per-workspace `engine.Engine`. Generalize the existing single-key middleware (`rest.go:171-176`) to the keystore. Per-workspace SQLite on a durable volume.

**Milestone P0.2 — Hosted dashboard (read + curate).** Serve the existing D3 graph (`export_html.go`) + `dashboard.html` behind OIDC login, scoped to a workspace, with live updates via the existing SSE stream (`rest.go:312`). Search (reuse `/harrier/recall`), node merlin, pin/forget.

**Milestone P0.3 — Queryable audit log.** `AuditSink` interface; cloud sink writes per-workspace rows; gateway wraps every governed handler. `GET /v1/workspaces/{ws}/audit` query API + dashboard audit view.

**Milestone P0.4 — Official client libraries v1.** Mem0-compatible Python (pip `harrier`) + TypeScript (npm `@graycode/harrier`) wrapping the REST API with auth headers and the `/v1/memories` alias surface. Replaces `sdk/python` + `sdk/typescript`.

**Exit criteria:** a user can sign up, create a workspace, mint an API key, write/recall memories from pip/npm, and merlin the graph + audit log in a browser.

### P1 — Governance, Webhooks, Benchmarks (≈ second quarter)

**Milestone P1.1 — Workspace governance.** Roles (owner/admin/member/viewer), invitations, per-key scopes + rate limits (extend `engine.RateLimiter`, `rest.go:56`), key rotation.

**Milestone P1.2 — Webhooks.** `webhooks` + `webhook_deliveries` tables; dispatcher subscribing to `events.go` bus; HMAC-signed payloads; retry with backoff; dashboard delivery log + test-send.

**Milestone P1.3 — Published benchmark report.** Wire LongMemEval, LoCoMo, and BEAM datasets into `internal/bench`; run; publish R@K/MRR/cost numbers in README + docs site, comparing against Mem0 v3 (94.8 LongMemEval / 91.6 LoCoMo per `TOP20_COMPARISON.md:143-144`). Add to CI as a tracked regression metric.

**Milestone P1.4 — Proactive memory API + panel.** Productize `proactive.go` + `intent.go`: a `/v1/conversations/{cid}/predict` endpoint that returns predicted-relevant memories with ranking rationale; a dashboard "likely next context" panel.

**Exit criteria:** teams can self-govern access, receive webhook events, and harrier has public benchmark numbers.

### P2 — Multimodal & Shared Conversations (≈ third quarter)

**Milestone P2.1 — Multimodal memory.** Image-capable `embeddings.Provider` impl; `modality` column + object-store blob storage; multimodal remember/recall; dashboard image thumbnails on nodes.

**Milestone P2.2 — Conversations API (shared memory).** Conversation scope (set of sessions); union recall across `source_session` (`sqlite.go:722-724`); shared-write semantics validated against WAL single-writer; concurrency tests for parallel agents. Letta-compatible shape where reasonable.

**Milestone P2.3 — Scale & storage investigation.** Evaluate per-workspace SQLite at scale vs. a Postgres/pgvector or object-backed option; usage accounting → billing readiness.

**Exit criteria:** image memories work end-to-end; multiple agents share a conversation's memory concurrently without corruption.

---

## 6. Build vs Buy & Dependencies

| Concern | Decision | Rationale / licensing |
|---------|----------|------------------------|
| Memory engine | **Build (reuse)** | Already ours (`engine/`, `storage/`). Differentiator. |
| Multi-tenant gateway | **Build** | Thin; must wrap our engine; no off-the-shelf fit. Go stdlib `net/http` (already used, `rest.go`). |
| Dashboard frontend | **Build (extend existing)** | D3 graph already written (`export_html.go`); avoid a heavyweight SPA framework in P0. D3.js is BSD-3 (permissive). |
| Auth (dashboard) | **Buy/integrate** | OIDC via a hosted IdP (Auth0/Clerk/Cognito) or self-host Keycloak (Apache-2.0). API-key plumbing is build (already present). |
| Embeddings (incl. image) | **Buy (API)** | Existing `Provider` impls call OpenAI/Cohere/Voyage. Image embedder = Cohere multimodal or a vision model via API. No new license risk. |
| Object store (image blobs, workspace DBs) | **Buy** | S3/GCS/R2. Standard. |
| Webhook delivery | **Build** | Trivial on top of `events.go`. |
| Benchmark datasets | **Buy/obtain** | LongMemEval, LoCoMo, BEAM are public research datasets — **verify each dataset's license/terms before redistribution** (some are research-use-only; we may publish *scores* without redistributing data). |
| Billing/metering | **Defer / Buy** | Stripe when needed; out of P0 scope. |

**Licensing implications to track:**
- harrier's own license must permit a hosted/SaaS offering (confirm the repo license; AGPL would have implications for the hosted plane and client libs — verify before launch).
- Benchmark dataset terms (LongMemEval/LoCoMo/BEAM): publish methodology + scores; do not redistribute datasets unless terms allow.
- Client libs (pip/npm) should ship under a permissive license to maximize adoption (consistent with the rest of the SDK story).
- `modernc.org/sqlite` (CGO-free, `sqlite.go:19-20`) is BSD-style — fine for hosted use.

---

## 7. Security & Privacy Considerations

The hawk-eco ecosystem is **privacy-first and local-first**. Cloud must not erode that.

1. **Local mode stays default and fully offline.** Cloud is opt-in. No telemetry of memory *content* ever leaves the user's machine in local mode. The same binary serves both; cloud features are gated by explicit configuration.
2. **Tenant isolation by construction.** One SQLite DB per workspace (separate files), not a shared multi-tenant table with a `tenant_id` filter — eliminates an entire class of cross-tenant query bugs. The gateway resolves workspace *before* touching any engine.
3. **No server-side mining of tenant content.** We do not embed tenant memories into our own models, run analytics over content, or read memories except to serve the tenant's own requests. State this in the privacy policy and enforce in code review.
4. **API keys hashed at rest**, shown once on creation, scoped, revocable, rate-limited. Reuse the constant-time compare already in place (`rest.go:171-176`, `crypto/subtle`).
5. **Webhooks signed (HMAC-SHA256) with a per-subscription secret**; receivers verify. Egress allowlist / SSRF protection on webhook URLs (block internal ranges).
6. **Audit log is governance-grade and tamper-evident.** Append-only semantics (today's JSONL is append-only, `audit.go:37`); cloud rows are immutable; consider hash-chaining entries.
7. **Encryption.** TLS in transit (TLS config already supported, `rest.go:71-76`); at-rest encryption for workspace DBs and image blobs in object store.
8. **Data residency & deletion.** Per-workspace DBs make export and hard-delete straightforward (reuse `/harrier/export/json` `rest.go:268`); honor deletion requests by dropping the workspace DB + blobs.
9. **Multimodal PII.** Images may contain faces/secrets/PII. Apply the existing privacy filter path (`engine/privacy_config.go`, `rest.go` privacy endpoints `rest.go:308-309`) before embedding; allow workspaces to disable image storage.
10. **Conversations API leakage.** Shared memory must respect that `source_agent`/`source_session` tagging stays intact so a shared scope cannot be used to exfiltrate another tenant's data — conversation scopes are always within a single workspace.

---

## 8. Open Questions

1. **Storage at scale.** Does per-workspace SQLite hold up for large/active workspaces, or do we need Postgres/pgvector for the busiest tenants? (P2 investigation.) The engine abstracts on the `storage.Storage` interface (`storage/interface.go`), which makes a second backend feasible but non-trivial.
2. **License of harrier itself** — does the current repo license permit a hosted SaaS and permissively-licensed client libs? Must resolve before launch.
3. **Benchmark dataset redistribution.** Can we redistribute LongMemEval/LoCoMo/BEAM, or only publish scores + a reproduction harness? Confirm each dataset's terms.
4. **Conversations API consistency model.** WAL gives single-writer serialization (`sqlite.go:252-254`); is that sufficient for many concurrent agents on one conversation, or do we need an explicit queue / optimistic-concurrency on conflicting upserts?
5. **Multimodal embedding provider choice** — Cohere multimodal vs. a dedicated vision embedder; dims and cross-modal recall quality need an eval before committing.
6. **Dashboard framework** — keep extending the vanilla D3 + HTML (`export_html.go`/`dashboard.html`) or invest in a real SPA once feature count grows? Lean vanilla through P1.
7. **Billing model** — per-memory, per-recall, per-seat, or storage-based? Affects what usage-accounting hooks we add in P0.
8. **Mem0 compatibility surface** — how much of Mem0's API do we mirror? Full parity vs. the core CRUD + search subset (the latter covers the drop-in migration case).
9. **OIDC IdP** — managed (Auth0/Clerk) vs. self-hosted (Keycloak); affects cost and data residency story.

---

## 9. Effort Estimate (rough, eng-weeks)

Assumes 2–3 engineers; estimates are for design-complete, tested, documented delivery. Numbers reflect that **the engine primitives already exist** — most cost is in the gateway, productization, and ops.

| Workstream | Eng-weeks | Notes |
|------------|----------:|-------|
| Multi-tenant gateway (auth, org/ws model, routing) | 8–10 | Largest net-new build; the platform spine. |
| Hosted dashboard (graph + search + curate, OIDC) | 5–7 | Extends `export_html.go`/`dashboard.html`; OIDC + live SSE wiring. |
| Workspace governance (roles, invites, key mgmt) | 4–5 | Builds on P0 keystore. |
| Queryable audit log | 2–3 | `AuditSink` + query API + view; schema reuses `AuditEntry`. |
| Webhooks (dispatcher, signing, retries, UI) | 3–4 | Bus already fans out (`events.go`); low risk. |
| Official client libs (Python + TS, Mem0-compatible) | 4–5 | Rewrite + packaging + docs + CI publish. |
| Published benchmark (LongMemEval/LoCoMo/BEAM) | 3–4 | Harness exists (`internal/bench`); cost is datasets + runs + write-up. |
| Multimodal memory (image embeddings) | 5–6 | New provider impl + blob storage + schema migration + eval. |
| Proactive memory API + dashboard panel | 3–4 | Productize `proactive.go`/`intent.go`. |
| Conversations API (shared memory) | 5–7 | Concurrency design + tests on WAL substrate. |
| Cross-cutting: infra, IaC, encryption, observability, security review | 6–8 | Object store, durable volumes, OTel, threat model. |
| **Total** | **≈ 48–63 eng-weeks** | ≈ 3 quarters with a small team, matching P0→P2 phasing. |

**Highest leverage first:** the gateway + dashboard + client libs + audit (P0) deliver the headline "managed platform with dashboard for memory inspection" P0 gap (`TOP20_COMPARISON.md:134`) and the client-lib P1 gap (`TOP20_COMPARISON.md:145`) — the two most-cited harrier gaps — before the more research-y multimodal and Conversations work.
