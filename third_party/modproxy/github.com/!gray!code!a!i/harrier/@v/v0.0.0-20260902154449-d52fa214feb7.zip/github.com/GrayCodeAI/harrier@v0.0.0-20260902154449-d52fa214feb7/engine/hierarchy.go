package engine

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// HierarchicalMemory implements RAPTOR-style multi-level abstraction.
// Memories are organized in layers:
//   - Level 0: Individual memories (leaf nodes)
//   - Level 1: Topic clusters (grouped by entity overlap)
//   - Level 2: Domain summaries (architecture, testing, deployment, etc.)
//
// Retrieval can target specific levels: detailed queries hit level 0,
// broad queries hit level 2, default hits all levels with RRF fusion.
type HierarchicalMemory struct {
	store  storage.Storage
	levels []*HierarchyLevel
}

// HierarchyLevel represents one abstraction layer.
type HierarchyLevel struct {
	Level    int
	Clusters []MemoryCluster
}

// MemoryCluster is a group of related memories with a summary.
type MemoryCluster struct {
	ID       string
	Summary  string
	NodeIDs  []string
	Keywords []string
	Size     int
	AvgConf  float64
}

// NewHierarchicalMemory creates the hierarchy builder.
func NewHierarchicalMemory(store storage.Storage) *HierarchicalMemory {
	return &HierarchicalMemory{
		store:  store,
		levels: make([]*HierarchyLevel, 3),
	}
}

// Build constructs the hierarchy from current memory state.
// Call periodically (e.g., at session end) to keep hierarchy fresh.
func (hm *HierarchicalMemory) Build(ctx context.Context) error {
	nodes, err := hm.store.ListNodes(ctx, storage.NodeFilter{
		MinConfidence: 0.2,
		Limit:         2000,
	})
	if err != nil {
		return err
	}
	if len(nodes) < 3 {
		return nil
	}

	// Level 0: individual memories (already stored in harrier)
	hm.levels[0] = &HierarchyLevel{Level: 0}

	// Level 1: cluster by shared entities (topic groups)
	clusters := hm.clusterByEntities(nodes)
	hm.levels[1] = &HierarchyLevel{Level: 1, Clusters: clusters}

	// Level 2: cluster by type (domain summaries)
	domains := hm.clusterByType(nodes)
	hm.levels[2] = &HierarchyLevel{Level: 2, Clusters: domains}

	return nil
}

// RetrieveAtLevel searches within a specific abstraction level.
func (hm *HierarchicalMemory) RetrieveAtLevel(query string, level int) []MemoryCluster {
	if level < 0 || level >= len(hm.levels) || hm.levels[level] == nil {
		return nil
	}

	queryLower := strings.ToLower(query)
	queryTerms := strings.Fields(queryLower)

	type scored struct {
		cluster MemoryCluster
		score   float64
	}
	var results []scored

	for _, cluster := range hm.levels[level].Clusters {
		score := 0.0
		summaryLower := strings.ToLower(cluster.Summary)
		for _, term := range queryTerms {
			if strings.Contains(summaryLower, term) {
				score += 1.0
			}
		}
		for _, kw := range cluster.Keywords {
			for _, term := range queryTerms {
				if strings.Contains(strings.ToLower(kw), term) {
					score += 0.5
				}
			}
		}
		if score > 0 {
			score *= cluster.AvgConf
			results = append(results, scored{cluster, score})
		}
	}

	sort.Slice(results, func(i, j int) bool {
		return results[i].score > results[j].score
	})

	var out []MemoryCluster
	for _, r := range results {
		out = append(out, r.cluster)
		if len(out) >= 5 {
			break
		}
	}
	return out
}

// RetrieveAdaptive picks the right level based on query specificity.
// Specific queries (file names, function names) → Level 0
// Topic queries ("auth", "testing") → Level 1
// Global queries ("what are the main patterns?") → Level 2
func (hm *HierarchicalMemory) RetrieveAdaptive(query string) int {
	// Heuristic: presence of specific identifiers → level 0
	if strings.Contains(query, ".") || strings.Contains(query, "/") || strings.Contains(query, "(") {
		return 0
	}
	// Global/broad queries
	globalIndicators := []string{"main", "all", "overview", "summary", "themes", "patterns", "architecture"}
	queryLower := strings.ToLower(query)
	for _, g := range globalIndicators {
		if strings.Contains(queryLower, g) {
			return 2
		}
	}
	return 1
}

// FormatLevel returns a readable summary of a hierarchy level.
func (hm *HierarchicalMemory) FormatLevel(level int) string {
	if level < 0 || level >= len(hm.levels) || hm.levels[level] == nil {
		return ""
	}
	var sb strings.Builder
	for _, c := range hm.levels[level].Clusters {
		fmt.Fprintf(&sb, "• [%d nodes] %s\n", c.Size, c.Summary)
	}
	return sb.String()
}

func (hm *HierarchicalMemory) clusterByEntities(nodes []*storage.Node) []MemoryCluster {
	// Extract entities for each node, group by shared entities
	entityToNodes := make(map[string][]int) // entity → node indices
	nodeEntities := make([][]string, len(nodes))

	for i, n := range nodes {
		ents := ExtractEntities(n.Content)
		var names []string
		for _, e := range ents {
			names = append(names, e.Name)
			key := strings.ToLower(e.Name)
			entityToNodes[key] = append(entityToNodes[key], i)
		}
		nodeEntities[i] = names
	}

	// Find clusters: nodes sharing 2+ entities
	assigned := make(map[int]int) // nodeIdx → clusterIdx
	var clusters []MemoryCluster
	clusterIdx := 0

	for entity, indices := range entityToNodes {
		if len(indices) < 2 {
			continue
		}
		// Check if any of these nodes are already in a cluster
		existingCluster := -1
		for _, idx := range indices {
			if c, ok := assigned[idx]; ok {
				existingCluster = c
				break
			}
		}

		if existingCluster >= 0 {
			// Add to existing cluster
			for _, idx := range indices {
				if _, ok := assigned[idx]; !ok {
					assigned[idx] = existingCluster
					clusters[existingCluster].NodeIDs = append(clusters[existingCluster].NodeIDs, nodes[idx].ID)
					clusters[existingCluster].Size++
				}
			}
			clusters[existingCluster].Keywords = appendUnique(clusters[existingCluster].Keywords, entity)
		} else {
			// New cluster
			c := MemoryCluster{
				ID:       fmt.Sprintf("cluster_%d", clusterIdx),
				Keywords: []string{entity},
			}
			for _, idx := range indices {
				assigned[idx] = clusterIdx
				c.NodeIDs = append(c.NodeIDs, nodes[idx].ID)
			}
			c.Size = len(c.NodeIDs)
			clusters = append(clusters, c)
			clusterIdx++
		}
	}

	// Pre-build node lookup map to avoid O(n^2) linear scan
	nodeMap := make(map[string]*storage.Node, len(nodes))
	for _, n := range nodes {
		nodeMap[n.ID] = n
	}

	// Generate summaries and compute avg confidence
	for i := range clusters {
		var totalConf float64
		var contents []string
		for _, id := range clusters[i].NodeIDs {
			if n, ok := nodeMap[id]; ok {
				totalConf += n.Confidence
				if len(n.Content) > 60 {
					contents = append(contents, n.Content[:60])
				} else {
					contents = append(contents, n.Content)
				}
			}
		}
		if clusters[i].Size > 0 {
			clusters[i].AvgConf = totalConf / float64(clusters[i].Size)
		}
		clusters[i].Summary = fmt.Sprintf("Topic: %s — %s",
			strings.Join(clusters[i].Keywords[:min(3, len(clusters[i].Keywords))], ", "),
			strings.Join(contents[:min(2, len(contents))], "; "))
	}

	// Sort by size
	sort.Slice(clusters, func(i, j int) bool {
		return clusters[i].Size > clusters[j].Size
	})

	return clusters
}

func (hm *HierarchicalMemory) clusterByType(nodes []*storage.Node) []MemoryCluster {
	typeMap := make(map[string][]*storage.Node)
	for _, n := range nodes {
		typeMap[n.Type] = append(typeMap[n.Type], n)
	}

	var clusters []MemoryCluster
	for typ, typeNodes := range typeMap {
		if len(typeNodes) == 0 {
			continue
		}

		var totalConf float64
		var ids []string
		for _, n := range typeNodes {
			ids = append(ids, n.ID)
			totalConf += n.Confidence
		}

		// Summary from top-confidence nodes
		sort.Slice(typeNodes, func(i, j int) bool {
			return typeNodes[i].Confidence > typeNodes[j].Confidence
		})
		var summaryParts []string
		for i := 0; i < min(3, len(typeNodes)); i++ {
			content := typeNodes[i].Content
			if len(content) > 60 {
				content = content[:60]
			}
			summaryParts = append(summaryParts, content)
		}

		clusters = append(clusters, MemoryCluster{
			ID:       "type_" + typ,
			Summary:  fmt.Sprintf("%s (%d): %s", typ, len(typeNodes), strings.Join(summaryParts, "; ")),
			NodeIDs:  ids,
			Keywords: []string{typ},
			Size:     len(typeNodes),
			AvgConf:  totalConf / float64(len(typeNodes)),
		})
	}

	sort.Slice(clusters, func(i, j int) bool {
		return clusters[i].Size > clusters[j].Size
	})
	return clusters
}
