package engine

import (
	"sync"
	"time"
)

// RateLimiter implements a token bucket rate limiter for the REST API.
// Prevents abuse and ensures fair usage for developers running locally
// multiple agents simultaneously.
type RateLimiter struct {
	mu       sync.Mutex
	tokens   float64
	maxBurst int
	rate     float64 // tokens per second
	lastTime time.Time
}

// NewRateLimiter creates a limiter with given rate (req/sec) and burst capacity.
func NewRateLimiter(ratePerSec float64, maxBurst int) *RateLimiter {
	return &RateLimiter{
		tokens:   float64(maxBurst),
		maxBurst: maxBurst,
		rate:     ratePerSec,
		lastTime: time.Now(),
	}
}

// Allow checks if a request is allowed. Returns true if within limits.
func (rl *RateLimiter) Allow() bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(rl.lastTime).Seconds()
	rl.lastTime = now

	// Refill tokens
	rl.tokens += elapsed * rl.rate
	if rl.tokens > float64(rl.maxBurst) {
		rl.tokens = float64(rl.maxBurst)
	}

	if rl.tokens >= 1.0 {
		rl.tokens--
		return true
	}
	return false
}

// Remaining returns how many requests are available right now.
func (rl *RateLimiter) Remaining() int {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	return int(rl.tokens)
}
