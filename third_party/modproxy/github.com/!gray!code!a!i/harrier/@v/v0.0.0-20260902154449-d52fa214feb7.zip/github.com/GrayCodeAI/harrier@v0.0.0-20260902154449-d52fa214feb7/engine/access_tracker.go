package engine

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

const maxAccessBuffer = 10000

// AccessTracker batches node access events to reduce SQLite UPDATE churn.
// Instead of updating nodes.access_count on every recall (which causes write
// contention under concurrent load), it INSERTs lightweight rows into
// access_log and periodically flushes them in a single aggregated UPDATE.
type AccessTracker struct {
	store     storage.Storage
	buffer    []string // node IDs pending flush
	mu        sync.Mutex
	flushTick *time.Ticker
	stopCh    chan struct{}
	stopped   sync.Once
	// wg tracks every background goroutine that may write to the store (the
	// flush loop and any detached overflow drains). Stop() waits on it so that
	// when Stop() returns, no goroutine can issue another DB write — callers
	// then safely Close() the store without a write landing afterward (which
	// otherwise re-creates SQLite -wal/-shm files, e.g. failing t.TempDir
	// cleanup with "directory not empty").
	wg sync.WaitGroup
}

// NewAccessTracker creates a tracker that flushes every interval.
func NewAccessTracker(store storage.Storage, interval time.Duration) *AccessTracker {
	at := &AccessTracker{
		store:     store,
		buffer:    make([]string, 0, 128),
		flushTick: time.NewTicker(interval),
		stopCh:    make(chan struct{}),
	}
	at.wg.Add(1)
	go at.loop()
	return at
}

// Log records an access for the given node ID (best-effort, non-blocking).
//
// The access is appended to an in-memory buffer and returns immediately — it
// does NOT touch SQLite on the calling path. The periodic flusher (loop) drains
// the buffer on its ticker. This is the whole point of the tracker: a single
// Recall returns many nodes and previously issued one synchronous INSERT per
// node, N writes per query all contending for the single SQLite writer. Access
// counts feed decay/recency ranking, not correctness, so deferring them is safe.
//
// On buffer overflow the buffer is drained synchronously in a detached
// goroutine so a pathological burst can never grow memory without bound.
func (at *AccessTracker) Log(_ context.Context, nodeID string) {
	at.mu.Lock()
	at.buffer = append(at.buffer, nodeID)
	if len(at.buffer) < maxAccessBuffer {
		at.mu.Unlock()
		return
	}
	// Buffer full — drain it in a detached goroutine. context.Background() is
	// intentional: the flush must outlive the caller's context. The storage
	// layer handles concurrent flush calls (it serializes its own writes).
	overflow := make([]string, len(at.buffer))
	copy(overflow, at.buffer)
	at.buffer = at.buffer[:0]
	at.mu.Unlock()
	at.wg.Add(1)
	go func() {
		defer at.wg.Done()
		at.drain(overflow)
	}()
}

// drain writes the given node IDs to the access log and aggregates them.
func (at *AccessTracker) drain(ids []string) {
	ctx := context.Background()
	for _, id := range ids {
		_ = at.store.LogAccess(ctx, id)
	}
	n, err := at.store.FlushAccessLog(ctx)
	if err != nil {
		slog.Warn("access_tracker: flush failed", "error", err)
	} else if n > 0 {
		slog.Debug("access_tracker: flushed", "nodes_updated", n)
	}
}

// Flush immediately applies all pending access counts to nodes. Used by the
// periodic flusher and once more on shutdown so no buffered access is lost.
func (at *AccessTracker) Flush(ctx context.Context) {
	at.mu.Lock()
	buf := make([]string, len(at.buffer))
	copy(buf, at.buffer)
	at.buffer = at.buffer[:0]
	at.mu.Unlock()

	for _, nodeID := range buf {
		_ = at.store.LogAccess(ctx, nodeID)
	}

	n, err := at.store.FlushAccessLog(ctx)
	if err != nil {
		slog.Warn("access_tracker: flush failed", "error", err)
	} else if n > 0 {
		slog.Debug("access_tracker: flushed", "nodes_updated", n)
	}
}

// Stop halts the background flusher and waits for all in-flight background
// goroutines (the flush loop and any overflow drains) to finish writing to the
// store. After Stop returns, no AccessTracker goroutine will touch the store,
// so the caller may safely Close() it. Safe to call multiple times; the wait
// happens once.
func (at *AccessTracker) Stop() {
	at.stopped.Do(func() {
		at.flushTick.Stop()
		close(at.stopCh)
		at.wg.Wait()
	})
}

func (at *AccessTracker) loop() {
	defer at.wg.Done()
	for {
		select {
		case <-at.flushTick.C:
			at.Flush(context.Background())
		case <-at.stopCh:
			return
		}
	}
}
