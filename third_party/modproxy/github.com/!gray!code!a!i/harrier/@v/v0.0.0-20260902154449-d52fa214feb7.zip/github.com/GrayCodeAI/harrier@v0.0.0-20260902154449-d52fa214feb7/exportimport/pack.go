package exportimport

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// HarrierPack represents a signed, portable team memory bundle (.harrierpack format).
type HarrierPack struct {
	Header    PackHeader      `json:"header"`
	Nodes     []*storage.Node `json:"nodes"`
	Edges     []*storage.Edge `json:"edges"`
	Signature string          `json:"signature"`
}

// PackHeader contains metadata for a .harrierpack file.
type PackHeader struct {
	Version   string    `json:"version"`
	Project   string    `json:"project"`
	Author    string    `json:"author"`
	CreatedAt time.Time `json:"created_at"`
	NodeCount int       `json:"node_count"`
}

// ExportPack builds and signs a .harrierpack file for team sharing.
func ExportPack(nodes []*storage.Node, edges []*storage.Edge, project, author, signingKey string) (*HarrierPack, error) {
	header := PackHeader{
		Version:   "1.0",
		Project:   project,
		Author:    author,
		CreatedAt: time.Now(),
		NodeCount: len(nodes),
	}

	pack := &HarrierPack{
		Header: header,
		Nodes:  nodes,
		Edges:  edges,
	}

	if signingKey != "" {
		sig, err := computePackSignature(pack, signingKey)
		if err != nil {
			return nil, err
		}
		pack.Signature = sig
	}

	return pack, nil
}

// VerifyPack checks the HMAC-SHA256 signature of a .harrierpack file.
func VerifyPack(pack *HarrierPack, signingKey string) (bool, error) {
	if pack.Signature == "" {
		return false, errors.New("unsigned pack")
	}
	expectedSig, err := computePackSignature(pack, signingKey)
	if err != nil {
		return false, err
	}
	return hmac.Equal([]byte(pack.Signature), []byte(expectedSig)), nil
}

func computePackSignature(pack *HarrierPack, key string) (string, error) {
	payload, err := json.Marshal(struct {
		Header PackHeader      `json:"header"`
		Nodes  []*storage.Node `json:"nodes"`
		Edges  []*storage.Edge `json:"edges"`
	}{
		Header: pack.Header,
		Nodes:  pack.Nodes,
		Edges:  pack.Edges,
	})
	if err != nil {
		return "", err
	}

	mac := hmac.New(sha256.New, []byte(key))
	mac.Write(payload)
	return hex.EncodeToString(mac.Sum(nil)), nil
}
