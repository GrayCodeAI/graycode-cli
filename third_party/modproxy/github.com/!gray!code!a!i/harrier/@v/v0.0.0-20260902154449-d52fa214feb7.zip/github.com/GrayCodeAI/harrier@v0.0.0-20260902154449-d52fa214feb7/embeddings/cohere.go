package embeddings

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

// cohereEndpoint is overridable in tests.
var cohereEndpoint = "https://api.cohere.com/v2/embed"

// cohere implements the Cohere embedding API.
// Supported models: embed-english-v3.0, embed-multilingual-v3.0.
type cohere struct {
	apiKey string
	model  string
	dims   int
}

// NewCohere creates a Cohere embedding provider.
// model: "embed-english-v3.0" (1024 dims) or "embed-multilingual-v3.0" (1024 dims).
func NewCohere(apiKey, model string) Provider {
	if model == "" {
		model = "embed-english-v3.0"
	}
	return &cohere{apiKey: apiKey, model: model, dims: 1024}
}

func (p *cohere) Name() string { return "cohere:" + p.model }
func (p *cohere) Dims() int    { return p.dims }

func (p *cohere) Embed(ctx context.Context, text string) ([]float32, error) {
	for attempt := 0; attempt <= maxRetries; attempt++ {
		body, err := json.Marshal(map[string]any{
			"texts":      []string{text},
			"model":      p.model,
			"input_type": "search_document",
		})
		if err != nil {
			return nil, fmt.Errorf("cohere: marshal: %w", err)
		}
		req, err := http.NewRequestWithContext(ctx, "POST", cohereEndpoint, bytes.NewReader(body))
		if err != nil {
			return nil, fmt.Errorf("cohere: create request: %w", err)
		}
		req.Header.Set("Authorization", "Bearer "+p.apiKey)
		req.Header.Set("Content-Type", "application/json")

		resp, err := httpClient.Do(req)
		if err != nil {
			return nil, err
		}

		if resp.StatusCode != 200 {
			var errBody struct {
				Message string `json:"message"`
			}
			_ = json.NewDecoder(resp.Body).Decode(&errBody)
			_ = resp.Body.Close()
			errMsg := fmt.Sprintf("cohere: API returned status %d: %s", resp.StatusCode, errBody.Message)
			if d := ExtractRetryDelay(errMsg); d > 0 && attempt < maxRetries {
				select {
				case <-time.After(d):
				case <-ctx.Done():
					return nil, ctx.Err()
				}
				continue
			}
			return nil, fmt.Errorf("%s", errMsg)
		}

		var result struct {
			Embeddings [][]float32 `json:"embeddings"`
		}
		decodeErr := json.NewDecoder(resp.Body).Decode(&result)
		_ = resp.Body.Close()
		if decodeErr != nil {
			return nil, decodeErr
		}
		if len(result.Embeddings) == 0 {
			return nil, fmt.Errorf("cohere: empty response")
		}
		return result.Embeddings[0], nil
	}
	return nil, fmt.Errorf("cohere: max retries (%d) exceeded", maxRetries)
}

func (p *cohere) EmbedBatch(ctx context.Context, texts []string) ([][]float32, error) {
	if len(texts) == 0 {
		return nil, nil
	}
	for attempt := 0; attempt <= maxRetries; attempt++ {
		body, err := json.Marshal(map[string]any{
			"texts":      texts,
			"model":      p.model,
			"input_type": "search_document",
		})
		if err != nil {
			return nil, fmt.Errorf("cohere: marshal batch: %w", err)
		}
		req, err := http.NewRequestWithContext(ctx, "POST", cohereEndpoint, bytes.NewReader(body))
		if err != nil {
			return nil, fmt.Errorf("cohere: create request: %w", err)
		}
		req.Header.Set("Authorization", "Bearer "+p.apiKey)
		req.Header.Set("Content-Type", "application/json")

		resp, err := httpClient.Do(req)
		if err != nil {
			return nil, err
		}

		if resp.StatusCode != 200 {
			var errBody struct {
				Message string `json:"message"`
			}
			_ = json.NewDecoder(resp.Body).Decode(&errBody)
			_ = resp.Body.Close()
			errMsg := fmt.Sprintf("cohere: API returned status %d: %s", resp.StatusCode, errBody.Message)
			if d := ExtractRetryDelay(errMsg); d > 0 && attempt < maxRetries {
				select {
				case <-time.After(d):
				case <-ctx.Done():
					return nil, ctx.Err()
				}
				continue
			}
			return nil, fmt.Errorf("%s", errMsg)
		}

		var result struct {
			Embeddings [][]float32 `json:"embeddings"`
		}
		decodeErr := json.NewDecoder(resp.Body).Decode(&result)
		_ = resp.Body.Close()
		if decodeErr != nil {
			return nil, decodeErr
		}
		if len(result.Embeddings) == 0 {
			return nil, fmt.Errorf("cohere: empty batch response")
		}
		return result.Embeddings, nil
	}
	return nil, fmt.Errorf("cohere: max retries (%d) exceeded", maxRetries)
}

// EmbedWithMode for Cohere uses input_type for asymmetric embeddings.
func (p *cohere) EmbedWithMode(ctx context.Context, text string, mode EmbedMode) ([]float32, error) {
	inputType := "search_document"
	if mode == ModeQuery {
		inputType = "search_query"
	}
	for attempt := 0; attempt <= maxRetries; attempt++ {
		body, err := json.Marshal(map[string]any{
			"texts":      []string{text},
			"model":      p.model,
			"input_type": inputType,
		})
		if err != nil {
			return nil, fmt.Errorf("cohere: marshal: %w", err)
		}
		req, err := http.NewRequestWithContext(ctx, "POST", cohereEndpoint, bytes.NewReader(body))
		if err != nil {
			return nil, fmt.Errorf("cohere: create request: %w", err)
		}
		req.Header.Set("Authorization", "Bearer "+p.apiKey)
		req.Header.Set("Content-Type", "application/json")

		resp, err := httpClient.Do(req)
		if err != nil {
			return nil, err
		}

		if resp.StatusCode != 200 {
			var errBody struct {
				Message string `json:"message"`
			}
			_ = json.NewDecoder(resp.Body).Decode(&errBody)
			_ = resp.Body.Close()
			errMsg := fmt.Sprintf("cohere: API returned status %d: %s", resp.StatusCode, errBody.Message)
			if d := ExtractRetryDelay(errMsg); d > 0 && attempt < maxRetries {
				select {
				case <-time.After(d):
				case <-ctx.Done():
					return nil, ctx.Err()
				}
				continue
			}
			return nil, fmt.Errorf("%s", errMsg)
		}

		var result struct {
			Embeddings [][]float32 `json:"embeddings"`
		}
		decodeErr := json.NewDecoder(resp.Body).Decode(&result)
		_ = resp.Body.Close()
		if decodeErr != nil {
			return nil, decodeErr
		}
		if len(result.Embeddings) == 0 {
			return nil, fmt.Errorf("cohere: empty response")
		}
		return result.Embeddings[0], nil
	}
	return nil, fmt.Errorf("cohere: max retries (%d) exceeded", maxRetries)
}
