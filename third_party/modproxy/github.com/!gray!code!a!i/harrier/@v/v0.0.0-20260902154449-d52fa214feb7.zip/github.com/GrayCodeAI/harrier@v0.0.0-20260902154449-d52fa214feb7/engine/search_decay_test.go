package engine

import (
	"context"
	"math"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// TestSearchTimeDecayHalfLifeFormula verifies the core half-life math:
// score * exp(-ln(2)/halfLife * age).
func TestSearchTimeDecayHalfLifeFormula(t *testing.T) {
	t.Parallel()
	halfLife := 30 * 24 * time.Hour // 30 days
	d := SearchTimeDecay{HalfLife: halfLife}
	now := time.Now()

	nodes := []*storage.Node{
		{
			ID:         "fresh",
			Confidence: 1.0,
			UpdatedAt:  now, // age = 0
		},
		{
			ID:         "one-half-life",
			Confidence: 1.0,
			UpdatedAt:  now.Add(-halfLife), // age = 1 half-life
		},
		{
			ID:         "two-half-lives",
			Confidence: 1.0,
			UpdatedAt:  now.Add(-2 * halfLife), // age = 2 half-lives
		},
	}

	results := d.ApplySearchTimeDecay(nodes, now)

	if len(results) != 3 {
		t.Fatalf("expected 3 results, got %d", len(results))
	}

	// Fresh node: age=0, decay=1, score=1.0
	if diff := results[0].Confidence - 1.0; diff > 1e-10 || diff < -1e-10 {
		t.Errorf("fresh: expected score=1.0, got %f", results[0].Confidence)
	}

	// One half-life: decay=0.5, score=0.5
	expectedHalf := 0.5
	if diff := results[1].Confidence - expectedHalf; diff > 1e-9 || diff < -1e-9 {
		t.Errorf("one half-life: expected score=%f, got %f", expectedHalf, results[1].Confidence)
	}

	// Two half-lives: decay=0.25, score=0.25
	expectedQuarter := 0.25
	if diff := results[2].Confidence - expectedQuarter; diff > 1e-9 || diff < -1e-9 {
		t.Errorf("two half-lives: expected score=%f, got %f", expectedQuarter, results[2].Confidence)
	}

	// Verify stored Confidence was NOT modified (non-destructive)
	if nodes[1].Confidence != 1.0 {
		t.Errorf("stored confidence was modified: expected 1.0, got %f", nodes[1].Confidence)
	}
	if nodes[2].Confidence != 1.0 {
		t.Errorf("stored confidence was modified: expected 1.0, got %f", nodes[2].Confidence)
	}
}

// TestSearchTimeDecayPrefersAccessedAt verifies that AccessedAt is used as
// the reference time when it is more recent than UpdatedAt.
func TestSearchTimeDecayPrefersAccessedAt(t *testing.T) {
	t.Parallel()
	halfLife := 30 * 24 * time.Hour
	d := SearchTimeDecay{HalfLife: halfLife}
	now := time.Now()

	nodes := []*storage.Node{
		{
			ID:         "old-update-recent-access",
			Confidence: 1.0,
			UpdatedAt:  now.Add(-60 * 24 * time.Hour), // 60 days ago
			AccessedAt: now.Add(-10 * 24 * time.Hour), // 10 days ago (more recent)
		},
	}

	results := d.ApplySearchTimeDecay(nodes, now)
	age := 10 * 24 * time.Hour
	expected := math.Exp(-math.Ln2 / halfLife.Seconds() * age.Seconds())
	if diff := results[0].Confidence - expected; diff > 1e-9 || diff < -1e-9 {
		t.Errorf("expected score=%f (10-day decay), got %f", expected, results[0].Confidence)
	}
}

// TestSearchTimeDecayZeroConfidence verifies zero-confidence nodes get score=0.
func TestSearchTimeDecayZeroConfidence(t *testing.T) {
	t.Parallel()
	d := SearchTimeDecay{HalfLife: 30 * 24 * time.Hour}
	now := time.Now()

	nodes := []*storage.Node{
		{ID: "archived", Confidence: 0, UpdatedAt: now.Add(-10 * 24 * time.Hour)},
	}

	results := d.ApplySearchTimeDecay(nodes, now)
	if results[0].Confidence != 0 {
		t.Errorf("expected score=0 for zero-confidence node, got %f", results[0].Confidence)
	}
}

// TestSearchTimeDecayNoHalfLife verifies that a zero half-life passes through
// raw confidence without applying decay.
func TestSearchTimeDecayNoHalfLife(t *testing.T) {
	t.Parallel()
	d := SearchTimeDecay{HalfLife: 0}
	now := time.Now()

	nodes := []*storage.Node{
		{ID: "old", Confidence: 0.8, UpdatedAt: now.Add(-100 * 24 * time.Hour)},
	}

	results := d.ApplySearchTimeDecay(nodes, now)
	if results[0].Confidence != 0.8 {
		t.Errorf("expected score=0.8 (no decay), got %f", results[0].Confidence)
	}
}

// TestSearchTimeDecayFutureTimestamp verifies that nodes with a future
// reference time (clock skew) are not penalized.
func TestSearchTimeDecayFutureTimestamp(t *testing.T) {
	t.Parallel()
	d := SearchTimeDecay{HalfLife: 30 * 24 * time.Hour}
	now := time.Now()

	nodes := []*storage.Node{
		{ID: "future", Confidence: 0.9, UpdatedAt: now.Add(1 * time.Hour)},
	}

	results := d.ApplySearchTimeDecay(nodes, now)
	if results[0].Confidence != 0.9 {
		t.Errorf("expected score=0.9 (future timestamp, no penalty), got %f", results[0].Confidence)
	}
}

// TestSearchTimeDecayPartialConfidence verifies decay is applied to
// non-unit confidence values correctly.
func TestSearchTimeDecayPartialConfidence(t *testing.T) {
	t.Parallel()
	halfLife := 10 * 24 * time.Hour
	d := SearchTimeDecay{HalfLife: halfLife}
	now := time.Now()

	nodes := []*storage.Node{
		{ID: "partial", Confidence: 0.6, UpdatedAt: now.Add(-halfLife)},
	}

	results := d.ApplySearchTimeDecay(nodes, now)
	expected := 0.6 * 0.5 // 0.6 * decay at one half-life = 0.3
	if diff := results[0].Confidence - expected; diff > 1e-9 || diff < -1e-9 {
		t.Errorf("expected score=%f, got %f", expected, results[0].Confidence)
	}
}

// TestSearchTimeDecayEmptySlice verifies graceful handling of an empty input.
func TestSearchTimeDecayEmptySlice(t *testing.T) {
	t.Parallel()
	d := SearchTimeDecay{HalfLife: 30 * 24 * time.Hour}
	results := d.ApplySearchTimeDecay(nil, time.Now())
	if len(results) != 0 {
		t.Errorf("expected empty results, got %d", len(results))
	}
}

// TestSearchTimeDecayDefaultConfig verifies the default 30-day half-life.
func TestSearchTimeDecayDefaultConfig(t *testing.T) {
	t.Parallel()
	d := DefaultSearchTimeDecay()
	if d.HalfLife != 30*24*time.Hour {
		t.Errorf("expected 30-day half-life, got %v", d.HalfLife)
	}
}

// TestSearchTimeDecayIntegration verifies search-time decay is applied as a
// post-fusion re-ranking step in FusedRecall without modifying stored data.
func TestSearchTimeDecayIntegration(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	// Enable search-time decay with a very short half-life so the effect is visible.
	eng.WithSearchDecay(1 * time.Hour)

	ctx := context.Background()

	// Create a node and manually backdate its UpdatedAt to simulate age.
	node, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "always use search time decay for ranking",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// Backdate the node to 3 hours ago (3 half-lives with 1-hour half-life).
	stored, err := eng.store.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	originalConfidence := stored.Confidence
	stored.UpdatedAt = time.Now().Add(-3 * time.Hour)
	if err := eng.store.UpdateNode(ctx, stored); err != nil {
		t.Fatalf("UpdateNode failed: %v", err)
	}

	// Create a fresh node with identical content to test relative ranking.
	fresh, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "always use search time decay for ranking",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("Remember fresh failed: %v", err)
	}

	result, err := eng.FusedRecall(ctx, RecallOpts{
		Query:   "search time decay",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("FusedRecall failed: %v", err)
	}

	if len(result.Nodes) == 0 {
		t.Fatalf("expected at least 1 node, got 0")
	}

	// The fresh node should rank higher than the aged node when both are returned.
	if len(result.Nodes) >= 2 && result.Nodes[0].ID != fresh.ID {
		t.Errorf("expected fresh node to rank first, got %s", result.Nodes[0].ID)
	}

	// Verify stored confidence was NOT modified (non-destructive).
	afterRecall, err := eng.store.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode after recall failed: %v", err)
	}
	if afterRecall.Confidence != originalConfidence {
		t.Errorf("stored confidence was modified by search-time decay: before=%.6f, after=%.6f",
			originalConfidence, afterRecall.Confidence)
	}
}

// TestSearchTimeDecayDisabledByDefault verifies FusedRecall does not apply
// decay when WithSearchDecay has not been called.
func TestSearchTimeDecayDisabledByDefault(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	// Do NOT call WithSearchDecay.

	ctx := context.Background()
	_, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "search time decay disabled test",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// FusedRecall should work without error even when searchDecay is nil.
	result, err := eng.FusedRecall(ctx, RecallOpts{
		Query:   "search time decay",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("FusedRecall failed with nil searchDecay: %v", err)
	}
	if len(result.Nodes) == 0 {
		t.Error("expected at least one result")
	}
}

// TestWithSearchDecayReturnsEngine verifies the fluent API.
func TestWithSearchDecayReturnsEngine(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	result := eng.WithSearchDecay(7 * 24 * time.Hour)
	if result != eng {
		t.Error("WithSearchDecay should return the same engine for chaining")
	}
	if eng.SearchDecay() == nil {
		t.Fatal("expected SearchDecay() to be non-nil after WithSearchDecay")
	}
	if eng.SearchDecay().HalfLife != 7*24*time.Hour {
		t.Errorf("expected 7-day half-life, got %v", eng.SearchDecay().HalfLife)
	}
}

// TestSearchDecayAccessorNilByDefault verifies SearchDecay() is nil when
// WithSearchDecay has not been called.
func TestSearchDecayAccessorNilByDefault(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	if eng.SearchDecay() != nil {
		t.Error("expected SearchDecay() to be nil by default")
	}
}
