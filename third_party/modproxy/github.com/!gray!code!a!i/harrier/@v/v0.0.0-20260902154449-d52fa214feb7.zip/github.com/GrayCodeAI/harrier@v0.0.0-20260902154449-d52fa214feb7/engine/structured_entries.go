package engine

// This file implements structured memory entry types inspired by cognee's
// memory model (https://github.com/topoteretes/cognee). Instead of storing
// only text blobs, harrier can now persist typed entries that carry structured
// fields, enabling richer retrieval and analysis.
//
// Entry types:
//   - QAEntry:        Q&A turn with question, answer, context, feedback
//   - TraceEntry:     Agent trace step (tool/function call, origin, outcome)
//   - FeedbackEntry:  Feedback attached to an existing QA entry
//   - SkillRunEntry:  Persisted execution record for a skill
//
// Each entry is stored as a Node with Type set to the entry kind and
// Metadata carrying the structured fields as JSON. This keeps the storage
// layer unchanged while enabling typed access via the entry helpers below.

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// EntryType identifies a structured memory entry kind.
type EntryType string

const (
	EntryQA       EntryType = "qa"
	EntryTrace    EntryType = "trace"
	EntryFeedback EntryType = "feedback"
	EntrySkillRun EntryType = "skill_run"
)

// --- QAEntry ---

// QAEntry captures a Q&A conversation turn with optional feedback.
// Mirrors cognee's QAEntry model.
type QAEntry struct {
	Type          EntryType `json:"type"` // "qa"
	Question      string    `json:"question"`
	Answer        string    `json:"answer"`
	Context       string    `json:"context,omitempty"`
	FeedbackText  string    `json:"feedback_text,omitempty"`
	FeedbackScore *int      `json:"feedback_score,omitempty"` // 1-5
	UsedGraphIDs  []string  `json:"used_graph_element_ids,omitempty"`
	SessionID     string    `json:"session_id,omitempty"`
	Project       string    `json:"project"`
	SourceAgent   string    `json:"source_agent,omitempty"`
	Timestamp     time.Time `json:"timestamp"`
}

// RememberQA stores a QAEntry as a typed node and returns the created node.
func (e *Engine) RememberQA(ctx context.Context, qa QAEntry) (*storage.Node, error) {
	if qa.Question == "" || qa.Answer == "" {
		return nil, fmt.Errorf("qa entry: question and answer are required")
	}
	if qa.Type == "" {
		qa.Type = EntryQA
	}
	qa.Timestamp = time.Now().UTC()

	meta, err := qaToMetadata(qa)
	if err != nil {
		return nil, err
	}

	in := RememberInput{
		Type:     string(EntryQA),
		Content:  qa.Question + "\n---\n" + qa.Answer,
		Summary:  qa.Question,
		Scope:    "project",
		Project:  qa.Project,
		Session:  qa.SessionID,
		Agent:    qa.SourceAgent,
		Tags:     "qa",
		Metadata: meta,
	}
	return e.Remember(ctx, in)
}

// RecallQA retrieves QA entries matching a query.
func (e *Engine) RecallQA(ctx context.Context, query, project string, limit int) ([]*QAEntry, error) {
	result, err := e.Recall(ctx, RecallOpts{
		Query:   query,
		Project: project,
		Limit:   limit,
		Type:    string(EntryQA),
	})
	if err != nil {
		return nil, err
	}
	entries := make([]*QAEntry, 0, len(result.Nodes))
	for _, n := range result.Nodes {
		qa, err := metadataToQA(n.Metadata)
		if err != nil {
			continue
		}
		qa.Question = n.Summary
		qa.Project = n.Project
		entries = append(entries, qa)
	}
	return entries, nil
}

// qaToMetadata serializes a QAEntry into metadata key-value pairs.
func qaToMetadata(qa QAEntry) (map[string]string, error) {
	m := map[string]string{
		"entry_type":   string(qa.Type),
		"question":     qa.Question,
		"answer":       qa.Answer,
		"context":      qa.Context,
		"session_id":   qa.SessionID,
		"project":      qa.Project,
		"source_agent": qa.SourceAgent,
		"timestamp":    qa.Timestamp.Format(time.RFC3339Nano),
	}
	if qa.FeedbackText != "" {
		m["feedback_text"] = qa.FeedbackText
	}
	if qa.FeedbackScore != nil {
		m["feedback_score"] = fmt.Sprintf("%d", *qa.FeedbackScore)
	}
	if len(qa.UsedGraphIDs) > 0 {
		ids, _ := json.Marshal(qa.UsedGraphIDs)
		m["used_graph_ids"] = string(ids)
	}
	return m, nil
}

// metadataToQA deserializes metadata key-value pairs into a QAEntry.
func metadataToQA(meta map[string]string) (*QAEntry, error) {
	if meta == nil {
		return nil, fmt.Errorf("nil metadata")
	}
	qa := &QAEntry{
		Type:         EntryType(meta["entry_type"]),
		Question:     meta["question"],
		Answer:       meta["answer"],
		Context:      meta["context"],
		FeedbackText: meta["feedback_text"],
		SessionID:    meta["session_id"],
		SourceAgent:  meta["source_agent"],
	}
	if meta["feedback_score"] != "" {
		var score int
		if _, err := fmt.Sscanf(meta["feedback_score"], "%d", &score); err == nil {
			qa.FeedbackScore = &score
		}
	}
	if meta["used_graph_ids"] != "" {
		var ids []string
		if err := json.Unmarshal([]byte(meta["used_graph_ids"]), &ids); err == nil {
			qa.UsedGraphIDs = ids
		}
	}
	if ts := meta["timestamp"]; ts != "" {
		if t, err := time.Parse(time.RFC3339Nano, ts); err == nil {
			qa.Timestamp = t
		}
	}
	return qa, nil
}

// --- TraceEntry ---

// TraceEntry captures a single step in an agent's execution trace.
// Mirrors cognee's TraceEntry model.
type TraceEntry struct {
	Type              EntryType `json:"type"`            // "trace"
	OriginFunction    string    `json:"origin_function"` // e.g. "search_codebase"
	Status            string    `json:"status"`          // "success" | "error"
	MethodParams      string    `json:"method_params,omitempty"`
	MethodReturnValue string    `json:"method_return_value,omitempty"`
	MemoryQuery       string    `json:"memory_query,omitempty"`
	MemoryContext     string    `json:"memory_context,omitempty"`
	ErrorMessage      string    `json:"error_message,omitempty"`
	GenerateFeedback  bool      `json:"generate_feedback_with_llm"`
	SessionID         string    `json:"session_id"`
	Project           string    `json:"project"`
	SourceAgent       string    `json:"source_agent,omitempty"`
	Timestamp         time.Time `json:"timestamp"`
}

// RememberTrace stores a TraceEntry as a typed node.
func (e *Engine) RememberTrace(ctx context.Context, te TraceEntry) (*storage.Node, error) {
	if te.Type == "" {
		te.Type = EntryTrace
	}
	if te.OriginFunction == "" {
		return nil, fmt.Errorf("trace entry: origin_function is required")
	}
	te.Timestamp = time.Now().UTC()

	meta, err := traceToMetadata(te)
	if err != nil {
		return nil, err
	}

	content := te.OriginFunction
	if te.ErrorMessage != "" {
		content += " [ERROR: " + te.ErrorMessage + "]"
	}

	in := RememberInput{
		Type:     string(EntryTrace),
		Content:  content,
		Summary:  te.OriginFunction,
		Scope:    "project",
		Project:  te.Project,
		Session:  te.SessionID,
		Agent:    te.SourceAgent,
		Tags:     "trace",
		Metadata: meta,
	}
	return e.Remember(ctx, in)
}

// traceToMetadata serializes a TraceEntry into metadata key-value pairs.
func traceToMetadata(te TraceEntry) (map[string]string, error) {
	return map[string]string{
		"entry_type":          string(te.Type),
		"origin_function":     te.OriginFunction,
		"status":              te.Status,
		"method_params":       te.MethodParams,
		"method_return_value": te.MethodReturnValue,
		"memory_query":        te.MemoryQuery,
		"memory_context":      te.MemoryContext,
		"error_message":       te.ErrorMessage,
		"generate_feedback":   fmt.Sprintf("%t", te.GenerateFeedback),
		"session_id":          te.SessionID,
		"project":             te.Project,
		"source_agent":        te.SourceAgent,
		"timestamp":           te.Timestamp.Format(time.RFC3339Nano),
	}, nil
}

// --- FeedbackEntry ---

// FeedbackEntry attaches feedback to an existing QA entry.
// Mirrors cognee's FeedbackEntry model.
type FeedbackEntry struct {
	Type         EntryType `json:"type"`           // "feedback"
	TargetNodeID string    `json:"target_node_id"` // the QA entry this feedback attaches to
	FeedbackText string    `json:"feedback_text"`
	Score        *int      `json:"feedback_score,omitempty"` // 1-5
	Project      string    `json:"project"`
	SessionID    string    `json:"session_id,omitempty"`
	SourceAgent  string    `json:"source_agent,omitempty"`
	Timestamp    time.Time `json:"timestamp"`
}

// RememberFeedback stores a FeedbackEntry and updates the target QA entry.
func (e *Engine) RememberFeedback(ctx context.Context, fe FeedbackEntry) (*storage.Node, error) {
	if fe.Type == "" {
		fe.Type = EntryFeedback
	}
	if fe.TargetNodeID == "" {
		return nil, fmt.Errorf("feedback entry: target_node_id is required")
	}
	if fe.FeedbackText == "" && fe.Score == nil {
		return nil, fmt.Errorf("feedback entry: feedback_text or score is required")
	}
	fe.Timestamp = time.Now().UTC()

	meta, err := feedbackToMetadata(fe)
	if err != nil {
		return nil, err
	}

	// Update the target QA entry's feedback fields.
	if err := e.updateQAFeedback(ctx, fe.TargetNodeID, fe); err != nil {
		return nil, fmt.Errorf("update target qa: %w", err)
	}

	in := RememberInput{
		Type:     string(EntryFeedback),
		Content:  fe.FeedbackText,
		Summary:  "Feedback for " + fe.TargetNodeID,
		Scope:    "project",
		Project:  fe.Project,
		Session:  fe.SessionID,
		Agent:    fe.SourceAgent,
		Tags:     "feedback",
		Metadata: meta,
	}
	return e.Remember(ctx, in)
}

// updateQAFeedback updates the feedback fields on an existing QA node.
func (e *Engine) updateQAFeedback(ctx context.Context, targetID string, fe FeedbackEntry) error {
	e.mu.Lock()
	defer e.mu.Unlock()

	node, err := e.store.GetNode(ctx, targetID)
	if err != nil {
		return err
	}
	if node.Metadata == nil {
		node.Metadata = make(map[string]string)
	}
	if fe.FeedbackText != "" {
		node.Metadata["feedback_text"] = fe.FeedbackText
	}
	if fe.Score != nil {
		node.Metadata["feedback_score"] = fmt.Sprintf("%d", *fe.Score)
	}
	return e.store.UpdateNode(ctx, node)
}

// feedbackToMetadata serializes a FeedbackEntry into metadata key-value pairs.
func feedbackToMetadata(fe FeedbackEntry) (map[string]string, error) {
	m := map[string]string{
		"entry_type":     string(fe.Type),
		"target_node_id": fe.TargetNodeID,
		"feedback_text":  fe.FeedbackText,
		"project":        fe.Project,
		"session_id":     fe.SessionID,
		"source_agent":   fe.SourceAgent,
		"timestamp":      fe.Timestamp.Format(time.RFC3339Nano),
	}
	if fe.Score != nil {
		m["feedback_score"] = fmt.Sprintf("%d", *fe.Score)
	}
	return m, nil
}

// --- SkillRunEntry ---

// SkillRunEntry persists an execution record for a skill.
// Mirrors cognee's SkillRunEntry model.
type SkillRunEntry struct {
	Type         EntryType `json:"type"` // "skill_run"
	SkillName    string    `json:"skill_name"`
	SkillVersion string    `json:"skill_version,omitempty"`
	Params       string    `json:"params,omitempty"` // JSON-encoded params
	Result       string    `json:"result,omitempty"` // summary of result
	Status       string    `json:"status"`           // "success" | "error"
	DurationMs   int64     `json:"duration_ms,omitempty"`
	Error        string    `json:"error,omitempty"`
	Project      string    `json:"project"`
	SessionID    string    `json:"session_id,omitempty"`
	SourceAgent  string    `json:"source_agent,omitempty"`
	Timestamp    time.Time `json:"timestamp"`
}

// RememberSkillRun stores a SkillRunEntry as a typed node.
func (e *Engine) RememberSkillRun(ctx context.Context, sr SkillRunEntry) (*storage.Node, error) {
	if sr.Type == "" {
		sr.Type = EntrySkillRun
	}
	if sr.SkillName == "" {
		return nil, fmt.Errorf("skill_run entry: skill_name is required")
	}
	sr.Timestamp = time.Now().UTC()

	meta, err := skillRunToMetadata(sr)
	if err != nil {
		return nil, err
	}

	content := sr.SkillName
	if sr.Status == "error" && sr.Error != "" {
		content += " [ERROR: " + sr.Error + "]"
	}

	in := RememberInput{
		Type:     string(EntrySkillRun),
		Content:  content,
		Summary:  sr.SkillName,
		Scope:    "project",
		Project:  sr.Project,
		Session:  sr.SessionID,
		Agent:    sr.SourceAgent,
		Tags:     "skill_run",
		Metadata: meta,
	}
	return e.Remember(ctx, in)
}

// skillRunToMetadata serializes a SkillRunEntry into metadata key-value pairs.
func skillRunToMetadata(sr SkillRunEntry) (map[string]string, error) {
	return map[string]string{
		"entry_type":    string(sr.Type),
		"skill_name":    sr.SkillName,
		"skill_version": sr.SkillVersion,
		"params":        sr.Params,
		"result":        sr.Result,
		"status":        sr.Status,
		"duration_ms":   fmt.Sprintf("%d", sr.DurationMs),
		"error":         sr.Error,
		"project":       sr.Project,
		"session_id":    sr.SessionID,
		"source_agent":  sr.SourceAgent,
		"timestamp":     sr.Timestamp.Format(time.RFC3339Nano),
	}, nil
}
