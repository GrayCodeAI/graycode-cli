package engine

import (
	"context"
	"crypto/sha256"
	"fmt"
	"log/slog"
	"strings"

	"github.com/GrayCodeAI/harrier/compact"
	"github.com/GrayCodeAI/harrier/engine/cognitive"
	"github.com/GrayCodeAI/harrier/mental"
	"github.com/GrayCodeAI/harrier/profile"
	"github.com/GrayCodeAI/harrier/storage"
)

// Forget archives a node by setting confidence to 0.
func (e *Engine) Forget(ctx context.Context, id string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	e.mu.Lock()
	node, err := e.store.GetNode(ctx, id)
	if err != nil {
		e.mu.Unlock()
		return err
	}
	// Save version before archiving
	if err := e.store.SaveVersion(ctx, node.ID, node.Content, "system", "archived"); err != nil {
		e.mu.Unlock()
		return fmt.Errorf("save version failed: %w", err)
	}
	// Conditional write: archive only if the node is still live, so a
	// concurrent content update is never clobbered by a stale archive copy
	// (and a node already archived is not re-archived).
	e.mu.Unlock()
	archived, err := e.store.ArchiveNode(ctx, node.ID)
	if err != nil {
		return err
	}
	if !archived {
		slog.Debug("harrier: forget: node already archived or not live", "node_id", node.ID)
		return nil
	}

	// Update the MEMORY.md hot-pointer file if configured (best-effort).
	if rerr := e.renderMemoryFile(ctx); rerr != nil {
		slog.Warn("harrier: render memory file failed (best-effort)", "error", rerr)
	}

	// Notify watchers (SSE / future gRPC WatchMemories) that the node is gone.
	e.emitMemoryEvent(MemoryDeleted, node)
	return nil
}

// Status returns basic stats.
type Status struct {
	Nodes    int
	Edges    int
	Sessions int
}

// Compact merges low-confidence memories to keep the graph lean.
func (e *Engine) Compact(ctx context.Context, project string) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	c := compact.New(e.store, compactThreshold).WithSummarizer(e.summarizer)
	return c.Compact(ctx, project)
}

// MentalModel generates an auto-evolving project summary.
func (e *Engine) MentalModel(ctx context.Context, project string) (*mental.Model, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return mental.Generate(ctx, e.store, project)
}

// Profile returns an auto-maintained user/project profile (static facts + dynamic context).
func (e *Engine) Profile(ctx context.Context, project string) (*profile.Profile, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return profile.Build(ctx, e.store, project)
}

func (e *Engine) Status(ctx context.Context, project string) (*Status, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	// Use SQL COUNT instead of loading all nodes into memory
	_, totalNodes, err := e.store.NodeStats(ctx)
	if err != nil {
		return nil, fmt.Errorf("node stats: %w", err)
	}
	sessions, err := e.store.ListSessions(ctx, project, 1000)
	if err != nil {
		return nil, fmt.Errorf("list sessions: %w", err)
	}
	edgeCount, _ := e.store.CountAllEdges(ctx)
	return &Status{Nodes: totalNodes, Edges: edgeCount, Sessions: len(sessions)}, nil
}

// TimelineFilter returns a NodeFilter suitable for timeline display.
func TimelineFilter(limit int) storage.NodeFilter {
	if limit <= 0 {
		limit = 30
	}
	return storage.NodeFilter{Limit: limit}
}

// ContentHash computes a deterministic SHA-256 hash for node content.
func ContentHash(content, scope, project, nodeType string) string {
	h := sha256.Sum256([]byte(content + "\x00" + scope + "\x00" + project + "\x00" + nodeType))
	return fmt.Sprintf("%x", h)
}

// ConflictCandidate represents a potential conflicting node found via FTS.
type ConflictCandidate struct {
	NodeID  string
	Content string
	Score   float64
}

// FindConflictCandidates searches for existing nodes that may conflict with the given content.
// Uses FTS search scoped to the same node type, returning candidates above a score threshold.
func (e *Engine) FindConflictCandidates(ctx context.Context, nodeID, content string, limit int) ([]ConflictCandidate, error) {
	if limit <= 0 {
		limit = 5
	}
	// Use first 200 chars as search query to find similar nodes
	query := content
	if len(query) > 200 {
		query = query[:200]
	}
	nodes, err := e.store.SearchNodes(ctx, query, limit*2)
	if err != nil {
		return nil, err
	}
	const minScore = 0.3
	var candidates []ConflictCandidate
	for _, n := range nodes {
		if n.ID == nodeID {
			continue
		}
		// Compute term overlap as a simple similarity score
		s := termOverlap(content, n.Content)
		if s >= minScore {
			candidates = append(candidates, ConflictCandidate{
				NodeID:  n.ID,
				Content: n.Content,
				Score:   s,
			})
		}
		if len(candidates) >= limit {
			break
		}
	}
	return candidates, nil
}

// termOverlap computes Jaccard similarity of key terms between two strings.
func termOverlap(a, b string) float64 {
	termsA := keyTerms(a)
	termsB := keyTerms(b)
	if len(termsA) == 0 || len(termsB) == 0 {
		return 0
	}
	shared := 0
	for t := range termsA {
		if termsB[t] {
			shared++
		}
	}
	union := len(termsA) + len(termsB) - shared
	if union == 0 {
		return 0
	}
	return float64(shared) / float64(union)
}

func keyTerms(s string) map[string]bool {
	terms := map[string]bool{}
	for _, w := range strings.Fields(strings.ToLower(s)) {
		w = strings.Trim(w, ".,;:!?\"'()[]{}")
		if len(w) > 3 {
			terms[w] = true
		}
	}
	return terms
}

// ─────────────────────────────────────────────────────────────────────────────
// Cognitive engine convenience methods — wired into Engine struct for hawk
// and other consumers to access without managing separate engine instances.
// ─────────────────────────────────────────────────────────────────────────────

// OpenLoops returns active (unresolved) Zeigarnik loops.
// Returns nil if Zeigarnik engine is not wired.
func (e *Engine) OpenLoops(limit int) []*cognitive.OpenLoop {
	if e.zeigarnik == nil {
		return nil
	}
	return e.zeigarnik.GetActiveLoops(limit)
}

// ScanForOpenLoops scans text chunks for open loops and marks them.
// Returns the number of new loops detected.
func (e *Engine) ScanForOpenLoops(chunks []cognitive.ZeigarnikChunk) int {
	if e.zeigarnik == nil {
		return 0
	}
	return e.zeigarnik.ScanChunks(chunks)
}

// ResolveLoop marks a Zeigarnik loop as resolved.
func (e *Engine) ResolveLoop(chunkID string) {
	if e.zeigarnik == nil {
		return
	}
	e.zeigarnik.CloseLoop(chunkID)
}

// CheckTriggers checks prospective memory triggers against the given text.
// Returns triggered memories (nil if Prospective engine is not wired).
func (e *Engine) CheckTriggers(messageText string) []*cognitive.ProspectiveMemory {
	if e.prospective == nil {
		return nil
	}
	return e.prospective.CheckTriggers(messageText, nil)
}

// CreateProspective creates a new prospective memory entry.
func (e *Engine) CreateProspective(triggerCondition, action, sourceSession string, priority float64) *cognitive.ProspectiveMemory {
	if e.prospective == nil {
		return nil
	}
	return e.prospective.Create(triggerCondition, action, sourceSession, nil, priority)
}

// ActiveProspective returns all untriggered, unexpired prospective memories.
func (e *Engine) ActiveProspective() []*cognitive.ProspectiveMemory {
	if e.prospective == nil {
		return nil
	}
	return e.prospective.GetActive()
}

// EpistemicDirectives returns pending knowledge gap directives.
func (e *Engine) EpistemicDirectives() []*cognitive.EpistemicDirective {
	if e.epistemic == nil {
		return nil
	}
	return e.epistemic.GetForSession()
}

// CreateEpistemicDirective creates a new knowledge gap directive.
func (e *Engine) CreateEpistemicDirective(dtype cognitive.DirectiveType, question, context string, priority float64) *cognitive.EpistemicDirective {
	if e.epistemic == nil {
		return nil
	}
	return e.epistemic.CreateDirective(dtype, question, context, priority, nil)
}

// ResolveEpistemic marks a knowledge gap directive as resolved.
func (e *Engine) ResolveEpistemic(directiveID, resolution string) bool {
	if e.epistemic == nil {
		return false
	}
	return e.epistemic.Resolve(directiveID, resolution)
}

// RecordSomaticOutcome records a success/failure outcome for a memory region.
func (e *Engine) RecordSomaticOutcome(region string, success bool) {
	if e.somatic == nil {
		return
	}
	e.somatic.RecordOutcome(region, success)
}

// ShouldSkipSomatic returns true if a region should be skipped based on past failures.
func (e *Engine) ShouldSkipSomatic(region string) bool {
	if e.somatic == nil {
		return false
	}
	return e.somatic.ShouldSkip(region)
}

// ExplorationTargets returns top curiosity-driven exploration targets.
func (e *Engine) ExplorationTargets(limit int) []*cognitive.ExplorationTarget {
	if e.curiosity == nil {
		return nil
	}
	return e.curiosity.GetTopTargets(limit)
}

// RecordWorkflowStep records a tool-use step for procedural pattern learning.
func (e *Engine) RecordWorkflowStep(toolName string) {
	if e.procedural != nil {
		e.procedural.RecordStep(toolName)
	}
}

// ObserveWorkflow records a full tool sequence as a learned procedural pattern.
func (e *Engine) ObserveWorkflow(tools []string, trigger string, success bool) *cognitive.ProceduralMemory {
	if e.procedural == nil {
		return nil
	}
	return e.procedural.ObserveSequence(tools, trigger, success)
}

// SuggestWorkflowSteps returns the most likely next steps given observed tool names.
func (e *Engine) SuggestWorkflowSteps(prefix []string, limit int) []string {
	if e.procedural == nil {
		return nil
	}
	return e.procedural.SuggestSteps(prefix, limit)
}

// WorkflowPatterns returns all learned procedural patterns.
func (e *Engine) WorkflowPatterns(limit int) []*cognitive.ProceduralMemory {
	if e.procedural == nil {
		return nil
	}
	return e.procedural.GetPatterns(limit)
}

// DetectTopicBoundaries detects topic shifts in a conversation.
func (e *Engine) DetectTopicBoundaries(messages []string) []cognitive.TopicBoundary {
	if e.boundary == nil {
		return nil
	}
	return e.boundary.DetectBoundaries(messages)
}

// SegmentConversation splits a conversation into topic-coherent segments.
func (e *Engine) SegmentConversation(messages []string) [][]string {
	if e.boundary == nil {
		return [][]string{messages}
	}
	return e.boundary.SegmentByBoundaries(messages)
}

// ConsolidateTopics groups related memories into topic clusters.
func (e *Engine) ConsolidateTopics(ctx context.Context, project string) ([]*TopicCluster, error) {
	if e.consolidator == nil {
		return nil, nil
	}
	return e.consolidator.Consolidate(ctx, project)
}

// RankWithFactors re-scores recalled memories using multi-factor ranking.
func (e *Engine) RankWithFactors(ctx context.Context, nodes []*storage.Node, baseScores map[string]float64) []*RankedNode {
	if e.ranker == nil {
		return nil
	}
	return e.ranker.Rank(ctx, nodes, baseScores, e.store)
}

// CognitiveStatus returns a summary of all cognitive engine states.
func (e *Engine) CognitiveStatus() string {
	var parts []string

	if e.zeigarnik != nil {
		loops := e.zeigarnik.GetActiveLoops(100)
		parts = append(parts, fmt.Sprintf("open_loops: %d", len(loops)))
	}

	if e.prospective != nil {
		active := e.prospective.GetActive()
		parts = append(parts, fmt.Sprintf("prospective: %d", len(active)))
	}

	if e.epistemic != nil {
		directives := e.epistemic.GetForSession()
		parts = append(parts, fmt.Sprintf("epistemic_directives: %d", len(directives)))
	}

	if e.curiosity != nil {
		targets := e.curiosity.GetTopTargets(100)
		parts = append(parts, fmt.Sprintf("exploration_targets: %d", len(targets)))
	}

	if e.procedural != nil {
		patterns := e.procedural.GetPatterns(100)
		parts = append(parts, fmt.Sprintf("procedural_patterns: %d", len(patterns)))
	}

	if len(parts) == 0 {
		return "cognitive_engines: none_wired"
	}

	return "cognitive_engines: " + strings.Join(parts, ", ")
}
