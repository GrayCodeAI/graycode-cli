package engine

import (
	"context"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// TemporalFilter enables time-bounded memory retrieval.
// Based on Zep's valid_at/invalid_at interval model layered on top of harrier's
// temporal backbone.
//
// Supports queries like:
//   - "What was true at time X?" (point-in-time)
//   - "What changed between X and Y?" (range)
//   - "What's currently valid?" (active only)
type TemporalFilter struct {
	store storage.Storage
}

// TemporalQuery specifies time constraints for retrieval.
type TemporalQuery struct {
	After      time.Time // only nodes created/updated after this time
	Before     time.Time // only nodes created/updated before this time
	ActiveOnly bool      // only nodes not superseded (no invalid_at on edges)
}

// NewTemporalFilter creates a temporal filter.
func NewTemporalFilter(store storage.Storage) *TemporalFilter {
	return &TemporalFilter{store: store}
}

// FilterByTime returns nodes that match the temporal constraints.
func (tf *TemporalFilter) FilterByTime(ctx context.Context, nodes []*storage.Node, query TemporalQuery) []*storage.Node {
	var filtered []*storage.Node
	for _, n := range nodes {
		if tf.matchesTemporal(n, query) {
			filtered = append(filtered, n)
		}
	}
	return filtered
}

// RecentSince returns nodes created or updated since the given time.
func (tf *TemporalFilter) RecentSince(ctx context.Context, since time.Time, limit int) ([]*storage.Node, error) {
	nodes, err := tf.store.ListNodes(ctx, storage.NodeFilter{Limit: limit * 3})
	if err != nil {
		return nil, err
	}

	var recent []*storage.Node
	for _, n := range nodes {
		ref := n.UpdatedAt
		if !n.AccessedAt.IsZero() && n.AccessedAt.After(ref) {
			ref = n.AccessedAt
		}
		if ref.After(since) || ref.Equal(since) {
			recent = append(recent, n)
		}
	}

	if len(recent) > limit {
		recent = recent[:limit]
	}
	return recent, nil
}

// ChangedBetween returns nodes that were created or modified in a time range.
func (tf *TemporalFilter) ChangedBetween(ctx context.Context, start, end time.Time, limit int) ([]*storage.Node, error) {
	nodes, err := tf.store.ListNodes(ctx, storage.NodeFilter{Limit: limit * 3})
	if err != nil {
		return nil, err
	}

	var ranged []*storage.Node
	for _, n := range nodes {
		created := n.CreatedAt
		updated := n.UpdatedAt
		if (created.After(start) || created.Equal(start)) && (created.Before(end) || created.Equal(end)) {
			ranged = append(ranged, n)
		} else if (updated.After(start) || updated.Equal(start)) && (updated.Before(end) || updated.Equal(end)) {
			ranged = append(ranged, n)
		}
	}

	if len(ranged) > limit {
		ranged = ranged[:limit]
	}
	return ranged, nil
}

// IsSuperseded checks if a node has been superseded by another via edge.
func (tf *TemporalFilter) IsSuperseded(ctx context.Context, nodeID string) (bool, string) {
	edges, err := tf.store.GetEdgesTo(ctx, nodeID)
	if err != nil {
		return false, ""
	}
	for _, e := range edges {
		if e.Type == "supersedes" && e.InvalidAt.IsZero() {
			return true, e.FromID
		}
	}
	return false, ""
}

// ActiveEdges returns only currently-valid edges (invalid_at is zero).
func (tf *TemporalFilter) ActiveEdges(ctx context.Context, nodeID string) ([]*storage.Edge, error) {
	edges, err := tf.store.GetEdgesFrom(ctx, nodeID)
	if err != nil {
		return nil, err
	}

	var active []*storage.Edge
	for _, e := range edges {
		if e.InvalidAt.IsZero() {
			active = append(active, e)
		}
	}
	return active, nil
}

func (tf *TemporalFilter) matchesTemporal(n *storage.Node, q TemporalQuery) bool {
	ref := n.UpdatedAt
	if ref.IsZero() {
		ref = n.CreatedAt
	}

	if !q.After.IsZero() && ref.Before(q.After) {
		return false
	}
	if !q.Before.IsZero() && ref.After(q.Before) {
		return false
	}
	return true
}
