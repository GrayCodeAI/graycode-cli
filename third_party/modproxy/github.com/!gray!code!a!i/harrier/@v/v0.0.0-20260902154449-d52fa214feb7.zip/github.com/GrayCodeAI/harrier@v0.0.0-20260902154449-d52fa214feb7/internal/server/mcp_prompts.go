package server

import (
	"context"
	"fmt"
	"os"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/skill"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/mark3labs/mcp-go/mcp"
)

// --- prompts ---

func (s *MCPServer) registerPrompts() {
	s.srv.AddPrompt(mcp.NewPrompt(
		"recall_context",
		mcp.WithPromptDescription("Search memory and format as injectable context"),
		mcp.WithArgument("query", mcp.ArgumentDescription("Search query"), mcp.RequiredArgument()),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path filter")),
		mcp.WithArgument("depth", mcp.ArgumentDescription("Graph expansion depth (default 2)")),
	), s.handlePromptRecallContext)

	s.srv.AddPrompt(mcp.NewPrompt(
		"session_handoff",
		mcp.WithPromptDescription("Generate handoff summary for session continuation"),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path")),
	), s.handlePromptSessionHandoff)

	// Task #153: Additional MCP prompts

	s.srv.AddPrompt(mcp.NewPrompt(
		"summarize_context",
		mcp.WithPromptDescription("Generate a concise summary of the current memory context for a project"),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path")),
		mcp.WithArgument("max_tokens", mcp.ArgumentDescription("Maximum tokens for summary (default 500)")),
	), s.handlePromptSummarizeContext)

	s.srv.AddPrompt(mcp.NewPrompt(
		"memory_search",
		mcp.WithPromptDescription("Search memories and format results with relevance ranking"),
		mcp.WithArgument("query", mcp.ArgumentDescription("Search query"), mcp.RequiredArgument()),
		mcp.WithArgument("type", mcp.ArgumentDescription("Filter by node type (convention|decision|bug|spec|task|preference)")),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path filter")),
	), s.handlePromptMemorySearch)

	s.srv.AddPrompt(mcp.NewPrompt(
		"knowledge_graph",
		mcp.WithPromptDescription("Get an overview of the memory knowledge graph structure and key nodes"),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path")),
		mcp.WithArgument("focus", mcp.ArgumentDescription("Focus area: all|conventions|decisions|tasks|bugs")),
	), s.handlePromptKnowledgeGraph)

	s.srv.AddPrompt(mcp.NewPrompt(
		"skill_replay",
		mcp.WithPromptDescription("Retrieve and format a stored procedural skill for execution"),
		mcp.WithArgument("name", mcp.ArgumentDescription("Skill name"), mcp.RequiredArgument()),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path")),
	), s.handlePromptSkillReplay)

	s.srv.AddPrompt(mcp.NewPrompt(
		"session_recap",
		mcp.WithPromptDescription("Show what was captured in the last session to pick up where you left off"),
		mcp.WithArgument("project", mcp.ArgumentDescription("Project path")),
	), s.handlePromptSessionRecap)

	s.srv.AddPrompt(mcp.NewPrompt(
		"impact_analysis",
		mcp.WithPromptDescription("Analyze what memories would be affected by a file change"),
		mcp.WithArgument("file", mcp.ArgumentDescription("File path to analyze"), mcp.RequiredArgument()),
		mcp.WithArgument("depth", mcp.ArgumentDescription("Traversal depth (default 3)")),
	), s.handlePromptImpactAnalysis)
}

func (s *MCPServer) handlePromptRecallContext(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	query := req.Params.Arguments["query"]
	project := req.Params.Arguments["project"]
	depth := 2
	if d, ok := req.Params.Arguments["depth"]; ok && d != "" {
		_, _ = fmt.Sscanf(d, "%d", &depth)
	}

	result, err := s.eng.Recall(ctx, engine.RecallOpts{
		Query:   query,
		Depth:   depth,
		Limit:   10,
		Project: project,
	})
	if err != nil {
		return nil, err
	}

	text := engine.FormatContext(result.Nodes)
	return &mcp.GetPromptResult{
		Description: "Retrieved context for: " + query,
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptSessionHandoff(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	project := req.Params.Arguments["project"]

	result, err := s.eng.Context(ctx, project)
	if err != nil {
		return nil, err
	}

	text := "## Session Handoff\n\n"
	text += "Here is the relevant context from previous sessions:\n\n"
	text += engine.FormatContext(result.Nodes)

	return &mcp.GetPromptResult{
		Description: "Session handoff context",
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

// Task #153: Additional prompt handlers

func (s *MCPServer) handlePromptSummarizeContext(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	project := req.Params.Arguments["project"]
	budget := 500
	if b, ok := req.Params.Arguments["max_tokens"]; ok && b != "" {
		_, _ = fmt.Sscanf(b, "%d", &budget)
	}

	result, err := s.eng.Context(ctx, project)
	if err != nil {
		return nil, err
	}

	packer := engine.NewContextPacker(budget)
	packed := packer.Pack(result.Nodes)

	text := "## Memory Context Summary\n\n"
	text += fmt.Sprintf("*%d nodes packed into %d tokens*\n\n", packed.NodesUsed, packed.TokensUsed)
	text += packed.Content

	if len(packed.TypeCounts) > 0 {
		text += "\n### Breakdown\n"
		for typ, count := range packed.TypeCounts {
			text += fmt.Sprintf("- %s: %d\n", typ, count)
		}
	}

	return &mcp.GetPromptResult{
		Description: fmt.Sprintf("Context summary: %d nodes, %d tokens", packed.NodesUsed, packed.TokensUsed),
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptMemorySearch(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	query := req.Params.Arguments["query"]
	project := req.Params.Arguments["project"]
	nodeType := req.Params.Arguments["type"]

	result, err := s.eng.Recall(ctx, engine.RecallOpts{
		Query:   query,
		Depth:   2,
		Limit:   10,
		Type:    nodeType,
		Project: project,
	})
	if err != nil {
		return nil, err
	}

	text := fmt.Sprintf("## Memory Search Results\n\n**Query**: %s\n", query)
	if nodeType != "" {
		text += fmt.Sprintf("**Filter**: %s nodes only\n", nodeType)
	}
	text += fmt.Sprintf("**Found**: %d memories\n\n", len(result.Nodes))

	for i, node := range result.Nodes {
		content := node.Content
		if len(content) > 200 {
			content = content[:200] + "..."
		}
		text += fmt.Sprintf("%d. **[%s]** %s\n", i+1, node.Type, content)
		if node.Summary != "" {
			text += fmt.Sprintf("   *Summary*: %s\n", node.Summary)
		}
		text += "\n"
	}

	return &mcp.GetPromptResult{
		Description: fmt.Sprintf("Found %d memories for: %s", len(result.Nodes), query),
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptKnowledgeGraph(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	_ = req.Params.Arguments["project"] // project filter reserved for future use
	focus := req.Params.Arguments["focus"]
	if focus == "" {
		focus = "all"
	}

	// Get stats
	stats, err := s.eng.GetMemoryStats(ctx)
	if err != nil {
		return nil, err
	}

	text := "## Knowledge Graph Overview\n\n"
	text += fmt.Sprintf("**Total Nodes**: %d\n", stats.TotalNodes)
	text += fmt.Sprintf("**Total Edges**: %d\n", stats.TotalEdges)
	text += fmt.Sprintf("**Last Updated**: %s\n\n", stats.LastUpdated.Format("2006-01-02 15:04:05"))

	// Node type breakdown
	text += "### Node Types\n"
	for typ, count := range stats.NodesByType {
		if focus == "all" || focus == typ+"s" {
			text += fmt.Sprintf("- %s: %d\n", typ, count)
		}
	}
	text += "\n"

	// Top connected nodes
	if len(stats.TopTopics) > 0 {
		text += "### Most Connected Topics\n"
		for _, topic := range stats.TopTopics {
			text += fmt.Sprintf("- %s\n", topic)
		}
		text += "\n"
	}

	// Get communities for thematic overview
	cd := engine.NewCommunityDetector(s.eng.Store())
	communities, err := cd.Detect(ctx, 5)
	if err == nil && len(communities) > 0 {
		communities = cd.Summarize(ctx, communities)
		text += "### Thematic Clusters\n"
		for _, c := range communities {
			text += fmt.Sprintf("- **Cluster %d** (%d nodes): %s\n", c.ID, c.Size, c.Summary)
		}
	}

	return &mcp.GetPromptResult{
		Description: "Knowledge graph overview",
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptSkillReplay(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	name := req.Params.Arguments["name"]
	project := req.Params.Arguments["project"]
	if project == "" {
		project, _ = os.Getwd()
	}

	sk, err := skill.Load(ctx, s.eng.Store(), name, project)
	if err != nil {
		return nil, fmt.Errorf("skill %q not found: %w", name, err)
	}

	text := skill.Replay(sk)

	return &mcp.GetPromptResult{
		Description: fmt.Sprintf("Skill: %s", sk.Name),
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptSessionRecap(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	project := req.Params.Arguments["project"]

	sessions, err := s.eng.Store().ListSessions(ctx, project, 1)
	if err != nil {
		return nil, err
	}
	if len(sessions) == 0 {
		return &mcp.GetPromptResult{
			Description: "No previous sessions found",
			Messages: []mcp.PromptMessage{
				mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent("No previous sessions found. Starting fresh.")),
			},
		}, nil
	}

	last := sessions[0]
	nodes, err := s.eng.Store().ListNodes(ctx, storage.NodeFilter{
		Project:       project,
		SourceSession: last.ID,
	})
	if err != nil {
		return nil, err
	}

	text := "## Session Recap\n\n"
	text += fmt.Sprintf("**Last Session**: %s\n", last.ID[:8])
	text += fmt.Sprintf("**Started**: %s\n\n", last.StartedAt.Format("2006-01-02 15:04"))

	if len(nodes) == 0 {
		text += "No memories were captured in the last session.\n"
	} else {
		text += fmt.Sprintf("**Captured %d memories:**\n\n", len(nodes))
		text += engine.FormatContext(nodes)
	}

	return &mcp.GetPromptResult{
		Description: fmt.Sprintf("Session recap: %d memories", len(nodes)),
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}

func (s *MCPServer) handlePromptImpactAnalysis(ctx context.Context, req mcp.GetPromptRequest) (*mcp.GetPromptResult, error) {
	file := req.Params.Arguments["file"]
	depth := 3
	if d, ok := req.Params.Arguments["depth"]; ok && d != "" {
		_, _ = fmt.Sscanf(d, "%d", &depth)
	}
	if depth <= 0 || depth > 5 {
		depth = 3
	}

	ids, err := s.eng.Graph().Impact(ctx, file, depth)
	if err != nil {
		return nil, err
	}

	text := fmt.Sprintf("## Impact Analysis\n\n**File**: %s\n**Traversal Depth**: %d\n\n", file, depth)

	if len(ids) == 0 {
		text += "No memories would be affected by changes to this file.\n"
	} else {
		text += fmt.Sprintf("**%d memories would be affected:**\n\n", len(ids))

		// Resolve IDs to nodes for details
		var nodes []*storage.Node
		for _, id := range ids {
			n, err := s.eng.Store().GetNode(ctx, id)
			if err == nil {
				nodes = append(nodes, n)
			}
		}

		for i, node := range nodes {
			content := node.Content
			if len(content) > 100 {
				content = content[:100] + "..."
			}
			text += fmt.Sprintf("%d. **[%s]** %s\n", i+1, node.Type, content)
		}

		text += "\n**Recommendation**: Review these memories before making changes to ensure consistency.\n"
	}

	return &mcp.GetPromptResult{
		Description: fmt.Sprintf("Impact analysis for %s: %d affected memories", file, len(ids)),
		Messages: []mcp.PromptMessage{
			mcp.NewPromptMessage(mcp.RoleUser, mcp.NewTextContent(text)),
		},
	}, nil
}
