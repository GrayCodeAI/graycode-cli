//nolint:gocritic
package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestHierarchicalMemory_Build(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()
	// Add enough nodes for clustering
	_ = store.CreateNode(ctx, &storage.Node{ID: "h1", Type: "convention", Content: "Use `jose` for JWT", Scope: "project", Confidence: 0.9})
	_ = store.CreateNode(ctx, &storage.Node{ID: "h2", Type: "convention", Content: "Use jose library always", Scope: "project", Confidence: 0.8})
	_ = store.CreateNode(ctx, &storage.Node{ID: "h3", Type: "decision", Content: "Chose jose over jsonwebtoken", Scope: "project", Confidence: 0.85})
	_ = store.CreateNode(ctx, &storage.Node{ID: "h4", Type: "decision", Content: "PostgreSQL for database", Scope: "project", Confidence: 0.7})
	_ = store.CreateNode(ctx, &storage.Node{ID: "h5", Type: "bug", Content: "Token refresh race condition", Scope: "project", Confidence: 0.6})

	hm := NewHierarchicalMemory(store)
	if err := hm.Build(ctx); err != nil {
		t.Fatalf("Build failed: %v", err)
	}

	// Level 2 should have type-based clusters (need MinConfidence >= 0.2)
	if hm.levels[2] == nil {
		t.Log("level 2 is nil — possibly not enough nodes above MinConfidence threshold")
	} else if len(hm.levels[2].Clusters) == 0 {
		t.Log("level 2 has 0 clusters — may need more data")
	} else {
		t.Logf("level 2 has %d clusters", len(hm.levels[2].Clusters))
	}
}

func TestHierarchicalMemory_RetrieveAdaptive(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	hm := NewHierarchicalMemory(store)

	// Specific query → level 0
	if level := hm.RetrieveAdaptive("src/auth.ts"); level != 0 {
		t.Errorf("file path query should be level 0, got %d", level)
	}

	// Function call → level 0
	if level := hm.RetrieveAdaptive("validateToken()"); level != 0 {
		t.Errorf("function query should be level 0, got %d", level)
	}

	// Global query → level 2
	if level := hm.RetrieveAdaptive("what are the main patterns?"); level != 2 {
		t.Errorf("global query should be level 2, got %d", level)
	}

	// Overview → level 2
	if level := hm.RetrieveAdaptive("give me an overview"); level != 2 {
		t.Errorf("overview query should be level 2, got %d", level)
	}

	// Medium specificity → level 1
	if level := hm.RetrieveAdaptive("auth library decision"); level != 1 {
		t.Errorf("topic query should be level 1, got %d", level)
	}
}

func TestHierarchicalMemory_FormatLevel(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	hm := NewHierarchicalMemory(store)
	// Before build, should return empty
	if s := hm.FormatLevel(1); s != "" {
		t.Errorf("expected empty format before Build, got %q", s)
	}
	if s := hm.FormatLevel(-1); s != "" {
		t.Error("negative level should return empty")
	}
	if s := hm.FormatLevel(99); s != "" {
		t.Error("out of bounds level should return empty")
	}
}
