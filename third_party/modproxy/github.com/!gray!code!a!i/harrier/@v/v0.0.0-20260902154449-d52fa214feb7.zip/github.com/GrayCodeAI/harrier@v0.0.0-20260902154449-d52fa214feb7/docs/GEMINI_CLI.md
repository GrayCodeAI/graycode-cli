# Gemini CLI Integration Guide for Harrier

## Overview

[Gemini CLI](https://github.com/google-gemini/gemini-cli) agents can use **Harrier** as a model-agnostic, persistent memory engine over **MCP (Model Context Protocol)** or **REST API**.

---

## Setup Options

### Option 1: MCP Server Setup (Stdio)

Add Harrier to your `~/.gemini/config.json` or project MCP settings:

```json
{
  "mcpServers": {
    "harrier": {
      "command": "harrier",
      "args": ["mcp"],
      "env": {
        "HARRIER_PROJECT_DIR": "${workspaceFolder}"
      }
    }
  }
}
```

### Option 2: REST API Setup

Start the Harrier daemon:

```bash
harrier server --port 3456
```

Configure Gemini CLI HTTP tools pointing to `http://localhost:3456/harrier`.

---

## Usage Workflow

1. **Remember context**: Call `harrier_remember` when saving architectural decisions, conventions, or bug fixes.
2. **Context preloading**: Before generating responses, Gemini CLI queries `harrier_context` or `harrier_recall` to pull hot/warm memory subgraphs.
3. **Session summary**: At session completion, call `harrier_session_end` to compress and consolidate session logs into long-term graph memory.
