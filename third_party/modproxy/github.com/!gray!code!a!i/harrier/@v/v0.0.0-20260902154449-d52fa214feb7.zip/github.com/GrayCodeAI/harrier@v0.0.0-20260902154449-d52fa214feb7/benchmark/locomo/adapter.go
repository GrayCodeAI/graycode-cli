package locomo

import (
	"fmt"

	"github.com/GrayCodeAI/harrier/engine"
	bench "github.com/GrayCodeAI/harrier/internal/bench"
)

// SeedInputs converts a Sample's dialogue turns into engine.RememberInput
// values, one per turn ("<speaker>: <text>"), tagged with project=sample_id.
// The project tag is informational only: bench.Run's Recall calls don't
// filter by project, so true isolation between LoCoMo-10's 10 independent
// conversations comes from running each sample against its own freshly
// seeded *engine.Engine (see locomobench/main.go), not from this tag —
// seeding multiple samples into one shared engine would let recall answer
// one conversation's questions from another's dialogue, which is a
// correctness bug, not a harder benchmark. Type "session" is the closest
// fit among harrier's node types (convention/decision/bug/spec/task/
// preference/skill/file/entity/session) for raw conversational content —
// the others are coding-specific and don't apply to LoCoMo's chat
// transcripts.
func (s Sample) SeedInputs() []engine.RememberInput {
	var inputs []engine.RememberInput
	for _, sess := range s.Sessions() {
		for _, turn := range sess.Turns {
			inputs = append(inputs, engine.RememberInput{
				Type:    "session",
				Content: fmt.Sprintf("%s: %s", turn.Speaker, turn.Text),
				Scope:   "project",
				Project: s.SampleID,
				Tags:    "locomo," + turn.DiaID,
			})
		}
	}
	return inputs
}

// ToQAs converts a Sample's QA pairs into bench.QA, matching by expected
// content (the LoCoMo answer text) rather than by node ID, since LoCoMo's
// answers are free-text, not references to specific ingested nodes.
//
// Category-5 (adversarial/unanswerable) questions are skipped: they carry
// no "answer" field, only "adversarial_answer" (real-world context for why
// the question is unanswerable) — bench's substring-match harness has no
// way to score "correctly recalled nothing," so including them would just
// be permanent misses inflating the miss count without measuring anything
// real.
//
// This is a real, documented harness limitation, not a LoCoMo-specific one:
// LoCoMo's own official evaluation grades answers via an LLM judge against
// free-text generation, not a substring-match-in-top-K retrieval hit; a
// substring match is a materially weaker (but network/API-key-free, fully
// offline) proxy. Treat these numbers as a retrieval-hit proxy score, not
// as directly comparable to published LoCoMo leaderboard numbers, which
// score generation quality, not retrieval.
func (s Sample) ToQAs() []bench.QA {
	var qas []bench.QA
	for _, qa := range s.QA {
		if qa.Category == categoryAdversarial {
			continue
		}
		answer := qa.AnswerText()
		if answer == "" {
			continue
		}
		qas = append(qas, bench.QA{
			Question:        qa.Question,
			ExpectedContent: answer,
		})
	}
	return qas
}
