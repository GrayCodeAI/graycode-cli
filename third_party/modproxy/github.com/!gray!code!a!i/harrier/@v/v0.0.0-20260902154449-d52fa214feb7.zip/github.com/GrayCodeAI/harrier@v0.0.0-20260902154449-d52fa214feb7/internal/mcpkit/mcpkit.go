// Package mcpkit provides the shared scaffolding used by hawk-ecosystem
// libraries (merlin, kestrel, ...) to expose their functionality as MCP
// servers. It wraps github.com/mark3labs/mcp-go with the ecosystem's
// standard construction, transports, and small handler helpers so that
// individual repos only declare their tools and handlers.
package mcpkit

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	mcp "github.com/mark3labs/mcp-go/mcp"
	mcpserver "github.com/mark3labs/mcp-go/server"
)

// MaxMCPRequestBodySize caps the body of any MCP-over-HTTP request so every
// MCP HTTP surface in the ecosystem has the same resource-exhaustion
// protection. It is applied in httpTokenHandler (HTTP-token path) and
// capBody (bearer-only and no-auth paths).
const MaxMCPRequestBodySize = 1 << 20 // 1 MB

// Server wraps an mcp-go MCPServer with the ecosystem's standard
// transports (stdio, streamable HTTP, and SSE).
type Server struct {
	mcp                 *mcpserver.MCPServer
	bearerToken         string
	bearerMiddlewareSet bool
	httpToken           string
	serverStartErr      chan error
	toolIndex           *ToolSearchIndex
	vault               *CredentialVault
}

// New creates a named MCP server with tool, prompt, and resource
// capabilities enabled. Default capabilities match the ecosystem
// convention (tool + prompt + read-only, no resource-list-changed
// updates). Pass extra mcpserver.ServerOptions to override — they are
// applied after the defaults, so a later option wins over an earlier one.
// This lets repos like harrier (which expose a resource *list* rather than a
// set of subscribable resources) tailor behavior without forks.
func New(name, version string, opts ...mcpserver.ServerOption) *Server {
	base := []mcpserver.ServerOption{
		mcpserver.WithToolCapabilities(true),
		mcpserver.WithPromptCapabilities(true),
		mcpserver.WithResourceCapabilities(false, true),
	}
	return &Server{
		mcp: mcpserver.NewMCPServer(name, version, append(base, opts...)...),
	}
}

// AddTool registers a tool and its handler.
func (s *Server) AddTool(tool mcp.Tool, handler mcpserver.ToolHandlerFunc) {
	s.mcp.AddTool(tool, handler)
}

// AddPrompt registers a prompt and its handler.
func (s *Server) AddPrompt(prompt mcp.Prompt, handler mcpserver.PromptHandlerFunc) {
	s.mcp.AddPrompt(prompt, handler)
}

// AddResource registers a resource and its handler.
func (s *Server) AddResource(resource mcp.Resource, handler mcpserver.ResourceHandlerFunc) {
	s.mcp.AddResource(resource, handler)
}

// AddResourceTemplate registers a resource template and its handler.
func (s *Server) AddResourceTemplate(template mcp.ResourceTemplate, handler mcpserver.ResourceTemplateHandlerFunc) {
	s.mcp.AddResourceTemplate(template, handler)
}

// MCP returns the underlying mcp-go server, as an escape hatch for
// capabilities mcpkit does not wrap.
func (s *Server) MCP() *mcpserver.MCPServer {
	return s.mcp
}

// RequireBearerToken configures ServeHTTP to reject tool
// calls that don't present a matching "Authorization: Bearer <token>"
// header. Pass "" (the default) for no auth requirement.
//
// This only gates tool calls, not resources or prompts: mcp-go's
// resource/prompt middleware are construction-time-only ServerOptions with
// no post-construction equivalent to the tool middleware's Use() method,
// so wiring them here would require restructuring New() itself. Given
// mcpkit's resource capability is already read-only
// (WithResourceCapabilities(false, true)) and tools are the primary
// capability, tool-only gating is the deliberate scope here.
//
// ServeStdio is never affected, regardless of this setting: stdio is a
// locally-spawned child process with no network exposure, not a transport
// this check is meant to protect.
func (s *Server) RequireBearerToken(token string) {
	s.bearerToken = token
	// Register once against the shared underlying server — not per-serve in
	// buildHTTPServer, where a call-stack of ServeHTTP/WithShutdown would
	// otherwise append duplicate middleware on every invocation.
	if token != "" && !s.bearerMiddlewareSet {
		s.mcp.Use(bearerToolMiddleware(token))
		s.bearerMiddlewareSet = true
	}
}

// WithHTTPToken configures ServeHTTP and ServeHTTPWithShutdown to reject
// every request that doesn't present a matching token, either as
// "Authorization: Bearer <token>" or "X-API-Key: <token>". Pass "" (the
// default) for no HTTP-level gate.
//
// Unlike RequireBearerToken (which only gates tool calls via mcp-go's tool
// middleware), WithHTTPToken gates the entire HTTP surface — initialize,
// resources, prompts, and tools alike — at the transport boundary. Use this
// when the server holds data that shouldn't be discoverable without auth
// (e.g. a per-user memory store). It is opt-in and does not affect repos
// that leave it unset.
//
// ServeStdio is never affected, regardless of this setting, for the same
// trust rationale as RequireBearerToken: stdio is a local subprocess pipe.
func (s *Server) WithHTTPToken(token string) {
	s.httpToken = token
}

// GraphMIMEType is the ecosystem standard media type for graph projections.
const GraphMIMEType = "application/vnd.hawk.graph+json"

// AddGraphResource registers a read-only graph JSON resource.
// The provider function must return a struct or map that can be marshaled to JSON.
func (s *Server) AddGraphResource(uri, name string, provider func(context.Context) (any, error)) {
	s.mcp.AddResource(
		mcp.NewResource(uri, name, mcp.WithMIMEType(GraphMIMEType)),
		graphResourceHandler(provider),
	)
}

func graphResourceHandler(provider func(context.Context) (any, error)) mcpserver.ResourceHandlerFunc {
	return func(ctx context.Context, req mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
		graph, err := provider(ctx)
		if err != nil {
			return nil, err
		}
		data, err := json.MarshalIndent(graph, "", "  ")
		if err != nil {
			return nil, err
		}
		return []mcp.ResourceContents{
			mcp.TextResourceContents{
				URI:      req.Params.URI,
				MIMEType: GraphMIMEType,
				Text:     string(data),
			},
		}, nil
	}
}

// ServeStdio serves MCP over stdin/stdout and blocks until the stream
// closes or the context that mcp-go derives internally is done.
func (s *Server) ServeStdio() error {
	return mcpserver.ServeStdio(s.mcp)
}

// ServeHTTP serves MCP over the streamable HTTP transport at
// http://<addr>/mcp and blocks until the server stops.
//
// Auth precedence: if WithHTTPToken was set, every request is gated at the
// transport boundary (bearer or X-API-Key). Otherwise, if RequireBearerToken
// was set, only tool calls without a matching bearer header are rejected.
// The two modes are mutually exclusive at the HTTP boundary — set at most
// one.
func (s *Server) ServeHTTP(addr string) error {
	httpServer, err := s.buildHTTPServer(addr)
	if err != nil {
		return err
	}
	return httpServer.Start(addr)
}

// ServeHTTPWithShutdown serves MCP over the streamable HTTP transport at
// http://<addr>/mcp and returns the underlying server so the caller can
// invoke Shutdown(ctx) for graceful teardown. It launches the listener in a
// background goroutine and returns immediately (once the server object
// exists), so the caller owns the lifecycle. Poll UntilReady on the returned
// server to wait for the listener to come up before calling Shutdown. See
// ServeHTTP for auth semantics.
func (s *Server) ServeHTTPWithShutdown(addr string) (*mcpserver.StreamableHTTPServer, error) {
	httpServer, err := s.buildHTTPServer(addr)
	if err != nil {
		return nil, err
	}
	s.serverStartErr = make(chan error, 1)
	go func() { s.serverStartErr <- httpServer.Start(addr) }()
	return httpServer, nil
}

// StartErr returns a channel that receives the error (or nil) from the
// background HTTP server goroutine started by ServeHTTPWithShutdown.
// Returns nil if no HTTP server has been started.
func (s *Server) StartErr() <-chan error {
	return s.serverStartErr
}

// Validate checks that the server's auth configuration is internally consistent.
// It should be called after all auth setters are applied and before serving.
func (s *Server) Validate() error {
	if s.bearerToken != "" && s.httpToken != "" {
		return fmt.Errorf("mcpkit: cannot set both RequireBearerToken and WithHTTPToken; use at most one")
	}
	return nil
}

// buildHTTPServer constructs the streamable HTTP transport, applying the
// configured auth mode. WithHTTPToken gates the whole HTTP handler;
// otherwise RequireBearerToken (if set) gates tool calls via mcp-go's
// bearer context-func + tool middleware.
func (s *Server) buildHTTPServer(addr string) (*mcpserver.StreamableHTTPServer, error) {
	if err := s.Validate(); err != nil {
		return nil, err
	}
	streamable := mcpserver.NewStreamableHTTPServer(s.mcp)
	if s.bearerToken != "" && s.httpToken == "" {
		// bearerToolMiddleware is registered once in RequireBearerToken; here
		// we only attach the per-request context func that feeds it.
		streamable = mcpserver.NewStreamableHTTPServer(
			s.mcp,
			mcpserver.WithHTTPContextFunc(bearerHTTPContextFunc(s.bearerToken)),
		)
	}
	if s.httpToken != "" {
		streamable = mcpserver.NewStreamableHTTPServer(s.mcp, mcpserver.WithStreamableHTTPServer(&http.Server{
			Addr:    addr,
			Handler: httpTokenHandler(s.httpToken, streamable),
		}))
	} else {
		// Cap the request body on the bearer-only and no-auth paths so that
		// every MCP HTTP surface has the same resource-exhaustion protection
		// as the HTTP-token path (httpTokenHandler applies MaxBytesReader
		// internally).
		streamable = mcpserver.NewStreamableHTTPServer(s.mcp, mcpserver.WithStreamableHTTPServer(&http.Server{
			Addr:    addr,
			Handler: capBodyHandler(streamable),
		}))
	}
	return streamable, nil
}

// capBodyHandler wraps next so that every request body is bounded by
// MaxMCPRequestBodySize, protecting against resource exhaustion from
// oversized payloads. It mirrors the cap that httpTokenHandler applies on
// the HTTP-token path.
func capBodyHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, MaxMCPRequestBodySize)
		next.ServeHTTP(w, r)
	})
}

// httpTokenHandler wraps a streamable MCP handler so that every request must
// present a matching bearer or X-API-Key token, and caps the request body.
func httpTokenHandler(token string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, MaxMCPRequestBodySize)
		got := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		if got == "" {
			got = r.Header.Get("X-API-Key")
		}
		if !constantTimeCompareStrings(got, token) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			_, _ = w.Write([]byte(`{"error":"unauthorized"}`))
			return
		}
		next.ServeHTTP(w, r)
	})
}

// constantTimeCompareStrings compares two strings in constant time. It returns
// false immediately when the lengths differ (leaking only the length mismatch,
// which is required because subtle.ConstantTimeCompare needs equal-length
// inputs). The caller is responsible for providing equal-length tokens.
func constantTimeCompareStrings(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}

type bearerAuthorizedKey struct{}

func checkBearer(r *http.Request, token string) bool {
	expected := "Bearer " + token
	got := r.Header.Get("Authorization")
	return constantTimeCompareStrings(got, expected)
}

// bearerHTTPContextFunc validates the incoming request's Authorization
// header and stashes the result in context for bearerToolMiddleware to
// check. It never rejects the request itself — mcp-go's HTTPContextFunc
// has no way to do that — enforcement happens in the tool middleware.
func bearerHTTPContextFunc(token string) mcpserver.HTTPContextFunc {
	return func(ctx context.Context, r *http.Request) context.Context {
		return context.WithValue(ctx, bearerAuthorizedKey{}, checkBearer(r, token))
	}
}

// bearerToolMiddleware rejects a tool call unless bearerHTTPContextFunc
// marked its context as authorized. A plain Go error
// return (rather than a *mcp.CallToolResult) mirrors mcp-go's own
// WithRecovery middleware, which mcp-go turns into a protocol-level error
// response.
func bearerToolMiddleware(token string) mcpserver.ToolHandlerMiddleware {
	return func(next mcpserver.ToolHandlerFunc) mcpserver.ToolHandlerFunc {
		return func(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
			authorized, _ := ctx.Value(bearerAuthorizedKey{}).(bool)
			if !authorized {
				return nil, fmt.Errorf("unauthorized: missing or invalid bearer token")
			}
			return next(ctx, req)
		}
	}
}

// StrArg extracts a string argument from a tool call request. Returns
// "" when absent or not a string.
func StrArg(req mcp.CallToolRequest, key string) string {
	if v, ok := req.GetArguments()[key].(string); ok {
		return v
	}
	return ""
}

// JSONResult marshals v as indented JSON and returns it as a text tool
// result. Returns a protocol-level error only when marshalling fails.
func JSONResult(v any) (*mcp.CallToolResult, error) {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return nil, err
	}
	return mcp.NewToolResultText(string(b)), nil
}
