package server

import (
	"context"
	"fmt"

	mcpkit "github.com/GrayCodeAI/harrier/internal/mcpkit"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/GrayCodeAI/harrier/utils"
	"github.com/mark3labs/mcp-go/mcp"
)

// --- Graph tool handlers ---

func (s *MCPServer) handleLink(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	edgeType := mcpkit.StrArg(req, "type")
	if edgeType == "" {
		return nil, fmt.Errorf("edge type is required")
	}
	if !graph.IsValidEdgeType(edgeType) {
		return nil, fmt.Errorf("invalid edge type: %q", edgeType)
	}
	edge := &storage.Edge{
		FromID: mcpkit.StrArg(req, "from_id"),
		ToID:   mcpkit.StrArg(req, "to_id"),
		Type:   edgeType,
		Weight: 1.0,
	}
	edge.ID = fmt.Sprintf("%s-%s-%s", utils.ShortID(edge.FromID), utils.ShortID(edge.ToID), edge.Type)
	if err := s.eng.Graph().AddEdge(ctx, edge); err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(edge)
}

func (s *MCPServer) handleUnlink(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	if err := s.eng.Graph().RemoveEdge(ctx, mcpkit.StrArg(req, "id")); err != nil {
		return nil, err
	}
	return mcp.NewToolResultText("unlinked"), nil
}

func (s *MCPServer) handleSubgraph(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	depth := intArgOr(req, "depth", 2)
	if depth <= 0 || depth > 5 {
		depth = 2
	}
	sg, err := s.eng.Graph().ExtractSubgraph(ctx, mcpkit.StrArg(req, "id"), depth)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(sg)
}

func (s *MCPServer) handleImpact(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken
	depth := intArgOr(req, "depth", 3)
	if depth <= 0 || depth > 5 {
		depth = 3
	}

	sendProgress(ctx, s.mcp(), token, 1, 3, "tracing impact graph")

	ids, err := s.eng.Graph().Impact(ctx, mcpkit.StrArg(req, "file"), depth)
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 2, 3, "resolving affected nodes")

	// Resolve IDs to nodes
	var nodes []*storage.Node
	for _, id := range ids {
		n, err := s.eng.Store().GetNode(ctx, id)
		if err == nil {
			nodes = append(nodes, n)
		}
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "impact analysis complete")
	return mcpkit.JSONResult(nodes)
}

func (s *MCPServer) handleCommunities(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 3, "detecting memory communities")

	cd := engine.NewCommunityDetector(s.eng.Store())
	communities, err := cd.Detect(ctx, 10)
	if err != nil {
		return nil, fmt.Errorf("community detection failed: %w", err)
	}

	sendProgress(ctx, s.mcp(), token, 2, 3, "summarizing clusters")

	communities = cd.Summarize(ctx, communities)

	sendProgress(ctx, s.mcp(), token, 3, 3, "communities detected")

	type communityOut struct {
		ID      int            `json:"id"`
		Size    int            `json:"size"`
		Summary string         `json:"summary"`
		Types   map[string]int `json:"types"`
	}
	out := make([]communityOut, len(communities))
	for i, c := range communities {
		out[i] = communityOut{ID: c.ID, Size: c.Size, Summary: c.Summary, Types: c.Types}
	}
	return mcpkit.JSONResult(out)
}

func (s *MCPServer) handleHierarchy(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 2, "building hierarchical memory")

	hm := engine.NewHierarchicalMemory(s.eng.Store())
	if err := hm.Build(ctx); err != nil {
		return nil, fmt.Errorf("hierarchy build failed: %w", err)
	}

	sendProgress(ctx, s.mcp(), token, 2, 2, "hierarchy ready")

	query := mcpkit.StrArg(req, "query")
	level := intArgOr(req, "level", -1)

	if level < 0 && query != "" {
		level = hm.RetrieveAdaptive(query)
	}
	if level < 0 {
		level = 1
	}

	if query != "" {
		clusters := hm.RetrieveAtLevel(query, level)
		return mcpkit.JSONResult(map[string]interface{}{
			"level":    level,
			"query":    query,
			"clusters": clusters,
		})
	}

	return mcp.NewToolResultText(fmt.Sprintf("## Level %d Memory Hierarchy\n\n%s", level, hm.FormatLevel(level))), nil
}

func (s *MCPServer) handleSparsify(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 3, "analyzing memory graph")

	sp := engine.NewSparsifier(s.eng.Store())

	sendProgress(ctx, s.mcp(), token, 2, 3, "merging duplicates and pruning orphans")

	result, err := sp.Run(ctx)
	if err != nil {
		return nil, fmt.Errorf("sparsification failed: %w", err)
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "sparsification complete")
	return mcpkit.JSONResult(map[string]interface{}{
		"merged":     result.Merged,
		"compressed": result.Compressed,
		"pruned":     result.Pruned,
		"total":      result.Merged + result.Compressed + result.Pruned,
	})
}
