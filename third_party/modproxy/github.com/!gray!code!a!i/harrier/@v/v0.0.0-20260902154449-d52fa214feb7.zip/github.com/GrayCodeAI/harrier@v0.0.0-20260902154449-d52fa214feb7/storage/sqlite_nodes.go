// This file is part of package storage. It holds node, version, metadata,
// signature, and access-log storage operations split verbatim out of
// sqlite.go for readability; behavior is unchanged.

package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/metric"
)

// --- Nodes ---

func (s *Store) CreateNode(ctx context.Context, n *Node) error {
	start := time.Now()
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	err := retryOnBusy(func() error {
		return createNodeQ(ctx, s.q(), n, s.cipher())
	}, 5, 2*time.Millisecond)
	attrs := attribute.NewSet(attribute.String("op", "create_node"))
	telemetry.SQLiteQueryDuration.Record(ctx, time.Since(start).Seconds(), metric.WithAttributeSet(attrs))
	telemetry.SQLiteQueryCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
	return err
}

func createNodeQ(ctx context.Context, q queryable, n *Node, c *NodeCipher) error {
	enc, err := encryptValues(c, n.Content, n.Summary)
	if err != nil {
		return err
	}
	_, err = q.ExecContext(ctx, `INSERT INTO nodes (id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version, encrypted, encryption_key_version)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		n.ID, n.Type, enc[0], n.ContentHash, enc[1], n.Scope, n.Project, n.Tier, n.Tags, nullString(n.Key), n.Pinned, n.Confidence, n.AccessCount,
		n.CreatedAt, n.UpdatedAt, nullTime(n.AccessedAt), n.SourceSession, n.SourceAgent, n.Version, encryptedFlag(c), keyVersionForWrite(c))
	if err != nil && strings.Contains(err.Error(), "UNIQUE constraint failed") {
		return fmt.Errorf("%w: %s", ErrDuplicateNode, err)
	}
	if err != nil {
		return err
	}
	// Persist structured metadata.
	return saveNodeMetadataQ(ctx, q, n.ID, n.Metadata)
}

// saveNodeMetadataQ replaces all metadata for a node, inserting rows for each
// key-value pair. Uses the same queryable (pooled connection or transaction).
func saveNodeMetadataQ(ctx context.Context, q queryable, nodeID string, meta map[string]string) error {
	if len(meta) == 0 {
		return nil
	}
	// Delete existing metadata for this node (upsert semantics).
	if _, err := q.ExecContext(ctx, `DELETE FROM node_metadata WHERE node_id = ?`, nodeID); err != nil {
		return err
	}
	for k, v := range meta {
		if _, err := q.ExecContext(ctx,
			`INSERT INTO node_metadata (node_id, key, value) VALUES (?, ?, ?)`, nodeID, k, v); err != nil {
			return err
		}
	}
	return nil
}

// GetNode retrieves a node by its primary key ID.
// Returns ErrNodeNotFound wrapped with the ID when no row is found.
func (s *Store) GetNode(ctx context.Context, id string) (*Node, error) {
	start := time.Now()
	n, err := retryOnBusyVal(func() (*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getNodeQ(ctx, s.q(), id, s.cipher())
	}, 5, 50*time.Millisecond)
	attrs := attribute.NewSet(attribute.String("op", "get_node"))
	telemetry.SQLiteQueryDuration.Record(ctx, time.Since(start).Seconds(), metric.WithAttributeSet(attrs))
	telemetry.SQLiteQueryCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
	_ = err // metrics always recorded
	return n, err
}

func getNodeQ(ctx context.Context, q queryable, id string, c *NodeCipher) (*Node, error) {
	n := &Node{}
	var accessedAt sql.NullTime
	var key sql.NullString
	err := q.QueryRowContext(ctx, `SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version FROM nodes WHERE id = ?`, id).
		Scan(&n.ID, &n.Type, &n.Content, &n.ContentHash, &n.Summary, &n.Scope, &n.Project, &n.Tier, &n.Tags, &key, &n.Pinned, &n.Confidence, &n.AccessCount, &n.CreatedAt, &n.UpdatedAt, &accessedAt, &n.SourceSession, &n.SourceAgent, &n.Version)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("%w: %s", ErrNodeNotFound, id)
		}
		return nil, err
	}
	if accessedAt.Valid {
		n.AccessedAt = accessedAt.Time
	}
	if key.Valid {
		n.Key = key.String
	}
	if err := decryptNodeInplace(n, c); err != nil {
		return nil, err
	}
	return n, nil
}

// GetNodeByKey looks up a node by its unique key within a project.
// Returns (nil, nil) when no matching node is found (upsert check pattern).
func (s *Store) GetNodeByKey(ctx context.Context, key, project string) (*Node, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return getNodeByKeyQ(ctx, s.q(), key, project, s.cipher())
}

func getNodeByKeyQ(ctx context.Context, q queryable, key, project string, c *NodeCipher) (*Node, error) {
	n := &Node{}
	var accessedAt sql.NullTime
	var k sql.NullString
	err := q.QueryRowContext(ctx, `SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version FROM nodes WHERE key = ? AND project = ?`, key, project).
		Scan(&n.ID, &n.Type, &n.Content, &n.ContentHash, &n.Summary, &n.Scope, &n.Project, &n.Tier, &n.Tags, &k, &n.Pinned, &n.Confidence, &n.AccessCount, &n.CreatedAt, &n.UpdatedAt, &accessedAt, &n.SourceSession, &n.SourceAgent, &n.Version)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	if accessedAt.Valid {
		n.AccessedAt = accessedAt.Time
	}
	if k.Valid {
		n.Key = k.String
	}
	if err := decryptNodeInplace(n, c); err != nil {
		return nil, err
	}
	return n, nil
}

func (s *Store) UpdateNode(ctx context.Context, n *Node) error {
	start := time.Now()
	err := retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return updateNodeQ(ctx, s.q(), n, s.cipher())
	}, 5, 50*time.Millisecond)
	attrs := attribute.NewSet(attribute.String("op", "update_node"))
	telemetry.SQLiteQueryDuration.Record(ctx, time.Since(start).Seconds(), metric.WithAttributeSet(attrs))
	telemetry.SQLiteQueryCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
	return err
}

func updateNodeQ(ctx context.Context, q queryable, n *Node, c *NodeCipher) error {
	enc, err := encryptValues(c, n.Content, n.Summary)
	if err != nil {
		return err
	}
	_, err = q.ExecContext(ctx, `UPDATE nodes SET type=?, content=?, content_hash=?, summary=?, scope=?, project=?, tier=?, tags=?, key=?, pinned=?, confidence=?, access_count=?, updated_at=?, accessed_at=?, source_session=?, source_agent=?, version=?, encrypted=?, encryption_key_version=? WHERE id=?`,
		n.Type, enc[0], n.ContentHash, enc[1], n.Scope, n.Project, n.Tier, n.Tags, nullString(n.Key), n.Pinned, n.Confidence, n.AccessCount,
		n.UpdatedAt, nullTime(n.AccessedAt), n.SourceSession, n.SourceAgent, n.Version, encryptedFlag(c), keyVersionForWrite(c), n.ID)
	if err != nil {
		return err
	}
	// Persist structured metadata (delete + insert).
	return saveNodeMetadataQ(ctx, q, n.ID, n.Metadata)
}

func (s *Store) ArchiveNode(ctx context.Context, id string) (bool, error) {
	return retryOnBusyVal(func() (bool, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return archiveNodeQ(ctx, s.q(), id)
	}, 5, 50*time.Millisecond)
}

func archiveNodeQ(ctx context.Context, q queryable, id string) (bool, error) {
	res, err := q.ExecContext(ctx, `UPDATE nodes SET confidence=0, updated_at=CURRENT_TIMESTAMP WHERE id=? AND confidence>0`, id)
	if err != nil {
		return false, err
	}
	n, err := res.RowsAffected()
	return n > 0, err
}

func (s *Store) UpdateNodeContent(ctx context.Context, id, newContent string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return updateNodeContentQ(ctx, s.q(), id, newContent, s.cipher())
	}, 5, 50*time.Millisecond)
}

func updateNodeContentQ(ctx context.Context, q queryable, id, newContent string, c *NodeCipher) error {
	enc, err := encryptValues(c, newContent)
	if err != nil {
		return err
	}
	_, err = q.ExecContext(ctx, `UPDATE nodes SET content=?, updated_at=CURRENT_TIMESTAMP, encrypted=?, encryption_key_version=? WHERE id=?`, enc[0], encryptedFlag(c), keyVersionForWrite(c), id)
	return err
}

func (s *Store) DeleteNode(ctx context.Context, id string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			return err
		}
		defer func() { _ = tx.Rollback() }()
		if err := deleteNodeQ(ctx, tx, id); err != nil {
			return err
		}
		return tx.Commit()
	}, 5, 50*time.Millisecond)
}

// deleteNodeQ removes a node and every dependent row, in one transaction
// context (both Store.DeleteNode and txStore.DeleteNode route through here).
//
// The schema declares child tables WITHOUT ON DELETE CASCADE — embeddings,
// file_watch, and node_signatures reference nodes(id) directly, and
// embeddings_hnsw references embeddings(node_id) — so with foreign_keys(ON)
// a bare `DELETE FROM nodes` fails with an FK violation whenever any child
// row exists. node_versions has no FK at all and would silently leak orphans.
// Delete every child explicitly, leaf tables first, before the node itself.
func deleteNodeQ(ctx context.Context, q queryable, id string) error {
	// Order matters: embeddings_hnsw must go before embeddings, and all
	// node-referencing children before nodes.
	children := []struct {
		query string
		args  []any
	}{
		{`DELETE FROM edges WHERE from_id=? OR to_id=?`, []any{id, id}},
		{`DELETE FROM node_signatures WHERE node_id=?`, []any{id}},
		{`DELETE FROM file_watch WHERE node_id=?`, []any{id}},
		{`DELETE FROM embeddings_hnsw WHERE node_id=?`, []any{id}},
		{`DELETE FROM embeddings WHERE node_id=?`, []any{id}},
		{`DELETE FROM node_versions WHERE node_id=?`, []any{id}},
		{`DELETE FROM node_metadata WHERE node_id=?`, []any{id}}, // cascade-deleted anyway; explicit for FK-off safety
	}
	for _, c := range children {
		if _, err := q.ExecContext(ctx, c.query, c.args...); err != nil {
			return err
		}
	}
	_, err := q.ExecContext(ctx, `DELETE FROM nodes WHERE id=?`, id)
	return err
}

func (s *Store) ListNodes(ctx context.Context, f NodeFilter) ([]*Node, error) {
	start := time.Now()
	nodes, err := retryOnBusyVal(func() ([]*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return listNodesQ(ctx, s.q(), f, s.cipher())
	}, 5, 50*time.Millisecond)
	attrs := attribute.NewSet(attribute.String("op", "list_nodes"))
	telemetry.SQLiteQueryDuration.Record(ctx, time.Since(start).Seconds(), metric.WithAttributeSet(attrs))
	telemetry.SQLiteQueryCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
	return nodes, err
}

func listNodesQ(ctx context.Context, q queryable, f NodeFilter, c *NodeCipher) ([]*Node, error) {
	query := "SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version FROM nodes WHERE 1=1"
	var args []any
	if f.Type != "" {
		query += " AND type=?"
		args = append(args, f.Type)
	}
	if f.Scope != "" {
		query += " AND scope=?"
		args = append(args, f.Scope)
	}
	if f.Project != "" {
		query += " AND project=?"
		args = append(args, f.Project)
	}
	if f.Tier > 0 {
		query += " AND tier=?"
		args = append(args, f.Tier)
	}
	if f.MinConfidence > 0 {
		query += " AND confidence>=?"
		args = append(args, f.MinConfidence)
	}
	if f.SourceSession != "" {
		query += " AND source_session=?"
		args = append(args, f.SourceSession)
	}
	if f.Pinned != nil {
		query += " AND pinned=?"
		args = append(args, *f.Pinned)
	}
	if f.Tag != "" {
		// Delimiter-aware exact tag match: wrap both the stored CSV and the
		// target in commas so "topic:foo" does not match "topic:foobar".
		// '%' and '_' in the tag are escaped so they are treated literally.
		esc := strings.NewReplacer(`\`, `\\`, `%`, `\%`, `_`, `\_`).Replace(f.Tag)
		query += ` AND (',' || tags || ',') LIKE ? ESCAPE '\'`
		args = append(args, "%,"+esc+",%")
	}
	// Metadata key-value filters (AND semantics — all must match).
	for k, v := range f.MetadataFilters {
		query += ` AND EXISTS (SELECT 1 FROM node_metadata nm WHERE nm.node_id = nodes.id AND nm.key = ? AND nm.value = ?)`
		args = append(args, k, v)
	}
	// Deterministic order: most recently updated first, then insertion order.
	// Pagination (Limit/Offset) is only meaningful with a stable ORDER BY, and
	// recent-window queries (e.g. conflict re-detection) rely on recency.
	query += " ORDER BY updated_at DESC, rowid DESC"
	query += " LIMIT ?"
	if f.Limit > 0 {
		args = append(args, f.Limit)
	} else {
		args = append(args, 1000)
	}
	if f.Offset > 0 {
		query += " OFFSET ?"
		args = append(args, f.Offset)
	}
	rows, err := q.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	return scanNodes(rows, c)
}

// escapeFTS5 escapes special FTS5 characters by wrapping each token in double
// quotes and escaping embedded quotes. This prevents FTS5 query injection via
// operators like *, -, AND, OR, NOT.
func escapeFTS5(query string) string {
	words := strings.Fields(query)
	for i, w := range words {
		// Escape embedded quotes by doubling them, then wrap in quotes
		w = strings.ReplaceAll(w, `"`, `""`)
		words[i] = `"` + w + `"`
	}
	return strings.Join(words, " OR ")
}

func (s *Store) SearchNodes(ctx context.Context, query string, limit int) ([]*Node, error) {
	start := time.Now()
	nodes, err := retryOnBusyVal(func() ([]*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return searchNodesQ(ctx, s.q(), query, limit, s.cipher())
	}, 5, 50*time.Millisecond)
	attrs := attribute.NewSet(attribute.String("op", "search_nodes"))
	telemetry.SQLiteQueryDuration.Record(ctx, time.Since(start).Seconds(), metric.WithAttributeSet(attrs))
	telemetry.SQLiteQueryCount.Add(ctx, 1, metric.WithAttributeSet(attrs))
	return nodes, err
}

func searchNodesQ(ctx context.Context, q queryable, query string, limit int, c *NodeCipher) ([]*Node, error) {
	if limit <= 0 {
		limit = 10
	}
	// FTS5 indexes the stored nodes.content column — ciphertext when
	// encryption is active — so keyword search would match nothing. Fall
	// back to an in-memory token scan over decrypted content; fine at
	// harrier's graph sizes and keeps Recall working with encryption on.
	if c != nil {
		return searchNodesInMemory(ctx, q, query, limit, c)
	}
	ftsQuery := escapeFTS5(query)
	rows, err := q.QueryContext(ctx, `SELECT n.id, n.type, n.content, n.content_hash, n.summary, n.scope, n.project, n.tier, n.tags, n.key, n.pinned, n.confidence, n.access_count, n.created_at, n.updated_at, n.accessed_at, n.source_session, n.source_agent, n.version
		FROM nodes_fts f JOIN nodes n ON f.rowid = n.rowid WHERE nodes_fts MATCH ? ORDER BY rank LIMIT ?`, ftsQuery, limit)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	return scanNodes(rows, c)
}

// searchNodesInMemory scans all nodes, decrypting as it goes, and matches the
// whitespace-separated query tokens (case-insensitive substring, OR semantics
// like escapeFTS5) against content and summary. Results are ordered by the
// number of distinct tokens matched (descending), then most-recently-updated.
func searchNodesInMemory(ctx context.Context, q queryable, query string, limit int, c *NodeCipher) ([]*Node, error) {
	tokens := strings.Fields(query)
	if len(tokens) == 0 {
		return nil, nil
	}
	for i := range tokens {
		tokens[i] = strings.ToLower(tokens[i])
	}

	rows, err := q.QueryContext(ctx, `SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version FROM nodes`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	all, err := scanNodes(rows, c)
	if err != nil {
		return nil, err
	}

	type scored struct {
		node  *Node
		score int
	}
	var hits []scored
	for _, n := range all {
		hay := strings.ToLower(n.Content + "\n" + n.Summary)
		matched := 0
		for _, tok := range tokens {
			if strings.Contains(hay, tok) {
				matched++
			}
		}
		if matched > 0 {
			hits = append(hits, scored{n, matched})
		}
	}
	sort.Slice(hits, func(i, j int) bool {
		if hits[i].score != hits[j].score {
			return hits[i].score > hits[j].score
		}
		return hits[i].node.UpdatedAt.After(hits[j].node.UpdatedAt)
	})
	if len(hits) > limit {
		hits = hits[:limit]
	}
	out := make([]*Node, 0, len(hits))
	for _, h := range hits {
		out = append(out, h.node)
	}
	return out, nil
}

// --- Versions ---

func (s *Store) SaveVersion(ctx context.Context, nodeID string, content, changedBy, reason string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			return err
		}
		defer func() { _ = tx.Rollback() }()
		if err := saveVersionQ(ctx, tx, nodeID, content, changedBy, reason, s.cipher()); err != nil {
			return err
		}
		return tx.Commit()
	}, 5, 50*time.Millisecond)
}

func saveVersionQ(ctx context.Context, q queryable, nodeID string, content, changedBy, reason string, c *NodeCipher) error {
	enc, err := encryptValues(c, content)
	if err != nil {
		return err
	}
	var maxVer int
	err = q.QueryRowContext(ctx, `SELECT COALESCE(MAX(version), 0) FROM node_versions WHERE node_id=?`, nodeID).Scan(&maxVer)
	if err != nil {
		return err
	}
	_, err = q.ExecContext(ctx, `INSERT INTO node_versions (node_id, version, content, changed_at, changed_by, reason) VALUES (?, ?, ?, ?, ?, ?)`,
		nodeID, maxVer+1, enc[0], time.Now().UTC(), changedBy, reason)
	return err
}

func (s *Store) GetVersions(ctx context.Context, nodeID string) ([]*NodeVersion, error) {
	return retryOnBusyVal(func() ([]*NodeVersion, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getVersionsQ(ctx, s.q(), nodeID, s.cipher())
	}, 5, 50*time.Millisecond)
}

func getVersionsQ(ctx context.Context, q queryable, nodeID string, c *NodeCipher) ([]*NodeVersion, error) {
	rows, err := q.QueryContext(ctx, `SELECT node_id, version, content, changed_at, changed_by, reason FROM node_versions WHERE node_id=? ORDER BY version`, nodeID)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	var out []*NodeVersion
	for rows.Next() {
		v := &NodeVersion{}
		if err := rows.Scan(&v.NodeID, &v.Version, &v.Content, &v.ChangedAt, &v.ChangedBy, &v.Reason); err != nil {
			return nil, err
		}
		if err := decryptVersionInplace(v, c); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

// --- AccessLog ---

// LogAccess records a lightweight access event (INSERT only, no UPDATE churn).
func (s *Store) LogAccess(ctx context.Context, nodeID string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return logAccessQ(ctx, s.q(), nodeID)
	}, 5, 50*time.Millisecond)
}

func logAccessQ(ctx context.Context, q queryable, nodeID string) error {
	_, err := q.ExecContext(ctx, `INSERT INTO access_log (node_id) VALUES (?)`, nodeID)
	return err
}

// FlushAccessLog aggregates access_log entries into nodes.access_count / accessed_at,
// then truncates the log. Runs atomically within a transaction.
func (s *Store) FlushAccessLog(ctx context.Context) (int, error) {
	return retryOnBusyVal(func() (int, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			return 0, err
		}
		defer func() { _ = tx.Rollback() }()
		n, err := flushAccessLogQ(ctx, tx)
		if err != nil {
			return 0, err
		}
		return n, tx.Commit()
	}, 5, 50*time.Millisecond)
}

func flushAccessLogQ(ctx context.Context, q queryable) (int, error) {
	rows, err := q.QueryContext(ctx, `
		SELECT node_id, COUNT(*) as cnt, MAX(created_at) as last_at
		FROM access_log
		GROUP BY node_id`)
	if err != nil {
		return 0, err
	}
	defer func() { _ = rows.Close() }()
	type agg struct {
		nodeID string
		count  int
		lastAt time.Time
	}
	var aggs []agg
	for rows.Next() {
		var a agg
		var lastAtStr string
		if err := rows.Scan(&a.nodeID, &a.count, &lastAtStr); err != nil {
			return 0, err
		}
		if lastAtStr != "" {
			t, _ := time.Parse(time.RFC3339Nano, lastAtStr)
			if t.IsZero() {
				t, _ = time.Parse("2006-01-02 15:04:05", lastAtStr)
			}
			a.lastAt = t
		}
		aggs = append(aggs, a)
	}
	if err := rows.Err(); err != nil {
		return 0, err
	}
	if len(aggs) == 0 {
		return 0, nil
	}
	for _, a := range aggs {
		_, err := q.ExecContext(ctx, `
			UPDATE nodes
			SET access_count = access_count + ?,
			    accessed_at  = MAX(COALESCE(accessed_at, '1970-01-01'), ?)
			WHERE id = ?`,
			a.count, a.lastAt, a.nodeID)
		if err != nil {
			return 0, err
		}
	}
	_, err = q.ExecContext(ctx, `DELETE FROM access_log`)
	if err != nil {
		return 0, err
	}
	return len(aggs), nil
}

// --- Metadata ---

func (s *Store) SaveNodeMetadata(ctx context.Context, nodeID string, meta map[string]string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return saveNodeMetadataQ(ctx, s.q(), nodeID, meta)
	}, 5, 50*time.Millisecond)
}

func (s *Store) LoadNodeMetadata(ctx context.Context, nodeIDs []string) (map[string]map[string]string, error) {
	if len(nodeIDs) == 0 {
		return nil, nil
	}
	return retryOnBusyVal(func() (map[string]map[string]string, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return loadNodeMetadataQ(ctx, s.q(), nodeIDs)
	}, 2, 10*time.Millisecond)
}

// loadNodeMetadataQ fetches node_metadata rows for nodeIDs. SQLite caps the
// number of host parameters per statement (maxSQLVariables), so large ID sets
// are queried in chunks and the per-node results merged.
func loadNodeMetadataQ(ctx context.Context, q queryable, nodeIDs []string) (map[string]map[string]string, error) {
	result := make(map[string]map[string]string)
	for i := 0; i < len(nodeIDs); i += maxSQLVariables {
		end := i + maxSQLVariables
		if end > len(nodeIDs) {
			end = len(nodeIDs)
		}
		chunk := nodeIDs[i:end]
		query := "SELECT node_id, key, value FROM node_metadata WHERE node_id IN (" + placeholders(len(chunk)) + ")"
		args := make([]any, len(chunk))
		for j, id := range chunk {
			args[j] = id
		}
		rows, err := q.QueryContext(ctx, query, args...)
		if err != nil {
			return nil, err
		}
		for rows.Next() {
			var nodeID, key, value string
			if err := rows.Scan(&nodeID, &key, &value); err != nil {
				_ = rows.Close()
				return nil, err
			}
			if result[nodeID] == nil {
				result[nodeID] = make(map[string]string)
			}
			result[nodeID][key] = value
		}
		if err := rows.Err(); err != nil {
			_ = rows.Close()
			return nil, err
		}
		_ = rows.Close()
	}
	return result, nil
}

// FillNodeMetadata loads metadata for all given nodes in one batch query and
// populates each node's Metadata field in-place. No-op for an empty slice.
func (s *Store) FillNodeMetadata(ctx context.Context, nodes []*Node) error {
	if len(nodes) == 0 {
		return nil
	}
	ids := make([]string, len(nodes))
	for i, n := range nodes {
		ids[i] = n.ID
	}
	meta, err := s.LoadNodeMetadata(ctx, ids)
	if err != nil {
		return err
	}
	for _, n := range nodes {
		n.Metadata = meta[n.ID]
	}
	return nil
}

// --- Signatures ---

func (s *Store) SaveSignature(ctx context.Context, nodeID, signature string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return saveSignatureQ(ctx, s.q(), nodeID, signature)
	}, 5, 50*time.Millisecond)
}

func saveSignatureQ(ctx context.Context, q queryable, nodeID, signature string) error {
	_, err := q.ExecContext(ctx,
		`INSERT OR REPLACE INTO node_signatures (node_id, signature, signed_at) VALUES (?, ?, CURRENT_TIMESTAMP)`,
		nodeID, signature)
	return err
}

func (s *Store) GetAllSignatures(ctx context.Context) (map[string]string, error) {
	return retryOnBusyVal(func() (map[string]string, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getAllSignaturesQ(ctx, s.db)
	}, 5, 50*time.Millisecond)
}

func getAllSignaturesQ(ctx context.Context, q queryable) (map[string]string, error) {
	rows, err := q.QueryContext(ctx, `SELECT node_id, signature FROM node_signatures`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	out := make(map[string]string)
	for rows.Next() {
		var nodeID, sig string
		if err := rows.Scan(&nodeID, &sig); err != nil {
			return nil, err
		}
		out[nodeID] = sig
	}
	return out, rows.Err()
}

func (s *Store) GetNodesBatch(ctx context.Context, ids []string) ([]*Node, error) {
	return retryOnBusyVal(func() ([]*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getNodesBatchQ(ctx, s.q(), ids, s.cipher())
	}, 5, 50*time.Millisecond)
}

func getNodesBatchQ(ctx context.Context, q queryable, ids []string, c *NodeCipher) ([]*Node, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	var all []*Node
	for i := 0; i < len(ids); i += maxSQLVariables {
		end := i + maxSQLVariables
		if end > len(ids) {
			end = len(ids)
		}
		chunk := ids[i:end]
		placeholders := make([]string, len(chunk))
		args := make([]any, len(chunk))
		for j, id := range chunk {
			placeholders[j] = "?"
			args[j] = id
		}
		query := fmt.Sprintf(`SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version FROM nodes WHERE id IN (%s)`, strings.Join(placeholders, ","))
		rows, err := q.QueryContext(ctx, query, args...)
		if err != nil {
			return nil, err
		}
		nodes, err := scanNodes(rows, c)
		_ = rows.Close()
		if err != nil {
			return nil, err
		}
		all = append(all, nodes...)
	}
	return all, nil
}
