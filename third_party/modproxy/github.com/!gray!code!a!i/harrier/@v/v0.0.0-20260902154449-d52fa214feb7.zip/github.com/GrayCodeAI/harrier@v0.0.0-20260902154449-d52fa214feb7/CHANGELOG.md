# Changelog

All notable changes to Harrier are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed
- **Standalone module resolution**: `go.mod` required
  `github.com/GrayCodeAI/falcon v0.0.0` (a non-existent version, only
  satisfiable through the monorepo `replace`), which made harrier unbuildable
  whenever it was consumed as a dependency module. The requirement is now the
  tagged `v0.1.5` (which ships `ServeHTTPWithShutdown`, the newest mcpkit API
  harrier uses) and `go.sum` carries its hashes; the local `replace` remains for
  monorepo development. The dead `ServeSSE`/`ServeSSEWithShutdown` wrappers in
  `internal/server` were removed — they referenced mcpkit APIs added after
  v0.1.5 and had no callers in harrier.
- **Per-connection PRAGMAs now cover the whole connection pool**:
  `synchronous`, `wal_autocheckpoint`, `temp_store`, `mmap_size`,
  `cache_size`, and `recursive_triggers` were issued once through
  `db.ExecContext`, which only configured the single pooled connection that
  served the call — the other four connections (pool size 5) silently ran on
  SQLite defaults. They are now `_pragma=` DSN parameters, which the
  modernc.org/sqlite driver applies to every new connection. `page_size`
  (a no-op after the database file exists) was dropped, and `PRAGMA optimize`
  moved from startup to `Store.Close()`, matching SQLite's guidance to run it
  near connection close.
- **Batch metadata and edge-count queries chunk large ID sets**:
  `LoadNodeMetadata`/`FillNodeMetadata` and `CountEdgesBatch` built a single
  `IN (...)` with every requested ID, ignoring the `maxSQLVariables` (900)
  host-parameter budget the other batch helpers (`GetNodesBatch`,
  `GetAllEdgesFor`, `GetEdgesBetween`) already chunk at — large ID sets could
  exceed SQLite's per-statement parameter limit. Both now fetch in
  `maxSQLVariables`-sized chunks and merge results, with regression tests
  covering >900 IDs.
- **Backup failures are now visible and backups are fsynced**:
  - `BackupScheduler.run` discarded every snapshot error (`_ = b.RunNow`), so
    a dead backup pipeline looked healthy. Failures are now logged via
    `log/slog` and tracked in the new `BackupScheduler.Status()` accessor
    (last success/error timestamps, snapshot/failure counters), with
    `RunNow` recording its outcome too.
  - `RotateBackups` silently ignored `os.Remove` errors; unexpected ones are
    now logged (a vanished file is still fine).
  - `Store.Backup` now fsyncs the snapshot file before renaming it into
    place and best-effort fsyncs the backup directory after the rename, so a
    crash cannot leave a renamed-but-not-durable (or truncated) backup.
- **`EnvKeyProvider` enforces a minimum key policy**: the raw environment
  value was used as master key material regardless of length, so a short
  passphrase (whose entropy HKDF cannot fix) was silently accepted.
  `KeyBytes` now accepts a raw string of at least 32 bytes, or a base64- or
  hex-encoded value that decodes to exactly 32 bytes (raw wins when a value
  qualifies both ways), and otherwise returns an error naming the
  environment variable.
  **Upgrade note:** deployments using a shorter key are rejected after this
  change (in hawk this disables the harrier memory bridge with a logged
  warning — it never falls back to plaintext). Rows already encrypted under
  a now-rejected short key cannot be decrypted by `EnvKeyProvider` anymore;
  set a compliant key and re-create or migrate that data.
- **Process lock paths are normalized**: `AcquireProcessLock` keys its
  in-process lock registry by the raw `dbPath + ".lock"` string, so
  lexically equivalent paths (`dir/db`, `dir/./db`, `dir/x/../db`) opened two
  lock-file handles in one process and the second open falsely reported
  "database locked by another harrier process". Lock paths are now normalized
  with `filepath.Abs`.
- **`storage.DeleteNode` foreign-key violations**: `deleteNodeQ` only deleted
  `edges` + `nodes`, so deleting a node with child rows in `embeddings`,
  `embeddings_hnsw`, `file_watch`, or `node_signatures` failed with
  `FOREIGN KEY constraint failed` (no `ON DELETE CASCADE` in the schema), and
  `node_versions` / `node_metadata` rows leaked as orphans. All child rows are
  now deleted explicitly, leaf tables first, in the same transaction.
- **Swallowed delete errors in engine passes**: `GarbageCollect`
  (`engine/decay.go`), the sparsifier passes (`engine/sparsify.go`),
  `consolidateDuplicates` (`engine/improve.go`), and the LLM consolidator
  (`engine/llm_consolidation.go`) silently ignored `DeleteNode` failures and
  mis-reported removed/merged/pruned counts. Failures are now logged via
  `log/slog` and only successful deletions are counted.

## [0.2.0] — 2026-07-14

### Changed
- **Version re-baselined to `0.1.0`** across `internal/server/mcp.go`
  (advertised MCP server version), `sdk/python/pyproject.toml`,
  `sdk/typescript/package.json`, and `api/openapi.yaml` (header `version`
  and the `/harrier/health` example). Aligns harrier with the rest of the
  hawk-eco ecosystem (`hawk`, `shrike`, `eyrie`, `kestrel`, `merlin`).
- **`internal/version`**: `Version` is now read at compile time via
  `go:embed` from `internal/version/VERSION` (kept in sync with the root
  `VERSION` via `make sync-version`). Previously hard-coded to `"dev"`
  and only overrideable through ldflags that no build path was actually
  setting — so every build reported `dev` regardless of the VERSION
  file. Pure `go build` / `go install` / `go get` now report the
  correct version with zero ldflags wiring required.

### Removed
- **`install.sh`** — fetched `harrier_${OS}_${ARCH}` from GitHub Releases and
  ran `harrier auto`. harrier is library-only (no `cmd/`, no `package main`, no
  goreleaser config); there is no such binary or subcommand.
- **`Formula/harrier.rb`** — Homebrew formula pointed at
  `releases/download/v0.2.0/harrier_<os>_<arch>` artifacts that have never
  been published, ran `harrier --version` against a binary that does not
  exist, and was still pinned at `0.2.0` while the rest of the repo
  re-baselined to `0.1.0`. Will return once a binary actually ships.
- **`deploy/docker/docker-compose.yml`** + **`.dockerignore`** —
  referenced a `Dockerfile` that does not exist in the repo. harrier is a
  library; consumers wire `internal/server/RESTServer` into their own
  daemons (or use `hawk daemon`).

### Security
- **Stop tracking `.harrier/integrity.key`** — this is a per-installation
  HMAC key for memory-integrity verification. Committing it meant every
  clone shared the same key, defeating the purpose. The file is now in
  `.gitignore` and is regenerated locally on first run if missing.
  Existing local files are kept intact; only the git-tracked copy is
  removed.
- Expanded `.gitignore` to also exclude `.harrier/*.db`, `.harrier/*.db-shm`,
  `.harrier/*.db-wal`, `coverage.html`, and the `.gocache/` /
  `.gomodcache/` Go build caches.

### Added
- Worktree-aware memory sharing — memory scoped to the git repository root so worktrees, subdirectories, and linked checkouts share one `.harrier/` store
- LLM-assisted entity extraction (opt-in via `HARRIER_LLM_EXTRACT` + `HARRIER_LLM_API_KEY`), merged with regex output; regex-only fallback keeps behavior unchanged when unset
- Live temporal fact-validity windows (`valid_at` / `invalid_at`) for point-in-time recall filtering
- gRPC/SSE `WatchMemories` streaming of Remember/Forget mutations in real time
- Versions and rollback CLI: `harrier versions <node-id>` and `harrier rollback <node-id> <version>`
- ADD-only single-pass ingestion mode (opt-in via `HARRIER_ADD_ONLY`)
- Subagent-scoped memory — isolated per-subagent stores under `agent-memory/<id>/`
- Sleep-time memory consolidation (opt-in via `HARRIER_CONSOLIDATE_INTERVAL`)
- Semantic boundary detection to segment sessions into coherent memory units
- Search-time non-destructive decay for recall results
- Config validation with typed errors at load time
- Spatial memory tier system (hot/warm/cold) with access-based promotion/demotion

### Added — Production Hardening (top-50 OSS parity)
- Same-style hardening pass already on this branch:
  strict `golangci-lint` v2 config, unchecked-error fixes across many
  packages, and dead-code removal. This commit additionally lands the
  errcheck fix on `internal/tls/tls.go` (`defer cf.Close()` →
  `defer func() { _ = cf.Close() }()`) that was left staged.
- `CODE_OF_CONDUCT.md` — Contributor Covenant 2.1.
- `.gitattributes` — LF normalization, binary detection, GitHub
  linguist hints (mark `sdk/python/**` as Python, `sdk/typescript/**`
  as TypeScript so language stats reflect the Go core).
- `.github/PULL_REQUEST_TEMPLATE.md` — Summary / Changes / Memory-/
  retrieval-quality impact / Testing / Checklist.
- `.github/ISSUE_TEMPLATE/bug_report.yml` — structured bug report
  with surface dropdown (CLI / MCP / REST / SDK).
- `.github/ISSUE_TEMPLATE/feature_request.yml` — feature request with
  a `kind` selector and developer fit checks.
- `.github/ISSUE_TEMPLATE/config.yml` — routes security to advisories,
  questions to discussions, blocks blank issues.

## [0.1.0] — 2026-05-12

### Added
- DAG branching with prefix-based memory lookup
- LangGraph import/export for interoperability
- MCP resources and prompts support
- Backpressure logging for high-throughput ingestion
- Query timeouts and configurable privacy levels
- Response size limits for large recall results

### Fixed
- Compaction edge re-linking preserves graph structure
- PII detection improvements (reduced false positives)
- Intent scoring accuracy for ambiguous queries
- Secret filter handles multi-line tokens

---

## [0.3.0] — 2026-05-01

### Added
- Tests for 8 previously untested packages
- Tests for 6 MCP resource/prompt packages
- Comprehensive integration test suite

### Fixed
- Backpressure handling under sustained write load
- Query timeout enforcement in graph traversal

---

## [0.1.0] — 2026-04-28

### Initial Release

> Note: this is the original initial release, dated 2026-04-28. A later patch
> release with the same `0.1.0` version was tagged on 2026-05-12 (above); the
> duplicate version heading predates the eco-wide version re-baseline that
> collapsed the interim `0.3.0` line into the current `0.1.0`.

**Core**
- Relaxed DAG memory graph (Labeled Property Graph in SQLite)
- 9 coding-specific node types: convention, decision, bug, spec, task, skill, preference, file, entity
- 8 edge types with cycle enforcement: led_to, supersedes, caused_by, learned_in, part_of (acyclic) + relates_to, depends_on, touches (cyclic allowed)
- Pure Go SQLite via `modernc.org/sqlite` — no CGO, no C compiler required
- FTS5 full-text search with multi-word OR query support
- SHA-256 content deduplication
- Auto entity extraction (files, packages, functions, classes)
- Privacy filtering (strips API keys, tokens, secrets on ingest)

**Interfaces**
- MCP server (stdio, 12 tools) — works with any MCP-compatible agent
- REST/HTTPS API (25+ endpoints, port 3456)
- gRPC server (port 3457) with WatchMemories streaming — planned, proto defined but not yet implemented
- SSE streaming at `/harrier/events`
- CLI (30 commands)
- Web dashboard at `/harrier/ui` (D3.js force graph)

**Agent Integration**
- `harrier setup` for 10 agents: claude-code, cursor, gemini-cli, opencode, codex-cli, cline, windsurf, goose, roo-code, aider
- Auto-capture hooks: SessionStart, PostToolUse, SessionEnd
- CLAUDE.md / .cursorrules / AGENTS.md bi-directional bridge

**Memory Intelligence**
- Hot/warm/cold tier system with token budget management
- Graph-aware memory decay (half-life, orphan/superseded 2× faster)
- Git-aware staleness detection (propagates through graph)
- Hybrid search: BM25 + vector + graph with RRF fusion
- Contextual re-ranking: centrality × recency × confidence × tier
- Proactive context prediction
- Session compression → summary nodes
- Memory feedback API (approve/edit/discard)
- Version history + rollback

**Team & Scale**
- Git chunk sync (`.harrier/chunks/*.jsonl.gz`) — append-only, no merge conflicts
- Team memory namespacing
- Skill/procedural memory with step sequences
- JSON/Markdown/Obsidian export
- Multi-project memory linking
- LongMemEval-style benchmark harness

**Protocols**
- HTTPS/TLS with auto self-signed cert generation
- gRPC with protobuf service definition (proto defined; server implementation planned)
- WebSocket/SSE for real-time memory events
