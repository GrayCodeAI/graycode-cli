package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestCommunityDetector_Empty(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	cd := NewCommunityDetector(store)
	communities, err := cd.Detect(context.Background(), 5)
	if err != nil {
		t.Fatalf("Detect failed: %v", err)
	}
	if len(communities) != 0 {
		t.Errorf("expected 0 communities from empty store, got %d", len(communities))
	}
}

func TestCommunityDetector_ConnectedNodes(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()

	// Create connected nodes (a community)
	_ = store.CreateNode(ctx, &storage.Node{ID: "a1", Type: "convention", Content: "Use jose", Scope: "project", Confidence: 0.9})
	_ = store.CreateNode(ctx, &storage.Node{ID: "a2", Type: "decision", Content: "Chose jose for JWT", Scope: "project", Confidence: 0.8})
	_ = store.CreateNode(ctx, &storage.Node{ID: "a3", Type: "spec", Content: "Auth uses jose RS256", Scope: "project", Confidence: 0.7})
	_ = store.CreateEdge(ctx, &storage.Edge{ID: "e1", FromID: "a1", ToID: "a2", Type: "led_to"})
	_ = store.CreateEdge(ctx, &storage.Edge{ID: "e2", FromID: "a2", ToID: "a3", Type: "led_to"})

	// Create isolated nodes (not a community)
	_ = store.CreateNode(ctx, &storage.Node{ID: "b1", Type: "task", Content: "Fix deploy", Scope: "project", Confidence: 0.5})

	cd := NewCommunityDetector(store)
	communities, err := cd.Detect(ctx, 10)
	if err != nil {
		t.Fatalf("Detect failed: %v", err)
	}
	// Community detection depends on adjacency structure; with 3 connected nodes
	// we should get at least one community, but label propagation may or may not
	// converge depending on graph structure.
	t.Logf("Detected %d communities", len(communities))
	if len(communities) > 0 && communities[0].Size < 2 {
		t.Errorf("largest community should have size >= 2, got %d", communities[0].Size)
	}
}

func TestCommunityDetector_Summarize(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()
	_ = store.CreateNode(ctx, &storage.Node{ID: "s1", Type: "convention", Content: "Always use strict TypeScript", Scope: "project", Confidence: 0.9})
	_ = store.CreateNode(ctx, &storage.Node{ID: "s2", Type: "convention", Content: "Use ESLint for linting", Scope: "project", Confidence: 0.8})
	_ = store.CreateEdge(ctx, &storage.Edge{ID: "se1", FromID: "s1", ToID: "s2", Type: "relates_to"})

	cd := NewCommunityDetector(store)
	communities, _ := cd.Detect(ctx, 5)
	communities = cd.Summarize(ctx, communities)

	for _, c := range communities {
		if c.Summary == "" {
			t.Error("community summary should not be empty after Summarize")
		}
	}
}

func TestFindCommunityForQuery(t *testing.T) {
	t.Parallel()
	cd := &CommunityDetector{}
	communities := []Community{
		{ID: 1, Summary: "Authentication using jose JWT RS256", Size: 5},
		{ID: 2, Summary: "Deploy to fly.io with Docker", Size: 3},
		{ID: 3, Summary: "Testing with vitest and coverage", Size: 4},
	}

	best := cd.FindCommunityForQuery(communities, "how does auth work?")
	if best == nil || best.ID != 1 {
		t.Errorf("expected auth community for 'how does auth work?', got %+v", best)
	}

	best2 := cd.FindCommunityForQuery(communities, "deploy docker fly")
	if best2 == nil || best2.ID != 2 {
		t.Errorf("expected deploy community, got %+v", best2)
	}
}
