package engine

import (
	"testing"
	"time"
)

func TestRateLimiter_AllowWithinBurst(t *testing.T) {
	t.Parallel()
	rl := NewRateLimiter(10, 5)

	// First 5 requests (burst) should all succeed.
	for i := 0; i < 5; i++ {
		if !rl.Allow() {
			t.Errorf("request %d: Allow = false, want true", i+1)
		}
	}
	// 6th request fails — no tokens left until refill.
	if rl.Allow() {
		t.Error("request 6: Allow = true, want false (burst exhausted)")
	}
}

func TestRateLimiter_Remaining(t *testing.T) {
	t.Parallel()
	rl := NewRateLimiter(10, 5)
	if rl.Remaining() != 5 {
		t.Errorf("Remaining = %d, want 5", rl.Remaining())
	}
	rl.Allow()
	if rl.Remaining() != 4 {
		t.Errorf("Remaining after 1 Allow = %d, want 4", rl.Remaining())
	}
}

func TestRateLimiter_Refill(t *testing.T) {
	t.Parallel()
	// 10 req/sec, burst of 1.
	rl := NewRateLimiter(10, 1)
	if !rl.Allow() {
		t.Fatal("first Allow = false, want true")
	}
	if rl.Allow() {
		t.Error("second Allow = true, want false (no tokens)")
	}

	// Wait for one token to refill (100ms for 10 req/sec).
	time.Sleep(150 * time.Millisecond)
	if !rl.Allow() {
		t.Error("Allow after refill = false, want true")
	}
}

func TestRateLimiter_MaxBurstCap(t *testing.T) {
	t.Parallel()
	rl := NewRateLimiter(1000, 3)
	// Wait long enough to refill many tokens, but it must cap at maxBurst.
	time.Sleep(200 * time.Millisecond)
	if rl.Remaining() > 3 {
		t.Errorf("Remaining = %d, want <= 3 (maxBurst cap)", rl.Remaining())
	}
}
