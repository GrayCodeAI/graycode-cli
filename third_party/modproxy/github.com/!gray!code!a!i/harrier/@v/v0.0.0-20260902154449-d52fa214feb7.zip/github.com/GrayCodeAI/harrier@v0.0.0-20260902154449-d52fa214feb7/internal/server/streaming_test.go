package server

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
)

func newIPv4Server(t *testing.T, h http.Handler) *httptest.Server {
	t.Helper()
	ln, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		if errors.Is(err, os.ErrPermission) || strings.Contains(err.Error(), "operation not permitted") {
			t.Skipf("sandbox does not allow local listeners: %v", err)
		}
		t.Fatalf("listen tcp4: %v", err)
	}
	srv := httptest.NewUnstartedServer(h)
	srv.Listener = ln
	srv.Start()
	return srv
}

// readSSEEvent reads SSE frames from r until it finds a "data:" line, parses it
// as a MemoryEvent, and returns it. Fails on timeout via the caller's deadline.
func readSSEEvent(t *testing.T, r *bufio.Reader) MemoryEvent {
	t.Helper()
	for {
		line, err := r.ReadString('\n')
		if err != nil {
			t.Fatalf("read SSE stream: %v", err)
		}
		line = strings.TrimRight(line, "\r\n")
		if !strings.HasPrefix(line, "data:") {
			continue
		}
		payload := strings.TrimSpace(strings.TrimPrefix(line, "data:"))
		var evt MemoryEvent
		if err := json.Unmarshal([]byte(payload), &evt); err != nil {
			t.Fatalf("unmarshal SSE data %q: %v", payload, err)
		}
		return evt
	}
}

func TestWatchMemoriesSSE(t *testing.T) {
	t.Parallel()
	srv, eng, cleanup := setupTestServer(t)
	defer cleanup()

	broadcaster := NewSSEBroadcaster(eng)
	srv.WithBroadcaster(broadcaster)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go broadcaster.Start(ctx)

	mux := http.NewServeMux()
	srv.RegisterRoutes(mux)
	ts := newIPv4Server(t, mux)
	defer ts.Close()

	// Open the SSE stream on the canonical /harrier/watch endpoint. The request
	// context (not Client.Timeout, which would abort the long-lived stream)
	// bounds the test.
	reqCtx, reqCancel := context.WithCancel(context.Background())
	defer reqCancel()
	req, err := http.NewRequestWithContext(reqCtx, "GET", ts.URL+"/harrier/watch", nil)
	if err != nil {
		t.Fatal(err)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "text/event-stream" {
		t.Fatalf("Content-Type = %q, want text/event-stream", ct)
	}

	// Give the broadcaster goroutine + the SSE subscription a moment to attach
	// before producing the event, otherwise the publish races the subscribe.
	time.Sleep(100 * time.Millisecond)

	n, err := eng.Remember(context.Background(), engine.RememberInput{
		Type: "decision", Content: "stream me", Scope: "project",
	})
	if err != nil {
		t.Fatalf("Remember: %v", err)
	}

	reader := bufio.NewReader(resp.Body)
	done := make(chan MemoryEvent, 1)
	go func() { done <- readSSEEvent(t, reader) }()

	select {
	case evt := <-done:
		if evt.Type != MemoryEventCreated {
			t.Errorf("event type = %q, want %q", evt.Type, MemoryEventCreated)
		}
		if evt.NodeID != n.ID {
			t.Errorf("event node id = %q, want %q", evt.NodeID, n.ID)
		}
		if evt.Content != "stream me" {
			t.Errorf("event content = %q, want %q", evt.Content, "stream me")
		}
	case <-time.After(3 * time.Second):
		t.Fatal("timed out waiting for SSE memory event")
	}
}

func TestWatchMemoriesDisabled(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupTestServer(t)
	defer cleanup()

	// No broadcaster attached: the endpoint must report streaming disabled.
	mux := http.NewServeMux()
	srv.RegisterRoutes(mux)

	req := httptest.NewRequest("GET", "/harrier/watch", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)
	if rr.Code != http.StatusServiceUnavailable {
		t.Fatalf("status = %d, want 503", rr.Code)
	}
}

func TestAPIV1EventsStreamSSE(t *testing.T) {
	t.Parallel()
	srv, eng, cleanup := setupTestServer(t)
	defer cleanup()

	broadcaster := NewSSEBroadcaster(eng)
	srv.WithBroadcaster(broadcaster)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go broadcaster.Start(ctx)

	mux := http.NewServeMux()
	srv.RegisterRoutes(mux)
	ts := newIPv4Server(t, mux)
	defer ts.Close()

	reqCtx, reqCancel := context.WithCancel(context.Background())
	defer reqCancel()
	req, err := http.NewRequestWithContext(reqCtx, "GET", ts.URL+"/api/v1/events/stream", nil)
	if err != nil {
		t.Fatal(err)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}
	if ct := resp.Header.Get("Content-Type"); ct != "text/event-stream" {
		t.Fatalf("Content-Type = %q, want text/event-stream", ct)
	}
}
