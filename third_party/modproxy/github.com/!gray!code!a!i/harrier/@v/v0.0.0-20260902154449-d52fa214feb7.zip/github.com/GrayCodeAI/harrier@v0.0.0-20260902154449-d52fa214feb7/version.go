// Package harrier provides graph-based persistent memory for coding agents.
//
// The Version variable is sourced from the VERSION file at the repo root.
package harrier

import (
	_ "embed"
	"fmt"
	"runtime"
	"strings"
)

//go:embed VERSION
var versionFile string

// Version of the harrier library. Single source of truth: VERSION file.
var Version = strings.TrimSpace(versionFile)

// Commit is the git commit short SHA. Set via ldflags at release time.
var Commit = "none"

// Date is the build date in RFC3339. Set via ldflags at release time.
var Date = "unknown"

// String returns just the version string.
func String() string { return Version }

// Full returns a verbose version string suitable for `--version` output.
func Full() string {
	return fmt.Sprintf("harrier %s (commit: %s, built: %s, %s/%s)",
		Version, Commit, Date, runtime.GOOS, runtime.GOARCH)
}
