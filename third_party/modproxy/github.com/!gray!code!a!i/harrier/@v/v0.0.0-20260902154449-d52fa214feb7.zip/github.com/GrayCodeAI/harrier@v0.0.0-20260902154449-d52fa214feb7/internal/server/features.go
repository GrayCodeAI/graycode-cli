package server

import (
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/privacy"
)

// --- Task #202: Git-aware staleness ---

// handleMarkStale detects files changed since the given time and marks affected
// memories as stale by reducing their confidence.
// POST /harrier/staleness/mark
// Body: {"since": "2026-05-20T00:00:00Z", "penalty": 0.15}
func (s *RESTServer) handleMarkStale(w http.ResponseWriter, r *http.Request) {
	if s.projectDir == "" {
		httpJSON(w, map[string]string{"status": "no project directory configured"}, 200)
		return
	}

	var body struct {
		Since   string  `json:"since"`
		Penalty float64 `json:"penalty"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}

	since := time.Now().Add(-7 * 24 * time.Hour)
	if body.Since != "" {
		var err error
		since, err = time.Parse(time.RFC3339, body.Since)
		if err != nil {
			httpErr(w, fmt.Errorf("invalid since format (use RFC3339): %w", err), 400)
			return
		}
	}

	sm, err := engine.NewStalenessManager(s.eng.Store(), s.eng.Graph(), s.projectDir)
	if err != nil {
		httpErr(w, err, 500)
		return
	}

	marked, err := sm.MarkStale(r.Context(), since, body.Penalty)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]interface{}{
		"marked":  len(marked),
		"details": marked,
	}, 200)
}

// --- Task #203: Impact analysis ---

// handleAnalyzeImpact traces all memories downstream of a changed node.
// POST /harrier/impact/analyze
// Body: {"node_id": "...", "max_depth": 3}
func (s *RESTServer) handleAnalyzeImpact(w http.ResponseWriter, r *http.Request) {
	var body struct {
		NodeID   string `json:"node_id"`
		MaxDepth int    `json:"max_depth"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if body.NodeID == "" {
		httpErr(w, fmt.Errorf("node_id is required"), 400)
		return
	}

	analysis, err := s.eng.AnalyzeImpact(r.Context(), body.NodeID, body.MaxDepth)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, analysis, 200)
}

// --- Task #207: Three-tier loading ---

// handleTierLoad returns memories grouped by tier (hot/warm/cold).
// GET /harrier/tiers?project=...
func (s *RESTServer) handleTierLoad(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	loader := engine.NewTierLoader(s.eng.Store())

	result, err := loader.LoadAll(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}

	httpJSON(w, map[string]interface{}{
		"hot":        len(result.Hot),
		"warm":       len(result.Warm),
		"cold":       len(result.Cold),
		"hot_nodes":  result.Hot,
		"warm_nodes": result.Warm,
		"cold_nodes": result.Cold,
	}, 200)
}

// --- Task #208: Privacy filter ---

// handlePrivacyGet returns the current privacy filter configuration.
// GET /harrier/privacy
func (s *RESTServer) handlePrivacyGet(w http.ResponseWriter, r *http.Request) {
	level := s.eng.PrivacyLevel()
	levelName := "moderate"
	switch level {
	case privacy.Strict:
		levelName = "strict"
	case privacy.Minimal:
		levelName = "minimal"
	}

	httpJSON(w, map[string]interface{}{
		"level":         levelName,
		"level_numeric": int(level),
		"levels": []map[string]interface{}{
			{"name": "strict", "numeric": 0, "description": "Strip all PII, emails, IPs, and secrets"},
			{"name": "moderate", "numeric": 1, "description": "Strip secrets and PII, keep work emails and infra IPs"},
			{"name": "minimal", "numeric": 2, "description": "Strip only high-entropy secrets and API keys"},
		},
	}, 200)
}

// handlePrivacySet updates the privacy filter level.
// POST /harrier/privacy
// Body: {"level": "strict"}
func (s *RESTServer) handlePrivacySet(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Level string `json:"level"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}

	var level privacy.FilterLevel
	switch body.Level {
	case "strict":
		level = privacy.Strict
	case "moderate":
		level = privacy.Moderate
	case "minimal":
		level = privacy.Minimal
	default:
		httpErr(w, fmt.Errorf("invalid level %q: use strict, moderate, or minimal", body.Level), 400)
		return
	}

	s.eng.WithPrivacyLevel(level)
	httpJSON(w, map[string]string{"level": body.Level, "status": "updated"}, 200)
}

// --- Task #209: Auto-decay ---

// handleDecayStatus returns the decay scheduler's current state.
// GET /harrier/decay/status
func (s *RESTServer) handleDecayStatus(w http.ResponseWriter, r *http.Request) {
	cfg := s.eng.DecayConfig
	httpJSON(w, map[string]interface{}{
		"half_life_days":  cfg.HalfLifeDays,
		"min_confidence":  cfg.MinConfidence,
		"boost_on_access": cfg.BoostOnAccess,
		"auto_decay":      "Use POST /harrier/decay to trigger manually. Configure scheduler in engine initialization.",
	}, 200)
}

// --- Task #204/205: Query with intent ---

// handleQuery answers a natural language question from memories.
// POST /harrier/query
// Body: {"question": "...", "project": "..."}
func (s *RESTServer) handleQuery(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Question string `json:"question"`
		Project  string `json:"project"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if body.Question == "" {
		httpErr(w, fmt.Errorf("question is required"), 400)
		return
	}

	result, err := s.eng.Query(r.Context(), body.Question, body.Project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, result, 200)
}
