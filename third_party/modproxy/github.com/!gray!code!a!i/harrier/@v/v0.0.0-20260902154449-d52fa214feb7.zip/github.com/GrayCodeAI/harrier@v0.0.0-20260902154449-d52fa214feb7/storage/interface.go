package storage

import (
	"context"
	"time"
)

// DoctorStatsResult holds aggregated diagnostic counts computed via SQL
// without loading individual nodes into memory.
type DoctorStatsResult struct {
	TotalNodes    int
	LowConfidence int // nodes with confidence < 0.2
	Pinned        int
	Orphans       int // nodes with zero edges (inbound or outbound)
}

// Storage is the persistence interface used by Engine and other packages.
// All graph-aware queries (recursive CTEs, cycle detection) are encapsulated
// behind methods so callers never need raw *sql.DB access.
type Storage interface {
	// Nodes
	CreateNode(ctx context.Context, n *Node) error
	GetNode(ctx context.Context, id string) (*Node, error)
	GetNodeByKey(ctx context.Context, key, project string) (*Node, error)
	GetNodesBatch(ctx context.Context, ids []string) ([]*Node, error)
	UpdateNode(ctx context.Context, n *Node) error
	UpdateNodeContent(ctx context.Context, id, newContent string) error
	// ArchiveNode atomically sets confidence to 0 (the archived marker) but
	// only if the node is still live (confidence > 0). It returns whether the
	// node was archived; a node already archived is a no-op, not an error.
	ArchiveNode(ctx context.Context, id string) (bool, error)
	DeleteNode(ctx context.Context, id string) error
	ListNodes(ctx context.Context, f NodeFilter) ([]*Node, error)
	SearchNodes(ctx context.Context, query string, limit int) ([]*Node, error)
	SearchNodeByHash(ctx context.Context, hash, scope, project string) (*Node, error)
	GetNeighbors(ctx context.Context, nodeID string) ([]*Node, error)

	// Edges
	CreateEdge(ctx context.Context, e *Edge) error
	GetEdge(ctx context.Context, id string) (*Edge, error)
	InvalidateEdge(ctx context.Context, id string) error // non-destructive: sets invalid_at = now
	DeleteEdge(ctx context.Context, id string) error
	GetEdgesFrom(ctx context.Context, nodeID string) ([]*Edge, error)
	GetEdgesTo(ctx context.Context, nodeID string) ([]*Edge, error)
	// Point-in-time validity queries: return only edges that were valid at the
	// given instant (valid_at <= at AND (invalid_at IS NULL OR invalid_at > at)).
	// A zero `at` is treated as "now". Default edge readers are unaffected.
	GetValidEdgesFrom(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error)
	GetValidEdgesTo(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error)
	GetEdgesBetween(ctx context.Context, nodeIDs []string) ([]*Edge, error)
	GetAllEdgesFor(ctx context.Context, nodeIDs []string) ([]*Edge, error) // edges where from_id OR to_id in set
	CountEdges(ctx context.Context, nodeID string) (inbound int, outbound int, err error)
	CountEdgesBatch(ctx context.Context, nodeIDs []string) (map[string][2]int, error)
	CountAllEdges(ctx context.Context) (int, error)

	// Stats
	NodeStats(ctx context.Context) (map[string]int, int, error) // nodesByType, totalNodes, err
	DoctorStats(ctx context.Context) (DoctorStatsResult, error) // aggregated diagnostics without loading nodes
	LastUpdated(ctx context.Context) (time.Time, error)
	TopConnected(ctx context.Context, limit int) ([]string, error)

	// Graph queries (encapsulates recursive CTEs)
	CheckCycle(ctx context.Context, fromID, toID string) (bool, error)

	// Sessions
	CreateSession(ctx context.Context, sess *Session) error
	EndSession(ctx context.Context, id string, summary string) error
	ListSessions(ctx context.Context, project string, limit int) ([]*Session, error)

	// Versions
	SaveVersion(ctx context.Context, nodeID string, content, changedBy, reason string) error
	GetVersions(ctx context.Context, nodeID string) ([]*NodeVersion, error)

	// Embeddings
	SaveEmbedding(ctx context.Context, nodeID, model string, vector []float32) error
	GetEmbedding(ctx context.Context, nodeID string) ([]float32, string, error)
	DeleteEmbedding(ctx context.Context, nodeID string) error
	// AllEmbeddings / GetEmbeddingsBatch take a model filter ("" = all models):
	// vectors from different embedding models occupy incompatible spaces and must
	// not be mixed into one similarity comparison.
	AllEmbeddings(ctx context.Context, model string) (map[string][]float32, error)
	GetEmbeddingsBatch(ctx context.Context, model string, offset, limit int) (map[string][]float32, error)

	// HNSW Vector Search (approximate nearest neighbor)
	BuildHNSWIndex(ctx context.Context, model string) error
	SearchHNSW(ctx context.Context, model string, query []float32, k, ef int) ([]string, []float32, error)

	// Replay
	AddReplayEvent(ctx context.Context, sessionID, data string) error
	GetReplayEvents(ctx context.Context, sessionID string) ([]*ReplayEvent, error)

	// File watch (staleness tracking)
	AddFileWatch(ctx context.Context, filePath, nodeID, gitHash string) error

	// AccessLog: lightweight access tracking (batched flush)
	LogAccess(ctx context.Context, nodeID string) error
	FlushAccessLog(ctx context.Context) (int, error)

	// Metadata: structured key-value metadata per node
	SaveNodeMetadata(ctx context.Context, nodeID string, meta map[string]string) error
	LoadNodeMetadata(ctx context.Context, nodeIDs []string) (map[string]map[string]string, error)

	// Signatures: HMAC integrity signatures for tamper detection
	SaveSignature(ctx context.Context, nodeID, signature string) error
	GetAllSignatures(ctx context.Context) (map[string]string, error)

	// Transactions
	WithTx(ctx context.Context, fn func(Storage) error) error

	// Backup writes a consistent, compact snapshot of the database to
	// backupPath (atomic temp-file + rename, owner-only permissions).
	Backup(ctx context.Context, backupPath string) error

	Close() error
}
