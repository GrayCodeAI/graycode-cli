package cognitive

import (
	"math"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

type ProspectiveMemory struct {
	ID               string     `json:"id"`
	TriggerCondition string     `json:"trigger_condition"`
	TriggerEmbedding []float32  `json:"trigger_embedding,omitempty"`
	Action           string     `json:"action"`
	CreatedAt        time.Time  `json:"created_at"`
	ExpiresAt        *time.Time `json:"expires_at,omitempty"`
	TriggeredAt      *time.Time `json:"triggered_at,omitempty"`
	SourceSession    string     `json:"source_session,omitempty"`
	Priority         float64    `json:"priority"`
}

type ProspectiveConfig struct {
	Enabled          bool          `json:"enabled"`
	TriggerThreshold float64       `json:"trigger_threshold"`
	DefaultTTL       time.Duration `json:"default_ttl"`
	MaxActive        int           `json:"max_active"`
}

func DefaultProspectiveConfig() ProspectiveConfig {
	return ProspectiveConfig{
		Enabled:          true,
		TriggerThreshold: 0.75,
		DefaultTTL:       30 * 24 * time.Hour,
		MaxActive:        50,
	}
}

type ProspectiveEngine struct {
	mu       sync.RWMutex
	memories []*ProspectiveMemory
	config   ProspectiveConfig
}

func NewProspectiveEngine(config ProspectiveConfig) *ProspectiveEngine {
	return &ProspectiveEngine{
		memories: make([]*ProspectiveMemory, 0),
		config:   config,
	}
}

func (e *ProspectiveEngine) Create(triggerCondition, action, sourceSession string, triggerEmbedding []float32, priority float64) *ProspectiveMemory {
	if !e.config.Enabled {
		return nil
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	active := e.activeCount()
	if active >= e.config.MaxActive {
		return nil
	}

	now := time.Now()
	expires := now.Add(e.config.DefaultTTL)
	if priority <= 0 {
		priority = 0.5
	}

	mem := &ProspectiveMemory{
		ID:               uuid.New().String()[:12],
		TriggerCondition: triggerCondition,
		TriggerEmbedding: triggerEmbedding,
		Action:           action,
		CreatedAt:        now,
		ExpiresAt:        &expires,
		SourceSession:    sourceSession,
		Priority:         priority,
	}
	e.memories = append(e.memories, mem)
	return mem
}

func (e *ProspectiveEngine) CheckTriggers(messageText string, messageEmbedding []float32) []*ProspectiveMemory {
	if !e.config.Enabled {
		return nil
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	now := time.Now()
	var triggered []*ProspectiveMemory

	for _, mem := range e.memories {
		if mem.TriggeredAt != nil {
			continue
		}
		if mem.ExpiresAt != nil && now.After(*mem.ExpiresAt) {
			continue
		}

		matched := false

		// Strategy 1: Semantic matching via cosine similarity
		if len(messageEmbedding) > 0 && len(mem.TriggerEmbedding) > 0 {
			sim := cosineSim(messageEmbedding, mem.TriggerEmbedding)
			if sim >= e.config.TriggerThreshold {
				matched = true
			}
		}

		// Strategy 2: Keyword matching
		if !matched {
			matched = keywordMatch(mem.TriggerCondition, messageText)
		}

		if matched {
			t := now
			mem.TriggeredAt = &t
			triggered = append(triggered, mem)
		}
	}

	return triggered
}

func (e *ProspectiveEngine) CleanExpired() int {
	e.mu.Lock()
	defer e.mu.Unlock()

	now := time.Now()
	cleaned := 0
	kept := make([]*ProspectiveMemory, 0, len(e.memories))

	for _, mem := range e.memories {
		if mem.ExpiresAt != nil && now.After(*mem.ExpiresAt) && mem.TriggeredAt == nil {
			cleaned++
			continue
		}
		kept = append(kept, mem)
	}

	e.memories = kept
	return cleaned
}

func (e *ProspectiveEngine) GetActive() []*ProspectiveMemory {
	e.mu.RLock()
	defer e.mu.RUnlock()

	now := time.Now()
	var active []*ProspectiveMemory
	for _, mem := range e.memories {
		if mem.TriggeredAt == nil && (mem.ExpiresAt == nil || now.Before(*mem.ExpiresAt)) {
			active = append(active, mem)
		}
	}
	return active
}

func (e *ProspectiveEngine) activeCount() int {
	now := time.Now()
	count := 0
	for _, mem := range e.memories {
		if mem.TriggeredAt == nil && (mem.ExpiresAt == nil || now.Before(*mem.ExpiresAt)) {
			count++
		}
	}
	return count
}

func keywordMatch(trigger, message string) bool {
	triggerLower := strings.ToLower(trigger)
	messageLower := strings.ToLower(message)

	words := strings.Fields(triggerLower)
	var significant []string
	for _, w := range words {
		if len(w) > 3 {
			significant = append(significant, w)
		}
	}
	if len(significant) == 0 {
		return false
	}

	matched := 0
	for _, w := range significant {
		if strings.Contains(messageLower, w) {
			matched++
		}
	}

	return float64(matched)/float64(len(significant)) >= 0.6
}

func cosineSim(a, b []float32) float64 {
	if len(a) != len(b) || len(a) == 0 {
		return 0
	}
	var dot, normA, normB float64
	for i := range a {
		dot += float64(a[i]) * float64(b[i])
		normA += float64(a[i]) * float64(a[i])
		normB += float64(b[i]) * float64(b[i])
	}
	if normA == 0 || normB == 0 {
		return 0
	}
	return dot / (math.Sqrt(normA) * math.Sqrt(normB))
}
