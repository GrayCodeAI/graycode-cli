package dedup

import (
	"testing"
	"time"
)

func TestWindow_BasicDedup(t *testing.T) {
	t.Parallel()
	w := New(5 * time.Minute)

	if w.IsDuplicate("hello world") {
		t.Error("first submission should not be duplicate")
	}
	if !w.IsDuplicate("hello world") {
		t.Error("second identical submission should be duplicate")
	}
}

func TestWindow_DifferentContent(t *testing.T) {
	t.Parallel()
	w := New(5 * time.Minute)

	w.IsDuplicate("content A")
	if w.IsDuplicate("content B") {
		t.Error("different content should not be duplicate")
	}
}

func TestWindow_WhitespaceNormalization(t *testing.T) {
	t.Parallel()
	w := New(5 * time.Minute)

	w.IsDuplicate("hello   world")
	if !w.IsDuplicate("hello\t\nworld") {
		t.Error("whitespace-only differences should be considered duplicates")
	}
}

func TestWindow_Expiry(t *testing.T) {
	t.Parallel()
	w := New(1 * time.Millisecond)

	w.IsDuplicate("expires fast")
	time.Sleep(5 * time.Millisecond)

	if w.IsDuplicate("expires fast") {
		t.Error("content should not be duplicate after window expires")
	}
}

func TestWindow_DefaultDuration(t *testing.T) {
	t.Parallel()
	w := New(0)
	if w.duration != 5*time.Minute {
		t.Errorf("expected default 5m, got %v", w.duration)
	}
}

func TestWindow_ConcurrentAccess(t *testing.T) {
	t.Parallel()
	w := New(5 * time.Minute)
	done := make(chan bool, 10)

	for i := 0; i < 10; i++ {
		go func(n int) {
			w.IsDuplicate("concurrent content")
			done <- true
		}(i)
	}

	for i := 0; i < 10; i++ {
		<-done
	}
}
