package hooks

// PipelinePhase identifies the step of the localize → repair → validate
// pipeline in which a tool call occurs. These constants match
// eagle/sessions.Phase; they are duplicated here to keep harrier
// free of the eagle go.mod dependency.
type PipelinePhase string

const (
	PipelinePhaseLocalize PipelinePhase = "localize"
	PipelinePhaseRepair   PipelinePhase = "repair"
	PipelinePhaseValidate PipelinePhase = "validate"
	PipelinePhaseReview   PipelinePhase = "review"
	PipelinePhaseUnknown  PipelinePhase = ""
)

// PhaseAwareRelevance adjusts the base relevance score from ScoreRelevance
// based on the pipeline phase in which the tool call occurs. Phase-specific
// tuning ensures harrier captures the right memories at the right time:
//
//   - localize: file reads become more interesting (they reveal search targets)
//   - repair: writes/edits are the primary signal; everything else is background
//   - validate: test and lint outputs are the primary signal
//   - review: any write or decision is high-signal (review phase drives cost)
func PhaseAwareRelevance(phase PipelinePhase, toolName, input, output, toolError string) float64 {
	base := ScoreRelevance(toolName, input, output, toolError)
	switch phase {
	case PipelinePhaseLocalize:
		// Reads are more signal-dense when actively localising a bug.
		if toolName == "Read" || toolName == "Glob" || toolName == "Grep" {
			base += 0.3
		}
	case PipelinePhaseRepair:
		// Writes and edits are the signal; devalue exploratory reads.
		switch toolName {
		case "Write", "Edit", "MultiEdit":
			base = max64(base, 0.8)
		case "Read", "Glob":
			base -= 0.1
		}
	case PipelinePhaseValidate:
		// Test/lint output is the primary decision signal.
		if toolName == "Bash" {
			base = max64(base, 0.7)
		}
	case PipelinePhaseReview:
		// Review is the most expensive phase; capture all decisions.
		if containsDecisionSignal(output) || containsConventionSignal(output) {
			base = max64(base, 0.9)
		}
	}
	if base > 1.0 {
		base = 1.0
	}
	if base < 0.0 {
		base = 0.0
	}
	return base
}

// PhaseAwareShouldCapture returns true if the observation passes the relevance
// threshold after phase-specific adjustment.
func PhaseAwareShouldCapture(phase PipelinePhase, toolName, input, output, toolError string) bool {
	return PhaseAwareRelevance(phase, toolName, input, output, toolError) >= relevanceThreshold
}

func max64(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}
