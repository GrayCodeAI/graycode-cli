package cognitive

import (
	"sort"
	"sync"
	"time"

	"github.com/google/uuid"
)

type ExplorationTarget struct {
	ID         string     `json:"id"`
	Topic      string     `json:"topic"`
	GapType    string     `json:"gap_type"`
	Priority   float64    `json:"priority"`
	CreatedAt  time.Time  `json:"created_at"`
	ExploredAt *time.Time `json:"explored_at,omitempty"`
	Findings   string     `json:"findings,omitempty"`
}

type CuriosityConfig struct {
	Enabled    bool `json:"enabled"`
	MaxTargets int  `json:"max_targets"`
}

func DefaultCuriosityConfig() CuriosityConfig {
	return CuriosityConfig{
		Enabled:    true,
		MaxTargets: 20,
	}
}

type CuriosityEngine struct {
	mu      sync.RWMutex
	targets []*ExplorationTarget
	config  CuriosityConfig
}

func NewCuriosityEngine(config CuriosityConfig) *CuriosityEngine {
	return &CuriosityEngine{
		targets: make([]*ExplorationTarget, 0),
		config:  config,
	}
}

func (e *CuriosityEngine) AddTarget(topic, gapType string, priority float64) *ExplorationTarget {
	if !e.config.Enabled {
		return nil
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	// Dedup
	for _, t := range e.targets {
		if t.Topic == topic && t.ExploredAt == nil {
			if priority > t.Priority {
				t.Priority = priority
			}
			return t
		}
	}

	if len(e.targets) >= e.config.MaxTargets {
		// Evict lowest priority explored target
		sort.Slice(e.targets, func(i, j int) bool {
			return e.targets[i].Priority < e.targets[j].Priority
		})
		if e.targets[0].ExploredAt != nil {
			e.targets = e.targets[1:]
		} else {
			return nil
		}
	}

	target := &ExplorationTarget{
		ID:        uuid.New().String()[:12],
		Topic:     topic,
		GapType:   gapType,
		Priority:  priority,
		CreatedAt: time.Now(),
	}
	e.targets = append(e.targets, target)
	return target
}

func (e *CuriosityEngine) GetTopTargets(limit int) []*ExplorationTarget {
	e.mu.RLock()
	defer e.mu.RUnlock()

	var unexplored []*ExplorationTarget
	for _, t := range e.targets {
		if t.ExploredAt == nil {
			unexplored = append(unexplored, t)
		}
	}

	sort.Slice(unexplored, func(i, j int) bool {
		return unexplored[i].Priority > unexplored[j].Priority
	})

	if len(unexplored) > limit {
		unexplored = unexplored[:limit]
	}
	return unexplored
}

func (e *CuriosityEngine) MarkExplored(targetID, findings string) bool {
	e.mu.Lock()
	defer e.mu.Unlock()

	for _, t := range e.targets {
		if t.ID == targetID {
			now := time.Now()
			t.ExploredAt = &now
			t.Findings = findings
			return true
		}
	}
	return false
}
