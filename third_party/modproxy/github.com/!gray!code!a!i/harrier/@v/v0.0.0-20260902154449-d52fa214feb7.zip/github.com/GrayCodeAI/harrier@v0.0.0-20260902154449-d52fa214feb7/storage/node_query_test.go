package storage

import (
	"context"
	"testing"
	"time"
)

func TestGetNodeByKey(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Not found returns (nil, nil) — upsert-check pattern.
	got, err := s.GetNodeByKey(ctx, "topic:auth", "proj")
	if err != nil {
		t.Fatalf("GetNodeByKey miss: %v", err)
	}
	if got != nil {
		t.Errorf("expected nil for missing key, got %v", got)
	}

	if err := s.CreateNode(ctx, &Node{
		ID: "n1", Type: "topic", Content: "auth content", ContentHash: "h1",
		Scope: "project", Project: "proj", Key: "topic:auth",
	}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}

	got, err = s.GetNodeByKey(ctx, "topic:auth", "proj")
	if err != nil {
		t.Fatalf("GetNodeByKey hit: %v", err)
	}
	if got == nil || got.ID != "n1" {
		t.Fatalf("expected n1, got %v", got)
	}
	if got.Key != "topic:auth" {
		t.Errorf("key = %q, want topic:auth", got.Key)
	}

	// Same key, different project must not match.
	other, err := s.GetNodeByKey(ctx, "topic:auth", "otherproj")
	if err != nil {
		t.Fatalf("GetNodeByKey other project: %v", err)
	}
	if other != nil {
		t.Errorf("key scoped to project should not match other project, got %v", other)
	}
}

func TestUpdateNode(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{
		ID: "n1", Type: "convention", Content: "old", ContentHash: "h1",
		Scope: "project", Project: "proj", Confidence: 0.5, Version: 1,
	}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}

	updated := &Node{
		ID: "n1", Type: "decision", Content: "new content", ContentHash: "h2",
		Summary: "sum", Scope: "global", Project: "proj", Tier: 3, Tags: "a,b",
		Pinned: true, Confidence: 0.9, AccessCount: 7, Version: 2,
		Metadata: map[string]string{"k": "v"},
	}
	if err := s.UpdateNode(ctx, updated); err != nil {
		t.Fatalf("UpdateNode: %v", err)
	}

	got, err := s.GetNode(ctx, "n1")
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if got.Type != "decision" || got.Content != "new content" || got.ContentHash != "h2" {
		t.Errorf("update not persisted: %+v", got)
	}
	if got.Tier != 3 || !got.Pinned || got.Confidence != 0.9 || got.Version != 2 {
		t.Errorf("scalar fields not updated: %+v", got)
	}

	// UpdateNode also persists metadata via saveNodeMetadataQ.
	loaded, err := s.LoadNodeMetadata(ctx, []string{"n1"})
	if err != nil {
		t.Fatalf("LoadNodeMetadata: %v", err)
	}
	if loaded["n1"]["k"] != "v" {
		t.Errorf("UpdateNode did not persist metadata, got %v", loaded["n1"])
	}
}

func TestUpdateNodeContent(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{
		ID: "n1", Type: "convention", Content: "before", ContentHash: "h1", Scope: "project",
	}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}
	if err := s.UpdateNodeContent(ctx, "n1", "after"); err != nil {
		t.Fatalf("UpdateNodeContent: %v", err)
	}
	got, err := s.GetNode(ctx, "n1")
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if got.Content != "after" {
		t.Errorf("content = %q, want after", got.Content)
	}
}

func TestGetNeighbors(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b", "c", "d"} {
		if err := s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}
	// a -> b (outbound), c -> a (inbound). d is isolated.
	if err := s.CreateEdge(ctx, &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1}); err != nil {
		t.Fatalf("CreateEdge e1: %v", err)
	}
	if err := s.CreateEdge(ctx, &Edge{ID: "e2", FromID: "c", ToID: "a", Type: "led_to", Weight: 1}); err != nil {
		t.Fatalf("CreateEdge e2: %v", err)
	}

	neighbors, err := s.GetNeighbors(ctx, "a")
	if err != nil {
		t.Fatalf("GetNeighbors: %v", err)
	}
	ids := map[string]bool{}
	for _, n := range neighbors {
		ids[n.ID] = true
	}
	if !ids["b"] || !ids["c"] {
		t.Errorf("expected neighbors b and c, got %v", ids)
	}
	if ids["a"] {
		t.Errorf("node should not be its own neighbor")
	}
	if ids["d"] {
		t.Errorf("isolated node d leaked")
	}
	if len(ids) != 2 {
		t.Errorf("expected 2 distinct neighbors, got %d (%v)", len(ids), ids)
	}
}

func TestGetValidEdgesFromTo_PointInTime(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b"} {
		if err := s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}

	base := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	// Edge valid in [base, base+2h).
	e := &Edge{
		ID: "e1", FromID: "a", ToID: "b", Type: "rel", Weight: 1,
		ValidAt:   base.Add(1 * time.Hour),
		InvalidAt: base.Add(3 * time.Hour),
	}
	if err := s.CreateEdge(ctx, e); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}

	// Before valid_at: not returned.
	from, err := s.GetValidEdgesFrom(ctx, "a", base)
	if err != nil {
		t.Fatalf("GetValidEdgesFrom before: %v", err)
	}
	if len(from) != 0 {
		t.Errorf("expected no valid edges before valid_at, got %d", len(from))
	}

	// Inside the validity window: returned.
	from, err = s.GetValidEdgesFrom(ctx, "a", base.Add(2*time.Hour))
	if err != nil {
		t.Fatalf("GetValidEdgesFrom inside: %v", err)
	}
	if len(from) != 1 {
		t.Fatalf("expected 1 valid edge inside window, got %d", len(from))
	}

	to, err := s.GetValidEdgesTo(ctx, "b", base.Add(2*time.Hour))
	if err != nil {
		t.Fatalf("GetValidEdgesTo inside: %v", err)
	}
	if len(to) != 1 || to[0].ID != "e1" {
		t.Errorf("expected inbound edge e1 inside window, got %v", to)
	}

	// At/after invalid_at: not returned (invalid_at is exclusive upper bound).
	to, err = s.GetValidEdgesTo(ctx, "b", base.Add(3*time.Hour))
	if err != nil {
		t.Fatalf("GetValidEdgesTo after: %v", err)
	}
	if len(to) != 0 {
		t.Errorf("expected no valid edges at invalid_at, got %d", len(to))
	}
}
