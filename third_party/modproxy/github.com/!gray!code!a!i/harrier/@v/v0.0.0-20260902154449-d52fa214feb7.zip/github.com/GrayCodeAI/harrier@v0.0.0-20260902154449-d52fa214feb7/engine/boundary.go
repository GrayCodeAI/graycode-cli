package engine

import (
	"context"
	"strings"

	"github.com/GrayCodeAI/harrier/embeddings"
)

// BoundaryConfig tunes semantic boundary (topic-shift) detection.
//
// A boundary is flagged when the similarity between incoming content and the
// running centroid of recent content drops below SimThreshold. The centroid is
// an exponential moving average over the last WindowSize observations, which
// keeps the detector responsive to gradual drift while smoothing out single
// noisy messages.
type BoundaryConfig struct {
	// SimThreshold is the similarity floor below which a topic shift is flagged.
	// For embedding-based detection this is cosine similarity in [-1, 1]; for the
	// lexical fallback it is Jaccard similarity in [0, 1]. Range: [0, 1].
	SimThreshold float64 `json:"sim_threshold"`
	// WindowSize is the number of recent observations the centroid tracks.
	WindowSize int `json:"window_size"`
	// Alpha is the EMA weight for incorporating a new observation into the
	// centroid (0 = ignore new, 1 = replace). Range: (0, 1].
	Alpha float64 `json:"alpha"`
}

// DefaultBoundaryConfig returns conservative defaults tuned to avoid flagging
// normal same-topic variation as a boundary.
func DefaultBoundaryConfig() BoundaryConfig {
	return BoundaryConfig{
		SimThreshold: 0.45,
		WindowSize:   5,
		Alpha:        0.4,
	}
}

// BoundaryDetector detects semantic boundaries between two pieces of content.
// It uses an embeddings.Provider when available and falls back to a lexical
// (Jaccard) comparison otherwise. The detector itself is stateless; use Tracker
// for rolling, stateful detection over a stream.
type BoundaryDetector struct {
	provider embeddings.Provider // optional; nil → lexical fallback
	cfg      BoundaryConfig
}

// NewBoundaryDetector creates a detector. provider may be nil, in which case the
// lexical Jaccard fallback is used for all comparisons.
func NewBoundaryDetector(provider embeddings.Provider, cfg BoundaryConfig) *BoundaryDetector {
	if cfg.WindowSize <= 0 {
		cfg.WindowSize = DefaultBoundaryConfig().WindowSize
	}
	if cfg.Alpha <= 0 || cfg.Alpha > 1 {
		cfg.Alpha = DefaultBoundaryConfig().Alpha
	}
	return &BoundaryDetector{provider: provider, cfg: cfg}
}

// DetectBoundary reports whether next represents a topic shift relative to prev.
// Empty inputs are never treated as boundaries (insufficient signal).
func (d *BoundaryDetector) DetectBoundary(prev, next string) bool {
	if strings.TrimSpace(prev) == "" || strings.TrimSpace(next) == "" {
		return false
	}
	sim := d.Similarity(prev, next)
	return sim < d.cfg.SimThreshold
}

// Similarity returns the similarity between two pieces of content in [0, 1].
// It uses the embedding provider when present (cosine, clamped to [0, 1]) and
// falls back to Jaccard token overlap otherwise.
func (d *BoundaryDetector) Similarity(a, b string) float64 {
	if d.provider != nil {
		if va, err := d.provider.Embed(context.Background(), a); err == nil {
			if vb, err := d.provider.Embed(context.Background(), b); err == nil {
				c := float64(embeddings.Cosine(va, vb))
				if c < 0 {
					c = 0
				}
				return c
			}
		}
		// Provider failed — fall through to lexical comparison.
	}
	return jaccardSimilarity(a, b)
}

// Tracker is a stateful, rolling boundary detector for streaming content. It
// maintains an exponential moving-average centroid of recent observations and
// flags an observation as a boundary when it diverges from that centroid.
//
// Tracker is NOT safe for concurrent use; guard with a mutex if shared.
type Tracker struct {
	det *BoundaryDetector

	// Embedding-based state.
	centroid []float32
	// Lexical fallback state: token-frequency centroid over the window.
	tokenWeights map[string]float64
	count        int
}

// NewTracker creates a stateful Tracker backed by the given detector.
func NewTracker(det *BoundaryDetector) *Tracker {
	return &Tracker{det: det, tokenWeights: map[string]float64{}}
}

// Observe ingests the next piece of content and reports whether it marks a
// semantic boundary relative to recent content. The very first non-empty
// observation establishes the baseline and is never a boundary.
func (t *Tracker) Observe(content string) (isBoundary bool) {
	if strings.TrimSpace(content) == "" {
		return false
	}
	if t.det.provider != nil {
		if vec, err := t.det.provider.Embed(context.Background(), content); err == nil {
			return t.observeEmbedding(vec)
		}
		// Provider failed for this observation — fall back to lexical.
	}
	return t.observeLexical(content)
}

func (t *Tracker) observeEmbedding(vec []float32) bool {
	defer func() { t.count++ }()
	if t.centroid == nil {
		t.centroid = append([]float32(nil), vec...)
		return false
	}
	sim := float64(embeddings.Cosine(t.centroid, vec))
	boundary := sim < t.det.cfg.SimThreshold
	// Update EMA centroid. On a boundary, reset toward the new topic so the
	// detector does not keep re-flagging within the new topic.
	if boundary {
		t.centroid = append([]float32(nil), vec...)
	} else {
		a := t.det.cfg.Alpha
		for i := range t.centroid {
			t.centroid[i] = float32((1-a)*float64(t.centroid[i]) + a*float64(vec[i]))
		}
	}
	return boundary
}

func (t *Tracker) observeLexical(content string) bool {
	defer func() { t.count++ }()
	toks := tokenSet(content)
	if len(t.tokenWeights) == 0 || t.count == 0 {
		for tok := range toks {
			t.tokenWeights[tok] = 1
		}
		return false
	}
	a := t.det.cfg.Alpha
	sim := weightedJaccard(t.tokenWeights, toks, a)
	boundary := sim < t.det.cfg.SimThreshold
	if boundary {
		// Reset centroid to the new topic's tokens.
		t.tokenWeights = map[string]float64{}
		for tok := range toks {
			t.tokenWeights[tok] = 1
		}
	} else {
		// Decay existing weights, reinforce observed tokens (EMA over the window).
		for k := range t.tokenWeights {
			t.tokenWeights[k] *= (1 - a)
		}
		for tok := range toks {
			t.tokenWeights[tok] += a
		}
		t.pruneWeights()
	}
	return boundary
}

// pruneWeights drops near-zero weights so the centroid stays bounded to roughly
// the active vocabulary of the window.
func (t *Tracker) pruneWeights() {
	for k, v := range t.tokenWeights {
		if v < 0.05 {
			delete(t.tokenWeights, k)
		}
	}
}

// Reset clears all rolling state, returning the Tracker to its initial baseline.
func (t *Tracker) Reset() {
	t.centroid = nil
	t.tokenWeights = map[string]float64{}
	t.count = 0
}

// --- lexical helpers ---

// tokenSet returns the set of lowercased word tokens in s, ignoring very short
// tokens (likely stopwords/punctuation noise).
func tokenSet(s string) map[string]struct{} {
	out := map[string]struct{}{}
	for _, f := range strings.FieldsFunc(strings.ToLower(s), func(r rune) bool {
		return (r < 'a' || r > 'z') && (r < '0' || r > '9')
	}) {
		if len(f) < 3 {
			continue
		}
		out[f] = struct{}{}
	}
	return out
}

// jaccardSimilarity returns |A∩B| / |A∪B| over token sets, in [0, 1].
func jaccardSimilarity(a, b string) float64 {
	sa, sb := tokenSet(a), tokenSet(b)
	if len(sa) == 0 && len(sb) == 0 {
		return 1
	}
	if len(sa) == 0 || len(sb) == 0 {
		return 0
	}
	inter := 0
	for tok := range sa {
		if _, ok := sb[tok]; ok {
			inter++
		}
	}
	union := len(sa) + len(sb) - inter
	if union == 0 {
		return 0
	}
	return float64(inter) / float64(union)
}

// weightedJaccard compares a weighted token centroid against an observed token
// set, returning a soft overlap ratio in [0, 1]. It is the lexical analogue of
// cosine-to-centroid: the numerator is the centroid weight covered by observed
// tokens, normalized by the union of centroid mass and observed tokens.
//
// Observed tokens absent from the centroid are added to the union mass with
// weight newWeight (the EMA alpha) rather than 1, mirroring how they will be
// folded into the centroid. This keeps a single message introducing fresh but
// on-topic vocabulary from collapsing the score below the boundary threshold.
func weightedJaccard(centroid map[string]float64, observed map[string]struct{}, newWeight float64) float64 {
	if len(centroid) == 0 && len(observed) == 0 {
		return 1
	}
	if len(centroid) == 0 || len(observed) == 0 {
		return 0
	}
	if newWeight <= 0 || newWeight > 1 {
		newWeight = 1
	}
	var inter, total float64
	for tok, w := range centroid {
		total += w
		if _, ok := observed[tok]; ok {
			inter += w
		}
	}
	for tok := range observed {
		if _, ok := centroid[tok]; !ok {
			total += newWeight
		}
	}
	if total == 0 {
		return 0
	}
	return inter / total
}
