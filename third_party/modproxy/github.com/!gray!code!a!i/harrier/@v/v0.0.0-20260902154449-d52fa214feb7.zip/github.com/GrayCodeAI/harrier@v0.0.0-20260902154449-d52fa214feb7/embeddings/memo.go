package embeddings

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"strconv"
	"sync"
)

// EmbeddingMemo caches embeddings to skip re-embedding unchanged content.
//
// The cache key is namespace + mode + sha256(content), NOT content alone. The
// namespace identifies the embedding model (provider Name()), so swapping models
// or model versions no longer serves stale, incomparable vectors from the old
// model. The mode dimension keeps document- and query-mode vectors separate for
// asymmetric retrieval models (e.g. Cohere v3 search_document vs search_query).
type EmbeddingMemo struct {
	mu        sync.RWMutex
	namespace string               // model identity, prefixed into every key
	cache     map[string][]float32 // namespace|mode|sha256(content) -> embedding
	order     []string             // insertion order for LRU eviction
	max       int
}

// NewEmbeddingMemo creates a memo cache with the given max entry count. The
// namespace is empty; prefer NewEmbeddingMemoNS so the cache is keyed by model
// identity. Pass "" only for tests or single-model callers that never switch.
func NewEmbeddingMemo(maxEntries int) *EmbeddingMemo {
	return NewEmbeddingMemoNS("", maxEntries)
}

// NewEmbeddingMemoNS creates a memo cache namespaced by model identity, so that
// changing the embedding model invalidates the cache instead of serving stale
// vectors from the previous model.
func NewEmbeddingMemoNS(namespace string, maxEntries int) *EmbeddingMemo {
	if maxEntries <= 0 {
		maxEntries = 1024
	}
	return &EmbeddingMemo{
		namespace: namespace,
		cache:     make(map[string][]float32, maxEntries),
		order:     make([]string, 0, maxEntries),
		max:       maxEntries,
	}
}

// Get returns a cached embedding for the content in ModeDocument, if present.
func (m *EmbeddingMemo) Get(content string) ([]float32, bool) {
	return m.GetMode(content, ModeDocument)
}

// GetMode returns a cached embedding for the content under the given mode.
func (m *EmbeddingMemo) GetMode(content string, mode EmbedMode) ([]float32, bool) {
	key := m.key(content, mode)
	m.mu.Lock()
	vec, ok := m.cache[key]
	if ok {
		m.promote(key)
	}
	m.mu.Unlock()
	return vec, ok
}

// Put stores an embedding for the given content in ModeDocument.
func (m *EmbeddingMemo) Put(content string, embedding []float32) {
	m.PutMode(content, ModeDocument, embedding)
}

// PutMode stores an embedding for the given content under the given mode,
// evicting the oldest entry if at capacity.
func (m *EmbeddingMemo) PutMode(content string, mode EmbedMode, embedding []float32) {
	key := m.key(content, mode)
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, exists := m.cache[key]; exists {
		m.cache[key] = embedding
		m.promote(key)
		return
	}
	for len(m.order) >= m.max {
		oldest := m.order[0]
		m.order = m.order[1:]
		delete(m.cache, oldest)
	}
	m.cache[key] = embedding
	m.order = append(m.order, key)
}

// Len returns the number of cached entries.
func (m *EmbeddingMemo) Len() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.cache)
}

func (m *EmbeddingMemo) promote(key string) {
	for i, k := range m.order {
		if k == key {
			m.order = append(m.order[:i], m.order[i+1:]...)
			m.order = append(m.order, key)
			return
		}
	}
}

// key builds the cache key from model namespace, embedding mode, and content
// hash, so that a model change or a mode change never collides with stale state.
func (m *EmbeddingMemo) key(content string, mode EmbedMode) string {
	return m.namespace + "|" + strconv.Itoa(int(mode)) + "|" + contentHash(content)
}

func contentHash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

// MemoizedProvider wraps a Provider with content-addressed memoization.
type MemoizedProvider struct {
	inner Provider
	memo  *EmbeddingMemo
}

// NewMemoizedProvider wraps an existing Provider with a memo cache. The cache is
// namespaced by the inner provider's Name() (which encodes the model), so a model
// swap can never serve stale vectors from the previous model.
func NewMemoizedProvider(inner Provider, maxEntries int) *MemoizedProvider {
	return &MemoizedProvider{
		inner: inner,
		memo:  NewEmbeddingMemoNS(inner.Name(), maxEntries),
	}
}

func (p *MemoizedProvider) Name() string { return p.inner.Name() }
func (p *MemoizedProvider) Dims() int    { return p.inner.Dims() }

func (p *MemoizedProvider) Embed(ctx context.Context, text string) ([]float32, error) {
	if vec, ok := p.memo.Get(text); ok {
		return vec, nil
	}
	vec, err := p.inner.Embed(ctx, text)
	if err != nil {
		return nil, err
	}
	p.memo.Put(text, vec)
	return vec, nil
}

func (p *MemoizedProvider) EmbedBatch(ctx context.Context, texts []string) ([][]float32, error) {
	results := make([][]float32, len(texts))
	var uncached []string
	var uncachedIdx []int
	for i, t := range texts {
		if vec, ok := p.memo.Get(t); ok {
			results[i] = vec
		} else {
			uncached = append(uncached, t)
			uncachedIdx = append(uncachedIdx, i)
		}
	}
	if len(uncached) == 0 {
		return results, nil
	}
	vecs, err := p.inner.EmbedBatch(ctx, uncached)
	if err != nil {
		return nil, err
	}
	for j, vec := range vecs {
		idx := uncachedIdx[j]
		results[idx] = vec
		p.memo.Put(texts[idx], vec)
	}
	return results, nil
}

func (p *MemoizedProvider) EmbedWithMode(ctx context.Context, text string, mode EmbedMode) ([]float32, error) {
	// Memoized per-mode: the key includes the mode, so document- and query-mode
	// vectors for the same text never collide.
	if vec, ok := p.memo.GetMode(text, mode); ok {
		return vec, nil
	}
	vec, err := p.inner.EmbedWithMode(ctx, text, mode)
	if err != nil {
		return nil, err
	}
	p.memo.PutMode(text, mode, vec)
	return vec, nil
}

// Memo returns the underlying cache for inspection/testing.
func (p *MemoizedProvider) Memo() *EmbeddingMemo { return p.memo }
