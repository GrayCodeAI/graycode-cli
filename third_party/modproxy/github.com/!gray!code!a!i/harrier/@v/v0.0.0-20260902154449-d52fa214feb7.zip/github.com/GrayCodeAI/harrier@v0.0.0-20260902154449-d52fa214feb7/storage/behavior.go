package storage

import (
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"
)

// Behavior represents a tracked user pattern or habit.
type Behavior struct {
	ID         string
	Pattern    string    // what the user tends to do
	Frequency  int       // how many times observed
	LastSeen   time.Time // last time this behavior occurred
	Context    string    // when/where this happens
	Confidence float64   // how confident we are this is a real pattern
}

// BehaviorTracker tracks user behaviors and predicts future actions.
type BehaviorTracker struct {
	behaviors []Behavior
	mu        sync.RWMutex
}

// NewBehaviorTracker creates a new BehaviorTracker.
func NewBehaviorTracker() *BehaviorTracker {
	return &BehaviorTracker{
		behaviors: make([]Behavior, 0),
	}
}

// GetBehaviors returns a copy of all tracked behaviors.
func (bt *BehaviorTracker) GetBehaviors() []Behavior {
	bt.mu.RLock()
	defer bt.mu.RUnlock()
	out := make([]Behavior, len(bt.behaviors))
	copy(out, bt.behaviors)
	return out
}

// Track records a user action within a given context. If a matching pattern
// already exists for the same context, its frequency is incremented and
// LastSeen is updated. Otherwise a new Behavior entry is created.
func (bt *BehaviorTracker) Track(action, context string) {
	bt.mu.Lock()
	defer bt.mu.Unlock()

	now := time.Now()

	for i := range bt.behaviors {
		if bt.behaviors[i].Pattern == action && bt.behaviors[i].Context == context {
			bt.behaviors[i].Frequency++
			bt.behaviors[i].LastSeen = now
			bt.behaviors[i].Confidence = computeConfidence(bt.behaviors[i].Frequency, bt.behaviors[i].LastSeen)
			return
		}
	}

	b := Behavior{
		ID:         fmt.Sprintf("beh_%d", len(bt.behaviors)+1),
		Pattern:    action,
		Frequency:  1,
		LastSeen:   now,
		Context:    context,
		Confidence: computeConfidence(1, now),
	}
	bt.behaviors = append(bt.behaviors, b)
}

// Predict returns behaviors that match the given context, ranked by a score
// combining frequency and recency.
func (bt *BehaviorTracker) Predict(context string) []Behavior {
	bt.mu.RLock()
	defer bt.mu.RUnlock()

	var matches []Behavior
	for _, b := range bt.behaviors {
		if b.Context == context {
			matches = append(matches, b)
		}
	}

	sort.Slice(matches, func(i, j int) bool {
		return score(matches[i]) > score(matches[j])
	})

	return matches
}

// GetTopPatterns returns the most frequent behaviors across all contexts,
// limited to the given count.
func (bt *BehaviorTracker) GetTopPatterns(limit int) []Behavior {
	bt.mu.RLock()
	defer bt.mu.RUnlock()

	sorted := make([]Behavior, len(bt.behaviors))
	copy(sorted, bt.behaviors)

	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].Frequency > sorted[j].Frequency
	})

	if limit > len(sorted) {
		limit = len(sorted)
	}
	return sorted[:limit]
}

// FormatPredictions formats a list of predicted behaviors into a readable string.
func FormatPredictions(predictions []Behavior) string {
	if len(predictions) == 0 {
		return "No predictions available."
	}

	var sb strings.Builder
	sb.WriteString("Predicted behaviors:\n")
	for i, p := range predictions {
		fmt.Fprintf(&sb, "  %d. %s (freq=%d, confidence=%.2f, context=%q)\n",
			i+1, p.Pattern, p.Frequency, p.Confidence, p.Context)
	}
	return sb.String()
}

// score combines frequency and recency into a single ranking value.
func score(b Behavior) float64 {
	hoursSinceSeen := time.Since(b.LastSeen).Hours()
	recency := 1.0 / (1.0 + hoursSinceSeen)
	return float64(b.Frequency)*0.7 + recency*0.3
}

// computeConfidence derives a confidence value from frequency and recency.
func computeConfidence(freq int, lastSeen time.Time) float64 {
	hoursSince := time.Since(lastSeen).Hours()
	recency := 1.0 / (1.0 + hoursSince)
	// Confidence grows with frequency but saturates around 1.0.
	freqFactor := 1.0 - 1.0/(1.0+float64(freq)*0.2)
	return freqFactor*0.7 + recency*0.3
}
