package engine

import (
	"context"
	"testing"
)

// TestForget_PreservesConcurrentContentUpdate pins the CAS archival contract:
// Forget must archive (confidence=0) without writing back a stale full-node
// copy, so a content update that lands between Forget's read and write is
// never clobbered.
func TestForget_PreservesConcurrentContentUpdate(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{Type: "decision", Content: "original content", Project: "p1"})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// Simulate an async writer updating content after Forget's read but
	// before its write (the ingestion path does not take e.mu).
	if err := eng.store.UpdateNodeContent(context.Background(), node.ID, "updated content"); err != nil {
		t.Fatalf("UpdateNodeContent failed: %v", err)
	}

	if err := eng.Forget(context.Background(), node.ID); err != nil {
		t.Fatalf("Forget failed: %v", err)
	}

	got, err := eng.store.GetNode(context.Background(), node.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	if got.Confidence != 0 {
		t.Errorf("expected confidence 0 after forget, got %f", got.Confidence)
	}
	if got.Content != "updated content" {
		t.Errorf("forget clobbered concurrent content update: got %q, want %q", got.Content, "updated content")
	}
}

// TestForget_TwiceIsNoOp ensures re-archiving an archived node is not an error
// and does not touch the node.
func TestForget_TwiceIsNoOp(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{Type: "decision", Content: "archive me", Project: "p1"})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	if err := eng.Forget(context.Background(), node.ID); err != nil {
		t.Fatalf("first Forget failed: %v", err)
	}
	if err := eng.Forget(context.Background(), node.ID); err != nil {
		t.Fatalf("second Forget must be a no-op, got: %v", err)
	}

	got, err := eng.store.GetNode(context.Background(), node.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	if got.Confidence != 0 {
		t.Errorf("expected confidence 0 after double forget, got %f", got.Confidence)
	}
}
