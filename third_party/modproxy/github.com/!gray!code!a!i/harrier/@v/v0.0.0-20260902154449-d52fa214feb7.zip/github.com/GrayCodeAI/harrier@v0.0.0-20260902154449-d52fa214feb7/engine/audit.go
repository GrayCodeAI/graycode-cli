package engine

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// AuditLog records all memory operations for traceability.
// Stores: who did what, when, on which node.
// Persists to .harrier/audit.jsonl (append-only).
type AuditLog struct {
	mu      sync.Mutex
	file    *os.File
	path    string
	entries int
}

// AuditEntry is a single audit record.
type AuditEntry struct {
	Timestamp time.Time `json:"ts"`
	Operation string    `json:"op"` // remember, recall, forget, link, feedback
	NodeID    string    `json:"node_id,omitempty"`
	NodeType  string    `json:"node_type,omitempty"`
	Agent     string    `json:"agent,omitempty"`
	Details   string    `json:"details,omitempty"`
}

// NewAuditLog creates or opens the audit log file.
func NewAuditLog(harrierDir string) (*AuditLog, error) {
	path := filepath.Join(harrierDir, "audit.jsonl")
	// The audit log records node IDs and operation details from memory
	// content, so it belongs to the same class of sensitive data as the
	// sqlite store — keep the directory and file owner-only.
	_ = os.MkdirAll(harrierDir, 0o700)

	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return nil, fmt.Errorf("open audit log: %w", err)
	}

	return &AuditLog{file: f, path: path}, nil
}

// Log records an operation.
func (al *AuditLog) Log(op, nodeID, nodeType, agent, details string) {
	if al == nil || al.file == nil {
		return
	}
	al.mu.Lock()
	defer al.mu.Unlock()

	entry := AuditEntry{
		Timestamp: time.Now(),
		Operation: op,
		NodeID:    nodeID,
		NodeType:  nodeType,
		Agent:     agent,
		Details:   details,
	}
	data, err := json.Marshal(entry)
	if err != nil {
		return
	}
	_, _ = al.file.Write(data)
	_, _ = al.file.WriteString("\n")
	al.entries++
}

// Count returns number of entries logged this session.
func (al *AuditLog) Count() int {
	if al == nil {
		return 0
	}
	al.mu.Lock()
	defer al.mu.Unlock()
	return al.entries
}

// Close flushes and closes the audit log.
func (al *AuditLog) Close() {
	if al == nil || al.file == nil {
		return
	}
	_ = al.file.Sync()
	_ = al.file.Close()
}

// MemoryExpiry handles automatic deletion of memories past their TTL.
type MemoryExpiry struct {
	defaultTTL time.Duration
}

// NewMemoryExpiry creates an expiry manager.
func NewMemoryExpiry(defaultTTL time.Duration) *MemoryExpiry {
	if defaultTTL <= 0 {
		defaultTTL = 90 * 24 * time.Hour // 90 days default
	}
	return &MemoryExpiry{defaultTTL: defaultTTL}
}

// IsExpired checks if a node has exceeded its TTL.
func (me *MemoryExpiry) IsExpired(createdAt time.Time, pinned bool) bool {
	if pinned {
		return false // pinned never expire
	}
	if createdAt.IsZero() {
		return false
	}
	return time.Since(createdAt) > me.defaultTTL
}
