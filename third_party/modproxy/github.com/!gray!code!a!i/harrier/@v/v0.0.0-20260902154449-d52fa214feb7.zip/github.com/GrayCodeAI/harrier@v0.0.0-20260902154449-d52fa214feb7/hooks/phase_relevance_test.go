package hooks

import (
	"testing"
)

func TestPhaseAwareRelevance_LocalizeBoostsReads(t *testing.T) {
	baseRead := ScoreRelevance("Read", "auth.go", "func Validate()", "")
	phaseRead := PhaseAwareRelevance(PipelinePhaseLocalize, "Read", "auth.go", "func Validate()", "")
	if phaseRead <= baseRead {
		t.Errorf("localize phase should boost Read relevance: base=%f phase=%f", baseRead, phaseRead)
	}
}

func TestPhaseAwareRelevance_RepairBoostsWrites(t *testing.T) {
	phaseWrite := PhaseAwareRelevance(PipelinePhaseRepair, "Write", "auth.go", "fixed code", "")
	if phaseWrite < 0.8 {
		t.Errorf("repair phase should score Write >= 0.8, got %f", phaseWrite)
	}
}

func TestPhaseAwareRelevance_ValidateBoostsBash(t *testing.T) {
	phaseBash := PhaseAwareRelevance(PipelinePhaseValidate, "Bash", "go test ./...", "PASS ok pkg", "")
	if phaseBash < 0.7 {
		t.Errorf("validate phase should score Bash >= 0.7, got %f", phaseBash)
	}
}

func TestPhaseAwareRelevance_ReviewBoostsDecisions(t *testing.T) {
	phaseReview := PhaseAwareRelevance(
		PipelinePhaseReview,
		"Read",
		"review context",
		"we decided to replace the legacy auth handler with the new session middleware instead of patching it",
		"",
	)
	if phaseReview < 0.9 {
		t.Errorf("review phase decision output should score >= 0.9, got %f", phaseReview)
	}
}

func TestPhaseAwareRelevance_ScoreWithinBounds(t *testing.T) {
	phases := []PipelinePhase{
		PipelinePhaseLocalize, PipelinePhaseRepair,
		PipelinePhaseValidate, PipelinePhaseReview, PipelinePhaseUnknown,
	}
	tools := []string{"Read", "Write", "Bash", "Grep", "Edit"}
	for _, phase := range phases {
		for _, tool := range tools {
			score := PhaseAwareRelevance(phase, tool, "input", "output", "")
			if score < 0.0 || score > 1.0 {
				t.Errorf("PhaseAwareRelevance(%q, %q) = %f, want in [0, 1]", phase, tool, score)
			}
		}
	}
}

func TestPhaseAwareShouldCapture_HighScore(t *testing.T) {
	if !PhaseAwareShouldCapture(PipelinePhaseRepair, "Write", "auth.go", "updated handler", "") {
		t.Error("high-relevance Write in repair phase should be captured")
	}
}

func TestPhaseAwareShouldCapture_LowScore(t *testing.T) {
	// Short bash navigation in unknown phase should not be captured
	if PhaseAwareShouldCapture(PipelinePhaseUnknown, "Bash", "ls", "file.go", "") {
		t.Error("low-relevance navigation in unknown phase should not be captured")
	}
}
