package cognitive

import (
	"sync"
	"time"
)

type LabileMemory struct {
	ChunkID      string    `json:"chunk_id"`
	RecalledAt   time.Time `json:"recalled_at"`
	Strengthened bool      `json:"strengthened"`
	Contradicted bool      `json:"contradicted"`
}

type ReconsolidationConfig struct {
	Enabled       bool          `json:"enabled"`
	LabileWindow  time.Duration `json:"labile_window"`
	StrengthBonus float64       `json:"strength_bonus"`
}

func DefaultReconsolidationConfig() ReconsolidationConfig {
	return ReconsolidationConfig{
		Enabled:       true,
		LabileWindow:  30 * time.Minute,
		StrengthBonus: 0.2,
	}
}

type ReconsolidationEngine struct {
	mu     sync.RWMutex
	labile map[string]*LabileMemory
	config ReconsolidationConfig
}

func NewReconsolidationEngine(config ReconsolidationConfig) *ReconsolidationEngine {
	return &ReconsolidationEngine{
		labile: make(map[string]*LabileMemory),
		config: config,
	}
}

func (e *ReconsolidationEngine) OnRecall(chunkID string) {
	if !e.config.Enabled {
		return
	}
	e.mu.Lock()
	defer e.mu.Unlock()

	e.labile[chunkID] = &LabileMemory{
		ChunkID:    chunkID,
		RecalledAt: time.Now(),
	}
}

func (e *ReconsolidationEngine) IsLabile(chunkID string) bool {
	e.mu.RLock()
	defer e.mu.RUnlock()

	mem, ok := e.labile[chunkID]
	if !ok {
		return false
	}
	return time.Since(mem.RecalledAt) <= e.config.LabileWindow
}

func (e *ReconsolidationEngine) Strengthen(chunkID string) float64 {
	e.mu.Lock()
	defer e.mu.Unlock()

	mem, ok := e.labile[chunkID]
	if !ok || time.Since(mem.RecalledAt) > e.config.LabileWindow {
		return 0
	}
	mem.Strengthened = true
	return e.config.StrengthBonus
}

func (e *ReconsolidationEngine) FlagContradiction(chunkID string) {
	e.mu.Lock()
	defer e.mu.Unlock()

	if mem, ok := e.labile[chunkID]; ok {
		mem.Contradicted = true
	}
}

func (e *ReconsolidationEngine) GetContradicted() []string {
	e.mu.RLock()
	defer e.mu.RUnlock()

	var ids []string
	for _, mem := range e.labile {
		if mem.Contradicted && time.Since(mem.RecalledAt) <= e.config.LabileWindow {
			ids = append(ids, mem.ChunkID)
		}
	}
	return ids
}

func (e *ReconsolidationEngine) Cleanup() int {
	e.mu.Lock()
	defer e.mu.Unlock()

	cleaned := 0
	for id, mem := range e.labile {
		if time.Since(mem.RecalledAt) > e.config.LabileWindow*2 {
			delete(e.labile, id)
			cleaned++
		}
	}
	return cleaned
}
