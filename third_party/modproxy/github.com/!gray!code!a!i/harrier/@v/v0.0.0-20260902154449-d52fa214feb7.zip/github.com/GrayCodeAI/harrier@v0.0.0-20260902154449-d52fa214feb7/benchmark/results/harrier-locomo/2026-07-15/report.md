# Harrier LoCoMo-10 External Baseline

## Metadata

- Suite: `harrier-locomo`
- Date: `2026-07-15`
- Dataset: LoCoMo-10 (`snap-research/locomo`), 10 conversations, 1,540 non-adversarial QA pairs evaluated
- Model: none
- Provider: none
- Commit: current workspace snapshot
- Command: `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/locomobench --cache /tmp/locomo10_cache.json'`

## Headline Metrics (aggregate across all 10 samples)

- R@1: `3.1%`
- R@3: `8.6%`
- R@5: `13.2%`
- R@10: `19.1%`
- MRR: `0.072`
- Avg tokens/query: `293`
- Duration: `3.60s` (1,540 questions, 10 isolated engines)

## Per-sample range

R@1 ranged `0.0%`–`4.6%` and R@10 ranged `8.6%`–`27.0%` across the 10 conversations (see `result.txt` for the full per-sample breakdown) — no single conversation dominates the aggregate.

## Notes

- This is the first committed run against a **standard external corpus**
  rather than harrier's first-party self-seeded QA set — see `notes.md` for
  why the numbers are structurally lower than `harrier-longmem-core`'s and
  what they do and don't measure.
- The harness (`internal/bench.Run`) is reused completely unmodified; only
  a new data adapter (`benchmark/locomo/`) was added to convert LoCoMo-10's
  conversation/QA format into `bench.QA` + seed inputs.
- The report is generated from 10 independent local SQLite-backed memory
  graphs (one per LoCoMo conversation) with no external model dependency —
  the dataset itself is fetched from `snap-research/locomo` on GitHub, but
  no LLM/API calls are made during the benchmark run.

## Comparison Summary

- Previous baseline: none committed for this suite (first `harrier-locomo` run)
- Change since baseline: initial published baseline
- Interpretation: establishes harrier's first honest external-corpus retrieval
  number. The gap to `harrier-longmem-core`'s numbers is expected given the
  harness's substring-match scoring (see `notes.md` caveat 1) and is not
  read as a quality regression — it's a materially harder, more realistic
  measurement than the self-seeded set.
