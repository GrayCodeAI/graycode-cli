package engine

import (
	"context"
	"sort"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// TierLoader implements three-tier memory loading (hot/warm/cold) for
// performance-optimized context window assembly.
//
// Hot tier (tier 1): Always loaded — pinned nodes, recently accessed,
// high-confidence memories. Fits in ~500 tokens.
//
// Warm tier (tier 2): Loaded on demand — moderately accessed memories,
// active tasks, recent decisions. Loaded when a session starts.
//
// Cold tier (tier 3): Loaded only on explicit query — older memories,
// low-confidence nodes, archived items. Loaded via Recall() when needed.
//
// This approach is inspired by Letta's memory hierarchy and MemGPT's
// tiered context management, adapted for harrier's graph-based architecture.
type TierLoader struct {
	store storage.Storage

	// Hot tier cache (in-memory, always available)
	hotMu     sync.RWMutex
	hotNodes  []*storage.Node
	hotExpiry time.Time
	hotTTL    time.Duration

	// Warm tier cache (loaded on session start)
	warmMu     sync.RWMutex
	warmNodes  []*storage.Node
	warmExpiry time.Time
	warmTTL    time.Duration

	// Cold tier is never cached — always hits the database
}

// NewTierLoader creates a tier loader with default TTLs.
func NewTierLoader(store storage.Storage) *TierLoader {
	return &TierLoader{
		store:   store,
		hotTTL:  30 * time.Second, // hot tier refreshes frequently
		warmTTL: 5 * time.Minute,  // warm tier refreshes less often
	}
}

// TierResult holds the combined result of loading multiple tiers.
type TierResult struct {
	Hot  []*storage.Node `json:"hot"`
	Warm []*storage.Node `json:"warm"`
	Cold []*storage.Node `json:"cold"`
}

// LoadHot returns hot-tier nodes (pinned + high-confidence + recently accessed).
// Cached in memory with a short TTL for performance.
func (tl *TierLoader) LoadHot(ctx context.Context, project string) ([]*storage.Node, error) {
	tl.hotMu.RLock()
	if tl.hotNodes != nil && time.Now().Before(tl.hotExpiry) {
		nodes := tl.hotNodes
		tl.hotMu.RUnlock()
		return nodes, nil
	}
	tl.hotMu.RUnlock()

	// Load pinned nodes
	pinTrue := true
	pinned, err := tl.store.ListNodes(ctx, storage.NodeFilter{
		Project: project, Pinned: &pinTrue,
	})
	if err != nil {
		return nil, err
	}

	// Load tier 1 (hot) nodes with high confidence
	hot, err := tl.store.ListNodes(ctx, storage.NodeFilter{
		Tier: 1, Project: project, MinConfidence: 0.5,
	})
	if err != nil {
		return nil, err
	}

	// Merge pinned + hot, deduplicating
	seen := make(map[string]bool)
	var result []*storage.Node
	for _, n := range pinned {
		if !seen[n.ID] {
			seen[n.ID] = true
			result = append(result, n)
		}
	}
	for _, n := range hot {
		if !seen[n.ID] {
			seen[n.ID] = true
			result = append(result, n)
		}
	}

	// Sort by confidence * recency
	sort.Slice(result, func(i, j int) bool {
		return tierScore(result[i]) > tierScore(result[j])
	})

	tl.hotMu.Lock()
	tl.hotNodes = result
	tl.hotExpiry = time.Now().Add(tl.hotTTL)
	tl.hotMu.Unlock()

	return result, nil
}

// LoadWarm returns warm-tier nodes (active tasks, recent decisions, moderate
// confidence). Loaded on session start with a medium TTL.
func (tl *TierLoader) LoadWarm(ctx context.Context, project string) ([]*storage.Node, error) {
	tl.warmMu.RLock()
	if tl.warmNodes != nil && time.Now().Before(tl.warmExpiry) {
		nodes := tl.warmNodes
		tl.warmMu.RUnlock()
		return nodes, nil
	}
	tl.warmMu.RUnlock()

	// Load tier 2 nodes
	warm, err := tl.store.ListNodes(ctx, storage.NodeFilter{
		Tier: 2, Project: project, MinConfidence: 0.2,
	})
	if err != nil {
		return nil, err
	}

	// Also include active tasks regardless of tier
	tasks, err := tl.store.ListNodes(ctx, storage.NodeFilter{
		Type: "task", Project: project, MinConfidence: 0.1,
	})
	if err != nil {
		return nil, err
	}

	seen := make(map[string]bool)
	var result []*storage.Node
	for _, n := range warm {
		if !seen[n.ID] {
			seen[n.ID] = true
			result = append(result, n)
		}
	}
	for _, n := range tasks {
		if !seen[n.ID] {
			seen[n.ID] = true
			result = append(result, n)
		}
	}

	sort.Slice(result, func(i, j int) bool {
		return tierScore(result[i]) > tierScore(result[j])
	})

	tl.warmMu.Lock()
	tl.warmNodes = result
	tl.warmExpiry = time.Now().Add(tl.warmTTL)
	tl.warmMu.Unlock()

	return result, nil
}

// LoadCold returns cold-tier nodes (low confidence, old, tier 3).
// Always hits the database — no caching.
func (tl *TierLoader) LoadCold(ctx context.Context, project string, limit int) ([]*storage.Node, error) {
	if limit <= 0 {
		limit = 50
	}
	nodes, err := tl.store.ListNodes(ctx, storage.NodeFilter{
		Project: project, Limit: limit,
	})
	if err != nil {
		return nil, err
	}

	// Filter to cold-tier characteristics: tier 3, low confidence, or old
	var cold []*storage.Node
	for _, n := range nodes {
		if n.Tier >= 3 || n.Confidence < 0.3 {
			cold = append(cold, n)
		}
	}

	sort.Slice(cold, func(i, j int) bool {
		return tierScore(cold[i]) > tierScore(cold[j])
	})

	if len(cold) > limit {
		cold = cold[:limit]
	}
	return cold, nil
}

// LoadAll loads all three tiers and returns them combined.
func (tl *TierLoader) LoadAll(ctx context.Context, project string) (*TierResult, error) {
	hot, err := tl.LoadHot(ctx, project)
	if err != nil {
		return nil, err
	}
	warm, err := tl.LoadWarm(ctx, project)
	if err != nil {
		return nil, err
	}
	cold, err := tl.LoadCold(ctx, project, 50)
	if err != nil {
		return nil, err
	}
	return &TierResult{Hot: hot, Warm: warm, Cold: cold}, nil
}

// InvalidateHot forces hot-tier cache refresh on next access.
func (tl *TierLoader) InvalidateHot() {
	tl.hotMu.Lock()
	tl.hotNodes = nil
	tl.hotMu.Unlock()
}

// InvalidateWarm forces warm-tier cache refresh on next access.
func (tl *TierLoader) InvalidateWarm() {
	tl.warmMu.Lock()
	tl.warmNodes = nil
	tl.warmMu.Unlock()
}

// InvalidateAll forces all tier caches to refresh on next access.
func (tl *TierLoader) InvalidateAll() {
	tl.InvalidateHot()
	tl.InvalidateWarm()
}

// tierScore computes a composite score for tier-based sorting.
func tierScore(n *storage.Node) float64 {
	s := n.Confidence
	if n.Pinned {
		s += 5.0
	}
	s += float64(n.AccessCount) * 0.05

	// Recency bonus
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if !ref.IsZero() {
		days := time.Since(ref).Hours() / 24
		if days > 0 {
			s *= 1.0 / (1.0 + days/30.0)
		}
	}
	return s
}
