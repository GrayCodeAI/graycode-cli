package server

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	mcpkit "github.com/GrayCodeAI/harrier/internal/mcpkit"
	"github.com/GrayCodeAI/harrier/engine"
	gitwatch "github.com/GrayCodeAI/harrier/git"
	intentpkg "github.com/GrayCodeAI/harrier/intent"
	"github.com/GrayCodeAI/harrier/skill"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/GrayCodeAI/harrier/utils"
	"github.com/mark3labs/mcp-go/mcp"
)

// --- Memory tool handlers ---

func (s *MCPServer) handleRemember(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	typ := strArgOr(req, "type", "decision")
	if typ != "" && !engine.IsValidNodeType(typ) {
		return nil, fmt.Errorf("invalid node type: %q", typ)
	}
	in := engine.RememberInput{
		Content: mcpkit.StrArg(req, "content"),
		Type:    typ,
		Summary: mcpkit.StrArg(req, "summary"),
		Tags:    mcpkit.StrArg(req, "tags"),
		Project: mcpkit.StrArg(req, "project"),
		Scope:   strArgOr(req, "scope", "project"),
	}
	node, err := s.eng.Remember(ctx, in)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(node)
}

func (s *MCPServer) handleRecall(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken
	depth := intArgOr(req, "depth", 2)
	if depth <= 0 || depth > 5 {
		depth = 2
	}
	limit := intArgOr(req, "limit", 10)
	if limit <= 0 || limit > 100 {
		limit = 10
	}

	sendProgress(ctx, s.mcp(), token, 1, 3, "running BM25 seed search")

	result, err := s.eng.Recall(ctx, engine.RecallOpts{
		Query:   mcpkit.StrArg(req, "query"),
		Depth:   depth,
		Limit:   limit,
		Type:    mcpkit.StrArg(req, "type"),
		Project: mcpkit.StrArg(req, "project"),
	})
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "recall complete")
	return mcpkit.JSONResult(result)
}

func (s *MCPServer) handleContext(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 2, "assembling hot-tier subgraph")

	result, err := s.eng.Context(ctx, mcpkit.StrArg(req, "project"))
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 2, 2, "context ready")
	return mcpkit.JSONResult(result)
}

func (s *MCPServer) handleForget(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	if err := s.eng.Forget(ctx, mcpkit.StrArg(req, "id")); err != nil {
		return nil, err
	}
	return mcp.NewToolResultText("forgotten"), nil
}

func (s *MCPServer) handleFeedback(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	id := mcpkit.StrArg(req, "id")
	action := mcpkit.StrArg(req, "action")
	content := mcpkit.StrArg(req, "content")
	if err := s.eng.Feedback(ctx, id, engine.FeedbackAction(action), content); err != nil {
		return nil, err
	}
	return mcp.NewToolResultText(fmt.Sprintf("feedback applied: %s on %s", action, utils.ShortID(id))), nil
}

func (s *MCPServer) handlePin(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	node, err := s.eng.Store().GetNode(ctx, mcpkit.StrArg(req, "id"))
	if err != nil {
		return nil, err
	}
	if v, ok := req.GetArguments()["pinned"].(bool); ok {
		node.Pinned = v
	} else {
		node.Pinned = !node.Pinned
	}
	if err := s.eng.Store().UpdateNode(ctx, node); err != nil {
		return nil, err
	}
	status := "unpinned"
	if node.Pinned {
		status = "pinned"
	}
	return mcp.NewToolResultText(fmt.Sprintf("%s node %s", status, utils.ShortID(node.ID))), nil
}

func (s *MCPServer) handleCompact(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	project := mcpkit.StrArg(req, "project")
	if strings.TrimSpace(project) == "" {
		return nil, fmt.Errorf("%w: harrier_compact requires a 'project' argument; refusing to compact across all projects", mcp.ErrInvalidParams)
	}

	sendProgress(ctx, s.mcp(), token, 1, 3, "identifying low-confidence memories")

	n, err := s.eng.Compact(ctx, project)
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "compaction complete")
	return mcp.NewToolResultText(fmt.Sprintf("compacted %d nodes", n)), nil
}

func (s *MCPServer) handleMentalModel(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 2, "building mental model")

	model, err := s.eng.MentalModel(ctx, mcpkit.StrArg(req, "project"))
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 2, 2, "mental model ready")
	return mcp.NewToolResultText(model.Format()), nil
}

func (s *MCPServer) handleProactive(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 3, "building hybrid search index")

	hs := engine.NewHybridSearch(s.eng.Store(), s.eng.Graph(), nil)
	pc := engine.NewProactiveContext(s.eng, hs)
	budget := intArgOr(req, "budget", 2000)

	sendProgress(ctx, s.mcp(), token, 2, 3, "predicting context")

	nodes, err := pc.Predict(ctx, mcpkit.StrArg(req, "project"), budget)
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "proactive context ready")
	return mcp.NewToolResultText(engine.FormatContext(nodes)), nil
}

func (s *MCPServer) handleHybridRecall(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	sendProgress(ctx, s.mcp(), token, 1, 4, "running hybrid search (BM25 + vector + graph)")

	hs := engine.NewHybridSearch(s.eng.Store(), s.eng.Graph(), nil)
	scored, err := hs.Search(ctx, mcpkit.StrArg(req, "query"), engine.RecallOpts{
		Depth: intArgOr(req, "depth", 2),
		Limit: intArgOr(req, "limit", 10),
	})
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 3, 4, "reranking results with RRF fusion")

	reranked := engine.Rerank(ctx, scored, s.eng.Store())

	sendProgress(ctx, s.mcp(), token, 4, 4, "hybrid recall complete")
	return mcpkit.JSONResult(reranked)
}

func (s *MCPServer) handleTaskUpdate(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	node, err := s.eng.Store().GetNode(ctx, mcpkit.StrArg(req, "id"))
	if err != nil {
		return nil, err
	}
	if err := s.eng.Store().SaveVersion(ctx, node.ID, node.Content, "agent", "task update"); err != nil {
		return nil, fmt.Errorf("save version: %w", err)
	}
	node.Content = mcpkit.StrArg(req, "content")
	node.Version++
	if err := s.eng.Store().UpdateNode(ctx, node); err != nil {
		return nil, err
	}
	// Update integrity signature after content change
	if mi := s.eng.Integrity(); mi != nil {
		sig := mi.Sign(node)
		_ = s.eng.Store().SaveSignature(ctx, node.ID, sig)
	}
	return mcpkit.JSONResult(node)
}

func (s *MCPServer) handleSessions(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	sessions, err := s.eng.Store().ListSessions(ctx, mcpkit.StrArg(req, "project"), intArgOr(req, "limit", 10))
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(sessions)
}

func (s *MCPServer) handleStale(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken
	project := mcpkit.StrArg(req, "project")
	if project == "" {
		project, _ = os.Getwd()
	}

	sendProgress(ctx, s.mcp(), token, 1, 3, "initializing git watcher")

	// gitwatch.New is lightweight (path validation + struct creation only).
	// No caching since the project directory varies per request.
	watcher, err := gitwatch.New(s.eng.Store(), s.eng.Graph(), project)
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 2, 3, "scanning for stale memories")

	since := time.Now().Add(-7 * 24 * time.Hour)
	reports, err := watcher.StalesSince(ctx, since)
	if err != nil {
		return nil, err
	}

	sendProgress(ctx, s.mcp(), token, 3, 3, "staleness check complete")
	if len(reports) == 0 {
		return mcp.NewToolResultText("No stale memories detected in the last 7 days."), nil
	}
	return mcpkit.JSONResult(reports)
}

func (s *MCPServer) handleIntent(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	query := mcpkit.StrArg(req, "query")
	i := intentpkg.Classify(query)
	weights := intentpkg.Weights(i)
	return mcpkit.JSONResult(map[string]any{
		"query":   query,
		"intent":  i.String(),
		"weights": weights,
	})
}

func (s *MCPServer) handleProfile(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	p, err := s.eng.Profile(ctx, mcpkit.StrArg(req, "project"))
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(map[string]any{
		"profile":   p,
		"formatted": p.Format(),
	})
}

func (s *MCPServer) handleSkillStore(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	name := mcpkit.StrArg(req, "name")
	desc := mcpkit.StrArg(req, "description")
	stepsJSON := mcpkit.StrArg(req, "steps")
	var stepDescs []string
	if err := json.Unmarshal([]byte(stepsJSON), &stepDescs); err != nil {
		return nil, fmt.Errorf("steps must be a JSON array of strings: %w", err)
	}
	steps := make([]skill.Step, len(stepDescs))
	for i, d := range stepDescs {
		steps[i] = skill.Step{Order: i + 1, Description: d}
	}
	sk := &skill.Skill{Name: name, Description: desc, Steps: steps}
	project, _ := os.Getwd()
	node, err := skill.Store(ctx, s.eng, sk, project)
	if err != nil {
		return nil, err
	}
	return mcp.NewToolResultText(fmt.Sprintf("stored skill %q (id: %s)", name, utils.ShortID(node.ID))), nil
}

func (s *MCPServer) handleSkillGet(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	project, _ := os.Getwd()
	sk, err := skill.Load(ctx, s.eng.Store(), mcpkit.StrArg(req, "name"), project)
	if err != nil {
		return nil, err
	}
	return mcp.NewToolResultText(skill.Replay(sk)), nil
}

func (s *MCPServer) handleSessionRecap(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	project := mcpkit.StrArg(req, "project")
	sessions, err := s.eng.Store().ListSessions(ctx, project, 1)
	if err != nil {
		return nil, err
	}
	if len(sessions) == 0 {
		return mcp.NewToolResultText("No previous sessions found."), nil
	}
	last := sessions[0]
	nodes, err := s.eng.Store().ListNodes(ctx, storage.NodeFilter{
		Project:       project,
		SourceSession: last.ID,
	})
	if err != nil {
		return nil, err
	}
	if len(nodes) == 0 {
		return mcp.NewToolResultText(fmt.Sprintf("Last session (%s) captured no memories.", last.ID[:8])), nil
	}
	return mcp.NewToolResultText(engine.FormatContext(nodes)), nil
}

func (s *MCPServer) handleStatus(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	st, err := s.eng.Status(ctx, mcpkit.StrArg(req, "project"))
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(st)
}

func (s *MCPServer) handleVerify(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	token := req.Params.Meta.ProgressToken

	mi := s.eng.Integrity()
	if mi == nil {
		return nil, fmt.Errorf("integrity checker not configured; initialize with NewMemoryIntegrity and wire via Engine.WithIntegrity")
	}

	sendProgress(ctx, s.mcp(), token, 1, 3, "loading memory nodes")

	nodes, err := s.eng.Store().ListNodes(ctx, storage.NodeFilter{Limit: 1000})
	if err != nil {
		return nil, err
	}

	// Load stored signatures
	storedSigs, err := s.eng.Store().GetAllSignatures(ctx)
	if err != nil {
		return nil, fmt.Errorf("load signatures: %w", err)
	}

	sendProgress(ctx, s.mcp(), token, 2, 3, "verifying integrity signatures")

	// Compare stored signatures against recomputed ones
	tampered := mi.VerifyBatch(nodes, storedSigs)

	sendProgress(ctx, s.mcp(), token, 3, 3, "verification complete")

	// Count nodes that have signatures stored
	signed := 0
	unsigned := 0
	for _, n := range nodes {
		if _, ok := storedSigs[n.ID]; ok {
			signed++
		} else {
			unsigned++
		}
	}

	status := "ok"
	if len(tampered) > 0 {
		status = "tampered"
	}

	result := map[string]interface{}{
		"status":        status,
		"nodes_checked": signed,
		"unsigned":      unsigned,
		"tampered":      len(tampered),
	}
	switch {
	case len(tampered) > 0:
		result["tampered_ids"] = tampered
		result["message"] = fmt.Sprintf("INTEGRITY VIOLATION: %d node(s) modified outside harrier.", len(tampered))
	case signed == 0:
		result["message"] = "No signatures stored yet. Memories created after this update will be signed automatically."
	default:
		result["message"] = fmt.Sprintf("All %d signed memories verified. No tampering detected.", signed)
	}

	return mcpkit.JSONResult(result)
}

// --- Cognee adoption: improve + structured entries + session tiers ---

func (s *MCPServer) handleImprove(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	opts := engine.ImproveOpts{
		Project:               mcpkit.StrArg(req, "project"),
		MinConfidence:         floatArgOr(req, "min_confidence", 0.5),
		MinAccessCount:        intArgOr(req, "min_access_count", 0),
		ConsolidateDuplicates: boolArgOr(req, "consolidate_duplicates", true),
		RegenerateSummaries:   boolArgOr(req, "regenerate_summaries", true),
		RefreshEmbeddings:     boolArgOr(req, "refresh_embeddings", false),
		Limit:                 intArgOr(req, "limit", 1000),
	}
	result, err := s.eng.Improve(ctx, opts)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(result)
}

func (s *MCPServer) handleQARemember(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	qa := engine.QAEntry{
		Question:    mcpkit.StrArg(req, "question"),
		Answer:      mcpkit.StrArg(req, "answer"),
		Context:     mcpkit.StrArg(req, "context"),
		Project:     mcpkit.StrArg(req, "project"),
		SessionID:   mcpkit.StrArg(req, "session_id"),
		SourceAgent: mcpkit.StrArg(req, "source_agent"),
	}
	node, err := s.eng.RememberQA(ctx, qa)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(node)
}

func (s *MCPServer) handleTraceRemember(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	te := engine.TraceEntry{
		OriginFunction:    mcpkit.StrArg(req, "origin_function"),
		Status:            mcpkit.StrArg(req, "status"),
		MethodParams:      mcpkit.StrArg(req, "method_params"),
		MethodReturnValue: mcpkit.StrArg(req, "method_return_value"),
		ErrorMessage:      mcpkit.StrArg(req, "error_message"),
		Project:           mcpkit.StrArg(req, "project"),
		SessionID:         mcpkit.StrArg(req, "session_id"),
	}
	if te.Status == "" {
		te.Status = "success"
	}
	node, err := s.eng.RememberTrace(ctx, te)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(node)
}

func (s *MCPServer) handleFeedbackRemember(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	fe := engine.FeedbackEntry{
		TargetNodeID: mcpkit.StrArg(req, "target_node_id"),
		FeedbackText: mcpkit.StrArg(req, "feedback_text"),
		Project:      mcpkit.StrArg(req, "project"),
		SessionID:    mcpkit.StrArg(req, "session_id"),
	}
	if scoreStr := mcpkit.StrArg(req, "score"); scoreStr != "" {
		var score int
		if _, err := fmt.Sscanf(scoreStr, "%d", &score); err == nil && score > 0 {
			fe.Score = &score
		}
	}
	node, err := s.eng.RememberFeedback(ctx, fe)
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(node)
}

func (s *MCPServer) handleSyncSession(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	sessionID := mcpkit.StrArg(req, "session_id")
	promoted, err := s.eng.SyncSessionToPermanent(ctx, sessionID)
	if err != nil {
		return nil, err
	}
	return mcp.NewToolResultText(fmt.Sprintf("synced %d memories from session %s to permanent graph", promoted, utils.ShortID(sessionID))), nil
}

func (s *MCPServer) handleRecallSession(ctx context.Context, req mcp.CallToolRequest) (*mcp.CallToolResult, error) {
	result, err := s.eng.RecallWithSession(ctx, engine.RecallOpts{
		Query:   mcpkit.StrArg(req, "query"),
		Project: mcpkit.StrArg(req, "project"),
		Limit:   intArgOr(req, "limit", 10),
	}, mcpkit.StrArg(req, "session_id"))
	if err != nil {
		return nil, err
	}
	return mcpkit.JSONResult(result)
}

// boolArgOr returns the boolean argument or a default value.
func boolArgOr(req mcp.CallToolRequest, key string, def bool) bool {
	v, ok := req.GetArguments()[key]
	if !ok {
		return def
	}
	b, ok := v.(bool)
	if !ok {
		return def
	}
	return b
}
