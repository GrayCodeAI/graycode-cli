package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

// buildPathStore creates a store with the given nodes and directed edges.
func buildPathStore(t *testing.T, nodes []string, edges [][2]string) *storage.MockStorage {
	t.Helper()
	s := storage.NewMockStorage()
	ctx := context.Background()
	for _, id := range nodes {
		if err := s.CreateNode(ctx, &storage.Node{ID: id, Type: "decision", Content: id, ContentHash: id}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}
	for i, e := range edges {
		if err := s.CreateEdge(ctx, &storage.Edge{ID: "e" + e[0] + e[1], FromID: e[0], ToID: e[1], Type: "led_to"}); err != nil {
			t.Fatalf("CreateEdge(%d): %v", i, err)
		}
	}
	return s
}

func eqPath(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func TestShortestPath(t *testing.T) {
	t.Parallel()
	ctx := context.Background()

	t.Run("same node", func(t *testing.T) {
		s := buildPathStore(t, []string{"a"}, nil)
		got, err := ShortestPath(ctx, s, "a", "a")
		if err != nil {
			t.Fatal(err)
		}
		if !eqPath(got, []string{"a"}) {
			t.Errorf("got %v, want [a]", got)
		}
	})

	t.Run("direct edge", func(t *testing.T) {
		s := buildPathStore(t, []string{"a", "b"}, [][2]string{{"a", "b"}})
		got, err := ShortestPath(ctx, s, "a", "b")
		if err != nil {
			t.Fatal(err)
		}
		if !eqPath(got, []string{"a", "b"}) {
			t.Errorf("got %v, want [a b]", got)
		}
	})

	t.Run("multi-hop shortest", func(t *testing.T) {
		// a->b->c->d  and a long detour a->b->x->y->d; shortest is the c route (len 4).
		s := buildPathStore(t, []string{"a", "b", "c", "d", "x", "y"},
			[][2]string{{"a", "b"}, {"b", "c"}, {"c", "d"}, {"b", "x"}, {"x", "y"}, {"y", "d"}})
		got, err := ShortestPath(ctx, s, "a", "d")
		if err != nil {
			t.Fatal(err)
		}
		if len(got) != 4 || got[0] != "a" || got[3] != "d" {
			t.Errorf("got %v, want length-4 path a..d", got)
		}
	})

	t.Run("undirected traversal", func(t *testing.T) {
		// Edge points b->a, but search a..b must still find it (undirected BFS).
		s := buildPathStore(t, []string{"a", "b"}, [][2]string{{"b", "a"}})
		got, err := ShortestPath(ctx, s, "a", "b")
		if err != nil {
			t.Fatal(err)
		}
		if !eqPath(got, []string{"a", "b"}) {
			t.Errorf("got %v, want [a b]", got)
		}
	})

	t.Run("no path", func(t *testing.T) {
		s := buildPathStore(t, []string{"a", "b", "c"}, [][2]string{{"a", "b"}})
		got, err := ShortestPath(ctx, s, "a", "c")
		if err != nil {
			t.Fatal(err)
		}
		if got != nil {
			t.Errorf("got %v, want nil (no path)", got)
		}
	})
}
