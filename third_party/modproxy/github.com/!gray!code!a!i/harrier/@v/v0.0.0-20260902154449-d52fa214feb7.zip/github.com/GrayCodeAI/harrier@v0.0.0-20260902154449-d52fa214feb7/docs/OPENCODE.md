# OpenCode Plugin & Integration Guide for Harrier

## Overview

[OpenCode](https://github.com/opencode-ai) agents integrate seamlessly with **Harrier** to store and retrieve persistent code graph memory across sessions.

---

## Configuration

### MCP Tool Config (`.opencode/mcp.json`)

```json
{
  "mcpServers": {
    "harrier": {
      "command": "harrier",
      "args": ["mcp"]
    }
  }
}
```

---

## Features Supported

* **Graph Memory**: 9 coding-specific node types (`convention`, `decision`, `bug`, `spec`, `task`, `preference`, `session`, `file`, `entity`).
* **Git-Aware Staleness**: Detects file changes and automatically flags outdated memories.
* **Impact Analysis**: Enables OpenCode to run reverse graph queries (`harrier_impact`) before performing code refactors.
* **Auto-Capture Hooks**: Ingests git pre-commit, post-merge, and terminal execution observations automatically.
