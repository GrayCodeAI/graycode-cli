# Harrier vs Mem0: Architecture Comparison

## Running Benchmarks

```bash
# All benchmarks
go test ./benchmark/ -bench=. -benchmem -benchtime=1s

# Specific operation
go test ./benchmark/ -bench=BenchmarkRemember -benchmem
go test ./benchmark/ -bench=BenchmarkRecall -benchmem
go test ./benchmark/ -bench=BenchmarkGraphBFS -benchmem
```

## Overview

| Dimension | Harrier | Mem0 |
|---|---|---|
| Language | Go | Python |
| Storage | SQLite (WAL mode) | Qdrant / pgvector + Postgres |
| Graph | Relaxed DAG in SQLite | Optional Neo4j |
| Dependencies | Zero (single binary) | Qdrant, Postgres, Redis (optional) |
| Target | Coding agents | General-purpose AI agents |
| Embeddings | Optional HNSW (pure Go) | Required (external service) |

## Memory Model

### Harrier

Harrier stores memories as typed nodes in a SQLite-backed DAG. Each node has:

- **9 coding-specific types**: convention, decision, bug, spec, task, preference, skill, file, entity
- **3-tier hierarchy**: hot (tier 1, always in context), warm (tier 2, query-relevant), cold (tier 3, full search)
- **Confidence decay**: half-life of 30 days; orphan nodes decay 2x faster
- **Version history**: full audit trail with rollback support

Nodes are connected by typed edges (caused_by, led_to, supersedes, relates_to, depends_on, touches, learned_in, part_of). Acyclic edges enforce DAG constraints via recursive CTE cycle detection. Cyclic edges (relates_to, depends_on, touches) allow bidirectional relationships.

### Mem0

Mem0 stores memories as flat text blobs in a vector database. Each memory is:

- A text string with optional metadata (user_id, agent_id, run_id)
- Embedded into a vector space for semantic search
- Optionally connected via a knowledge graph (Neo4j) for entity relationships

Mem0 uses LLM-based extraction to identify facts and entities from conversations. Memories are deduplicated via LLM comparison (not hash-based).

## Retrieval Architecture

### Harrier: 4-Signal Fused Recall (RRF)

Harrier's retrieval pipeline (FusedRecall) combines four independent signals using Reciprocal Rank Fusion:

1. **BM25 keyword search** (SQLite FTS5) with query expansion
2. **Graph traversal** (intent-aware BFS from top-5 BM25 seed nodes)
3. **Recency signal** (recently accessed/modified nodes sorted by timestamp)
4. **HNSW vector search** (optional, when embeddings are available)

Each signal produces an independent ranked list. RRF merges them with the formula: score = sum(1/(k+rank)) where k=60.

Post-fusion re-ranking applies:
- Confidence boost (high-confidence memories rank higher)
- Intent-type alignment ("Why" queries boost decisions, "How" queries boost skills)
- Pinned boost (2x for pinned nodes)
- Tier boost (1.3x for hot-tier nodes)
- Entity overlap boost (Mem0 v3 style)
- MMR diversity re-ranking (prevents near-duplicate results)

### Mem0: Multi-Signal Retrieval

Mem0's retrieval combines:

1. **Vector similarity** (embedding cosine distance)
2. **BM25 keyword search** (full-text)
3. **Entity graph traversal** (knowledge graph neighbors)
4. **RRF fusion** (same algorithm as Harrier)

The key difference: Mem0 relies on external embedding services (OpenAI, etc.) for vector search, while Harrier's HNSW is optional and pure-Go.

## Storage Architecture

### Harrier: Single SQLite File

```
Tables:
  nodes          — graph nodes with typed fields
  edges          — typed edges with cycle detection
  nodes_fts      — FTS5 full-text search index
  embeddings     — optional vector embeddings
  sessions       — session tracking
  file_watch     — file-to-node staleness mapping
  node_versions  — version history for audit/rollback
  access_log     — batched access tracking

Concurrency:
  WAL mode for concurrent reads
  Single writer (Go mutex serialization)
  No external lock service needed
```

Advantages:
- Zero deployment dependencies
- Single-file backup/restore
- ACID transactions
- No network hops for queries

### Mem0: Multi-Service Stack

```
Services:
  Qdrant/pgvector — vector storage + ANN search
  PostgreSQL      — metadata + history
  Redis           — caching (optional)
  Neo4j           — knowledge graph (optional)

Concurrency:
  Distributed locking via Redis
  Connection pooling per service
  Network latency for every operation
```

## Graph Operations

### Harrier

- **BFS/DFS traversal** via recursive CTEs in SQLite
- **Impact analysis**: reverse traversal from file path to find affected memories
- **Cycle detection**: recursive CTE ancestor check for acyclic edge types
- **PageRank**: in-graph centrality scoring
- **Self-linking**: automatic edge creation via content similarity (A-MEM inspired)
- **Temporal backbone**: auto-linking nodes in creation timeline

### Mem0

- **Entity graph**: optional Neo4j integration for entity relationships
- **Graph-RAG**: entity-based retrieval via graph neighbors
- **No impact analysis**: cannot swift which memories are affected by code changes
- **No cycle detection**: flat entity relationships, no DAG constraints

## Cognitive Engines (Harrier-Unique)

Harrier includes several cognitive engines absent from Mem0:

1. **Zeigarnik Engine**: detects open loops (unfinished tasks) in conversation transcripts
2. **Prospective Engine**: trigger-based future memory ("remind me when X happens")
3. **Epistemic Engine**: knowledge gap detection and directive generation
4. **Somatic Engine**: valence/arousal tracking for outcome-based memory regions
5. **Curiosity Engine**: exploration target generation for under-explored memory areas
6. **Reconsolidation Engine**: labile window for memory updates (inspired by neuroscience)

## Performance Characteristics

### Harrier (benchmarked on Apple M1, SQLite WAL, Go 1.26)

| Operation | Latency | Allocs/op | Notes |
|---|---|---|---|
| Remember (insert) | 14.7ms | 5,278 | Privacy filter, dedup, entity extraction, self-linking |
| Recall (search, 50 nodes) | 4.3ms | 5,725 | BM25 + graph expansion + RRF fusion |
| Recall (search, 30 nodes + edges) | 4.7ms | 6,045 | With graph traversal |
| Recall (empty query, list) | 74us | 410 | Simple filtered list |
| Context loading | 248us | 1,352 | Hot-tier + pinned + active tasks |
| BFS (depth=3, 50 nodes) | 1.3ms | 121 | Recursive CTE over SQLite |
| BFS (depth=1, shallow) | 116us | 24 | Single-hop traversal |
| BFS (depth=5, deep) | 3.1ms | 157 | Deep recursive traversal |
| ExtractSubgraph (depth=3) | 1.9ms | 2,602 | BFS + node/edge batch fetch |
| Compact (30 nodes) | 180us | 1,294 | Summarize + archive low-confidence |
| Compact (small, 10 nodes) | 120us | 604 | Minimal compaction |
| HNSW Insert (384D) | 2.0ms | 2,675 | Pure Go, in-memory ANN index |
| HNSW Search (1K vectors, k=10) | 598us | 955 | O(log n) approximate search |
| Entity Extraction | 137us | 28 | Regex + heuristic, no LLM |
| ListNodes (20 nodes) | 161us | 1,481 | SQLite query |
| Bloom Filter check | 104ns | 3 | In-memory probabilistic |
| ContextPacker (50 nodes) | 11us | 122 | Token-budget context formatting |

### Mem0 (reported in benchmarks)

| Operation | Latency | Notes |
|---|---|---|
| Add memory | ~500-2000ms | LLM extraction + embedding + vector DB write |
| Search | ~100-500ms | Embedding + vector search + graph traversal |
| Depends on | External services | Network latency to Qdrant/Postgres/Redis |

## Where Harrier Excels

1. **Zero dependencies**: single binary, no Docker, no external services
2. **Coding-specific types**: first-class support for conventions, decisions, bugs, specs
3. **Graph-propagated staleness**: file changes flag entire subgraphs via impact analysis
4. **Version history**: full rollback of memory changes
5. **Cognitive engines**: proactive memory, open-loop detection, knowledge gaps
6. **Latency**: 10-100x faster for common operations (no network hops)
7. **Privacy**: regex-based PII stripping before storage

## Where Mem0 Excels

1. **LLM-based extraction**: more accurate entity/fact extraction than regex
2. **Semantic search**: embedding-based retrieval catches paraphrases
3. **Ecosystem**: 54k GitHub stars, large community, many integrations
4. **Multi-modal**: supports image memories (Harrier: Phase 5)
5. **Cloud offering**: managed service with dashboard
6. **Evaluation benchmarks**: LoCoMo benchmark scores published

## Summary

Harrier is a purpose-built memory engine for coding agents that prioritizes low latency, zero dependencies, and graph-native operations. Mem0 is a general-purpose memory layer that prioritizes extraction accuracy and ecosystem breadth at the cost of operational complexity.

For coding agents that need fast, local, graph-aware memory with impact analysis and staleness tracking, Harrier is the better fit. For general AI applications that need LLM-powered extraction and don't mind external service dependencies, Mem0 is the more mature choice.
