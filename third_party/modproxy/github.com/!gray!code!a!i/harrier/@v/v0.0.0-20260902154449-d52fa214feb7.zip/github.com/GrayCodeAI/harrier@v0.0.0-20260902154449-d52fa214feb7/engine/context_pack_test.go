package engine

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func makeNode(id, content, nodeType string, confidence float64, accessCount int, pinned bool) *storage.Node {
	return &storage.Node{
		ID:          id,
		Content:     content,
		Type:        nodeType,
		Confidence:  confidence,
		AccessCount: accessCount,
		Pinned:      pinned,
	}
}

func TestContextPackerEmpty(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(2000)
	result := cp.Pack(nil)
	if result.Content != "" {
		t.Errorf("expected empty content for nil nodes, got %q", result.Content)
	}
	if result.NodesUsed != 0 {
		t.Errorf("expected 0 nodes used, got %d", result.NodesUsed)
	}
}

func TestContextPackerBudgetEnforcement(t *testing.T) {
	t.Parallel()
	// Very small budget should limit output
	cp := NewContextPacker(20)
	nodes := []*storage.Node{
		makeNode("a", "This is a convention that has some content to fill the budget", "convention", 0.9, 5, false),
		makeNode("b", "Another convention with different content that also fills budget", "convention", 0.8, 3, false),
	}
	result := cp.Pack(nodes)
	// With tiny budget, should pack fewer nodes
	if result.TokensUsed > 30 {
		t.Errorf("expected tokens <= 30 with 20 budget, got %d", result.TokensUsed)
	}
}

func TestContextPackerDefaultBudget(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(0)
	if cp.budget != 2000 {
		t.Errorf("expected default budget 2000, got %d", cp.budget)
	}
	cp2 := NewContextPacker(-5)
	if cp2.budget != 2000 {
		t.Errorf("expected default budget 2000 for negative, got %d", cp2.budget)
	}
}

func TestContextPackerTypeQuotas(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(5000)
	// Create 12 conventions (quota is 8)
	nodes := make([]*storage.Node, 12)
	for i := 0; i < 12; i++ {
		nodes[i] = makeNode(
			"c"+string(rune('a'+i)),
			"convention "+string(rune('a'+i))+" with unique content for dedup",
			"convention", 0.8, 1, false,
		)
	}
	result := cp.Pack(nodes)
	if result.TypeCounts["convention"] > 8 {
		t.Errorf("expected at most 8 conventions (quota), got %d", result.TypeCounts["convention"])
	}
}

func TestContextPackerPinnedFirst(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(5000)
	nodes := []*storage.Node{
		makeNode("np", "regular node with enough content", "convention", 0.9, 10, false),
		makeNode("p1", "pinned node with enough content", "convention", 0.1, 1, true),
	}
	result := cp.Pack(nodes)
	if result.NodesUsed < 2 {
		t.Fatalf("expected 2 nodes, got %d", result.NodesUsed)
	}
	// Pinned should appear first
	if !strings.Contains(result.Content, "pinned") {
		t.Error("expected pinned node to appear first in packed content")
	}
}

func TestContextPackerDeduplication(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(5000)
	// Two nodes with identical first 50 chars
	nodes := []*storage.Node{
		makeNode("d1", "this is a duplicate content that starts the same way and then differs", "convention", 0.9, 5, false),
		makeNode("d2", "this is a duplicate content that starts the same way and then differs too", "convention", 0.8, 3, false),
	}
	result := cp.Pack(nodes)
	if result.NodesUsed != 1 {
		t.Errorf("expected 1 node after dedup (same first 50 chars), got %d", result.NodesUsed)
	}
}

func TestContextPackerLongContentTruncation(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(5000)
	longContent := strings.Repeat("x", 200)
	nodes := []*storage.Node{
		makeNode("lc", longContent, "convention", 0.9, 1, false),
	}
	result := cp.Pack(nodes)
	if strings.Contains(result.Content, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx") {
		t.Error("expected content to be truncated at 120 chars")
	}
	if !strings.Contains(result.Content, "...") {
		t.Error("expected '...' after truncation")
	}
}

func TestContextPackerPriority(t *testing.T) {
	t.Parallel()
	cp := NewContextPacker(5000)
	// Convention gets +1.0 priority boost over "spec" (+0.6)
	conv := makeNode("conv", "convention content for priority test", "convention", 0.5, 0, false)
	spec := makeNode("spec", "spec content for priority test", "spec", 0.5, 0, false)
	score1 := cp.priority(conv)
	score2 := cp.priority(spec)
	if score1 <= score2 {
		t.Errorf("expected convention priority (%f) > spec priority (%f)", score1, score2)
	}
}
