package engine

import (
	"testing"
)

func FuzzContentHash(f *testing.F) {
	f.Add("hello world", "global", "default", "convention")
	f.Add("", "", "", "")
	f.Add("content", "scope", "project", "type")

	f.Fuzz(func(t *testing.T, content, scope, project, nodeType string) {
		hash := ContentHash(content, scope, project, nodeType)
		if hash == "" {
			t.Error("ContentHash returned empty string")
		}
		// Determinism: same input always produces same hash
		hash2 := ContentHash(content, scope, project, nodeType)
		if hash != hash2 {
			t.Errorf("ContentHash not deterministic: %q != %q", hash, hash2)
		}
	})
}

func FuzzExtractEntities(f *testing.F) {
	f.Add("The @auth module handles #security for $ProjectX")
	f.Add("")
	f.Add("@@not-an-entity ##not-a-tag")
	f.Add("@valid @entity @with @many @entities")

	f.Fuzz(func(t *testing.T, input string) {
		entities := ExtractEntities(input)
		// Should not panic, entities should have non-empty names
		for _, e := range entities {
			if e.Name == "" {
				t.Errorf("entity with empty name from input %q", input)
			}
		}
	})
}

func FuzzRecallOpts(f *testing.F) {
	f.Add("test query", "convention", "proj", 10, 2)
	f.Add("", "", "", 0, 0)

	f.Fuzz(func(t *testing.T, query, typ, project string, limit, depth int) {
		opts := RecallOpts{
			Query:   query,
			Type:    typ,
			Project: project,
			Limit:   limit,
			Depth:   depth,
		}
		key := CacheKey(opts)
		if key == "" {
			t.Error("CacheKey returned empty string")
		}
	})
}
