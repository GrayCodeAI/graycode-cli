"""Harrier Python SDK client — thin wrapper around the REST API."""

import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class HarrierConfig:
    """Configuration for the Harrier client."""
    host: str = "127.0.0.1"
    port: int = 3456
    project: str = ""
    timeout: int = 10

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"


@dataclass
class Memory:
    """A single memory node."""
    id: str = ""
    type: str = ""
    content: str = ""
    confidence: float = 0.5
    pinned: bool = False
    tier: int = 2
    tags: str = ""
    access_count: int = 0


@dataclass
class RecallResult:
    """Result of a recall operation."""
    nodes: list = field(default_factory=list)
    edges: list = field(default_factory=list)


class Harrier:
    """Harrier client for persistent coding agent memory.

    Usage:
        y = Harrier(project="my-app")
        y.remember("Use jose not jsonwebtoken", type="convention")
        results = y.recall("auth library")
        context = y.context()
    """

    def __init__(self, project: str = "", host: str = "127.0.0.1", port: int = 3456, timeout: int = 10):
        self.config = HarrierConfig(host=host, port=port, project=project, timeout=timeout)

    def remember(self, content: str, type: str = "decision", tags: str = "", pinned: bool = False) -> Memory:
        """Store a memory in the graph.

        Args:
            content: The memory content (what to remember).
            type: Memory type — convention, decision, bug, spec, task, preference, skill.
            tags: Comma-separated tags.
            pinned: If True, memory always appears in context.

        Returns:
            The created Memory node.
        """
        body = {
            "content": content,
            "type": type,
            "scope": "project",
            "project": self.config.project,
            "tags": tags,
            "pinned": pinned,
        }
        resp = self._post("/harrier/remember", body)
        return Memory(
            id=resp.get("id", ""),
            type=type,
            content=content,
            confidence=resp.get("confidence", 0.8),
            pinned=pinned,
        )

    def recall(self, query: str, limit: int = 10, depth: int = 3, type: str = "") -> RecallResult:
        """Search the memory graph.

        Args:
            query: Natural language query.
            limit: Max results.
            depth: Graph traversal depth.
            type: Filter by memory type (optional).

        Returns:
            RecallResult with nodes and edges.
        """
        body = {"query": query, "limit": limit, "depth": depth}
        if type:
            body["type"] = type
        if self.config.project:
            body["project"] = self.config.project

        resp = self._post("/harrier/recall", body)
        nodes = [Memory(
            id=n.get("id", ""),
            type=n.get("type", ""),
            content=n.get("content", ""),
            confidence=n.get("confidence", 0.5),
            pinned=n.get("pinned", False),
            tier=n.get("tier", 2),
        ) for n in resp.get("nodes", [])]

        return RecallResult(nodes=nodes, edges=resp.get("edges", []))

    def context(self, budget: int = 2000) -> str:
        """Get hot-tier context for session injection.

        Args:
            budget: Max token budget.

        Returns:
            Formatted context string.
        """
        params = f"?budget={budget}"
        if self.config.project:
            params += f"&project={self.config.project}"
        resp = self._get(f"/harrier/context{params}")
        nodes = resp.get("nodes", [])
        lines = []
        for n in nodes:
            lines.append(f"[{n.get('type', '')}] {n.get('content', '')}")
        return "\n".join(lines)

    def forget(self, node_id: str) -> bool:
        """Archive a memory (sets confidence to 0)."""
        self._delete(f"/harrier/forget/{node_id}")
        return True

    def link(self, from_id: str, to_id: str, edge_type: str = "relates_to") -> dict:
        """Create a typed edge between two memories."""
        body = {"from_id": from_id, "to_id": to_id, "type": edge_type}
        return self._post("/harrier/link", body)

    def status(self) -> dict:
        """Get graph statistics."""
        return self._get("/harrier/graph/stats")

    def impact(self, file_path: str) -> list:
        """Check what memories are affected by a file change."""
        resp = self._get(f"/harrier/impact/{file_path}")
        return resp.get("affected", [])

    def stale(self) -> list:
        """Get memories flagged as stale due to code changes."""
        resp = self._get("/harrier/stale")
        return resp.get("stale", [])

    def health(self) -> dict:
        """Health check."""
        return self._get("/harrier/health")

    # --- Private methods ---

    def _post(self, path: str, body: dict) -> dict:
        url = f"{self.config.base_url}{path}"
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise HarrierError(f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}")
        except urllib.error.URLError as e:
            raise HarrierError(f"Connection failed: {e.reason}. Is harrier running?")

    def _get(self, path: str) -> dict:
        url = f"{self.config.base_url}{path}"
        req = urllib.request.Request(url)
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise HarrierError(f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}")
        except urllib.error.URLError as e:
            raise HarrierError(f"Connection failed: {e.reason}. Is harrier running?")

    def _delete(self, path: str) -> dict:
        url = f"{self.config.base_url}{path}"
        req = urllib.request.Request(url, method="DELETE")
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise HarrierError(f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}")
        except urllib.error.URLError as e:
            raise HarrierError(f"Connection failed: {e.reason}. Is harrier running?")


class HarrierError(Exception):
    """Error from the Harrier API."""
    pass
