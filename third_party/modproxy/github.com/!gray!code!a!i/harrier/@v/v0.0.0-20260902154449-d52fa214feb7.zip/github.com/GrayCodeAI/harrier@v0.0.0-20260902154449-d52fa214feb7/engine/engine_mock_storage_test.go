//nolint:gocritic
package engine

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// This file is part of package engine tests. It holds mockStorage, the
// in-memory storage.Storage test double, moved verbatim out of
// engine_test.go for readability; behavior is unchanged.

// ---------------------------------------------------------------------------
// mockStorage — in-memory implementation of storage.Storage
// ---------------------------------------------------------------------------

type mockStorage struct {
	mu       sync.RWMutex
	nodes    map[string]*storage.Node
	edges    map[string]*storage.Edge
	sessions map[string]*storage.Session
	versions map[string][]*storage.NodeVersion
	embeds   map[string][]float32
	watches  []fileWatch
	metadata map[string]map[string]string
}

type fileWatch struct {
	filePath, nodeID, gitHash string
}

func newMockStorage() *mockStorage {
	return &mockStorage{
		nodes:    make(map[string]*storage.Node),
		edges:    make(map[string]*storage.Edge),
		sessions: make(map[string]*storage.Session),
		versions: make(map[string][]*storage.NodeVersion),
		embeds:   make(map[string][]float32),
		metadata: make(map[string]map[string]string),
	}
}

func (m *mockStorage) CreateNode(ctx context.Context, n *storage.Node) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	cp := *n
	m.nodes[n.ID] = &cp
	return nil
}

func (m *mockStorage) GetNode(ctx context.Context, id string) (*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	if n, ok := m.nodes[id]; ok {
		cp := *n
		return &cp, nil
	}
	return nil, storage.ErrNodeNotFound
}

func (m *mockStorage) GetNodeByKey(ctx context.Context, key, project string) (*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	for _, n := range m.nodes {
		if n.Key == key && n.Project == project {
			cp := *n
			return &cp, nil
		}
	}
	return nil, nil
}

func (m *mockStorage) GetNodesBatch(ctx context.Context, ids []string) ([]*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Node
	for _, id := range ids {
		if n, ok := m.nodes[id]; ok {
			cp := *n
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) UpdateNode(ctx context.Context, n *storage.Node) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	cp := *n
	m.nodes[n.ID] = &cp
	return nil
}

func (m *mockStorage) UpdateNodeContent(ctx context.Context, id, newContent string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if n, ok := m.nodes[id]; ok {
		n.Content = newContent
		return nil
	}
	return storage.ErrNodeNotFound
}

func (m *mockStorage) ArchiveNode(ctx context.Context, id string) (bool, error) {
	if err := ctx.Err(); err != nil {
		return false, err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	n, ok := m.nodes[id]
	if !ok || n.Confidence <= 0 {
		return false, nil
	}
	cp := *n
	cp.Confidence = 0
	m.nodes[id] = &cp
	return true, nil
}

func (m *mockStorage) DeleteNode(ctx context.Context, id string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.nodes, id)
	return nil
}

func (m *mockStorage) ListNodes(ctx context.Context, f storage.NodeFilter) ([]*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Node
	for _, n := range m.nodes {
		if f.Type != "" && n.Type != f.Type {
			continue
		}
		if f.Scope != "" && n.Scope != f.Scope {
			continue
		}
		if f.Project != "" && n.Project != f.Project {
			continue
		}
		if f.Tier > 0 && n.Tier != f.Tier {
			continue
		}
		if f.MinConfidence > 0 && n.Confidence < f.MinConfidence {
			continue
		}
		// return a copy to avoid races when caller mutates
		cp := *n
		out = append(out, &cp)
	}
	return out, nil
}

func (m *mockStorage) SearchNodes(ctx context.Context, query string, limit int) ([]*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Node
	words := strings.Fields(strings.ToLower(query))
	for _, n := range m.nodes {
		if query == "" || matchesAnyWord(words, n.Content, n.Summary, n.Tags) {
			cp := *n
			out = append(out, &cp)
			if limit > 0 && len(out) >= limit {
				break
			}
		}
	}
	return out, nil
}

func matchesAnyWord(words []string, fields ...string) bool {
	for _, f := range fields {
		lower := strings.ToLower(f)
		for _, w := range words {
			if strings.Contains(lower, w) {
				return true
			}
		}
	}
	return false
}

func (m *mockStorage) SearchNodeByHash(ctx context.Context, hash, scope, project string) (*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	for _, n := range m.nodes {
		if n.ContentHash == hash && n.Scope == scope && n.Project == project {
			cp := *n
			return &cp, nil
		}
	}
	return nil, nil
}

func (m *mockStorage) GetNeighbors(ctx context.Context, nodeID string) ([]*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	seen := map[string]bool{}
	var out []*storage.Node
	for _, e := range m.edges {
		var other string
		if e.FromID == nodeID {
			other = e.ToID
		} else if e.ToID == nodeID {
			other = e.FromID
		} else {
			continue
		}
		if seen[other] {
			continue
		}
		seen[other] = true
		if n, ok := m.nodes[other]; ok {
			cp := *n
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) CreateEdge(ctx context.Context, e *storage.Edge) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.edges[e.ID] = e
	return nil
}

func (m *mockStorage) GetEdge(ctx context.Context, id string) (*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	if e, ok := m.edges[id]; ok {
		cp := *e
		return &cp, nil
	}
	return nil, storage.ErrEdgeNotFound
}

func (m *mockStorage) InvalidateEdge(ctx context.Context, id string) error {
	return nil
}

func (m *mockStorage) DeleteEdge(ctx context.Context, id string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.edges, id)
	return nil
}

func (m *mockStorage) GetEdgesFrom(ctx context.Context, nodeID string) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Edge
	for _, e := range m.edges {
		if e.FromID == nodeID {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) GetEdgesTo(ctx context.Context, nodeID string) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Edge
	for _, e := range m.edges {
		if e.ToID == nodeID {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) GetValidEdgesFrom(ctx context.Context, nodeID string, at time.Time) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if at.IsZero() {
		at = time.Now().UTC()
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Edge
	for _, e := range m.edges {
		if e.FromID == nodeID && validEdgeAt(e, at) {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) GetValidEdgesTo(ctx context.Context, nodeID string, at time.Time) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if at.IsZero() {
		at = time.Now().UTC()
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Edge
	for _, e := range m.edges {
		if e.ToID == nodeID && validEdgeAt(e, at) {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func validEdgeAt(e *storage.Edge, at time.Time) bool {
	if !e.ValidAt.IsZero() && e.ValidAt.After(at) {
		return false
	}
	if !e.InvalidAt.IsZero() && !e.InvalidAt.After(at) {
		return false
	}
	return true
}

func (m *mockStorage) GetEdgesBetween(ctx context.Context, nodeIDs []string) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	idSet := make(map[string]bool, len(nodeIDs))
	for _, id := range nodeIDs {
		idSet[id] = true
	}
	var out []*storage.Edge
	for _, e := range m.edges {
		if idSet[e.FromID] && idSet[e.ToID] {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) GetAllEdgesFor(ctx context.Context, nodeIDs []string) ([]*storage.Edge, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	idSet := make(map[string]bool, len(nodeIDs))
	for _, id := range nodeIDs {
		idSet[id] = true
	}
	var out []*storage.Edge
	for _, e := range m.edges {
		if idSet[e.FromID] || idSet[e.ToID] {
			cp := *e
			out = append(out, &cp)
		}
	}
	return out, nil
}

func (m *mockStorage) CountEdges(ctx context.Context, nodeID string) (inbound int, outbound int, err error) {
	if err := ctx.Err(); err != nil {
		return 0, 0, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	for _, e := range m.edges {
		if e.FromID == nodeID {
			outbound++
		}
		if e.ToID == nodeID {
			inbound++
		}
	}
	return inbound, outbound, nil
}

func (m *mockStorage) CountAllEdges(ctx context.Context) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.edges), nil
}

func (m *mockStorage) CountEdgesBatch(ctx context.Context, nodeIDs []string) (map[string][2]int, error) {
	result := make(map[string][2]int, len(nodeIDs))
	for _, id := range nodeIDs {
		inbound, outbound, _ := m.CountEdges(ctx, id)
		result[id] = [2]int{inbound, outbound}
	}
	return result, nil
}

func (m *mockStorage) CheckCycle(ctx context.Context, fromID, toID string) (bool, error) {
	if err := ctx.Err(); err != nil {
		return false, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	seen := map[string]bool{}
	var walk func(id string) bool
	walk = func(id string) bool {
		if id == toID {
			return true
		}
		if seen[id] {
			return false
		}
		seen[id] = true
		for _, e := range m.edges {
			acyclic := e.Type == "caused_by" || e.Type == "led_to" || e.Type == "supersedes" ||
				e.Type == "learned_in" || e.Type == "part_of"
			if e.ToID == id && acyclic {
				if walk(e.FromID) {
					return true
				}
			}
		}
		return false
	}
	return walk(fromID), nil
}

func (m *mockStorage) CreateSession(ctx context.Context, sess *storage.Session) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.sessions[sess.ID] = sess
	return nil
}

func (m *mockStorage) EndSession(ctx context.Context, id string, summary string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if s, ok := m.sessions[id]; ok {
		s.Summary = summary
		s.EndedAt = time.Now()
	}
	return nil
}

func (m *mockStorage) ListSessions(ctx context.Context, project string, limit int) ([]*storage.Session, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	var out []*storage.Session
	for _, s := range m.sessions {
		if project == "" || s.Project == project {
			out = append(out, s)
		}
	}
	return out, nil
}

func (m *mockStorage) SaveVersion(ctx context.Context, nodeID string, content, changedBy, reason string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	vers := m.versions[nodeID]
	nextVer := 1
	for _, v := range vers {
		if v.Version >= nextVer {
			nextVer = v.Version + 1
		}
	}
	m.versions[nodeID] = append(vers, &storage.NodeVersion{
		NodeID:    nodeID,
		Content:   content,
		ChangedBy: changedBy,
		Reason:    reason,
		Version:   nextVer,
		ChangedAt: time.Now(),
	})
	return nil
}

func (m *mockStorage) GetVersions(ctx context.Context, nodeID string) ([]*storage.NodeVersion, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make([]*storage.NodeVersion, len(m.versions[nodeID]))
	copy(out, m.versions[nodeID])
	return out, nil
}

func (m *mockStorage) SaveEmbedding(ctx context.Context, nodeID, model string, vector []float32) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	cp := make([]float32, len(vector))
	copy(cp, vector)
	m.embeds[nodeID] = cp
	return nil
}

func (m *mockStorage) DeleteEmbedding(ctx context.Context, nodeID string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.embeds, nodeID)
	return nil
}

func (m *mockStorage) AllEmbeddings(ctx context.Context, _ string) (map[string][]float32, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make(map[string][]float32, len(m.embeds))
	for k, v := range m.embeds {
		cp := make([]float32, len(v))
		copy(cp, v)
		out[k] = cp
	}
	return out, nil
}

func (m *mockStorage) GetEmbedding(ctx context.Context, nodeID string) ([]float32, string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if v, ok := m.embeds[nodeID]; ok {
		cp := make([]float32, len(v))
		copy(cp, v)
		return cp, "", nil
	}
	return nil, "", nil
}

func (m *mockStorage) GetEmbeddingsBatch(ctx context.Context, model string, offset, limit int) (map[string][]float32, error) {
	return m.AllEmbeddings(ctx, model)
}

func (m *mockStorage) BuildHNSWIndex(ctx context.Context, model string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	return nil
}

func (m *mockStorage) SearchHNSW(ctx context.Context, model string, query []float32, k, ef int) ([]string, []float32, error) {
	if err := ctx.Err(); err != nil {
		return nil, nil, err
	}
	return nil, nil, nil
}

func (m *mockStorage) AddFileWatch(ctx context.Context, filePath, nodeID, gitHash string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	m.watches = append(m.watches, fileWatch{filePath, nodeID, gitHash})
	return nil
}

func (m *mockStorage) AddReplayEvent(ctx context.Context, sessionID, data string) error { return nil }

func (m *mockStorage) GetReplayEvents(ctx context.Context, sessionID string) ([]*storage.ReplayEvent, error) {
	return nil, nil
}
func (m *mockStorage) LogAccess(ctx context.Context, nodeID string) error { return nil }
func (m *mockStorage) FlushAccessLog(ctx context.Context) (int, error)    { return 0, nil }

func (m *mockStorage) SaveNodeMetadata(_ context.Context, nodeID string, meta map[string]string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.metadata[nodeID] = meta
	return nil
}

func (m *mockStorage) LoadNodeMetadata(_ context.Context, nodeIDs []string) (map[string]map[string]string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make(map[string]map[string]string, len(nodeIDs))
	for _, id := range nodeIDs {
		if meta, ok := m.metadata[id]; ok {
			out[id] = meta
		}
	}
	return out, nil
}

func (m *mockStorage) NodeStats(ctx context.Context) (map[string]int, int, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	stats := make(map[string]int)
	total := 0
	for _, n := range m.nodes {
		stats[n.Type]++
		total++
	}
	return stats, total, nil
}

func (m *mockStorage) DoctorStats(ctx context.Context) (storage.DoctorStatsResult, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	var r storage.DoctorStatsResult
	for _, n := range m.nodes {
		r.TotalNodes++
		if n.Confidence < 0.2 {
			r.LowConfidence++
		}
		if n.Pinned {
			r.Pinned++
		}
	}
	return r, nil
}

func (m *mockStorage) LastUpdated(ctx context.Context) (time.Time, error) {
	return time.Time{}, nil
}

func (m *mockStorage) TopConnected(ctx context.Context, limit int) ([]string, error) {
	return nil, nil
}

func (m *mockStorage) SaveSignature(ctx context.Context, nodeID, signature string) error {
	return nil
}

func (m *mockStorage) GetAllSignatures(ctx context.Context) (map[string]string, error) {
	return nil, nil
}

func (m *mockStorage) WithTx(ctx context.Context, fn func(storage.Storage) error) error {
	return fn(m)
}
func (m *mockStorage) Backup(ctx context.Context, backupPath string) error { return nil }
func (m *mockStorage) Close() error                                        { return nil }
