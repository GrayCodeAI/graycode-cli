package engine

import (
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// MemoryEventKind classifies a memory mutation emitted on the engine's event bus.
type MemoryEventKind string

const (
	// MemoryCreated is emitted when a new node is stored.
	MemoryCreated MemoryEventKind = "created"
	// MemoryUpdated is emitted when an existing node is overwritten (keyed upsert).
	MemoryUpdated MemoryEventKind = "updated"
	// MemoryDeleted is emitted when a node is archived/forgotten.
	MemoryDeleted MemoryEventKind = "deleted"
)

// MemoryEvent is an in-process notification about a memory mutation. It carries
// the same payload the gRPC WatchMemories RPC (api/proto/harrier.proto) would
// stream, so a transport (SSE today, gRPC later) can forward it verbatim.
type MemoryEvent struct {
	Kind      MemoryEventKind
	NodeID    string
	Content   string
	Project   string
	Timestamp int64 // unix milliseconds
}

// eventBus is a tiny fan-out publisher. Subscribers receive every published
// event on a buffered channel; a slow subscriber drops events rather than
// blocking publishers, matching the SSE broadcaster's best-effort semantics.
type eventBus struct {
	mu     sync.RWMutex
	nextID uint64
	subs   map[uint64]chan MemoryEvent
}

func newEventBus() *eventBus {
	return &eventBus{subs: make(map[uint64]chan MemoryEvent)}
}

// subscribe registers a new subscriber and returns its channel plus an
// unsubscribe func that removes and closes the channel.
func (b *eventBus) subscribe() (<-chan MemoryEvent, func()) {
	ch := make(chan MemoryEvent, 64)
	b.mu.Lock()
	id := b.nextID
	b.nextID++
	b.subs[id] = ch
	b.mu.Unlock()

	return ch, func() {
		b.mu.Lock()
		if _, ok := b.subs[id]; ok {
			delete(b.subs, id)
			close(ch)
		}
		b.mu.Unlock()
	}
}

// publish fans an event out to all current subscribers, dropping it for any
// subscriber whose buffer is full.
func (b *eventBus) publish(evt MemoryEvent) {
	b.mu.RLock()
	defer b.mu.RUnlock()
	for _, ch := range b.subs {
		select {
		case ch <- evt:
		default:
			// Slow subscriber: drop rather than block the writer.
		}
	}
}

// Events lazily creates and returns the engine's event bus accessor. Callers
// use Subscribe to receive memory mutation events.
func (e *Engine) events() *eventBus {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.eventBus == nil {
		e.eventBus = newEventBus()
	}
	return e.eventBus
}

// SubscribeMemoryEvents registers a subscriber for memory mutation events
// (created/updated/deleted). It returns a receive-only channel and an
// unsubscribe function the caller must invoke when done. The channel is
// buffered; events are dropped for subscribers that fall behind.
func (e *Engine) SubscribeMemoryEvents() (<-chan MemoryEvent, func()) {
	return e.events().subscribe()
}

// emitMemoryEvent publishes a memory mutation on the bus. It is best-effort and
// safe to call with no subscribers (and before the bus is initialized).
func (e *Engine) emitMemoryEvent(kind MemoryEventKind, node *storage.Node) {
	if node == nil {
		return
	}
	e.mu.Lock()
	bus := e.eventBus
	e.mu.Unlock()
	if bus == nil {
		return
	}
	bus.publish(MemoryEvent{
		Kind:      kind,
		NodeID:    node.ID,
		Content:   node.Content,
		Project:   node.Project,
		Timestamp: time.Now().UnixMilli(),
	})
}
