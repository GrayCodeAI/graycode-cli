package engine

import (
	"context"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// Consolidation defaults. These intentionally mirror the conservative,
// idle-time spirit of the decay scheduler: small windows, bounded work.
const (
	// defaultConsolidationInterval is used when StartConsolidation is called
	// with a non-positive interval.
	defaultConsolidationInterval = 1 * time.Hour
	// consolidationRecentWindow bounds how far back the conflict re-scan looks.
	// Only nodes updated within this window are re-checked, keeping each cycle
	// proportional to recent activity rather than total graph size.
	consolidationRecentWindow = 24 * time.Hour
	// consolidationRecentLimit caps how many recent nodes a single cycle
	// re-scans for contradictions, so a burst of writes cannot make a cycle
	// unbounded.
	consolidationRecentLimit = 200
)

// consolidationState holds the lifecycle of a background consolidation loop.
// It is created by StartConsolidation and torn down by StopConsolidation or by
// cancelling the context passed to StartConsolidation. A nil/absent state means
// consolidation is OFF, which is the default.
type consolidationState struct {
	cancel  context.CancelFunc
	done    chan struct{}
	cycles  int64 // number of completed cycles, for observability/tests
	stopped sync.Once
}

// StartConsolidation launches a background "sleep-time" consolidation loop that
// runs during idle periods. Each cycle:
//
//  1. applies half-life decay (RunDecay) over the whole store,
//  2. re-runs conflict detection over recently-updated nodes, and
//  3. compacts low-confidence memories per active project.
//
// The loop runs at the given interval (the first cycle fires after one
// interval, not immediately, so startup stays cheap). It is OFF by default and
// only runs once explicitly started. Calling StartConsolidation while a loop is
// already running is a no-op and returns false.
//
// Cancellation: the loop stops when ctx is cancelled or StopConsolidation is
// called, whichever comes first. All writes performed by a cycle reuse the
// engine's existing locking model (e.mu for the conflict re-scan, the store's
// WAL single-writer for decay/compaction), so no new write races are
// introduced.
func (e *Engine) StartConsolidation(ctx context.Context, interval time.Duration) bool {
	if interval <= 0 {
		interval = defaultConsolidationInterval
	}
	e.consolMu.Lock()
	defer e.consolMu.Unlock()
	if e.consol != nil {
		return false // already running
	}
	loopCtx, cancel := context.WithCancel(ctx)
	st := &consolidationState{
		cancel: cancel,
		done:   make(chan struct{}),
	}
	e.consol = st
	go e.consolidationLoop(loopCtx, interval, st)
	return true
}

// StopConsolidation halts a running consolidation loop and waits for the
// current cycle to finish. Safe to call when no loop is running (no-op) and
// safe to call multiple times.
func (e *Engine) StopConsolidation() {
	e.consolMu.Lock()
	st := e.consol
	e.consol = nil
	e.consolMu.Unlock()
	if st == nil {
		return
	}
	st.stopped.Do(func() {
		st.cancel()
	})
	<-st.done
}

// ConsolidationCycles reports how many consolidation cycles have completed
// since the loop started. Returns 0 when consolidation has never been started
// or has been stopped. Primarily for observability and tests.
func (e *Engine) ConsolidationCycles() int64 {
	e.consolMu.Lock()
	st := e.consol
	e.consolMu.Unlock()
	if st == nil {
		return 0
	}
	return atomic.LoadInt64(&st.cycles)
}

func (e *Engine) consolidationLoop(ctx context.Context, interval time.Duration, st *consolidationState) {
	defer close(st.done)
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			e.runConsolidationCycle(ctx)
			atomic.AddInt64(&st.cycles, 1)
		}
	}
}

// runConsolidationCycle performs a single consolidation pass. Errors are logged
// and swallowed: a background maintenance loop must not crash the process, and
// a transient failure in one phase should not prevent the next cycle.
func (e *Engine) runConsolidationCycle(ctx context.Context) {
	if err := ctx.Err(); err != nil {
		return
	}
	slog.Debug("harrier: consolidation: cycle start")

	// Phase 1: decay. RunDecay paginates internally and relies on the store's
	// WAL single-writer for safety, matching the decay scheduler.
	if err := RunDecay(ctx, e.store, e.DecayConfig); err != nil {
		slog.Warn("harrier: consolidation: decay failed", "error", err)
	}

	// Phase 2: conflict re-detection over recently-updated nodes.
	projects := e.reconcileRecentConflicts(ctx)

	// Phase 3: compaction per active project.
	for project := range projects {
		if err := ctx.Err(); err != nil {
			return
		}
		if _, err := e.Compact(ctx, project); err != nil {
			slog.Warn("harrier: consolidation: compact failed", "project", project, "error", err)
		}
	}
	slog.Debug("harrier: consolidation: cycle done")
}

// reconcileRecentConflicts re-runs conflict resolution over nodes updated
// within the recent window and returns the set of projects those nodes belong
// to (so the caller can target compaction at active projects only).
//
// The conflict resolver mutates nodes and edges, so the write portion is
// serialized under e.mu — the same lock the high-level Remember/Forget path
// uses — to avoid interleaving with those operations.
func (e *Engine) reconcileRecentConflicts(ctx context.Context) map[string]struct{} {
	projects := make(map[string]struct{})
	if e.conflict == nil {
		return projects
	}
	cutoff := time.Now().Add(-consolidationRecentWindow)

	nodes, err := e.store.ListNodes(ctx, storage.NodeFilter{Limit: consolidationRecentLimit})
	if err != nil {
		slog.Warn("harrier: consolidation: list recent nodes failed", "error", err)
		return projects
	}

	e.mu.Lock()
	defer e.mu.Unlock()
	for _, n := range nodes {
		if err := ctx.Err(); err != nil {
			return projects
		}
		if n.Confidence <= 0 {
			continue // archived
		}
		// Track every live project we touched so compaction can follow up.
		projects[n.Project] = struct{}{}
		// Only re-check genuinely recent nodes for contradictions.
		ref := n.UpdatedAt
		if !n.AccessedAt.IsZero() && n.AccessedAt.After(ref) {
			ref = n.AccessedAt
		}
		if ref.Before(cutoff) {
			continue
		}
		if _, err := e.conflict.CheckAndResolve(ctx, n); err != nil {
			slog.Warn("harrier: consolidation: conflict check failed", "node", n.ID, "error", err)
		}
	}
	return projects
}
