package engine

import (
	"strings"
)

// ExpandQuery adds related terms to improve BM25 recall.
// Handles common coding synonyms and abbreviations.
//
// Examples:
//
//	"auth" → "auth authentication authorize"
//	"db" → "db database"
//	"config" → "config configuration settings"
func ExpandQuery(query string) string {
	words := strings.Fields(strings.ToLower(query))
	var expanded []string
	seen := make(map[string]bool)

	for _, w := range words {
		if seen[w] {
			continue
		}
		seen[w] = true
		expanded = append(expanded, w)

		// Add synonyms
		if synonyms, ok := codingSynonyms[w]; ok {
			for _, s := range synonyms {
				if !seen[s] {
					seen[s] = true
					expanded = append(expanded, s)
				}
			}
		}
	}

	return strings.Join(expanded, " ")
}

var codingSynonyms = map[string][]string{
	"auth":          {"authentication", "authorize", "login"},
	"authn":         {"authentication"},
	"authz":         {"authorization"},
	"db":            {"database"},
	"database":      {"db"},
	"config":        {"configuration", "settings"},
	"configuration": {"config", "settings"},
	"settings":      {"config", "configuration"},
	"env":           {"environment"},
	"dep":           {"dependency", "dependencies"},
	"deps":          {"dependency", "dependencies"},
	"dependency":    {"deps", "dependencies"},
	"err":           {"error"},
	"error":         {"err", "exception", "failure"},
	"func":          {"function"},
	"function":      {"func", "method"},
	"method":        {"function", "func"},
	"pkg":           {"package"},
	"package":       {"pkg", "module"},
	"module":        {"package", "pkg"},
	"repo":          {"repository"},
	"repository":    {"repo"},
	"test":          {"testing", "spec"},
	"testing":       {"test", "spec"},
	"spec":          {"test", "specification"},
	"api":           {"endpoint", "route"},
	"endpoint":      {"api", "route"},
	"route":         {"endpoint", "api"},
	"deploy":        {"deployment", "ship"},
	"deployment":    {"deploy"},
	"ci":            {"continuous integration", "pipeline"},
	"cd":            {"continuous deployment"},
	"jwt":           {"token", "jsonwebtoken"},
	"token":         {"jwt"},
	"orm":           {"database", "query builder"},
	"cache":         {"caching", "memoize"},
	"caching":       {"cache"},
	"async":         {"asynchronous", "concurrent"},
	"sync":          {"synchronous"},
	"ws":            {"websocket"},
	"websocket":     {"ws", "realtime"},
	"msg":           {"message"},
	"message":       {"msg"},
	"req":           {"request"},
	"request":       {"req"},
	"res":           {"response"},
	"response":      {"res"},
	"middleware":    {"handler", "interceptor"},
	"handler":       {"controller", "middleware"},
	"controller":    {"handler"},
	"ui":            {"interface", "frontend"},
	"frontend":      {"ui", "client"},
	"backend":       {"server", "api"},
	"server":        {"backend"},
}
