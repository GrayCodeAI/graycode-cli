package cognitive

import (
	"testing"
)

func TestProceduralEngine_ObserveSequence(t *testing.T) {
	t.Parallel()
	e := NewProceduralEngine(DefaultProceduralConfig())

	// Observe a sequence
	p := e.ObserveSequence([]string{"Read", "Edit", "Bash"}, "fixing a bug", true)
	if p == nil {
		t.Fatal("expected a procedural memory, got nil")
	}
	if p.Frequency != 1 {
		t.Errorf("expected frequency 1, got %d", p.Frequency)
	}

	// Observe similar sequence — should increment frequency
	p2 := e.ObserveSequence([]string{"Read", "Edit", "Bash"}, "another fix", true)
	if p2 == nil {
		t.Fatal("expected a procedural memory, got nil")
	}
	if p2.Frequency != 2 {
		t.Errorf("expected frequency 2, got %d", p2.Frequency)
	}
}

func TestProceduralEngine_ObserveSequence_TooShort(t *testing.T) {
	t.Parallel()
	cfg := DefaultProceduralConfig()
	cfg.SequenceMinLen = 3
	e := NewProceduralEngine(cfg)

	p := e.ObserveSequence([]string{"Read"}, "single step", true)
	if p != nil {
		t.Error("expected nil for sequence shorter than min length")
	}
}

func TestProceduralEngine_SuggestSteps(t *testing.T) {
	t.Parallel()
	e := NewProceduralEngine(DefaultProceduralConfig())

	// Build up a pattern
	for i := 0; i < 5; i++ {
		e.ObserveSequence([]string{"Read", "Edit", "Bash", "Read"}, "workflow", true)
	}

	// Suggest from prefix
	suggestions := e.SuggestSteps([]string{"Read", "Edit"}, 3)
	if len(suggestions) == 0 {
		t.Fatal("expected suggestions, got none")
	}
	if suggestions[0] != "Bash" {
		t.Errorf("expected first suggestion 'Bash', got %q", suggestions[0])
	}
}

func TestProceduralEngine_SuggestSteps_NoMatch(t *testing.T) {
	t.Parallel()
	e := NewProceduralEngine(DefaultProceduralConfig())

	suggestions := e.SuggestSteps([]string{"NonExistent"}, 3)
	if suggestions != nil {
		t.Error("expected nil for no match")
	}
}

func TestProceduralEngine_GetPatterns(t *testing.T) {
	t.Parallel()
	e := NewProceduralEngine(DefaultProceduralConfig())

	e.ObserveSequence([]string{"A", "B", "C"}, "test1", true)
	e.ObserveSequence([]string{"D", "E", "F"}, "test2", false)

	patterns := e.GetPatterns(10)
	if len(patterns) != 2 {
		t.Errorf("expected 2 patterns, got %d", len(patterns))
	}
}

func TestProceduralEngine_Disabled(t *testing.T) {
	t.Parallel()
	cfg := DefaultProceduralConfig()
	cfg.Enabled = false
	e := NewProceduralEngine(cfg)

	p := e.ObserveSequence([]string{"A", "B", "C"}, "test", true)
	if p != nil {
		t.Error("expected nil when disabled")
	}
}

func TestProceduralEngine_Cleanup(t *testing.T) {
	t.Parallel()
	cfg := DefaultProceduralConfig()
	cfg.MinFrequency = 100 // very high threshold
	e := NewProceduralEngine(cfg)

	e.ObserveSequence([]string{"A", "B", "C"}, "test", true)
	removed := e.Cleanup()
	if removed != 1 {
		t.Errorf("expected 1 removed, got %d", removed)
	}
}

func TestLongestCommonSubseq(t *testing.T) {
	t.Parallel()
	tests := []struct {
		a, b []string
		want int
	}{
		{[]string{"A", "B", "C"}, []string{"A", "B", "C"}, 3},
		{[]string{"A", "B", "C"}, []string{"X", "Y", "Z"}, 0},
		{[]string{"A", "B", "C"}, []string{"A", "X", "C"}, 2},
		{nil, nil, 0},
	}
	for _, tt := range tests {
		got := longestCommonSubseq(tt.a, tt.b)
		if got != tt.want {
			t.Errorf("longestCommonSubseq(%v, %v) = %d, want %d", tt.a, tt.b, got, tt.want)
		}
	}
}

func TestSequenceSimilarity(t *testing.T) {
	t.Parallel()
	sim := sequenceSimilarity([]string{"A", "B", "C"}, []string{"A", "B", "C"})
	if sim != 1.0 {
		t.Errorf("expected 1.0, got %f", sim)
	}

	sim = sequenceSimilarity([]string{"A", "B", "C"}, []string{"X", "Y", "Z"})
	if sim != 0.0 {
		t.Errorf("expected 0.0, got %f", sim)
	}
}

func TestPrefixMatch(t *testing.T) {
	t.Parallel()
	seq := []string{"Read", "Edit", "Bash", "Read"}
	idx := prefixMatch(seq, []string{"Edit", "Bash"})
	if idx != 3 {
		t.Errorf("expected index 3, got %d", idx)
	}

	idx = prefixMatch(seq, []string{"Bash", "Read"})
	if idx != 4 {
		t.Errorf("expected index 4, got %d", idx)
	}

	idx = prefixMatch(seq, []string{"NonExistent"})
	if idx != -1 {
		t.Errorf("expected -1, got %d", idx)
	}
}

func TestProceduralEngine_SuccessRate(t *testing.T) {
	t.Parallel()
	e := NewProceduralEngine(DefaultProceduralConfig())

	// Record successes
	for i := 0; i < 5; i++ {
		e.ObserveSequence([]string{"A", "B", "C"}, "test", true)
	}

	patterns := e.GetPatterns(1)
	if len(patterns) == 0 {
		t.Fatal("expected at least one pattern")
	}
	if patterns[0].SuccessRate < 0.5 {
		t.Errorf("expected high success rate, got %f", patterns[0].SuccessRate)
	}
}
