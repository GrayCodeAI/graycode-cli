package cognitive

import (
	"testing"
)

func TestBoundaryDetector_DetectBoundaries(t *testing.T) {
	t.Parallel()
	bd := NewBoundaryDetector(DefaultBoundaryConfig())

	// Messages with a clear topic shift
	messages := []string{
		"Let's discuss the database schema design",
		"We need a users table with email and password columns",
		"The posts table should have a foreign key to users",
		"Now let's switch to the frontend framework",
		"We should use React with TypeScript for the UI",
		"The component library needs to support dark mode",
	}

	boundaries := bd.DetectBoundaries(messages)
	if len(boundaries) == 0 {
		t.Log("No boundaries detected (may be expected with short messages)")
	}
	// We expect at least some boundary detection between the DB and frontend topics
	for _, b := range boundaries {
		if b.Score < 0 || b.Score > 1 {
			t.Errorf("boundary score out of range: %f", b.Score)
		}
	}
}

func TestBoundaryDetector_TooFewMessages(t *testing.T) {
	t.Parallel()
	cfg := DefaultBoundaryConfig()
	cfg.MinMessages = 10
	bd := NewBoundaryDetector(cfg)

	messages := []string{"hello", "world"}
	boundaries := bd.DetectBoundaries(messages)
	if boundaries != nil {
		t.Error("expected nil for too few messages")
	}
}

func TestBoundaryDetector_Disabled(t *testing.T) {
	t.Parallel()
	cfg := DefaultBoundaryConfig()
	cfg.Enabled = false
	bd := NewBoundaryDetector(cfg)

	messages := []string{"a", "b", "c", "d", "e"}
	boundaries := bd.DetectBoundaries(messages)
	if boundaries != nil {
		t.Error("expected nil when disabled")
	}
}

func TestBoundaryDetector_SegmentByBoundaries(t *testing.T) {
	t.Parallel()
	bd := NewBoundaryDetector(DefaultBoundaryConfig())

	messages := []string{
		"topic A discussion one",
		"topic A discussion two",
		"topic A discussion three",
		"completely different subject here",
		"another message about new topic",
	}

	segments := bd.SegmentByBoundaries(messages)
	if len(segments) == 0 {
		t.Fatal("expected at least one segment")
	}

	// All messages should be accounted for
	total := 0
	for _, seg := range segments {
		total += len(seg)
	}
	if total != len(messages) {
		t.Errorf("expected %d total messages across segments, got %d", len(messages), total)
	}
}

func TestComputeShift_SameText(t *testing.T) {
	t.Parallel()
	bd := NewBoundaryDetector(DefaultBoundaryConfig())
	shift := bd.computeShift("hello world test", "hello world test")
	if shift != 0 {
		t.Errorf("expected 0 shift for identical text, got %f", shift)
	}
}

func TestComputeShift_DifferentText(t *testing.T) {
	t.Parallel()
	bd := NewBoundaryDetector(DefaultBoundaryConfig())
	shift := bd.computeShift("database schema design table", "react component frontend framework")
	if shift < 0.3 {
		t.Errorf("expected significant shift for different topics, got %f", shift)
	}
}

func TestExtractSignificantTerms(t *testing.T) {
	t.Parallel()
	terms := extractSignificantTerms("The database schema needs indexing")
	if len(terms) == 0 {
		t.Error("expected some terms")
	}
	// "the" should be filtered as stop word
	if terms["the"] > 0 {
		t.Error("'the' should be filtered as stop word")
	}
	// "database" should be included
	if terms["database"] == 0 {
		t.Error("'database' should be included")
	}
}

func TestExtractBoundaryTopic(t *testing.T) {
	t.Parallel()
	topic := extractBoundaryTopic("database schema design with tables and indexes")
	if topic == "general" {
		t.Error("expected non-general topic")
	}
}

func TestMergeWindow(t *testing.T) {
	t.Parallel()
	merged := mergeWindow([]string{"hello", "world"})
	if merged != "hello world" {
		t.Errorf("expected 'hello world', got %q", merged)
	}
}
