package engine

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// CommunityDetector finds clusters of related memories in the graph using
// label propagation (lightweight, no external deps). Each community gets
// a summary enabling "what are the main themes?" global queries.
//
// Based on GraphRAG (Microsoft): community detection → summarization → global retrieval.
type CommunityDetector struct {
	store storage.Storage
}

// Community represents a cluster of related memories.
type Community struct {
	ID      int
	NodeIDs []string
	Summary string
	Size    int
	Types   map[string]int // type → count
}

// NewCommunityDetector creates a detector.
func NewCommunityDetector(store storage.Storage) *CommunityDetector {
	return &CommunityDetector{store: store}
}

// Detect finds communities using iterative label propagation.
// Each node starts with its own label. Iteratively, each node adopts
// the most frequent label among its neighbors. Converges in ~5 iterations.
func (cd *CommunityDetector) Detect(ctx context.Context, maxIter int) ([]Community, error) {
	if maxIter <= 0 {
		maxIter = 10
	}

	// Load all nodes
	nodes, err := cd.store.ListNodes(ctx, storage.NodeFilter{Limit: 5000})
	if err != nil {
		return nil, err
	}
	if len(nodes) == 0 {
		return nil, nil
	}

	// Batch edge retrieval: single query instead of N+1
	nodeIDs := make([]string, len(nodes))
	for i, n := range nodes {
		nodeIDs[i] = n.ID
	}
	allEdges, err := cd.store.GetAllEdgesFor(ctx, nodeIDs)
	if err != nil {
		return nil, err
	}
	// Build adjacency: nodeID → []neighborID (undirected for community detection)
	adj := make(map[string][]string)
	for _, e := range allEdges {
		adj[e.FromID] = append(adj[e.FromID], e.ToID)
		adj[e.ToID] = append(adj[e.ToID], e.FromID)
	}

	// Initialize labels: each node gets its own label (index)
	nodeToIdx := make(map[string]int, len(nodes))
	for i, n := range nodes {
		nodeToIdx[n.ID] = i
	}
	labels := make([]int, len(nodes))
	for i := range labels {
		labels[i] = i
	}

	// Iterative label propagation
	for iter := 0; iter < maxIter; iter++ {
		changed := false
		for i, n := range nodes {
			neighbors := adj[n.ID]
			if len(neighbors) == 0 {
				continue
			}

			// Count neighbor labels
			labelCount := make(map[int]int)
			for _, nbr := range neighbors {
				if idx, ok := nodeToIdx[nbr]; ok {
					labelCount[labels[idx]]++
				}
			}

			// Adopt most frequent label
			maxCount := 0
			maxLabel := labels[i]
			for lbl, cnt := range labelCount {
				if cnt > maxCount {
					maxCount = cnt
					maxLabel = lbl
				}
			}
			if maxLabel != labels[i] {
				labels[i] = maxLabel
				changed = true
			}
		}
		if !changed {
			break
		}
	}

	// Group nodes by label
	communities := make(map[int][]string)
	for i, lbl := range labels {
		communities[lbl] = append(communities[lbl], nodes[i].ID)
	}

	// Build community objects (skip singletons)
	var result []Community
	commID := 0
	for _, nodeIDs := range communities {
		if len(nodeIDs) < 2 {
			continue
		}
		commID++
		types := make(map[string]int)
		for _, id := range nodeIDs {
			if idx, ok := nodeToIdx[id]; ok {
				types[nodes[idx].Type]++
			}
		}
		result = append(result, Community{
			ID:      commID,
			NodeIDs: nodeIDs,
			Size:    len(nodeIDs),
			Types:   types,
		})
	}

	// Sort by size descending
	sort.Slice(result, func(i, j int) bool {
		return result[i].Size > result[j].Size
	})

	return result, nil
}

// Summarize generates a summary for each community based on its node contents.
func (cd *CommunityDetector) Summarize(ctx context.Context, communities []Community) []Community {
	for i := range communities {
		nodes, err := cd.store.GetNodesBatch(ctx, communities[i].NodeIDs)
		if err != nil {
			continue
		}
		communities[i].Summary = buildCommunitySummary(nodes, communities[i].Types)
	}
	return communities
}

func buildCommunitySummary(nodes []*storage.Node, types map[string]int) string {
	if len(nodes) == 0 {
		return ""
	}

	// Build a summary from the highest-confidence nodes
	sort.Slice(nodes, func(i, j int) bool {
		return nodes[i].Confidence > nodes[j].Confidence
	})

	var sb strings.Builder
	// Type distribution
	var typeParts []string
	for t, c := range types {
		typeParts = append(typeParts, fmt.Sprintf("%d %ss", c, t))
	}
	sb.WriteString("Cluster of " + strings.Join(typeParts, ", ") + ". ")

	// Top 3 memories as the summary
	limit := 3
	if len(nodes) < limit {
		limit = len(nodes)
	}
	for i := 0; i < limit; i++ {
		content := nodes[i].Content
		if len(content) > 80 {
			content = content[:80] + "..."
		}
		sb.WriteString(content)
		if i < limit-1 {
			sb.WriteString("; ")
		}
	}

	return sb.String()
}

// FindCommunityForQuery returns the most relevant community for a query.
func (cd *CommunityDetector) FindCommunityForQuery(communities []Community, query string) *Community {
	queryLower := strings.ToLower(query)
	var best *Community
	bestScore := 0

	for i := range communities {
		score := 0
		summaryLower := strings.ToLower(communities[i].Summary)
		queryTerms := strings.Fields(queryLower)
		for _, term := range queryTerms {
			if strings.Contains(summaryLower, term) {
				score++
			}
		}
		if score > bestScore {
			bestScore = score
			best = &communities[i]
		}
	}
	return best
}
