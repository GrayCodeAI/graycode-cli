package engine

import (
	"context"
	"sort"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"github.com/GrayCodeAI/harrier/storage"
)

// RecallOpts configures a recall search.
type RecallOpts struct {
	Query              string
	Depth              int
	Limit              int
	Budget             int // max tokens in response (0 = no cap)
	Type               string
	Tier               int
	Project            string
	Alpha              float64           // hybrid retrieval blend: -1=RRF (default), 0=pure BM25, 1=pure vector, else alpha blend
	GraphTraverseDepth int               // if > 0, enrich results by traversing the graph from top results (0 = disabled)
	MetadataFilters    map[string]string // key-value metadata filters (AND semantics)
}

// RecallResult holds search results.
type RecallResult struct {
	Nodes []*storage.Node
	Edges []*storage.Edge
}

// Recall performs graph-aware hybrid search: BM25 seed → graph expand → rank.
func (e *Engine) Recall(ctx context.Context, opts RecallOpts) (*RecallResult, error) {
	start := time.Now()
	atomic.AddInt64(&e.metrics.Recalls, 1)
	if err := ctx.Err(); err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}
	if opts.Depth == 0 {
		opts.Depth = 2
	}
	if opts.Limit == 0 {
		opts.Limit = 10
	}

	// Use FusedRecall (RRF multi-signal) when query is non-empty for better retrieval
	if opts.Query != "" {
		// Check cache first
		if e.cache != nil {
			key := CacheKey(opts)
			if cached := e.cache.Get(key); cached != nil {
				telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
				return cached, nil
			}
			result, err := e.FusedRecall(ctx, opts)
			if err == nil && result != nil {
				e.cache.Put(key, result)
			}
			telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
			return result, err
		}
		result, err := e.FusedRecall(ctx, opts)
		telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
		return result, err
	}

	// For empty-query recalls (listing), use simple list + filter
	nodes, err := e.store.ListNodes(ctx, storage.NodeFilter{
		Type:    opts.Type,
		Project: opts.Project,
		Tier:    opts.Tier,
		Limit:   opts.Limit,
	})
	if err != nil {
		telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}
	sortByScore(nodes)
	if opts.Budget > 0 {
		nodes = TrimToTokenBudget(nodes, opts.Budget)
	}
	telemetry.MemoryRecallDuration.Record(ctx, time.Since(start).Seconds())
	return &RecallResult{Nodes: nodes}, nil
}

// VectorSearch performs HNSW-accelerated nearest neighbor search.
// Returns node IDs ranked by vector similarity.
// Lazily loads the HNSW index from disk if a save path is configured.
func (e *Engine) VectorSearch(query []float32, k int) []string {
	if e.hnsw == nil {
		if e.hnswPath != "" {
			if loaded, err := LoadHNSW(e.hnswPath); err == nil {
				e.hnsw = loaded
				e.hnsw.autoSavePath = e.hnswPath
			}
		}
		if e.hnsw == nil {
			return nil
		}
	}
	if e.hnsw.Size() == 0 || len(query) != e.hnsw.dim {
		return nil
	}
	start := time.Now()
	ids, _ := e.hnsw.Search(query, k)
	telemetry.HNSWSearchDuration.Record(context.Background(), time.Since(start).Seconds())
	telemetry.HNSWSearchCount.Add(context.Background(), 1)
	return ids
}

func filterNodes(nodes []*storage.Node, opts RecallOpts) []*storage.Node {
	if opts.Type == "" && opts.Tier == 0 && opts.Project == "" {
		return nodes
	}
	var out []*storage.Node
	for _, n := range nodes {
		if opts.Type != "" && n.Type != opts.Type {
			continue
		}
		if opts.Tier != 0 && n.Tier != opts.Tier {
			continue
		}
		if opts.Project != "" && n.Project != opts.Project {
			continue
		}
		out = append(out, n)
	}
	return out
}

func sortByScore(nodes []*storage.Node) {
	now := time.Now()
	sort.Slice(nodes, func(i, j int) bool {
		return score(nodes[i], now) > score(nodes[j], now)
	})
}

func score(n *storage.Node, now time.Time) float64 {
	// Recency: exponential decay based on last access or update
	recency := 1.0
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if !ref.IsZero() {
		days := now.Sub(ref).Hours() / 24
		if days > 0 {
			recency = 1.0 / (1.0 + days/30.0)
		}
	}

	// Tier boost
	tierBoost := 1.0
	switch n.Tier {
	case 1:
		tierBoost = 2.0
	case 2:
		tierBoost = 1.3
	}

	// Pinned nodes get a fixed high boost
	pinnedBoost := 1.0
	if n.Pinned {
		pinnedBoost = 3.0
	}

	return n.Confidence * recency * tierBoost * pinnedBoost * (1.0 + float64(n.AccessCount)*0.05)
}
