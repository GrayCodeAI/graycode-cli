package hooks

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func setupTestEngine(t *testing.T) (*engine.Engine, storage.Storage) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { store.Close() })

	g := graph.New(store, store.DB())
	eng := engine.New(store, g)
	t.Cleanup(func() { eng.Close() })
	return eng, store
}

func TestGitHookRunner_Commit(t *testing.T) {
	t.Parallel()
	eng, store := setupTestEngine(t)
	ctx := context.Background()
	runner := NewGitHookRunner(eng, "proj1")

	input := &GitHookInput{
		Type:          GitPreCommit,
		Project:       "proj1",
		CommitMessage: "fix(auth): resolve JWT expiration bug",
		ChangedFiles:  []string{"auth/jwt.go"},
		Branch:        "main",
	}

	if err := runner.Run(ctx, input); err != nil {
		t.Fatalf("GitHookRunner.Run: %v", err)
	}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: "proj1"})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}

	if len(nodes) == 0 {
		t.Fatal("expected stored memory node from git commit hook")
	}
}

func TestBashHookRunner_PostExecution(t *testing.T) {
	t.Parallel()
	eng, store := setupTestEngine(t)
	ctx := context.Background()
	runner := NewBashHookRunner(eng, "proj1")

	input := &BashExecutionInput{
		Command:  "make test",
		ExitCode: 1,
		Error:    "test failure in auth_test.go",
		Project:  "proj1",
	}

	if err := runner.PostExecution(ctx, input); err != nil {
		t.Fatalf("BashHookRunner.PostExecution: %v", err)
	}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: "proj1"})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}

	if len(nodes) == 0 {
		t.Fatal("expected stored memory node from bash hook execution")
	}
	// ListNodes is ordered by recency (updated_at DESC), so locate the bug
	// node instead of assuming a position.
	var found bool
	for _, n := range nodes {
		if n.Type == "bug" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected a bug node for non-zero exit code, got types %v", func() []string {
			var types []string
			for _, n := range nodes {
				types = append(types, n.Type)
			}
			return types
		}())
	}
}
