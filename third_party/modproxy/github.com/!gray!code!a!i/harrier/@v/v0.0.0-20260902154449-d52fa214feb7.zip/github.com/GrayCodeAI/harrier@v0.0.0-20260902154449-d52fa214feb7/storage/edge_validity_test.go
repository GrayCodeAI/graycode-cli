package storage

import (
	"context"
	"testing"
	"time"

	"github.com/google/uuid"
)

// seedNodes inserts two nodes so edges satisfy the FK constraint.
func seedNodes(t *testing.T, s *Store, ids ...string) {
	t.Helper()
	ctx := context.Background()
	for i, id := range ids {
		n := &Node{
			ID:          id,
			Type:        "fact",
			Content:     "node " + id,
			ContentHash: "h" + id,
			Scope:       "project",
			Project:     "p",
			Confidence:  1.0,
		}
		// Distinct hashes already; index also keys on scope/project.
		_ = i
		if err := s.CreateNode(ctx, n); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}
}

func TestCreateEdge_SetsValidAt(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	seedNodes(t, s, "a", "b")

	before := time.Now().UTC().Add(-time.Second)
	e := &Edge{ID: uuid.New().String(), FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0}
	if err := s.CreateEdge(ctx, e); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}
	// The struct should have been stamped in place.
	if e.ValidAt.IsZero() {
		t.Fatal("expected ValidAt to be set on the edge after CreateEdge")
	}

	got, err := s.GetEdge(ctx, e.ID)
	if err != nil {
		t.Fatalf("GetEdge: %v", err)
	}
	if got.ValidAt.IsZero() {
		t.Fatal("expected persisted valid_at to be non-NULL")
	}
	if got.ValidAt.Before(before) {
		t.Errorf("valid_at %v is before test start %v", got.ValidAt, before)
	}
	if !got.InvalidAt.IsZero() {
		t.Errorf("expected invalid_at to be NULL on a fresh edge, got %v", got.InvalidAt)
	}
}

func TestInvalidateEdge_SetsInvalidAt(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	seedNodes(t, s, "a", "b")

	e := &Edge{ID: uuid.New().String(), FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0}
	if err := s.CreateEdge(ctx, e); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}
	if err := s.InvalidateEdge(ctx, e.ID); err != nil {
		t.Fatalf("InvalidateEdge: %v", err)
	}
	got, err := s.GetEdge(ctx, e.ID)
	if err != nil {
		t.Fatalf("GetEdge: %v", err)
	}
	if got.InvalidAt.IsZero() {
		t.Fatal("expected invalid_at to be set after InvalidateEdge")
	}
}

func TestGetValidEdges_PointInTime(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	seedNodes(t, s, "a", "b", "c")

	t0 := time.Now().UTC()
	// Edge e1: valid from t0, invalidated at t0+2h.
	e1 := &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0, ValidAt: t0}
	// Edge e2: only becomes valid at t0+1h (future relative to t0).
	e2 := &Edge{ID: "e2", FromID: "a", ToID: "c", Type: "led_to", Weight: 1.0, ValidAt: t0.Add(time.Hour)}
	if err := s.CreateEdge(ctx, e1); err != nil {
		t.Fatalf("CreateEdge e1: %v", err)
	}
	if err := s.CreateEdge(ctx, e2); err != nil {
		t.Fatalf("CreateEdge e2: %v", err)
	}
	// Close e1's validity window at t0+2h via a direct update so the test is
	// deterministic (InvalidateEdge stamps "now").
	if _, err := s.q().ExecContext(ctx, `UPDATE edges SET invalid_at=? WHERE id=?`, t0.Add(2*time.Hour), "e1"); err != nil {
		t.Fatalf("set invalid_at: %v", err)
	}

	tests := []struct {
		name string
		at   time.Time
		want []string // expected edge IDs valid at `at`
	}{
		{"at t0 only e1 active", t0, []string{"e1"}},
		{"at t0+90m both active", t0.Add(90 * time.Minute), []string{"e1", "e2"}},
		{"at t0+3h only e2 active", t0.Add(3 * time.Hour), []string{"e2"}},
		{"before t0 nothing active", t0.Add(-time.Hour), nil},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			edges, err := s.GetValidEdgesFrom(ctx, "a", tt.at)
			if err != nil {
				t.Fatalf("GetValidEdgesFrom: %v", err)
			}
			got := map[string]bool{}
			for _, e := range edges {
				got[e.ID] = true
			}
			if len(got) != len(tt.want) {
				t.Fatalf("at %v: got %d edges %v, want %v", tt.at, len(got), keys(got), tt.want)
			}
			for _, id := range tt.want {
				if !got[id] {
					t.Errorf("at %v: missing expected edge %s (got %v)", tt.at, id, keys(got))
				}
			}
		})
	}
}

func TestGetValidEdges_ZeroTimeMeansNow(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	seedNodes(t, s, "a", "b")

	e := &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0}
	if err := s.CreateEdge(ctx, e); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}
	// Zero `at` => now: a fresh edge should be returned.
	edges, err := s.GetValidEdgesFrom(ctx, "a", time.Time{})
	if err != nil {
		t.Fatalf("GetValidEdgesFrom: %v", err)
	}
	if len(edges) != 1 {
		t.Fatalf("expected 1 currently-valid edge, got %d", len(edges))
	}

	// After invalidation, the "now" view should exclude it.
	if err := s.InvalidateEdge(ctx, "e1"); err != nil {
		t.Fatalf("InvalidateEdge: %v", err)
	}
	edges, err = s.GetValidEdgesFrom(ctx, "a", time.Time{})
	if err != nil {
		t.Fatalf("GetValidEdgesFrom after invalidate: %v", err)
	}
	if len(edges) != 0 {
		t.Fatalf("expected 0 currently-valid edges after invalidation, got %d", len(edges))
	}
}

func keys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
