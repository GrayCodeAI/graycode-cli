package engine

import (
	"context"
	"fmt"
	"sort"

	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/intent"
	"github.com/GrayCodeAI/harrier/storage"
)

const rrfK = 60 // RRF constant

// HybridSearch performs 3-stage retrieval: BM25 → vector → graph expansion → RRF fusion.
type HybridSearch struct {
	store    storage.Storage
	graph    graph.Graph
	provider embeddings.Provider // nil = BM25 only
	hnsw     *HNSW               // optional HNSW index for fast vector search
}

// NewHybridSearch creates a hybrid search engine.
func NewHybridSearch(store storage.Storage, g graph.Graph, provider embeddings.Provider) *HybridSearch {
	return &HybridSearch{store: store, graph: g, provider: provider}
}

// SetHNSW attaches an HNSW index for fast approximate nearest neighbor search.
func (h *HybridSearch) SetHNSW(index *HNSW) {
	h.hnsw = index
}

// ScoredNode is a node with a combined relevance score.
type ScoredNode struct {
	Node  *storage.Node
	Score float64
}

// Search runs hybrid search and returns ranked nodes.
// 4-path retrieval: BM25 + vector + graph (intent-aware) + temporal recency
// Based on Hindsight's multi-strategy approach.
func (h *HybridSearch) Search(ctx context.Context, query string, opts RecallOpts) ([]*ScoredNode, error) {
	if opts.Depth == 0 {
		opts.Depth = 2
	}
	if opts.Limit == 0 {
		opts.Limit = 10
	}

	// Classify query intent (MAGMA: intent-aware routing)
	queryIntent := intent.Classify(query)

	// Path 1: BM25 seed nodes
	bm25Nodes, err := h.store.SearchNodes(ctx, query, opts.Limit*2)
	if err != nil {
		return nil, fmt.Errorf("bm25 search: %w", err)
	}
	bm25Ranks := rankMap(bm25Nodes)

	// Path 2: Vector seed nodes (if provider available)
	vectorRanks := map[string]int{}
	if h.provider != nil {
		// Embed in query mode: asymmetric models (e.g. Cohere v3) expect
		// search_query for queries vs search_document for stored content.
		vec, err := h.provider.EmbedWithMode(ctx, query, embeddings.ModeQuery)
		if err == nil {
			vectorRanks = h.vectorSearch(ctx, vec, opts.Limit*2)
		}
	}

	// Path 3: Intent-aware graph expansion (MAGMA: adaptive traversal)
	graphRanks := map[string]int{}
	rank := 1
	for _, id := range mergeKeys(bm25Ranks, vectorRanks) {
		ids, err := h.graph.IntentBFS(ctx, id, opts.Depth, queryIntent)
		if err != nil {
			continue
		}
		for _, nid := range ids {
			if _, seen := graphRanks[nid]; !seen {
				graphRanks[nid] = rank
				rank++
			}
		}
	}

	// Path 4: Temporal recency (Hindsight-inspired)
	// For When/temporal queries, boost recently accessed nodes
	temporalRanks := map[string]int{}
	if queryIntent == intent.IntentWhen {
		recent, _ := h.store.ListNodes(ctx, storage.NodeFilter{Project: opts.Project})
		// Sort by accessed_at descending (most recent first)
		sort.Slice(recent, func(i, j int) bool {
			return recent[i].AccessedAt.After(recent[j].AccessedAt)
		})
		for i, n := range recent {
			if i >= opts.Limit*2 {
				break
			}
			temporalRanks[n.ID] = i + 1
		}
	}

	// Stage 3: RRF fusion of all 4 paths
	allIDs := mergeKeys(bm25Ranks, vectorRanks, graphRanks, temporalRanks)
	nodes, _ := h.store.GetNodesBatch(ctx, allIDs)
	nodeByID := make(map[string]*storage.Node, len(nodes))
	for _, n := range nodes {
		nodeByID[n.ID] = n
	}
	scored := make([]*ScoredNode, 0, len(allIDs))
	for _, id := range allIDs {
		node, ok := nodeByID[id]
		if !ok {
			continue
		}
		if opts.Type != "" && node.Type != opts.Type {
			continue
		}
		if opts.Project != "" && node.Project != opts.Project {
			continue
		}
		rrf := rrfScore(bm25Ranks[id], vectorRanks[id], graphRanks[id], temporalRanks[id])
		scored = append(scored, &ScoredNode{Node: node, Score: rrf})
	}

	// Sort by RRF score descending
	sort.Slice(scored, func(i, j int) bool {
		return scored[i].Score > scored[j].Score
	})

	if len(scored) > opts.Limit {
		scored = scored[:opts.Limit]
	}
	return scored, nil
}

// vectorSearch returns a rank map of node IDs by cosine similarity.
// Uses HNSW index when available for O(log n) approximate search,
// falls back to brute-force linear scan otherwise.
func (h *HybridSearch) vectorSearch(ctx context.Context, queryVec []float32, limit int) map[string]int {
	// Fast path: use HNSW index if available
	if h.hnsw != nil && h.hnsw.Size() > 0 {
		ids, _ := h.hnsw.Search(queryVec, limit)
		ranks := map[string]int{}
		for i, id := range ids {
			ranks[id] = i + 1
		}
		return ranks
	}

	// Fallback: brute-force scan of all embeddings
	type pair struct {
		id    string
		score float32
	}
	var pairs []pair

	// Scope the scan to the active provider's model: stored vectors from a
	// different model occupy an incompatible space and would produce meaningless
	// cosine scores. The ingest path records model = provider.Name() (rest.go).
	var model string
	if h.provider != nil {
		model = h.provider.Name()
	}

	const batchSize = 500
	offset := 0
	for {
		batch, err := h.store.GetEmbeddingsBatch(ctx, model, offset, batchSize)
		if err != nil || len(batch) == 0 {
			break
		}
		for id, vec := range batch {
			pairs = append(pairs, pair{id, embeddings.Cosine(queryVec, vec)})
		}
		if len(batch) < batchSize {
			break
		}
		offset += batchSize
	}

	sort.Slice(pairs, func(i, j int) bool { return pairs[i].score > pairs[j].score })
	ranks := map[string]int{}
	for i, p := range pairs {
		if i >= limit {
			break
		}
		ranks[p.id] = i + 1
	}
	return ranks
}

// rrfScore computes Reciprocal Rank Fusion score from multiple rank lists.
// rank=0 means not present in that list.
func rrfScore(ranks ...int) float64 {
	score := 0.0
	for _, r := range ranks {
		if r > 0 {
			score += 1.0 / float64(rrfK+r)
		}
	}
	return score
}

func rankMap(nodes []*storage.Node) map[string]int {
	m := map[string]int{}
	for i, n := range nodes {
		m[n.ID] = i + 1
	}
	return m
}

func mergeKeys(maps ...map[string]int) []string {
	seen := map[string]bool{}
	var keys []string
	for _, m := range maps {
		for k := range m {
			if !seen[k] {
				seen[k] = true
				keys = append(keys, k)
			}
		}
	}
	return keys
}
