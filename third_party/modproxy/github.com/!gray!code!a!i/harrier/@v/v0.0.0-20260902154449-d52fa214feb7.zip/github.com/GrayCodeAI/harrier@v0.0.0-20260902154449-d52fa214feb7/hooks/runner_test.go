package hooks

import (
	"context"
	"path/filepath"
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// setupRunner builds a Runner backed by a real temp SQLite store. The project
// directory is a TempDir so the session file (<project>/.harrier/.session) is fully
// isolated per-test and cleaned up automatically.
func setupRunner(t *testing.T) (*Runner, *storage.Store, string) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatalf("NewStore: %v", err)
	}
	t.Cleanup(func() { _ = store.Close() })

	eng := engine.New(store, graph.New(store, store.DB()))
	t.Cleanup(func() { eng.Close() })

	project := t.TempDir()
	return New(eng, project), store, project
}

func TestReadInput_DecodesJSON(t *testing.T) {
	t.Parallel()
	r := strings.NewReader(`{"session_id":"s1","project":"p1","agent":"a1","tool_name":"Write","tool_input":"main.go"}`)
	in, err := ReadInput(r)
	if err != nil {
		t.Fatalf("ReadInput: %v", err)
	}
	if in.SessionID != "s1" {
		t.Errorf("SessionID = %q, want s1", in.SessionID)
	}
	if in.Project != "p1" {
		t.Errorf("Project = %q, want p1", in.Project)
	}
	if in.Agent != "a1" {
		t.Errorf("Agent = %q, want a1", in.Agent)
	}
	if in.ToolName != "Write" {
		t.Errorf("ToolName = %q, want Write", in.ToolName)
	}
	if in.ToolInput != "main.go" {
		t.Errorf("ToolInput = %q, want main.go", in.ToolInput)
	}
}

func TestReadInput_Empty(t *testing.T) {
	t.Parallel()
	in, err := ReadInput(strings.NewReader(""))
	if err != nil {
		t.Fatalf("ReadInput on empty reader: %v", err)
	}
	if in == nil {
		t.Fatal("expected non-nil HookInput")
	}
	if *in != (HookInput{}) {
		t.Errorf("expected zero-value HookInput, got %+v", *in)
	}
}

func TestReadInput_InvalidJSON(t *testing.T) {
	t.Parallel()
	in, err := ReadInput(strings.NewReader(`{"session_id": `))
	if err == nil {
		t.Fatal("expected error decoding malformed JSON")
	}
	if in == nil {
		t.Fatal("expected non-nil HookInput even on error")
	}
	if !strings.Contains(err.Error(), "decode hook input") {
		t.Errorf("error = %v, want it to mention 'decode hook input'", err)
	}
}

func TestNew_SetsFields(t *testing.T) {
	t.Parallel()
	r, _, project := setupRunner(t)
	if r.eng == nil {
		t.Error("expected non-nil engine")
	}
	if r.project != project {
		t.Errorf("project = %q, want %q", r.project, project)
	}
}

func TestNew_EmptyProjectDefaultsToCwd(t *testing.T) {
	t.Parallel()
	store, err := storage.NewStore(filepath.Join(t.TempDir(), "t.db"))
	if err != nil {
		t.Fatalf("NewStore: %v", err)
	}
	t.Cleanup(func() { _ = store.Close() })
	eng := engine.New(store, graph.New(store, store.DB()))
	t.Cleanup(func() { eng.Close() })

	r := New(eng, "")
	if r.project == "" {
		t.Error("expected empty project to default to a non-empty working dir")
	}
}

func TestSessionStart_CreatesSessionAndFile(t *testing.T) {
	t.Parallel()
	r, store, project := setupRunner(t)
	ctx := context.Background()

	if err := r.SessionStart(ctx, &HookInput{Agent: "agent-a"}); err != nil {
		t.Fatalf("SessionStart: %v", err)
	}

	// A session record must exist for the project.
	sessions, err := store.ListSessions(ctx, project, 0)
	if err != nil {
		t.Fatalf("ListSessions: %v", err)
	}
	if len(sessions) != 1 {
		t.Fatalf("expected 1 session, got %d", len(sessions))
	}
	if sessions[0].Agent != "agent-a" {
		t.Errorf("session agent = %q, want agent-a", sessions[0].Agent)
	}

	// The session id must have been written where readSessionID expects it.
	got := readSessionID(project)
	if got != sessions[0].ID {
		t.Errorf("session file id = %q, want %q", got, sessions[0].ID)
	}
}

func TestPostToolUse_StoresObservation(t *testing.T) {
	t.Parallel()
	r, store, project := setupRunner(t)
	ctx := context.Background()

	if err := r.SessionStart(ctx, &HookInput{Agent: "agent-a"}); err != nil {
		t.Fatalf("SessionStart: %v", err)
	}

	// A Write tool scores 0.7 (>= 0.3 threshold) so it is captured, and
	// classifyTool maps Write -> "convention".
	in := &HookInput{
		Agent:     "agent-a",
		ToolName:  "Write",
		ToolInput: "internal/config/config.go",
	}
	if err := r.PostToolUse(ctx, in); err != nil {
		t.Fatalf("PostToolUse: %v", err)
	}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Type: "convention", Project: project})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}
	if len(nodes) != 1 {
		t.Fatalf("expected 1 convention node, got %d", len(nodes))
	}
	if !strings.Contains(nodes[0].Content, "config.go") {
		t.Errorf("node content = %q, want it to reference the tool input", nodes[0].Content)
	}
}

func TestPostToolUse_EmptyToolNameNoop(t *testing.T) {
	t.Parallel()
	r, store, _ := setupRunner(t)
	ctx := context.Background()

	before := storeNodeCount(t, store, ctx)
	if err := r.PostToolUse(ctx, &HookInput{Agent: "agent-a"}); err != nil {
		t.Fatalf("PostToolUse: %v", err)
	}
	if after := storeNodeCount(t, store, ctx); after != before {
		t.Errorf("node count changed from %d to %d on empty tool name", before, after)
	}
}

func TestPostToolUse_LowSignalReadFiltered(t *testing.T) {
	t.Parallel()
	r, store, _ := setupRunner(t)
	ctx := context.Background()

	before := storeNodeCount(t, store, ctx)
	// Read scores 0.2 and the short input/output drops it further: below 0.3.
	in := &HookInput{
		Agent:      "agent-a",
		ToolName:   "Read",
		ToolInput:  "x",
		ToolOutput: "y",
	}
	if err := r.PostToolUse(ctx, in); err != nil {
		t.Fatalf("PostToolUse: %v", err)
	}
	if after := storeNodeCount(t, store, ctx); after != before {
		t.Errorf("low-signal Read should be filtered: count %d -> %d", before, after)
	}
}

func TestSessionEnd_StoresSummaryAndRemovesFile(t *testing.T) {
	t.Parallel()
	r, store, project := setupRunner(t)
	ctx := context.Background()

	if err := r.SessionStart(ctx, &HookInput{Agent: "agent-a"}); err != nil {
		t.Fatalf("SessionStart: %v", err)
	}

	in := &HookInput{Agent: "agent-a", Summary: "Shipped the auth refactor and migrated to JWT tokens"}
	if err := r.SessionEnd(ctx, in); err != nil {
		t.Fatalf("SessionEnd: %v", err)
	}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Type: "session", Project: project})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}
	if len(nodes) != 1 {
		t.Fatalf("expected 1 session-summary node, got %d", len(nodes))
	}
	if !strings.Contains(nodes[0].Content, "auth refactor") {
		t.Errorf("summary node content = %q, want it to contain the summary", nodes[0].Content)
	}

	// SessionEnd cleans up the session file.
	if got := readSessionID(project); got != "" {
		t.Errorf("expected session file removed, readSessionID returned %q", got)
	}
}

func TestSessionEnd_NoSessionNoop(t *testing.T) {
	t.Parallel()
	r, store, _ := setupRunner(t)
	ctx := context.Background()

	// No SessionStart -> no session file -> readSessionID == "" -> early return.
	before := storeNodeCount(t, store, ctx)
	if err := r.SessionEnd(ctx, &HookInput{Summary: "ignored because no active session here"}); err != nil {
		t.Fatalf("SessionEnd: %v", err)
	}
	if after := storeNodeCount(t, store, ctx); after != before {
		t.Errorf("SessionEnd with no session should be a noop: %d -> %d", before, after)
	}
}

func TestCaptureMessages_StoresMemories(t *testing.T) {
	t.Parallel()
	r, store, project := setupRunner(t)
	ctx := context.Background()

	cc := NewConversationCapture(r.eng, project)
	msgs := []ConversationMessage{
		{Role: "system", Content: "We decided to use PostgreSQL for the database and ignore this system line"},
		{Role: "user", Content: "We decided to use PostgreSQL instead of MySQL for the primary datastore"},
		{Role: "assistant", Content: "Always use context.Context as the first parameter; this is our convention"},
		{Role: "user", Content: "ok"}, // too short, no memory
	}

	stored := cc.CaptureMessages(ctx, msgs, "sess-1", "agent-a")
	if stored != 2 {
		t.Fatalf("CaptureMessages stored = %d, want 2 (decision + convention; system & short skipped)", stored)
	}

	decisions, err := store.ListNodes(ctx, storage.NodeFilter{Type: "decision", Project: project})
	if err != nil {
		t.Fatalf("ListNodes decision: %v", err)
	}
	if len(decisions) != 1 {
		t.Errorf("expected 1 decision node, got %d", len(decisions))
	}

	conventions, err := store.ListNodes(ctx, storage.NodeFilter{Type: "convention", Project: project})
	if err != nil {
		t.Fatalf("ListNodes convention: %v", err)
	}
	if len(conventions) != 1 {
		t.Errorf("expected 1 convention node, got %d", len(conventions))
	}
}

func TestCaptureMessages_Empty(t *testing.T) {
	t.Parallel()
	r, _, project := setupRunner(t)
	cc := NewConversationCapture(r.eng, project)
	if n := cc.CaptureMessages(context.Background(), nil, "sess-1", "agent-a"); n != 0 {
		t.Errorf("CaptureMessages on empty slice = %d, want 0", n)
	}
}

func storeNodeCount(t *testing.T, store *storage.Store, ctx context.Context) int {
	t.Helper()
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}
	return len(nodes)
}
