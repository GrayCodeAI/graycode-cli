package engine

// This file implements session + permanent memory tiers, inspired by
// cognee's two-tier memory system. Session memories are fast-cached and
// synced to the permanent graph at session end.
//
// The pattern:
//   1. During a session, Remember stores nodes with SourceSession set
//   2. Recall first checks session-tier nodes, then falls through to
//      the permanent graph
//   3. At session end, SyncSessionToPermanent promotes session nodes
//      to permanent status (removes session ID, increases confidence)

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// SessionTier holds the fast in-memory cache of session-scoped memories.
// This is the "session cache" tier — fast lookups for the current session.
type SessionTier struct {
	entries map[string]*storage.Node // nodeID -> node
	mu      syncRWMutex
}

// NewSessionTier creates an empty session tier cache.
func NewSessionTier() *SessionTier {
	return &SessionTier{
		entries: make(map[string]*storage.Node),
	}
}

// Put stores a node in the session cache.
func (st *SessionTier) Put(n *storage.Node) {
	st.mu.Lock()
	defer st.mu.Unlock()
	st.entries[n.ID] = n
}

// Get retrieves a node from the session cache.
func (st *SessionTier) Get(id string) (*storage.Node, bool) {
	st.mu.RLock()
	defer st.mu.RUnlock()
	n, ok := st.entries[id]
	return n, ok
}

// List returns all nodes in the session cache for a given session.
func (st *SessionTier) List(sessionID string) []*storage.Node {
	st.mu.RLock()
	defer st.mu.RUnlock()
	var out []*storage.Node
	for _, n := range st.entries {
		if n.SourceSession == sessionID {
			out = append(out, n)
		}
	}
	return out
}

// Clear removes all entries for a given session.
func (st *SessionTier) Clear(sessionID string) int {
	st.mu.Lock()
	defer st.mu.Unlock()
	count := 0
	for id, n := range st.entries {
		if n.SourceSession == sessionID {
			delete(st.entries, id)
			count++
		}
	}
	return count
}

// syncRWMutex is an alias to sync.RWMutex for use in the SessionTier struct.
type syncRWMutex = sync.RWMutex

// --- Engine methods for session + permanent tiers ---

// RememberWithSession stores a memory node with session context.
// This is the session-tier entry point: nodes are stored in both the
// permanent graph (via Remember) and the session cache.
func (e *Engine) RememberWithSession(ctx context.Context, in RememberInput, sessionID string) (*storage.Node, error) {
	in.Session = sessionID
	node, err := e.Remember(ctx, in)
	if err != nil {
		return nil, err
	}

	// Cache in session tier.
	if e.sessionTier != nil {
		e.sessionTier.Put(node)
	}

	return node, nil
}

// RecallWithSession performs session-aware recall: first checks the
// session cache, then falls through to the permanent graph.
// This mirrors cognee's session memory + permanent graph pattern.
func (e *Engine) RecallWithSession(ctx context.Context, opts RecallOpts, sessionID string) (*RecallResult, error) {
	if sessionID == "" {
		return e.Recall(ctx, opts)
	}

	// 1. Check session cache first.
	var sessionNodes []*storage.Node
	if e.sessionTier != nil {
		sessionNodes = e.sessionTier.List(sessionID)
	}

	// Filter session nodes by query/type/project.
	filtered := filterSessionNodes(sessionNodes, opts)

	// If we have enough results from the session, return them.
	if len(filtered) >= opts.Limit {
		return &RecallResult{Nodes: filtered[:opts.Limit]}, nil
	}

	// 2. Fall through to permanent graph.
	permanentResult, err := e.Recall(ctx, opts)
	if err != nil {
		return nil, err
	}

	// 3. Merge session + permanent results, deduplicating by ID.
	seen := make(map[string]bool)
	merged := make([]*storage.Node, 0, len(filtered)+len(permanentResult.Nodes))

	for _, n := range filtered {
		if !seen[n.ID] {
			seen[n.ID] = true
			merged = append(merged, n)
		}
	}
	for _, n := range permanentResult.Nodes {
		if !seen[n.ID] {
			seen[n.ID] = true
			merged = append(merged, n)
		}
	}

	// Truncate to limit.
	if opts.Limit > 0 && len(merged) > opts.Limit {
		merged = merged[:opts.Limit]
	}

	return &RecallResult{Nodes: merged, Edges: permanentResult.Edges}, nil
}

// SyncSessionToPermanent promotes session-scoped memories to permanent
// status. This is called at session end to sync the session cache into
// the permanent graph.
//
// Promotion steps:
//  1. Remove SourceSession from each node (makes it permanent)
//  2. Increase confidence (session memories are validated by use)
//  3. Clear the session cache
func (e *Engine) SyncSessionToPermanent(ctx context.Context, sessionID string) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}

	// Get all session nodes from the permanent graph.
	nodes, err := e.store.ListNodes(ctx, storage.NodeFilter{
		SourceSession: sessionID,
		Limit:         10000,
	})
	if err != nil {
		return 0, fmt.Errorf("list session nodes: %w", err)
	}

	promoted := 0
	for _, n := range nodes {
		if err := ctx.Err(); err != nil {
			break
		}

		e.mu.Lock()
		n.SourceSession = "" // make permanent
		n.Confidence = minFloat(n.Confidence+0.3, 1.0)
		n.UpdatedAt = time.Now()
		if err := e.store.UpdateNode(ctx, n); err != nil {
			e.mu.Unlock()
			continue
		}
		e.mu.Unlock()
		promoted++
	}

	// Clear session cache.
	if e.sessionTier != nil {
		e.sessionTier.Clear(sessionID)
	}

	atomic.AddInt64(&e.metrics.Remembers, int64(promoted))
	return promoted, nil
}

// filterSessionNodes filters session-cached nodes by the recall options.
func filterSessionNodes(nodes []*storage.Node, opts RecallOpts) []*storage.Node {
	var out []*storage.Node
	for _, n := range nodes {
		if opts.Type != "" && n.Type != opts.Type {
			continue
		}
		if opts.Project != "" && n.Project != opts.Project {
			continue
		}
		if len(opts.MetadataFilters) > 0 {
			// Simple metadata filter check
			match := true
			for k, v := range opts.MetadataFilters {
				if n.Metadata == nil || n.Metadata[k] != v {
					match = false
					break
				}
			}
			if !match {
				continue
			}
		}
		out = append(out, n)
	}
	return out
}
