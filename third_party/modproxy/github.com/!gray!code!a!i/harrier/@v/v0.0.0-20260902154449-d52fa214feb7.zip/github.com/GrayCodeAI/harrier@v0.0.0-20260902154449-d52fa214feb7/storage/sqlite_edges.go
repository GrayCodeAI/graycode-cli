// This file is part of package storage. It holds edge, graph-statistics,
// and cycle-check storage operations split verbatim out of sqlite.go for
// readability; behavior is unchanged.

package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

// --- Edges ---

func (s *Store) CreateEdge(ctx context.Context, e *Edge) error {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	// Retry on SQLITE_BUSY: SelfLink runs outside the engine's write lock and
	// competes for the SQLite write lock with concurrent graph operations.
	return retryOnBusy(func() error {
		return createEdgeQ(ctx, s.q(), e)
	}, 5, 2*time.Millisecond)
}

func createEdgeQ(ctx context.Context, q queryable, e *Edge) error {
	// Temporal validity: an edge becomes valid the moment it is created unless
	// the caller explicitly supplied a valid_at. This keeps valid_at "live" for
	// every insert path without requiring callers to set it. CreatedAt is also
	// defaulted to now so the columns are never NULL for new rows.
	now := time.Now().UTC()
	if e.ValidAt.IsZero() {
		e.ValidAt = now
	}
	if e.CreatedAt.IsZero() {
		e.CreatedAt = now
	}
	_, err := q.ExecContext(ctx, `INSERT INTO edges (id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		e.ID, e.FromID, e.ToID, e.Type, e.Acyclic, e.Weight, e.Metadata, nullTime(e.ValidAt), nullTime(e.InvalidAt), e.CreatedAt)
	if err != nil && strings.Contains(err.Error(), "UNIQUE constraint failed") {
		return fmt.Errorf("%w: %s", ErrDuplicateEdge, err)
	}
	return err
}

// GetEdge retrieves an edge by its primary key ID.
// Returns ErrEdgeNotFound wrapped with the ID when no row is found.
func (s *Store) GetEdge(ctx context.Context, id string) (*Edge, error) {
	return retryOnBusyVal(func() (*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getEdgeQ(ctx, s.q(), id)
	}, 5, 50*time.Millisecond)
}

func getEdgeQ(ctx context.Context, q queryable, id string) (*Edge, error) {
	e := &Edge{}
	var validAt, invalidAt sql.NullTime
	err := q.QueryRowContext(ctx, `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges WHERE id=?`, id).
		Scan(&e.ID, &e.FromID, &e.ToID, &e.Type, &e.Acyclic, &e.Weight, &e.Metadata, &validAt, &invalidAt, &e.CreatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, fmt.Errorf("%w: %s", ErrEdgeNotFound, id)
		}
		return nil, err
	}
	if validAt.Valid {
		e.ValidAt = validAt.Time
	}
	if invalidAt.Valid {
		e.InvalidAt = invalidAt.Time
	}
	return e, nil
}

func (s *Store) InvalidateEdge(ctx context.Context, id string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return invalidateEdgeQ(ctx, s.q(), id)
	}, 5, 50*time.Millisecond)
}

func invalidateEdgeQ(ctx context.Context, q queryable, id string) error {
	_, err := q.ExecContext(ctx, `UPDATE edges SET invalid_at = ? WHERE id = ?`, time.Now().UTC(), id)
	return err
}

func (s *Store) DeleteEdge(ctx context.Context, id string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return deleteEdgeQ(ctx, s.q(), id)
	}, 5, 50*time.Millisecond)
}

func deleteEdgeQ(ctx context.Context, q queryable, id string) error {
	_, err := q.ExecContext(ctx, `DELETE FROM edges WHERE id=?`, id)
	return err
}

func (s *Store) GetEdgesFrom(ctx context.Context, nodeID string) ([]*Edge, error) {
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return queryEdgesQ(ctx, s.q(), `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges WHERE from_id=? AND invalid_at IS NULL`, nodeID)
	}, 5, 50*time.Millisecond)
}

func (s *Store) GetEdgesTo(ctx context.Context, nodeID string) ([]*Edge, error) {
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return queryEdgesQ(ctx, s.q(), `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges WHERE to_id=? AND invalid_at IS NULL`, nodeID)
	}, 5, 50*time.Millisecond)
}

// GetValidEdgesFrom returns outbound edges from nodeID that were valid at the
// given instant: valid_at <= at AND (invalid_at IS NULL OR invalid_at > at).
// A zero `at` defaults to now, giving a "currently valid" view. This is a
// point-in-time variant of GetEdgesFrom; the latter is left unchanged so
// existing callers keep their current behavior.
func (s *Store) GetValidEdgesFrom(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	at = validityInstant(at)
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return queryEdgesQ(ctx, s.q(), `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
			WHERE from_id=? AND (valid_at IS NULL OR valid_at <= ?) AND (invalid_at IS NULL OR invalid_at > ?)`, nodeID, at, at)
	}, 5, 50*time.Millisecond)
}

// GetValidEdgesTo is the inbound counterpart of GetValidEdgesFrom.
func (s *Store) GetValidEdgesTo(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	at = validityInstant(at)
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return queryEdgesQ(ctx, s.q(), `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
			WHERE to_id=? AND (valid_at IS NULL OR valid_at <= ?) AND (invalid_at IS NULL OR invalid_at > ?)`, nodeID, at, at)
	}, 5, 50*time.Millisecond)
}

// validityInstant normalizes a point-in-time argument: a zero time means "now".
func validityInstant(at time.Time) time.Time {
	if at.IsZero() {
		return time.Now().UTC()
	}
	return at.UTC()
}

func queryEdgesQ(ctx context.Context, q queryable, query string, args ...any) ([]*Edge, error) {
	rows, err := q.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	return scanEdges(rows)
}

func (s *Store) GetEdgesBetween(ctx context.Context, nodeIDs []string) ([]*Edge, error) {
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getEdgesBetweenQ(ctx, s.q(), nodeIDs)
	}, 5, 50*time.Millisecond)
}

func getEdgesBetweenQ(ctx context.Context, q queryable, nodeIDs []string) ([]*Edge, error) {
	if len(nodeIDs) == 0 {
		return nil, nil
	}
	var all []*Edge
	for i := 0; i < len(nodeIDs); i += maxSQLVariables {
		end := i + maxSQLVariables
		if end > len(nodeIDs) {
			end = len(nodeIDs)
		}
		chunk := nodeIDs[i:end]
		placeholders := make([]string, len(chunk))
		args := make([]any, 0, len(chunk)*2)
		for j, id := range chunk {
			placeholders[j] = "?"
			args = append(args, id)
		}
		ph := strings.Join(placeholders, ",")
		query := fmt.Sprintf(`SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
			WHERE from_id IN (%s) AND to_id IN (%s)`, ph, ph)
		args = append(args, args...)
		edges, err := queryEdgesQ(ctx, q, query, args...)
		if err != nil {
			return nil, err
		}
		all = append(all, edges...)
	}
	return all, nil
}

// GetAllEdgesFor returns all edges where from_id OR to_id is in the given set.
// Used by IntentBFS for batch edge retrieval (avoids N+1 queries).
func (s *Store) GetAllEdgesFor(ctx context.Context, nodeIDs []string) ([]*Edge, error) {
	return retryOnBusyVal(func() ([]*Edge, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getAllEdgesForQ(ctx, s.q(), nodeIDs)
	}, 5, 50*time.Millisecond)
}

func getAllEdgesForQ(ctx context.Context, q queryable, nodeIDs []string) ([]*Edge, error) {
	if len(nodeIDs) == 0 {
		return nil, nil
	}
	var all []*Edge
	for i := 0; i < len(nodeIDs); i += maxSQLVariables {
		end := i + maxSQLVariables
		if end > len(nodeIDs) {
			end = len(nodeIDs)
		}
		chunk := nodeIDs[i:end]
		placeholders := make([]string, len(chunk))
		args := make([]any, 0, len(chunk)*2)
		for j, id := range chunk {
			placeholders[j] = "?"
			args = append(args, id)
		}
		ph := strings.Join(placeholders, ",")
		query := fmt.Sprintf(`SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
			WHERE from_id IN (%s) OR to_id IN (%s)`, ph, ph)
		args = append(args, args[:len(chunk)]...) // second set of args for to_id
		edges, err := queryEdgesQ(ctx, q, query, args...)
		if err != nil {
			return nil, err
		}
		all = append(all, edges...)
	}
	return all, nil
}

func (s *Store) GetNeighbors(ctx context.Context, nodeID string) ([]*Node, error) {
	return retryOnBusyVal(func() ([]*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return getNeighborsQ(ctx, s.q(), nodeID, s.cipher())
	}, 5, 50*time.Millisecond)
}

func getNeighborsQ(ctx context.Context, q queryable, nodeID string, c *NodeCipher) ([]*Node, error) {
	rows, err := q.QueryContext(ctx, `SELECT DISTINCT n.id, n.type, n.content, n.content_hash, n.summary, n.scope, n.project, n.tier, n.tags, n.key, n.pinned, n.confidence, n.access_count, n.created_at, n.updated_at, n.accessed_at, n.source_session, n.source_agent, n.version
		FROM nodes n JOIN edges e ON (e.to_id = n.id AND e.from_id = ?) OR (e.from_id = n.id AND e.to_id = ?)`, nodeID, nodeID)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	return scanNodes(rows, c)
}

// CountEdges returns inbound and outbound edge counts for a node.
func (s *Store) CountEdges(ctx context.Context, nodeID string) (inbound int, outbound int, err error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return countEdgesQ(ctx, s.q(), nodeID)
}

func countEdgesQ(ctx context.Context, q queryable, nodeID string) (int, int, error) {
	var inbound, outbound int
	err := q.QueryRowContext(ctx,
		`SELECT (SELECT COUNT(*) FROM edges WHERE to_id = ?), (SELECT COUNT(*) FROM edges WHERE from_id = ?)`,
		nodeID, nodeID).Scan(&inbound, &outbound)
	return inbound, outbound, err
}

// CountAllEdges returns the total number of edges in the graph.
func (s *Store) CountAllEdges(ctx context.Context) (int, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return countAllEdgesQ(ctx, s.db)
}

func countAllEdgesQ(ctx context.Context, q queryable) (int, error) {
	var count int
	err := q.QueryRowContext(ctx, `SELECT COUNT(*) FROM edges`).Scan(&count)
	return count, err
}

// CountEdgesBatch returns inbound/outbound edge counts for multiple nodes in a single query.
func (s *Store) CountEdgesBatch(ctx context.Context, nodeIDs []string) (map[string][2]int, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return countEdgesBatchQ(ctx, s.q(), nodeIDs)
}

// countEdgesBatchQ counts inbound/outbound edges for nodeIDs. SQLite caps the
// number of host parameters per statement (maxSQLVariables), so large ID sets
// are counted chunk by chunk; each chunk's GROUP BY totals merge into the
// same per-node counts.
func countEdgesBatchQ(ctx context.Context, q queryable, nodeIDs []string) (map[string][2]int, error) {
	if len(nodeIDs) == 0 {
		return nil, nil
	}
	result := make(map[string][2]int, len(nodeIDs))
	for _, id := range nodeIDs {
		result[id] = [2]int{0, 0}
	}

	for i := 0; i < len(nodeIDs); i += maxSQLVariables {
		end := i + maxSQLVariables
		if end > len(nodeIDs) {
			end = len(nodeIDs)
		}
		chunk := nodeIDs[i:end]
		args := make([]any, len(chunk))
		for j, id := range chunk {
			args[j] = id
		}
		ph := placeholders(len(chunk))

		// Count outbound edges (from_id IN (...))
		outQ := `SELECT from_id, COUNT(*) FROM edges WHERE from_id IN (` + ph + `) GROUP BY from_id`
		rows, err := q.QueryContext(ctx, outQ, args...)
		if err != nil {
			return nil, fmt.Errorf("count edges batch outbound: %w", err)
		}
		for rows.Next() {
			var id string
			var count int
			if err := rows.Scan(&id, &count); err != nil {
				_ = rows.Close()
				return nil, err
			}
			if v, ok := result[id]; ok {
				v[1] = count
				result[id] = v
			}
		}
		if err := rows.Err(); err != nil {
			_ = rows.Close()
			return nil, err
		}
		_ = rows.Close()

		// Count inbound edges (to_id IN (...))
		inQ := `SELECT to_id, COUNT(*) FROM edges WHERE to_id IN (` + ph + `) GROUP BY to_id`
		rows2, err := q.QueryContext(ctx, inQ, args...)
		if err != nil {
			return nil, fmt.Errorf("count edges batch inbound: %w", err)
		}
		for rows2.Next() {
			var id string
			var count int
			if err := rows2.Scan(&id, &count); err != nil {
				_ = rows2.Close()
				return nil, err
			}
			if v, ok := result[id]; ok {
				v[0] = count
				result[id] = v
			}
		}
		if err := rows2.Err(); err != nil {
			_ = rows2.Close()
			return nil, err
		}
		_ = rows2.Close()
	}

	return result, nil
}

func placeholders(n int) string {
	if n <= 0 {
		return ""
	}
	b := make([]byte, 0, n*2-1)
	for i := 0; i < n; i++ {
		if i > 0 {
			b = append(b, ',')
		}
		b = append(b, '?')
	}
	return string(b)
}

// NodeStats returns nodes grouped by type and total count.
func (s *Store) NodeStats(ctx context.Context) (map[string]int, int, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return nodeStatsQ(ctx, s.db)
}

func nodeStatsQ(ctx context.Context, q queryable) (map[string]int, int, error) {
	rows, err := q.QueryContext(ctx, `SELECT type, COUNT(*) FROM nodes GROUP BY type`)
	if err != nil {
		return nil, 0, err
	}
	defer func() { _ = rows.Close() }()
	stats := make(map[string]int)
	total := 0
	for rows.Next() {
		var typ string
		var cnt int
		if err := rows.Scan(&typ, &cnt); err != nil {
			return nil, 0, err
		}
		stats[typ] = cnt
		total += cnt
	}
	return stats, total, rows.Err()
}

// DoctorStats returns aggregated diagnostic counts via SQL without loading
// individual nodes into memory.
func (s *Store) DoctorStats(ctx context.Context) (DoctorStatsResult, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return doctorStatsQ(ctx, s.db)
}

func doctorStatsQ(ctx context.Context, q queryable) (DoctorStatsResult, error) {
	var r DoctorStatsResult

	err := q.QueryRowContext(ctx, `
		SELECT
			COUNT(*),
			SUM(CASE WHEN confidence < 0.2 THEN 1 ELSE 0 END),
			SUM(CASE WHEN pinned = 1 THEN 1 ELSE 0 END),
			SUM(CASE WHEN NOT EXISTS (
				SELECT 1 FROM edges ef WHERE ef.from_id = nodes.id
				UNION ALL
				SELECT 1 FROM edges et WHERE et.to_id = nodes.id
				LIMIT 1
			) THEN 1 ELSE 0 END)
		FROM nodes
	`).Scan(&r.TotalNodes, &r.LowConfidence, &r.Pinned, &r.Orphans)
	if err != nil {
		return DoctorStatsResult{}, err
	}
	return r, nil
}

// LastUpdated returns the most recent updated_at time across all nodes.
func (s *Store) LastUpdated(ctx context.Context) (time.Time, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return lastUpdatedQ(ctx, s.db)
}

func lastUpdatedQ(ctx context.Context, q queryable) (time.Time, error) {
	// updated_at is stored as a text timestamp; the sqlite driver returns
	// MAX(updated_at) as a string, so scan into a NullString and parse it the
	// same way the rest of this file does (RFC3339Nano with a legacy fallback).
	// Scanning directly into sql.NullTime fails the driver's type conversion
	// whenever a row exists.
	var s sql.NullString
	if err := q.QueryRowContext(ctx, `SELECT MAX(updated_at) FROM nodes`).Scan(&s); err != nil {
		return time.Time{}, err
	}
	if !s.Valid || s.String == "" {
		return time.Time{}, nil
	}
	// The sqlite driver stores a time.Time as its String() form
	// ("2006-01-02 15:04:05.999999999 -0700 MST"); also accept RFC3339 and the
	// legacy "2006-01-02 15:04:05" layout for robustness across writers.
	for _, layout := range []string{"2006-01-02 15:04:05.999999999 -0700 MST", time.RFC3339Nano, "2006-01-02 15:04:05"} {
		if t, err := time.Parse(layout, s.String); err == nil {
			return t, nil
		}
	}
	return time.Time{}, nil
}

// TopConnected returns the content of the most-connected nodes by edge count.
func (s *Store) TopConnected(ctx context.Context, limit int) ([]string, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	return topConnectedQ(ctx, s.q(), limit)
}

func topConnectedQ(ctx context.Context, q queryable, limit int) ([]string, error) {
	rows, err := q.QueryContext(ctx, `SELECT n.content, COUNT(*) as cnt
		FROM edges e JOIN nodes n ON n.id = e.from_id OR n.id = e.to_id
		GROUP BY n.id ORDER BY cnt DESC LIMIT ?`, limit)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	var out []string
	for rows.Next() {
		var content string
		var cnt int
		if err := rows.Scan(&content, &cnt); err != nil {
			return nil, err
		}
		out = append(out, content)
	}
	return out, rows.Err()
}

// CheckCycle uses a recursive CTE to detect if adding from->to would create a cycle
// among acyclic edges.
func (s *Store) CheckCycle(ctx context.Context, fromID, toID string) (bool, error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	var result bool
	err := retryOnBusy(func() error {
		var innerErr error
		result, innerErr = checkCycleQ(ctx, s.q(), fromID, toID)
		return innerErr
	}, 5, 2*time.Millisecond)
	return result, err
}

func checkCycleQ(ctx context.Context, q queryable, fromID, toID string) (bool, error) {
	// UNION (not UNION ALL) deduplicates the frontier: if a cycle ever slips
	// into the acyclic edge set, UNION ALL would recurse forever, whereas UNION
	// terminates once every reachable ancestor has been visited.
	query := `
		WITH RECURSIVE ancestors(id) AS (
			SELECT ?
			UNION
			SELECT e.from_id FROM ancestors a
			JOIN edges e ON e.to_id = a.id AND e.acyclic = 1
		)
		SELECT 1 FROM ancestors WHERE id = ? LIMIT 1`
	var exists int
	err := q.QueryRowContext(ctx, query, fromID, toID).Scan(&exists)
	if err == nil {
		return true, nil
	}
	if err == sql.ErrNoRows {
		return false, nil
	}
	return false, err
}
