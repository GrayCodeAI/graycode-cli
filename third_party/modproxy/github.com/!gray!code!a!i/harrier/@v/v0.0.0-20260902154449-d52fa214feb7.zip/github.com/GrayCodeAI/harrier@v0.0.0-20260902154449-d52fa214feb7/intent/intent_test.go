package intent

import "testing"

func TestClassify(t *testing.T) {
	t.Parallel()
	tests := []struct {
		query  string
		expect Intent
	}{
		{"why did we choose PostgreSQL?", IntentWhy},
		{"what is the reason for the migration?", IntentWhy},
		{"when did we decide to use React?", IntentWhen},
		{"what happened before the refactor?", IntentWhen},
		{"how to deploy the service?", IntentHow},
		{"what are the steps to install?", IntentHow},
		{"who wrote the auth module?", IntentWho},
		{"which library handles JWT?", IntentWho},
		{"what is the auth middleware?", IntentWhat},
		{"describe the payment flow", IntentWhat},
		{"tell me about the config system", IntentWhat},
		{"just a random lookup on this thing", IntentGeneral},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.query, func(t *testing.T) {
			t.Parallel()
			got := Classify(tt.query)
			if got != tt.expect {
				t.Errorf("Classify(%q) = %v, want %v", tt.query, got, tt.expect)
			}
		})
	}
}

func TestWeights_IntentWhy(t *testing.T) {
	t.Parallel()
	w := Weights(IntentWhy)
	if w.CausedBy <= w.Touches {
		t.Error("Why intent should boost CausedBy over Touches")
	}
	if w.LedTo <= w.RelatesTo {
		t.Error("Why intent should boost LedTo over RelatesTo")
	}
}

func TestWeights_IntentGeneral(t *testing.T) {
	t.Parallel()
	w := Weights(IntentGeneral)
	if w.CausedBy != 1.0 || w.LedTo != 1.0 || w.PartOf != 1.0 {
		t.Error("General intent should have all weights at 1.0")
	}
}

func TestEdgeWeight(t *testing.T) {
	t.Parallel()
	w := Weights(IntentHow)

	tests := []struct {
		edgeType string
		min      float64
	}{
		{"part_of", 3.0},
		{"depends_on", 2.0},
		{"unknown_type", 1.0},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.edgeType, func(t *testing.T) {
			t.Parallel()
			got := w.EdgeWeight(tt.edgeType)
			if got < tt.min {
				t.Errorf("EdgeWeight(%q) = %v, expected >= %v", tt.edgeType, got, tt.min)
			}
		})
	}
}

func TestIntent_String(t *testing.T) {
	t.Parallel()
	tests := []struct {
		intent Intent
		expect string
	}{
		{IntentGeneral, "General"},
		{IntentWhy, "Why"},
		{IntentWhen, "When"},
		{IntentWho, "Who"},
		{IntentHow, "How"},
		{IntentWhat, "What"},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.expect, func(t *testing.T) {
			t.Parallel()
			if got := tt.intent.String(); got != tt.expect {
				t.Errorf("%v.String() = %q, want %q", tt.intent, got, tt.expect)
			}
		})
	}
}
