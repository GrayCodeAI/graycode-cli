package engine

import (
	"context"
	"fmt"
	"log/slog"
	"sort"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// Sparsifier implements Memory³-style memory sparsification.
// As the graph grows, it:
//  1. Merges near-duplicate memories (same entities, similar content)
//  2. Compresses low-value clusters into single summary nodes
//  3. Prunes truly orphaned nodes with no edges and low confidence
//
// This keeps the memory graph lean and fast as it scales.
type Sparsifier struct {
	store storage.Storage
}

// SparsifyResult reports what was cleaned up.
type SparsifyResult struct {
	Merged     int
	Compressed int
	Pruned     int
}

// NewSparsifier creates a memory sparsification engine.
func NewSparsifier(store storage.Storage) *Sparsifier {
	return &Sparsifier{store: store}
}

// Run executes all sparsification passes. Safe to call periodically (e.g., weekly).
func (s *Sparsifier) Run(ctx context.Context) (*SparsifyResult, error) {
	result := &SparsifyResult{}

	// Pass 1: Merge near-duplicates
	merged, err := s.mergeNearDuplicates(ctx)
	if err != nil {
		return result, fmt.Errorf("merge pass: %w", err)
	}
	result.Merged = merged

	// Pass 2: Compress low-value clusters
	compressed, err := s.compressLowValueClusters(ctx)
	if err != nil {
		return result, fmt.Errorf("compress pass: %w", err)
	}
	result.Compressed = compressed

	// Pass 3: Prune orphaned low-confidence nodes
	pruned, err := s.pruneOrphans(ctx)
	if err != nil {
		return result, fmt.Errorf("prune pass: %w", err)
	}
	result.Pruned = pruned

	return result, nil
}

// mergeNearDuplicates finds nodes with very similar content and merges them.
// Uses MinHash LSH to avoid O(n^2) pairwise comparisons. Instead of comparing
// every pair (n*(n-1)/2), only candidates from the same LSH bucket are compared.
func (s *Sparsifier) mergeNearDuplicates(ctx context.Context) (int, error) {
	nodes, err := s.store.ListNodes(ctx, storage.NodeFilter{Limit: 5000})
	if err != nil {
		return 0, err
	}

	// Pre-compute term sets and build lookup index (tokenize once per node).
	termSets := make(map[string]map[string]bool, len(nodes)) // id -> terms
	nodeIndex := make(map[string]*storage.Node, len(nodes))  // id -> node
	for _, n := range nodes {
		termSets[n.ID] = termSet(n.Content)
		nodeIndex[n.ID] = n
	}

	// Build LSH index keyed by node type to avoid cross-type comparisons.
	typeToLSH := make(map[string]*MinHashLSH)
	for _, n := range nodes {
		lsh, ok := typeToLSH[n.Type]
		if !ok {
			lsh = NewMinHashLSH(0.85)
			typeToLSH[n.Type] = lsh
		}
		lsh.Insert(n.ID, termSets[n.ID])
	}

	merged := 0
	processed := make(map[string]bool)

	for _, a := range nodes {
		if processed[a.ID] {
			continue
		}

		// Query LSH for candidate IDs that likely share a bucket with a.
		lsh := typeToLSH[a.Type]
		candidates := lsh.Query(termSets[a.ID])

		for _, candID := range candidates {
			if candID == a.ID || processed[candID] {
				continue
			}

			b := nodeIndex[candID]
			if b == nil || a.Type != b.Type {
				continue
			}

			// Verify with exact Jaccard similarity (LSH may produce false positives).
			similarity := contentSimilarity(a.Content, b.Content)
			if similarity > 0.85 {
				// Keep the higher-confidence node as primary.
				primary, duplicate := a, b
				if b.Confidence > a.Confidence {
					primary, duplicate = b, a
				}
				// Append unique info from duplicate to primary.
				if !strings.Contains(primary.Content, duplicate.Content) {
					combined := primary.Content
					if len(combined)+len(duplicate.Content) < 500 {
						combined += " | " + duplicate.Content
					}
					_ = s.store.UpdateNodeContent(ctx, primary.ID, combined)
				}
				// Archive the duplicate.
				if err := s.store.DeleteNode(ctx, duplicate.ID); err != nil {
					slog.Warn("sparsify: failed to delete merged duplicate", "node_id", duplicate.ID, "error", err)
				}
				processed[duplicate.ID] = true
				merged++
			}
		}
	}
	return merged, nil
}

// compressLowValueClusters finds groups of low-confidence nodes of the same type
// and compresses them into a single summary node.
func (s *Sparsifier) compressLowValueClusters(ctx context.Context) (int, error) {
	nodes, err := s.store.ListNodes(ctx, storage.NodeFilter{
		MinConfidence: 0.1,
		Limit:         5000,
	})
	if err != nil {
		return 0, err
	}

	// Group low-confidence nodes by type
	lowConf := make(map[string][]*storage.Node) // type → nodes
	for _, n := range nodes {
		if n.Confidence < 0.3 && !n.Pinned {
			lowConf[n.Type] = append(lowConf[n.Type], n)
		}
	}

	compressed := 0
	for nodeType, group := range lowConf {
		if len(group) < 5 {
			continue // only compress if there are enough
		}

		// Sort by confidence descending, keep top 2, compress rest
		sort.Slice(group, func(i, j int) bool {
			return group[i].Confidence > group[j].Confidence
		})

		toCompress := group[2:] // keep top 2
		if len(toCompress) < 3 {
			continue
		}

		// Build summary from compressed nodes
		var summaryParts []string
		for _, n := range toCompress {
			content := n.Content
			if len(content) > 50 {
				content = content[:50]
			}
			summaryParts = append(summaryParts, content)
		}
		summary := fmt.Sprintf("[Compressed %d %s memories] %s",
			len(toCompress), nodeType, strings.Join(summaryParts[:min(5, len(summaryParts))], "; "))

		// Create summary node
		summaryNode := &storage.Node{
			ID:          uuid.New().String(),
			Type:        nodeType,
			Content:     summary,
			ContentHash: ContentHash(summary, "project", "", nodeType),
			Scope:       "project",
			Tier:        3, // cold tier
			Confidence:  0.3,
		}
		if err := s.store.CreateNode(ctx, summaryNode); err != nil {
			continue
		}

		// Delete compressed nodes
		for _, n := range toCompress {
			if err := s.store.DeleteNode(ctx, n.ID); err != nil {
				slog.Warn("sparsify: failed to delete compressed node", "node_id", n.ID, "error", err)
				continue
			}
			compressed++
		}
	}

	return compressed, nil
}

// pruneOrphans removes nodes with no edges and very low confidence.
func (s *Sparsifier) pruneOrphans(ctx context.Context) (int, error) {
	nodes, err := s.store.ListNodes(ctx, storage.NodeFilter{Limit: 5000})
	if err != nil {
		return 0, err
	}

	pruned := 0
	for _, n := range nodes {
		if n.Pinned || n.Confidence >= 0.2 {
			continue
		}

		inbound, outbound, err := s.store.CountEdges(ctx, n.ID)
		if err != nil {
			continue
		}
		if inbound+outbound == 0 && n.AccessCount <= 1 {
			if err := s.store.DeleteNode(ctx, n.ID); err != nil {
				slog.Warn("sparsify: failed to prune orphan node", "node_id", n.ID, "error", err)
				continue
			}
			pruned++
		}
	}
	return pruned, nil
}

// contentSimilarity computes Jaccard similarity between two texts based on terms.
func contentSimilarity(a, b string) float64 {
	termsA := termSet(a)
	termsB := termSet(b)

	if len(termsA) == 0 || len(termsB) == 0 {
		return 0
	}

	intersection := 0
	for t := range termsA {
		if termsB[t] {
			intersection++
		}
	}

	union := len(termsA) + len(termsB) - intersection
	if union == 0 {
		return 0
	}
	return float64(intersection) / float64(union)
}

func termSet(text string) map[string]bool {
	terms := make(map[string]bool)
	for _, t := range tokenize(text) {
		if len(t) >= 3 {
			terms[t] = true
		}
	}
	return terms
}
