package engine

import (
	"context"
	"fmt"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// ImpactAnalysis reports how a memory change cascades through the graph.
// Given a node that changed, it identifies all downstream memories that may
// be affected, grouped by relationship type.
type ImpactAnalysis struct {
	SourceNode *storage.Node       `json:"source_node"`
	Affected   []*AffectedNode     `json:"affected"`
	TotalCount int                 `json:"total_count"`
	StaleCount int                 `json:"stale_count"`
	ByRelType  map[string][]string `json:"by_relationship_type"`
	AnalyzedAt time.Time           `json:"analyzed_at"`
}

// AffectedNode is a single affected memory with its relationship to the source.
type AffectedNode struct {
	Node         *storage.Node `json:"node"`
	RelationType string        `json:"relation_type"`
	Distance     int           `json:"distance"`
	Confidence   float64       `json:"confidence"`
}

// AnalyzeImpact traces all memories downstream of a changed node and reports
// what would be affected. Walks both forward (led_to, part_of) and backward
// (caused_by, supersedes) edges to find the full impact surface.
func (e *Engine) AnalyzeImpact(ctx context.Context, nodeID string, maxDepth int) (*ImpactAnalysis, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if maxDepth <= 0 {
		maxDepth = 3
	}

	node, err := e.store.GetNode(ctx, nodeID)
	if err != nil {
		return nil, fmt.Errorf("get source node: %w", err)
	}

	// BFS through the graph to find all reachable nodes
	ids, err := e.graph.BFS(ctx, nodeID, maxDepth)
	if err != nil {
		return nil, fmt.Errorf("graph traversal: %w", err)
	}

	// Fetch all reachable nodes in batch
	batchIDs := make([]string, 0, len(ids))
	for _, id := range ids {
		if id != nodeID {
			batchIDs = append(batchIDs, id)
		}
	}
	nodes, err := e.store.GetNodesBatch(ctx, batchIDs)
	if err != nil {
		return nil, fmt.Errorf("batch fetch: %w", err)
	}
	nodeByID := make(map[string]*storage.Node, len(nodes))
	for _, n := range nodes {
		nodeByID[n.ID] = n
	}

	// Get all edges touching source or neighbors for relationship classification
	edges, err := e.store.GetAllEdgesFor(ctx, append(batchIDs, nodeID))
	if err != nil {
		return nil, fmt.Errorf("get edges: %w", err)
	}

	// Build adjacency with edge types
	type edgeInfo struct {
		fromID string
		toID   string
		etype  string
	}
	var sourceEdges []edgeInfo
	for _, ed := range edges {
		if ed.FromID == nodeID {
			sourceEdges = append(sourceEdges, edgeInfo{ed.FromID, ed.ToID, ed.Type})
		}
	}

	analysis := &ImpactAnalysis{
		SourceNode: node,
		ByRelType:  make(map[string][]string),
		AnalyzedAt: time.Now(),
	}

	seen := map[string]bool{nodeID: true}
	for _, se := range sourceEdges {
		if seen[se.toID] {
			continue
		}
		seen[se.toID] = true
		affected := nodeByID[se.toID]
		if affected == nil {
			continue
		}
		analysis.Affected = append(analysis.Affected, &AffectedNode{
			Node:         affected,
			RelationType: se.etype,
			Distance:     1,
			Confidence:   affected.Confidence,
		})
		analysis.ByRelType[se.etype] = append(analysis.ByRelType[se.etype], se.toID)
		if affected.Confidence < 0.3 {
			analysis.StaleCount++
		}
	}

	analysis.TotalCount = len(analysis.Affected)
	return analysis, nil
}
