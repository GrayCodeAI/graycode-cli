// Package daemon manages harrier's background server lifecycle:
// PID file tracking, health checks, and auto-start logic.
package daemon

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const (
	DefaultAddr   = ":3456"
	healthPath    = "/harrier/health"
	pidFileName   = "harrier.pid"
	startTimeout  = 5 * time.Second
	healthTimeout = 2 * time.Second
)

// PIDFile returns the path to the PID file for the given project directory.
func PIDFile(projectDir string) string {
	return filepath.Join(projectDir, ".harrier", pidFileName)
}

// WritePID writes the current process PID to the PID file.
func WritePID(projectDir string) error {
	// .harrier also holds the sqlite store and audit log, both owner-only;
	// keep the directory consistent rather than relying on creation order.
	dir := filepath.Join(projectDir, ".harrier")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	return os.WriteFile(PIDFile(projectDir), []byte(strconv.Itoa(os.Getpid())), 0o600)
}

// RemovePID removes the PID file.
func RemovePID(projectDir string) {
	_ = os.Remove(PIDFile(projectDir))
}

// ReadPID reads the stored PID. Returns 0 if no PID file or invalid.
func ReadPID(projectDir string) int {
	b, err := os.ReadFile(PIDFile(projectDir))
	if err != nil {
		return 0
	}
	pid, err := strconv.Atoi(strings.TrimSpace(string(b)))
	if err != nil {
		return 0
	}
	return pid
}

// IsRunning checks if the daemon process is alive (signal 0 check).
func IsRunning(projectDir string) bool {
	pid := ReadPID(projectDir)
	if pid == 0 {
		return false
	}
	proc, err := os.FindProcess(pid)
	if err != nil {
		return false
	}
	// Signal 0: check if process exists without sending a real signal
	err = proc.Signal(syscall.Signal(0))
	return err == nil
}

// HealthCheck pings the harrier health endpoint. Returns nil if healthy.
// addr can be ":port", "host:port", or a full "http://host:port" URL.
func HealthCheck(addr string) error {
	if addr == "" {
		addr = DefaultAddr
	}
	var url string
	switch {
	case strings.HasPrefix(addr, "http://") || strings.HasPrefix(addr, "https://"):
		url = addr + healthPath
	case strings.HasPrefix(addr, ":"):
		url = "http://localhost" + addr + healthPath
	default:
		url = "http://" + addr + healthPath
	}
	client := &http.Client{Timeout: healthTimeout}
	req, err := http.NewRequestWithContext(context.Background(), "GET", url, nil)
	if err != nil {
		return fmt.Errorf("creating request: %w", err)
	}
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("harrier not reachable: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != 200 {
		return fmt.Errorf("harrier unhealthy: status %d", resp.StatusCode)
	}
	return nil
}

// Stop sends SIGTERM to the daemon process.
func Stop(projectDir string) error {
	pid := ReadPID(projectDir)
	if pid == 0 {
		return fmt.Errorf("no harrier daemon found (no PID file)")
	}
	proc, err := os.FindProcess(pid)
	if err != nil {
		return fmt.Errorf("process %d not found: %w", pid, err)
	}
	if err := proc.Signal(syscall.SIGTERM); err != nil {
		RemovePID(projectDir)
		return fmt.Errorf("could not signal process %d: %w", pid, err)
	}
	// Wait briefly for shutdown
	for i := 0; i < 10; i++ {
		time.Sleep(200 * time.Millisecond)
		if err := proc.Signal(syscall.Signal(0)); err != nil {
			break
		}
	}
	RemovePID(projectDir)
	return nil
}

// EnsureRunning checks health; if harrier is not running, launches it as a daemon.
// Returns the addr the server is (or will be) listening on.
func EnsureRunning(projectDir, addr string) error {
	if addr == "" {
		addr = DefaultAddr
	}

	// Fast path: already healthy
	if HealthCheck(addr) == nil {
		return nil //nolint:errcheck // intentional early return
	}

	// Process exists but unhealthy — stale PID
	if IsRunning(projectDir) {
		_ = Stop(projectDir)
	}

	// Launch daemon (without --daemon flag so it runs in foreground in the child)
	exe, err := os.Executable()
	if err != nil {
		exe = "harrier"
	}
	cmd := exec.CommandContext(context.Background(), exe, "serve", "--addr", addr) // #nosec G204 -- exe is os.Executable() (own binary path) or a fixed fallback; addr is caller-controlled config
	cmd.Dir = projectDir
	cmd.Stdout = nil
	cmd.Stderr = nil
	setSysProcAttr(cmd)
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("failed to start harrier daemon: %w", err)
	}
	// Detach — don't wait for child
	_ = cmd.Process.Release()

	// Poll until healthy or timeout
	deadline := time.Now().Add(startTimeout)
	for time.Now().Before(deadline) {
		time.Sleep(200 * time.Millisecond)
		if HealthCheck(addr) == nil {
			return nil
		}
	}
	return fmt.Errorf("harrier daemon started but not healthy after %s", startTimeout)
}

func normalizeAddr(addr string) string {
	if strings.HasPrefix(addr, ":") {
		return addr
	}
	return ":" + addr
}
