package engine

import (
	"context"
	"sort"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// RankingWeights configures the relative importance of each ranking factor.
// Weights are normalized to sum to 1.0 before use.
type RankingWeights struct {
	Recency    float64
	Relevance  float64
	Frequency  float64
	Confidence float64
	Tier       float64
	Centrality float64
	Pinned     float64
}

// DefaultRankingWeights returns balanced weights tuned for coding memory workloads.
func DefaultRankingWeights() RankingWeights {
	return RankingWeights{
		Recency:    0.20,
		Relevance:  0.25,
		Frequency:  0.10,
		Confidence: 0.20,
		Tier:       0.10,
		Centrality: 0.10,
		Pinned:     0.05,
	}
}

// normalizeWeights scales weights so they sum to 1.0. Falls back to defaults
// if the total is zero.
func normalizeWeights(w RankingWeights) RankingWeights {
	total := w.Recency + w.Relevance + w.Frequency + w.Confidence + w.Tier + w.Centrality + w.Pinned
	if total <= 0 {
		return DefaultRankingWeights()
	}
	return RankingWeights{
		Recency:    w.Recency / total,
		Relevance:  w.Relevance / total,
		Frequency:  w.Frequency / total,
		Confidence: w.Confidence / total,
		Tier:       w.Tier / total,
		Centrality: w.Centrality / total,
		Pinned:     w.Pinned / total,
	}
}

// RankedNode pairs a memory node with its multi-factor score and a breakdown
// of individual factor contributions.
type RankedNode struct {
	Node    *storage.Node
	Score   float64
	Factors map[string]float64
}

// MultiFactorRanker re-scores recalled memories using configurable factor weights.
type MultiFactorRanker struct {
	weights RankingWeights
}

// NewMultiFactorRanker creates a ranker with the given weights (normalized).
func NewMultiFactorRanker(cfg RankingWeights) *MultiFactorRanker {
	return &MultiFactorRanker{weights: normalizeWeights(cfg)}
}

// Rank re-scores nodes using multi-factor ranking and returns them sorted by
// combined score descending. baseScores provides pre-computed relevance scores
// (e.g., from BM25 or RRF fusion).
func (r *MultiFactorRanker) Rank(ctx context.Context, nodes []*storage.Node, baseScores map[string]float64, store storage.Storage) []*RankedNode {
	if len(nodes) == 0 {
		return nil
	}

	now := time.Now()
	ranked := make([]*RankedNode, 0, len(nodes))

	for _, n := range nodes {
		if ctx.Err() != nil {
			break
		}

		factors := map[string]float64{
			"recency":    mfrRecencyScore(n, now),
			"relevance":  baseScores[n.ID],
			"frequency":  frequencyScore(n),
			"confidence": n.Confidence,
			"tier":       tierLevelScore(n.Tier),
			"centrality": 0.0,
			"pinned":     pinnedScore(n.Pinned),
		}

		// Centrality: approximate via edge count (more edges = more central).
		if store != nil {
			inbound, outbound, err := store.CountEdges(ctx, n.ID)
			if err == nil {
				total := float64(inbound + outbound)
				if total > 10 {
					total = 10
				}
				factors["centrality"] = total / 10.0
			}
		}

		score := r.weights.Recency*factors["recency"] +
			r.weights.Relevance*factors["relevance"] +
			r.weights.Frequency*factors["frequency"] +
			r.weights.Confidence*factors["confidence"] +
			r.weights.Tier*factors["tier"] +
			r.weights.Centrality*factors["centrality"] +
			r.weights.Pinned*factors["pinned"]

		ranked = append(ranked, &RankedNode{
			Node:    n,
			Score:   score,
			Factors: factors,
		})
	}

	sort.Slice(ranked, func(i, j int) bool {
		return ranked[i].Score > ranked[j].Score
	})

	return ranked
}

// mfrRecencyScore computes a 0-1 recency score based on last access time.
func mfrRecencyScore(n *storage.Node, now time.Time) float64 {
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if ref.IsZero() {
		return 0.1
	}
	days := now.Sub(ref).Hours() / 24
	if days <= 0 {
		return 1.0
	}
	return 1.0 / (1.0 + days/30.0)
}

// frequencyScore computes a 0-1 score based on access count.
func frequencyScore(n *storage.Node) float64 {
	if n.AccessCount <= 0 {
		return 0
	}
	score := float64(n.AccessCount)
	if score > 100 {
		score = 100
	}
	return score / 100.0
}

// tierLevelScore maps tier levels to scores.
func tierLevelScore(tier int) float64 {
	switch tier {
	case 1:
		return 1.0
	case 2:
		return 0.6
	case 3:
		return 0.3
	default:
		return 0.1
	}
}

// pinnedScore returns 1.0 for pinned nodes, 0.0 otherwise.
func pinnedScore(pinned bool) float64 {
	if pinned {
		return 1.0
	}
	return 0.0
}

// RankedNodesToNodes extracts the underlying nodes from ranked results.
func RankedNodesToNodes(ranked []*RankedNode) []*storage.Node {
	nodes := make([]*storage.Node, len(ranked))
	for i, r := range ranked {
		nodes[i] = r.Node
	}
	return nodes
}
