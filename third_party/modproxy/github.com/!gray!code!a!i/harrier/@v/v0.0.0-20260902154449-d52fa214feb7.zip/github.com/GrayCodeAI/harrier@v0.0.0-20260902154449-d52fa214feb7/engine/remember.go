package engine

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// RememberInput is the input for creating a memory node.
type RememberInput struct {
	Type     string // convention|decision|bug|spec|task|preference
	Content  string
	Summary  string // doubles as short searchable title (Engram Title)
	Scope    string // global|project
	Project  string
	Tier     int
	Tags     string
	Key      string // optional unique key per project (upsert: same key → update, not duplicate)
	TopicKey string // topic-based upsert dedup key (Engram pattern); stored in Tags as "topic:<key>"
	Pinned   bool   // pinned nodes always appear in context output
	Session  string
	Agent    string
	Metadata map[string]string // optional structured key-value metadata persisted alongside the node
	// Optional: explicit edges to create
	Edges []EdgeInput
}

// EdgeInput describes an edge to create alongside a node.
type EdgeInput struct {
	ToID string
	Type string
}

// validateRememberInput checks that input meets basic constraints.
func validateRememberInput(in RememberInput) error {
	if len(in.Content) == 0 {
		return fmt.Errorf("content cannot be empty")
	}
	if len(in.Content) > maxContentLength {
		return fmt.Errorf("content exceeds max length of %d characters", maxContentLength)
	}
	if in.Type != "" && !validNodeTypes[in.Type] {
		return fmt.Errorf("invalid node type: %q", in.Type)
	}
	return nil
}

// Remember creates a memory node with privacy filtering, dedup, and entity extraction.
func (e *Engine) Remember(ctx context.Context, in RememberInput) (*storage.Node, error) {
	start := time.Now()
	atomic.AddInt64(&e.metrics.Remembers, 1)
	if err := ctx.Err(); err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		telemetry.MemoryRememberDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}
	if err := validateRememberInput(in); err != nil {
		atomic.AddInt64(&e.metrics.Errors, 1)
		telemetry.MemoryRememberDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}

	// Steps 1-3: Privacy filtering, defaults, and content hashing are pure
	// computation with no shared state, so they run outside the lock.
	// Use the engine's configured privacy level/StripPrivate setting (set via
	// WithPrivacyLevel/WithPrivacyConfig) instead of the package-default filter,
	// so a caller's configured privacy level is actually honored.
	content := e.FilterContent(in.Content)
	summary := e.FilterContent(in.Summary)
	if in.Scope == "" {
		in.Scope = "project"
	}
	if in.Tier == 0 {
		in.Tier = defaultTier(in.Type)
	}
	hash := ContentHash(content, in.Scope, in.Project, in.Type)

	// Steps 4+: DB reads/writes require the write lock.
	e.mu.Lock()
	node, err := e.rememberLocked(ctx, in, content, summary, hash)
	e.mu.Unlock()
	if err != nil {
		telemetry.MemoryRememberDuration.Record(ctx, time.Since(start).Seconds())
		return nil, err
	}

	// 13. Self-linking — find related nodes and create edges (A-MEM inspired, best-effort)
	// Runs outside the write lock to avoid blocking concurrent Remember/Forget/Feedback.
	e.SelfLink(ctx, node)

	// 14. Update the MEMORY.md hot-pointer file if configured (best-effort).
	if err := e.renderMemoryFile(ctx); err != nil {
		slog.Warn("harrier: render memory file failed (best-effort)", "error", err)
	}

	// 15. Notify watchers (SSE / future gRPC WatchMemories). New nodes carry
	// Version 1; upsert/topic-key paths increment Version, so >1 means updated.
	kind := MemoryCreated
	if node.Version > 1 {
		kind = MemoryUpdated
	}
	e.emitMemoryEvent(kind, node)

	telemetry.MemoryRememberDuration.Record(ctx, time.Since(start).Seconds())
	return node, nil
}

// rememberLocked does the critical-path work of Remember under e.mu.
// Must be called with e.mu held. The content, summary, and hash parameters
// are pre-computed outside the lock by the caller.
func (e *Engine) rememberLocked(ctx context.Context, in RememberInput, content, summary, hash string) (*storage.Node, error) {
	// 4. Keyed upsert: if key is set, find existing node and update it
	if in.Key != "" {
		existing, err := e.store.GetNodeByKey(ctx, in.Key, in.Project)
		if err != nil {
			return nil, fmt.Errorf("keyed lookup failed: %w", err)
		}
		if existing != nil {
			// Save version before overwriting
			if err := e.store.SaveVersion(ctx, existing.ID, existing.Content, in.Agent, "keyed update"); err != nil {
				slog.Warn("harrier: save version failed (best-effort)", "node_id", existing.ID, "error", err)
			}
			existing.Content = content
			existing.ContentHash = hash
			existing.Summary = summary
			existing.Type = in.Type
			// Merge tags rather than overwrite, so tags applied out-of-band
			// (e.g. a previously-merged "topic:" tag) survive a keyed update.
			existing.Tags = mergeTags(existing.Tags, in.Tags)
			existing.Pinned = in.Pinned
			existing.Confidence = 1.0
			existing.AccessCount++
			existing.AccessedAt = time.Now()
			existing.UpdatedAt = time.Now()
			existing.Version++
			existing.Metadata = in.Metadata
			if err := e.store.UpdateNode(ctx, existing); err != nil {
				return nil, fmt.Errorf("keyed upsert failed: %w", err)
			}
			// Persist integrity signature
			if e.integrity != nil {
				sig := e.integrity.Sign(existing)
				if err := e.store.SaveSignature(ctx, existing.ID, sig); err != nil {
					slog.Warn("harrier: save signature failed (best-effort)", "node_id", existing.ID, "error", err)
				}
			}
			atomic.AddInt64(&e.metrics.NodesStored, 1)
			return existing, nil
		}
	}

	// 4b. TopicKey upsert: dedup by topic tag (Engram pattern)
	if in.TopicKey != "" {
		tag := "topic:" + in.TopicKey
		// Filter by the topic tag in SQL (delimiter-aware LIKE) instead of
		// loading every node of this type/project/scope and scanning in Go.
		candidates, err := e.store.ListNodes(ctx, storage.NodeFilter{
			Type: in.Type, Project: in.Project, Scope: in.Scope, Tag: tag, Limit: 1,
		})
		if err != nil {
			return nil, fmt.Errorf("topic key lookup failed: %w", err)
		}
		for _, c := range candidates {
			if containsTag(c.Tags, tag) {
				if err := e.store.SaveVersion(ctx, c.ID, c.Content, in.Agent, "topic upsert: "+in.TopicKey); err != nil {
					slog.Warn("harrier: save version failed (best-effort)", "node_id", c.ID, "error", err)
				}
				c.Content = content
				c.ContentHash = hash
				c.Summary = summary
				c.Tags = in.Tags
				c.Pinned = in.Pinned
				c.Confidence = 1.0
				c.AccessCount++
				c.UpdatedAt = time.Now()
				c.Version++
				c.Metadata = in.Metadata
				if err := e.store.UpdateNode(ctx, c); err != nil {
					return nil, fmt.Errorf("topic upsert failed: %w", err)
				}
				// Persist integrity signature
				if e.integrity != nil {
					sig := e.integrity.Sign(c)
					if err := e.store.SaveSignature(ctx, c.ID, sig); err != nil {
						slog.Warn("harrier: save signature failed (best-effort)", "node_id", c.ID, "error", err)
					}
				}
				atomic.AddInt64(&e.metrics.NodesStored, 1)
				return c, nil
			}
		}
		// Append topic tag for new node
		if in.Tags == "" {
			in.Tags = tag
		} else {
			in.Tags = in.Tags + "," + tag
		}
	}

	// 5. Rolling window dedup (skip near-duplicates within 5min)
	if e.dedup.IsDuplicate(content) {
		existing, err := e.store.SearchNodeByHash(ctx, hash, in.Scope, in.Project)
		if err != nil {
			return nil, fmt.Errorf("dedup lookup failed: %w", err)
		}
		if existing != nil {
			return existing, nil
		}
	}

	// 6. Check dedup — if exists, boost confidence and return
	existing, err := e.store.SearchNodeByHash(ctx, hash, in.Scope, in.Project)
	if err != nil {
		return nil, fmt.Errorf("hash lookup failed: %w", err)
	}
	if existing != nil {
		existing.Confidence = min(existing.Confidence+0.2, 1.0)
		existing.AccessCount++
		existing.AccessedAt = time.Now()
		if err := e.store.UpdateNode(ctx, existing); err != nil {
			return nil, fmt.Errorf("dedup boost failed: %w", err)
		}
		return existing, nil
	}

	// 8. Create node
	node := &storage.Node{
		ID:            uuid.New().String(),
		Type:          in.Type,
		Content:       content,
		ContentHash:   hash,
		Summary:       summary,
		Scope:         in.Scope,
		Project:       in.Project,
		Tier:          in.Tier,
		Tags:          in.Tags,
		Key:           in.Key,
		Pinned:        in.Pinned,
		Confidence:    1.0,
		SourceSession: in.Session,
		SourceAgent:   in.Agent,
		Version:       1,
		Metadata:      in.Metadata,
	}
	if err := e.graph.AddNode(ctx, node); err != nil {
		return nil, fmt.Errorf("create node failed: %w", err)
	}

	// 8b. Persist integrity signature
	if e.integrity != nil {
		sig := e.integrity.Sign(node)
		if err := e.store.SaveSignature(ctx, node.ID, sig); err != nil {
			slog.Warn("harrier: save signature failed (best-effort)", "node_id", node.ID, "error", err)
		}
	}

	// 9. Extract entities and create anchor nodes + edges (best-effort).
	// Uses the LLM-augmented path when an extractor is configured (merging LLM
	// and regex results); regex-only otherwise — no behavior change without an LLM.
	entities := ExtractEntitiesWithLLM(ctx, content, e.llmExtractor)
	for _, ent := range entities {
		entNode := e.getOrCreateAnchor(ctx, ent.Name, ent.Type, in.Scope, in.Project)
		if entNode != nil {
			if err := e.graph.AddEdge(ctx, &storage.Edge{
				ID:     uuid.New().String(),
				FromID: node.ID,
				ToID:   entNode.ID,
				Type:   "touches",
				Weight: 1.0,
			}); err != nil {
				// Entity edge is best-effort; don't fail Remember, but make the
				// drop observable so silent graph gaps aren't invisible.
				atomic.AddInt64(&e.metrics.Errors, 1)
				slog.Debug("harrier: entity edge failed (best-effort)",
					"node_id", node.ID, "entity", entNode.ID, "error", err)
				continue
			}
		}
	}

	// 10. Create explicit edges (fail if user-requested edges can't be created)
	for _, ei := range in.Edges {
		if err := e.graph.AddEdge(ctx, &storage.Edge{
			ID:     uuid.New().String(),
			FromID: node.ID,
			ToID:   ei.ToID,
			Type:   ei.Type,
			Weight: 1.0,
		}); err != nil {
			return nil, fmt.Errorf("link edge failed: %w", err)
		}
	}

	// 11. Temporal backbone — auto-link to previous node in timeline
	if err := e.temporal.Link(ctx, node.ID, in.Project); err != nil {
		return nil, fmt.Errorf("temporal link failed: %w", err)
	}

	// 12. Conflict resolution — detect and supersede contradictions (best-effort).
	// Skipped in ADD-only mode (Mem0-v3-style single-pass ADD): contradictory
	// memories both persist with no supersedes edge and no confidence drop.
	if !e.addOnly {
		_, _ = e.conflict.CheckAndResolve(ctx, node)
	}

	// 14. Index in entity boost index + bloom filter for fast retrieval
	if e.entities != nil {
		e.entities.IndexNode(node)
	}
	if e.bloom != nil {
		e.bloom.AddTerms(node.Content)
	}
	// 15. Invalidate query cache (new data means cached results may be stale)
	if e.cache != nil {
		e.cache.Invalidate()
	}

	atomic.AddInt64(&e.metrics.NodesStored, 1)
	return node, nil
}

func defaultTier(nodeType string) int {
	switch nodeType {
	case "convention", "preference", "task":
		return 1
	case "decision", "bug":
		return 2
	default:
		return 3
	}
}

func (e *Engine) getOrCreateAnchor(ctx context.Context, name, typ, scope, project string) *storage.Node {
	hash := ContentHash(name, scope, project, typ)
	existing, err := e.store.SearchNodeByHash(ctx, hash, scope, project)
	if err != nil {
		slog.Warn("getOrCreateAnchor: search failed", "error", err)
		return nil
	}
	if existing != nil {
		return existing
	}
	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        typ,
		Content:     name,
		ContentHash: hash,
		Scope:       scope,
		Project:     project,
		Tier:        0, // anchor nodes don't have a tier
		Confidence:  1.0,
		Version:     1,
	}
	if err := e.store.CreateNode(ctx, node); err != nil {
		return nil
	}
	return node
}

// stripPrivateTags removes <private>...</private> tags and their content.
func stripPrivateTags(s string) string {
	for {
		start := strings.Index(s, "<private>")
		if start == -1 {
			return s
		}
		end := strings.Index(s[start:], "</private>")
		if end == -1 {
			return s
		}
		s = s[:start] + s[start+end+len("</private>"):]
	}
}

// containsTag checks if a comma-separated tag list contains a specific tag.
func containsTag(tags, tag string) bool {
	for _, t := range strings.Split(tags, ",") {
		if strings.TrimSpace(t) == tag {
			return true
		}
	}
	return false
}

// mergeTags returns the union of two comma-separated tag strings, preserving
// first-seen order and dropping blanks/duplicates. Existing tags come first so
// out-of-band tags (e.g. "topic:") are retained across a keyed update.
func mergeTags(existing, incoming string) string {
	seen := map[string]bool{}
	var out []string
	add := func(csv string) {
		for _, t := range strings.Split(csv, ",") {
			t = strings.TrimSpace(t)
			if t == "" || seen[t] {
				continue
			}
			seen[t] = true
			out = append(out, t)
		}
	}
	add(existing)
	add(incoming)
	return strings.Join(out, ",")
}
