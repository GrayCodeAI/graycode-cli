// This file is part of package storage. It holds the transactional store
// (WithTx and txStore) plus version rollback/diff, split verbatim out of
// sqlite.go for readability; behavior is unchanged.

package storage

import (
	"context"
	"database/sql"
	"fmt"
	"time"
)

// WithTx runs the given function inside a SQL transaction.
// If the function returns an error, the transaction is rolled back.
//
// The whole transaction is retried on SQLITE_BUSY. A transaction acquires the
// single SQLite writer more eagerly than a lone statement, so it can lose a
// race with the async ingestion goroutine; without retry, correctness-critical
// transactional writes (e.g. the atomic cycle-check+insert in AddEdge) would
// fail spuriously under concurrency. Re-running fn is safe because a busy error
// occurs before commit, so no partial state is visible.
func (s *Store) WithTx(ctx context.Context, fn func(Storage) error) error {
	return retryOnBusy(func() error {
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			return err
		}
		defer func() { _ = tx.Rollback() }()

		txStore := &txStore{tx: tx, store: s, dirtyHNSW: make(map[string]struct{})}
		if err := fn(txStore); err != nil {
			return err
		}
		if err := tx.Commit(); err != nil {
			return err
		}
		// Embedding writes inside the transaction were not applied to the
		// built HNSW indexes incrementally; drop the affected caches so the
		// next SearchHNSW rebuilds them from the embeddings table.
		for model := range txStore.dirtyHNSW {
			s.invalidateHNSWIndex(model)
		}
		return nil
	}, 5, 50*time.Millisecond)
}

// txStore is a Storage implementation backed by a SQL transaction.
type txStore struct {
	tx        *sql.Tx
	store     *Store
	dirtyHNSW map[string]struct{} // embedding models touched in this tx
}

// txStore is a thin wrapper that delegates all operations to shared *Q functions.
func (t *txStore) CreateNode(ctx context.Context, n *Node) error {
	return createNodeQ(ctx, t.tx, n, t.store.cipher())
}

func (t *txStore) GetNode(ctx context.Context, id string) (*Node, error) {
	return getNodeQ(ctx, t.tx, id, t.store.cipher())
}

func (t *txStore) GetNodeByKey(ctx context.Context, key, project string) (*Node, error) {
	return getNodeByKeyQ(ctx, t.tx, key, project, t.store.cipher())
}

func (t *txStore) GetNodesBatch(ctx context.Context, ids []string) ([]*Node, error) {
	return getNodesBatchQ(ctx, t.tx, ids, t.store.cipher())
}

func (t *txStore) UpdateNode(ctx context.Context, n *Node) error {
	return updateNodeQ(ctx, t.tx, n, t.store.cipher())
}

func (t *txStore) UpdateNodeContent(ctx context.Context, id, newContent string) error {
	return updateNodeContentQ(ctx, t.tx, id, newContent, t.store.cipher())
}

func (t *txStore) ArchiveNode(ctx context.Context, id string) (bool, error) {
	return archiveNodeQ(ctx, t.tx, id)
}

func (t *txStore) DeleteNode(ctx context.Context, id string) error { return deleteNodeQ(ctx, t.tx, id) }

func (t *txStore) ListNodes(ctx context.Context, f NodeFilter) ([]*Node, error) {
	return listNodesQ(ctx, t.tx, f, t.store.cipher())
}

func (t *txStore) SearchNodes(ctx context.Context, query string, limit int) ([]*Node, error) {
	return searchNodesQ(ctx, t.tx, query, limit, t.store.cipher())
}

func (t *txStore) SearchNodeByHash(ctx context.Context, hash, scope, project string) (*Node, error) {
	return searchNodeByHashQ(ctx, t.tx, hash, scope, project, t.store.cipher())
}

func (t *txStore) GetNeighbors(ctx context.Context, nodeID string) ([]*Node, error) {
	return getNeighborsQ(ctx, t.tx, nodeID, t.store.cipher())
}

func (t *txStore) CreateEdge(ctx context.Context, e *Edge) error { return createEdgeQ(ctx, t.tx, e) }

func (t *txStore) GetEdge(ctx context.Context, id string) (*Edge, error) {
	return getEdgeQ(ctx, t.tx, id)
}

func (t *txStore) InvalidateEdge(ctx context.Context, id string) error {
	return invalidateEdgeQ(ctx, t.tx, id)
}

func (t *txStore) DeleteEdge(ctx context.Context, id string) error { return deleteEdgeQ(ctx, t.tx, id) }

func (t *txStore) GetEdgesFrom(ctx context.Context, nodeID string) ([]*Edge, error) {
	return queryEdgesQ(ctx, t.tx, `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges WHERE from_id=? AND invalid_at IS NULL`, nodeID)
}

func (t *txStore) GetEdgesTo(ctx context.Context, nodeID string) ([]*Edge, error) {
	return queryEdgesQ(ctx, t.tx, `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges WHERE to_id=? AND invalid_at IS NULL`, nodeID)
}

func (t *txStore) GetValidEdgesFrom(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	at = validityInstant(at)
	return queryEdgesQ(ctx, t.tx, `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
		WHERE from_id=? AND (valid_at IS NULL OR valid_at <= ?) AND (invalid_at IS NULL OR invalid_at > ?)`, nodeID, at, at)
}

func (t *txStore) GetValidEdgesTo(ctx context.Context, nodeID string, at time.Time) ([]*Edge, error) {
	at = validityInstant(at)
	return queryEdgesQ(ctx, t.tx, `SELECT id, from_id, to_id, type, acyclic, weight, metadata, valid_at, invalid_at, created_at FROM edges
		WHERE to_id=? AND (valid_at IS NULL OR valid_at <= ?) AND (invalid_at IS NULL OR invalid_at > ?)`, nodeID, at, at)
}

func (t *txStore) GetEdgesBetween(ctx context.Context, nodeIDs []string) ([]*Edge, error) {
	return getEdgesBetweenQ(ctx, t.tx, nodeIDs)
}

func (t *txStore) GetAllEdgesFor(ctx context.Context, nodeIDs []string) ([]*Edge, error) {
	return getAllEdgesForQ(ctx, t.tx, nodeIDs)
}

func (t *txStore) CountEdges(ctx context.Context, nodeID string) (int, int, error) {
	return countEdgesQ(ctx, t.tx, nodeID)
}

func (t *txStore) CountAllEdges(ctx context.Context) (int, error) { return countAllEdgesQ(ctx, t.tx) }

func (t *txStore) CountEdgesBatch(ctx context.Context, nodeIDs []string) (map[string][2]int, error) {
	return countEdgesBatchQ(ctx, t.tx, nodeIDs)
}

func (t *txStore) NodeStats(ctx context.Context) (map[string]int, int, error) {
	return nodeStatsQ(ctx, t.tx)
}

func (t *txStore) DoctorStats(ctx context.Context) (DoctorStatsResult, error) {
	return doctorStatsQ(ctx, t.tx)
}

func (t *txStore) LastUpdated(ctx context.Context) (time.Time, error) { return lastUpdatedQ(ctx, t.tx) }

func (t *txStore) TopConnected(ctx context.Context, limit int) ([]string, error) {
	return topConnectedQ(ctx, t.tx, limit)
}

func (t *txStore) CheckCycle(ctx context.Context, fromID, toID string) (bool, error) {
	return checkCycleQ(ctx, t.tx, fromID, toID)
}

func (t *txStore) CreateSession(ctx context.Context, sess *Session) error {
	return createSessionQ(ctx, t.tx, sess)
}

func (t *txStore) EndSession(ctx context.Context, id string, summary string) error {
	return endSessionQ(ctx, t.tx, id, summary)
}

func (t *txStore) ListSessions(ctx context.Context, project string, limit int) ([]*Session, error) {
	return listSessionsQ(ctx, t.tx, project, limit)
}

func (t *txStore) SaveVersion(ctx context.Context, nodeID string, content, changedBy, reason string) error {
	return saveVersionQ(ctx, t.tx, nodeID, content, changedBy, reason, t.store.cipher())
}

func (t *txStore) GetVersions(ctx context.Context, nodeID string) ([]*NodeVersion, error) {
	return getVersionsQ(ctx, t.tx, nodeID, t.store.cipher())
}

func (t *txStore) SaveEmbedding(ctx context.Context, nodeID, model string, vector []float32) error {
	if err := saveEmbeddingQ(ctx, t.tx, nodeID, model, vector); err != nil {
		return err
	}
	t.dirtyHNSW[model] = struct{}{}
	return nil
}

func (t *txStore) DeleteEmbedding(ctx context.Context, nodeID string) error {
	// Capture the embedding's model (if any) in-tx so the corresponding
	// HNSW cache gets invalidated after commit.
	_, model, _ := getEmbeddingQ(ctx, t.tx, nodeID)
	// FK order: embeddings_hnsw.node_id references embeddings.node_id, so
	// the graph row goes first.
	if _, err := t.tx.ExecContext(ctx, `DELETE FROM embeddings_hnsw WHERE node_id=?`, nodeID); err != nil {
		return err
	}
	if err := deleteEmbeddingQ(ctx, t.tx, nodeID); err != nil {
		return err
	}
	if model != "" {
		t.dirtyHNSW[model] = struct{}{}
	}
	return nil
}

func (t *txStore) GetEmbedding(ctx context.Context, nodeID string) ([]float32, string, error) {
	return getEmbeddingQ(ctx, t.tx, nodeID)
}

func (t *txStore) AllEmbeddings(ctx context.Context, model string) (map[string][]float32, error) {
	return allEmbeddingsQ(ctx, t.tx, model)
}

func (t *txStore) GetEmbeddingsBatch(ctx context.Context, model string, offset, limit int) (map[string][]float32, error) {
	return getEmbeddingsBatchQ(ctx, t.tx, model, offset, limit)
}

// HNSW methods not supported in transactional store - return error
func (t *txStore) BuildHNSWIndex(ctx context.Context, model string) error {
	return fmt.Errorf("BuildHNSWIndex not supported in transactional store")
}

func (t *txStore) SearchHNSW(ctx context.Context, model string, query []float32, k, ef int) ([]string, []float32, error) {
	return nil, nil, fmt.Errorf("SearchHNSW not supported in transactional store")
}

func (t *txStore) AddFileWatch(ctx context.Context, filePath, nodeID, gitHash string) error {
	return addFileWatchQ(ctx, t.tx, filePath, nodeID, gitHash)
}

func (t *txStore) AddReplayEvent(ctx context.Context, sessionID, data string) error {
	return addReplayEventQ(ctx, t.tx, sessionID, data)
}

func (t *txStore) GetReplayEvents(ctx context.Context, sessionID string) ([]*ReplayEvent, error) {
	return getReplayEventsQ(ctx, t.tx, sessionID)
}

func (t *txStore) LogAccess(ctx context.Context, nodeID string) error {
	return logAccessQ(ctx, t.tx, nodeID)
}

func (t *txStore) SaveNodeMetadata(ctx context.Context, nodeID string, meta map[string]string) error {
	return saveNodeMetadataQ(ctx, t.tx, nodeID, meta)
}

func (t *txStore) LoadNodeMetadata(ctx context.Context, nodeIDs []string) (map[string]map[string]string, error) {
	return loadNodeMetadataQ(ctx, t.tx, nodeIDs)
}

func (t *txStore) SaveSignature(ctx context.Context, nodeID, signature string) error {
	return saveSignatureQ(ctx, t.tx, nodeID, signature)
}

func (t *txStore) GetAllSignatures(ctx context.Context) (map[string]string, error) {
	return getAllSignaturesQ(ctx, t.tx)
}

func (t *txStore) FlushAccessLog(ctx context.Context) (int, error)          { return flushAccessLogQ(ctx, t.tx) }
func (t *txStore) WithTx(ctx context.Context, fn func(Storage) error) error { return fn(t) }

// Backup cannot run inside a transaction: callers must back up through a
// non-transactional Store handle.
func (t *txStore) Backup(ctx context.Context, backupPath string) error {
	return fmt.Errorf("backup is not supported inside a transaction")
}
func (t *txStore) Close() error { return nil }

// RollbackToVersion restores a node's content to a specific version.
// All operations run inside a single transaction to prevent concurrent
// modifications from interleaving between the SELECT and UPDATE.
func (s *Store) RollbackToVersion(ctx context.Context, nodeID string, version int) error {
	return s.WithTx(ctx, func(tx Storage) error {
		// GetVersions is not on Storage interface, so use GetNode + version query via txStore.
		// We need the raw version content. Use the versions listing through txStore.
		var content string
		// txStore implements Storage; cast to access version query
		if tts, ok := tx.(*txStore); ok {
			err := tts.tx.QueryRowContext(ctx,
				`SELECT content FROM node_versions WHERE node_id=? AND version=?`, nodeID, version).Scan(&content)
			if err != nil {
				return fmt.Errorf("version %d not found for node %s: %w", version, nodeID, err)
			}
		} else {
			return fmt.Errorf("unexpected storage type in transaction")
		}
		// Version history stores ciphertext; decrypt before re-encrypting
		// via UpdateNodeContent / SaveVersion to avoid double-encryption.
		vals, err := decryptValues(s.cipher(), content)
		if err != nil {
			return err
		}
		content = vals[0]
		if err := tx.UpdateNodeContent(ctx, nodeID, content); err != nil {
			return err
		}
		return tx.SaveVersion(ctx, nodeID, content, "system", fmt.Sprintf("rollback to v%d", version))
	})
}

// DiffVersions returns the content of two versions for comparison.
func (s *Store) DiffVersions(ctx context.Context, nodeID string, v1, v2 int) (content1, content2 string, err error) {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	err = s.db.QueryRowContext(ctx,
		`SELECT content FROM node_versions WHERE node_id=? AND version=?`, nodeID, v1).Scan(&content1)
	if err != nil {
		return "", "", fmt.Errorf("version %d not found: %w", v1, err)
	}
	err = s.db.QueryRowContext(ctx,
		`SELECT content FROM node_versions WHERE node_id=? AND version=?`, nodeID, v2).Scan(&content2)
	if err != nil {
		return "", "", fmt.Errorf("version %d not found: %w", v2, err)
	}
	// Version history stores ciphertext; decrypt for a plaintext comparison.
	vals, err := decryptValues(s.cipher(), content1, content2)
	if err != nil {
		return "", "", err
	}
	return vals[0], vals[1], nil
}
