// Package privacy strips secrets and sensitive material from memory content
// before storage, via pattern matching, entropy heuristics, and <private> tag
// removal.
package privacy

import (
	"math"
	"regexp"
	"strings"
	"unicode"
)

// FilterLevel controls how aggressively content is filtered.
type FilterLevel int

const (
	// Strict strips everything (emails, IPs, phones, secrets).
	Strict FilterLevel = iota
	// Moderate keeps infrastructure IPs (10.x, 192.168.x) and work-related emails.
	Moderate
	// Minimal only strips high-entropy secrets and explicit API keys.
	Minimal
)

// DefaultFilterLevel is used by Filter() when no level is specified.
var DefaultFilterLevel = Moderate

// secretPatterns are always stripped (all levels including Minimal).
var secretPatterns = []*regexp.Regexp{
	// API keys
	regexp.MustCompile(`sk-[a-zA-Z0-9]{20,}`),                          // OpenAI
	regexp.MustCompile(`AKIA[A-Z0-9]{16}`),                             // AWS Access Key
	regexp.MustCompile(`gh[pousr]_[A-Za-z0-9_]{36,}`),                  // GitHub tokens
	regexp.MustCompile(`glpat-[a-zA-Z0-9_\-]{20,}`),                    // GitLab PAT
	regexp.MustCompile(`SG\.[a-zA-Z0-9_\-]{20,}\.[a-zA-Z0-9_\-]{20,}`), // SendGrid API key
	regexp.MustCompile(`xox[bpras]-[A-Za-z0-9\-]{10,}`),                // Slack tokens
	regexp.MustCompile(`sk_live_[A-Za-z0-9]{20,}`),                     // Stripe secret key
	regexp.MustCompile(`npm_[A-Za-z0-9]{36,}`),                         // npm token
	// JWT / tokens
	regexp.MustCompile(`eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]*`),
	// Auth headers
	regexp.MustCompile(`Bearer\s+[A-Za-z0-9_.\-]+`),
	regexp.MustCompile(`Basic\s+[A-Za-z0-9+/=]{20,}`),
	regexp.MustCompile(`(?i)(PASSWORD|SECRET|KEY|TOKEN|API_KEY)\s*=\s*\S+`),
	// Private keys
	regexp.MustCompile(`-----BEGIN\s+\w+\s+PRIVATE\s+KEY-----[\s\S]*?-----END\s+\w+\s+PRIVATE\s+KEY-----`),
	// Connection strings with passwords
	regexp.MustCompile(`(?i)(postgres|mysql|mongodb)://[^\s"]+:[^\s"]+@[^\s"]+`),
}

// piiPatterns are stripped by Strict and Moderate (but not Minimal).
var piiPatterns = []*regexp.Regexp{
	// PII: US phone numbers
	regexp.MustCompile(`\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b`),
	// PII: US Social Security Numbers
	regexp.MustCompile(`\b\d{3}-\d{2}-\d{4}\b`),
	// PII: credit card numbers (basic Luhn-eligible patterns)
	regexp.MustCompile(`\b(?:\d[ -]*?){13,19}\b`),
}

// strictOnlyPatterns are only stripped in Strict mode.
var strictOnlyPatterns = []*regexp.Regexp{
	// PII: email addresses (Moderate keeps work emails). \p{L}/\p{N} (rather
	// than a-zA-Z0-9) so internationalized (SMTPUTF8, RFC 6531) addresses with
	// a literal non-ASCII local part or domain — e.g. "üser@müenchen.de" —
	// are also redacted; punycode-encoded IDN domains were already ASCII and
	// matched the narrower pattern.
	regexp.MustCompile(`[\p{L}\p{N}._%+\-]+@[\p{L}\p{N}.\-]+\.[\p{L}]{2,}`),
	// PII: IPv4 addresses (Moderate keeps infrastructure IPs like 10.x, 192.168.x)
	regexp.MustCompile(`\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b`),
}

// Filter replaces secrets in content with [REDACTED] using DefaultFilterLevel.
func Filter(content string) string {
	return FilterWithLevel(content, DefaultFilterLevel)
}

// FilterWithLevel replaces secrets in content with [REDACTED] at the specified level.
func FilterWithLevel(content string, level FilterLevel) string {
	// All levels strip explicit secrets
	for _, p := range secretPatterns {
		content = p.ReplaceAllString(content, "[REDACTED]")
	}

	// Moderate and Strict also strip PII patterns (phones, SSNs, credit cards)
	if level <= Moderate {
		for _, p := range piiPatterns {
			content = p.ReplaceAllString(content, "[REDACTED]")
		}
	}

	// Strict strips everything including emails and all IPs
	if level == Strict {
		for _, p := range strictOnlyPatterns {
			content = p.ReplaceAllString(content, "[REDACTED]")
		}
	}

	// Catch high-entropy tokens that regexes might miss.
	// Only target tokens that look like standalone secrets (no JSON, no code).
	// Replacement is done by byte offset (not a global substring Replace), so a
	// short flagged token that happens to also appear as a substring of an
	// earlier, unrelated word cannot cause the wrong location to be redacted
	// while the actual flagged token is left untouched.
	content = redactHighEntropyWords(content)
	return content
}

// wordPattern matches whitespace-delimited words, used to locate entropy
// candidates by exact byte offset rather than by substring search.
var wordPattern = regexp.MustCompile(`\S+`)

func redactHighEntropyWords(content string) string {
	var sb strings.Builder
	lastIdx := 0
	for _, loc := range wordPattern.FindAllStringIndex(content, -1) {
		wordStart, wordEnd := loc[0], loc[1]
		word := content[wordStart:wordEnd]
		clean := strings.Trim(word, `"',:;{}[]()`)
		if len(clean) >= 24 && !strings.ContainsAny(clean, "{}[]():/ ") && IsLikelySecret(clean) {
			// clean is word with leading/trailing punctuation trimmed; locate
			// its exact span within this word so surrounding punctuation is preserved.
			cleanStart := wordStart + strings.Index(word, clean)
			cleanEnd := cleanStart + len(clean)
			sb.WriteString(content[lastIdx:cleanStart])
			sb.WriteString("[REDACTED]")
			lastIdx = cleanEnd
		}
	}
	sb.WriteString(content[lastIdx:])
	return sb.String()
}

// hasHighEntropy returns true if a string has Shannon entropy above threshold.
// Useful for detecting random tokens that regexes might miss.
func hasHighEntropy(s string, threshold float64) bool {
	if len(s) < 20 {
		return false
	}
	freq := make(map[rune]int)
	for _, r := range s {
		freq[r]++
	}
	var entropy float64
	length := float64(len(s))
	for _, count := range freq {
		p := float64(count) / length
		if p > 0 {
			entropy -= p * math.Log2(p)
		}
	}
	return entropy >= threshold
}

// IsLikelySecret heuristically determines if a token string is a secret.
//
// Two shapes are treated as secrets:
//  1. Mixed tokens with a moderate fraction of special characters (0.1–0.4),
//     e.g. structured keys like "abc-123_def.ghi".
//  2. Pure alphanumeric tokens with high Shannon entropy, e.g. hex digests and
//     base64-without-padding random keys. These have a special-char ratio of
//     ~0, so the ratio gate alone would never catch them — the dominant secret
//     shape in practice.
func IsLikelySecret(token string) bool {
	if len(token) < 16 {
		return false
	}
	// Exclude tokens that look like code constants (UPPER_SNAKE_CASE).
	// Constants use underscores as word separators and only [A-Z0-9_].
	if isUpperSnakeCase(token) {
		return false
	}
	special := 0
	for _, r := range token {
		if !unicode.IsLetter(r) && !unicode.IsDigit(r) {
			special++
		}
	}
	ratio := float64(special) / float64(len(token))
	// (1) Mixed tokens: a moderate fraction of separators suggests a structured key.
	if ratio > 0.1 && ratio < 0.4 {
		return true
	}
	// (2) Pure-alphanumeric tokens (hex / base64-no-symbol / random keys):
	// near-zero special ratio. Require BOTH letters and digits — this is the
	// real discriminator, since 32-char hex digests (~3.66 bits) actually have
	// LOWER entropy than long lowercase prose (~3.75 bits), so entropy alone
	// cannot separate them. The mixed-alnum gate excludes prose and all-digit
	// IDs; a modest entropy floor then rejects low-information repetitive tokens.
	if ratio <= 0.1 && len(token) >= 24 && hasMixedAlnum(token) && hasHighEntropy(token, 3.5) {
		return true
	}
	return false
}

// hasMixedAlnum reports whether s contains at least one letter and one digit.
// Random secrets almost always mix both; English words and numeric IDs do not.
func hasMixedAlnum(s string) bool {
	var hasLetter, hasDigit bool
	for _, r := range s {
		switch {
		case unicode.IsLetter(r):
			hasLetter = true
		case unicode.IsDigit(r):
			hasDigit = true
		}
		if hasLetter && hasDigit {
			return true
		}
	}
	return false
}

// isUpperSnakeCase returns true for tokens like MAX_RETRY_COUNT_VALUE.
func isUpperSnakeCase(s string) bool {
	hasUnderscore := false
	for _, r := range s {
		if r == '_' {
			hasUnderscore = true
		} else if !unicode.IsUpper(r) && !unicode.IsDigit(r) {
			return false
		}
	}
	return hasUnderscore
}
