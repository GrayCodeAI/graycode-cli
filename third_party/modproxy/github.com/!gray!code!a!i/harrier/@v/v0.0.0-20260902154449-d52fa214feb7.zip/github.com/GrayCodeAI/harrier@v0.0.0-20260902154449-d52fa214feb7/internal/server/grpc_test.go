package server

import (
	"context"
	"net"
	"path/filepath"
	"testing"
	"time"

	harrierproto "github.com/GrayCodeAI/harrier/api/proto"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/test/bufconn"
)

// setupGrpcServer mirrors setupMCPServer (mcp_test.go): a *GrpcServer backed
// by a temporary SQLite store, served in-memory over bufconn so no real
// network port is used.
func setupGrpcServer(t *testing.T, withBroadcaster bool) (harrierproto.HarrierServiceClient, *engine.Engine, func()) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	eng := engine.New(store, graph.New(store, store.DB()))

	var broadcaster *SSEBroadcaster
	var stopBroadcast func()
	if withBroadcaster {
		broadcaster = NewSSEBroadcaster(eng)
		bctx, cancel := context.WithCancel(context.Background())
		go broadcaster.Start(bctx)
		stopBroadcast = cancel
	}

	grpcSrv := NewGrpcServer(eng, broadcaster)

	lis := bufconn.Listen(1024 * 1024)
	s := grpc.NewServer()
	harrierproto.RegisterHarrierServiceServer(s, grpcSrv)
	go func() { _ = s.Serve(lis) }()

	conn, err := grpc.NewClient(
		"passthrough:///bufnet",
		grpc.WithContextDialer(func(context.Context, string) (net.Conn, error) { return lis.Dial() }),
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		t.Fatal(err)
	}
	client := harrierproto.NewHarrierServiceClient(conn)

	cleanup := func() {
		_ = conn.Close()
		s.Stop()
		if stopBroadcast != nil {
			stopBroadcast()
		}
		eng.Close()
		_ = store.Close()
	}
	return client, eng, cleanup
}

func TestGrpc_RememberAndRecall(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()
	ctx := context.Background()

	rememberResp, err := client.Remember(ctx, &harrierproto.RememberRequest{
		Content:  "the deploy script lives in scripts/deploy.sh",
		Category: "convention",
		Scope:    "project",
		Project:  "proj-a",
		Tags:     []string{"deploy", "scripts"},
	})
	if err != nil {
		t.Fatalf("Remember: %v", err)
	}
	if rememberResp.GetNodeId() == "" {
		t.Fatal("Remember returned empty node_id")
	}
	if !rememberResp.GetCreated() {
		t.Error("Remember: Created = false, want true for a new node")
	}

	recallResp, err := client.Recall(ctx, &harrierproto.RecallRequest{
		Query:   "deploy script",
		Project: "proj-a",
	})
	if err != nil {
		t.Fatalf("Recall: %v", err)
	}
	if len(recallResp.GetNodes()) == 0 {
		t.Error("Recall returned no nodes for a query matching the remembered content")
	}
	found := false
	for _, n := range recallResp.GetNodes() {
		if n.GetId() == rememberResp.GetNodeId() {
			found = true
		}
	}
	if !found {
		t.Error("Recall didn't return the just-remembered node")
	}
}

func TestGrpc_RememberInvalidCategory(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()

	_, err := client.Remember(context.Background(), &harrierproto.RememberRequest{
		Content:  "x",
		Category: "not-a-real-type",
		Project:  "proj-a",
	})
	if err == nil {
		t.Fatal("expected an error for an invalid category/type, got nil")
	}
}

func TestGrpc_LinkForgetUnlink(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()
	ctx := context.Background()

	a, err := client.Remember(ctx, &harrierproto.RememberRequest{Content: "node a", Category: "convention", Project: "p"})
	if err != nil {
		t.Fatalf("Remember(a): %v", err)
	}
	b, err := client.Remember(ctx, &harrierproto.RememberRequest{Content: "node b", Category: "convention", Project: "p"})
	if err != nil {
		t.Fatalf("Remember(b): %v", err)
	}

	link, err := client.Link(ctx, &harrierproto.LinkRequest{
		FromId: a.GetNodeId(),
		ToId:   b.GetNodeId(),
		Type:   "relates_to",
	})
	if err != nil {
		t.Fatalf("Link: %v", err)
	}
	if link.GetEdgeId() == "" {
		t.Fatal("Link returned empty edge_id")
	}

	sg, err := client.Subgraph(ctx, &harrierproto.SubgraphRequest{NodeId: a.GetNodeId(), Depth: 2})
	if err != nil {
		t.Fatalf("Subgraph: %v", err)
	}
	if len(sg.GetEdges()) == 0 {
		t.Error("Subgraph returned no edges after Link")
	}

	if _, err := client.Unlink(ctx, &harrierproto.UnlinkRequest{EdgeId: link.GetEdgeId()}); err != nil {
		t.Fatalf("Unlink: %v", err)
	}

	forgetResp, err := client.Forget(ctx, &harrierproto.ForgetRequest{NodeId: a.GetNodeId()})
	if err != nil {
		t.Fatalf("Forget: %v", err)
	}
	if !forgetResp.GetDeleted() {
		t.Error("Forget: Deleted = false, want true")
	}
}

func TestGrpc_LinkInvalidEdgeType(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()

	_, err := client.Link(context.Background(), &harrierproto.LinkRequest{
		FromId: "a", ToId: "b", Type: "not-a-real-edge-type",
	})
	if err == nil {
		t.Fatal("expected an error for an invalid edge type, got nil")
	}
}

func TestGrpc_HealthAndGraphStats(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()
	ctx := context.Background()

	if _, err := client.Remember(ctx, &harrierproto.RememberRequest{Content: "x", Category: "convention", Project: "p"}); err != nil {
		t.Fatalf("Remember: %v", err)
	}

	health, err := client.Health(ctx, &harrierproto.HealthRequest{})
	if err != nil {
		t.Fatalf("Health: %v", err)
	}
	if health.GetStatus() != "ok" {
		t.Errorf("Health.Status = %q, want ok", health.GetStatus())
	}
	if health.GetNodeCount() < 1 {
		t.Errorf("Health.NodeCount = %d, want >= 1", health.GetNodeCount())
	}

	stats, err := client.GraphStats(ctx, &harrierproto.GraphStatsRequest{})
	if err != nil {
		t.Fatalf("GraphStats: %v", err)
	}
	if stats.GetTotalNodes() < 1 {
		t.Errorf("GraphStats.TotalNodes = %d, want >= 1", stats.GetTotalNodes())
	}
}

func TestGrpc_SessionStartEnd(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()
	ctx := context.Background()

	if _, err := client.SessionStart(ctx, &harrierproto.SessionStartRequest{SessionId: "sess-1", Project: "p"}); err != nil {
		t.Fatalf("SessionStart: %v", err)
	}
	if _, err := client.SessionEnd(ctx, &harrierproto.SessionEndRequest{SessionId: "sess-1", Summary: "done", Success: true}); err != nil {
		t.Fatalf("SessionEnd: %v", err)
	}
}

func TestGrpc_WatchMemoriesWithoutBroadcaster(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, false)
	defer cleanup()

	stream, err := client.WatchMemories(context.Background(), &harrierproto.WatchMemoriesRequest{})
	if err != nil {
		t.Fatalf("WatchMemories (open): %v", err)
	}
	if _, err := stream.Recv(); err == nil {
		t.Fatal("expected an Unavailable error when no broadcaster is configured, got nil")
	}
}

func TestGrpc_WatchMemoriesDeliversEvent(t *testing.T) {
	client, _, cleanup := setupGrpcServer(t, true)
	defer cleanup()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	stream, err := client.WatchMemories(ctx, &harrierproto.WatchMemoriesRequest{})
	if err != nil {
		t.Fatalf("WatchMemories: %v", err)
	}

	// Give the stream a moment to subscribe before triggering the event.
	time.Sleep(50 * time.Millisecond)

	if _, err := client.Remember(ctx, &harrierproto.RememberRequest{Content: "watched", Category: "convention", Project: "p"}); err != nil {
		t.Fatalf("Remember: %v", err)
	}

	evt, err := stream.Recv()
	if err != nil {
		t.Fatalf("stream.Recv: %v", err)
	}
	if evt.GetType() != "created" {
		t.Errorf("event Type = %q, want created", evt.GetType())
	}
	if evt.GetContent() != "watched" {
		t.Errorf("event Content = %q, want %q", evt.GetContent(), "watched")
	}
}
