package engine

import (
	"context"
	"path/filepath"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// newConsolidationEngine builds an engine backed by a temp SQLite store.
func newConsolidationEngine(t *testing.T) *Engine {
	t.Helper()
	store, err := storage.NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	eng := New(store, graph.New(store, store.DB()))
	t.Cleanup(eng.Close)
	return eng
}

// waitForCycles polls until at least min cycles have completed or the deadline
// passes, returning the observed count.
func waitForCycles(t *testing.T, eng *Engine, min int64, timeout time.Duration) int64 {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if c := eng.ConsolidationCycles(); c >= min {
			return c
		}
		time.Sleep(2 * time.Millisecond)
	}
	return eng.ConsolidationCycles()
}

func TestStartConsolidationRunsAndStops(t *testing.T) {
	t.Parallel()
	eng := newConsolidationEngine(t)
	ctx := context.Background()

	// Seed a node so decay/conflict/compaction have something to operate on.
	if _, err := eng.Remember(ctx, RememberInput{
		Type:    "decision",
		Content: "We use SQLite with WAL mode for storage",
		Scope:   "project",
		Project: "demo",
	}); err != nil {
		t.Fatalf("Remember: %v", err)
	}

	if !eng.StartConsolidation(ctx, 5*time.Millisecond) {
		t.Fatal("StartConsolidation returned false on first start")
	}

	// At least one cycle should run within a generous window.
	if got := waitForCycles(t, eng, 1, 2*time.Second); got < 1 {
		t.Fatalf("expected >=1 consolidation cycle, got %d", got)
	}

	// Stop and confirm the loop halts: the count must not advance afterwards.
	eng.StopConsolidation()
	if c := eng.ConsolidationCycles(); c != 0 {
		t.Errorf("ConsolidationCycles after stop = %d, want 0 (state cleared)", c)
	}

	// StartConsolidation can be called again after a stop.
	if !eng.StartConsolidation(ctx, 5*time.Millisecond) {
		t.Fatal("StartConsolidation returned false after stop; expected restart to succeed")
	}
	eng.StopConsolidation()
}

func TestStartConsolidationStopsOnContextCancel(t *testing.T) {
	t.Parallel()
	eng := newConsolidationEngine(t)
	ctx, cancel := context.WithCancel(context.Background())

	if !eng.StartConsolidation(ctx, 5*time.Millisecond) {
		t.Fatal("StartConsolidation returned false")
	}
	if got := waitForCycles(t, eng, 1, 2*time.Second); got < 1 {
		t.Fatalf("expected >=1 cycle before cancel, got %d", got)
	}

	// Cancelling the supplied context must terminate the loop goroutine.
	cancel()

	// The goroutine should observe the cancellation and exit; once it does, a
	// subsequent StopConsolidation must not block (done channel is closed) and
	// a fresh StartConsolidation must succeed.
	done := make(chan struct{})
	go func() {
		eng.StopConsolidation()
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("StopConsolidation blocked after context cancel — loop did not exit")
	}

	if !eng.StartConsolidation(context.Background(), 5*time.Millisecond) {
		t.Fatal("could not restart consolidation after context cancel")
	}
	eng.StopConsolidation()
}

func TestStartConsolidationDoubleStartIsNoop(t *testing.T) {
	t.Parallel()
	eng := newConsolidationEngine(t)
	ctx := context.Background()

	if !eng.StartConsolidation(ctx, time.Hour) {
		t.Fatal("first StartConsolidation should return true")
	}
	if eng.StartConsolidation(ctx, time.Hour) {
		t.Error("second StartConsolidation should return false while one is running")
	}
	eng.StopConsolidation()
}

func TestStopConsolidationWithoutStartIsSafe(t *testing.T) {
	t.Parallel()
	eng := newConsolidationEngine(t)
	// Must not panic or block.
	eng.StopConsolidation()
	if c := eng.ConsolidationCycles(); c != 0 {
		t.Errorf("ConsolidationCycles with no loop = %d, want 0", c)
	}
}
