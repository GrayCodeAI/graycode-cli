package storage

import (
	"context"
	"testing"
)

func TestAddFileWatchAndGetNodesByFile(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"n1", "n2", "n3"} {
		if err := s.CreateNode(ctx, &Node{ID: id, Type: "convention", Content: id, ContentHash: "h" + id, Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}

	// n1 and n2 watch the same file; n3 watches a different file.
	if err := s.AddFileWatch(ctx, "main.go", "n1", "gita"); err != nil {
		t.Fatalf("AddFileWatch n1: %v", err)
	}
	if err := s.AddFileWatch(ctx, "main.go", "n2", "gitb"); err != nil {
		t.Fatalf("AddFileWatch n2: %v", err)
	}
	if err := s.AddFileWatch(ctx, "other.go", "n3", "gitc"); err != nil {
		t.Fatalf("AddFileWatch n3: %v", err)
	}

	got, err := s.GetNodesByFile(ctx, "main.go")
	if err != nil {
		t.Fatalf("GetNodesByFile: %v", err)
	}
	ids := map[string]bool{}
	for _, n := range got {
		ids[n.ID] = true
	}
	if len(ids) != 2 || !ids["n1"] || !ids["n2"] {
		t.Errorf("expected n1 and n2 for main.go, got %v", ids)
	}
	if ids["n3"] {
		t.Errorf("n3 (other.go) leaked into main.go results")
	}

	other, err := s.GetNodesByFile(ctx, "other.go")
	if err != nil {
		t.Fatalf("GetNodesByFile other: %v", err)
	}
	if len(other) != 1 || other[0].ID != "n3" {
		t.Errorf("expected only n3 for other.go, got %v", other)
	}
}

func TestGetNodesByFileNoMatch(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	got, err := s.GetNodesByFile(ctx, "absent.go")
	if err != nil {
		t.Fatalf("GetNodesByFile: %v", err)
	}
	if len(got) != 0 {
		t.Errorf("expected no nodes, got %d", len(got))
	}
}
