package server

import (
	"context"

	mcpkit "github.com/GrayCodeAI/harrier/internal/mcpkit"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/mark3labs/mcp-go/mcp"
	mcpserver "github.com/mark3labs/mcp-go/server"
)

// MCPServer wraps the shared mcpkit MCP scaffolding with harrier's tool,
// resource, and prompt registrations plus the engine that backs them.
type MCPServer struct {
	eng *engine.Engine
	srv *mcpkit.Server
}

// WithAPIKey makes HTTP requests require a matching Bearer or X-API-Key
// token before reaching any MCP surface (initialize, resources, prompts,
// tools). Has no effect on ServeStdio, which is a trusted local subprocess
// pipe.
func (s *MCPServer) WithAPIKey(key string) *MCPServer {
	s.srv.WithHTTPToken(key)
	return s
}

// NewMCPServer creates an MCP server with all harrier tools registered.
func NewMCPServer(eng *engine.Engine) *MCPServer {
	s := &MCPServer{eng: eng}
	// harrier exposes a resource *list* rather than a set of subscribable
	// resources, so it opts into resource-list-changed updates (the
	// second arg) — overriding mcpkit's read-only default.
	s.srv = mcpkit.New("harrier", "0.1.0", mcpserver.WithResourceCapabilities(true, false))
	s.registerTools()
	s.registerResources()
	s.registerPrompts()
	return s
}

// ServeStdio starts the MCP server on stdin/stdout.
func (s *MCPServer) ServeStdio() error {
	return s.srv.ServeStdio()
}

// ServeHTTP starts the MCP server on a streamable HTTP endpoint.
// The default endpoint path is /mcp. Clients connect to http://<addr>/mcp.
func (s *MCPServer) ServeHTTP(addr string) error {
	return s.srv.ServeHTTP(addr)
}

// ServeHTTPWithShutdown starts the MCP server on a streamable HTTP endpoint
// and returns the server so the caller can invoke Shutdown for graceful
// teardown.
func (s *MCPServer) ServeHTTPWithShutdown(addr string) (*mcpserver.StreamableHTTPServer, error) {
	return s.srv.ServeHTTPWithShutdown(addr)
}

// mcp returns the underlying mcp-go server so the progress notification
// helper can reach mcp-go's send path directly.
func (s *MCPServer) mcp() *mcpserver.MCPServer {
	return s.srv.MCP()
}

func (s *MCPServer) registerTools() {
	add := func(tool mcp.Tool, handler mcpserver.ToolHandlerFunc) {
		s.srv.AddTool(tool, handler)
	}

	// harrier_remember
	add(mcp.NewTool(
		"harrier_remember",
		mcp.WithDescription("Store a memory node with type, metadata, and auto-linked entities"),
		mcp.WithString("content", mcp.Required(), mcp.Description("Memory content")),
		mcp.WithString("type", mcp.Description("Node type: convention|decision|bug|spec|task|preference")),
		mcp.WithString("summary", mcp.Description("Short summary")),
		mcp.WithString("tags", mcp.Description("Comma-separated tags")),
		mcp.WithString("project", mcp.Description("Project path")),
		mcp.WithString("scope", mcp.Description("global or project")),
	), s.handleRemember)

	// harrier_recall
	add(mcp.NewTool(
		"harrier_recall",
		mcp.WithDescription("Graph-aware search: BM25 seed → graph expansion → ranked results"),
		mcp.WithString("query", mcp.Required(), mcp.Description("Search query")),
		mcp.WithNumber("depth", mcp.Description("Graph expansion depth (default 2)")),
		mcp.WithNumber("limit", mcp.Description("Max results (default 10)")),
		mcp.WithString("type", mcp.Description("Filter by node type")),
		mcp.WithString("project", mcp.Description("Filter by project")),
	), s.handleRecall)

	// harrier_context
	add(mcp.NewTool(
		"harrier_context",
		mcp.WithDescription("Get session-start context: hot-tier subgraph for injection"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleContext)

	// harrier_forget
	add(mcp.NewTool(
		"harrier_forget",
		mcp.WithDescription("Archive a memory node"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Node ID to forget")),
	), s.handleForget)

	// harrier_link
	add(mcp.NewTool(
		"harrier_link",
		mcp.WithDescription("Create an edge between two nodes"),
		mcp.WithString("from_id", mcp.Required(), mcp.Description("Source node ID")),
		mcp.WithString("to_id", mcp.Required(), mcp.Description("Target node ID")),
		mcp.WithString("type", mcp.Required(), mcp.Description("Edge type: caused_by|led_to|supersedes|relates_to|depends_on|touches|learned_in|part_of")),
	), s.handleLink)

	// harrier_unlink
	add(mcp.NewTool(
		"harrier_unlink",
		mcp.WithDescription("Remove an edge"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Edge ID to remove")),
	), s.handleUnlink)

	// harrier_improve — 4th operation in cognee's memory API (remember/recall/forget/improve)
	add(mcp.NewTool(
		"harrier_improve",
		mcp.WithDescription("Re-process memories to enhance quality: regenerate summaries, refresh embeddings, consolidate duplicates"),
		mcp.WithString("project", mcp.Description("Project to improve (empty = all)")),
		mcp.WithNumber("min_confidence", mcp.Description("Only improve nodes with confidence below this (default 0.5)")),
		mcp.WithNumber("min_access_count", mcp.Description("Only improve nodes accessed at least this many times")),
		mcp.WithBoolean("consolidate_duplicates", mcp.Description("Merge near-duplicate nodes")),
		mcp.WithBoolean("regenerate_summaries", mcp.Description("Regenerate summaries for nodes with poor summaries")),
		mcp.WithBoolean("refresh_embeddings", mcp.Description("Re-embed nodes to refresh vectors")),
		mcp.WithNumber("limit", mcp.Description("Max nodes to process (default 1000)")),
	), s.handleImprove)

	// harrier_qa_remember — structured QA entry (cognee pattern)
	add(mcp.NewTool(
		"harrier_qa_remember",
		mcp.WithDescription("Store a structured Q&A entry with optional feedback"),
		mcp.WithString("question", mcp.Required(), mcp.Description("The question")),
		mcp.WithString("answer", mcp.Required(), mcp.Description("The answer")),
		mcp.WithString("context", mcp.Description("Additional context")),
		mcp.WithString("project", mcp.Required(), mcp.Description("Project path")),
		mcp.WithString("session_id", mcp.Description("Session ID")),
		mcp.WithString("source_agent", mcp.Description("Agent that generated this entry")),
	), s.handleQARemember)

	// harrier_trace_remember — structured trace entry (cognee pattern)
	add(mcp.NewTool(
		"harrier_trace_remember",
		mcp.WithDescription("Store a structured trace entry for agent execution"),
		mcp.WithString("origin_function", mcp.Required(), mcp.Description("Function/tool that was called")),
		mcp.WithString("status", mcp.Description("success or error")),
		mcp.WithString("method_params", mcp.Description("JSON-encoded parameters")),
		mcp.WithString("method_return_value", mcp.Description("JSON-encoded return value")),
		mcp.WithString("error_message", mcp.Description("Error message if failed")),
		mcp.WithString("project", mcp.Required(), mcp.Description("Project path")),
		mcp.WithString("session_id", mcp.Description("Session ID")),
	), s.handleTraceRemember)

	// harrier_feedback_remember — structured feedback entry (cognee pattern)
	add(mcp.NewTool(
		"harrier_feedback_remember",
		mcp.WithDescription("Store feedback on an existing QA entry"),
		mcp.WithString("target_node_id", mcp.Required(), mcp.Description("ID of the QA entry to feedback on")),
		mcp.WithString("feedback_text", mcp.Description("Feedback text")),
		mcp.WithNumber("score", mcp.Description("Feedback score 1-5")),
		mcp.WithString("project", mcp.Required(), mcp.Description("Project path")),
		mcp.WithString("session_id", mcp.Description("Session ID")),
	), s.handleFeedbackRemember)

	// harrier_sync_session — sync session memories to permanent graph
	add(mcp.NewTool(
		"harrier_sync_session",
		mcp.WithDescription("Sync session-scoped memories to the permanent graph (call at session end)"),
		mcp.WithString("session_id", mcp.Required(), mcp.Description("Session ID to sync")),
	), s.handleSyncSession)

	// harrier_recall_session — session-aware recall (session cache + permanent graph)
	add(mcp.NewTool(
		"harrier_recall_session",
		mcp.WithDescription("Session-aware recall: checks session cache first, then permanent graph"),
		mcp.WithString("query", mcp.Required(), mcp.Description("Search query")),
		mcp.WithString("session_id", mcp.Required(), mcp.Description("Session ID")),
		mcp.WithString("project", mcp.Description("Filter by project")),
		mcp.WithNumber("limit", mcp.Description("Max results (default 10)")),
	), s.handleRecallSession)

	// harrier_subgraph
	add(mcp.NewTool(
		"harrier_subgraph",
		mcp.WithDescription("Get subgraph around a node via BFS"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Center node ID")),
		mcp.WithNumber("depth", mcp.Description("BFS depth (default 2)")),
	), s.handleSubgraph)

	// harrier_impact
	add(mcp.NewTool(
		"harrier_impact",
		mcp.WithDescription("Impact analysis: what memories are affected if a file changes"),
		mcp.WithString("file", mcp.Required(), mcp.Description("File path")),
		mcp.WithNumber("depth", mcp.Description("Traversal depth (default 3)")),
	), s.handleImpact)

	// harrier_status
	add(mcp.NewTool(
		"harrier_status",
		mcp.WithDescription("Health check: node/edge counts, session count"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleStatus)

	// harrier_task_update
	add(mcp.NewTool(
		"harrier_task_update",
		mcp.WithDescription("Update a task node's content/status"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Task node ID")),
		mcp.WithString("content", mcp.Required(), mcp.Description("Updated task content")),
	), s.handleTaskUpdate)

	// harrier_sessions
	add(mcp.NewTool(
		"harrier_sessions",
		mcp.WithDescription("List recent sessions"),
		mcp.WithString("project", mcp.Description("Project path")),
		mcp.WithNumber("limit", mcp.Description("Max results (default 10)")),
	), s.handleSessions)

	// harrier_stale
	add(mcp.NewTool(
		"harrier_stale",
		mcp.WithDescription("Show potentially stale memory subgraphs"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleStale)

	// harrier_intent
	add(mcp.NewTool(
		"harrier_intent",
		mcp.WithDescription("Classify query intent (Why/When/Who/How/What/General) for intent-aware retrieval"),
		mcp.WithString("query", mcp.Required(), mcp.Description("Query to classify")),
	), s.handleIntent)

	// harrier_profile
	add(mcp.NewTool(
		"harrier_profile",
		mcp.WithDescription("Get auto-maintained user/project profile: static facts + dynamic recent context"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleProfile)

	// harrier_feedback
	add(mcp.NewTool(
		"harrier_feedback",
		mcp.WithDescription("Approve, edit, or discard a memory node"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Node ID")),
		mcp.WithString("action", mcp.Required(), mcp.Description("approve|edit|discard")),
		mcp.WithString("content", mcp.Description("New content (required for edit)")),
	), s.handleFeedback)

	// harrier_hybrid_recall
	add(mcp.NewTool(
		"harrier_hybrid_recall",
		mcp.WithDescription("Hybrid search: BM25 + vector + graph with RRF fusion ranking"),
		mcp.WithString("query", mcp.Required(), mcp.Description("Search query")),
		mcp.WithNumber("depth", mcp.Description("Graph expansion depth (default 2)")),
		mcp.WithNumber("limit", mcp.Description("Max results (default 10)")),
	), s.handleHybridRecall)

	// harrier_proactive
	add(mcp.NewTool(
		"harrier_proactive",
		mcp.WithDescription("Get proactively predicted context for the current session"),
		mcp.WithString("project", mcp.Description("Project path")),
		mcp.WithNumber("budget", mcp.Description("Token budget (default 2000)")),
	), s.handleProactive)

	// harrier_compact
	add(mcp.NewTool(
		"harrier_compact",
		mcp.WithDescription("Compact graph: merge low-confidence memories into summaries"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleCompact)

	// harrier_mental_model
	add(mcp.NewTool(
		"harrier_mental_model",
		mcp.WithDescription("Get auto-evolving project summary: conventions, decisions, architecture"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleMentalModel)

	// harrier_pin
	add(mcp.NewTool(
		"harrier_pin",
		mcp.WithDescription("Pin/unpin a memory node (pinned nodes always appear in context)"),
		mcp.WithString("id", mcp.Required(), mcp.Description("Node ID")),
		mcp.WithBoolean("pinned", mcp.Description("true to pin, false to unpin (default: toggle)")),
	), s.handlePin)

	// harrier_skill_store
	add(mcp.NewTool(
		"harrier_skill_store",
		mcp.WithDescription("Store a procedural skill (step-by-step procedure)"),
		mcp.WithString("name", mcp.Required(), mcp.Description("Skill name")),
		mcp.WithString("description", mcp.Required(), mcp.Description("What this skill does")),
		mcp.WithString("steps", mcp.Required(), mcp.Description("JSON array of step descriptions")),
	), s.handleSkillStore)

	// harrier_skill_get
	add(mcp.NewTool(
		"harrier_skill_get",
		mcp.WithDescription("Retrieve a stored skill by name"),
		mcp.WithString("name", mcp.Required(), mcp.Description("Skill name")),
	), s.handleSkillGet)

	// harrier_session_recap
	add(mcp.NewTool(
		"harrier_session_recap",
		mcp.WithDescription("Show what was captured in the last session (pick up where you left off)"),
		mcp.WithString("project", mcp.Description("Project path")),
	), s.handleSessionRecap)

	// harrier_communities — GraphRAG-style community detection
	add(mcp.NewTool(
		"harrier_communities",
		mcp.WithDescription("Detect memory communities (clusters of related memories). Enables 'what are the main themes?' queries."),
	), s.handleCommunities)

	// harrier_hierarchy — RAPTOR-style multi-level abstraction
	add(mcp.NewTool(
		"harrier_hierarchy",
		mcp.WithDescription("View memory at different abstraction levels: specific (0), topic (1), or global (2)"),
		mcp.WithNumber("level", mcp.Description("Abstraction level: 0=specific, 1=topic, 2=global (default: adaptive)")),
		mcp.WithString("query", mcp.Description("Optional query for level-specific retrieval")),
	), s.handleHierarchy)

	// harrier_sparsify — Memory³-style memory cleanup
	add(mcp.NewTool(
		"harrier_sparsify",
		mcp.WithDescription("Clean up memory: merge near-duplicates, compress low-value clusters, prune orphans. Keeps graph lean."),
	), s.handleSparsify)

	// harrier_verify — HMAC integrity check
	add(mcp.NewTool(
		"harrier_verify",
		mcp.WithDescription("Verify memory integrity. Detects if any memories were tampered with outside harrier."),
	), s.handleVerify)
}

// sendProgress sends an MCP progress notification to the client if a
// progressToken was provided in the request metadata. Errors are silently
// ignored — progress is best-effort and must never break the tool call.
func sendProgress(ctx context.Context, srv *mcpserver.MCPServer, token mcp.ProgressToken, progress, total float64, message string) {
	if token == nil || srv == nil {
		return
	}
	_ = srv.SendNotificationToClient(ctx, "notifications/progress", map[string]any{
		"progress":      progress,
		"total":         total,
		"progressToken": token,
		"message":       message,
	})
}

// --- helpers ---
// strArgOr / intArgOr are harrier-specific extraction helpers not carried by
// mcpkit (mcpkit exports the base StrArg). Kept as small unexported helpers.

func strArgOr(req mcp.CallToolRequest, key, def string) string {
	if v := mcpkit.StrArg(req, key); v != "" {
		return v
	}
	return def
}

func intArgOr(req mcp.CallToolRequest, key string, def int) int {
	if v, ok := req.GetArguments()[key].(float64); ok {
		return int(v)
	}
	return def
}

func floatArgOr(req mcp.CallToolRequest, key string, def float64) float64 {
	if v, ok := req.GetArguments()[key].(float64); ok {
		return v
	}
	return def
}
