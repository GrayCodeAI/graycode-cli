package hooks

import (
	"context"
	"fmt"
	"strings"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/privacy"
)

// ConversationMessage represents a single message in a conversation for
// auto-capture processing.
type ConversationMessage struct {
	Role    string // "user", "assistant", "system"
	Content string
}

// ConversationCapture extracts memories from conversation messages.
// Unlike PostToolUse (which captures tool observations), ConversationCapture
// analyzes the semantic content of messages to identify decisions, conventions,
// learnings, and action items worth remembering.
type ConversationCapture struct {
	eng     *engine.Engine
	project string
}

// NewConversationCapture creates a conversation capture hook.
func NewConversationCapture(eng *engine.Engine, project string) *ConversationCapture {
	return &ConversationCapture{eng: eng, project: project}
}

// CaptureMessages analyzes a slice of conversation messages and stores
// significant observations as memories. Returns the number of memories created.
func (cc *ConversationCapture) CaptureMessages(ctx context.Context, messages []ConversationMessage, sessionID, agent string) int {
	if len(messages) == 0 {
		return 0
	}

	stored := 0
	for _, msg := range messages {
		if msg.Role == "system" {
			continue // skip system messages
		}
		nodeType, content := cc.extractMemory(msg)
		if content == "" {
			continue
		}

		content = privacy.Filter(content)
		summary := content
		if len(summary) > 100 {
			summary = summary[:100] + "..."
		}

		_, err := cc.eng.Remember(ctx, engine.RememberInput{
			Type:    nodeType,
			Content: content,
			Summary: summary,
			Scope:   "project",
			Project: cc.project,
			Session: sessionID,
			Agent:   agent,
		})
		if err == nil {
			stored++
		}
	}
	return stored
}

// extractMemory identifies whether a message contains a memory-worthy
// observation and classifies it. Returns the node type and cleaned content.
func (cc *ConversationCapture) extractMemory(msg ConversationMessage) (string, string) {
	content := msg.Content
	if len(content) < 30 {
		return "", ""
	}

	lower := strings.ToLower(content)

	// Decision signals
	if containsAny(lower, "decided to", "going with", "chose", "switched to",
		"migrating to", "replaced with", "we will use", "let's use") {
		return "decision", content
	}

	// Convention signals
	if containsAny(lower, "always use", "never use", "convention", "standard",
		"must be", "required to", "rule:", "pattern:") {
		return "convention", content
	}

	// Bug/error signals
	if containsAny(lower, "bug:", "error:", "issue:", "fix:", "broken",
		"crash", "failing", "regression") {
		if msg.Role == "assistant" {
			return "bug", content
		}
	}

	// Spec/requirement signals
	if containsAny(lower, "requirement:", "spec:", "should support",
		"needs to", "must support", "interface:") {
		return "spec", content
	}

	// Task/action item signals
	if containsAny(lower, "todo:", "task:", "need to", "action item",
		"next step", "follow up", "will implement") {
		return "task", content
	}

	// Preference signals (from user messages)
	if msg.Role == "user" && containsAny(lower, "prefer", "i like", "i don't like",
		"please always", "please don't", "instead of") {
		return "preference", content
	}

	// Learning signals (from assistant messages)
	if msg.Role == "assistant" && containsAny(lower, "learned", "insight",
		"key takeaway", "important:", "note:") {
		return "decision", content
	}

	return "", ""
}

// ConversationCaptureSummary reports how many memories were captured.
type ConversationCaptureSummary struct {
	TotalMessages  int
	MemoriesStored int
	ByType         map[string]int
}

// CaptureWithSummary is like CaptureMessages but returns a detailed summary.
func (cc *ConversationCapture) CaptureWithSummary(ctx context.Context, messages []ConversationMessage, sessionID, agent string) ConversationCaptureSummary {
	summary := ConversationCaptureSummary{
		TotalMessages: len(messages),
		ByType:        make(map[string]int),
	}

	for _, msg := range messages {
		if msg.Role == "system" {
			continue
		}
		nodeType, content := cc.extractMemory(msg)
		if content == "" {
			continue
		}

		content = privacy.Filter(content)
		s := content
		if len(s) > 100 {
			s = s[:100] + "..."
		}

		_, err := cc.eng.Remember(ctx, engine.RememberInput{
			Type:    nodeType,
			Content: content,
			Summary: s,
			Scope:   "project",
			Project: cc.project,
			Session: sessionID,
			Agent:   agent,
		})
		if err == nil {
			summary.MemoriesStored++
			summary.ByType[nodeType]++
		}
	}

	return summary
}

// FormatSummary returns a human-readable capture summary.
func (s ConversationCaptureSummary) FormatSummary() string {
	if s.MemoriesStored == 0 {
		return fmt.Sprintf("Analyzed %d messages, no memories captured", s.TotalMessages)
	}
	var parts []string
	parts = append(parts, fmt.Sprintf("Analyzed %d messages, captured %d memories", s.TotalMessages, s.MemoriesStored))
	for typ, count := range s.ByType {
		parts = append(parts, fmt.Sprintf("  %s: %d", typ, count))
	}
	return strings.Join(parts, "\n")
}
