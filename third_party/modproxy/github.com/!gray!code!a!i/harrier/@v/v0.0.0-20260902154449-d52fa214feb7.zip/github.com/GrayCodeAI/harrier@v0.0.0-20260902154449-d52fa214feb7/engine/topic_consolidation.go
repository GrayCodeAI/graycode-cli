package engine

import (
	"context"
	"sort"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/engine/cognitive"
	"github.com/GrayCodeAI/harrier/storage"
)

// TopicCluster represents a consolidated group of related memories.
type TopicCluster struct {
	ID        string    `json:"id"`
	Topic     string    `json:"topic"`
	Summary   string    `json:"summary"`
	MemoryIDs []string  `json:"memory_ids"`
	Keywords  []string  `json:"keywords"`
	Size      int       `json:"size"`
	Coherence float64   `json:"coherence"`
	CreatedAt time.Time `json:"created_at"`
}

// ConsolidationConfig holds configuration for topic consolidation.
type ConsolidationConfig struct {
	Enabled        bool    `json:"enabled"`
	MinClusterSize int     `json:"min_cluster_size"`
	MaxClusters    int     `json:"max_clusters"`
	OverlapThres   float64 `json:"overlap_thres"`
}

// DefaultConsolidationConfig returns production-tuned defaults.
func DefaultConsolidationConfig() ConsolidationConfig {
	return ConsolidationConfig{
		Enabled:        true,
		MinClusterSize: 2,
		MaxClusters:    50,
		OverlapThres:   0.3,
	}
}

// TopicConsolidator groups related memories into topic clusters based on
// keyword and entity overlap. This helps organize the memory graph by
// creating cluster summaries that represent related knowledge.
type TopicConsolidator struct {
	config ConsolidationConfig
	store  storage.Storage
}

// NewTopicConsolidator creates a topic consolidator.
func NewTopicConsolidator(store storage.Storage, config ConsolidationConfig) *TopicConsolidator {
	return &TopicConsolidator{config: config, store: store}
}

// Consolidate finds groups of related memories and returns topic clusters.
// It operates on the given project's memories, computing pairwise keyword
// overlap to identify coherent groups.
func (tc *TopicConsolidator) Consolidate(ctx context.Context, project string) ([]*TopicCluster, error) {
	if !tc.config.Enabled {
		return nil, nil
	}

	nodes, err := tc.store.ListNodes(ctx, storage.NodeFilter{
		Project: project,
		Limit:   500,
	})
	if err != nil {
		return nil, err
	}
	if len(nodes) < tc.config.MinClusterSize {
		return nil, nil
	}

	// Build keyword sets for each node
	nodeKeywords := make([]map[string]bool, len(nodes))
	for i, n := range nodes {
		nodeKeywords[i] = extractClusterKeywords(n.Content + " " + n.Summary)
	}

	// Union-Find for clustering
	uf := newUnionFind(len(nodes))
	for i := 0; i < len(nodes); i++ {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		for j := i + 1; j < len(nodes); j++ {
			overlap := keywordOverlap(nodeKeywords[i], nodeKeywords[j])
			if overlap >= tc.config.OverlapThres {
				uf.union(i, j)
			}
		}
	}

	// Build clusters from union-find groups
	groups := uf.groups()
	var clusters []*TopicCluster
	for _, members := range groups {
		if len(members) < tc.config.MinClusterSize {
			continue
		}

		cluster := &TopicCluster{
			ID:        clusterID(nodes, members),
			MemoryIDs: make([]string, len(members)),
			Size:      len(members),
			CreatedAt: time.Now(),
		}
		mergedKW := make(map[string]bool)
		for i, idx := range members {
			cluster.MemoryIDs[i] = nodes[idx].ID
			for kw := range nodeKeywords[idx] {
				mergedKW[kw] = true
			}
		}
		cluster.Keywords = topKeywords(mergedKW, 5)
		cluster.Topic = strings.Join(cluster.Keywords, ", ")
		cluster.Summary = summarizeCluster(nodes, members)
		cluster.Coherence = clusterCoherence(nodeKeywords, members)

		clusters = append(clusters, cluster)
	}

	// Sort by size descending
	sort.Slice(clusters, func(i, j int) bool {
		return clusters[i].Size > clusters[j].Size
	})

	if len(clusters) > tc.config.MaxClusters {
		clusters = clusters[:tc.config.MaxClusters]
	}

	return clusters, nil
}

// FindRelated returns memory IDs that belong to the same topic cluster
// as the given node, based on keyword overlap.
func (tc *TopicConsolidator) FindRelated(ctx context.Context, node *storage.Node, limit int) ([]string, error) {
	if !tc.config.Enabled {
		return nil, nil
	}
	if limit <= 0 {
		limit = 10
	}

	nodeKW := extractClusterKeywords(node.Content + " " + node.Summary)

	nodes, err := tc.store.ListNodes(ctx, storage.NodeFilter{
		Project: node.Project,
		Limit:   200,
	})
	if err != nil {
		return nil, err
	}

	type scored struct {
		id    string
		score float64
	}
	var results []scored
	for _, n := range nodes {
		if n.ID == node.ID {
			continue
		}
		otherKW := extractClusterKeywords(n.Content + " " + n.Summary)
		overlap := keywordOverlap(nodeKW, otherKW)
		if overlap >= tc.config.OverlapThres {
			results = append(results, scored{id: n.ID, score: overlap})
		}
	}

	sort.Slice(results, func(i, j int) bool {
		return results[i].score > results[j].score
	})

	if len(results) > limit {
		results = results[:limit]
	}

	ids := make([]string, len(results))
	for i, r := range results {
		ids[i] = r.id
	}
	return ids, nil
}

// --- helpers ---

func extractClusterKeywords(text string) map[string]bool {
	kw := make(map[string]bool)
	for _, w := range strings.Fields(strings.ToLower(text)) {
		w = strings.Trim(w, ".,;:!?\"'()[]{}")
		if len(w) > 3 && !cognitive.BoundaryStopWord(w) {
			kw[w] = true
		}
	}
	return kw
}

func keywordOverlap(a, b map[string]bool) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	shared := 0
	for t := range a {
		if b[t] {
			shared++
		}
	}
	minSet := len(a)
	if len(b) < minSet {
		minSet = len(b)
	}
	return float64(shared) / float64(minSet)
}

func topKeywords(kw map[string]bool, limit int) []string {
	var all []string
	for k := range kw {
		all = append(all, k)
	}
	if len(all) > limit {
		all = all[:limit]
	}
	return all
}

func clusterID(nodes []*storage.Node, members []int) string {
	var ids []string
	for _, m := range members {
		ids = append(ids, nodes[m].ID[:8])
	}
	return "cluster-" + strings.Join(ids, "-")
}

func summarizeCluster(nodes []*storage.Node, members []int) string {
	// Use the longest summary from members as the cluster summary
	best := ""
	for _, m := range members {
		s := nodes[m].Summary
		if s == "" {
			s = nodes[m].Content
		}
		if len(s) > len(best) {
			best = s
		}
	}
	if len(best) > 200 {
		best = best[:200] + "..."
	}
	return best
}

func clusterCoherence(nodeKeywords []map[string]bool, members []int) float64 {
	if len(members) < 2 {
		return 1.0
	}
	totalOverlap := 0.0
	pairs := 0
	for i := 0; i < len(members); i++ {
		for j := i + 1; j < len(members); j++ {
			totalOverlap += keywordOverlap(nodeKeywords[members[i]], nodeKeywords[members[j]])
			pairs++
		}
	}
	if pairs == 0 {
		return 0
	}
	return totalOverlap / float64(pairs)
}

// --- simple union-find ---

type unionFind struct {
	parent []int
	rank   []int
}

func newUnionFind(n int) *unionFind {
	p := make([]int, n)
	r := make([]int, n)
	for i := range p {
		p[i] = i
	}
	return &unionFind{parent: p, rank: r}
}

func (uf *unionFind) find(x int) int {
	if uf.parent[x] != x {
		uf.parent[x] = uf.find(uf.parent[x])
	}
	return uf.parent[x]
}

func (uf *unionFind) union(x, y int) {
	rx, ry := uf.find(x), uf.find(y)
	if rx == ry {
		return
	}
	if uf.rank[rx] < uf.rank[ry] {
		rx, ry = ry, rx
	}
	uf.parent[ry] = rx
	if uf.rank[rx] == uf.rank[ry] {
		uf.rank[rx]++
	}
}

func (uf *unionFind) groups() map[int][]int {
	g := make(map[int][]int)
	for i := range uf.parent {
		root := uf.find(i)
		g[root] = append(g[root], i)
	}
	return g
}
