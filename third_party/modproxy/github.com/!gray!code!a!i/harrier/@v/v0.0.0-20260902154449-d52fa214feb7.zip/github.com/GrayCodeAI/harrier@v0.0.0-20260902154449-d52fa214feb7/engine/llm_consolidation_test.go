//nolint:gocritic
package engine

import (
	"context"
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

// --- Mock LLM for testing ---

type mockConsolidationLLM struct {
	mergeFunc func(ctx context.Context, nodes []*storage.Node) (*MergePlan, error)
	summFunc  func(ctx context.Context, nodes []*storage.Node) (string, error)
}

func (m *mockConsolidationLLM) SuggestMerge(ctx context.Context, nodes []*storage.Node) (*MergePlan, error) {
	if m.mergeFunc != nil {
		return m.mergeFunc(ctx, nodes)
	}
	ids := make([]string, len(nodes))
	for i, n := range nodes {
		ids[i] = n.ID
	}
	contents := make([]string, len(nodes))
	for i, n := range nodes {
		contents[i] = n.Content
	}
	return &MergePlan{
		NodeIDs:    ids,
		NewContent: strings.Join(contents, "\n---\n"),
		NewSummary: "merged: " + nodes[0].Summary,
		NewKey:     nodes[0].Key,
		NewType:    nodes[0].Type,
	}, nil
}

func (m *mockConsolidationLLM) Summarize(ctx context.Context, nodes []*storage.Node) (string, error) {
	if m.summFunc != nil {
		return m.summFunc(ctx, nodes)
	}
	return "summary of nodes", nil
}

// --- Tests ---

func TestLevenshtein(t *testing.T) {
	t.Parallel()
	tests := []struct {
		a, b string
		want int
	}{
		{"", "", 0},
		{"abc", "", 3},
		{"", "abc", 3},
		{"kitten", "sitting", 3},
		{"hello", "hello", 0},
		{"saturday", "sunday", 3},
	}
	for _, tt := range tests {
		got := levenshtein(tt.a, tt.b)
		if got != tt.want {
			t.Errorf("levenshtein(%q, %q) = %d, want %d", tt.a, tt.b, got, tt.want)
		}
	}
}

func TestTokenJaccard(t *testing.T) {
	t.Parallel()
	tests := []struct {
		a, b string
		min  float64
		max  float64
	}{
		{"hello world", "hello world", 1.0, 1.0},
		{"hello world", "goodbye moon", 0.0, 0.0},
		{"hello world", "hello moon", 0.3, 0.6},
		{"", "", 1.0, 1.0},
	}
	for _, tt := range tests {
		got := tokenJaccard(tt.a, tt.b)
		if got < tt.min || got > tt.max {
			t.Errorf("tokenJaccard(%q, %q) = %f, want [%f, %f]", tt.a, tt.b, got, tt.min, tt.max)
		}
	}
}

func TestExtractKeywords(t *testing.T) {
	t.Parallel()
	kw := extractKeywords("The database connection pool configuration settings")
	if kw["database"] != true {
		t.Error("expected 'database' in keywords")
	}
	if kw["the"] {
		t.Error("stop word 'the' should be filtered")
	}
	if kw["connection"] != true {
		t.Error("expected 'connection' in keywords")
	}
}

func TestFindCandidateClusters_EmptyProject(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	llm := &mockConsolidationLLM{}
	cfg := DefaultLLMConsolidationConfig()
	lc := NewLLMConsolidator(store, llm, cfg)

	clusters, err := lc.FindCandidateClusters(context.Background(), "test-project")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if clusters != nil {
		t.Errorf("expected nil clusters for empty project, got %d", len(clusters))
	}
}

func TestFindCandidateClusters_Disabled(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	llm := &mockConsolidationLLM{}
	cfg := DefaultLLMConsolidationConfig()
	cfg.Enabled = false
	lc := NewLLMConsolidator(store, llm, cfg)

	clusters, err := lc.FindCandidateClusters(context.Background(), "test-project")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if clusters != nil {
		t.Errorf("expected nil when disabled, got %d", len(clusters))
	}
}

func TestFindCandidateClusters_SimilarNodes(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	store.nodes["n1"] = &storage.Node{
		ID:      "n1",
		Type:    "convention",
		Key:     "go-error-handling",
		Content: "Always wrap errors with fmt.Errorf for context in Go projects",
		Summary: "Go error handling convention",
		Project: "myproj",
	}
	store.nodes["n2"] = &storage.Node{
		ID:      "n2",
		Type:    "convention",
		Key:     "go-error-handling-style",
		Content: "Error handling in Go should use fmt.Errorf to wrap errors with context",
		Summary: "Go error handling style",
		Project: "myproj",
	}
	store.nodes["n3"] = &storage.Node{
		ID:      "n3",
		Type:    "convention",
		Key:     "python-logging",
		Content: "Use structured logging with Python's logging module",
		Summary: "Python logging convention",
		Project: "myproj",
	}

	llm := &mockConsolidationLLM{}
	cfg := DefaultLLMConsolidationConfig()
	cfg.KeySimilarityThreshold = 0.3
	cfg.ContentKeywordThreshold = 0.2
	lc := NewLLMConsolidator(store, llm, cfg)

	clusters, err := lc.FindCandidateClusters(context.Background(), "myproj")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	foundMerge := false
	for _, c := range clusters {
		if len(c.Nodes) >= 2 {
			foundMerge = true
		}
	}
	if !foundMerge {
		t.Error("expected at least one cluster with 2+ nodes")
	}
}

func TestConsolidate_DryRun(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	store.nodes["n1"] = &storage.Node{
		ID:      "n1",
		Type:    "decision",
		Key:     "use-postgres",
		Content: "We decided to use PostgreSQL as our primary database",
		Summary: "PostgreSQL chosen as primary DB",
		Project: "proj",
	}
	store.nodes["n2"] = &storage.Node{
		ID:      "n2",
		Type:    "decision",
		Key:     "use-postgresql",
		Content: "Decision: PostgreSQL will be the primary database system",
		Summary: "PostgreSQL as main database",
		Project: "proj",
	}

	llm := &mockConsolidationLLM{}
	cfg := DefaultLLMConsolidationConfig()
	cfg.DryRun = true
	cfg.KeySimilarityThreshold = 0.3
	cfg.ContentKeywordThreshold = 0.1
	lc := NewLLMConsolidator(store, llm, cfg)

	result, err := lc.Consolidate(context.Background(), "proj")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !result.DryRun {
		t.Error("expected DryRun=true in result")
	}
	// Nodes should still exist in storage (not deleted).
	if len(store.nodes) != 2 {
		t.Errorf("expected 2 nodes preserved in dry run, got %d", len(store.nodes))
	}
}

func TestConsolidate_AppliesPlan(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	store.nodes["n1"] = &storage.Node{
		ID:      "n1",
		Type:    "decision",
		Key:     "use-postgres",
		Content: "We decided to use PostgreSQL as our primary database",
		Summary: "PostgreSQL chosen as primary DB",
		Project: "proj",
	}
	store.nodes["n2"] = &storage.Node{
		ID:      "n2",
		Type:    "decision",
		Key:     "use-postgresql",
		Content: "Decision: PostgreSQL will be the primary database system",
		Summary: "PostgreSQL as main database",
		Project: "proj",
	}

	llm := &mockConsolidationLLM{}
	cfg := DefaultLLMConsolidationConfig()
	cfg.DryRun = false
	cfg.KeySimilarityThreshold = 0.3
	cfg.ContentKeywordThreshold = 0.1
	lc := NewLLMConsolidator(store, llm, cfg)

	result, err := lc.Consolidate(context.Background(), "proj")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.Applied == 0 {
		t.Error("expected at least 1 applied merge")
	}
}

func TestConsolidate_SkipsOnLLMError(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	store.nodes["n1"] = &storage.Node{
		ID:      "n1",
		Type:    "spec",
		Key:     "api-spec",
		Content: "REST API specification with authentication endpoints",
		Summary: "API spec",
		Project: "proj",
	}
	store.nodes["n2"] = &storage.Node{
		ID:      "n2",
		Type:    "spec",
		Key:     "api-auth-spec",
		Content: "REST API authentication specification with endpoints",
		Summary: "Auth API spec",
		Project: "proj",
	}

	llm := &mockConsolidationLLM{
		mergeFunc: func(_ context.Context, _ []*storage.Node) (*MergePlan, error) {
			return nil, context.DeadlineExceeded
		},
	}
	cfg := DefaultLLMConsolidationConfig()
	cfg.KeySimilarityThreshold = 0.3
	cfg.ContentKeywordThreshold = 0.1
	lc := NewLLMConsolidator(store, llm, cfg)

	result, err := lc.Consolidate(context.Background(), "proj")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.Skipped == 0 {
		t.Error("expected skipped > 0 when LLM errors")
	}
}

func TestConsolidate_SkipsNilPlan(t *testing.T) {
	t.Parallel()
	store := newMockStorage()
	store.nodes["n1"] = &storage.Node{
		ID:      "n1",
		Type:    "bug",
		Key:     "login-bug",
		Content: "Login fails when email contains plus sign",
		Summary: "Login bug with plus in email",
		Project: "proj",
	}
	store.nodes["n2"] = &storage.Node{
		ID:      "n2",
		Type:    "bug",
		Key:     "login-email-bug",
		Content: "Login fails with plus sign in email address",
		Summary: "Login email character bug",
		Project: "proj",
	}

	llm := &mockConsolidationLLM{
		mergeFunc: func(_ context.Context, _ []*storage.Node) (*MergePlan, error) {
			return nil, nil
		},
	}
	cfg := DefaultLLMConsolidationConfig()
	cfg.KeySimilarityThreshold = 0.3
	cfg.ContentKeywordThreshold = 0.1
	lc := NewLLMConsolidator(store, llm, cfg)

	result, err := lc.Consolidate(context.Background(), "proj")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if result.Skipped == 0 {
		t.Error("expected skipped > 0 when LLM returns nil plan")
	}
}

func TestTokenJaccard_TokenOverlap(t *testing.T) {
	t.Parallel()
	got := tokenJaccard("go error handling", "go error style")
	if got < 0.49 || got > 0.51 {
		t.Errorf("tokenJaccard = %f, want ~0.5", got)
	}
}

func TestDefaultLLMConsolidationConfig(t *testing.T) {
	t.Parallel()
	cfg := DefaultLLMConsolidationConfig()
	if !cfg.Enabled {
		t.Error("expected Enabled=true")
	}
	if cfg.MinClusterSize != 2 {
		t.Errorf("expected MinClusterSize=2, got %d", cfg.MinClusterSize)
	}
	if cfg.MaxBatchSize != 20 {
		t.Errorf("expected MaxBatchSize=20, got %d", cfg.MaxBatchSize)
	}
	if cfg.DryRun {
		t.Error("expected DryRun=false")
	}
}
