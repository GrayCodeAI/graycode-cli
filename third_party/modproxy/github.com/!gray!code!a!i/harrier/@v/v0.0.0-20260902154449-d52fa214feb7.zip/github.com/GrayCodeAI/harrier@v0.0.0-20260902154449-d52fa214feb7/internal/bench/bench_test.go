package bench

import (
	"context"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func TestResultStringEmpty(t *testing.T) {
	r := &Result{
		Total:     10,
		HitAtK:    map[int]int{1: 2, 3: 4, 5: 6, 10: 8},
		MRR:       0.456,
		AvgTokens: 150.5,
		Duration:  2 * time.Second,
	}

	s := r.String()
	if s == "" {
		t.Fatal("String() returned empty")
	}

	// Check that key metrics appear in output
	checks := []string{
		"Benchmark Results (10 questions)",
		"R@1:",
		"R@3:",
		"R@5:",
		"R@10:",
		"MRR:",
		"Avg tokens/query:",
		"Duration:",
	}
	for _, want := range checks {
		if !strings.Contains(s, want) {
			t.Errorf("String() missing %q\nGot: %s", want, s)
		}
	}
}

func TestResultStringPercentages(t *testing.T) {
	r := &Result{
		Total:     4,
		HitAtK:    map[int]int{1: 1, 3: 2, 5: 3, 10: 4},
		MRR:       0.75,
		AvgTokens: 100,
		Duration:  time.Second,
	}

	s := r.String()
	// R@1: 25.0%, R@3: 50.0%, R@5: 75.0%, R@10: 100.0%
	if !strings.Contains(s, "25.0%") {
		t.Errorf("expected 25.0%% in output, got: %s", s)
	}
	if !strings.Contains(s, "100.0%") {
		t.Errorf("expected 100.0%% in output, got: %s", s)
	}
}

func TestFindRankByNodeID(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "aaa", Content: "first"},
		{ID: "bbb", Content: "second"},
		{ID: "ccc", Content: "third"},
	}

	qa := QA{ExpectedNodeID: "bbb"}
	rank := findRank(nodes, qa)
	if rank != 2 {
		t.Errorf("findRank by ID = %d, want 2", rank)
	}
}

func TestFindRankByContent(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "aaa", Content: "Use TypeScript strict mode"},
		{ID: "bbb", Content: "Always use jose for JWT"},
		{ID: "ccc", Content: "Run tests with pnpm"},
	}

	qa := QA{ExpectedContent: "jose"}
	rank := findRank(nodes, qa)
	if rank != 2 {
		t.Errorf("findRank by content = %d, want 2", rank)
	}
}

func TestFindRankCaseInsensitive(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "aaa", Content: "Use NATS for event bus"},
	}

	qa := QA{ExpectedContent: "nats"}
	rank := findRank(nodes, qa)
	if rank != 1 {
		t.Errorf("findRank case-insensitive = %d, want 1", rank)
	}
}

func TestFindRankNotFound(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "aaa", Content: "something"},
	}

	qa := QA{ExpectedContent: "nonexistent"}
	rank := findRank(nodes, qa)
	if rank != 0 {
		t.Errorf("findRank not found = %d, want 0", rank)
	}
}

func TestFindRankEmptyNodes(t *testing.T) {
	qa := QA{ExpectedContent: "test"}
	rank := findRank(nil, qa)
	if rank != 0 {
		t.Errorf("findRank empty = %d, want 0", rank)
	}
}

func TestDefaultQAsNotEmpty(t *testing.T) {
	qas := DefaultQAs()
	if len(qas) == 0 {
		t.Fatal("DefaultQAs() returned empty")
	}
}

func TestDefaultQAsHaveFields(t *testing.T) {
	for i, qa := range DefaultQAs() {
		if qa.Question == "" {
			t.Errorf("DefaultQAs[%d].Question is empty", i)
		}
		if qa.ExpectedContent == "" && qa.ExpectedNodeID == "" {
			t.Errorf("DefaultQAs[%d] has neither ExpectedContent nor ExpectedNodeID", i)
		}
	}
}

func TestCodingBenchQAsLargerThanDefault(t *testing.T) {
	def := DefaultQAs()
	coding := CodingBenchQAs()
	if len(coding) <= len(def) {
		t.Errorf("CodingBenchQAs (%d) should be larger than DefaultQAs (%d)", len(coding), len(def))
	}
}

func TestCodingBenchQAsContainsDefaults(t *testing.T) {
	coding := CodingBenchQAs()
	// First len(DefaultQAs()) entries should match
	def := DefaultQAs()
	for i, qa := range def {
		if coding[i].Question != qa.Question {
			t.Errorf("CodingBenchQAs[%d].Question = %q, want %q", i, coding[i].Question, qa.Question)
		}
	}
}

func TestRunEmptyQAs(t *testing.T) {
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close() //nolint:errcheck // test cleanup //nolint:errcheck // test cleanup
	eng := engine.New(store, graph.New(store, store.DB()))

	result := Run(context.Background(), eng, nil, 2, 10)
	if result.Total != 0 {
		t.Errorf("Total = %d, want 0", result.Total)
	}
	if result.MRR != 0 {
		t.Errorf("MRR = %f, want 0", result.MRR)
	}
}

func TestRunWithSeedData(t *testing.T) {
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close() //nolint:errcheck // test cleanup
	eng := engine.New(store, graph.New(store, store.DB()))
	ctx := context.Background()

	// Seed some memories
	_, err = eng.Remember(ctx, engine.RememberInput{
		Type: "convention", Content: "Always use jose for JWT handling", Scope: "project",
	})
	if err != nil {
		t.Fatalf("remember: %v", err)
	}
	_, err = eng.Remember(ctx, engine.RememberInput{
		Type: "decision", Content: "We use NATS for event bus", Scope: "project",
	})
	if err != nil {
		t.Fatalf("remember: %v", err)
	}

	qas := []QA{
		{Question: "which JWT library", ExpectedContent: "jose"},
		{Question: "event bus choice", ExpectedContent: "NATS"},
	}

	result := Run(ctx, eng, qas, 2, 10)
	if result.Total != 2 {
		t.Errorf("Total = %d, want 2", result.Total)
	}
	if result.Duration <= 0 {
		t.Error("Duration should be positive")
	}
}
