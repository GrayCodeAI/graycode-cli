package cognitive

import (
	"regexp"
	"strings"
	"sync"
	"time"
)

var openLoopPatterns = []*regexp.Regexp{
	regexp.MustCompile(`(?i)\b(?:todo|to-do|need to|have to|should|must)\b.*(?:later|tomorrow|next|soon|eventually)`),
	regexp.MustCompile(`(?i)\b(?:working on|started|in progress|wip)\b`),
	regexp.MustCompile(`(?i)\b(?:not sure|don't know|unclear|confused about|need to figure out)\b`),
	regexp.MustCompile(`(?i)\b(?:bug|error|issue|broken|failing|crashed)\b.*(?:still|remains|unresolved|unfixed)`),
	regexp.MustCompile(`(?i)\b(?:will do|gonna|going to|plan to)\b`),
	regexp.MustCompile(`(?i)\b(?:remind me|don't forget|remember to)\b`),
	regexp.MustCompile(`\?\s*$`),
}

var resolutionPatterns = []*regexp.Regexp{
	regexp.MustCompile(`(?i)\b(?:done|completed|finished|resolved|fixed|solved|shipped)\b`),
	regexp.MustCompile(`(?i)\b(?:no longer|not anymore|already|taken care of)\b`),
	regexp.MustCompile(`(?i)\b(?:works now|passes now|all good|all set)\b`),
}

type OpenLoop struct {
	ChunkID    string    `json:"chunk_id"`
	Context    string    `json:"context"`
	DetectedAt time.Time `json:"detected_at"`
	Resolved   bool      `json:"resolved"`
}

type ZeigarnikConfig struct {
	Enabled         bool    `json:"enabled"`
	DecayResistance float64 `json:"decay_resistance"`
	MinTextLength   int     `json:"min_text_length"`
}

func DefaultZeigarnikConfig() ZeigarnikConfig {
	return ZeigarnikConfig{
		Enabled:         true,
		DecayResistance: 1.5,
		MinTextLength:   20,
	}
}

type ZeigarnikEngine struct {
	mu     sync.RWMutex
	loops  map[string]*OpenLoop
	config ZeigarnikConfig
}

func NewZeigarnikEngine(config ZeigarnikConfig) *ZeigarnikEngine {
	return &ZeigarnikEngine{
		loops:  make(map[string]*OpenLoop),
		config: config,
	}
}

func DetectOpenLoop(text string, minLen int) string {
	if len(text) < minLen {
		return ""
	}
	for _, p := range openLoopPatterns {
		loc := p.FindStringIndex(text)
		if loc != nil {
			start := loc[0] - 30
			if start < 0 {
				start = 0
			}
			end := loc[1] + 70
			if end > len(text) {
				end = len(text)
			}
			return strings.TrimSpace(text[start:end])
		}
	}
	return ""
}

func DetectResolution(text string) bool {
	for _, p := range resolutionPatterns {
		if p.MatchString(text) {
			return true
		}
	}
	return false
}

func (e *ZeigarnikEngine) MarkOpenLoop(chunkID, context string) {
	if !e.config.Enabled {
		return
	}
	e.mu.Lock()
	defer e.mu.Unlock()

	e.loops[chunkID] = &OpenLoop{
		ChunkID:    chunkID,
		Context:    context,
		DetectedAt: time.Now(),
	}
}

func (e *ZeigarnikEngine) CloseLoop(chunkID string) {
	e.mu.Lock()
	defer e.mu.Unlock()

	if loop, ok := e.loops[chunkID]; ok {
		loop.Resolved = true
	}
}

func (e *ZeigarnikEngine) GetActiveLoops(limit int) []*OpenLoop {
	e.mu.RLock()
	defer e.mu.RUnlock()

	var active []*OpenLoop
	for _, loop := range e.loops {
		if !loop.Resolved {
			active = append(active, loop)
			if len(active) >= limit {
				break
			}
		}
	}
	return active
}

func (e *ZeigarnikEngine) DecayMultiplier(chunkID string) float64 {
	e.mu.RLock()
	defer e.mu.RUnlock()

	if loop, ok := e.loops[chunkID]; ok && !loop.Resolved {
		return e.config.DecayResistance
	}
	return 1.0
}

type ZeigarnikChunk struct {
	ID   string
	Text string
}

func (e *ZeigarnikEngine) ScanChunks(chunks []ZeigarnikChunk) int {
	marked := 0
	for _, chunk := range chunks {
		context := DetectOpenLoop(chunk.Text, e.config.MinTextLength)
		if context != "" {
			e.MarkOpenLoop(chunk.ID, context)
			marked++
		}
	}
	return marked
}
