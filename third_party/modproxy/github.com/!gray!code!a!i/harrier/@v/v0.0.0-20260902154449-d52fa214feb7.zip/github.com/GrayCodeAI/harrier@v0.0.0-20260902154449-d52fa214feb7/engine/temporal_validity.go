package engine

import "time"

type TemporalEdge struct {
	SourceID     string     `json:"source_id"`
	TargetID     string     `json:"target_id"`
	RelationType string     `json:"relation_type"`
	ValidFrom    *time.Time `json:"valid_from,omitempty"`
	ValidUntil   *time.Time `json:"valid_until,omitempty"`
	Confidence   float64    `json:"confidence"`
	Evidence     string     `json:"evidence,omitempty"`
}

func (e *TemporalEdge) IsActiveAt(t time.Time) bool {
	if e.ValidFrom != nil && t.Before(*e.ValidFrom) {
		return false
	}
	if e.ValidUntil != nil && t.After(*e.ValidUntil) {
		return false
	}
	return true
}

func (e *TemporalEdge) IsCurrentlyActive() bool {
	return e.IsActiveAt(time.Now())
}

func FilterActiveEdges(edges []*TemporalEdge, at time.Time) []*TemporalEdge {
	var active []*TemporalEdge
	for _, edge := range edges {
		if edge.IsActiveAt(at) {
			active = append(active, edge)
		}
	}
	return active
}

func FilterCurrentEdges(edges []*TemporalEdge) []*TemporalEdge {
	return FilterActiveEdges(edges, time.Now())
}

func SupersedeEdge(edge *TemporalEdge) {
	now := time.Now()
	edge.ValidUntil = &now
}
