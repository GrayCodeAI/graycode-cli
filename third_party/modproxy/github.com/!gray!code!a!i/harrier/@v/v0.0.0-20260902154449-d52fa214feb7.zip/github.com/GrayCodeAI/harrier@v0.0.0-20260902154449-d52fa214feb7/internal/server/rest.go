// Package server exposes harrier over the network: the REST API, the MCP server,
// and the browser dashboard, all backed by the same engine.
package server

import (
	"context"
	"crypto/subtle"
	stdtls "crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/metric"
)

// Note: the REST request handlers were moved verbatim into
// rest_handlers.go (core memory/graph/session/ops handlers) and
// rest_extra.go (export/import, skill, version-history, and advanced
// feature handlers) for readability. This file keeps the server
// lifecycle, middleware, route registration, and shared HTTP helpers.

const (
	maxRequestBodySize = 1 << 20       // 1 MB
	maxResponseSize    = 5 * (1 << 20) // 5 MB
	maxGraphDepth      = 5
)

// RESTServer serves the HTTP API.
type RESTServer struct {
	eng         *engine.Engine
	addr        string
	projectDir  string
	tlsCfg      *stdtls.Config
	embedder    embeddings.Provider // nil = no vector search
	srv         *http.Server
	limiter     *engine.RateLimiter // rate limiter for destructive operations
	broadcaster *SSEBroadcaster     // nil = streaming disabled
	apiKey      string              // if set, require Bearer / X-API-Key on all requests
}

// NewRESTServer creates a REST server.
func NewRESTServer(eng *engine.Engine, addr string) *RESTServer {
	return &RESTServer{
		eng:     eng,
		addr:    addr,
		limiter: engine.NewRateLimiter(10, 20), // 10 req/sec, burst 20
	}
}

// WithProjectDir sets the project directory for git-based staleness detection.
func (s *RESTServer) WithProjectDir(dir string) *RESTServer {
	s.projectDir = dir
	return s
}

// WithEmbedder sets the embedding provider for vector search.
func (s *RESTServer) WithEmbedder(p embeddings.Provider) *RESTServer {
	s.embedder = p
	return s
}

// WithTLS sets TLS config on the server.
func (s *RESTServer) WithTLS(cfg *stdtls.Config) *RESTServer {
	s.tlsCfg = cfg
	return s
}

// WithAPIKey sets the API key required for authenticated requests (Bearer / X-API-Key).
func (s *RESTServer) WithAPIKey(key string) *RESTServer {
	s.apiKey = key
	return s
}

// ListenAndServe starts the HTTP server with middleware.
func (s *RESTServer) ListenAndServe() error {
	mux := http.NewServeMux()
	s.RegisterRoutes(mux)
	handler := http.TimeoutHandler(s.withMiddleware(mux), 30*time.Second, `{"error":"request timeout"}`)
	s.srv = &http.Server{
		Addr:         s.addr,
		Handler:      handler,
		TLSConfig:    s.tlsCfg,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 35 * time.Second,
		IdleTimeout:  120 * time.Second,
	}
	if s.tlsCfg != nil {
		fmt.Printf("harrier REST API (HTTPS) listening on %s\n", s.addr)
		ln, err := stdtls.Listen("tcp", s.addr, s.tlsCfg)
		if err != nil {
			return err
		}
		return s.srv.Serve(ln)
	}
	fmt.Printf("harrier REST API listening on %s\n", s.addr)
	return s.srv.ListenAndServe()
}

// Shutdown gracefully shuts down the REST server with a timeout.
func (s *RESTServer) Shutdown(ctx context.Context) error {
	if s.srv == nil {
		return nil
	}
	return s.srv.Shutdown(ctx)
}

// statusRecorder wraps http.ResponseWriter to capture the status code.
type statusRecorder struct {
	http.ResponseWriter
	status int
	wrote  bool
}

func (sr *statusRecorder) WriteHeader(code int) {
	if !sr.wrote {
		sr.status = code
		sr.wrote = true
	}
	sr.ResponseWriter.WriteHeader(code)
}

func (sr *statusRecorder) Write(b []byte) (int, error) {
	if !sr.wrote {
		sr.status = http.StatusOK
		sr.wrote = true
	}
	return sr.ResponseWriter.Write(b)
}

// withMiddleware wraps the handler with auth, panic recovery, security headers, request logging, and OTel metrics.
func (s *RESTServer) withMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		// CORS headers for localhost development. Only emit them for actual
		// cross-origin requests (those that carry an Origin header) and only when
		// that origin is local — a request with no Origin is not a CORS request,
		// so reflecting "*" for it was unnecessarily broad.
		origin := r.Header.Get("Origin")
		if origin != "" && isLocalOrigin(origin) {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Vary", "Origin")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization, X-API-Key")
			w.Header().Set("Access-Control-Max-Age", "86400")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		// Security headers
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Cache-Control", "no-store")
		// Limit request body size
		r.Body = http.MaxBytesReader(w, r.Body, maxRequestBodySize)
		// API key authentication (skip health/version so orchestrators can probe without a key)
		if s.apiKey != "" && r.URL.Path != "/harrier/health" && r.URL.Path != "/harrier/version" && r.URL.Path != "/healthz" && r.URL.Path != "/readyz" {
			token := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
			if token == "" {
				token = r.Header.Get("X-API-Key")
			}
			if !constantTimeEqual(token, s.apiKey) {
				httpErr(w, fmt.Errorf("unauthorized"), http.StatusUnauthorized)
				return
			}
		}
		// Wrap ResponseWriter to capture status code for metrics
		sr := &statusRecorder{ResponseWriter: w, status: http.StatusOK}
		// Panic recovery
		defer func() {
			if rec := recover(); rec != nil {
				slog.Error("http panic recovered", "path", r.URL.Path, "panic", rec)
				httpErr(w, fmt.Errorf("internal server error"), 500)
				sr.status = 500
			}
			// Record OTel metrics
			duration := time.Since(start).Seconds()
			statusStr := strconv.Itoa(sr.status)
			attrs := attribute.NewSet(
				attribute.String("method", r.Method),
				attribute.String("path", r.URL.Path),
				attribute.String("status", statusStr),
			)
			telemetry.HTTPRequestDuration.Record(r.Context(), duration, metric.WithAttributeSet(attrs))
			telemetry.HTTPRequestCount.Add(r.Context(), 1, metric.WithAttributeSet(attrs))
		}()
		next.ServeHTTP(sr, r)
		slog.Debug("http request", "method", r.Method, "path", r.URL.Path, "duration", time.Since(start).String())
	})
}

// isLocalOrigin reports whether origin is a localhost address suitable for CORS.
//
// It parses the Origin URL and matches the host EXACTLY, rather than by string
// prefix. Prefix matching ("http://localhost"+) is bypassable with hostnames
// like "localhost.evil.com" or "127.0.0.1.evil.com" — an attacker registers
// such a domain and the prefix check passes. Exact host comparison after
// url.Parse closes that hole; the scheme must also be http/https.
func isLocalOrigin(origin string) bool {
	u, err := url.Parse(origin)
	if err != nil {
		return false
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return false
	}
	switch u.Hostname() { // Hostname() strips any :port and [] from IPv6
	case "localhost", "127.0.0.1", "::1":
		return true
	default:
		return false
	}
}

// constantTimeEqual compares two strings in constant time, padding the shorter
// value so comparison time does not leak token length.
func constantTimeEqual(a, b string) bool {
	if len(a) < len(b) {
		a += strings.Repeat("\x00", len(b)-len(a))
	} else if len(b) < len(a) {
		b += strings.Repeat("\x00", len(a)-len(b))
	}
	return subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}

// RegisterRoutes registers all routes on the given mux (useful for testing).
func (s *RESTServer) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("POST /harrier/remember", s.handleRemember)
	mux.HandleFunc("POST /harrier/recall", s.handleRecall)
	mux.HandleFunc("GET /harrier/context", s.handleContext)
	mux.HandleFunc("POST /harrier/link", s.handleLink)
	mux.HandleFunc("DELETE /harrier/link/{id}", s.handleDeleteLink)
	mux.HandleFunc("GET /harrier/node/{id}", s.handleGetNode)
	mux.HandleFunc("PATCH /harrier/node/{id}", s.handleUpdateNode)
	mux.HandleFunc("POST /harrier/pin/{id}", s.handlePinNode)
	mux.HandleFunc("GET /harrier/subgraph/{id}", s.handleSubgraph)
	mux.HandleFunc("GET /harrier/impact/{file...}", s.handleImpact)
	mux.HandleFunc("DELETE /harrier/forget/{id}", s.handleForget)
	mux.HandleFunc("GET /healthz", s.handleLiveness)
	mux.HandleFunc("GET /readyz", s.handleReadiness)
	mux.HandleFunc("GET /harrier/health", s.handleHealth)
	mux.HandleFunc("GET /harrier/version", s.handleVersion)
	mux.HandleFunc("GET /harrier/graph/stats", s.handleStats)
	mux.HandleFunc("GET /harrier/sessions", s.handleSessions)
	mux.HandleFunc("POST /harrier/session/start", s.handleSessionStart)
	mux.HandleFunc("POST /harrier/session/end", s.handleSessionEnd)
	mux.HandleFunc("GET /harrier/stale", s.handleStale)
	mux.HandleFunc("POST /harrier/embed", s.handleEmbed)
	mux.HandleFunc("POST /harrier/hybrid-recall", s.handleHybridRecall)
	mux.HandleFunc("GET /harrier/proactive", s.handleProactive)
	mux.HandleFunc("POST /harrier/feedback", s.handleFeedback)
	mux.HandleFunc("POST /harrier/decay", s.handleDecay)
	mux.HandleFunc("POST /harrier/gc", s.handleGC)
	mux.HandleFunc("GET /harrier/replay/{session_id}", s.handleReplay)
	ServeDashboard(mux)
	mux.HandleFunc("POST /harrier/export/json", s.handleExportJSON)
	mux.HandleFunc("POST /harrier/export/markdown", s.handleExportMarkdown)
	mux.HandleFunc("POST /harrier/export/obsidian", s.handleExportObsidian)
	mux.HandleFunc("POST /harrier/import/json", s.handleImportJSON)
	mux.HandleFunc("POST /harrier/skill/store", s.handleSkillStore)
	mux.HandleFunc("GET /harrier/skill/list", s.handleSkillList)
	mux.HandleFunc("GET /harrier/skill/{name}", s.handleSkillGet)
	mux.HandleFunc("POST /harrier/bench", s.handleBench)
	mux.HandleFunc("POST /harrier/compact", s.handleCompact)
	mux.HandleFunc("GET /harrier/mental-model", s.handleMentalModel)
	mux.HandleFunc("GET /harrier/profile", s.handleProfile)

	// Advanced features
	mux.HandleFunc("GET /harrier/communities", s.handleCommunities)
	mux.HandleFunc("POST /harrier/hierarchy", s.handleHierarchy)
	mux.HandleFunc("POST /harrier/sparsify", s.handleSparsify)
	mux.HandleFunc("GET /harrier/verify", s.handleVerify)
	mux.HandleFunc("GET /harrier/entities", s.handleEntities)
	mux.HandleFunc("GET /harrier/doctor", s.handleDoctor)

	// Version history and rollback
	mux.HandleFunc("GET /harrier/node/{id}/versions", s.handleVersions)
	mux.HandleFunc("POST /harrier/node/{id}/rollback", s.handleRollback)
	mux.HandleFunc("GET /harrier/node/{id}/diff", s.handleDiff)

	// Confidence-scored recall
	mux.HandleFunc("POST /harrier/recall-confidence", s.handleRecallConfidence)

	// Session compression
	mux.HandleFunc("POST /harrier/session/compress", s.handleSessionCompress)

	// Agent file bridge
	mux.HandleFunc("POST /harrier/bridge/import", s.handleBridgeImport)
	mux.HandleFunc("POST /harrier/bridge/export", s.handleBridgeExport)
	mux.HandleFunc("POST /harrier/bridge/sync", s.handleBridgeSync)

	// Search, retrieval, and API features
	mux.HandleFunc("POST /harrier/staleness/mark", s.handleMarkStale)
	mux.HandleFunc("POST /harrier/impact/analyze", s.handleAnalyzeImpact)
	mux.HandleFunc("GET /harrier/tiers", s.handleTierLoad)
	mux.HandleFunc("GET /harrier/privacy", s.handlePrivacyGet)
	mux.HandleFunc("POST /harrier/privacy", s.handlePrivacySet)
	mux.HandleFunc("GET /harrier/decay/status", s.handleDecayStatus)
	mux.HandleFunc("POST /harrier/query", s.handleQuery)
	mux.HandleFunc("GET /harrier/stream/memories", s.handleWatchMemories)
	mux.HandleFunc("GET /harrier/stream/stale", s.handleWatchStale)
	// /harrier/watch and /api/v1/events/stream are SSE endpoints for memory events
	mux.HandleFunc("GET /harrier/watch", s.handleWatchMemories)
	mux.HandleFunc("GET /api/v1/events/stream", s.handleWatchMemories)
}

// --- helpers ---

func httpJSON(w http.ResponseWriter, v any, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// httpJSONCapped encodes the response as JSON but returns a 413 error if the
// serialized payload exceeds maxResponseSize.
func httpJSONCapped(w http.ResponseWriter, v any, code int) {
	data, err := json.Marshal(v)
	if err != nil {
		httpErr(w, fmt.Errorf("marshal response: %w", err), 500)
		return
	}
	if len(data) > maxResponseSize {
		httpErr(w, fmt.Errorf("response size %d bytes exceeds limit of %d bytes", len(data), maxResponseSize), 413)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_, _ = w.Write(data)
}

func httpErr(w http.ResponseWriter, err error, code int) {
	// Sanitize error messages: never leak internal details for 500-level errors.
	msg := err.Error()
	if code >= 500 {
		msg = "internal server error"
		slog.Error("http_error", "code", code, "err", err.Error())
	}
	httpJSON(w, map[string]string{"error": msg}, code)
}

// decodeJSON unmarshals JSON from the request body, returning 413 if the body
// exceeds MaxBytesReader limits.
func decodeJSON(r *http.Request, v any) error {
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			return fmt.Errorf("request body exceeds %d bytes: %w", maxBytesErr.Limit, err)
		}
		return err
	}
	return nil
}

func intQuery(r *http.Request, key string, def int) int {
	v := r.URL.Query().Get(key)
	if v == "" {
		return def
	}
	var n int
	_, _ = fmt.Sscanf(v, "%d", &n)
	if n <= 0 {
		return def
	}
	return n
}
