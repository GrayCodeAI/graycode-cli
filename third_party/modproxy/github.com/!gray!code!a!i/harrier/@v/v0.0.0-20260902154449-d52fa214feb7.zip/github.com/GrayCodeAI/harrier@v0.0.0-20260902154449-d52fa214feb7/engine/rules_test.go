package engine

import (
	"context"
	"strings"
	"testing"
)

func TestRememberRule_StoresConventionNode(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.RememberRule(context.Background(), RuleInput{
		Path:        ".hawk/rules/naming.md",
		Content:     "Use camelCase for variables",
		Description: "Go naming conventions",
		Globs:       []string{"**/*.go"},
		AlwaysApply: false,
		Project:     "test",
	})
	if err != nil {
		t.Fatalf("RememberRule: %v", err)
	}
	if node.Type != "convention" {
		t.Errorf("expected type 'convention', got %q", node.Type)
	}
	if node.Key != "rule:.hawk/rules/naming.md" {
		t.Errorf("expected key 'rule:.hawk/rules/naming.md', got %q", node.Key)
	}
	if node.Tier != 1 {
		t.Errorf("expected tier 1, got %d", node.Tier)
	}
}

func TestRememberRule_WithGlobs(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.RememberRule(context.Background(), RuleInput{
		Path:    ".hawk/rules/testing.md",
		Content: "Write table-driven tests",
		Globs:   []string{"**/*_test.go", "**/test_*.go"},
		Project: "test",
	})
	if err != nil {
		t.Fatalf("RememberRule: %v", err)
	}

	// Check tags contain globs (Tags is comma-separated string)
	foundGlob := 0
	for _, tag := range strings.Split(node.Tags, ",") {
		if strings.HasPrefix(tag, "glob:") {
			foundGlob++
		}
	}
	if foundGlob != 2 {
		t.Errorf("expected 2 glob tags, got %d (tags: %s)", foundGlob, node.Tags)
	}
}

func TestRememberRule_Upsert(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	// First insert
	node1, err := eng.RememberRule(context.Background(), RuleInput{
		Path:    ".hawk/rules/style.md",
		Content: "Version 1",
		Project: "test",
	})
	if err != nil {
		t.Fatalf("first RememberRule: %v", err)
	}

	// Second insert with same path — should update
	node2, err := eng.RememberRule(context.Background(), RuleInput{
		Path:    ".hawk/rules/style.md",
		Content: "Version 2",
		Project: "test",
	})
	if err != nil {
		t.Fatalf("second RememberRule: %v", err)
	}

	if node1.ID != node2.ID {
		t.Error("same key should update, not create new node")
	}
}

func TestRememberRule_ContentIncludesDescription(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.RememberRule(context.Background(), RuleInput{
		Path:        "rule.md",
		Content:     "The rule body",
		Description: "Short description",
		Globs:       []string{"*.go"},
		Project:     "test",
	})
	if err != nil {
		t.Fatalf("RememberRule: %v", err)
	}

	if node.Content == "" {
		t.Fatal("content should not be empty")
	}
	if !containsSubstr(node.Content, "Short description") {
		t.Error("content should include description")
	}
	if !containsSubstr(node.Content, "The rule body") {
		t.Error("content should include body")
	}
}

func containsSubstr(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || findSubstr(s, sub))
}

func findSubstr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
