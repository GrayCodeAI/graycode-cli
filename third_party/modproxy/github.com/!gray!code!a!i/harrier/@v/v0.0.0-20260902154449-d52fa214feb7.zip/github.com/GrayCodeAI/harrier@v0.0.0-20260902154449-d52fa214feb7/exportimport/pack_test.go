package exportimport

import (
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestExportAndVerifyPack(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "n1", Content: "Convention: Use Jose"},
	}
	edges := []*storage.Edge{}

	signingKey := "secret-team-key-123"
	pack, err := ExportPack(nodes, edges, "proj-a", "lead-dev", signingKey)
	if err != nil {
		t.Fatalf("failed to export pack: %v", err)
	}

	valid, err := VerifyPack(pack, signingKey)
	if err != nil || !valid {
		t.Fatalf("expected signature to be valid, got valid=%v, err=%v", valid, err)
	}

	invalid, _ := VerifyPack(pack, "wrong-key")
	if invalid {
		t.Fatalf("expected signature verification to fail with wrong key")
	}
}
