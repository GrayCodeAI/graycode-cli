// Package compact implements memory compaction — auto-summarize when
// the graph exceeds a token budget. Based on Engram and Letta approaches.
package compact

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// Summarizer generates a summary from a list of content strings.
// Default: naive list. Consumers (e.g., Hawk) can inject an LLM-backed implementation.
type Summarizer interface {
	Summarize(ctx context.Context, typ string, contents []string) (string, error)
}

// DefaultSummarizer is the built-in, no-LLM summarizer.
type DefaultSummarizer struct{}

func (DefaultSummarizer) Summarize(_ context.Context, typ string, contents []string) (string, error) {
	return buildCompactSummary(typ, contents), nil
}

// Compactor summarizes old, low-confidence memories to keep the graph lean.
type Compactor struct {
	store      storage.Storage
	maxTokens  int
	summarizer Summarizer
}

func New(store storage.Storage, maxTokens int) *Compactor {
	if maxTokens <= 0 {
		maxTokens = 50000
	}
	return &Compactor{store: store, maxTokens: maxTokens, summarizer: DefaultSummarizer{}}
}

// WithSummarizer sets a custom summarizer (e.g., LLM-backed).
func (c *Compactor) WithSummarizer(s Summarizer) *Compactor {
	c.summarizer = s
	return c
}

// NeedsCompaction returns true if total content exceeds the token budget.
// An empty project is treated as "no compaction needed" — measuring the whole
// store would compact across unrelated projects.
func (c *Compactor) NeedsCompaction(ctx context.Context, project string) (bool, int) {
	if err := ctx.Err(); err != nil {
		return false, 0
	}
	if strings.TrimSpace(project) == "" {
		return false, 0
	}
	nodes, err := c.store.ListNodes(ctx, storage.NodeFilter{Project: project})
	if err != nil {
		slog.Warn("compact: NeedsCompaction list failed", "project", project, "error", err)
		return false, 0
	}
	totalTokens := 0
	for _, n := range nodes {
		// ~4 chars (runes, not bytes) per token; count Summary too.
		totalTokens += (utf8.RuneCountInString(n.Content) + utf8.RuneCountInString(n.Summary)) / 4
	}
	return totalTokens > c.maxTokens, totalTokens
}

// Compact merges low-confidence, old memories of the same type into summary nodes.
// Returns the number of nodes compacted.
func (c *Compactor) Compact(ctx context.Context, project string) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	if strings.TrimSpace(project) == "" {
		return 0, fmt.Errorf("compact: project is required; refusing to compact across all projects")
	}
	nodes, err := c.store.ListNodes(ctx, storage.NodeFilter{Project: project})
	if err != nil {
		return 0, err
	}

	// Group by type
	byType := map[string][]*storage.Node{}
	for _, n := range nodes {
		if n.Type == "file" || n.Type == "entity" || n.Type == "session" {
			continue // don't compact anchors or sessions
		}
		if n.Confidence <= 0 {
			continue // archived nodes must never be re-compacted
		}
		if n.Confidence < 0.5 && n.AccessCount < 3 {
			byType[n.Type] = append(byType[n.Type], n)
		}
	}

	compacted := 0
	for typ, group := range byType {
		if len(group) < 3 {
			continue // not enough to compact
		}
		if err := ctx.Err(); err != nil {
			return compacted, err
		}

		// Build summary from group
		contents := make([]string, 0, len(group))
		ids := make([]string, 0, len(group))
		for _, n := range group {
			contents = append(contents, n.Content)
			ids = append(ids, n.ID)
		}

		summary, err := c.summarizer.Summarize(ctx, typ, contents)
		if err != nil {
			// Skipping this group is safe — nothing has been mutated yet.
			slog.Warn("compact: summarize failed, skipping group", "type", typ, "count", len(group), "error", err)
			continue
		}

		// Create summary node
		hashInput := strings.Join(ids, "\x00")
		contentHash := fmt.Sprintf("%x", sha256.Sum256([]byte(hashInput)))
		now := time.Now()
		summaryNode := &storage.Node{
			ID:          uuid.New().String(),
			Type:        typ,
			Content:     summary,
			ContentHash: contentHash,
			Summary:     fmt.Sprintf("Compacted %d %s memories", len(ids), typ),
			Scope:       group[0].Scope,
			Project:     project,
			Tier:        3, // cold
			Confidence:  0.6,
			Version:     1,
			CreatedAt:   now,
			UpdatedAt:   now,
		}

		// The whole mutation — summary node creation, edge re-linking and
		// archival — is one transaction so a mid-way failure leaves the graph
		// untouched instead of half re-linked.
		err = c.store.WithTx(ctx, func(tx storage.Storage) error {
			if err := tx.CreateNode(ctx, summaryNode); err != nil {
				return fmt.Errorf("compact: create summary node %s: %w", summaryNode.ID, err)
			}

			compactedIDs := make(map[string]bool, len(ids))
			for _, id := range ids {
				compactedIDs[id] = true
			}
			for _, id := range ids {
				if err := ctx.Err(); err != nil {
					return err
				}
				outEdges, err := tx.GetEdgesFrom(ctx, id)
				if err != nil {
					return fmt.Errorf("compact: list outbound edges of node %s: %w", id, err)
				}
				for _, e := range outEdges {
					if compactedIDs[e.ToID] {
						continue // skip edges between compacted nodes
					}
					if err := relinkEdge(ctx, tx, summaryNode.ID, e.ToID, e); err != nil {
						return err
					}
				}
				inEdges, err := tx.GetEdgesTo(ctx, id)
				if err != nil {
					return fmt.Errorf("compact: list inbound edges of node %s: %w", id, err)
				}
				for _, e := range inEdges {
					if compactedIDs[e.FromID] {
						continue
					}
					if err := relinkEdge(ctx, tx, e.FromID, summaryNode.ID, e); err != nil {
						return err
					}
				}
			}

			// Archive compacted nodes
			for _, id := range ids {
				if err := ctx.Err(); err != nil {
					return err
				}
				old, err := tx.GetNode(ctx, id)
				if err != nil {
					if errors.Is(err, storage.ErrNodeNotFound) {
						// Node disappeared concurrently — nothing to archive.
						slog.Warn("compact: node vanished before archival", "node_id", id)
						continue
					}
					return fmt.Errorf("compact: load node %s for archival: %w", id, err)
				}
				if old == nil {
					continue
				}
				if err := tx.SaveVersion(ctx, old.ID, old.Content, "compactor", "compacted into "+summaryNode.ID[:8]); err != nil {
					return fmt.Errorf("compact: save version of node %s: %w", old.ID, err)
				}
				old.Confidence = 0
				if err := tx.UpdateNode(ctx, old); err != nil {
					return fmt.Errorf("compact: archive node %s: %w", old.ID, err)
				}
			}
			return nil
		})
		if err != nil {
			return compacted, fmt.Errorf("compact: commit compaction of %s: %w", typ, err)
		}
		compacted += len(ids)
	}
	return compacted, nil
}

// relinkEdge transfers an edge onto the summary node. Duplicate edges are
// benign (the link already exists) and are logged at debug level; any other
// failure is propagated so the compaction pipeline can abort.
func relinkEdge(ctx context.Context, store storage.Storage, fromID, toID string, orig *storage.Edge) error {
	err := store.CreateEdge(ctx, &storage.Edge{
		ID:     uuid.New().String(),
		FromID: fromID,
		ToID:   toID,
		Type:   orig.Type,
		Weight: orig.Weight,
	})
	if err == nil {
		return nil
	}
	if errors.Is(err, storage.ErrDuplicateEdge) {
		slog.Debug("compact: re-linked edge already exists", "from", fromID, "to", toID, "type", orig.Type)
		return nil
	}
	return fmt.Errorf("compact: re-link edge %s→%s (%s): %w", fromID, toID, orig.Type, err)
}

func buildCompactSummary(typ string, contents []string) string {
	// Take first 5 items as representative
	limit := 5
	if len(contents) < limit {
		limit = len(contents)
	}
	var sb strings.Builder
	fmt.Fprintf(&sb, "Summary of %d %s memories:\n", len(contents), typ)
	for i, c := range contents[:limit] {
		if len(c) > 100 {
			c = c[:100] + "..."
		}
		fmt.Fprintf(&sb, "%d. %s\n", i+1, c)
	}
	if len(contents) > limit {
		fmt.Fprintf(&sb, "... and %d more\n", len(contents)-limit)
	}
	return sb.String()
}
