# Harrier LongMem Core Baseline

## Metadata

- Suite: `harrier-longmem-core`
- Date: `2026-06-27`
- Model: none
- Provider: none
- Commit: current workspace snapshot
- Command: `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/longmemreport --suite default'`

## Headline Metrics

- R@1: `66.7%`
- R@3: `88.9%`
- R@5: `94.4%`
- R@10: `100.0%`
- MRR: `0.781`
- Avg tokens/query: `94`
- Duration: `15.61675ms`

## Notes

- This is the first committed repo-owned baseline artifact for `harrier-longmem-core`.
- The run uses the built-in default QA set from `harrier/internal/bench`.
- The report is generated from a local SQLite-backed seeded memory graph with no external model dependency.

## Comparison Summary

- Previous baseline: none committed
- Change since baseline: initial published baseline
- Interpretation: retrieval quality is already strong at broader cutoffs (`R@5`, `R@10`) with room to improve first-rank accuracy.
