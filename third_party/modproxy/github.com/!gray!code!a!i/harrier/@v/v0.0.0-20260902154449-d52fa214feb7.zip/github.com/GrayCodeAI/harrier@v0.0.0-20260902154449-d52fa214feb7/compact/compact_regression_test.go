package compact

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func seedMemoryNode(t *testing.T, store storage.Storage, typ, project string, confidence float64, accessCount int, extra string) *storage.Node {
	t.Helper()
	content := "memory content " + extra
	hash := fmt.Sprintf("%x", sha256.Sum256([]byte(content)))
	n := &storage.Node{
		ID:          fmt.Sprintf("node-%s-%s-%s", project, typ, extra),
		Type:        typ,
		Content:     content,
		ContentHash: hash,
		Scope:       "global",
		Project:     project,
		Confidence:  confidence,
		AccessCount: accessCount,
		CreatedAt:   time.Now().Add(-time.Hour),
		UpdatedAt:   time.Now().Add(-time.Hour),
	}
	if err := store.CreateNode(context.Background(), n); err != nil {
		t.Fatal(err)
	}
	return n
}

func TestCompact_EmptyProjectRefused(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	c := New(store, 100)
	ctx := context.Background()

	for _, project := range []string{"", "   "} {
		n, err := c.Compact(ctx, project)
		if err == nil {
			t.Errorf("Compact(%q): expected error, got nil (compacted=%d)", project, n)
		}
	}
}

func TestCompact_SkipsArchivedNodes(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	c := New(store, 10000)
	ctx := context.Background()

	seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-1")
	seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-2")
	seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-3")
	seedMemoryNode(t, store, "idea", "p1", 0, 0, "archived-1")
	seedMemoryNode(t, store, "idea", "p1", 0, 0, "archived-2")
	seedMemoryNode(t, store, "idea", "p1", 0, 0, "archived-3")

	n, err := c.Compact(ctx, "p1")
	if err != nil {
		t.Fatalf("Compact failed: %v", err)
	}
	if n != 3 {
		t.Errorf("expected 3 archived (live) nodes compacted, got %d", n)
	}

	// Only the live nodes collapsed into the summary.
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: "p1"})
	if err != nil {
		t.Fatal(err)
	}
	var summary *storage.Node
	for _, node := range nodes {
		if strings.HasPrefix(node.Content, "Summary of") {
			summary = node
		}
		if node.Confidence == 0 {
			continue // archived stays archived
		}
		if node.Confidence < 0.5 {
			t.Errorf("live node %s was not archived but is still low-confidence after compact", node.ID)
		}
	}
	if summary == nil {
		t.Fatal("no summary node created")
	}
	if !strings.Contains(summary.Content, "Summary of 3 idea memories") {
		t.Errorf("summary should mention only live nodes, got: %q", summary.Content)
	}
	if summary.Summary != "Compacted 3 idea memories" {
		t.Errorf("summary field = %q, want %q", summary.Summary, "Compacted 3 idea memories")
	}
	if summary.Confidence != 0.6 {
		t.Errorf("summary node confidence = %f, want 0.6", summary.Confidence)
	}
}

func TestCompact_SetsSummaryNodeTimestamps(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	c := New(store, 10000)
	ctx := context.Background()

	for i := 0; i < 3; i++ {
		seedMemoryNode(t, store, "idea", "p1", 0.4, 0, fmt.Sprintf("live-%d", i))
	}

	before := time.Now()
	if _, err := c.Compact(ctx, "p1"); err != nil {
		t.Fatalf("Compact failed: %v", err)
	}

	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: "p1"})
	if err != nil {
		t.Fatal(err)
	}
	for _, node := range nodes {
		if node.Confidence != 0.6 {
			continue // summary node only
		}
		if node.CreatedAt.IsZero() || node.UpdatedAt.IsZero() {
			t.Errorf("summary node timestamps must be set, got CreatedAt=%v UpdatedAt=%v", node.CreatedAt, node.UpdatedAt)
		}
		if node.CreatedAt.Before(before) {
			t.Errorf("summary node CreatedAt %v is before compaction started %v", node.CreatedAt, before)
		}
	}
}

// failingStore fails every CreateEdge call after the first, to force a
// mid-transaction failure while re-linking edges.
type failingStore struct {
	storage.Storage
	calls int
}

func (f *failingStore) CreateEdge(ctx context.Context, e *storage.Edge) error {
	f.calls++
	if f.calls > 1 {
		return errors.New("injected edge failure")
	}
	return f.Storage.CreateEdge(ctx, e)
}

func (f *failingStore) WithTx(ctx context.Context, fn func(storage.Storage) error) error {
	return f.Storage.WithTx(ctx, func(tx storage.Storage) error {
		return fn(&failingStore{Storage: tx})
	})
}

func TestCompact_TransactionalRollback(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	fs := &failingStore{Storage: store}
	c := New(fs, 10000)
	ctx := context.Background()

	n1 := seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-1")
	n2 := seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-2")
	n3 := seedMemoryNode(t, store, "idea", "p1", 0.4, 0, "live-3")
	ext := seedMemoryNode(t, store, "entity", "p1", 1.0, 5, "external")
	if err := store.CreateEdge(ctx, &storage.Edge{
		ID: "edge-1", FromID: n1.ID, ToID: ext.ID, Type: "mentions",
	}); err != nil {
		t.Fatal(err)
	}
	if err := store.CreateEdge(ctx, &storage.Edge{
		ID: "edge-2", FromID: n2.ID, ToID: ext.ID, Type: "mentions",
	}); err != nil {
		t.Fatal(err)
	}

	if _, err := c.Compact(ctx, "p1"); err == nil {
		t.Fatal("expected compaction to fail on injected edge error")
	}

	// Nothing may have been committed: summary node absent, original nodes
	// still live, original edges untouched.
	if _, err := store.GetNode(ctx, n1.ID); err != nil {
		t.Errorf("node n1 lost after rollback: %v", err)
	}
	for _, n := range []*storage.Node{n1, n2, n3} {
		got, err := store.GetNode(ctx, n.ID)
		if err != nil {
			t.Fatalf("GetNode(%s) failed: %v", n.ID, err)
		}
		if got.Confidence != 0.4 {
			t.Errorf("node %s archived despite rollback (confidence=%f)", n.ID, got.Confidence)
		}
	}
	out, err := store.GetEdgesFrom(ctx, n1.ID)
	if err != nil {
		t.Fatal(err)
	}
	if len(out) != 1 || out[0].ToID != ext.ID {
		t.Errorf("original edge n1->ext not preserved after rollback: %+v", out)
	}
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: "p1"})
	if err != nil {
		t.Fatal(err)
	}
	for _, node := range nodes {
		if strings.HasPrefix(node.Content, "Summary of") {
			t.Errorf("summary node survived rollback: %q", node.Content)
		}
	}
}
