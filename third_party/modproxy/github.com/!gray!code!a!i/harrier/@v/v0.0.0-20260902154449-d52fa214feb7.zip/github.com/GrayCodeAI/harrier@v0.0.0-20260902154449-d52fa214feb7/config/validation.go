package config

import (
	"fmt"
	"strings"
)

// ValidationErrorType categorizes the kind of validation problem.
type ValidationErrorType int

const (
	MissingRequired    ValidationErrorType = iota // A required field is absent or zero-value.
	InvalidValue                                  // A field has an invalid or malformed value.
	OutOfRange                                    // A numeric field is outside its acceptable range.
	IncompatibleFields                            // Two or more fields conflict with each other.
	UnknownField                                  // A TOML key is not recognized.
)

func (t ValidationErrorType) String() string {
	switch t {
	case MissingRequired:
		return "missing required"
	case InvalidValue:
		return "invalid value"
	case OutOfRange:
		return "out of range"
	case IncompatibleFields:
		return "incompatible fields"
	case UnknownField:
		return "unknown field"
	default:
		return "unknown"
	}
}

// ConfigError is a single validation problem found in the configuration.
type ConfigError struct {
	Field   string              // Dot-separated path to the offending field (e.g. "decay.half_life_days").
	Message string              // Human-readable explanation of the problem.
	Value   interface{}         // The offending value, or nil for missing-required errors.
	ErrType ValidationErrorType // Categorization of the error.
}

func (e ConfigError) String() string {
	if e.Value != nil {
		return fmt.Sprintf("[%s] %s: %s (got %v)", e.ErrType, e.Field, e.Message, e.Value)
	}
	return fmt.Sprintf("[%s] %s: %s", e.ErrType, e.Field, e.Message)
}

// ConfigValidator validates a Config and returns any errors found.
type ConfigValidator interface {
	Validate(cfg *Config) []ConfigError
}

// ---------- built-in validators ----------

// serverValidator checks server configuration.
type serverValidator struct{}

func (serverValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	port := cfg.Server.Port
	if port < 1 || port > 65535 {
		errs = append(errs, ConfigError{
			Field:   "server.port",
			Message: "port must be between 1 and 65535",
			Value:   port,
			ErrType: OutOfRange,
		})
	}
	if cfg.Server.Host == "" {
		errs = append(errs, ConfigError{
			Field:   "server.host",
			Message: "host is required",
			Value:   cfg.Server.Host,
			ErrType: MissingRequired,
		})
	}
	if cfg.Server.TLS {
		if cfg.Server.CertFile == "" {
			errs = append(errs, ConfigError{
				Field:   "server.cert_file",
				Message: "cert_file is required when TLS is enabled",
				ErrType: IncompatibleFields,
			})
		}
		if cfg.Server.KeyFile == "" {
			errs = append(errs, ConfigError{
				Field:   "server.key_file",
				Message: "key_file is required when TLS is enabled",
				ErrType: IncompatibleFields,
			})
		}
	}
	return errs
}

// memoryValidator checks memory configuration ranges.
type memoryValidator struct{}

func (memoryValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	if cfg.Memory.HotTokenBudget < 1 {
		errs = append(errs, ConfigError{
			Field:   "memory.hot_token_budget",
			Message: "hot_token_budget must be greater than 0",
			Value:   cfg.Memory.HotTokenBudget,
			ErrType: OutOfRange,
		})
	}
	if cfg.Memory.WarmTokenBudget < 1 {
		errs = append(errs, ConfigError{
			Field:   "memory.warm_token_budget",
			Message: "warm_token_budget must be greater than 0",
			Value:   cfg.Memory.WarmTokenBudget,
			ErrType: OutOfRange,
		})
	}
	if cfg.Memory.MaxMemories < 1 {
		errs = append(errs, ConfigError{
			Field:   "memory.max_memories",
			Message: "max_memories must be greater than 0",
			Value:   cfg.Memory.MaxMemories,
			ErrType: OutOfRange,
		})
	}
	return errs
}

// searchValidator checks search weight ranges.
type searchValidator struct{}

func (searchValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	if cfg.Search.BM25Weight < 0 || cfg.Search.BM25Weight > 1 {
		errs = append(errs, ConfigError{
			Field:   "search.bm25_weight",
			Message: "bm25_weight must be between 0 and 1",
			Value:   cfg.Search.BM25Weight,
			ErrType: OutOfRange,
		})
	}
	if cfg.Search.VectorWeight < 0 || cfg.Search.VectorWeight > 1 {
		errs = append(errs, ConfigError{
			Field:   "search.vector_weight",
			Message: "vector_weight must be between 0 and 1",
			Value:   cfg.Search.VectorWeight,
			ErrType: OutOfRange,
		})
	}
	if cfg.Search.DefaultLimit < 1 {
		errs = append(errs, ConfigError{
			Field:   "search.default_limit",
			Message: "default_limit must be greater than 0",
			Value:   cfg.Search.DefaultLimit,
			ErrType: OutOfRange,
		})
	}
	return errs
}

// decayValidator checks decay configuration ranges.
type decayValidator struct{}

func (decayValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	if cfg.Decay.HalfLifeDays < 1 {
		errs = append(errs, ConfigError{
			Field:   "decay.half_life_days",
			Message: "half_life_days must be greater than 0",
			Value:   cfg.Decay.HalfLifeDays,
			ErrType: OutOfRange,
		})
	}
	if cfg.Decay.MinConfidence < 0 || cfg.Decay.MinConfidence > 1 {
		errs = append(errs, ConfigError{
			Field:   "decay.min_confidence",
			Message: "min_confidence must be between 0 and 1",
			Value:   cfg.Decay.MinConfidence,
			ErrType: OutOfRange,
		})
	}
	if cfg.Decay.BoostOnAccess < 0 || cfg.Decay.BoostOnAccess > 1 {
		errs = append(errs, ConfigError{
			Field:   "decay.boost_on_access",
			Message: "boost_on_access must be between 0 and 1",
			Value:   cfg.Decay.BoostOnAccess,
			ErrType: OutOfRange,
		})
	}
	return errs
}

// embeddingsValidator checks that embeddings config is coherent.
type embeddingsValidator struct{}

func (embeddingsValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	if cfg.Embeddings.Enabled && cfg.Embeddings.Provider == "" {
		errs = append(errs, ConfigError{
			Field:   "embeddings.provider",
			Message: "provider is required when embeddings are enabled",
			ErrType: IncompatibleFields,
		})
	}
	return errs
}

// tlsValidator checks TLS field compatibility with server config.
type tlsValidator struct{}

func (tlsValidator) Validate(cfg *Config) []ConfigError {
	var errs []ConfigError
	if (cfg.Server.CertFile != "" || cfg.Server.KeyFile != "") && !cfg.Server.TLS {
		errs = append(errs, ConfigError{
			Field:   "server.tls",
			Message: "cert_file or key_file specified but TLS is not enabled",
			ErrType: IncompatibleFields,
		})
	}
	return errs
}

// ---------- public API ----------

// builtinValidators is the ordered list of all built-in validators.
var builtinValidators = []ConfigValidator{
	serverValidator{},
	memoryValidator{},
	searchValidator{},
	decayValidator{},
	embeddingsValidator{},
	tlsValidator{},
}

// ValidateConfig runs all built-in validators against cfg and returns the
// aggregated list of ConfigErrors.
func ValidateConfig(cfg *Config) []ConfigError {
	var all []ConfigError
	for _, v := range builtinValidators {
		all = append(all, v.Validate(cfg)...)
	}
	return all
}

// FormatErrors produces a human-readable summary of validation errors.
func FormatErrors(errs []ConfigError) string {
	if len(errs) == 0 {
		return ""
	}
	var b strings.Builder
	fmt.Fprintf(&b, "%d config validation error(s):\n", len(errs))
	for i, e := range errs {
		fmt.Fprintf(&b, "  %d. %s\n", i+1, e.String())
	}
	return b.String()
}
