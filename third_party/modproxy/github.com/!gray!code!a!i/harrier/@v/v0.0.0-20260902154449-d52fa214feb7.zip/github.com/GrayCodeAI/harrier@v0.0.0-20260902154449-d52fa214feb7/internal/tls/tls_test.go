package tls

import (
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"os"
	"path/filepath"
	"testing"
)

func TestTLSConfigGeneratesSelfSignedCert(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()

	cfg := Config{Enabled: true}
	tlsCfg, err := TLSConfig(cfg, dir)
	if err != nil {
		t.Fatalf("TLSConfig: %v", err)
	}

	if tlsCfg == nil {
		t.Fatal("TLSConfig returned nil")
	}

	// MinVersion should be TLS 1.2
	if tlsCfg.MinVersion != tls.VersionTLS12 {
		t.Errorf("MinVersion = %x, want %x", tlsCfg.MinVersion, tls.VersionTLS12)
	}

	// Should have at least one certificate
	if len(tlsCfg.Certificates) == 0 {
		t.Fatal("TLSConfig returned no certificates")
	}

	// Verify cert and key files were created
	certPath := filepath.Join(dir, "cert.pem")
	keyPath := filepath.Join(dir, "key.pem")

	if _, err := os.Stat(certPath); os.IsNotExist(err) {
		t.Error("cert.pem was not created")
	}
	if _, err := os.Stat(keyPath); os.IsNotExist(err) {
		t.Error("key.pem was not created")
	}
}

func TestTLSConfigUsesExistingCerts(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()

	// Generate certs first time
	cfg := Config{Enabled: true}
	_, err := TLSConfig(cfg, dir)
	if err != nil {
		t.Fatalf("first TLSConfig: %v", err)
	}

	// Load again — should reuse existing certs
	tlsCfg, err := TLSConfig(cfg, dir)
	if err != nil {
		t.Fatalf("second TLSConfig: %v", err)
	}

	if len(tlsCfg.Certificates) == 0 {
		t.Fatal("second TLSConfig returned no certificates")
	}
}

func TestTLSConfigCustomCertPaths(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	certPath := filepath.Join(dir, "custom-cert.pem")
	keyPath := filepath.Join(dir, "custom-key.pem")

	cfg := Config{
		Enabled:  true,
		CertFile: certPath,
		KeyFile:  keyPath,
	}
	_, err := TLSConfig(cfg, dir)
	if err != nil {
		t.Fatalf("TLSConfig with custom paths: %v", err)
	}

	if _, err := os.Stat(certPath); os.IsNotExist(err) {
		t.Error("custom cert.pem was not created")
	}
	if _, err := os.Stat(keyPath); os.IsNotExist(err) {
		t.Error("custom key.pem was not created")
	}
}

func TestSelfSignedCertProperties(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	certPath := filepath.Join(dir, "cert.pem")
	keyPath := filepath.Join(dir, "key.pem")

	if err := generateSelfSigned(certPath, keyPath); err != nil {
		t.Fatalf("generateSelfSigned: %v", err)
	}

	// Read and parse the cert
	data, err := os.ReadFile(certPath)
	if err != nil {
		t.Fatalf("read cert: %v", err)
	}
	block, _ := pem.Decode(data)
	if block == nil {
		t.Fatal("failed to decode PEM block")
	}

	cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		t.Fatalf("parse cert: %v", err)
	}

	// Check subject organization
	if len(cert.Subject.Organization) == 0 || cert.Subject.Organization[0] != "harrier" {
		t.Errorf("Organization = %v, want [harrier]", cert.Subject.Organization)
	}

	// Check SANs
	if len(cert.DNSNames) == 0 || cert.DNSNames[0] != "localhost" {
		t.Errorf("DNSNames = %v, want [localhost]", cert.DNSNames)
	}

	if len(cert.IPAddresses) == 0 || cert.IPAddresses[0].String() != "127.0.0.1" {
		t.Errorf("IPAddresses = %v, want [127.0.0.1]", cert.IPAddresses)
	}

	// Check key usage
	if cert.KeyUsage&x509.KeyUsageKeyEncipherment == 0 {
		t.Error("missing KeyUsageKeyEncipherment")
	}
	if cert.KeyUsage&x509.KeyUsageDigitalSignature == 0 {
		t.Error("missing KeyUsageDigitalSignature")
	}

	// Check extended key usage
	hasServerAuth := false
	for _, eku := range cert.ExtKeyUsage {
		if eku == x509.ExtKeyUsageServerAuth {
			hasServerAuth = true
		}
	}
	if !hasServerAuth {
		t.Error("missing ExtKeyUsageServerAuth")
	}

	// Cert should be valid for ~365 days (give or take a few seconds)
	validity := cert.NotAfter.Sub(cert.NotBefore)
	if validity < 364*24*60*60*1e9 || validity > 366*24*60*60*1e9 {
		t.Errorf("validity = %v, want ~365 days", validity)
	}
}

func TestSelfSignedCertPEMBlocks(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	certPath := filepath.Join(dir, "cert.pem")
	keyPath := filepath.Join(dir, "key.pem")

	if err := generateSelfSigned(certPath, keyPath); err != nil {
		t.Fatalf("generateSelfSigned: %v", err)
	}

	// Verify cert PEM type
	certData, _ := os.ReadFile(certPath)
	block, _ := pem.Decode(certData)
	if block == nil || block.Type != "CERTIFICATE" {
		t.Errorf("cert PEM type = %q, want CERTIFICATE", func() string {
			if block != nil {
				return block.Type
			}
			return "<nil>"
		}())
	}

	// Verify key PEM type
	keyData, _ := os.ReadFile(keyPath)
	keyBlock, _ := pem.Decode(keyData)
	if keyBlock == nil || keyBlock.Type != "EC PRIVATE KEY" {
		t.Errorf("key PEM type = %q, want EC PRIVATE KEY", func() string {
			if keyBlock != nil {
				return keyBlock.Type
			}
			return "<nil>"
		}())
	}
}

func TestCertFilePermissions(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	certPath := filepath.Join(dir, "cert.pem")
	keyPath := filepath.Join(dir, "key.pem")

	if err := generateSelfSigned(certPath, keyPath); err != nil {
		t.Fatalf("generateSelfSigned: %v", err)
	}

	// Key file should have restrictive permissions (0600)
	info, err := os.Stat(keyPath)
	if err != nil {
		t.Fatalf("stat key: %v", err)
	}
	perm := info.Mode().Perm()
	if perm != 0o600 {
		t.Errorf("key file permissions = %o, want 0600", perm)
	}

	// Cert file should have 0644
	info, err = os.Stat(certPath)
	if err != nil {
		t.Fatalf("stat cert: %v", err)
	}
	perm = info.Mode().Perm()
	if perm != 0o644 {
		t.Errorf("cert file permissions = %o, want 0644", perm)
	}
}
