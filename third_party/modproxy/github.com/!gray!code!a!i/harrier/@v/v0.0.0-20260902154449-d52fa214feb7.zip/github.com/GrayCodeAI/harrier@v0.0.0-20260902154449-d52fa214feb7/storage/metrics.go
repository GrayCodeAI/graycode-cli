package storage

import (
	"context"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	NodesTotal = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "harrier_nodes_total",
		Help: "Total nodes by project and type",
	}, []string{"project", "type"})

	RecallLatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name:    "harrier_recall_duration_seconds",
		Help:    "Recall operation latency",
		Buckets: []float64{.005, .01, .025, .05, .1, .25, .5, 1},
	}, []string{"project", "status"})

	VectorSearchLatency = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "harrier_vector_search_duration_seconds",
		Help:    "Vector similarity search latency",
		Buckets: []float64{.005, .01, .025, .05, .1, .25, .5, 1},
	})

	DBSize = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "harrier_db_size_bytes",
		Help: "SQLite database file size in bytes",
	})

	WALSize = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "harrier_wal_size_bytes",
		Help: "WAL file size in bytes",
	})

	LockWait = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "harrier_lock_wait_seconds",
		Help:    "Time spent waiting for database lock",
		Buckets: []float64{.001, .005, .01, .025, .05, .1, .25, .5, 1, 5},
	})

	SchemaVersion = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "harrier_schema_version",
		Help: "Current schema migration version",
	})

	WriteLatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name:    "harrier_write_duration_seconds",
		Help:    "Write operation latency",
		Buckets: []float64{.001, .005, .01, .025, .05, .1, .25, .5},
	}, []string{"operation", "status"})

	MigrationDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "harrier_migration_duration_seconds",
		Help:    "Schema migration duration",
		Buckets: []float64{.01, .05, .1, .5, 1, 5, 10},
	})
)

// RecordMetrics updates gauges from database state.
func (s *Store) RecordMetrics(ctx context.Context) error {
	// Node counts by project/type
	rows, err := s.db.QueryContext(ctx, `SELECT project, type, COUNT(*) FROM nodes GROUP BY project, type`)
	if err != nil {
		return err
	}
	defer func() { _ = rows.Close() }()
	for rows.Next() {
		var project, typ string
		var count int
		if err := rows.Scan(&project, &typ, &count); err != nil {
			continue
		}
		if project == "" {
			project = "__global__"
		}
		NodesTotal.WithLabelValues(project, typ).Set(float64(count))
	}

	// DB file size
	var pageCount, pageSize int64
	if err := s.db.QueryRowContext(ctx, "PRAGMA page_count").Scan(&pageCount); err != nil {
		return err
	}
	if err := s.db.QueryRowContext(ctx, "PRAGMA page_size").Scan(&pageSize); err != nil {
		return err
	}
	DBSize.Set(float64(pageCount * pageSize))

	// Schema version
	if v, err := s.GetSchemaVersion(ctx); err == nil {
		SchemaVersion.Set(float64(v))
	}

	return nil
}
