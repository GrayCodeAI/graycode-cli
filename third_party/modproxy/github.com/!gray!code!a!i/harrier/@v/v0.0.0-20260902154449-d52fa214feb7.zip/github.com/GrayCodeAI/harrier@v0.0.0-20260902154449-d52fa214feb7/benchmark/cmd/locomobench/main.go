// Command locomobench runs harrier's retrieval-quality harness against the
// public LoCoMo-10 long-term conversational memory benchmark, as opposed to
// longmemreport's first-party self-seeded QA set. Each of LoCoMo-10's 10
// conversations is benchmarked against its own freshly seeded engine (see
// locomo.SeedInputs for why), then results are aggregated.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/GrayCodeAI/harrier/benchmark/locomo"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	bench "github.com/GrayCodeAI/harrier/internal/bench"
	"github.com/GrayCodeAI/harrier/storage"
)

func main() {
	var (
		depth      = flag.Int("depth", 2, "recall depth")
		limit      = flag.Int("limit", 10, "recall limit")
		datasetURL = flag.String("dataset-url", locomo.DatasetURL, "LoCoMo-10 dataset URL to download")
		cacheFile  = flag.String("cache", "", "local path to a previously downloaded LoCoMo-10 JSON file (skips download if present)")
	)
	flag.Parse()

	ctx := context.Background()

	datasetPath := *cacheFile
	if datasetPath == "" {
		dir := mustTempDir()
		datasetPath = filepath.Join(dir, "locomo10.json")
	}
	if _, err := os.Stat(datasetPath); err != nil {
		fmt.Fprintf(os.Stderr, "Downloading LoCoMo-10 dataset from %s...\n", *datasetURL)
		must(locomo.Download(*datasetURL, datasetPath))
	}

	samples, err := locomo.Load(datasetPath)
	must(err)

	fmt.Printf("Suite: harrier-locomo\n")
	fmt.Printf("Samples: %d\n", len(samples))
	fmt.Printf("Depth: %d\n", *depth)
	fmt.Printf("Limit: %d\n", *limit)
	fmt.Printf("Timestamp: %s\n\n", time.Now().UTC().Format(time.RFC3339))

	agg := &bench.Result{HitAtK: map[int]int{1: 0, 3: 0, 5: 0, 10: 0}}
	var mrrWeighted, tokensWeighted float64

	for _, sample := range samples {
		result, err := runSample(ctx, sample, *depth, *limit)
		if err != nil {
			fmt.Fprintf(os.Stderr, "sample %s: %v\n", sample.SampleID, err)
			continue
		}
		fmt.Printf("--- %s (%d questions) ---\n", sample.SampleID, result.Total)
		fmt.Print(result.String())
		fmt.Println()

		agg.Total += result.Total
		for _, k := range []int{1, 3, 5, 10} {
			agg.HitAtK[k] += result.HitAtK[k]
		}
		mrrWeighted += result.MRR * float64(result.Total)
		tokensWeighted += result.AvgTokens * float64(result.Total)
		agg.Duration += result.Duration
	}

	if agg.Total > 0 {
		agg.MRR = mrrWeighted / float64(agg.Total)
		agg.AvgTokens = tokensWeighted / float64(agg.Total)
	}

	fmt.Println("=== Aggregate across all samples ===")
	fmt.Print(agg.String())
}

// runSample seeds a fresh, isolated engine with one LoCoMo sample's
// dialogue turns and runs bench.Run against that sample's QA pairs.
func runSample(ctx context.Context, sample locomo.Sample, depth, limit int) (*bench.Result, error) {
	dir, err := os.MkdirTemp("", "harrier-locomo-*")
	if err != nil {
		return nil, err
	}
	defer func() { _ = os.RemoveAll(dir) }()

	store, err := storage.NewStore(filepath.Join(dir, "locomo.db"))
	if err != nil {
		return nil, err
	}
	defer func() { _ = store.Close() }()

	eng := engine.New(store, graph.New(store, store.DB()))
	defer eng.Close()

	for _, in := range sample.SeedInputs() {
		if _, err := eng.Remember(ctx, in); err != nil {
			return nil, fmt.Errorf("seed: %w", err)
		}
	}

	qas := sample.ToQAs()
	return bench.Run(ctx, eng, qas, depth, limit), nil
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}

func mustTempDir() string {
	dir, err := os.MkdirTemp("", "harrier-locomo-cache-*")
	must(err)
	return dir
}
