package storage

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

// ProcessLock provides cross-process exclusive ownership of a database and
// in-process reference counting of the lock. The OS lock (flock on Unix,
// LockFileEx on Windows) is held once per process on a lock file next to
// the database; multiple stores in the same process — common in hosts that
// open the memory bridge from several callsites — share it via a refcount
// and never block each other.
//
// The in-memory no-op lock (path == "") is safe to create and release.
type ProcessLock struct {
	proc *procLock
	once sync.Once
	err  error
}

// procLock is the per-path, per-process holder of the OS lock. It lives in
// procHolders for as long as at least one ProcessLock references it.
type procLock struct {
	fd   *os.File
	path string
	refs int
}

var (
	procMu      sync.Mutex
	procHolders = make(map[string]*procLock)
)

// AcquireProcessLock returns a shared process lock for dbPath. The first
// acquisition in the process takes the OS lock non-blockingly and fails if
// another harrier process already holds it; subsequent acquisitions from the
// same process bump the refcount. In-memory DSNs return a no-op lock.
func AcquireProcessLock(dbPath string) (*ProcessLock, error) {
	if isMemoryDSN(dbPath) {
		return &ProcessLock{}, nil // no-op for in-memory
	}
	procMu.Lock()
	defer procMu.Unlock()

	// Normalize the lock path so equivalent spellings of the same database
	// ("data/harrier.db", "./data/harrier.db", "x/../data/harrier.db") share one
	// procHolders entry. Without this, two paths resolving to the same lock
	// file would open it twice in-process; flock treats the two open file
	// descriptions as separate holders, so the second open would spuriously
	// fail with "locked by another harrier process".
	lockPath := dbPath + ".lock"
	if abs, err := filepath.Abs(lockPath); err == nil {
		lockPath = abs
	}
	if p, ok := procHolders[lockPath]; ok {
		p.refs++
		return &ProcessLock{proc: p}, nil
	}

	fd, err := os.OpenFile(lockPath, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return nil, fmt.Errorf("open lock file: %w", err)
	}
	// Non-blocking exclusive lock: fail fast instead of waiting for the
	// other process to exit.
	if err := acquireOSLock(fd); err != nil {
		_ = fd.Close()
		return nil, fmt.Errorf("database locked by another harrier process: %w", err)
	}
	p := &procLock{fd: fd, path: lockPath, refs: 1}
	procHolders[lockPath] = p
	return &ProcessLock{proc: p}, nil
}

// Release decrements the refcount and, on the last release in the process,
// unlocks and best-effort removes the lock file. Repeated releases on the
// same lock and releases of the no-op lock are safe.
func (l *ProcessLock) Release() error {
	if l.proc == nil {
		return nil
	}
	l.once.Do(func() {
		l.err = l.releaseOnce()
	})
	return l.err
}

func (l *ProcessLock) releaseOnce() error {
	procMu.Lock()
	defer procMu.Unlock()

	// A refcount drop must stay paired with its holder: if another Release
	// raced us for the same holder (guarded by l.once), refs is already
	// accounted for.
	p := l.proc
	p.refs--
	if p.refs > 0 {
		return nil
	}
	delete(procHolders, p.path)
	releaseOSLock(p.fd)
	err := p.fd.Close()
	_ = os.Remove(p.path) // best-effort cleanup
	return err
}
