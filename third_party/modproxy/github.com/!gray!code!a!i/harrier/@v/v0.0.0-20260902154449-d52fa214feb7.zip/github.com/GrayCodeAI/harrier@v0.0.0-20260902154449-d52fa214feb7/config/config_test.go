package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDefault(t *testing.T) {
	t.Parallel()
	cfg := Default()

	if cfg.Server.Port != 3456 {
		t.Errorf("expected port 3456, got %d", cfg.Server.Port)
	}
	if cfg.Server.Host != "127.0.0.1" {
		t.Errorf("expected host 127.0.0.1, got %s", cfg.Server.Host)
	}
	if cfg.Memory.HotTokenBudget != 800 {
		t.Errorf("expected hot token budget 800, got %d", cfg.Memory.HotTokenBudget)
	}
	if cfg.Decay.HalfLifeDays != 30 {
		t.Errorf("expected half life 30, got %d", cfg.Decay.HalfLifeDays)
	}
	if !cfg.Decay.Enabled {
		t.Error("expected decay to be enabled by default")
	}
	if !cfg.Git.Watch {
		t.Error("expected git watch to be enabled by default")
	}
}

func TestLoad_NoConfigFile(t *testing.T) {
	t.Parallel()
	cfg, err := Load("/nonexistent/path")
	if err != nil {
		t.Fatalf("loading from nonexistent path should not error: %v", err)
	}
	if cfg.Server.Port != 3456 {
		t.Errorf("expected defaults when no config file, got port %d", cfg.Server.Port)
	}
}

func TestLoad_ProjectConfig(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	harrierDir := filepath.Join(dir, ".harrier")
	os.MkdirAll(harrierDir, 0o755)

	configContent := `[server]
port = 9999
host = "0.0.0.0"

[memory]
hot_token_budget = 1600

[decay]
half_life_days = 60
`
	os.WriteFile(filepath.Join(harrierDir, "config.toml"), []byte(configContent), 0o644)

	cfg, err := Load(dir)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if cfg.Server.Port != 9999 {
		t.Errorf("expected port 9999 from project config, got %d", cfg.Server.Port)
	}
	if cfg.Server.Host != "0.0.0.0" {
		t.Errorf("expected host 0.0.0.0, got %s", cfg.Server.Host)
	}
	if cfg.Memory.HotTokenBudget != 1600 {
		t.Errorf("expected hot budget 1600, got %d", cfg.Memory.HotTokenBudget)
	}
	if cfg.Decay.HalfLifeDays != 60 {
		t.Errorf("expected half life 60, got %d", cfg.Decay.HalfLifeDays)
	}
}

func TestLoad_InvalidTOML(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	harrierDir := filepath.Join(dir, ".harrier")
	os.MkdirAll(harrierDir, 0o755)
	os.WriteFile(filepath.Join(harrierDir, "config.toml"), []byte("invalid [[[ toml"), 0o644)

	_, err := Load(dir)
	if err == nil {
		t.Error("expected error for invalid TOML")
	}
}
