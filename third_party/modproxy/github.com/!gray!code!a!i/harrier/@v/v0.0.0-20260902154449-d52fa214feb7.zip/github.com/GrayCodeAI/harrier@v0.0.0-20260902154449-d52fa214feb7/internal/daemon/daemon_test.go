package daemon

import (
	"errors"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func newIPv4Server(t *testing.T, h http.Handler) *httptest.Server {
	t.Helper()
	ln, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		if errors.Is(err, os.ErrPermission) || strings.Contains(err.Error(), "operation not permitted") {
			t.Skipf("sandbox does not allow local listeners: %v", err)
		}
		t.Fatalf("listen tcp4: %v", err)
	}
	srv := httptest.NewUnstartedServer(h)
	srv.Listener = ln
	srv.Start()
	return srv
}

func TestPIDFileRoundTrip(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	_ = os.MkdirAll(filepath.Join(dir, ".harrier"), 0o755)

	if err := WritePID(dir); err != nil {
		t.Fatalf("WritePID: %v", err)
	}

	pid := ReadPID(dir)
	if pid != os.Getpid() {
		t.Fatalf("expected PID %d, got %d", os.Getpid(), pid)
	}

	if !IsRunning(dir) {
		t.Fatal("expected IsRunning to be true for own PID")
	}

	RemovePID(dir)
	if ReadPID(dir) != 0 {
		t.Fatal("expected PID 0 after removal")
	}
}

func TestHealthCheck(t *testing.T) {
	t.Parallel()
	// Healthy server
	srv := newIPv4Server(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(200)
		w.Write([]byte(`{"status":"ok"}`))
	}))
	defer srv.Close()

	// Pass full URL so HealthCheck doesn't prepend localhost
	if err := HealthCheck(srv.URL); err != nil {
		t.Fatalf("expected healthy, got: %v", err)
	}

	// Unhealthy: nothing listening
	if err := HealthCheck(":19999"); err == nil {
		t.Fatal("expected error for non-existent server")
	}
}

func TestNormalizeAddr(t *testing.T) {
	t.Parallel()
	tests := []struct{ in, want string }{
		{":3456", ":3456"},
		{"3456", ":3456"},
		{"localhost:3456", ":localhost:3456"},
	}
	for _, tt := range tests {
		got := normalizeAddr(tt.in)
		if got != tt.want {
			t.Errorf("normalizeAddr(%q) = %q, want %q", tt.in, got, tt.want)
		}
	}
}
