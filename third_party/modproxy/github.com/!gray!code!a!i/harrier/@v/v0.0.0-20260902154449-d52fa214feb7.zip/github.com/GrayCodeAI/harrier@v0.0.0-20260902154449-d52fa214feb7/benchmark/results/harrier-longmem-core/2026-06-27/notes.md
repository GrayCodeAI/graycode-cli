# Provenance Notes

- Command:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/longmemreport --suite default'`
- Verification:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./internal/bench -count=1'`
- Environment:
  local workspace run on `2026-06-27`
- Caveats:
  first-party seeded benchmark harness, not yet LoCoMo/BEAM external dataset ingestion
  commit SHA was not persisted into the command output in this first baseline
