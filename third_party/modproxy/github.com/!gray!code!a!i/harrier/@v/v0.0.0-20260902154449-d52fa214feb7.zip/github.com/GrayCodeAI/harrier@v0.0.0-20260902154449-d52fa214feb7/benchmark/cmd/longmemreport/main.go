package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	bench "github.com/GrayCodeAI/harrier/internal/bench"
	"github.com/GrayCodeAI/harrier/storage"
)

func main() {
	var (
		depth = flag.Int("depth", 2, "recall depth")
		limit = flag.Int("limit", 10, "recall limit")
		suite = flag.String("suite", "default", "benchmark suite: default|coding")
	)
	flag.Parse()

	ctx := context.Background()
	dir := mustTempDir()
	dbPath := filepath.Join(dir, "longmem-core.db")

	store, err := storage.NewStore(dbPath)
	must(err)
	defer store.Close() //nolint:errcheck

	eng := engine.New(store, graph.New(store, store.DB()))
	defer eng.Close()

	must(seedBaseline(ctx, eng))

	var qas []bench.QA
	switch *suite {
	case "coding":
		qas = bench.CodingBenchQAs()
	default:
		qas = bench.DefaultQAs()
	}

	result := bench.Run(ctx, eng, qas, *depth, *limit)
	fmt.Printf("Suite: harrier-longmem-core (%s)\n", *suite)
	fmt.Printf("Depth: %d\n", *depth)
	fmt.Printf("Limit: %d\n", *limit)
	fmt.Printf("Timestamp: %s\n\n", time.Now().UTC().Format(time.RFC3339))
	fmt.Print(result.String())
}

func seedBaseline(ctx context.Context, eng *engine.Engine) error {
	memories := []engine.RememberInput{
		{Type: "convention", Content: "Use jose for JWT handling across the auth stack", Scope: "project", Project: "bench-project"},
		{Type: "task", Content: "Run tests with pnpm test --coverage before merge", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "Auth middleware bug: token refresh race can occur without a mutex", Scope: "project", Project: "bench-project"},
		{Type: "decision", Content: "We chose NATS for event bus reliability and backpressure support", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "Token refresh issue: mutex guards refresh rotation", Scope: "project", Project: "bench-project"},
		{Type: "spec", Content: "JWT algorithm for compliance is RS256", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "Database query performance bug fixed with DataLoader", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "NATS connection issue solved with keepalive tuning", Scope: "project", Project: "bench-project"},
		{Type: "spec", Content: "Auth subsystem spec uses jose and RS256 tokens", Scope: "project", Project: "bench-project"},
		{Type: "task", Content: "Rate limiting task is in progress on public endpoints", Scope: "project", Project: "bench-project"},
		{Type: "decision", Content: "We chose NATS because it offered simpler ops and better backpressure behavior", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "The token refresh race was caused by missing mutex protection", Scope: "project", Project: "bench-project"},
		{Type: "decision", Content: "The jose convention was adopted after Edge runtime compatibility issues", Scope: "project", Project: "bench-project"},
		{Type: "decision", Content: "The last architecture decision was to standardize on NATS", Scope: "project", Project: "bench-project"},
		{Type: "bug", Content: "Recent bug patterns in auth include refresh token races", Scope: "project", Project: "bench-project"},
		{Type: "preference", Content: "Testing framework preference is pnpm for JS and TS workspaces", Scope: "project", Project: "bench-project"},
		{Type: "convention", Content: "Coding conventions: use jose, named exports, and explicit validation", Scope: "project", Project: "bench-project"},
		{Type: "preference", Content: "TypeScript export style uses named exports only", Scope: "project", Project: "bench-project"},
		{Type: "task", Content: "Integration tests for auth are required before merge", Scope: "project", Project: "bench-project"},
		{Type: "spec", Content: "Access token expiry is 15min", Scope: "project", Project: "bench-project"},
		{Type: "spec", Content: "Refresh token duration is 7d", Scope: "project", Project: "bench-project"},
		{Type: "file", Content: "Auth middleware file location is auth.ts", Scope: "project", Project: "bench-project"},
		{Type: "task", Content: "Test coverage command is coverage via pnpm test --coverage", Scope: "project", Project: "bench-project"},
		{Type: "preference", Content: "Functional programming preference applies in TypeScript modules", Scope: "project", Project: "bench-project"},
	}

	for _, memory := range memories {
		if _, err := eng.Remember(ctx, memory); err != nil {
			return err
		}
	}
	return nil
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}

func mustTempDir() string {
	dir, err := os.MkdirTemp("", "harrier-longmem-core-*")
	must(err)
	return dir
}
