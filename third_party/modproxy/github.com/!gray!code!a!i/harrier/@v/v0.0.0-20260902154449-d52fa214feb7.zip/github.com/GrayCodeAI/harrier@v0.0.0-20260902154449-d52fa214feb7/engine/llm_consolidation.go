package engine

import (
	"context"
	"fmt"
	"log/slog"
	"sort"
	"strings"
	"unicode"

	"github.com/GrayCodeAI/harrier/storage"
)

// ConsolidationLLM is the interface callers must implement to provide LLM
// capabilities for semantic memory consolidation. This keeps harrier free of
// any direct LLM dependency.
type ConsolidationLLM interface {
	// SuggestMerge examines a cluster of related nodes and proposes a merge plan.
	SuggestMerge(ctx context.Context, nodes []*storage.Node) (*MergePlan, error)
	// Summarize produces a concise summary of a group of nodes.
	Summarize(ctx context.Context, nodes []*storage.Node) (string, error)
}

// MergePlan describes how a cluster of nodes should be merged into one.
type MergePlan struct {
	// NodeIDs lists the IDs of nodes to merge.
	NodeIDs []string `json:"node_ids"`
	// NewContent is the unified content replacing the merged nodes.
	NewContent string `json:"new_content"`
	// NewSummary is a short summary of the merged content.
	NewSummary string `json:"new_summary"`
	// NewKey is the key for the resulting consolidated node.
	NewKey string `json:"new_key"`
	// NewType is the node type for the consolidated node.
	NewType string `json:"new_type"`
}

// LLMConsolidationConfig holds tuning knobs for the LLM consolidator.
type LLMConsolidationConfig struct {
	// Enabled turns the consolidator on/off.
	Enabled bool `json:"enabled"`
	// MinClusterSize is the minimum number of nodes in a candidate cluster.
	MinClusterSize int `json:"min_cluster_size"`
	// MaxBatchSize caps how many nodes are sent to the LLM in a single call.
	MaxBatchSize int `json:"max_batch_size"`
	// KeySimilarityThreshold (0-1) controls how similar keys must be to
	// group nodes together. 0.5 means at least 50% token overlap.
	KeySimilarityThreshold float64 `json:"key_similarity_threshold"`
	// ContentKeywordThreshold (0-1) controls keyword overlap required.
	ContentKeywordThreshold float64 `json:"content_keyword_threshold"`
	// EdgeCrossRefThreshold is the minimum number of shared edges between
	// two nodes to consider them candidates.
	EdgeCrossRefThreshold int `json:"edge_cross_ref_threshold"`
	// DryRun when true causes Consolidate to return merge plans without
	// modifying storage.
	DryRun bool `json:"dry_run"`
}

// DefaultLLMConsolidationConfig returns production-tuned defaults.
func DefaultLLMConsolidationConfig() LLMConsolidationConfig {
	return LLMConsolidationConfig{
		Enabled:                 true,
		MinClusterSize:          2,
		MaxBatchSize:            20,
		KeySimilarityThreshold:  0.5,
		ContentKeywordThreshold: 0.3,
		EdgeCrossRefThreshold:   1,
		DryRun:                  false,
	}
}

// LLMConsolidator uses an LLM to find semantically duplicate or closely
// related memory nodes and merge them, reducing graph noise.
type LLMConsolidator struct {
	config LLMConsolidationConfig
	store  storage.Storage
	llm    ConsolidationLLM
}

// NewLLMConsolidator creates an LLM-backed consolidator.
func NewLLMConsolidator(store storage.Storage, llm ConsolidationLLM, config LLMConsolidationConfig) *LLMConsolidator {
	return &LLMConsolidator{config: config, store: store, llm: llm}
}

// CandidateCluster is a group of nodes that are potential merge candidates.
type CandidateCluster struct {
	Nodes   []*storage.Node
	Score   float64  // combined similarity score
	Reasons []string // human-readable reasons for clustering
}

// FindCandidateClusters scans all nodes of a project and groups them by
// type+project, then refines by key similarity, content keyword overlap,
// and cross-reference density.
func (lc *LLMConsolidator) FindCandidateClusters(ctx context.Context, project string) ([]*CandidateCluster, error) {
	if !lc.config.Enabled {
		return nil, nil
	}

	nodes, err := lc.store.ListNodes(ctx, storage.NodeFilter{
		Project: project,
		Limit:   2000,
	})
	if err != nil {
		return nil, fmt.Errorf("list nodes: %w", err)
	}
	if len(nodes) < lc.config.MinClusterSize {
		return nil, nil
	}

	// Step 1: Group by (type, project) to reduce pairwise comparisons.
	typeGroups := make(map[string][]*storage.Node)
	for _, n := range nodes {
		key := n.Type + ":" + n.Project
		typeGroups[key] = append(typeGroups[key], n)
	}

	// Step 2: Build edge-count map for cross-reference scoring.
	edgeCounts, err := lc.buildEdgeCountMap(ctx, nodes)
	if err != nil {
		return nil, fmt.Errorf("build edge counts: %w", err)
	}

	// Step 3: Within each type group, cluster by similarity.
	var clusters []*CandidateCluster
	for _, group := range typeGroups {
		if len(group) < lc.config.MinClusterSize {
			continue
		}
		groupClusters := lc.clusterBySimilarity(group, edgeCounts)
		clusters = append(clusters, groupClusters...)
	}

	// Sort by score descending (best merge candidates first).
	sort.Slice(clusters, func(i, j int) bool {
		return clusters[i].Score > clusters[j].Score
	})

	return clusters, nil
}

// ConsolidateResult holds the outcome of a consolidation run.
type ConsolidateResult struct {
	Plans   []*MergePlan
	Applied int
	Skipped int
	DryRun  bool
}

// Consolidate finds candidate clusters, asks the LLM for merge suggestions,
// and applies the plans to storage. If DryRun is set in the config, it
// returns merge plans without modifying anything.
func (lc *LLMConsolidator) Consolidate(ctx context.Context, project string) (*ConsolidateResult, error) {
	clusters, err := lc.FindCandidateClusters(ctx, project)
	if err != nil {
		return nil, fmt.Errorf("find candidates: %w", err)
	}

	result := &ConsolidateResult{DryRun: lc.config.DryRun}

	for _, cluster := range clusters {
		if ctx.Err() != nil {
			return result, ctx.Err()
		}

		// Respect max batch size.
		nodes := cluster.Nodes
		if len(nodes) > lc.config.MaxBatchSize {
			nodes = nodes[:lc.config.MaxBatchSize]
		}

		plan, err := lc.llm.SuggestMerge(ctx, nodes)
		if err != nil {
			// Log but continue with other clusters.
			result.Skipped++
			continue
		}
		if plan == nil || len(plan.NodeIDs) < 2 {
			result.Skipped++
			continue
		}

		result.Plans = append(result.Plans, plan)

		if !lc.config.DryRun {
			if err := lc.applyMergePlan(ctx, plan); err != nil {
				result.Skipped++
				continue
			}
			result.Applied++
		}
	}

	return result, nil
}

// applyMergePlan executes a single merge plan: creates the consolidated node,
// re-edges it, saves versions for audit, and deletes the old nodes.
func (lc *LLMConsolidator) applyMergePlan(ctx context.Context, plan *MergePlan) error {
	if len(plan.NodeIDs) < 2 {
		return fmt.Errorf("merge plan needs at least 2 nodes")
	}

	// Determine project and type from the first node.
	first, err := lc.store.GetNode(ctx, plan.NodeIDs[0])
	if err != nil {
		return fmt.Errorf("get node %s: %w", plan.NodeIDs[0], err)
	}

	mergedType := plan.NewType
	if mergedType == "" {
		mergedType = first.Type
	}
	mergedKey := plan.NewKey
	if mergedKey == "" {
		mergedKey = first.Key
	}

	// Save versions of all source nodes before modifying them.
	for _, nid := range plan.NodeIDs {
		n, err := lc.store.GetNode(ctx, nid)
		if err != nil {
			continue
		}
		_ = lc.store.SaveVersion(ctx, nid, n.Content, "llm-consolidator", "pre-merge snapshot")
	}

	// Create the merged node.
	merged := &storage.Node{
		Type:        mergedType,
		Content:     plan.NewContent,
		Summary:     plan.NewSummary,
		Key:         mergedKey,
		Project:     first.Project,
		Scope:       first.Scope,
		Tier:        first.Tier,
		Confidence:  first.Confidence,
		SourceAgent: "llm-consolidator",
	}
	if err := lc.store.CreateNode(ctx, merged); err != nil {
		return fmt.Errorf("create merged node: %w", err)
	}

	// Redirect all edges from old nodes to the merged node.
	if err := lc.redirectEdges(ctx, plan.NodeIDs, merged.ID); err != nil {
		return fmt.Errorf("redirect edges: %w", err)
	}

	// Delete the old nodes.
	for _, nid := range plan.NodeIDs {
		if err := lc.store.DeleteNode(ctx, nid); err != nil {
			// Best-effort delete; log but don't fail.
			slog.Warn("llm-consolidation: failed to delete merged-away node", "node_id", nid, "error", err)
		}
	}

	return nil
}

// redirectEdges rewires all edges involving oldIDs to point at newID instead.
func (lc *LLMConsolidator) redirectEdges(ctx context.Context, oldIDs []string, newID string) error {
	edges, err := lc.store.GetAllEdgesFor(ctx, oldIDs)
	if err != nil {
		return err
	}

	oldSet := make(map[string]bool, len(oldIDs))
	for _, id := range oldIDs {
		oldSet[id] = true
	}

	for _, e := range edges {
		// Skip edges between nodes being merged (they'll be deleted).
		if oldSet[e.FromID] && oldSet[e.ToID] {
			continue
		}

		newFrom := e.FromID
		newTo := e.ToID
		if oldSet[e.FromID] {
			newFrom = newID
		}
		if oldSet[e.ToID] {
			newTo = newID
		}

		// Create the redirected edge.
		redirected := &storage.Edge{
			FromID:   newFrom,
			ToID:     newTo,
			Type:     e.Type,
			Metadata: e.Metadata,
			Weight:   e.Weight,
		}
		_ = lc.store.CreateEdge(ctx, redirected)

		// Delete the old edge.
		_ = lc.store.DeleteEdge(ctx, e.ID)
	}

	return nil
}

// --- clustering helpers ---

// clusterBySimilarity performs pairwise similarity analysis within a type group
// and uses union-find to build clusters.
func (lc *LLMConsolidator) clusterBySimilarity(
	nodes []*storage.Node,
	edgeCounts map[string]map[string]int,
) []*CandidateCluster {
	n := len(nodes)
	uf := newUnionFind(n)
	reasons := make([][]string, n*n) // flat 2D for [i][j]

	for i := 0; i < n; i++ {
		for j := i + 1; j < n; j++ {
			var totalScore float64
			var clusterReasons []string

			// Key similarity (token-based Jaccard).
			keySim := tokenJaccard(nodes[i].Key, nodes[j].Key)
			if keySim >= lc.config.KeySimilarityThreshold {
				totalScore += keySim * 2 // keys are strong signal
				clusterReasons = append(clusterReasons, fmt.Sprintf("key_similarity=%.2f", keySim))
			}

			// Content keyword overlap.
			kwI := extractKeywords(nodes[i].Content + " " + nodes[i].Summary)
			kwJ := extractKeywords(nodes[j].Content + " " + nodes[j].Summary)
			kwOverlap := keywordOverlap(kwI, kwJ)
			if kwOverlap >= lc.config.ContentKeywordThreshold {
				totalScore += kwOverlap
				clusterReasons = append(clusterReasons, fmt.Sprintf("content_overlap=%.2f", kwOverlap))
			}

			// Cross-reference edge density.
			ec := edgeCounts[nodes[i].ID]
			if ec == nil {
				ec = make(map[string]int)
			}
			sharedEdges := ec[nodes[j].ID]
			if sharedEdges >= lc.config.EdgeCrossRefThreshold {
				totalScore += float64(sharedEdges) * 0.5
				clusterReasons = append(clusterReasons, fmt.Sprintf("shared_edges=%d", sharedEdges))
			}

			// Require at least one signal.
			if totalScore > 0 && len(clusterReasons) > 0 {
				uf.union(i, j)
				reasons[i*n+j] = clusterReasons
			}
		}
	}

	groups := uf.groups()
	var clusters []*CandidateCluster
	for _, members := range groups {
		if len(members) < lc.config.MinClusterSize {
			continue
		}

		clusterNodes := make([]*storage.Node, len(members))
		for i, idx := range members {
			clusterNodes[i] = nodes[idx]
		}

		// Compute average score for the cluster.
		totalScore := 0.0
		pairs := 0
		var allReasons []string
		seen := make(map[string]bool)
		for i := 0; i < len(members); i++ {
			for j := i + 1; j < len(members); j++ {
				idx := members[i]*n + members[j]
				for _, r := range reasons[idx] {
					totalScore += 1.0
					if !seen[r] {
						allReasons = append(allReasons, r)
						seen[r] = true
					}
				}
				pairs++
			}
		}
		avgScore := 0.0
		if pairs > 0 {
			avgScore = totalScore / float64(pairs)
		}

		clusters = append(clusters, &CandidateCluster{
			Nodes:   clusterNodes,
			Score:   avgScore,
			Reasons: allReasons,
		})
	}

	return clusters
}

// buildEdgeCountMap returns a map: nodeID -> (otherNodeID -> count of shared edges).
func (lc *LLMConsolidator) buildEdgeCountMap(
	ctx context.Context,
	nodes []*storage.Node,
) (map[string]map[string]int, error) {
	ids := make([]string, len(nodes))
	for i, n := range nodes {
		ids[i] = n.ID
	}

	edges, err := lc.store.GetAllEdgesFor(ctx, ids)
	if err != nil {
		return nil, err
	}

	counts := make(map[string]map[string]int)
	for _, e := range edges {
		if counts[e.FromID] == nil {
			counts[e.FromID] = make(map[string]int)
		}
		counts[e.FromID][e.ToID]++

		// Also count in reverse for undirected-like queries.
		if counts[e.ToID] == nil {
			counts[e.ToID] = make(map[string]int)
		}
		counts[e.ToID][e.FromID]++
	}

	return counts, nil
}

// --- string similarity helpers ---

// tokenJaccard computes Jaccard similarity over whitespace-delimited tokens.
func tokenJaccard(a, b string) float64 {
	tokA := splitTokens(a)
	tokB := splitTokens(b)
	if len(tokA) == 0 && len(tokB) == 0 {
		return 1.0 // both empty = identical
	}
	if len(tokA) == 0 || len(tokB) == 0 {
		return 0
	}
	intersect := 0
	setB := make(map[string]bool, len(tokB))
	for _, t := range tokB {
		setB[t] = true
	}
	for _, t := range tokA {
		if setB[t] {
			intersect++
		}
	}
	union := len(tokA) + len(tokB) - intersect
	if union == 0 {
		return 0
	}
	return float64(intersect) / float64(union)
}

// splitTokens lowercases and splits on non-alphanumeric boundaries.
func splitTokens(s string) []string {
	s = strings.ToLower(s)
	var tokens []string
	var buf strings.Builder
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			buf.WriteRune(r)
		} else if buf.Len() > 0 {
			tokens = append(tokens, buf.String())
			buf.Reset()
		}
	}
	if buf.Len() > 0 {
		tokens = append(tokens, buf.String())
	}
	return tokens
}

// extractKeywords returns meaningful tokens from text (length > 3, not stop words).
func extractKeywords(text string) map[string]bool {
	kw := make(map[string]bool)
	for _, w := range splitTokens(text) {
		if len(w) > 3 && !isStopWord(w) {
			kw[w] = true
		}
	}
	return kw
}

// isStopWord is a minimal stop-word check for clustering.
func isStopWord(w string) bool {
	stop := map[string]bool{
		"this": true, "that": true, "with": true, "from": true,
		"have": true, "been": true, "were": true, "they": true,
		"will": true, "would": true, "could": true, "should": true,
		"about": true, "which": true, "their": true, "there": true,
		"then": true, "than": true, "when": true, "what": true,
		"some": true, "more": true, "also": true, "into": true,
		"only": true, "very": true, "just": true, "each": true,
		"most": true, "used": true, "using": true, "does": true,
	}
	return stop[w]
}

// levenshtein computes the edit distance between two strings.
// Exported for potential external use.
func levenshtein(a, b string) int {
	la := len(a)
	lb := len(b)
	if la == 0 {
		return lb
	}
	if lb == 0 {
		return la
	}
	prev := make([]int, lb+1)
	curr := make([]int, lb+1)
	for j := 0; j <= lb; j++ {
		prev[j] = j
	}
	for i := 1; i <= la; i++ {
		curr[0] = i
		for j := 1; j <= lb; j++ {
			cost := 1
			if a[i-1] == b[j-1] {
				cost = 0
			}
			curr[j] = min3(curr[j-1]+1, prev[j]+1, prev[j-1]+cost)
		}
		prev, curr = curr, prev
	}
	return prev[lb]
}

func min3(a, b, c int) int {
	if a < b {
		if a < c {
			return a
		}
		return c
	}
	if b < c {
		return b
	}
	return c
}
