package engine

import (
	"context"
	"math"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// ScoredMemory is a memory node with an explicit confidence score reflecting
// how reliable/relevant the memory is for the given context.
type ScoredMemory struct {
	Node       *storage.Node `json:"node"`
	Confidence float64       `json:"confidence"` // [0, 1] composite confidence
	Recency    float64       `json:"recency"`    // [0, 1] recency factor
	Centrality float64       `json:"centrality"` // [0, 1] graph centrality factor
	Trust      float64       `json:"trust"`      // [0, 1] base node confidence
}

// ScoredRecallResult extends RecallResult with per-node confidence scores.
type ScoredRecallResult struct {
	Nodes []*ScoredMemory `json:"nodes"`
	Edges []*storage.Edge `json:"edges,omitempty"`
	Count int             `json:"count"`
	Query string          `json:"query,omitempty"`
}

// RecallWithConfidence performs recall and computes explicit confidence scores
// for each returned memory. The composite confidence combines:
//   - Trust: the node's stored confidence (from feedback, decay, etc.)
//   - Recency: exponential decay based on last access/update
//   - Centrality: graph connectivity (more connections = more trustworthy)
//   - Retrieval rank: how highly the memory scored in retrieval
func (e *Engine) RecallWithConfidence(ctx context.Context, opts RecallOpts) (*ScoredRecallResult, error) {
	result, err := e.Recall(ctx, opts)
	if err != nil {
		return nil, err
	}

	now := time.Now()
	ids := make([]string, len(result.Nodes))
	for i, n := range result.Nodes {
		ids[i] = n.ID
	}

	// Batch-fetch edge counts for centrality
	edgeCounts, _ := e.store.CountEdgesBatch(ctx, ids)

	scored := make([]*ScoredMemory, len(result.Nodes))
	for i, n := range result.Nodes {
		trust := n.Confidence
		recency := computeRecency(n, now)
		centrality := computeCentrality(n.ID, edgeCounts)

		// Composite confidence: weighted combination
		composite := 0.5*trust + 0.3*recency + 0.2*centrality
		composite = math.Min(math.Max(composite, 0), 1)

		scored[i] = &ScoredMemory{
			Node:       n,
			Confidence: composite,
			Recency:    recency,
			Centrality: centrality,
			Trust:      trust,
		}
	}

	return &ScoredRecallResult{
		Nodes: scored,
		Edges: result.Edges,
		Count: len(scored),
		Query: opts.Query,
	}, nil
}

// computeRecency returns a [0, 1] score based on how recently the node was accessed.
// Uses exponential decay with a 30-day half-life.
func computeRecency(n *storage.Node, now time.Time) float64 {
	ref := n.AccessedAt
	if ref.IsZero() {
		ref = n.UpdatedAt
	}
	if ref.IsZero() {
		return 0.5 // unknown age, neutral score
	}
	days := now.Sub(ref).Hours() / 24
	if days <= 0 {
		return 1.0
	}
	return math.Exp(-days * math.Ln2 / 30.0)
}

// computeCentrality returns a [0, 1] score based on graph connectivity.
// Nodes with more edges are considered more central/important.
func computeCentrality(nodeID string, edgeCounts map[string][2]int) float64 {
	ec, ok := edgeCounts[nodeID]
	if !ok {
		return 0.1 // no edge info, low default
	}
	total := ec[0] + ec[1] // inbound + outbound
	// Saturating function: 5+ edges → ~1.0
	return 1.0 - math.Exp(-float64(total)*0.3)
}
