package engine

import (
	"sync"

	tiktoken "github.com/tiktoken-go/tokenizer"
)

var (
	tokenizerOnce sync.Once
	tokenizerBPE  tiktoken.Codec
	tokenizerErr  error
)

func estimateTokens(content string) int {
	if content == "" {
		return 0
	}

	tokenizerOnce.Do(func() {
		tokenizerBPE, tokenizerErr = tiktoken.Get(tiktoken.Cl100kBase)
	})
	if tokenizerErr == nil && tokenizerBPE != nil {
		if count, err := tokenizerBPE.Count(content); err == nil {
			return count
		}
	}

	return fallbackTokenCount(content)
}

func fallbackTokenCount(content string) int {
	length := len(content)
	if length < 30 {
		return (length + 2) / 3
	}
	if length < 100 {
		return (length + 3) / 4
	}

	spaces := 0
	sample := length
	if sample > 200 {
		sample = 200
	}
	for i := 0; i < sample; i++ {
		switch content[i] {
		case ' ', '\n', '\t', '\r':
			spaces++
		}
	}

	spaceRatio := float64(spaces) / float64(sample)
	nonSpaceChars := float64(length) * (1 - spaceRatio)
	spaceTokens := float64(length) * spaceRatio
	return int(nonSpaceChars/3.5 + spaceTokens)
}
