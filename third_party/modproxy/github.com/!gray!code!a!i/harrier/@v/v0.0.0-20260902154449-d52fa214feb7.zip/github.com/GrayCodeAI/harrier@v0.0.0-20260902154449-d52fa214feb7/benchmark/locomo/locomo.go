// Package locomo adapts the public LoCoMo-10 long-term conversational
// memory benchmark (snap-research/locomo) into internal/bench's QA harness,
// so harrier's retrieval quality can be measured against a standard external
// corpus rather than only the first-party self-seeded QA set in
// internal/bench.go's DefaultQAs/CodingBenchQAs.
//
// This package only adapts data — it does not modify internal/bench, whose
// Run/QA/Result types are reused as-is.
package locomo

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
)

// DatasetURL is the public LoCoMo-10 dataset file. Exported so callers (the
// locomobench command) can override it, e.g. to point at a local mirror.
const DatasetURL = "https://raw.githubusercontent.com/snap-research/locomo/main/data/locomo10.json"

// categoryAdversarial is LoCoMo's "unanswerable" question category: these
// QAs have no "answer" field (only "adversarial_answer", the real-world
// context explaining why the question can't be answered from the
// conversation) and are excluded by ToQAs — a substring-match retrieval-hit
// harness has no way to score "the model correctly recalled nothing."
const categoryAdversarial = 5

// Turn is a single dialogue line within a session.
type Turn struct {
	Speaker string `json:"speaker"`
	DiaID   string `json:"dia_id"`
	Text    string `json:"text"`
}

// QAPair is one question/answer/evidence entry from a LoCoMo sample.
type QAPair struct {
	Question string   `json:"question"`
	Answer   any      `json:"answer"` // string or number depending on the question; see AnswerText
	Evidence []string `json:"evidence"`
	Category int      `json:"category"`
}

// AnswerText renders Answer as a string regardless of its underlying JSON
// type (LoCoMo mixes string and numeric answers, e.g. ages).
func (q QAPair) AnswerText() string {
	switch v := q.Answer.(type) {
	case string:
		return v
	case nil:
		return ""
	default:
		return fmt.Sprint(v)
	}
}

// Sample is one LoCoMo conversation: up to ~35 sessions between two
// speakers, plus QA pairs whose evidence cites specific dialogue turns.
// Conversation is left as a raw map because session keys are numbered
// ("session_1", "session_1_date_time", "session_2", ...) rather than a
// fixed schema — Sessions() below extracts them in order.
type Sample struct {
	SampleID     string         `json:"sample_id"`
	QA           []QAPair       `json:"qa"`
	Conversation map[string]any `json:"conversation"`
}

// Session is one numbered session's turns plus its date/time label.
type Session struct {
	Number   int
	DateTime string
	Turns    []Turn
}

// Sessions extracts s.Conversation's numbered sessions in order. LoCoMo
// samples have a variable number of sessions (not fixed across samples), so
// this scans session_1..session_N until a number is missing rather than
// assuming a fixed count.
func (s Sample) Sessions() []Session {
	var sessions []Session
	for n := 1; ; n++ {
		key := fmt.Sprintf("session_%d", n)
		raw, ok := s.Conversation[key]
		if !ok {
			break
		}
		data, err := json.Marshal(raw)
		if err != nil {
			break
		}
		var turns []Turn
		if err := json.Unmarshal(data, &turns); err != nil {
			break
		}
		dateTime, _ := s.Conversation[key+"_date_time"].(string)
		sessions = append(sessions, Session{Number: n, DateTime: dateTime, Turns: turns})
	}
	return sessions
}

// Load parses a local LoCoMo-10 JSON file (as saved by Download).
func Load(path string) ([]Sample, error) {
	f, err := os.Open(path) //nolint:gosec // path is operator-supplied (CLI flag / test fixture), not untrusted input
	if err != nil {
		return nil, fmt.Errorf("locomo: open %s: %w", path, err)
	}
	defer func() { _ = f.Close() }()
	return Parse(f)
}

// Parse decodes a LoCoMo-10 dataset from r.
func Parse(r io.Reader) ([]Sample, error) {
	var samples []Sample
	if err := json.NewDecoder(r).Decode(&samples); err != nil {
		return nil, fmt.Errorf("locomo: decode dataset: %w", err)
	}
	return samples, nil
}

// Download fetches url (typically DatasetURL) and saves it to destPath,
// so a benchmark run doesn't depend on network access at eval time and the
// downloaded copy can be inspected/reused.
func Download(url, destPath string) error {
	req, err := http.NewRequest(http.MethodGet, url, nil) //nolint:noctx // one-shot CLI download, no cancellation needed
	if err != nil {
		return fmt.Errorf("locomo: build request: %w", err)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return fmt.Errorf("locomo: download %s: %w", url, err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("locomo: download %s: unexpected status %d", url, resp.StatusCode)
	}

	out, err := os.Create(destPath) //nolint:gosec // destPath is operator-supplied (CLI flag), not untrusted input
	if err != nil {
		return fmt.Errorf("locomo: create %s: %w", destPath, err)
	}
	defer func() { _ = out.Close() }()
	if _, err := io.Copy(out, resp.Body); err != nil { //nolint:gosec // dataset size is bounded (a few MB); no DoS concern for a manually-invoked benchmark CLI
		return fmt.Errorf("locomo: write %s: %w", destPath, err)
	}
	return nil
}
