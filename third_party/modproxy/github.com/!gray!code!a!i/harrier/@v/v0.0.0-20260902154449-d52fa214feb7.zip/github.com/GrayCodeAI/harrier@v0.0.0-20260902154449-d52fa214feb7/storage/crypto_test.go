package storage

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"testing"
)

type constKeyProvider struct {
	key     []byte
	version int
}

func (p *constKeyProvider) KeyBytes(version int) ([]byte, error) {
	if version != p.version {
		return nil, ErrUnknownKeyVersion
	}
	return p.key, nil
}

func (p *constKeyProvider) CurrentVersion() int { return p.version }

func newTestCipher(t *testing.T, v int) *NodeCipher {
	t.Helper()
	c, err := NewNodeCipher(&constKeyProvider{key: []byte("unit-test-master-key-material-32b"), version: v})
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestNodeCipherRoundTrip(t *testing.T) {
	c := newTestCipher(t, 0)

	plain := "convention: always run make lint before opening a PR"
	enc, err := c.Encrypt(plain)
	if err != nil {
		t.Fatal(err)
	}
	if !IsEncryptedValue(enc) {
		t.Fatalf("ciphertext missing prefix: %q", enc)
	}
	if strings.Contains(enc, plain) {
		t.Fatal("plaintext leaked into ciphertext")
	}
	enc2, err := c.Encrypt(plain)
	if err != nil {
		t.Fatal(err)
	}
	if enc == enc2 {
		t.Fatal("deterministic ciphertext: nonce must randomize")
	}
	dec, err := c.Decrypt(enc)
	if err != nil {
		t.Fatal(err)
	}
	if dec != plain {
		t.Fatalf("round trip: got %q", dec)
	}
}

func TestNodeCipherPassthrough(t *testing.T) {
	c := newTestCipher(t, 0)

	got, err := c.Decrypt("legacy plaintext content")
	if err != nil {
		t.Fatal(err)
	}
	if got != "legacy plaintext content" {
		t.Fatalf("plaintext passthrough failed: %q", got)
	}

	if enc, err := c.Encrypt(""); err != nil || enc != "" {
		t.Fatalf("empty plaintext should pass through: %q, %v", enc, err)
	}
}

func TestNodeCipherTamper(t *testing.T) {
	c := newTestCipher(t, 0)
	enc, err := c.Encrypt("sensitive")
	if err != nil {
		t.Fatal(err)
	}
	// Flip one character in the base64 payload (GCM auth must reject it).
	i := len(enc) - 5
	tampered := enc[:i] + "A" + enc[i+1:]
	if _, err := c.Decrypt(tampered); !errors.Is(err, ErrDecryptionFailed) {
		t.Fatalf("expected ErrDecryptionFailed, got %v", err)
	}
}

func TestNodeCipherVersionBinding(t *testing.T) {
	c0 := newTestCipher(t, 0)
	// c0b uses DIFFERENT key material for the same version 0 — a wrong key
	// must fail authentication, and relabeling the version must too.
	c0b, err := NewNodeCipher(&constKeyProvider{key: []byte("different-key-material-32-bytes!!"), version: 0})
	if err != nil {
		t.Fatal(err)
	}

	enc0, err := c0.Encrypt("secret v0")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := c0b.Decrypt(enc0); !errors.Is(err, ErrDecryptionFailed) {
		t.Fatalf("wrong-key decryption must fail, got %v", err)
	}
}

func TestNodeCipherRelabeledVersionRejected(t *testing.T) {
	c0 := newTestCipher(t, 0)
	enc, err := c0.Encrypt("bind the version")
	if err != nil {
		t.Fatal(err)
	}
	relabeled := strings.Replace(enc, CipherScheme+"0.", CipherScheme+"1.", 1)
	if _, err := c0.Decrypt(relabeled); !errors.Is(err, ErrUnknownKeyVersion) {
		t.Fatalf("relabeled ciphertext must be rejected (unknown version), got %v", err)
	}
}

func TestNewNodeCipherEagerValidation(t *testing.T) {
	t.Setenv("HARRIER_TEST_MISSING_KEY", "")
	if _, err := NewNodeCipher(NewEnvKeyProvider("HARRIER_TEST_MISSING_KEY")); !errors.Is(err, ErrKeyMaterial) {
		t.Fatalf("expected ErrKeyMaterial for unset env var, got %v", err)
	}
}

func TestEnvKeyProvider(t *testing.T) {
	t.Setenv("HARRIER_TEST_KEY", "env-provided-key-material-at-least-32-bytes!")
	p := NewEnvKeyProvider("HARRIER_TEST_KEY")
	if p.CurrentVersion() != 0 {
		t.Fatalf("env provider version: %d", p.CurrentVersion())
	}
	b, err := p.KeyBytes(0)
	if err != nil || string(b) != "env-provided-key-material-at-least-32-bytes!" {
		t.Fatalf("KeyBytes(0) = %q, %v", b, err)
	}
	if _, err := p.KeyBytes(1); !errors.Is(err, ErrUnknownKeyVersion) {
		t.Fatalf("KeyBytes(1) should be unknown version, got %v", err)
	}

	c, err := NewNodeCipher(p)
	if err != nil {
		t.Fatal(err)
	}
	enc, err := c.Encrypt("from env")
	if err != nil {
		t.Fatal(err)
	}
	dec, err := c.Decrypt(enc)
	if err != nil || dec != "from env" {
		t.Fatalf("env-key round trip: %q, %v", dec, err)
	}
}

// TestEnvKeyProviderKeyPolicy covers the accepted key formats and the
// rejection of weak material: HKDF would stretch any input to 32 bytes, but a
// short password retains only the password's entropy and must be refused.
func TestEnvKeyProviderKeyPolicy(t *testing.T) {
	raw32 := "0123456789abcdef0123456789abcdef" // exactly 32 bytes
	p := NewEnvKeyProvider("HARRIER_TEST_KEY")

	t.Setenv("HARRIER_TEST_KEY", raw32)
	b, err := p.KeyBytes(0)
	if err != nil || string(b) != raw32 {
		t.Fatalf("raw 32-byte key rejected: %q, %v", b, err)
	}

	key32 := make([]byte, 32)
	for i := range key32 {
		key32[i] = byte(i)
	}
	// Encoded 32-byte keys are 43+ (base64) or 64 (hex) characters, so the
	// documented "raw wins if ambiguous" tie-break applies: they are used as
	// raw material rather than decoded.
	for name, encoded := range map[string]string{
		"base64":    base64.StdEncoding.EncodeToString(key32),
		"base64url": base64.RawURLEncoding.EncodeToString(key32),
		"hex":       hex.EncodeToString(key32),
	} {
		t.Setenv("HARRIER_TEST_KEY", encoded)
		b, err := p.KeyBytes(0)
		if err != nil || !bytes.Equal(b, []byte(encoded)) {
			t.Fatalf("%s-encoded key (len %d) should be used raw: %v", name, len(encoded), err)
		}
	}

	for _, weak := range []string{
		"short",                         // far too short
		"0123456789abcdef0123456789abc", // 31 bytes: one short of the raw policy
		"Y2FyaXR5MTZieXRlcw==",          // valid base64, but decodes to 16 bytes
		"0011223344556677",              // valid hex, but decodes to 8 bytes
	} {
		t.Setenv("HARRIER_TEST_KEY", weak)
		_, err := p.KeyBytes(0)
		if !errors.Is(err, ErrKeyMaterial) {
			t.Errorf("weak key %q accepted, want ErrKeyMaterial", weak)
		} else if !strings.Contains(err.Error(), "HARRIER_TEST_KEY") {
			t.Errorf("error should name the env var: %v", err)
		}
	}
}

// TestStoreEncryptionRoundTrip covers the full storage path: writes encrypt,
// reads decrypt, and the bookkeeping columns carry the right flags.
func TestStoreEncryptionRoundTrip(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.EnableEncryption(&constKeyProvider{key: []byte("store-round-trip-key-material!!"), version: 0}); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	n := &Node{
		ID: "enc-1", Type: "convention", Content: "encrypt me at rest",
		Summary: "summary too", ContentHash: "h-enc-1", Scope: "project", Project: "test",
		Key: "enc-key-1",
	}
	if err := s.CreateNode(ctx, n); err != nil {
		t.Fatal(err)
	}

	got, err := s.GetNode(ctx, "enc-1")
	if err != nil {
		t.Fatal(err)
	}
	if got.Content != "encrypt me at rest" || got.Summary != "summary too" {
		t.Fatalf("API returned wrong plaintext: %q / %q", got.Content, got.Summary)
	}

	// At rest: raw content must be ciphertext with the bookkeeping set.
	var rawContent, rawSummary string
	var encrypted bool
	var keyVersion int
	err = s.DB().QueryRowContext(ctx,
		`SELECT content, summary, encrypted, encryption_key_version FROM nodes WHERE id=?`, "enc-1").
		Scan(&rawContent, &rawSummary, &encrypted, &keyVersion)
	if err != nil {
		t.Fatal(err)
	}
	if !IsEncryptedValue(rawContent) || !IsEncryptedValue(rawSummary) {
		t.Fatalf("at-rest values not encrypted: %q / %q", rawContent, rawSummary)
	}
	if strings.Contains(rawContent, "encrypt me at rest") {
		t.Fatal("plaintext visible at rest")
	}
	if !encrypted || keyVersion != 0 {
		t.Fatalf("bookkeeping wrong: encrypted=%v keyVersion=%d", encrypted, keyVersion)
	}

	// Other readers decrypt too.
	list, err := s.ListNodes(ctx, NodeFilter{Type: "convention"})
	if err != nil || len(list) != 1 || list[0].Content != "encrypt me at rest" {
		t.Fatalf("ListNodes decrypt failed: %v, %+v", err, list)
	}
	byKey, err := s.GetNodeByKey(ctx, "enc-key-1", "test")
	if err != nil || byKey == nil || byKey.Content != "encrypt me at rest" {
		t.Fatalf("GetNodeByKey decrypt failed: %v, %+v", err, byKey)
	}
	batch, err := s.GetNodesBatch(ctx, []string{"enc-1"})
	if err != nil || len(batch) != 1 || batch[0].Content != "encrypt me at rest" {
		t.Fatalf("GetNodesBatch decrypt failed: %v", err)
	}

	// Updates re-encrypt.
	got.Content = "updated plaintext"
	if err := s.UpdateNode(ctx, got); err != nil {
		t.Fatal(err)
	}
	var raw2 string
	if err := s.DB().QueryRowContext(ctx, `SELECT content FROM nodes WHERE id=?`, "enc-1").Scan(&raw2); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(raw2, "updated plaintext") {
		t.Fatal("update stored plaintext at rest")
	}
	got2, err := s.GetNode(ctx, "enc-1")
	if err != nil || got2.Content != "updated plaintext" {
		t.Fatalf("read after update: %v, %q", err, got2.Content)
	}

	if err := s.UpdateNodeContent(ctx, "enc-1", "content-only update"); err != nil {
		t.Fatal(err)
	}
	got3, err := s.GetNode(ctx, "enc-1")
	if err != nil || got3.Content != "content-only update" {
		t.Fatalf("read after UpdateNodeContent: %v, %q", err, got3.Content)
	}

	// Version history encrypts and decrypts.
	if err := s.SaveVersion(ctx, "enc-1", "historical plaintext", "test", "v1"); err != nil {
		t.Fatal(err)
	}
	vers, err := s.GetVersions(ctx, "enc-1")
	if err != nil || len(vers) != 1 || vers[0].Content != "historical plaintext" {
		t.Fatalf("GetVersions decrypt failed: %v", err)
	}
	var rawVer string
	if err := s.DB().QueryRowContext(ctx,
		`SELECT content FROM node_versions WHERE node_id=? AND version=1`, "enc-1").Scan(&rawVer); err != nil {
		t.Fatal(err)
	}
	if !IsEncryptedValue(rawVer) {
		t.Fatalf("version history not encrypted at rest: %q", rawVer)
	}
}

// TestStoreEncryptionPlaintextLegacy covers the migration boundary: rows
// written before EnableEncryption remain readable afterwards, and a rewrite
// upgrades them to ciphertext.
func TestStoreEncryptionPlaintextLegacy(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	legacy := &Node{
		ID: "legacy-1", Type: "decision", Content: "written in plaintext",
		ContentHash: "h-legacy", Scope: "project", Project: "test",
	}
	if err := s.CreateNode(ctx, legacy); err != nil {
		t.Fatal(err)
	}

	if err := s.EnableEncryption(&constKeyProvider{key: []byte("legacy-boundary-key-material!!!"), version: 0}); err != nil {
		t.Fatal(err)
	}

	got, err := s.GetNode(ctx, "legacy-1")
	if err != nil {
		t.Fatal(err)
	}
	if got.Content != "written in plaintext" {
		t.Fatalf("legacy row unreadable after enabling encryption: %q", got.Content)
	}

	// Progressive re-encryption via update.
	got.Content = "now encrypted"
	if err := s.UpdateNode(ctx, got); err != nil {
		t.Fatal(err)
	}
	var raw string
	if err := s.DB().QueryRowContext(ctx, `SELECT content FROM nodes WHERE id=?`, "legacy-1").Scan(&raw); err != nil {
		t.Fatal(err)
	}
	if !IsEncryptedValue(raw) {
		t.Fatalf("legacy row not upgraded to ciphertext on update: %q", raw)
	}
}

// TestStoreEncryptionWrongKeyFailFast asserts the store refuses to serve
// ciphertext garbage when opened without the right key.
func TestStoreEncryptionWrongKeyFailFast(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.EnableEncryption(&constKeyProvider{key: []byte("first-key-material-32-bytes!!!!"), version: 0}); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	if err := s.CreateNode(ctx, &Node{
		ID: "k1", Type: "convention", Content: "sealed with key one",
		ContentHash: "h-k1", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}

	// Reopen with a different key: decrypt must fail, not return garbage.
	dbPath := s.dbPath
	_ = s.Close()

	s2, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	defer s2.Close()
	if err := s2.EnableEncryption(&constKeyProvider{key: []byte("second-key-material-32-bytes!!!"), version: 0}); err != nil {
		t.Fatal(err)
	}
	if _, err := s2.GetNode(ctx, "k1"); !errors.Is(err, ErrDecryptionFailed) {
		t.Fatalf("wrong key must fail reads, got %v", err)
	}
}

// TestStoreEncryptionInTx covers the transactional store path.
func TestStoreEncryptionInTx(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.EnableEncryption(&constKeyProvider{key: []byte("tx-key-material-32-bytes!!!!!!!"), version: 0}); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	err := s.WithTx(ctx, func(tx Storage) error {
		if err := tx.CreateNode(ctx, &Node{
			ID: "tx-enc", Type: "convention", Content: "tx plaintext",
			ContentHash: "h-tx", Scope: "project", Project: "test",
		}); err != nil {
			return err
		}
		got, err := tx.GetNode(ctx, "tx-enc")
		if err != nil {
			return err
		}
		if got.Content != "tx plaintext" {
			return errors.New("tx read did not decrypt")
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}

	var raw string
	if err := s.DB().QueryRowContext(ctx, `SELECT content FROM nodes WHERE id=?`, "tx-enc").Scan(&raw); err != nil {
		t.Fatal(err)
	}
	if !IsEncryptedValue(raw) {
		t.Fatalf("tx write not encrypted at rest: %q", raw)
	}
}

// TestStoreNoEncryptionByDefault verifies default behaviour is unchanged:
// plaintext on disk, bookkeeping columns false/0.
func TestStoreNoEncryptionByDefault(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	if err := s.CreateNode(ctx, &Node{
		ID: "plain-1", Type: "convention", Content: "stays plaintext",
		ContentHash: "h-plain", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}

	var raw string
	var encrypted bool
	var keyVersion int
	if err := s.DB().QueryRowContext(ctx,
		`SELECT content, encrypted, encryption_key_version FROM nodes WHERE id=?`, "plain-1").
		Scan(&raw, &encrypted, &keyVersion); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			t.Fatal("node row missing")
		}
		t.Fatal(err)
	}
	if raw != "stays plaintext" || encrypted || keyVersion != 0 {
		t.Fatalf("default store must stay plaintext: %q enc=%v kv=%d", raw, encrypted, keyVersion)
	}
}

// TestStoreEncryptionSearchFallback pins the FTS5 boundary: the FTS index
// stores ciphertext, so keyword search falls back to an in-memory scan over
// decrypted content when the cipher is active.
func TestStoreEncryptionSearchFallback(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if err := s.EnableEncryption(&constKeyProvider{key: []byte("search-fallback-key-material!!!"), version: 0}); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	for i, content := range []string{
		"always run the linter before commit",
		"deploy through the golden pipeline",
		"keep functions under forty lines",
	} {
		if err := s.CreateNode(ctx, &Node{
			ID: fmt.Sprintf("search-%d", i), Type: "convention", Content: content,
			ContentHash: fmt.Sprintf("h-search-%d", i), Scope: "project", Project: "test",
		}); err != nil {
			t.Fatal(err)
		}
	}

	nodes, err := s.SearchNodes(ctx, "linter", 5)
	if err != nil {
		t.Fatal(err)
	}
	if len(nodes) != 1 || nodes[0].Content != "always run the linter before commit" {
		t.Fatalf("encrypted keyword search failed: %d hits, %+v", len(nodes), nodes)
	}

	// Multi-token OR matching across content/summary.
	nodes, err = s.SearchNodes(ctx, "pipeline forty", 5)
	if err != nil {
		t.Fatal(err)
	}
	if len(nodes) != 2 {
		t.Fatalf("expected 2 OR-matched nodes, got %d", len(nodes))
	}

	// Limit respected.
	nodes, err = s.SearchNodes(ctx, "the", 2)
	if err != nil {
		t.Fatal(err)
	}
	if len(nodes) != 2 {
		t.Fatalf("limit 2 not honored, got %d", len(nodes))
	}
}

// TestEncryptValuesNilCipher guards the hot-path passthrough.
func TestEncryptValuesNilCipher(t *testing.T) {
	out, err := encryptValues(nil, "a", "b")
	if err != nil || out[0] != "a" || out[1] != "b" {
		t.Fatalf("nil cipher must pass through: %v %v", out, err)
	}
	out, err = decryptValues(nil, "x")
	if err != nil || out[0] != "x" {
		t.Fatalf("nil cipher decrypt passthrough: %v %v", out, err)
	}
}
