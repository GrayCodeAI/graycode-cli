package engine

import (
	"context"
	"fmt"
	"math/rand"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// Quiz tests how well an agent (or developer) remembers project knowledge.
// Generates questions from stored memories and checks answers.
// Useful for validating that the memory system is capturing the right things.
type Quiz struct {
	store storage.Storage
}

// QuizQuestion is a generated question with its expected answer.
type QuizQuestion struct {
	Question string `json:"question"`
	Answer   string `json:"answer"`
	Type     string `json:"type"`
	NodeID   string `json:"node_id"`
}

// QuizResult tracks how well the quiz was answered.
type QuizResult struct {
	Total   int     `json:"total"`
	Correct int     `json:"correct"`
	Score   float64 `json:"score"` // 0-100
}

// NewQuiz creates a quiz generator.
func NewQuiz(store storage.Storage) *Quiz {
	return &Quiz{store: store}
}

// Generate creates quiz questions from stored memories.
func (q *Quiz) Generate(ctx context.Context, count int) ([]QuizQuestion, error) {
	if count <= 0 {
		count = 10
	}

	// Get high-confidence memories as quiz material
	nodes, err := q.store.ListNodes(ctx, storage.NodeFilter{MinConfidence: 0.5, Limit: 100})
	if err != nil {
		return nil, err
	}
	if len(nodes) == 0 {
		return nil, nil
	}

	// Shuffle and pick
	rand.Shuffle(len(nodes), func(i, j int) {
		nodes[i], nodes[j] = nodes[j], nodes[i]
	})
	if count > len(nodes) {
		count = len(nodes)
	}

	questions := make([]QuizQuestion, 0, count)
	for _, n := range nodes[:count] {
		question := generateQuestion(n)
		if question.Question != "" {
			questions = append(questions, question)
		}
	}
	return questions, nil
}

// CheckAnswer verifies if a given answer matches the stored memory.
func (q *Quiz) CheckAnswer(question QuizQuestion, answer string) bool {
	ansLower := strings.ToLower(answer)
	expected := strings.ToLower(question.Answer)

	// Exact match
	if strings.Contains(ansLower, expected) || strings.Contains(expected, ansLower) {
		return true
	}

	// Key term overlap (>50% of terms match)
	ansTerms := strings.Fields(ansLower)
	expTerms := strings.Fields(expected)
	matches := 0
	for _, at := range ansTerms {
		for _, et := range expTerms {
			if at == et && len(at) >= 3 {
				matches++
				break
			}
		}
	}
	if len(expTerms) > 0 {
		return float64(matches)/float64(len(expTerms)) > 0.5
	}
	return false
}

func generateQuestion(n *storage.Node) QuizQuestion {
	content := n.Content
	if len(content) > 150 {
		content = content[:150]
	}

	var question string
	switch n.Type {
	case "convention":
		question = fmt.Sprintf("What is the convention for: %s?", extractTopic(content))
	case "decision":
		question = fmt.Sprintf("Why did we decide: %s?", extractTopic(content))
	case "bug":
		question = fmt.Sprintf("What was the fix for: %s?", extractTopic(content))
	case "spec":
		question = fmt.Sprintf("How does this work: %s?", extractTopic(content))
	case "preference":
		question = fmt.Sprintf("What is the preferred approach for: %s?", extractTopic(content))
	default:
		question = fmt.Sprintf("What do you know about: %s?", extractTopic(content))
	}

	return QuizQuestion{
		Question: question,
		Answer:   content,
		Type:     n.Type,
		NodeID:   n.ID,
	}
}

func extractTopic(content string) string {
	// Take first meaningful phrase (up to 50 chars)
	content = strings.TrimSpace(content)
	if idx := strings.IndexAny(content, ":.;—–"); idx > 0 && idx < 50 {
		return content[:idx]
	}
	if len(content) > 50 {
		// Find word boundary
		end := 50
		for end > 30 && content[end] != ' ' {
			end--
		}
		return content[:end]
	}
	return content
}
