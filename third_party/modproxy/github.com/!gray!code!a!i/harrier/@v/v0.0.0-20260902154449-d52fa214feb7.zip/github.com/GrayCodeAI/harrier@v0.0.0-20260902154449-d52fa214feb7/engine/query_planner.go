package engine

import (
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/intent"
)

// QueryPlanner implements intelligent query routing based on Qdrant's
// cardinality estimation and Cognee's auto-routing approach.
// Instead of always running all 5 retrieval signals, it selects the
// optimal subset based on query characteristics.
//
// Techniques from:
//   - Qdrant: Cardinality-based path selection
//   - Cognee: Intent-aware routing to specialized retrievers
//   - Mem0: Query-adaptive parameters
type QueryPlanner struct {
	nodeCount  int
	hasVectors bool
	hasGraph   bool
	scoringCfg ScoringConfig
}

// QueryPlan describes which retrieval signals to use.
type QueryPlan struct {
	UseBM25      bool
	UseVector    bool
	UseGraph     bool
	UseRecency   bool
	UseEntity    bool
	GraphDepth   int
	BM25Limit    int
	Intent       intent.Intent
	TemporalOnly bool
}

// NewQueryPlanner creates a planner with context about the index.
func NewQueryPlanner(nodeCount int, hasVectors, hasGraph bool) *QueryPlanner {
	return &QueryPlanner{
		nodeCount:  nodeCount,
		hasVectors: hasVectors,
		hasGraph:   hasGraph,
		scoringCfg: DefaultScoringConfig(),
	}
}

// Plan analyzes a query and decides the optimal retrieval strategy.
func (qp *QueryPlanner) Plan(query string, opts RecallOpts) QueryPlan {
	plan := QueryPlan{
		UseBM25:   true, // always use BM25 as baseline
		UseEntity: true, // always boost by entities
		BM25Limit: opts.Limit * 3,
	}

	queryIntent := intent.Classify(query)
	plan.Intent = queryIntent

	// Temporal queries: skip vector, focus on time-based filtering
	if queryIntent == intent.IntentWhen || isTemporalQuery(query) {
		plan.UseRecency = true
		plan.UseGraph = true
		plan.GraphDepth = 2
		plan.UseVector = false
		return plan
	}

	// Causal/Why queries: deep graph traversal is critical
	if queryIntent == intent.IntentWhy {
		plan.UseGraph = true
		plan.GraphDepth = 4 // deeper for causal chains
		plan.UseVector = qp.hasVectors
		plan.UseRecency = false
		return plan
	}

	// How queries: skill/procedural memory + moderate graph
	if queryIntent == intent.IntentHow {
		plan.UseGraph = true
		plan.GraphDepth = 2
		plan.UseVector = qp.hasVectors
		plan.UseRecency = false
		return plan
	}

	// Specific entity queries (file paths, function names): BM25 dominant
	if isSpecificQuery(query) {
		plan.UseVector = false // BM25 is better for exact matches
		plan.UseGraph = true
		plan.GraphDepth = 1
		plan.UseRecency = false
		plan.BM25Limit = opts.Limit * 5 // over-fetch for better precision
		return plan
	}

	// General/What queries: balanced pipeline
	plan.UseVector = qp.hasVectors
	plan.UseGraph = qp.hasGraph
	plan.GraphDepth = 2 // depth 2 is fast; depth 3+ only for causal chains
	plan.UseRecency = true
	return plan
}

// EstimateCardinality estimates how many results a query will return.
// Used to decide if expensive signals (vector, graph) are worth running.
// Based on Qdrant's Agresti-Coull sampling approach (simplified).
func (qp *QueryPlanner) EstimateCardinality(query string) float64 {
	if qp.nodeCount == 0 {
		return 0
	}
	// Heuristic: more specific queries have lower cardinality
	terms := strings.Fields(query)
	specificity := float64(len(terms)) / 10.0
	if specificity > 1.0 {
		specificity = 1.0
	}
	// Estimated fraction of nodes that will match
	return (1.0 - specificity*0.7) * float64(qp.nodeCount)
}

func isTemporalQuery(query string) bool {
	temporalWords := []string{"when", "yesterday", "last week", "today", "recent", "latest", "ago", "before", "after", "since"}
	lower := strings.ToLower(query)
	for _, w := range temporalWords {
		if strings.Contains(lower, w) {
			return true
		}
	}
	return false
}

func isSpecificQuery(query string) bool {
	return strings.Contains(query, ".") || strings.Contains(query, "/") ||
		strings.Contains(query, "(") || strings.Contains(query, "_")
}

// QueryMetrics tracks retrieval performance for auto-tuning.
type QueryMetrics struct {
	Query       string
	Duration    time.Duration
	ResultCount int
	SignalsUsed []string
	WasUseful   bool
}
