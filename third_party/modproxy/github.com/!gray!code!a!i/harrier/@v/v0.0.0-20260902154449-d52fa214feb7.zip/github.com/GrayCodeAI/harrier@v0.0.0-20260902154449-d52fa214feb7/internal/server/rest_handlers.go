// This file is part of package server. It holds the core REST request
// handlers (memory, graph, node, session, and maintenance endpoints)
// split verbatim out of rest.go for readability; behavior is unchanged.

package server

import (
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"time"

	harrierversion "github.com/GrayCodeAI/harrier"
	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/engine"
	gitwatch "github.com/GrayCodeAI/harrier/git"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/internal/telemetry"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

func (s *RESTServer) handleRemember(w http.ResponseWriter, r *http.Request) {
	var in engine.RememberInput
	if err := decodeJSON(r, &in); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if in.Type != "" && !engine.IsValidNodeType(in.Type) {
		httpErr(w, fmt.Errorf("invalid node type: %q", in.Type), 400)
		return
	}
	node, err := s.eng.Remember(r.Context(), in)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, node, 201)
}

func (s *RESTServer) handleRecall(w http.ResponseWriter, r *http.Request) {
	var opts engine.RecallOpts
	if err := decodeJSON(r, &opts); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if opts.Depth > maxGraphDepth {
		httpErr(w, fmt.Errorf("depth exceeds maximum of %d", maxGraphDepth), 400)
		return
	}
	result, err := s.eng.Recall(r.Context(), opts)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, result, 200)
}

func (s *RESTServer) handleContext(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	result, err := s.eng.Context(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, result, 200)
}

func (s *RESTServer) handleLink(w http.ResponseWriter, r *http.Request) {
	var edge storage.Edge
	if err := decodeJSON(r, &edge); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if edge.Type == "" {
		httpErr(w, fmt.Errorf("edge type is required"), 400)
		return
	}
	if !graph.IsValidEdgeType(edge.Type) {
		httpErr(w, fmt.Errorf("invalid edge type: %q", edge.Type), 400)
		return
	}
	if edge.ID == "" {
		edge.ID = uuid.New().String()
	}
	if err := s.eng.Graph().AddEdge(r.Context(), &edge); err != nil {
		httpErr(w, err, 400)
		return
	}
	httpJSON(w, edge, 201)
}

// rateLimit returns 429 if the rate limiter rejects the request.
func (s *RESTServer) rateLimit(w http.ResponseWriter) bool {
	if s.limiter != nil && !s.limiter.Allow() {
		httpErr(w, fmt.Errorf("rate limit exceeded, try again later"), 429)
		return false
	}
	return true
}

func (s *RESTServer) handleDeleteLink(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	id := r.PathValue("id")
	if err := s.eng.Graph().RemoveEdge(r.Context(), id); err != nil {
		httpErr(w, err, 404)
		return
	}
	httpJSON(w, map[string]string{"status": "deleted"}, 200)
}

func (s *RESTServer) handleGetNode(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	id := r.PathValue("id")
	node, err := s.eng.Store().GetNode(r.Context(), id)
	telemetry.MemoryRetrieveDuration.Record(r.Context(), time.Since(start).Seconds())
	if err != nil {
		httpErr(w, err, 404)
		return
	}
	neighbors, _ := s.eng.Store().GetNeighbors(r.Context(), id)
	httpJSON(w, map[string]any{"node": node, "neighbors": neighbors}, 200)
}

func (s *RESTServer) handleSubgraph(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	depth := intQuery(r, "depth", 2)
	if depth > maxGraphDepth {
		httpErr(w, fmt.Errorf("depth exceeds maximum of %d", maxGraphDepth), 400)
		return
	}
	sg, err := s.eng.Graph().ExtractSubgraph(r.Context(), id, depth)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSONCapped(w, sg, 200)
}

func (s *RESTServer) handleImpact(w http.ResponseWriter, r *http.Request) {
	file := r.PathValue("file")
	depth := intQuery(r, "depth", 3)
	if depth > maxGraphDepth {
		httpErr(w, fmt.Errorf("depth exceeds maximum of %d", maxGraphDepth), 400)
		return
	}
	ids, err := s.eng.Graph().Impact(r.Context(), file, depth)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	var nodes []*storage.Node
	for _, id := range ids {
		if n, err := s.eng.Store().GetNode(r.Context(), id); err == nil {
			nodes = append(nodes, n)
		}
	}
	httpJSONCapped(w, nodes, 200)
}

func (s *RESTServer) handleForget(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	id := r.PathValue("id")
	if err := s.eng.Forget(r.Context(), id); err != nil {
		httpErr(w, err, 404)
		return
	}
	httpJSON(w, map[string]string{"status": "forgotten"}, 200)
}

func (s *RESTServer) handleUpdateNode(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	node, err := s.eng.Store().GetNode(r.Context(), id)
	if err != nil {
		httpErr(w, err, 404)
		return
	}

	var patch struct {
		Content *string `json:"content"`
		Summary *string `json:"summary"`
		Tags    *string `json:"tags"`
		Key     *string `json:"key"`
		Pinned  *bool   `json:"pinned"`
		Type    *string `json:"type"`
		Tier    *int    `json:"tier"`
	}
	if err := decodeJSON(r, &patch); err != nil {
		httpErr(w, err, 400)
		return
	}

	// Save version before modifying
	if patch.Content != nil && *patch.Content != node.Content {
		_ = s.eng.Store().SaveVersion(r.Context(), node.ID, node.Content, "api", "updated via PATCH")
	}

	if patch.Content != nil {
		node.Content = *patch.Content
		node.ContentHash = engine.ContentHash(node.Content, node.Scope, node.Project, node.Type)
	}
	if patch.Summary != nil {
		node.Summary = *patch.Summary
	}
	if patch.Tags != nil {
		node.Tags = *patch.Tags
	}
	if patch.Key != nil {
		node.Key = *patch.Key
	}
	if patch.Pinned != nil {
		node.Pinned = *patch.Pinned
	}
	if patch.Type != nil {
		if !engine.IsValidNodeType(*patch.Type) {
			httpErr(w, fmt.Errorf("invalid node type: %q", *patch.Type), 400)
			return
		}
		node.Type = *patch.Type
	}
	if patch.Tier != nil {
		node.Tier = *patch.Tier
	}
	node.Version++
	if err := s.eng.Store().UpdateNode(r.Context(), node); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, node, 200)
}

func (s *RESTServer) handlePinNode(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	node, err := s.eng.Store().GetNode(r.Context(), id)
	if err != nil {
		httpErr(w, err, 404)
		return
	}
	node.Pinned = !node.Pinned
	if err := s.eng.Store().UpdateNode(r.Context(), node); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"id": node.ID, "pinned": node.Pinned}, 200)
}

func (s *RESTServer) handleHealth(w http.ResponseWriter, r *http.Request) {
	// Actually verify database connectivity with a lightweight query
	_, err := s.eng.Store().ListNodes(r.Context(), storage.NodeFilter{})
	if err != nil {
		httpJSON(w, map[string]string{"status": "error", "error": err.Error()}, 503)
		return
	}
	httpJSON(w, map[string]string{"status": "ok", "version": harrierversion.String()}, 200)
}

func (s *RESTServer) handleVersion(w http.ResponseWriter, _ *http.Request) {
	httpJSON(w, map[string]string{"version": harrierversion.String()}, 200)
}

// handleLiveness responds to Kubernetes liveness probes (/healthz).
// Always returns 200 — if the process is alive, it is live.
func (s *RESTServer) handleLiveness(w http.ResponseWriter, _ *http.Request) {
	httpJSON(w, map[string]string{"status": "ok"}, 200)
}

// handleReadiness responds to Kubernetes readiness probes (/readyz).
// Delegates to the full health check to confirm the database is reachable.
func (s *RESTServer) handleReadiness(w http.ResponseWriter, r *http.Request) {
	s.handleHealth(w, r)
}

func (s *RESTServer) handleStats(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	st, err := s.eng.Status(r.Context(), project)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, st, 200)
}

func (s *RESTServer) handleSessions(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	limit := intQuery(r, "limit", 10)
	sessions, err := s.eng.Store().ListSessions(r.Context(), project, limit)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, sessions, 200)
}

func (s *RESTServer) handleSessionStart(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Project string `json:"project"`
		Agent   string `json:"agent"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	sess := &storage.Session{
		ID:        uuid.New().String(),
		Project:   body.Project,
		Agent:     body.Agent,
		StartedAt: time.Now(),
	}
	if err := s.eng.Store().CreateSession(r.Context(), sess); err != nil {
		httpErr(w, err, 500)
		return
	}
	ctxRes, err := s.eng.Context(r.Context(), body.Project)
	if err != nil {
		slog.Warn("session start: context load failed", "error", err)
	}
	httpJSON(w, map[string]any{"session": sess, "context": ctxRes}, 201)
}

func (s *RESTServer) handleSessionEnd(w http.ResponseWriter, r *http.Request) {
	var body struct {
		ID      string `json:"id"`
		Summary string `json:"summary"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if err := s.eng.Store().EndSession(r.Context(), body.ID, body.Summary); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]string{"status": "ended"}, 200)
}

func (s *RESTServer) handleStale(w http.ResponseWriter, r *http.Request) {
	if s.projectDir == "" {
		httpJSON(w, map[string]string{"status": "no project directory configured"}, 200)
		return
	}
	// gitwatch.New is lightweight (path validation + struct creation only).
	watcher, err := gitwatch.New(s.eng.Store(), s.eng.Graph(), s.projectDir)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	since := time.Now().Add(-7 * 24 * time.Hour) // last 7 days
	reports, err := watcher.StalesSince(r.Context(), since)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, reports, 200)
}

func (s *RESTServer) handleEmbed(w http.ResponseWriter, r *http.Request) {
	var body struct {
		NodeID string `json:"node_id"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if s.embedder == nil {
		httpErr(w, fmt.Errorf("no embedding provider configured"), 503)
		return
	}
	node, err := s.eng.Store().GetNode(r.Context(), body.NodeID)
	if err != nil {
		httpErr(w, err, 404)
		return
	}
	// Document mode: stored content is embedded as a document (search_document)
	// so it pairs correctly with query-mode embeddings at search time.
	vec, err := s.embedder.EmbedWithMode(r.Context(), node.Content, embeddings.ModeDocument)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	if err := s.eng.Store().SaveEmbedding(r.Context(), node.ID, s.embedder.Name(), vec); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{"node_id": node.ID, "dims": len(vec)}, 200)
}

func (s *RESTServer) handleHybridRecall(w http.ResponseWriter, r *http.Request) {
	var opts engine.RecallOpts
	if err := decodeJSON(r, &opts); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	hs := engine.NewHybridSearch(s.eng.Store(), s.eng.Graph(), s.embedder)
	scored, err := hs.Search(r.Context(), opts.Query, opts)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	reranked := engine.Rerank(r.Context(), scored, s.eng.Store())
	httpJSONCapped(w, reranked, 200)
}

func (s *RESTServer) handleProactive(w http.ResponseWriter, r *http.Request) {
	project := r.URL.Query().Get("project")
	hs := engine.NewHybridSearch(s.eng.Store(), s.eng.Graph(), s.embedder)
	pc := engine.NewProactiveContext(s.eng, hs)
	nodes, err := pc.Predict(r.Context(), project, 2000)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]any{
		"nodes":   nodes,
		"context": engine.FormatContext(nodes),
	}, 200)
}

func (s *RESTServer) handleFeedback(w http.ResponseWriter, r *http.Request) {
	var body struct {
		ID         string                `json:"id"`
		Action     engine.FeedbackAction `json:"action"`
		NewContent string                `json:"new_content"`
	}
	if err := decodeJSON(r, &body); err != nil {
		var maxBytesErr *http.MaxBytesError
		if errors.As(err, &maxBytesErr) {
			httpErr(w, err, 413)
		} else {
			httpErr(w, err, 400)
		}
		return
	}
	if err := s.eng.Feedback(r.Context(), body.ID, body.Action, body.NewContent); err != nil {
		httpErr(w, err, 400)
		return
	}
	httpJSON(w, map[string]string{"status": "ok"}, 200)
}

func (s *RESTServer) handleDecay(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	if err := engine.RunDecay(r.Context(), s.eng.Store(), s.eng.DecayConfig); err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]string{"status": "decay applied"}, 200)
}

func (s *RESTServer) handleGC(w http.ResponseWriter, r *http.Request) {
	if !s.rateLimit(w) {
		return
	}
	n, err := engine.GarbageCollect(r.Context(), s.eng.Store(), s.eng.DecayConfig)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, map[string]int{"removed": n}, 200)
}

func (s *RESTServer) handleReplay(w http.ResponseWriter, r *http.Request) {
	sessionID := r.PathValue("session_id")
	events, err := s.eng.Store().GetReplayEvents(r.Context(), sessionID)
	if err != nil {
		httpErr(w, err, 500)
		return
	}
	httpJSON(w, events, 200)
}
