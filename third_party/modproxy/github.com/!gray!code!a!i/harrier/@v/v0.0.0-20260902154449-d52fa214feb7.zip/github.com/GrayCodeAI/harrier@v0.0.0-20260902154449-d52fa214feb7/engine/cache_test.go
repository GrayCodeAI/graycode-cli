package engine

import (
	"testing"
	"time"
)

func TestNewQueryCache_Defaults(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(0, 0)
	if c.maxSize != 64 {
		t.Errorf("default maxSize = %d, want 64", c.maxSize)
	}
	if c.ttl != 5*time.Minute {
		t.Errorf("default ttl = %v, want 5m", c.ttl)
	}
}

func TestQueryCache_GetPut(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(10, time.Minute)

	if got := c.Get("missing"); got != nil {
		t.Errorf("Get(missing) = %v, want nil", got)
	}

	result := &RecallResult{Nodes: nil}
	c.Put("q1", result)

	if got := c.Get("q1"); got != result {
		t.Errorf("Get(q1) = %v, want original result", got)
	}
}

func TestQueryCache_Invalidate(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(10, time.Minute)
	c.Put("q1", &RecallResult{})

	c.Invalidate()

	if got := c.Get("q1"); got != nil {
		t.Errorf("Get after Invalidate = %v, want nil", got)
	}
}

func TestQueryCache_TTLExpiry(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(10, time.Millisecond)
	c.Put("q1", &RecallResult{})

	time.Sleep(5 * time.Millisecond)

	if got := c.Get("q1"); got != nil {
		t.Errorf("Get after TTL = %v, want nil (expired)", got)
	}
}

func TestQueryCache_Eviction(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(2, time.Minute)
	c.Put("a", &RecallResult{})
	c.Put("b", &RecallResult{})
	c.Put("c", &RecallResult{}) // evicts "a"

	if got := c.Get("a"); got != nil {
		t.Errorf("Get(a) after eviction = %v, want nil", got)
	}
	if got := c.Get("b"); got == nil {
		t.Error("Get(b) = nil, want present")
	}
	if got := c.Get("c"); got == nil {
		t.Error("Get(c) = nil, want present")
	}
	size, _ := c.Stats()
	if size != 2 {
		t.Errorf("size = %d, want 2", size)
	}
}

func TestQueryCache_StatsAndClear(t *testing.T) {
	t.Parallel()
	c := NewQueryCache(10, time.Minute)
	c.Put("q1", &RecallResult{})
	c.Put("q2", &RecallResult{})

	size, version := c.Stats()
	if size != 2 {
		t.Errorf("size = %d, want 2", size)
	}
	if version != 0 {
		t.Errorf("version = %d, want 0", version)
	}

	c.Clear()
	size, _ = c.Stats()
	if size != 0 {
		t.Errorf("size after Clear = %d, want 0", size)
	}
}

func TestCacheKey(t *testing.T) {
	t.Parallel()
	key := CacheKey(RecallOpts{Query: "hello", Type: "convention", Project: "myproj", Limit: 10, Depth: 2})
	if key == "" {
		t.Error("CacheKey returned empty string")
	}
	// Different opts must yield different keys.
	other := CacheKey(RecallOpts{Query: "world", Type: "convention", Project: "myproj", Limit: 10, Depth: 2})
	if key == other {
		t.Errorf("different queries produced same key %q", key)
	}
}
