package storage

import (
	"context"
	"database/sql"
	"fmt"
)

// Migration represents a single schema migration.
type Migration struct {
	Version int
	Up      func(*sql.Tx) error
}

var migrations = []Migration{
	{1, func(tx *sql.Tx) error { _, err := tx.ExecContext(context.Background(), schema); return err }},
	{2, func(tx *sql.Tx) error {
		_, err := tx.ExecContext(context.Background(), `CREATE INDEX IF NOT EXISTS idx_nodes_type_project_scope ON nodes(type, project, scope);`)
		return err
	}},
	{3, func(tx *sql.Tx) error {
		_, err := tx.ExecContext(context.Background(), `
			CREATE TABLE IF NOT EXISTS node_metadata (
				node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
				key TEXT NOT NULL,
				value TEXT NOT NULL,
				PRIMARY KEY (node_id, key)
			);
			CREATE INDEX IF NOT EXISTS idx_node_metadata_key_value ON node_metadata(key, value);
		`)
		return err
	}},
	{4, func(tx *sql.Tx) error { // HNSW vector index table
		_, err := tx.ExecContext(context.Background(), `
			CREATE TABLE IF NOT EXISTS embeddings_hnsw (
				node_id TEXT PRIMARY KEY REFERENCES nodes(id) ON DELETE CASCADE,
				vector BLOB NOT NULL,
				model TEXT NOT NULL,
				neighbors TEXT NOT NULL,  -- JSON array of {"id": "...", "level": 0}
				updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
			);
			CREATE INDEX IF NOT EXISTS idx_embeddings_hnsw_model ON embeddings_hnsw(model);
		`)
		return err
	}},
	{5, func(tx *sql.Tx) error { // Encryption support (future)
		_, err := tx.ExecContext(context.Background(), `
			ALTER TABLE nodes ADD COLUMN encrypted BOOLEAN DEFAULT FALSE;
			ALTER TABLE nodes ADD COLUMN encryption_key_version INTEGER DEFAULT 0;
		`)
		return err
	}},
}

// Migrate runs pending migrations in a transaction.
func (s *Store) Migrate(ctx context.Context) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin migration tx: %w", err)
	}
	defer func() { _ = tx.Rollback() }()

	var currentVersion int
	err = tx.QueryRowContext(ctx, "SELECT COALESCE(MAX(version), 0) FROM schema_version").Scan(&currentVersion)
	if err == sql.ErrNoRows {
		currentVersion = 0
	} else if err != nil {
		return fmt.Errorf("read schema version: %w", err)
	}

	for _, m := range migrations {
		if m.Version <= currentVersion {
			continue
		}
		if err := m.Up(tx); err != nil {
			return fmt.Errorf("migration %d: %w", m.Version, err)
		}
		if currentVersion == 0 {
			_, err = tx.ExecContext(ctx, "INSERT INTO schema_version (version) VALUES (?)", m.Version)
		} else {
			_, err = tx.ExecContext(ctx, "UPDATE schema_version SET version = ?", m.Version)
		}
		if err != nil {
			return fmt.Errorf("update schema version %d: %w", m.Version, err)
		}
		currentVersion = m.Version
	}

	return tx.Commit()
}

// GetSchemaVersion returns the current schema version.
func (s *Store) GetSchemaVersion(ctx context.Context) (int, error) {
	var v int
	err := s.db.QueryRowContext(ctx, "SELECT COALESCE(MAX(version), 0) FROM schema_version").Scan(&v)
	if err == sql.ErrNoRows {
		return 0, nil
	}
	return v, err
}
