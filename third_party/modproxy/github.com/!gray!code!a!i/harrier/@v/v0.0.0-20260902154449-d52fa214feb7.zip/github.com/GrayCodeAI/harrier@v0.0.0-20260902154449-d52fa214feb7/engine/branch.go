package engine

import (
	"context"
	"crypto/sha256"
	"fmt"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// Branch creates a new node branching off from the given nodeID.
// The new node inherits the parent's project and scope but carries the
// provided newContent and newType. An edge of type "caused_by" links the
// branch node back to its parent, forming a DAG branch.
func (e *Engine) Branch(ctx context.Context, nodeID, newContent, newType string) (*storage.Node, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if newContent == "" {
		return nil, fmt.Errorf("branch content cannot be empty")
	}
	if newType != "" && !validNodeTypes[newType] {
		return nil, fmt.Errorf("invalid node type: %q", newType)
	}

	// Fetch the parent node to inherit project/scope.
	parent, err := e.store.GetNode(ctx, nodeID)
	if err != nil {
		return nil, fmt.Errorf("branch: parent not found: %w", err)
	}

	// Compute content hash for the new node.
	h := sha256.Sum256([]byte(newContent + "\x00" + parent.Scope + "\x00" + parent.Project))
	hash := fmt.Sprintf("%x", h)

	node := &storage.Node{
		ID:          uuid.New().String(),
		Type:        newType,
		Content:     newContent,
		ContentHash: hash,
		Scope:       parent.Scope,
		Project:     parent.Project,
		Tier:        defaultTier(newType),
		Confidence:  1.0,
		Version:     1,
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	if err := e.graph.AddNode(ctx, node); err != nil {
		return nil, fmt.Errorf("branch: create node failed: %w", err)
	}

	// Create an edge from the branched node back to the parent (DAG link).
	edge := &storage.Edge{
		ID:     uuid.New().String(),
		FromID: node.ID,
		ToID:   nodeID,
		Type:   "caused_by",
		Weight: 1.0,
	}
	if err := e.graph.AddEdge(ctx, edge); err != nil {
		return nil, fmt.Errorf("branch: edge failed: %w", err)
	}

	return node, nil
}
