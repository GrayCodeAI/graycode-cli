// Package browse presents stored memories as a navigable virtual filesystem
// (directories per category, files per memory) for tree/search/get access.
package browse

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"
)

// MemoryItem represents a flat memory entry to be organized into the filesystem.
type MemoryItem struct {
	ID        string
	Content   string
	Category  string
	Type      string
	CreatedAt time.Time
}

// FSNode represents a node in the memory filesystem tree.
type FSNode struct {
	Name      string
	Type      string // "dir" or "file"
	Children  []*FSNode
	MemoryID  string
	Content   string
	CreatedAt time.Time
}

// MemoryFS provides a filesystem-style interface for browsing memories.
type MemoryFS struct {
	Root *FSNode
	mu   sync.RWMutex
}

// NewMemoryFS creates a new MemoryFS with an empty root directory.
func NewMemoryFS() *MemoryFS {
	return &MemoryFS{
		Root: &FSNode{
			Name:     "/",
			Type:     "dir",
			Children: make([]*FSNode, 0),
		},
	}
}

// BuildFromMemories organizes flat memory items into a tree structure grouped
// by Category (first level directory) and Type (second level directory).
// Each memory becomes a file node named by its ID.
func (fs *MemoryFS) BuildFromMemories(memories []MemoryItem) *MemoryFS {
	fs.mu.Lock()
	defer fs.mu.Unlock()

	fs.Root = &FSNode{
		Name:     "/",
		Type:     "dir",
		Children: make([]*FSNode, 0),
	}

	for _, m := range memories {
		category := m.Category
		if category == "" {
			category = "uncategorized"
		}

		catNode := fs.findChild(fs.Root, category)
		if catNode == nil {
			catNode = &FSNode{
				Name:     category,
				Type:     "dir",
				Children: make([]*FSNode, 0),
			}
			fs.Root.Children = append(fs.Root.Children, catNode)
		}

		var parent *FSNode
		if m.Type != "" {
			typeNode := fs.findChild(catNode, m.Type)
			if typeNode == nil {
				typeNode = &FSNode{
					Name:     m.Type,
					Type:     "dir",
					Children: make([]*FSNode, 0),
				}
				catNode.Children = append(catNode.Children, typeNode)
			}
			parent = typeNode
		} else {
			parent = catNode
		}

		fileNode := &FSNode{
			Name:      m.ID,
			Type:      "file",
			MemoryID:  m.ID,
			Content:   m.Content,
			CreatedAt: m.CreatedAt,
		}
		parent.Children = append(parent.Children, fileNode)
	}

	return fs
}

// List returns the children of the directory at the given path, similar to `ls`.
// Returns nil if the path does not exist or is not a directory.
func (fs *MemoryFS) List(path string) []*FSNode {
	fs.mu.RLock()
	defer fs.mu.RUnlock()

	node := fs.resolve(path)
	if node == nil || node.Type != "dir" {
		return nil
	}
	return node.Children
}

// Get returns the node at the given path, similar to `cat` for files.
func (fs *MemoryFS) Get(path string) *FSNode {
	fs.mu.RLock()
	defer fs.mu.RUnlock()

	return fs.resolve(path)
}

// Tree returns a visual tree representation of the filesystem starting at the
// given path, up to the specified depth. Use depth <= 0 for unlimited depth.
func (fs *MemoryFS) Tree(path string, depth int) string {
	fs.mu.RLock()
	defer fs.mu.RUnlock()

	node := fs.resolve(path)
	if node == nil {
		return ""
	}

	var sb strings.Builder
	if node == fs.Root {
		sb.WriteString("/\n")
	} else {
		sb.WriteString(node.Name)
		if node.Type == "dir" {
			sb.WriteString("/")
		}
		sb.WriteString("\n")
	}

	fs.buildTree(&sb, node, "", depth, 1)
	return sb.String()
}

// Search finds nodes whose Name or Content contains the query string
// (case-insensitive). Returns all matching nodes.
func (fs *MemoryFS) Search(query string) []*FSNode {
	fs.mu.RLock()
	defer fs.mu.RUnlock()

	var results []*FSNode
	q := strings.ToLower(query)
	fs.searchRecursive(fs.Root, q, &results)
	return results
}

// Add inserts a memory item at the specified path. Intermediate directories
// are created as needed. The final path component becomes the file name.
func (fs *MemoryFS) Add(path string, item MemoryItem) error {
	fs.mu.Lock()
	defer fs.mu.Unlock()

	path = normalizePath(path)
	parts := splitPath(path)
	if len(parts) == 0 {
		return errors.New("cannot add to root path")
	}

	// Navigate/create intermediate directories.
	current := fs.Root
	for _, part := range parts[:len(parts)-1] {
		child := fs.findChild(current, part)
		if child == nil {
			child = &FSNode{
				Name:     part,
				Type:     "dir",
				Children: make([]*FSNode, 0),
			}
			current.Children = append(current.Children, child)
		} else if child.Type != "dir" {
			return fmt.Errorf("path component %q is not a directory", part)
		}
		current = child
	}

	fileName := parts[len(parts)-1]

	// Check if file already exists.
	for _, c := range current.Children {
		if c.Name == fileName {
			return fmt.Errorf("node %q already exists at path %q", fileName, path)
		}
	}

	fileNode := &FSNode{
		Name:      fileName,
		Type:      "file",
		MemoryID:  item.ID,
		Content:   item.Content,
		CreatedAt: item.CreatedAt,
	}
	current.Children = append(current.Children, fileNode)
	return nil
}

// Remove deletes the node at the specified path.
func (fs *MemoryFS) Remove(path string) error {
	fs.mu.Lock()
	defer fs.mu.Unlock()

	path = normalizePath(path)
	parts := splitPath(path)
	if len(parts) == 0 {
		return errors.New("cannot remove root")
	}

	current := fs.Root
	for _, part := range parts[:len(parts)-1] {
		child := fs.findChild(current, part)
		if child == nil || child.Type != "dir" {
			return fmt.Errorf("path %q not found", path)
		}
		current = child
	}

	target := parts[len(parts)-1]
	for i, c := range current.Children {
		if c.Name == target {
			current.Children = append(current.Children[:i], current.Children[i+1:]...)
			return nil
		}
	}
	return fmt.Errorf("node %q not found", target)
}

// --- internal helpers ---

func (fs *MemoryFS) resolve(path string) *FSNode {
	path = normalizePath(path)
	if path == "" {
		return fs.Root
	}

	parts := splitPath(path)
	current := fs.Root
	for _, part := range parts {
		child := fs.findChild(current, part)
		if child == nil {
			return nil
		}
		current = child
	}
	return current
}

func (fs *MemoryFS) findChild(parent *FSNode, name string) *FSNode {
	for _, c := range parent.Children {
		if c.Name == name {
			return c
		}
	}
	return nil
}

func (fs *MemoryFS) buildTree(sb *strings.Builder, node *FSNode, prefix string, maxDepth, currentDepth int) {
	if maxDepth > 0 && currentDepth > maxDepth {
		return
	}
	if node.Type != "dir" {
		return
	}

	for i, child := range node.Children {
		isLast := i == len(node.Children)-1
		connector := "├── "
		childPrefix := "│   "
		if isLast {
			connector = "└── "
			childPrefix = "    "
		}

		sb.WriteString(prefix + connector + child.Name)
		if child.Type == "dir" {
			sb.WriteString("/")
		}
		sb.WriteString("\n")

		if child.Type == "dir" {
			fs.buildTree(sb, child, prefix+childPrefix, maxDepth, currentDepth+1)
		}
	}
}

func (fs *MemoryFS) searchRecursive(node *FSNode, query string, results *[]*FSNode) {
	if strings.Contains(strings.ToLower(node.Name), query) ||
		strings.Contains(strings.ToLower(node.Content), query) {
		*results = append(*results, node)
	}
	for _, child := range node.Children {
		fs.searchRecursive(child, query, results)
	}
}

func normalizePath(path string) string {
	path = strings.TrimPrefix(path, "/")
	path = strings.TrimSuffix(path, "/")
	return path
}

func splitPath(path string) []string {
	if path == "" {
		return nil
	}
	return strings.Split(path, "/")
}
