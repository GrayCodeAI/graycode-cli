package storage

import "fmt"

// NodeCipher methods below are written with a nil receiver guard so callers
// can pass a *NodeCipher that is nil when encryption is disabled and get
// plaintext passthrough without branching at every call site.

// encryptValues seals the provided node content/summary with c. When c is nil
// (encryption disabled) or a value is empty, the value is returned unchanged.
// Encrypting an already-encrypted value is harmless but pointless; callers
// always pass fresh plaintext loaded from the API.
func encryptValues(c *NodeCipher, values ...string) ([]string, error) {
	if c == nil {
		out := make([]string, len(values))
		copy(out, values)
		return out, nil
	}
	out := make([]string, len(values))
	for i, v := range values {
		enc, err := c.Encrypt(v)
		if err != nil {
			return nil, fmt.Errorf("encrypt field %d: %w", i, err)
		}
		out[i] = enc
	}
	return out, nil
}

// decryptValues opens the provided stored values with c. A nil c, or any value
// lacking the cipher prefix (legacy plaintext written before encryption was
// enabled), passes through unchanged. This is what makes a store transparently
// readable across the plaintext→encrypted boundary.
func decryptValues(c *NodeCipher, values ...string) ([]string, error) {
	if c == nil {
		out := make([]string, len(values))
		copy(out, values)
		return out, nil
	}
	out := make([]string, len(values))
	for i, v := range values {
		dec, err := c.Decrypt(v)
		if err != nil {
			return nil, fmt.Errorf("decrypt field %d: %w", i, err)
		}
		out[i] = dec
	}
	return out, nil
}

// decryptNodeInplace seals nothing; it opens a freshly scanned Node's
// encrypted content/summary so the caller sees plaintext. On any field error
// the node is returned as-is and the error propagates — a tampered or
// key-rotated-away row must not silently degrade to ciphertext.
func decryptNodeInplace(n *Node, c *NodeCipher) error {
	if n == nil || c == nil {
		return nil
	}
	vals, err := decryptValues(c, n.Content, n.Summary)
	if err != nil {
		return err
	}
	n.Content = vals[0]
	n.Summary = vals[1]
	return nil
}

// decryptVersionInplace opens a NodeVersion's stored content (version history
// is encrypted alongside the live content so history does not leak).
func decryptVersionInplace(v *NodeVersion, c *NodeCipher) error {
	if v == nil || c == nil {
		return nil
	}
	vals, err := decryptValues(c, v.Content)
	if err != nil {
		return err
	}
	v.Content = vals[0]
	return nil
}

// keyVersionForWrite reports the encryption key version stamped into
// nodes.encryption_key_version for new writes, or 0 when encryption is
// disabled. nodes.encrypted is set in lockstep.
func keyVersionForWrite(c *NodeCipher) int {
	if c == nil {
		return 0
	}
	return c.KeyVersion()
}

// encryptedFlag returns the nodes.encrypted value for a write: true when the
// cipher is active, false for plaintext.
func encryptedFlag(c *NodeCipher) bool { return c != nil }
