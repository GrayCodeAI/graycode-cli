package engine

import (
	"context"
	"log/slog"
	"math"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// DecayConfig controls decay behaviour.
type DecayConfig struct {
	HalfLifeDays  float64 // default 30
	MinConfidence float64 // default 0.1 — below this, eligible for GC
	BoostOnAccess float64 // default 0.2
}

var DefaultDecayConfig = DecayConfig{
	HalfLifeDays:  30,
	MinConfidence: 0.1,
	BoostOnAccess: 0.2,
}

// RunDecay applies half-life decay to all nodes in the store.
// Orphan nodes (0 edges) and superseded nodes decay 2× faster.
// Processes nodes in pages to avoid loading the entire graph into memory.
func RunDecay(ctx context.Context, store storage.Storage, cfg DecayConfig) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	now := time.Now()
	const pageSize = 1000
	offset := 0
	for {
		nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: pageSize, Offset: offset})
		if err != nil {
			return err
		}
		if len(nodes) == 0 {
			break
		}

		// Batch edge counts for all nodes in this page to avoid N+1 queries.
		nodeIDs := make([]string, 0, len(nodes))
		for _, n := range nodes {
			if n.Confidence > 0 {
				nodeIDs = append(nodeIDs, n.ID)
			}
		}
		edgeCounts, _ := store.CountEdgesBatch(ctx, nodeIDs)

		for _, n := range nodes {
			if err := ctx.Err(); err != nil {
				return err
			}
			if n.Confidence <= 0 {
				continue // already archived
			}
			ref := n.UpdatedAt
			if !n.AccessedAt.IsZero() && n.AccessedAt.After(ref) {
				ref = n.AccessedAt
			}
			days := now.Sub(ref).Hours() / 24
			if days <= 0 {
				continue
			}
			multiplier := 1.0
			// Orphan nodes decay 2× faster — use batched edge counts
			counts := edgeCounts[n.ID]
			inbound, outbound := counts[0], counts[1]
			if inbound+outbound == 0 {
				multiplier = 2.0
			}
			// Superseded nodes decay 2× faster (only check edge types for relevant node types)
			if multiplier == 1.0 && (n.Type == "bug" || n.Type == "decision") {
				edges, _ := store.GetEdgesFrom(ctx, n.ID)
				for _, e := range edges {
					if e.Type == "supersedes" {
						multiplier = 2.0
						break
					}
				}
			}

			// Ebbinghaus decay formula: R = e^(-days / stability)
			stability := MemoryStability(cfg.HalfLifeDays, n.AccessCount, 0) / multiplier
			decay := EbbinghausRetention(days, stability)
			newConf := math.Max(n.Confidence*decay, 0)
			if newConf == n.Confidence {
				continue // no change, skip write
			}
			n.Confidence = newConf
			if err := store.UpdateNode(ctx, n); err != nil {
				return err
			}
		}
		if len(nodes) < pageSize {
			break
		}
		offset += pageSize
	}
	return nil
}

// GarbageCollect removes nodes below min_confidence (except anchors: file/entity).
// Processes nodes in pages to avoid loading the entire graph into memory.
// IDs are collected first, then deleted in a separate pass to avoid
// offset drift when rows shift during deletion.
func GarbageCollect(ctx context.Context, store storage.Storage, cfg DecayConfig) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}

	// Phase 1: collect all qualifying node IDs
	var toDelete []string
	const pageSize = 1000
	offset := 0
	for {
		nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: pageSize, Offset: offset})
		if err != nil {
			return 0, err
		}
		if len(nodes) == 0 {
			break
		}
		for _, n := range nodes {
			if err := ctx.Err(); err != nil {
				return 0, err
			}
			if n.Type == "file" || n.Type == "entity" {
				continue
			}
			if n.Confidence < cfg.MinConfidence {
				toDelete = append(toDelete, n.ID)
			}
		}
		if len(nodes) < pageSize {
			break
		}
		offset += pageSize
	}

	// Phase 2: delete all collected IDs
	removed := 0
	failed := 0
	for _, id := range toDelete {
		if err := ctx.Err(); err != nil {
			return removed, err
		}
		if err := store.DeleteNode(ctx, id); err != nil {
			failed++
			slog.Warn("gc: delete node failed", "node_id", id, "error", err)
			continue
		}
		removed++
	}
	if failed > 0 {
		slog.Error("gc: failed to delete nodes", "failed", failed, "removed", removed)
	}
	return removed, nil
}

// BoostNode increases confidence of a node on access (capped at 1.0).
func BoostNode(ctx context.Context, store storage.Storage, id string, boost float64) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	n, err := store.GetNode(ctx, id)
	if err != nil {
		return err
	}
	n.Confidence = math.Min(n.Confidence+boost, 1.0)
	n.AccessCount++
	n.AccessedAt = time.Now()
	return store.UpdateNode(ctx, n)
}
