package browse

import (
	"strings"
	"testing"
	"time"
)

func sampleMemories() []MemoryItem {
	now := time.Now()
	return []MemoryItem{
		{ID: "error-wrapping", Content: "Always wrap errors with context", Category: "conventions", Type: "", CreatedAt: now},
		{ID: "naming-style", Content: "Use camelCase for local vars", Category: "conventions", Type: "", CreatedAt: now},
		{ID: "test-patterns", Content: "Table-driven tests preferred", Category: "conventions", Type: "", CreatedAt: now},
		{ID: "use-jwt", Content: "Chose JWT for auth tokens", Category: "decisions", Type: "", CreatedAt: now},
		{ID: "chose-chi-router", Content: "Using chi over gin", Category: "decisions", Type: "", CreatedAt: now},
		{ID: "token-refresh-race", Content: "Race condition in token refresh", Category: "bugs", Type: "", CreatedAt: now},
		{ID: "deploy-flow", Content: "Deploy via CI pipeline", Category: "skills", Type: "", CreatedAt: now},
		{ID: "test-setup", Content: "Use testcontainers for integration", Category: "skills", Type: "", CreatedAt: now},
	}
}

func TestBuildFromMemories(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	if len(fs.Root.Children) != 4 {
		t.Fatalf("expected 4 top-level dirs, got %d", len(fs.Root.Children))
	}
}

func TestList(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	conventions := fs.List("/conventions")
	if conventions == nil {
		t.Fatal("expected non-nil for /conventions")
	}
	if len(conventions) != 3 {
		t.Errorf("expected 3 items in conventions, got %d", len(conventions))
	}

	// Root listing
	root := fs.List("/")
	if root == nil {
		t.Fatal("expected non-nil for /")
	}
	if len(root) != 4 {
		t.Errorf("expected 4 items at root, got %d", len(root))
	}

	// Non-existent path
	result := fs.List("/nonexistent")
	if result != nil {
		t.Errorf("expected nil for nonexistent path, got %v", result)
	}
}

func TestGet(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	node := fs.Get("/conventions/error-wrapping")
	if node == nil {
		t.Fatal("expected non-nil for /conventions/error-wrapping")
	}
	if node.Content != "Always wrap errors with context" {
		t.Errorf("unexpected content: %q", node.Content)
	}
	if node.Type != "file" {
		t.Errorf("expected type 'file', got %q", node.Type)
	}

	// Get directory
	dir := fs.Get("/decisions")
	if dir == nil {
		t.Fatal("expected non-nil for /decisions")
	}
	if dir.Type != "dir" {
		t.Errorf("expected type 'dir', got %q", dir.Type)
	}
}

func TestTree(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	tree := fs.Tree("/", 0)
	if !strings.Contains(tree, "conventions/") {
		t.Error("expected tree to contain 'conventions/'")
	}
	if !strings.Contains(tree, "error-wrapping") {
		t.Error("expected tree to contain 'error-wrapping'")
	}
	if !strings.Contains(tree, "├──") || !strings.Contains(tree, "└──") {
		t.Error("expected tree connectors")
	}

	// Depth-limited tree
	shallow := fs.Tree("/", 1)
	// At depth 1, we should see top-level dirs but not their children.
	if strings.Contains(shallow, "error-wrapping") {
		t.Error("depth 1 tree should not show files inside dirs")
	}
}

func TestSearch(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	results := fs.Search("jwt")
	if len(results) != 1 {
		t.Fatalf("expected 1 search result for 'jwt', got %d", len(results))
	}
	if results[0].MemoryID != "use-jwt" {
		t.Errorf("expected use-jwt, got %q", results[0].MemoryID)
	}

	// Case-insensitive search
	results2 := fs.Search("RACE")
	if len(results2) != 1 {
		t.Fatalf("expected 1 result for 'RACE', got %d", len(results2))
	}
}

func TestAdd(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	err := fs.Add("/conventions/logging-style", MemoryItem{
		ID:        "logging-style",
		Content:   "Use structured logging",
		Category:  "conventions",
		CreatedAt: time.Now(),
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	node := fs.Get("/conventions/logging-style")
	if node == nil {
		t.Fatal("expected to find added node")
	}
	if node.Content != "Use structured logging" {
		t.Errorf("unexpected content: %q", node.Content)
	}

	// Adding to non-existent intermediate path should auto-create dirs.
	err = fs.Add("/new-category/sub/my-item", MemoryItem{
		ID:      "my-item",
		Content: "Some content",
	})
	if err != nil {
		t.Fatalf("unexpected error creating nested path: %v", err)
	}
	got := fs.Get("/new-category/sub/my-item")
	if got == nil {
		t.Fatal("expected to find deeply nested item")
	}

	// Duplicate add should fail.
	err = fs.Add("/conventions/logging-style", MemoryItem{ID: "logging-style"})
	if err == nil {
		t.Error("expected error on duplicate add")
	}
}

func TestRemove(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()
	fs.BuildFromMemories(sampleMemories())

	err := fs.Remove("/conventions/error-wrapping")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	node := fs.Get("/conventions/error-wrapping")
	if node != nil {
		t.Error("expected node to be removed")
	}

	// Remove non-existent should fail.
	err = fs.Remove("/conventions/nonexistent")
	if err == nil {
		t.Error("expected error on removing nonexistent node")
	}

	// Remove root should fail.
	err = fs.Remove("/")
	if err == nil {
		t.Error("expected error on removing root")
	}
}

func TestBuildFromMemoriesWithTypes(t *testing.T) {
	t.Parallel()
	now := time.Now()
	memories := []MemoryItem{
		{ID: "item1", Content: "content1", Category: "cat", Type: "subtype", CreatedAt: now},
		{ID: "item2", Content: "content2", Category: "cat", Type: "subtype", CreatedAt: now},
	}

	fs := NewMemoryFS()
	fs.BuildFromMemories(memories)

	// Should create cat/subtype/ directory structure.
	items := fs.List("/cat/subtype")
	if len(items) != 2 {
		t.Errorf("expected 2 items under /cat/subtype, got %d", len(items))
	}
}

func TestEmptyFS(t *testing.T) {
	t.Parallel()
	fs := NewMemoryFS()

	root := fs.List("/")
	if root == nil {
		t.Fatal("root should exist even when empty")
	}
	if len(root) != 0 {
		t.Errorf("expected 0 children in empty FS, got %d", len(root))
	}

	tree := fs.Tree("/", 0)
	if !strings.Contains(tree, "/") {
		t.Error("tree of empty FS should still show root")
	}
}
