// Package portablegraph provides graph-based execution journaling for harrier.
package portablegraph

import (
	"encoding/json"
	"fmt"
	"sync"
	"time"

	graphcontracts "github.com/GrayCodeAI/harrier/portablegraph/graph"
)

// PortableNode represents a portable graph node.
type PortableNode struct {
	ID          string                 `json:"id"`
	Type        string                 `json:"type"`
	Name        string                 `json:"name"`
	Description string                 `json:"description,omitempty"`
	Attrs       map[string]interface{} `json:"attrs,omitempty"`
	CreatedAt   time.Time              `json:"created_at"`
	UpdatedAt   time.Time              `json:"updated_at"`
}

// PortableEdge represents a portable graph edge.
type PortableEdge struct {
	ID        string                 `json:"id"`
	From      string                 `json:"from"`
	To        string                 `json:"to"`
	Kind      string                 `json:"kind"` // "depends_on", "produced", "references"
	Weight    float64                `json:"weight"`
	Attrs     map[string]interface{} `json:"attrs,omitempty"`
	CreatedAt time.Time              `json:"created_at"`
}

// PortableGraph represents a portable, serializable graph.
type PortableGraph struct {
	mu    sync.RWMutex
	ID    string                   `json:"id"`
	Name  string                   `json:"name"`
	Nodes map[string]*PortableNode `json:"nodes"`
	Edges []PortableEdge           `json:"edges"`
	Attrs map[string]interface{}   `json:"attrs,omitempty"`
}

// NewPortableGraph creates a new portable graph.
func NewPortableGraph(id, name string) *PortableGraph {
	return &PortableGraph{
		ID:    id,
		Name:  name,
		Nodes: make(map[string]*PortableNode),
		Attrs: make(map[string]interface{}),
	}
}

// AddNode adds a node to the graph.
func (g *PortableGraph) AddNode(node *PortableNode) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if node.CreatedAt.IsZero() {
		node.CreatedAt = time.Now()
	}
	node.UpdatedAt = time.Now()
	g.Nodes[node.ID] = node
}

// AddEdge adds an edge to the graph.
func (g *PortableGraph) AddEdge(edge *PortableEdge) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if edge.CreatedAt.IsZero() {
		edge.CreatedAt = time.Now()
	}
	g.Edges = append(g.Edges, *edge)
}

// GetNode retrieves a node by ID.
func (g *PortableGraph) GetNode(id string) (*PortableNode, bool) {
	g.mu.RLock()
	defer g.mu.RUnlock()
	node, ok := g.Nodes[id]
	return node, ok
}

// GetNodes returns all nodes.
func (g *PortableGraph) GetNodes() []*PortableNode {
	g.mu.RLock()
	defer g.mu.RUnlock()
	result := make([]*PortableNode, 0, len(g.Nodes))
	for _, node := range g.Nodes {
		result = append(result, node)
	}
	return result
}

// GetEdges returns all edges.
func (g *PortableGraph) GetEdges() []PortableEdge {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return g.Edges
}

// ToJSON serializes the graph to JSON.
func (g *PortableGraph) ToJSON() ([]byte, error) {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return json.Marshal(g)
}

// FromJSON deserializes a graph from JSON.
func FromJSON(data []byte) (*PortableGraph, error) {
	var g PortableGraph
	if err := json.Unmarshal(data, &g); err != nil {
		return nil, fmt.Errorf("failed to deserialize graph: %w", err)
	}
	return &g, nil
}

// ToGraphSpec converts the portable graph to a portable graph spec.
func (g *PortableGraph) ToGraphSpec() *graphcontracts.GraphSpec {
	g.mu.RLock()
	defer g.mu.RUnlock()

	nodes := make([]graphcontracts.NodeSpec, 0, len(g.Nodes))
	for id, node := range g.Nodes {
		config := make(map[string]string)
		for k, v := range node.Attrs {
			config[k] = fmt.Sprintf("%v", v)
		}
		config["name"] = node.Name
		config["type"] = node.Type

		nodes = append(nodes, graphcontracts.NodeSpec{
			ID:     id,
			Name:   node.Name,
			Config: config,
		})
	}

	edges := make([]graphcontracts.EdgeSpec, 0, len(g.Edges))
	for _, edge := range g.Edges {
		edges = append(edges, graphcontracts.EdgeSpec{
			From:   edge.From,
			To:     edge.To,
			Weight: edge.Weight,
		})
	}

	return &graphcontracts.GraphSpec{
		ID:    g.ID,
		Name:  g.Name,
		Nodes: nodes,
		Edges: edges,
	}
}

// Export exports the graph as a map.
func (g *PortableGraph) Export() map[string]interface{} {
	g.mu.RLock()
	defer g.mu.RUnlock()

	return map[string]interface{}{
		"id":    g.ID,
		"name":  g.Name,
		"nodes": g.Nodes,
		"edges": g.Edges,
		"attrs": g.Attrs,
	}
}
