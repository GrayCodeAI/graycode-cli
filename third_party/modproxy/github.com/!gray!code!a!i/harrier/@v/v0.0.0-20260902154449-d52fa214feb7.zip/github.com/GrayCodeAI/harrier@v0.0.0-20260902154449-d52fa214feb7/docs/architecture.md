<div align="center">

# 🧠 harrier Architecture

**Graph-Native Persistent Memory for Coding Agents**

[![Go](https://img.shields.io/badge/Go-1.26+-00ADD8?logo=go)](https://go.dev/)
[![Port](https://img.shields.io/badge/Port-3456-orange)]()
[![Protocol](https://img.shields.io/badge/REST-SSE-MCP-blue)]()

</div>

---

## 🎯 Overview

harrier (याद, "memory") is the graph-native persistent memory service for the hawk ecosystem. It stores **decisions**, **bugs**, **conventions**, **tasks**, and **skills** as nodes in a knowledge graph with typed edges — giving coding agents persistent memory across sessions.

> 💡 One config line to enable. Zero setup. Works with any MCP agent.

---

## 🧱 Components

```
harrier/
├── cmd/harrier/                ⚡ CLI — serve, mcp, tui, doctor
├── api/
│   ├── openapi.yaml         📜 REST API contract (OpenAPI 3.1)
│   └── proto/
│       ├── harrier.proto       🔗 Planned gRPC service definition
│       └── buf.yaml         🐃 buf v2 module config
├── engine/
│   ├── engine_core.go       🧠 Facade: Remember, Recall, Context, Feedback
│   ├── remember.go          📥 Node ingestion + entity extraction
│   ├── recall.go            🔍 BM25 + vector + graph + temporal search
│   ├── fused_recall.go      🔀 RRF fusion of 4 search paths
│   ├── context.go           📦 Tiered context pack generation
│   ├── decay.go             📉 Confidence decay over time
│   ├── selflink.go          🔗 Async relationship discovery
│   └── entities.go          🏷️ Entity extraction from content
├── graph/
│   ├── graph.go             🕸️ Graph operations (BFS, path finding)
│   ├── community.go         👥 Community detection
│   └── drift_search.go      🌊 Semantic drift detection
├── storage/
│   ├── interface.go         📋 Store interface
│   └── sqlite.go            🗄️ SQLite + FTS5 implementation
├── hooks/                   🪝 Session lifecycle hooks
├── skill/                   🎯 Procedural memory (skills as nodes)
├── config/                  ⚙️ TOML config loading
├── internal/
│   ├── server/              🌐 HTTP + MCP server handlers
│   ├── daemon/              🔮 Daemon lifecycle management
│   ├── search/              🔍 Search subsystem internals
│   ├── telemetry/           📊 OpenTelemetry instrumentation
│   └── temporal/            ⏰ Time-aware graph queries
└── sdk/
    ├── python/              🐍 Python SDK (PyPI: harrier-sdk)
    └── typescript/          📘 TypeScript SDK (npm: @harrier/sdk)
```

---

## 🌐 Interfaces

### REST API (:3456)

| | |
|---|---|
| **Contract** | [`api/openapi.yaml`](../api/openapi.yaml) |
| **Port** | `:3456` (default). Override: `HARRIER_ADDR=host:port` |
| **Auth** | Bearer token or `X-API-Key`. Set via `HARRIER_API_KEY` |

<details>
<summary><b>📡 REST Endpoint Summary</b></summary>

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/harrier/remember` | 📥 Store a memory node |
| `POST` | `/harrier/recall` | 🔍 Graph-aware search |
| `POST` | `/harrier/hybrid-recall` | 🔀 4-path search with RRF fusion |
| `GET` | `/harrier/context` | 📦 Session-start context pack |
| `GET` | `/harrier/node/{id}` | 🔍 Get node and neighbors |
| `POST` | `/harrier/link` | 🔗 Create edge between nodes |
| `GET` | `/harrier/subgraph/{id}` | 🕸️ BFS subgraph |
| `GET` | `/harrier/impact/{file}` | 💥 Impact analysis for file change |
| `POST` | `/harrier/session/start` | 🚀 Start session (triggers decay) |
| `GET` | `/harrier/events` | 📡 SSE stream of memory changes |
| `GET` | `/harrier/health` | 🩺 Health check |

</details>

### gRPC (planned, not implemented)

| | |
|---|---|
The protobuf definition at [`api/proto/harrier.proto`](../api/proto/harrier.proto)
is a design contract only. There is no generated Go service or listening gRPC
server in the current repository. Live streaming is implemented over SSE at
`/harrier/stream/memories`, `/harrier/stream/stale`, and `/harrier/watch`.

### MCP Server (stdio / HTTP)

```bash
harrier mcp              # 📡 stdio transport (for agent config)
harrier mcp --http :8080 # 🌐 HTTP transport
```

**27 MCP tools** including: `harrier_remember`, `harrier_recall`, `harrier_context`, `harrier_forget`, `harrier_link`, `harrier_subgraph`, `harrier_impact`, `harrier_compact`, `harrier_pin`

---

## 🕸️ Memory Graph

| Node Types | Edge Types | Scopes |
|------------|------------|--------|
| `convention` | `led_to` | `project` (per-repo) |
| `decision` | `supersedes` | `global` (cross-repo) |
| `task` | `caused_by` | |
| `bug` | `touches` | |
| `preference` | `implements` | |
| `spec` | `blocks`, `related_to`, `mentions` | |

---

## 🔀 4-Path Hybrid Recall

Recall fuses four search strategies with **Reciprocal Rank Fusion (RRF)**:

| # | Strategy | Description |
|---|----------|-------------|
| 1 | 📄 **BM25** | Full-text keyword search via SQLite FTS5 |
| 2 | 📐 **Vector** | Cosine similarity on embeddings |
| 3 | 🕸️ **Graph** | Intent-aware relationship traversal |
| 4 | ⏰ **Temporal** | Recency + access frequency weighting |

```
BM25 ──┐
Vector ──┤
Graph  ──┼──▶ RRF Fusion ──▶ Ranked Results
Temporal─┘
```
