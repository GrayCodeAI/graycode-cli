package storage

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestScheduleBackupsValidation(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	dir := t.TempDir()
	cases := []struct {
		name     string
		interval time.Duration
		keep     int
		maxAge   time.Duration
		wantErr  bool
	}{
		{"valid", time.Hour, 3, time.Hour, false},
		{"zero-interval", 0, 3, 0, true},
		{"negative-interval", -time.Minute, 3, 0, true},
		{"negative-keep", time.Hour, -1, 0, true},
		{"negative-maxage", time.Hour, 0, -time.Hour, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			_, err := s.ScheduleBackups(dir, tc.interval, tc.keep, tc.maxAge)
			if (err != nil) != tc.wantErr {
				t.Fatalf("ScheduleBackups err = %v, wantErr = %v", err, tc.wantErr)
			}
		})
	}
}

func TestSchedulerRunNowAndRotation(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{
		ID: "sched-node", Type: "convention", Content: "schedule me",
		ContentHash: "h-sched", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}

	dir := t.TempDir()
	sched, err := s.ScheduleBackups(dir, time.Hour, 2, 0)
	if err != nil {
		t.Fatal(err)
	}

	for i := 0; i < 3; i++ {
		if err := sched.RunNow(ctx); err != nil {
			t.Fatalf("RunNow #%d: %v", i, err)
		}
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) != 2 {
		t.Fatalf("expected rotation to keep 2 backups, got %d", len(entries))
	}

	// Each backup must be a consistent, openable snapshot.
	for _, e := range entries {
		restore, err := NewStore(filepath.Join(dir, e.Name()))
		if err != nil {
			t.Fatalf("open backup %s: %v", e.Name(), err)
		}
		if _, err := restore.GetNode(ctx, "sched-node"); err != nil {
			t.Errorf("backup %s missing sched-node: %v", e.Name(), err)
		}
		_ = restore.Close()
	}
}

func TestSchedulerStartStop(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	dir := t.TempDir()

	sched, err := s.ScheduleBackups(dir, 20*time.Millisecond, 5, 0)
	if err != nil {
		t.Fatal(err)
	}
	sched.Start()

	// Several ticks produce at least one backup.
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		entries, _ := os.ReadDir(dir)
		if len(entries) > 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(entries) == 0 {
		t.Fatal("expected at least one backup after Start")
	}

	sched.Stop()
	// Stopping twice is a no-op, and stopping never panics.
	sched.Stop()
}

func TestSchedulerStopWithoutStart(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()

	sched, err := s.ScheduleBackups(t.TempDir(), time.Hour, 1, 0)
	if err != nil {
		t.Fatal(err)
	}
	sched.Stop() // must not deadlock or panic
	sched.Stop()
	sched.Start() // Start after Stop is a no-op
}

func TestScheduleBackupsEmptyDir(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	if _, err := s.ScheduleBackups("", time.Hour, 1, 0); err == nil {
		t.Fatal("expected error for empty backup directory")
	}
}

// TestSchedulerStatusTracksFailures verifies the scheduler surfaces snapshot
// failures instead of discarding them: a successful RunNow updates
// LastSuccessAt/Snapshots, and a failing RunNow records LastError and bumps
// Failures.
func TestSchedulerStatusTracksFailures(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	dir := filepath.Join(t.TempDir(), "backups")
	sched, err := s.ScheduleBackups(dir, time.Hour, 0, 0)
	if err != nil {
		t.Fatalf("ScheduleBackups: %v", err)
	}

	if st := sched.Status(); st.Snapshots != 0 || st.Failures != 0 || st.LastError != nil || !st.LastSuccessAt.IsZero() {
		t.Fatalf("fresh scheduler status = %+v, want zero values", st)
	}

	if err := sched.RunNow(ctx); err != nil {
		t.Fatalf("RunNow: %v", err)
	}
	st := sched.Status()
	if st.Snapshots != 1 || st.Failures != 0 || st.LastError != nil {
		t.Errorf("after success: %+v, want Snapshots=1 Failures=0 LastError=nil", st)
	}
	if st.LastSuccessAt.IsZero() {
		t.Error("LastSuccessAt not set after successful snapshot")
	}

	// Make the directory unwritable so the snapshot fails.
	if err := os.Chmod(dir, 0o500); err != nil {
		t.Fatalf("chmod dir read-only: %v", err)
	}
	defer func() { _ = os.Chmod(dir, 0o700) }()

	if err := sched.RunNow(ctx); err == nil {
		t.Fatal("expected RunNow to fail with unwritable backup dir")
	}
	st = sched.Status()
	if st.Failures != 1 || st.LastError == nil || st.LastErrorAt.IsZero() {
		t.Errorf("after failure: %+v, want Failures=1 LastError set LastErrorAt set", st)
	}
	if st.Snapshots != 1 {
		t.Errorf("Snapshots = %d, want still 1", st.Snapshots)
	}
}
