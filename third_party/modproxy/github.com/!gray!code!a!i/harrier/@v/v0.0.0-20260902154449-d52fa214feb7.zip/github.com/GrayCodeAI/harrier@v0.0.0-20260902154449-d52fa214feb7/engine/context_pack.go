package engine

import (
	"fmt"
	"regexp"
	"sort"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// ContextPacker optimizes what gets injected into an agent's context window.
// Packs maximum information density within a token budget by:
//   - Prioritizing by PageRank importance + confidence + recency
//   - Deduplicating similar content
//   - Compressing verbose memories into concise forms
//   - Respecting type quotas (max N conventions, M decisions, etc.)
type ContextPacker struct {
	budget     int
	typeQuotas map[string]int
}

// PackedContext is the optimized output ready for prompt injection.
type PackedContext struct {
	Content    string
	TokensUsed int
	NodesUsed  int
	TypeCounts map[string]int
}

// NewContextPacker creates a packer with the given token budget.
func NewContextPacker(budget int) *ContextPacker {
	if budget <= 0 {
		budget = 2000
	}
	return &ContextPacker{
		budget: budget,
		typeQuotas: map[string]int{
			"convention": 8,
			"decision":   6,
			"spec":       4,
			"bug":        4,
			"task":       4,
			"preference": 3,
			"skill":      2,
			"file":       3,
		},
	}
}

// Pack selects and formats the optimal subset of nodes for the context window.
func (cp *ContextPacker) Pack(nodes []*storage.Node) *PackedContext {
	if len(nodes) == 0 {
		return &PackedContext{TypeCounts: map[string]int{}}
	}

	// Sort by priority: pinned first, then by confidence × accessCount
	sort.Slice(nodes, func(i, j int) bool {
		return cp.priority(nodes[i]) > cp.priority(nodes[j])
	})

	result := &PackedContext{TypeCounts: make(map[string]int)}
	var sb strings.Builder
	tokensUsed := 0
	typeCounts := make(map[string]int)
	seen := make(map[string]bool)

	for _, n := range nodes {
		// Check type quota
		quota := cp.typeQuotas[n.Type]
		if quota > 0 && typeCounts[n.Type] >= quota {
			continue
		}

		// Deduplicate by content similarity
		contentKey := strings.ToLower(n.Content)
		if len(contentKey) > 50 {
			contentKey = contentKey[:50]
		}
		if seen[contentKey] {
			continue
		}
		seen[contentKey] = true

		// Format and check budget
		line := cp.formatNode(n)
		lineTokens := estimateTokens(line)

		if tokensUsed+lineTokens > cp.budget {
			break
		}

		sb.WriteString(line)
		sb.WriteString("\n")
		tokensUsed += lineTokens
		typeCounts[n.Type]++
		result.NodesUsed++
	}

	result.Content = sb.String()
	result.TokensUsed = tokensUsed
	result.TypeCounts = typeCounts
	return result
}

func (cp *ContextPacker) priority(n *storage.Node) float64 {
	score := n.Confidence
	if n.Pinned {
		score += 5.0
	}
	score += float64(n.AccessCount) * 0.1
	// Type priority
	switch n.Type {
	case "convention":
		score += 1.0
	case "decision":
		score += 0.8
	case "spec":
		score += 0.6
	case "bug":
		score += 0.4
	}
	return score
}

func (cp *ContextPacker) formatNode(n *storage.Node) string {
	content := n.Content
	// Compress long content
	if len(content) > 120 {
		content = content[:120] + "..."
	}
	return fmt.Sprintf("- [%s] %s", n.Type, content)
}

// ConversationSummarizer compresses multi-turn conversations into single memories.
// Used when ingesting long transcripts — extracts the key takeaways.
type ConversationSummarizer struct{}

// Summarize extracts key points from a conversation into concise memories.
func (cs *ConversationSummarizer) Summarize(conversation string, maxMemories int) []SummarizedMemory {
	if maxMemories <= 0 {
		maxMemories = 10
	}

	var memories []SummarizedMemory
	lines := strings.Split(conversation, "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if len(line) < 20 {
			continue
		}

		nodeType := classifyContent(line)
		if nodeType == "" {
			continue
		}

		// Compress the line
		content := line
		if len(content) > 150 {
			content = content[:150]
		}

		memories = append(memories, SummarizedMemory{
			Content: content,
			Type:    nodeType,
		})

		if len(memories) >= maxMemories {
			break
		}
	}

	return memories
}

// SummarizedMemory is a compressed memory extracted from conversation.
type SummarizedMemory struct {
	Content string
	Type    string
}

var (
	classifyConventionRe = regexp.MustCompile(`(?i)(always|never|must|should|prefer|avoid|use .+ instead|don't|do not|convention|rule|standard)`)
	classifyDecisionRe   = regexp.MustCompile(`(?i)(decided|chose|picked|selected|went with|switched to|migrated|adopted|we use)`)
	classifyBugRe        = regexp.MustCompile(`(?i)(bug|fix|issue|error|broken|crash|race condition|deadlock|leak|regression)`)
	classifyTaskRe       = regexp.MustCompile(`(?i)(todo|TODO|FIXME|HACK|in progress|need to|should implement|blocked)`)
	classifyPrefRe       = regexp.MustCompile(`(?i)(i prefer|i like|my style|i want|personally|i always)`)
)

// classifyContent maps a line of conversation to a memory node type based on
// keyword heuristics. Returns "" when no type matches.
func classifyContent(text string) string {
	switch {
	case classifyDecisionRe.MatchString(text):
		return "decision"
	case classifyConventionRe.MatchString(text):
		return "convention"
	case classifyBugRe.MatchString(text):
		return "bug"
	case classifyTaskRe.MatchString(text):
		return "task"
	case classifyPrefRe.MatchString(text):
		return "preference"
	default:
		return ""
	}
}
