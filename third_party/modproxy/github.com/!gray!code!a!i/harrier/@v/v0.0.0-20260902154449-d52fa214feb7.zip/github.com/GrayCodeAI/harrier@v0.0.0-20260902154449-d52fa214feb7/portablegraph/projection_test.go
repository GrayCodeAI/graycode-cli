package portablegraph

import (
	"encoding/json"
	"strings"
	"testing"
	"time"

	graphcontracts "github.com/GrayCodeAI/harrier/portablegraph/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func TestBuildProjectsRetrievedMemorySubgraphWithoutPayloads(t *testing.T) {
	t.Parallel()

	generatedAt := time.Date(2026, time.July, 25, 5, 0, 0, 0, time.UTC)
	first := &storage.Node{
		ID:            "memory-1",
		Type:          "decision",
		Content:       "private decision content",
		Scope:         "project",
		Project:       "private project",
		Confidence:    0.9,
		Tier:          1,
		Pinned:        true,
		CreatedAt:     generatedAt.Add(-time.Hour),
		UpdatedAt:     generatedAt.Add(-time.Minute),
		SourceSession: "private session",
		SourceAgent:   "private agent",
		Version:       2,
	}
	second := &storage.Node{
		ID:         "memory-2",
		Type:       "file",
		Content:    "private file content",
		Confidence: 0.8,
		CreatedAt:  generatedAt.Add(-30 * time.Minute),
	}
	relation := &storage.Edge{
		ID:        "relation-1",
		FromID:    first.ID,
		ToID:      second.ID,
		Type:      "touches",
		Weight:    0.7,
		CreatedAt: generatedAt.Add(-20 * time.Minute),
	}

	export, err := Build(Input{
		Nodes:           []*storage.Node{second, first},
		Edges:           []*storage.Edge{relation},
		Query:           "private retrieval query",
		GeneratedAt:     generatedAt,
		Scope:           graphcontracts.Scope{RepositoryID: "hawk"},
		ProducerVersion: "test",
	})
	if err != nil {
		t.Fatalf("Build() error = %v", err)
	}
	if export.SchemaVersion != SchemaVersion {
		t.Fatalf("SchemaVersion = %q, want %q", export.SchemaVersion, SchemaVersion)
	}
	if len(export.Nodes) != 2 || len(export.Edges) != 1 || len(export.Events) != 2 {
		t.Fatalf("projection sizes = nodes:%d edges:%d events:%d", len(export.Nodes), len(export.Edges), len(export.Events))
	}
	if export.Edges[0].Kind != graphcontracts.EdgeReferences {
		t.Fatalf("edge kind = %q, want references", export.Edges[0].Kind)
	}

	encoded, err := json.Marshal(export)
	if err != nil {
		t.Fatalf("json.Marshal() error = %v", err)
	}
	for _, secret := range []string{
		"private decision content",
		"private file content",
		"private project",
		"private session",
		"private agent",
		"private retrieval query",
	} {
		if strings.Contains(string(encoded), secret) {
			t.Fatalf("portable graph leaked %q", secret)
		}
	}
}

func TestBuildRejectsDanglingRetrievedEdge(t *testing.T) {
	t.Parallel()

	_, err := Build(Input{
		Nodes: []*storage.Node{{ID: "memory-1"}},
		Edges: []*storage.Edge{{
			ID:     "edge-1",
			FromID: "memory-1",
			ToID:   "missing",
		}},
		GeneratedAt: time.Date(2026, time.July, 25, 6, 0, 0, 0, time.UTC),
	})
	if err == nil || !strings.Contains(err.Error(), "outside the retrieved subgraph") {
		t.Fatalf("Build() error = %v, want dangling-edge error", err)
	}
}

func TestBuildRequiresGeneratedTime(t *testing.T) {
	t.Parallel()
	if _, err := Build(Input{}); err == nil {
		t.Fatal("Build() error = nil, want generated-time error")
	}
}
