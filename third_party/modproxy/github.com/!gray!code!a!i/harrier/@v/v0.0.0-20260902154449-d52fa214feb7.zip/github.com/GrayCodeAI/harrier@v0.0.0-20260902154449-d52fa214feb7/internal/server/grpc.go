package server

import (
	"context"
	"crypto/subtle"
	"fmt"
	"net"
	"strings"
	"time"

	harrierversion "github.com/GrayCodeAI/harrier"
	harrierproto "github.com/GrayCodeAI/harrier/api/proto"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
)

// GrpcServer implements harrierproto.HarrierServiceServer, the gRPC counterpart to
// RESTServer and MCPServer — all three are thin adapters over the same
// *engine.Engine. Unlike REST/MCP, streaming (WatchMemories/WatchStale) is
// only available if a broadcaster is supplied; without one those two RPCs
// return Unavailable, mirroring REST's 503 when streaming isn't enabled.
type GrpcServer struct {
	harrierproto.UnimplementedHarrierServiceServer

	eng         *engine.Engine
	broadcaster *SSEBroadcaster     // nil = WatchMemories/WatchStale disabled
	limiter     *engine.RateLimiter // rate limiter for destructive operations, mirrors RESTServer
	apiKey      string              // if non-empty, clients must present matching Bearer or x-api-key

	srv *grpc.Server
}

// NewGrpcServer creates a gRPC server backed by eng. broadcaster may be nil,
// in which case WatchMemories and WatchStale return Unavailable.
func NewGrpcServer(eng *engine.Engine, broadcaster *SSEBroadcaster) *GrpcServer {
	return &GrpcServer{
		eng:         eng,
		broadcaster: broadcaster,
		limiter:     engine.NewRateLimiter(10, 20), // 10 req/sec, burst 20 — matches RESTServer
	}
}

// WithAPIKey configures API-key authentication. When the key is non-empty,
// every unary RPC must present a matching token via the "authorization"
// metadata (Bearer <token>) or the "x-api-key" header. If the key does not
// match, the call returns codes.Unauthenticated.
func (s *GrpcServer) WithAPIKey(apiKey string) *GrpcServer {
	s.apiKey = apiKey
	return s
}

// authInterceptor returns a unary interceptor that enforces API‑key auth when
// s.apiKey is set. Health checks are always allowed through.
func (s *GrpcServer) authInterceptor(ctx context.Context, req any, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (any, error) {
	if s.apiKey == "" {
		return handler(ctx, req)
	}
	if info.FullMethod == "/harrier.v1.HarrierService/Health" ||
		info.FullMethod == "/harrier.v1.HarrierService/GraphStats" {
		return handler(ctx, req)
	}

	token := extractToken(ctx)
	if token == "" || subtle.ConstantTimeCompare([]byte(token), []byte(s.apiKey)) != 1 {
		return nil, status.Error(codes.Unauthenticated, "invalid or missing API key")
	}
	return handler(ctx, req)
}

// extractToken pulls the bearer token from grpc metadata. Checks both
// "authorization: Bearer <token>" and "x-api-key: <token>" headers.
func extractToken(ctx context.Context) string {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return ""
	}
	// authorization: Bearer <token>
	auth := md.Get("authorization")
	for _, v := range auth {
		if strings.HasPrefix(v, "Bearer ") {
			return strings.TrimPrefix(v, "Bearer ")
		}
	}
	// x-api-key header
	keys := md.Get("x-api-key")
	if len(keys) > 0 {
		return keys[0]
	}
	return ""
}

// ListenAndServe starts the gRPC server on addr. Blocks until the server
// stops (via Shutdown or a fatal error).
func (s *GrpcServer) ListenAndServe(addr string) error {
	lis, err := net.Listen("tcp", addr)
	if err != nil {
		return fmt.Errorf("harrier grpc: listen on %s: %w", addr, err)
	}
	opts := []grpc.ServerOption{}
	if s.apiKey != "" {
		opts = append(opts, grpc.UnaryInterceptor(s.authInterceptor))
	}
	s.srv = grpc.NewServer(opts...)
	harrierproto.RegisterHarrierServiceServer(s.srv, s)
	fmt.Printf("harrier gRPC API listening on %s\n", addr)
	return s.srv.Serve(lis)
}

// Shutdown gracefully stops the gRPC server. Unlike grpc.Server.GracefulStop
// (which has no timeout), this respects ctx's deadline by falling back to a
// hard Stop if graceful shutdown doesn't finish in time.
func (s *GrpcServer) Shutdown(ctx context.Context) error {
	if s.srv == nil {
		return nil
	}
	done := make(chan struct{})
	go func() {
		s.srv.GracefulStop()
		close(done)
	}()
	select {
	case <-done:
		return nil
	case <-ctx.Done():
		s.srv.Stop()
		return ctx.Err()
	}
}

func (s *GrpcServer) rateLimit() error {
	if s.limiter != nil && !s.limiter.Allow() {
		return status.Error(codes.ResourceExhausted, "rate limit exceeded, try again later")
	}
	return nil
}

// --- unary RPCs -------------------------------------------------------

func (s *GrpcServer) Remember(ctx context.Context, req *harrierproto.RememberRequest) (*harrierproto.RememberResponse, error) {
	in := engine.RememberInput{
		Content: req.GetContent(),
		Type:    req.GetCategory(),
		Scope:   req.GetScope(),
		Project: req.GetProject(),
		Tags:    strings.Join(req.GetTags(), ","),
	}
	if in.Type != "" && !engine.IsValidNodeType(in.Type) {
		return nil, status.Errorf(codes.InvalidArgument, "invalid node type: %q", in.Type)
	}
	node, err := s.eng.Remember(ctx, in)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "remember: %v", err)
	}
	return &harrierproto.RememberResponse{
		NodeId:  node.ID,
		Created: node.Version == 1, // see engine.Remember: Version 1 = newly created, >1 = upsert/update
	}, nil
}

func (s *GrpcServer) Recall(ctx context.Context, req *harrierproto.RecallRequest) (*harrierproto.RecallResponse, error) {
	result, err := s.eng.Recall(ctx, engine.RecallOpts{
		Query:   req.GetQuery(),
		Budget:  int(req.GetTokenBudget()),
		Project: req.GetProject(),
	})
	if err != nil {
		return nil, status.Errorf(codes.Internal, "recall: %v", err)
	}
	text := renderContextText(result.Nodes)
	return &harrierproto.RecallResponse{
		Context:    text,
		Nodes:      nodesToProto(result.Nodes),
		TokensUsed: roughTokenCount(text),
	}, nil
}

func (s *GrpcServer) Context(ctx context.Context, req *harrierproto.ContextRequest) (*harrierproto.ContextResponse, error) {
	result, err := s.eng.Context(ctx, req.GetProject())
	if err != nil {
		return nil, status.Errorf(codes.Internal, "context: %v", err)
	}
	text := renderContextText(result.Nodes)
	sources := make([]string, 0, len(result.Nodes))
	for _, n := range result.Nodes {
		sources = append(sources, n.ID)
	}
	return &harrierproto.ContextResponse{
		Context:    text,
		TokensUsed: roughTokenCount(text),
		Sources:    sources,
	}, nil
}

func (s *GrpcServer) Forget(ctx context.Context, req *harrierproto.ForgetRequest) (*harrierproto.ForgetResponse, error) {
	if err := s.rateLimit(); err != nil {
		return nil, err
	}
	if err := s.eng.Forget(ctx, req.GetNodeId()); err != nil {
		return nil, status.Errorf(codes.NotFound, "forget: %v", err)
	}
	return &harrierproto.ForgetResponse{Deleted: true}, nil
}

func (s *GrpcServer) Link(ctx context.Context, req *harrierproto.LinkRequest) (*harrierproto.LinkResponse, error) {
	if req.GetType() == "" {
		return nil, status.Error(codes.InvalidArgument, "edge type is required")
	}
	if !graph.IsValidEdgeType(req.GetType()) {
		return nil, status.Errorf(codes.InvalidArgument, "invalid edge type: %q", req.GetType())
	}
	edge := &storage.Edge{
		ID:     uuid.New().String(),
		FromID: req.GetFromId(),
		ToID:   req.GetToId(),
		Type:   req.GetType(),
	}
	if err := s.eng.Graph().AddEdge(ctx, edge); err != nil {
		return nil, status.Errorf(codes.InvalidArgument, "link: %v", err)
	}
	return &harrierproto.LinkResponse{EdgeId: edge.ID}, nil
}

func (s *GrpcServer) Unlink(ctx context.Context, req *harrierproto.UnlinkRequest) (*harrierproto.UnlinkResponse, error) {
	if err := s.rateLimit(); err != nil {
		return nil, err
	}
	if err := s.eng.Graph().RemoveEdge(ctx, req.GetEdgeId()); err != nil {
		return nil, status.Errorf(codes.NotFound, "unlink: %v", err)
	}
	return &harrierproto.UnlinkResponse{Deleted: true}, nil
}

func (s *GrpcServer) Subgraph(ctx context.Context, req *harrierproto.SubgraphRequest) (*harrierproto.SubgraphResponse, error) {
	depth := int(req.GetDepth())
	if depth <= 0 {
		depth = 2
	}
	if depth > maxGraphDepth {
		return nil, status.Errorf(codes.InvalidArgument, "depth exceeds maximum of %d", maxGraphDepth)
	}
	sg, err := s.eng.Graph().ExtractSubgraph(ctx, req.GetNodeId(), depth)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "subgraph: %v", err)
	}
	return &harrierproto.SubgraphResponse{
		Nodes: nodesToProto(sg.Nodes),
		Edges: edgesToProto(sg.Edges),
	}, nil
}

// Impact maps to the same graph-traversal impact analysis REST exposes at
// GET /harrier/impact/{file} (Graph().Impact), not the separate node-centric
// POST /harrier/impact/analyze (Engine.AnalyzeImpact) — the proto request shape
// (repeated changed_files + project) matches the file-based traversal, not
// AnalyzeImpact's single node_id.
func (s *GrpcServer) Impact(ctx context.Context, req *harrierproto.ImpactRequest) (*harrierproto.ImpactResponse, error) {
	const depth = 3
	seen := make(map[string]bool)
	var affected []string
	for _, file := range req.GetChangedFiles() {
		ids, err := s.eng.Graph().Impact(ctx, file, depth)
		if err != nil {
			return nil, status.Errorf(codes.Internal, "impact: %v", err)
		}
		for _, id := range ids {
			if !seen[id] {
				seen[id] = true
				affected = append(affected, id)
			}
		}
	}
	summary := fmt.Sprintf("%d file(s) changed, %d memory node(s) potentially affected", len(req.GetChangedFiles()), len(affected))
	return &harrierproto.ImpactResponse{
		AffectedNodes: affected,
		// StaleNodes is left empty: the graph-traversal impact path doesn't
		// itself compute staleness (that's StalenessManager's job, exposed
		// via WatchStale) — reporting a guess here would be worse than
		// reporting nothing.
		Summary: summary,
	}, nil
}

func (s *GrpcServer) SessionStart(ctx context.Context, req *harrierproto.SessionStartRequest) (*harrierproto.SessionStartResponse, error) {
	sess := &storage.Session{
		ID:        req.GetSessionId(),
		Project:   req.GetProject(),
		StartedAt: time.Now(),
	}
	if err := s.eng.Store().CreateSession(ctx, sess); err != nil {
		return nil, status.Errorf(codes.Internal, "session start: %v", err)
	}
	result, err := s.eng.Context(ctx, req.GetProject())
	if err != nil {
		// Best-effort, matching REST: session creation already succeeded.
		return &harrierproto.SessionStartResponse{}, nil
	}
	return &harrierproto.SessionStartResponse{Context: renderContextText(result.Nodes)}, nil
}

func (s *GrpcServer) SessionEnd(ctx context.Context, req *harrierproto.SessionEndRequest) (*harrierproto.SessionEndResponse, error) {
	summary := req.GetSummary()
	if !req.GetSuccess() && summary != "" {
		summary = "[unsuccessful] " + summary
	}
	if err := s.eng.Store().EndSession(ctx, req.GetSessionId(), summary); err != nil {
		return nil, status.Errorf(codes.Internal, "session end: %v", err)
	}
	return &harrierproto.SessionEndResponse{}, nil
}

func (s *GrpcServer) Health(ctx context.Context, _ *harrierproto.HealthRequest) (*harrierproto.HealthResponse, error) {
	if _, err := s.eng.Store().ListNodes(ctx, storage.NodeFilter{}); err != nil {
		return &harrierproto.HealthResponse{Status: "error"}, nil
	}
	stats, err := s.eng.GetMemoryStats(ctx)
	if err != nil {
		return &harrierproto.HealthResponse{Status: "error"}, nil
	}
	return &harrierproto.HealthResponse{
		Status:    "ok",
		NodeCount: int32(stats.TotalNodes), //nolint:gosec // node/edge counts fit comfortably in int32 for any real deployment
		EdgeCount: int32(stats.TotalEdges), //nolint:gosec
		Version:   harrierversion.String(),
	}, nil
}

func (s *GrpcServer) GraphStats(ctx context.Context, _ *harrierproto.GraphStatsRequest) (*harrierproto.GraphStatsResponse, error) {
	stats, err := s.eng.GetMemoryStats(ctx)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "graph stats: %v", err)
	}
	byType := make(map[string]int32, len(stats.NodesByType))
	for k, v := range stats.NodesByType {
		byType[k] = int32(v) //nolint:gosec // per-type node counts fit comfortably in int32
	}
	return &harrierproto.GraphStatsResponse{
		TotalNodes:  int32(stats.TotalNodes), //nolint:gosec
		TotalEdges:  int32(stats.TotalEdges), //nolint:gosec
		NodesByType: byType,
		// Communities isn't computed by GetMemoryStats today — left at the
		// zero value rather than approximated.
	}, nil
}

// --- streaming RPCs -----------------------------------------------------

func (s *GrpcServer) WatchMemories(req *harrierproto.WatchMemoriesRequest, stream harrierproto.HarrierService_WatchMemoriesServer) error {
	if s.broadcaster == nil {
		return status.Error(codes.Unavailable, "streaming not enabled")
	}
	ch, unsub := s.broadcaster.subscribeMemory()
	defer unsub()

	ctx := stream.Context()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case evt, ok := <-ch:
			if !ok {
				return nil
			}
			if err := stream.Send(&harrierproto.MemoryEvent{
				Type:      string(evt.Type),
				NodeId:    evt.NodeID,
				Content:   evt.Content,
				Timestamp: evt.Timestamp,
			}); err != nil {
				return err
			}
		}
	}
}

func (s *GrpcServer) WatchStale(req *harrierproto.WatchStaleRequest, stream harrierproto.HarrierService_WatchStaleServer) error {
	if s.broadcaster == nil {
		return status.Error(codes.Unavailable, "streaming not enabled")
	}
	ch, unsub := s.broadcaster.subscribeStale()
	defer unsub()

	ctx := stream.Context()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case evt, ok := <-ch:
			if !ok {
				return nil
			}
			if err := stream.Send(&harrierproto.StaleEvent{
				NodeId:    evt.NodeID,
				Reason:    evt.Reason,
				FilePath:  evt.FilePath,
				Timestamp: evt.Timestamp,
			}); err != nil {
				return err
			}
		}
	}
}

// --- conversion helpers ---------------------------------------------------

func nodesToProto(nodes []*storage.Node) []*harrierproto.MemoryNode {
	out := make([]*harrierproto.MemoryNode, 0, len(nodes))
	for _, n := range nodes {
		out = append(out, &harrierproto.MemoryNode{
			Id:         n.ID,
			Type:       n.Type,
			Content:    n.Content,
			Summary:    n.Summary,
			Confidence: float32(n.Confidence),
			CreatedAt:  n.CreatedAt.Unix(),
			AccessedAt: n.AccessedAt.Unix(),
		})
	}
	return out
}

func edgesToProto(edges []*storage.Edge) []*harrierproto.MemoryEdge {
	out := make([]*harrierproto.MemoryEdge, 0, len(edges))
	for _, e := range edges {
		out = append(out, &harrierproto.MemoryEdge{
			Id:     e.ID,
			FromId: e.FromID,
			ToId:   e.ToID,
			Type:   e.Type,
			Weight: float32(e.Weight),
		})
	}
	return out
}

// renderContextText synthesizes the "context" text blob the .proto's
// RecallResponse/ContextResponse/SessionStartResponse promise. No existing
// transport (REST, MCP) does this today — both return the structured
// RecallResult{Nodes, Edges} as-is — so this is new, minimal rendering
// logic, not a port of an existing formatter.
func renderContextText(nodes []*storage.Node) string {
	if len(nodes) == 0 {
		return ""
	}
	var sb strings.Builder
	for i, n := range nodes {
		if i > 0 {
			sb.WriteString("\n\n")
		}
		if n.Summary != "" {
			sb.WriteString(n.Summary)
			sb.WriteString(": ")
		}
		sb.WriteString(n.Content)
	}
	return sb.String()
}

// roughTokenCount is a rough chars/4 heuristic, not a real tokenizer — good
// enough for the proto's tokens_used field, which no existing transport
// populates today either. Do not use this for real budget enforcement
// (Engine.Context/TrimToTokenBudget already do that internally).
func roughTokenCount(s string) int32 {
	return int32(len(s) / 4) //nolint:gosec // bounded by response size limits well under int32 range
}
