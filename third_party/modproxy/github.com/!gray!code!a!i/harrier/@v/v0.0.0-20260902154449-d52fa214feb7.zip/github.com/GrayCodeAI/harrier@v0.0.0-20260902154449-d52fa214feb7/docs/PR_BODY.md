## Summary

Move the optional Bubble Tea demo TUI out of the core Harrier library into a
nested module so embedders (especially Hawk) no longer pull Charm TUI
dependencies through the memory engine graph.

Also includes the Go 1.26.5 bump and architecture doc updates already on this
branch.

## Changes

- New nested module: `cmd/harrier-tui/` (`go.mod`, `main.go`, TUI sources)
- Remove `internal/tui` from the core module
- `go mod tidy` drops `charmbracelet/{bubbles,bubbletea,lipgloss}` from core
- Document optional TUI build in `AGENTS.md`

## Test plan

- [x] `go test ./...` (core module)
- [x] `cd cmd/harrier-tui && go test ./...`
- [x] Confirm core `go.mod` has no charmbracelet direct requires

## Notes for Hawk integrators

After this lands on `main`, update Hawk's `harrier` module pin and its
`go.mod` / `go.sum` so `GOWORK=off` CI and module-release parity stay green.
