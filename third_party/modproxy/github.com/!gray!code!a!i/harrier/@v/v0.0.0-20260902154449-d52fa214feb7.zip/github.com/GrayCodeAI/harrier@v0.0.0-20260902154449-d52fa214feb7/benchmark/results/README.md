# Published Harrier Benchmark Runs

This directory is reserved for benchmark runs that are important enough to treat as evidence.

Expected per-run files:

- `report.md`
- `result.txt` or `result.json`
- `notes.md`

Only commit runs that are intended to serve as:

- baselines
- release notes evidence
- comparison evidence in docs

Current published runs:

- `harrier-longmem-core/2026-06-27/`
- `harrier-microbench/2026-06-27/`
- `harrier-locomo/2026-07-15/`
