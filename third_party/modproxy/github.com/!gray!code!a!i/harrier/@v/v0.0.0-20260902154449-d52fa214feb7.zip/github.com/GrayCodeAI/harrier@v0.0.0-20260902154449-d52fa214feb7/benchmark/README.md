# Harrier Benchmark Publication Workflow

This directory is the publication surface for Harrier benchmarks.

It complements:

- `harrier/internal/bench` for retrieval-quality evaluation
- `harrier/benchmark/benchmark_test.go` for microbenchmarks
- `harrier/benchmark/compare.md` for architecture/performance narrative
- `harrier/benchmark/manifests/` for machine-readable suite definitions

## Official suite ids

- `harrier-longmem-core`
- `harrier-microbench`
- `harrier-locomo` (LoCoMo-10 external corpus; see caveats in its published run's `notes.md`)
- `harrier-locomo-beam-publication` (planned — broader BEAM-benchmark coverage in addition to LoCoMo; `harrier-locomo` above covers LoCoMo only)

See the Hawk-side benchmark registry at `hawk/docs/benchmarks/SUITES.md`.

## Current published baselines

- `harrier-longmem-core`: `results/harrier-longmem-core/2026-06-27/`
- `harrier-microbench`: `results/harrier-microbench/2026-06-27/`
- `harrier-locomo`: `results/harrier-locomo/2026-07-15/`

## Current runnable commands

```bash
/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/longmemreport --suite default'
/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/locomobench'
go test ./benchmark/ -bench=. -benchmem -benchtime=1s
go test ./benchmark/ -bench=BenchmarkRemember -benchmem
go test ./benchmark/ -bench=BenchmarkRecall -benchmem
go test ./benchmark/ -bench=BenchmarkGraphBFS -benchmem
/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./internal/bench -count=1'
/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./benchmark/locomo -count=1'
```

## Publication layout

Recommended committed layout:

```text
benchmark/
  README.md
  compare.md
  results/
    harrier-longmem-core/
      2026-06-27/
        report.md
        result.txt
        notes.md
    harrier-microbench/
      2026-06-27/
        report.md
        result.txt
        notes.md
    harrier-locomo/
      2026-07-15/
        report.md
        result.txt
        notes.md
```

## Required metrics

### `harrier-longmem-core`, `harrier-locomo`

- R@1
- R@3
- R@5
- R@10
- MRR
- avg tokens/query
- duration

### `harrier-microbench`

- latency
- allocs/op
- bytes/op where emitted
- benchmark environment notes

## Promotion rule

Do not cite a Harrier benchmark as evidence in cross-project comparison docs unless:

1. the command used is recorded
2. the commit is recorded
3. the metric table is committed or linked as an artifact
4. the benchmark scope is stated clearly
