// Package dedup implements rolling-window deduplication.
// Skips near-duplicate memories within a configurable time window.
// Based on Engram's SHA-256 dedup with 15-minute rolling window
// and agentmemory's 5-minute dedup window.
package dedup

import (
	"container/heap"
	"crypto/sha256"
	"fmt"
	"sync"
	"time"
)

const maxDedupEntries = 50000 // cap to prevent unbounded map growth

// Window tracks recent content hashes to skip near-duplicates.
type Window struct {
	duration time.Duration
	seen     map[string]time.Time
	mu       sync.Mutex
}

// New creates a dedup window. Default: 5 minutes.
func New(duration time.Duration) *Window {
	if duration <= 0 {
		duration = 5 * time.Minute
	}
	return &Window{duration: duration, seen: map[string]time.Time{}}
}

// IsDuplicate returns true if content was seen within the rolling window.
// If not a duplicate, records it for future checks.
func (w *Window) IsDuplicate(content string) bool {
	hash := contentHash(content)

	w.mu.Lock()
	defer w.mu.Unlock()

	// Clean expired entries
	now := time.Now()
	for k, t := range w.seen {
		if now.Sub(t) > w.duration {
			delete(w.seen, k)
		}
	}

	// Check if seen recently
	if _, exists := w.seen[hash]; exists {
		return true
	}

	// Enforce max size: if at cap, evict oldest entries before inserting
	if len(w.seen) >= maxDedupEntries {
		// Remove the oldest 25% of entries using a min-heap
		h := make(timeHeap, 0, len(w.seen))
		for k, t := range w.seen {
			h = append(h, timeHeapEntry{k, t})
		}
		heap.Init(&h)

		cutoff := len(w.seen) / 4
		if cutoff < 1 {
			cutoff = 1
		}
		for i := 0; i < cutoff && h.Len() > 0; i++ {
			entry, ok := heap.Pop(&h).(timeHeapEntry)
			if !ok {
				continue
			}
			delete(w.seen, entry.key)
		}
	}

	w.seen[hash] = now
	return false
}

// timeHeap implements heap.Interface ordered by timestamp (oldest first).
type timeHeap []timeHeapEntry

type timeHeapEntry struct {
	key string
	t   time.Time
}

func (h timeHeap) Len() int           { return len(h) }
func (h timeHeap) Less(i, j int) bool { return h[i].t.Before(h[j].t) }
func (h timeHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *timeHeap) Push(x interface{}) {
	if e, ok := x.(timeHeapEntry); ok {
		*h = append(*h, e)
	}
}

func (h *timeHeap) Pop() interface{} {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

// NormalizedHash returns a hash that ignores whitespace differences.
func contentHash(content string) string {
	h := sha256.Sum256([]byte(normalizeWhitespace(content)))
	return fmt.Sprintf("%x", h[:16])
}

func normalizeWhitespace(s string) string {
	var result []byte
	space := false
	for _, b := range []byte(s) {
		if b == ' ' || b == '\t' || b == '\n' || b == '\r' {
			if !space {
				result = append(result, ' ')
				space = true
			}
		} else {
			result = append(result, b)
			space = false
		}
	}
	return string(result)
}
