package engine

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestWithMemoryFile_WritesOnRemember(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	memPath := filepath.Join(dir, "MEMORY.md")

	eng := newTestEngine().WithMemoryFile(memPath)

	_, err := eng.Remember(context.Background(), RememberInput{
		Type:    "convention",
		Content: "always use gofmt",
		Project: "p1",
		Tier:    1,
	})
	if err != nil {
		t.Fatalf("Remember: %v", err)
	}

	data, err := os.ReadFile(memPath)
	if err != nil {
		t.Fatalf("reading MEMORY.md: %v", err)
	}
	content := string(data)
	if !strings.Contains(content, "# Memory Index") {
		t.Error("expected memory index header")
	}
	if !strings.Contains(content, "always use gofmt") {
		t.Errorf("expected hot-tier memory in file, got:\n%s", content)
	}
}

func TestWithMemoryFile_EmptyPath(t *testing.T) {
	t.Parallel()
	// No memory file configured: Remember must not error.
	eng := newTestEngine()
	_, err := eng.Remember(context.Background(), RememberInput{
		Type:    "convention",
		Content: "no file configured",
		Project: "p1",
		Tier:    1,
	})
	if err != nil {
		t.Fatalf("Remember with no memory file should succeed: %v", err)
	}
}

func TestWithMemoryFile_UpdatesAfterForget(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	memPath := filepath.Join(dir, "MEMORY.md")
	eng := newTestEngine().WithMemoryFile(memPath)

	node, err := eng.Remember(context.Background(), RememberInput{
		Type:    "convention",
		Content: "temporary rule",
		Project: "p1",
		Tier:    1,
	})
	if err != nil {
		t.Fatalf("Remember: %v", err)
	}

	if err := eng.Forget(context.Background(), node.ID); err != nil {
		t.Fatalf("Forget: %v", err)
	}

	// File should still exist and be readable after Forget.
	if _, err := os.ReadFile(memPath); err != nil {
		t.Fatalf("MEMORY.md should exist after Forget: %v", err)
	}
}
