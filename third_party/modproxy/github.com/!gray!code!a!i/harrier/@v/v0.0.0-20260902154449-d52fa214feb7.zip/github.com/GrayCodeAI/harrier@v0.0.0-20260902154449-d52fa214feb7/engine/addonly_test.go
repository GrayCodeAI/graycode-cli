package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

// countSupersedesEdges returns how many "supersedes" edges exist across all
// nodes in the mock store, plus the lowest confidence found among nodes (used
// to detect the conflict resolver's confidence drop).
func countSupersedesEdges(t *testing.T, e *Engine) (int, float64) {
	t.Helper()
	ctx := context.Background()
	nodes, err := e.Store().ListNodes(ctx, storage.NodeFilter{Type: "convention"})
	if err != nil {
		t.Fatalf("ListNodes: %v", err)
	}
	supersedes := 0
	minConf := 1.0
	for _, n := range nodes {
		if n.Confidence < minConf {
			minConf = n.Confidence
		}
		edges, err := e.Store().GetEdgesFrom(ctx, n.ID)
		if err != nil {
			t.Fatalf("GetEdgesFrom: %v", err)
		}
		for _, ed := range edges {
			if ed.Type == "supersedes" {
				supersedes++
			}
		}
	}
	return supersedes, minConf
}

// TestAddOnlyMode verifies that ADD-only ingestion skips the supersede/conflict
// path: contradictory memories both persist with no supersedes edge and no
// confidence drop. With ADD-only off, the existing supersede behavior holds.
func TestAddOnlyMode(t *testing.T) {
	t.Parallel()
	// A contradicting pair of conventions: same topic (JWT library), opposite
	// recommendation. isContradiction fires on the "instead of" signal.
	const old = "Use jsonwebtoken library for JWT validation in the auth service"
	const upd = "Use jose library instead of jsonwebtoken for JWT validation"

	tests := []struct {
		name           string
		addOnly        bool
		wantSupersedes int
		wantConfDrop   bool // true => some node confidence < 1.0 (resolver lowered it)
	}{
		{name: "add-only on: both persist, no supersede", addOnly: true, wantSupersedes: 0, wantConfDrop: false},
		{name: "add-only off: supersede applied", addOnly: false, wantSupersedes: 1, wantConfDrop: true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			eng := newTestEngine().WithAddOnly(tt.addOnly)
			if got := eng.AddOnly(); got != tt.addOnly {
				t.Fatalf("AddOnly() = %v, want %v", got, tt.addOnly)
			}
			ctx := context.Background()

			n1, err := eng.Remember(ctx, RememberInput{Type: "convention", Content: old, Project: "p"})
			if err != nil {
				t.Fatalf("Remember(old): %v", err)
			}
			n2, err := eng.Remember(ctx, RememberInput{Type: "convention", Content: upd, Project: "p"})
			if err != nil {
				t.Fatalf("Remember(upd): %v", err)
			}

			// Both contradictory memories must persist as independent nodes.
			if n1.ID == n2.ID {
				t.Fatalf("expected two distinct nodes, got same ID %s", n1.ID)
			}
			nodes, err := eng.Store().ListNodes(ctx, storage.NodeFilter{Type: "convention"})
			if err != nil {
				t.Fatalf("ListNodes: %v", err)
			}
			if len(nodes) != 2 {
				t.Fatalf("expected 2 persisted convention nodes, got %d", len(nodes))
			}

			supersedes, minConf := countSupersedesEdges(t, eng)
			if supersedes != tt.wantSupersedes {
				t.Errorf("supersedes edges = %d, want %d", supersedes, tt.wantSupersedes)
			}
			gotConfDrop := minConf < 1.0
			if gotConfDrop != tt.wantConfDrop {
				t.Errorf("confidence drop = %v (min conf %.2f), want %v", gotConfDrop, minConf, tt.wantConfDrop)
			}
		})
	}
}
