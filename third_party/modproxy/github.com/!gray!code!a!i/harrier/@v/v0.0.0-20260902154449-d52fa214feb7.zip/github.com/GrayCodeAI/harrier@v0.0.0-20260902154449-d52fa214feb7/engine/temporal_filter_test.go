package engine

import (
	"context"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func nodeWithTimes(id string, created, updated time.Time) *storage.Node {
	return &storage.Node{
		ID:        id,
		CreatedAt: created,
		UpdatedAt: updated,
	}
}

func TestMatchesTemporal_After(t *testing.T) {
	t.Parallel()
	tf := NewTemporalFilter(nil)

	cutoff := time.Date(2026, 1, 15, 0, 0, 0, 0, time.UTC)
	before := nodeWithTimes("a", time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC), time.Time{})
	after := nodeWithTimes("b", time.Date(2026, 1, 20, 0, 0, 0, 0, time.UTC), time.Time{})

	if tf.matchesTemporal(before, TemporalQuery{After: cutoff}) {
		t.Error("node before cutoff matched After query")
	}
	if !tf.matchesTemporal(after, TemporalQuery{After: cutoff}) {
		t.Error("node after cutoff did not match After query")
	}
}

func TestMatchesTemporal_Before(t *testing.T) {
	t.Parallel()
	tf := NewTemporalFilter(nil)

	cutoff := time.Date(2026, 1, 15, 0, 0, 0, 0, time.UTC)
	before := nodeWithTimes("a", time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC), time.Time{})
	after := nodeWithTimes("b", time.Date(2026, 1, 20, 0, 0, 0, 0, time.UTC), time.Time{})

	if !tf.matchesTemporal(before, TemporalQuery{Before: cutoff}) {
		t.Error("node before cutoff did not match Before query")
	}
	if tf.matchesTemporal(after, TemporalQuery{Before: cutoff}) {
		t.Error("node after cutoff matched Before query")
	}
}

func TestMatchesTemporal_Range(t *testing.T) {
	t.Parallel()
	tf := NewTemporalFilter(nil)

	start := time.Date(2026, 1, 10, 0, 0, 0, 0, time.UTC)
	end := time.Date(2026, 1, 20, 0, 0, 0, 0, time.UTC)

	outside := nodeWithTimes("a", time.Date(2026, 2, 1, 0, 0, 0, 0, time.UTC), time.Time{})
	inside := nodeWithTimes("b", time.Date(2026, 1, 15, 0, 0, 0, 0, time.UTC), time.Time{})

	if tf.matchesTemporal(outside, TemporalQuery{After: start, Before: end}) {
		t.Error("node outside range matched")
	}
	if !tf.matchesTemporal(inside, TemporalQuery{After: start, Before: end}) {
		t.Error("node inside range did not match")
	}
}

func TestFilterByTime(t *testing.T) {
	t.Parallel()
	tf := NewTemporalFilter(nil)

	cutoff := time.Date(2026, 1, 15, 0, 0, 0, 0, time.UTC)
	nodes := []*storage.Node{
		nodeWithTimes("old", time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC), time.Time{}),
		nodeWithTimes("new", time.Date(2026, 1, 20, 0, 0, 0, 0, time.UTC), time.Time{}),
	}

	got := tf.FilterByTime(context.TODO(), nodes, TemporalQuery{After: cutoff})
	if len(got) != 1 {
		t.Fatalf("FilterByTime returned %d nodes, want 1", len(got))
	}
	if got[0].ID != "new" {
		t.Errorf("got node %q, want new", got[0].ID)
	}
}
