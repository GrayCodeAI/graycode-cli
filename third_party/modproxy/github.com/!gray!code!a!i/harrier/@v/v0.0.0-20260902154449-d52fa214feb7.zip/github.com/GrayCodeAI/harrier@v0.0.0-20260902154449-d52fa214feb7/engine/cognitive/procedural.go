package cognitive

import (
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

// ProceduralMemory represents a learned workflow pattern extracted from
// observed tool-use sequences. Unlike explicit Skill nodes (which are
// user-defined step lists), procedural memories are inferred automatically
// from repeated trigger-action sequences in agent sessions.
type ProceduralMemory struct {
	ID           string    `json:"id"`
	Name         string    `json:"name"`
	Description  string    `json:"description"`
	TriggerText  string    `json:"trigger_text"`
	StepSequence []string  `json:"step_sequence"`
	Tools        []string  `json:"tools"`
	Frequency    int       `json:"frequency"`
	SuccessRate  float64   `json:"success_rate"`
	CreatedAt    time.Time `json:"created_at"`
	LastUsedAt   time.Time `json:"last_used_at"`
	Tags         string    `json:"tags,omitempty"`
}

// ProceduralConfig holds configuration for the procedural memory engine.
type ProceduralConfig struct {
	Enabled         bool    `json:"enabled"`
	MaxPatterns     int     `json:"max_patterns"`
	MinFrequency    int     `json:"min_frequency"`
	SequenceMinLen  int     `json:"sequence_min_len"`
	SequenceMaxLen  int     `json:"sequence_max_len"`
	SimilarityThres float64 `json:"similarity_thres"`
}

// DefaultProceduralConfig returns production-tuned defaults.
func DefaultProceduralConfig() ProceduralConfig {
	return ProceduralConfig{
		Enabled:         true,
		MaxPatterns:     100,
		MinFrequency:    2,
		SequenceMinLen:  2,
		SequenceMaxLen:  10,
		SimilarityThres: 0.6,
	}
}

// ProceduralEngine tracks and learns workflow patterns from tool-use sequences.
type ProceduralEngine struct {
	mu       sync.RWMutex
	patterns map[string]*ProceduralMemory
	config   ProceduralConfig
}

// NewProceduralEngine creates a new procedural memory engine.
func NewProceduralEngine(config ProceduralConfig) *ProceduralEngine {
	return &ProceduralEngine{
		patterns: make(map[string]*ProceduralMemory),
		config:   config,
	}
}

// RecordStep appends a tool invocation step to the current session's sequence
// buffer. When the sequence reaches SequenceMaxLen or a session boundary is
// detected, the engine attempts to match the sequence against known patterns
// and either increments an existing pattern's frequency or creates a new one.
func (e *ProceduralEngine) RecordStep(toolName string) {
	if !e.config.Enabled {
		return
	}
	e.mu.Lock()
	defer e.mu.Unlock()

	// Find or create a temporary sequence key for the current session.
	// We use a single accumulator keyed by the most recent tools.
	key := sequenceKey([]string{toolName})
	if existing, ok := e.patterns[key]; ok {
		existing.Frequency++
		existing.LastUsedAt = time.Now()
		return
	}
}

// ObserveSequence records a full observed tool sequence as a procedural memory.
// Called by session-end hooks when a meaningful sequence is detected.
func (e *ProceduralEngine) ObserveSequence(tools []string, trigger string, success bool) *ProceduralMemory {
	if !e.config.Enabled {
		return nil
	}
	if len(tools) < e.config.SequenceMinLen {
		return nil
	}
	if len(tools) > e.config.SequenceMaxLen {
		tools = tools[:e.config.SequenceMaxLen]
	}

	e.mu.Lock()
	defer e.mu.Unlock()

	key := sequenceKey(tools)

	// Check for existing similar pattern
	for _, p := range e.patterns {
		if sequenceSimilarity(p.StepSequence, tools) >= e.config.SimilarityThres {
			p.Frequency++
			p.LastUsedAt = time.Now()
			if success {
				p.SuccessRate = p.SuccessRate*0.9 + 0.1
			} else {
				p.SuccessRate *= 0.9
			}
			// Update sequence to the latest observed (keeps patterns current)
			if p.Frequency%5 == 0 {
				p.StepSequence = tools
			}
			return p
		}
	}

	// Evict lowest-frequency pattern if at capacity
	if len(e.patterns) >= e.config.MaxPatterns {
		e.evictLowest()
	}

	succRate := 0.5
	if success {
		succRate = 1.0
	}

	pattern := &ProceduralMemory{
		ID:           uuid.New().String()[:12],
		Name:         key,
		Description:  "Learned from " + strings.Join(tools, " -> "),
		TriggerText:  trigger,
		StepSequence: tools,
		Tools:        tools,
		Frequency:    1,
		SuccessRate:  succRate,
		CreatedAt:    time.Now(),
		LastUsedAt:   time.Now(),
	}
	e.patterns[pattern.ID] = pattern
	return pattern
}

// SuggestSteps returns the most likely next steps given a prefix of tool names.
// Returns nil if no matching pattern is found or the engine is disabled.
func (e *ProceduralEngine) SuggestSteps(prefix []string, limit int) []string {
	if !e.config.Enabled || len(prefix) == 0 {
		return nil
	}
	if limit <= 0 {
		limit = 3
	}

	e.mu.RLock()
	defer e.mu.RUnlock()

	type candidate struct {
		steps []string
		score float64
	}

	var candidates []candidate
	for _, p := range e.patterns {
		if p.Frequency < e.config.MinFrequency {
			continue
		}
		match := prefixMatch(p.StepSequence, prefix)
		if match >= 0 {
			remaining := p.StepSequence[match:]
			score := float64(p.Frequency) * p.SuccessRate
			candidates = append(candidates, candidate{steps: remaining, score: score})
		}
	}

	if len(candidates) == 0 {
		return nil
	}

	sort.Slice(candidates, func(i, j int) bool {
		return candidates[i].score > candidates[j].score
	})

	if len(candidates) > limit {
		candidates = candidates[:limit]
	}

	// Return the best-matching continuation
	if len(candidates) > 0 {
		return candidates[0].steps
	}
	return nil
}

// GetPatterns returns all procedural patterns, sorted by frequency.
func (e *ProceduralEngine) GetPatterns(limit int) []*ProceduralMemory {
	e.mu.RLock()
	defer e.mu.RUnlock()

	all := make([]*ProceduralMemory, 0, len(e.patterns))
	for _, p := range e.patterns {
		all = append(all, p)
	}
	sort.Slice(all, func(i, j int) bool {
		return all[i].Frequency > all[j].Frequency
	})
	if limit > 0 && len(all) > limit {
		all = all[:limit]
	}
	return all
}

// Cleanup removes patterns below the minimum frequency threshold.
func (e *ProceduralEngine) Cleanup() int {
	e.mu.Lock()
	defer e.mu.Unlock()

	removed := 0
	for id, p := range e.patterns {
		if p.Frequency < e.config.MinFrequency {
			delete(e.patterns, id)
			removed++
		}
	}
	return removed
}

// evictLowest removes the lowest-frequency pattern. Must be called with e.mu held.
func (e *ProceduralEngine) evictLowest() {
	var lowestID string
	lowestFreq := int(^uint(0) >> 1) // max int
	for id, p := range e.patterns {
		if p.Frequency < lowestFreq {
			lowestFreq = p.Frequency
			lowestID = id
		}
	}
	if lowestID != "" {
		delete(e.patterns, lowestID)
	}
}

// sequenceKey creates a short key from a tool sequence for dedup.
func sequenceKey(tools []string) string {
	return strings.Join(tools, "->")
}

// sequenceSimilarity computes the fraction of shared tools between two sequences
// (Jaccard-like, but order-aware via longest common subsequence ratio).
func sequenceSimilarity(a, b []string) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	lcs := longestCommonSubseq(a, b)
	maxLen := len(a)
	if len(b) > maxLen {
		maxLen = len(b)
	}
	return float64(lcs) / float64(maxLen)
}

// longestCommonSubseq returns the length of the LCS of two string slices.
func longestCommonSubseq(a, b []string) int {
	m, n := len(a), len(b)
	if m == 0 || n == 0 {
		return 0
	}
	// Space-optimized LCS
	prev := make([]int, n+1)
	curr := make([]int, n+1)
	for i := 1; i <= m; i++ {
		for j := 1; j <= n; j++ {
			switch {
			case a[i-1] == b[j-1]:
				curr[j] = prev[j-1] + 1
			case prev[j] > curr[j-1]:
				curr[j] = prev[j]
			default:
				curr[j] = curr[j-1]
			}
		}
		prev, curr = curr, prev
		for k := range curr {
			curr[k] = 0
		}
	}
	return prev[n]
}

// prefixMatch checks if the given prefix appears in the pattern sequence.
// Returns the index where the prefix ends (i.e., start of remaining steps),
// or -1 if no match.
func prefixMatch(sequence, prefix []string) int {
	if len(prefix) > len(sequence) {
		return -1
	}
	for i := 0; i <= len(sequence)-len(prefix); i++ {
		match := true
		for j := 0; j < len(prefix); j++ {
			if sequence[i+j] != prefix[j] {
				match = false
				break
			}
		}
		if match {
			return i + len(prefix)
		}
	}
	return -1
}
