package engine

import (
	"context"
	"path/filepath"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func newEventTestEngine(t *testing.T) (*Engine, func()) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	eng := New(store, graph.New(store, store.DB()))
	return eng, func() {
		eng.Close()
		_ = store.Close()
	}
}

func TestMemoryEventBus(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name     string
		wantKind MemoryEventKind
		action   func(t *testing.T, e *Engine) string // returns node id involved
	}{
		{
			name:     "remember emits created",
			wantKind: MemoryCreated,
			action: func(t *testing.T, e *Engine) string {
				n, err := e.Remember(context.Background(), RememberInput{
					Type: "decision", Content: "use Go 1.26", Scope: "project",
				})
				if err != nil {
					t.Fatalf("Remember: %v", err)
				}
				return n.ID
			},
		},
		{
			name:     "keyed re-remember emits updated",
			wantKind: MemoryUpdated,
			action: func(t *testing.T, e *Engine) string {
				ctx := context.Background()
				if _, err := e.Remember(ctx, RememberInput{
					Type: "decision", Content: "v1", Scope: "project", Key: "k1",
				}); err != nil {
					t.Fatalf("first Remember: %v", err)
				}
				n, err := e.Remember(ctx, RememberInput{
					Type: "decision", Content: "v2", Scope: "project", Key: "k1",
				})
				if err != nil {
					t.Fatalf("second Remember: %v", err)
				}
				return n.ID
			},
		},
		{
			name:     "forget emits deleted",
			wantKind: MemoryDeleted,
			action: func(t *testing.T, e *Engine) string {
				ctx := context.Background()
				n, err := e.Remember(ctx, RememberInput{
					Type: "decision", Content: "ephemeral", Scope: "project",
				})
				if err != nil {
					t.Fatalf("Remember: %v", err)
				}
				if err := e.Forget(ctx, n.ID); err != nil {
					t.Fatalf("Forget: %v", err)
				}
				return n.ID
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			eng, cleanup := newEventTestEngine(t)
			defer cleanup()

			ch, unsub := eng.SubscribeMemoryEvents()
			defer unsub()

			wantID := tc.action(t, eng)

			// Drain until we observe the event we expect (setup actions in some
			// cases emit a preceding created/updated event).
			deadline := time.After(2 * time.Second)
			for {
				select {
				case evt := <-ch:
					if evt.Kind != tc.wantKind {
						continue
					}
					if evt.NodeID != wantID {
						t.Fatalf("event node id = %q, want %q", evt.NodeID, wantID)
					}
					if evt.Timestamp == 0 {
						t.Error("event timestamp not set")
					}
					return
				case <-deadline:
					t.Fatalf("did not observe %q event", tc.wantKind)
				}
			}
		})
	}
}

func TestSubscribeUnsubscribe(t *testing.T) {
	t.Parallel()
	eng, cleanup := newEventTestEngine(t)
	defer cleanup()

	ch, unsub := eng.SubscribeMemoryEvents()
	unsub()
	// Double unsubscribe must not panic.
	unsub()

	// After unsubscribe the channel is closed; a publish must not reach it.
	if _, err := eng.Remember(context.Background(), RememberInput{
		Type: "decision", Content: "after unsub", Scope: "project",
	}); err != nil {
		t.Fatalf("Remember: %v", err)
	}
	select {
	case _, ok := <-ch:
		if ok {
			t.Error("received event after unsubscribe")
		}
	default:
	}
}
