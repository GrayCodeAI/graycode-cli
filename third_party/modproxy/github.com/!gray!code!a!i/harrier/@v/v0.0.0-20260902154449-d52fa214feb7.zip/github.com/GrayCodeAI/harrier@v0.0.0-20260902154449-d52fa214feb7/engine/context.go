package engine

import (
	"context"
	"fmt"

	"github.com/GrayCodeAI/harrier/storage"
)

// Context returns the hot-tier subgraph for session start injection.
// Pinned nodes always appear first (guaranteed 500-token budget), followed by
// hot-tier and active tasks filling the remaining budget.
func (e *Engine) Context(ctx context.Context, project string) (*RecallResult, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}

	const totalBudget = 4000 // tokens
	const pinnedBudget = 500 // reserved for pinned

	// Load pinned nodes (always-in-context, like Letta's core memory)
	pinTrue := true
	pinnedNodes, err := e.store.ListNodes(ctx, storage.NodeFilter{
		Project: project, Pinned: &pinTrue,
	})
	if err != nil {
		return nil, fmt.Errorf("load pinned: %w", err)
	}
	pinnedNodes = TrimToTokenBudget(pinnedNodes, pinnedBudget)

	// Load hot tier nodes
	hotNodes, err := e.store.ListNodes(ctx, storage.NodeFilter{
		Tier: 1, Project: project, MinConfidence: 0.3,
	})
	if err != nil {
		return nil, fmt.Errorf("load hot tier: %w", err)
	}

	// Load active tasks
	tasks, err := e.store.ListNodes(ctx, storage.NodeFilter{
		Type: "task", Project: project, MinConfidence: 0.1,
	})
	if err != nil {
		return nil, fmt.Errorf("load tasks: %w", err)
	}

	// Merge hot+tasks, excluding already-pinned nodes
	pinnedSet := map[string]bool{}
	for _, n := range pinnedNodes {
		pinnedSet[n.ID] = true
	}
	nodeMap := map[string]*storage.Node{}
	for _, n := range hotNodes {
		if !pinnedSet[n.ID] {
			nodeMap[n.ID] = n
		}
	}
	for _, n := range tasks {
		if !pinnedSet[n.ID] {
			nodeMap[n.ID] = n
		}
	}

	rest := make([]*storage.Node, 0, len(nodeMap))
	for _, n := range nodeMap {
		rest = append(rest, n)
	}
	sortByScore(rest)

	// Trim rest to remaining budget
	remainingBudget := totalBudget - tokenCount(pinnedNodes)
	rest = TrimToTokenBudget(rest, remainingBudget)

	// Pinned first, then rest
	nodes := make([]*storage.Node, 0, len(pinnedNodes)+len(rest))
	nodes = append(nodes, pinnedNodes...)
	nodes = append(nodes, rest...)

	return &RecallResult{Nodes: nodes}, nil
}

func tokenCount(nodes []*storage.Node) int {
	total := 0
	for _, n := range nodes {
		total += (len(n.Content) + len(n.Summary) + len(n.Tags) + 50) / 4
	}
	return total
}
