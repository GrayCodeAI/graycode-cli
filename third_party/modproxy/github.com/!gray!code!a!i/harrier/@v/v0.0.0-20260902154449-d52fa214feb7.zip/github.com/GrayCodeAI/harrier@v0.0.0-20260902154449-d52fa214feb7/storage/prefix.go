package storage

import (
	"context"
	"fmt"
)

// FindByPrefix returns nodes whose ID starts with the given prefix.
// Returns at most 10 results. The prefix must be at least 1 character.
func (s *Store) FindByPrefix(ctx context.Context, prefix string) ([]*Node, error) {
	if prefix == "" {
		return nil, fmt.Errorf("prefix cannot be empty")
	}

	ctx, cancel := s.withTimeout(ctx)
	defer cancel()

	rows, err := s.db.QueryContext(ctx,
		`SELECT id, type, content, content_hash, summary, scope, project, tier, tags, key, pinned, confidence, access_count, created_at, updated_at, accessed_at, source_session, source_agent, version
		FROM nodes WHERE id LIKE ? || '%' LIMIT 10`, prefix)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	return scanNodes(rows, s.cipher())
}
