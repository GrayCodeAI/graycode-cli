package engine

import (
	"container/heap"
	"encoding/gob"
	"math"
	"math/rand"
	"os"
	"sort"
	"sync"
	"time"
)

// HNSW implements Hierarchical Navigable Small World graph for approximate
// nearest neighbor search. Pure Go, zero dependencies.
//
// Based on: Malkov & Yashunin, "Efficient and robust approximate nearest
// neighbor search using Hierarchical Navigable Small World graphs" (2018).
//
// Parameters tuned for coding memory workloads (1K-50K vectors, 384D):
//   - M = 16 (max connections per layer)
//   - efConstruct = 200 (construction beam width)
//   - efSearch = 100 (search beam width)
//   - mL = 1/ln(M) (level generation factor)
//
// The index can be persisted to disk via Save() / LoadHNSW() for
// survival across restarts. Set autoSavePath to enable debounced auto-save
// (at most once per second, or every 100 inserts).
type HNSW struct {
	mu           sync.RWMutex
	nodes        []hnswNode
	entryPoint   int
	maxLevel     int
	M            int            // max connections per layer
	efConstruct  int            // beam width during construction
	efSearch     int            // beam width during search
	mL           float64        // level multiplier
	dim          int            // vector dimensionality
	idToIdx      map[string]int // external ID → internal index
	autoSavePath string         // if set, save with debounce after Insert
	lastSaveTime time.Time      // last auto-save timestamp (debounce)
	insertsSince int            // inserts since last auto-save (debounce)
}

type hnswNode struct {
	id      string
	vector  []float32
	level   int
	friends [][]int // friends[layer] = sorted list of neighbor indices
}

type hnswCandidate struct {
	idx  int
	dist float32
}

// minHeap implements heap.Interface for candidates (pop closest first).
type minHeap []hnswCandidate

func (h minHeap) Len() int           { return len(h) }
func (h minHeap) Less(i, j int) bool { return h[i].dist < h[j].dist }
func (h minHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *minHeap) Push(x interface{}) {
	if c, ok := x.(hnswCandidate); ok {
		*h = append(*h, c)
	}
}

func (h *minHeap) Pop() interface{} {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

// maxHeap implements heap.Interface for result set (pop farthest first, capped at ef).
type maxHeap []hnswCandidate

func (h maxHeap) Len() int           { return len(h) }
func (h maxHeap) Less(i, j int) bool { return h[i].dist > h[j].dist }
func (h maxHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *maxHeap) Push(x interface{}) {
	if c, ok := x.(hnswCandidate); ok {
		*h = append(*h, c)
	}
}

func (h *maxHeap) Pop() interface{} {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

// NewHNSW creates an HNSW index with default parameters for coding memory.
func NewHNSW(dim int) *HNSW {
	m := 16
	return &HNSW{
		M:           m,
		efConstruct: 200,
		efSearch:    100,
		mL:          1.0 / math.Log(float64(m)),
		dim:         dim,
		entryPoint:  -1,
		idToIdx:     make(map[string]int),
	}
}

// Insert adds a vector to the index.
func (h *HNSW) Insert(id string, vector []float32) {
	if len(vector) != h.dim {
		return
	}

	h.mu.Lock()
	defer h.mu.Unlock()

	if _, exists := h.idToIdx[id]; exists {
		return // already indexed
	}

	level := h.randomLevel()
	idx := len(h.nodes)
	node := hnswNode{
		id:      id,
		vector:  vector,
		level:   level,
		friends: make([][]int, level+1),
	}
	h.nodes = append(h.nodes, node)
	h.idToIdx[id] = idx

	if h.entryPoint == -1 {
		h.entryPoint = idx
		h.maxLevel = level
		return
	}

	// Find entry point at top levels
	curr := h.entryPoint
	for l := h.maxLevel; l > level; l-- {
		curr = h.greedyClosest(vector, curr, l)
	}

	// Insert at each level from top to 0
	for l := min(level, h.maxLevel); l >= 0; l-- {
		neighbors := h.searchLayer(vector, curr, h.efConstruct, l)
		selected := h.selectNeighbors(neighbors, h.M)

		h.nodes[idx].friends[l] = make([]int, len(selected))
		for i, s := range selected {
			h.nodes[idx].friends[l][i] = s.idx
		}

		// Add bidirectional connections
		for _, s := range selected {
			h.addConnection(s.idx, idx, l)
		}

		if len(neighbors) > 0 {
			curr = neighbors[0].idx
		}
	}

	if level > h.maxLevel {
		h.maxLevel = level
		h.entryPoint = idx
	}

	// Debounced auto-save: only persist if >1s since last save or >100 inserts.
	// This avoids gob serialization on every Insert which is expensive for
	// high-throughput ingestion.
	if h.autoSavePath != "" {
		h.insertsSince++
		if h.insertsSince >= 100 || time.Since(h.lastSaveTime) > time.Second {
			_ = h.saveLocked(h.autoSavePath)
			h.lastSaveTime = time.Now()
			h.insertsSince = 0
		}
	}
}

// Search finds the k nearest neighbors to the query vector.
// Returns (nodeIDs, distances) sorted by distance ascending.
func (h *HNSW) Search(query []float32, k int) ([]string, []float32) {
	if len(query) != h.dim || h.entryPoint == -1 {
		return nil, nil
	}

	h.mu.RLock()
	defer h.mu.RUnlock()

	// Traverse from top level down to level 1
	curr := h.entryPoint
	for l := h.maxLevel; l > 0; l-- {
		curr = h.greedyClosest(query, curr, l)
	}

	// Search at level 0 with ef candidates
	candidates := h.searchLayer(query, curr, h.efSearch, 0)

	// Return top-k
	if len(candidates) > k {
		candidates = candidates[:k]
	}

	ids := make([]string, len(candidates))
	dists := make([]float32, len(candidates))
	for i, c := range candidates {
		ids[i] = h.nodes[c.idx].id
		dists[i] = c.dist
	}
	return ids, dists
}

// Size returns the number of vectors in the index.
func (h *HNSW) Size() int {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return len(h.nodes)
}

// Remove marks a node as deleted (logical delete, doesn't restructure).
func (h *HNSW) Remove(id string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if idx, ok := h.idToIdx[id]; ok {
		h.nodes[idx].vector = nil // mark as deleted
		delete(h.idToIdx, id)
	}
}

// Contains checks if an ID is in the index.
func (h *HNSW) Contains(id string) bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	_, ok := h.idToIdx[id]
	return ok
}

// hnswSnapshot holds the persistable fields of HNSW (excludes sync primitives).
type hnswSnapshot struct {
	Nodes       []hnswNode
	IDToIdx     map[string]int
	EntryPoint  int
	MaxLevel    int
	M           int
	EfConstruct int
	EfSearch    int
	ML          float64
	Dim         int
}

// Save writes the HNSW index to a gob-encoded file at path.
func (h *HNSW) Save(path string) error {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.saveLocked(path)
}

// saveLocked writes the index without acquiring the lock. Caller must hold h.mu.
func (h *HNSW) saveLocked(path string) (err error) {
	f, err := os.Create(path) // #nosec G304 -- path is the index file location computed/configured by the caller (e.g. under the harrier data dir), not externally supplied
	if err != nil {
		return err
	}
	defer func() {
		if closeErr := f.Close(); closeErr != nil && err == nil {
			err = closeErr
		}
	}()
	snap := hnswSnapshot{
		Nodes:       h.nodes,
		IDToIdx:     h.idToIdx,
		EntryPoint:  h.entryPoint,
		MaxLevel:    h.maxLevel,
		M:           h.M,
		EfConstruct: h.efConstruct,
		EfSearch:    h.efSearch,
		ML:          h.mL,
		Dim:         h.dim,
	}
	return gob.NewEncoder(f).Encode(snap)
}

// LoadHNSW restores an HNSW index from a gob-encoded file at path.
func LoadHNSW(path string) (*HNSW, error) {
	f, err := os.Open(path) // #nosec G304 -- path is the index file location computed/configured by the caller (e.g. under the harrier data dir), not externally supplied
	if err != nil {
		return nil, err
	}
	defer f.Close() //nolint:errcheck
	var snap hnswSnapshot
	if err := gob.NewDecoder(f).Decode(&snap); err != nil {
		return nil, err
	}
	return &HNSW{
		nodes:       snap.Nodes,
		idToIdx:     snap.IDToIdx,
		entryPoint:  snap.EntryPoint,
		maxLevel:    snap.MaxLevel,
		M:           snap.M,
		efConstruct: snap.EfConstruct,
		efSearch:    snap.EfSearch,
		mL:          snap.ML,
		dim:         snap.Dim,
	}, nil
}

// DeadNodeRatio returns the fraction of nodes with nil vectors (logically deleted).
func (h *HNSW) DeadNodeRatio() float64 {
	h.mu.RLock()
	defer h.mu.RUnlock()
	if len(h.nodes) == 0 {
		return 0
	}
	dead := 0
	for _, n := range h.nodes {
		if n.vector == nil {
			dead++
		}
	}
	return float64(dead) / float64(len(h.nodes))
}

// Compact removes dead nodes and remaps all neighbor indices.
// Returns early if dead ratio is below 20% (no compaction needed).
func (h *HNSW) Compact() {
	h.mu.Lock()
	defer h.mu.Unlock()

	if len(h.nodes) == 0 {
		return
	}

	// Count dead nodes
	dead := 0
	for _, n := range h.nodes {
		if n.vector == nil {
			dead++
		}
	}
	if float64(dead)/float64(len(h.nodes)) < 0.20 {
		return // below threshold, skip
	}

	// Build old-to-new index mapping; -1 means removed
	oldToNew := make([]int, len(h.nodes))
	newNodes := make([]hnswNode, 0, len(h.nodes)-dead)
	for i, n := range h.nodes {
		if n.vector == nil {
			oldToNew[i] = -1
		} else {
			oldToNew[i] = len(newNodes)
			newNodes = append(newNodes, n)
		}
	}

	// Remap neighbor indices in the new nodes
	for i := range newNodes {
		for l, neighbors := range newNodes[i].friends {
			remapped := make([]int, 0, len(neighbors))
			for _, idx := range neighbors {
				if oldToNew[idx] != -1 {
					remapped = append(remapped, oldToNew[idx])
				}
			}
			newNodes[i].friends[l] = remapped
		}
	}

	// Remap entry point
	switch { //nolint:gocritic // multi-condition cases
	case h.entryPoint >= 0 && oldToNew[h.entryPoint] != -1:
		h.entryPoint = oldToNew[h.entryPoint]
	case len(newNodes) > 0:
		// Entry point was dead; pick the first live node with the highest level
		best := 0
		for i, n := range newNodes {
			if n.level > newNodes[best].level {
				best = i
			}
		}
		h.entryPoint = best
	default:
		h.entryPoint = -1
	}

	// Rebuild idToIdx with new indices
	newIDToIdx := make(map[string]int, len(newNodes))
	for i, n := range newNodes {
		newIDToIdx[n.id] = i
	}

	// Recalculate maxLevel
	newMaxLevel := 0
	for _, n := range newNodes {
		if n.level > newMaxLevel {
			newMaxLevel = n.level
		}
	}

	h.nodes = newNodes
	h.idToIdx = newIDToIdx
	h.maxLevel = newMaxLevel
}

func (h *HNSW) randomLevel() int {
	level := 0
	// #nosec G404 -- non-cryptographic use (HNSW level sampling)
	for rand.Float64() < h.mL && level < 16 {
		level++
	}
	return level
}

func (h *HNSW) greedyClosest(query []float32, start int, level int) int {
	curr := start
	currDist := h.distance(query, h.nodes[curr].vector)

	for {
		changed := false
		if level < len(h.nodes[curr].friends) {
			for _, neighbor := range h.nodes[curr].friends[level] {
				if h.nodes[neighbor].vector == nil {
					continue // deleted
				}
				d := h.distance(query, h.nodes[neighbor].vector)
				if d < currDist {
					curr = neighbor
					currDist = d
					changed = true
				}
			}
		}
		if !changed {
			break
		}
	}
	return curr
}

func (h *HNSW) searchLayer(query []float32, entry int, ef int, level int) []hnswCandidate {
	visited := make(map[int]bool)
	visited[entry] = true

	entryDist := h.distance(query, h.nodes[entry].vector)

	// Min-heap for candidates to explore (pop closest first)
	candidates := &minHeap{{idx: entry, dist: entryDist}}
	heap.Init(candidates)

	// Max-heap for results (pop farthest first, capped at ef)
	results := &maxHeap{{idx: entry, dist: entryDist}}
	heap.Init(results)

	for candidates.Len() > 0 {
		curr, ok := heap.Pop(candidates).(hnswCandidate)
		if !ok {
			continue
		}

		// Check if we can stop: if current candidate is farther than worst result
		if results.Len() >= ef && curr.dist > (*results)[0].dist {
			break
		}

		// Explore neighbors
		if level < len(h.nodes[curr.idx].friends) {
			for _, neighbor := range h.nodes[curr.idx].friends[level] {
				if visited[neighbor] {
					continue
				}
				visited[neighbor] = true
				if h.nodes[neighbor].vector == nil {
					continue
				}

				d := h.distance(query, h.nodes[neighbor].vector)

				if results.Len() < ef || d < (*results)[0].dist {
					heap.Push(candidates, hnswCandidate{idx: neighbor, dist: d})
					heap.Push(results, hnswCandidate{idx: neighbor, dist: d})
					if results.Len() > ef {
						heap.Pop(results) // remove farthest
					}
				}
			}
		}
	}

	// Convert max-heap to sorted slice (closest first)
	sorted := make([]hnswCandidate, results.Len())
	for i := len(sorted) - 1; i >= 0; i-- {
		if c, ok := heap.Pop(results).(hnswCandidate); ok {
			sorted[i] = c
		}
	}
	return sorted
}

func (h *HNSW) selectNeighbors(candidates []hnswCandidate, m int) []hnswCandidate {
	if len(candidates) <= m {
		return candidates
	}
	sort.Slice(candidates, func(i, j int) bool {
		return candidates[i].dist < candidates[j].dist
	})
	return candidates[:m]
}

func (h *HNSW) addConnection(nodeIdx, newNeighbor, level int) {
	if level >= len(h.nodes[nodeIdx].friends) {
		return
	}
	friends := h.nodes[nodeIdx].friends[level]

	// Check if already connected
	for _, f := range friends {
		if f == newNeighbor {
			return
		}
	}

	maxM := h.M
	if level == 0 {
		maxM = h.M * 2 // level 0 gets 2M connections
	}

	friends = append(friends, newNeighbor)
	if len(friends) > maxM {
		// Prune: keep closest M neighbors
		type nd struct {
			idx  int
			dist float32
		}
		nds := make([]nd, len(friends))
		for i, f := range friends {
			nds[i] = nd{idx: f, dist: h.distance(h.nodes[nodeIdx].vector, h.nodes[f].vector)}
		}
		sort.Slice(nds, func(i, j int) bool { return nds[i].dist < nds[j].dist })
		friends = make([]int, maxM)
		for i := 0; i < maxM; i++ {
			friends[i] = nds[i].idx
		}
	}
	h.nodes[nodeIdx].friends[level] = friends
}

// distance computes cosine distance (1 - cosine_similarity).
func (h *HNSW) distance(a, b []float32) float32 {
	if a == nil || b == nil {
		return math.MaxFloat32
	}
	var dot, normA, normB float64
	for i := range a {
		dot += float64(a[i]) * float64(b[i])
		normA += float64(a[i]) * float64(a[i])
		normB += float64(b[i]) * float64(b[i])
	}
	denom := math.Sqrt(normA) * math.Sqrt(normB)
	if denom < 1e-30 {
		return 1.0
	}
	return float32(1.0 - dot/denom)
}
