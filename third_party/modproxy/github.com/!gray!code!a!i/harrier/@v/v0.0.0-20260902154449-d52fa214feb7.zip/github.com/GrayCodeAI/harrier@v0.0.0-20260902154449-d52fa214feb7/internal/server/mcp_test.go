package server

import (
	"context"
	"encoding/json"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/mark3labs/mcp-go/mcp"
)

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------

// setupMCPServer creates an MCPServer backed by a temporary SQLite store.
func setupMCPServer(t *testing.T) (*MCPServer, *engine.Engine, func()) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	eng := engine.New(store, graph.New(store, store.DB()))
	mcpSrv := NewMCPServer(eng)
	return mcpSrv, eng, func() {
		eng.Close()
		_ = store.Close()
	}
}

// toolRequest builds a CallToolRequest with the given arguments.
func toolRequest(name string, args map[string]any) mcp.CallToolRequest {
	return mcp.CallToolRequest{
		Request: mcp.Request{Method: "tools/call"},
		Params: mcp.CallToolParams{
			Name:      name,
			Arguments: args,
			Meta:      &mcp.Meta{},
		},
	}
}

// textContent extracts the text from a CallToolResult's first TextContent.
func textContent(res *mcp.CallToolResult) string {
	if res == nil || len(res.Content) == 0 {
		return ""
	}
	if tc, ok := res.Content[0].(mcp.TextContent); ok {
		return tc.Text
	}
	return ""
}

// rememberAndID creates a memory and returns its ID.
// It yields the goroutine briefly afterward because the engine's SelfLink
// runs asynchronously after Remember and writes edges to SQLite; without
// a yield the next DB write can hit SQLITE_BUSY.
func rememberAndID(t *testing.T, srv *MCPServer, content, typ string) string {
	t.Helper()
	ctx := context.Background()
	req := toolRequest("harrier_remember", map[string]any{
		"content": content,
		"type":    typ,
	})
	res, err := srv.handleRemember(ctx, req)
	if err != nil {
		t.Fatalf("remember %q: %v", content, err)
	}
	var node storage.Node
	if err := json.Unmarshal([]byte(textContent(res)), &node); err != nil {
		t.Fatalf("unmarshal remember result: %v", err)
	}
	// Allow SelfLink's async edge writes to complete.
	runtime.Gosched()
	time.Sleep(50 * time.Millisecond)
	return node.ID
}

// ---------------------------------------------------------------------------
// 1. Memory operations — Create, Read, Update, Delete
// ---------------------------------------------------------------------------

// Note: MCP graph/session/feedback tests and concurrency/REST-auth tests
// were moved verbatim into mcp_graph_test.go and
// mcp_concurrency_rest_test.go for readability. This file keeps the shared
// test helpers plus the remember/forget/pin/recall test groups.

func TestMCPRememberCreatesNode(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_remember", map[string]any{
		"content": "Use Go 1.26 generics",
		"type":    "convention",
		"summary": "Go version convention",
		"tags":    "go,version",
	})

	res, err := srv.handleRemember(ctx, req)
	if err != nil {
		t.Fatalf("handleRemember: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}

	var node storage.Node
	if err := json.Unmarshal([]byte(textContent(res)), &node); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if node.Content != "Use Go 1.26 generics" {
		t.Errorf("content = %q, want %q", node.Content, "Use Go 1.26 generics")
	}
	if node.Type != "convention" {
		t.Errorf("type = %q, want convention", node.Type)
	}
	if node.ID == "" {
		t.Error("expected non-empty node ID")
	}
}

func TestMCPRememberDefaultType(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_remember", map[string]any{
		"content": "Some memory without explicit type",
	})

	res, err := srv.handleRemember(ctx, req)
	if err != nil {
		t.Fatalf("handleRemember: %v", err)
	}
	var node storage.Node
	json.Unmarshal([]byte(textContent(res)), &node)
	if node.Type != "decision" {
		t.Errorf("default type = %q, want decision", node.Type)
	}
}

func TestMCPRememberInvalidType(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_remember", map[string]any{
		"content": "test",
		"type":    "nonexistent_type",
	})

	_, err := srv.handleRemember(ctx, req)
	if err == nil {
		t.Fatal("expected error for invalid node type")
	}
	if !strings.Contains(err.Error(), "invalid node type") {
		t.Errorf("error = %q, want 'invalid node type'", err.Error())
	}
}

func TestMCPRememberEmptyContent(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_remember", map[string]any{
		"content": "",
	})

	_, err := srv.handleRemember(ctx, req)
	if err == nil {
		t.Fatal("expected error for empty content")
	}
	if !strings.Contains(err.Error(), "content cannot be empty") {
		t.Errorf("error = %q, want 'content cannot be empty'", err.Error())
	}
}

func TestMCPForget(t *testing.T) {
	t.Parallel()
	srv, eng, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "memory to forget", "decision")

	// Verify node exists before forgetting.
	if _, err := eng.Store().GetNode(ctx, id); err != nil {
		t.Fatalf("node should exist before forget: %v", err)
	}

	req := toolRequest("harrier_forget", map[string]any{"id": id})
	res, err := srv.handleForget(ctx, req)
	if err != nil {
		t.Fatalf("handleForget: %v", err)
	}
	if text := textContent(res); text != "forgotten" {
		t.Errorf("result = %q, want 'forgotten'", text)
	}

	// After forgetting, confidence should be 0 (archived, not deleted).
	node, err := eng.Store().GetNode(ctx, id)
	if err != nil {
		t.Fatalf("node should still exist after forget: %v", err)
	}
	if node.Confidence != 0 {
		t.Errorf("confidence = %f, want 0 after forget", node.Confidence)
	}
}

func TestMCPForgetNodeNotFound(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_forget", map[string]any{"id": "nonexistent-id"})
	_, err := srv.handleForget(ctx, req)
	if err == nil {
		t.Fatal("expected error for nonexistent node")
	}
}

func TestMCPTaskUpdate(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "original task content", "task")

	req := toolRequest("harrier_task_update", map[string]any{
		"id":      id,
		"content": "updated task content",
	})
	res, err := srv.handleTaskUpdate(ctx, req)
	if err != nil {
		t.Fatalf("handleTaskUpdate: %v", err)
	}

	var node storage.Node
	json.Unmarshal([]byte(textContent(res)), &node)
	if node.Content != "updated task content" {
		t.Errorf("content = %q, want 'updated task content'", node.Content)
	}
	if node.Version < 1 {
		t.Errorf("version = %d, want >= 1 after update", node.Version)
	}
}

func TestMCPPinToggle(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "pin me", "decision")

	// Pin.
	req := toolRequest("harrier_pin", map[string]any{"id": id, "pinned": true})
	res, err := srv.handlePin(ctx, req)
	if err != nil {
		t.Fatalf("handlePin: %v", err)
	}
	if !strings.Contains(textContent(res), "pinned") {
		t.Errorf("expected 'pinned' in result, got %q", textContent(res))
	}

	// Unpin.
	req = toolRequest("harrier_pin", map[string]any{"id": id, "pinned": false})
	res, err = srv.handlePin(ctx, req)
	if err != nil {
		t.Fatalf("handlePin unpin: %v", err)
	}
	if !strings.Contains(textContent(res), "unpinned") {
		t.Errorf("expected 'unpinned' in result, got %q", textContent(res))
	}
}

func TestMCPPinToggleDefault(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "toggle pin", "decision")

	// Toggle without explicit pinned value (should toggle from false to true).
	req := toolRequest("harrier_pin", map[string]any{"id": id})
	res, err := srv.handlePin(ctx, req)
	if err != nil {
		t.Fatalf("handlePin toggle: %v", err)
	}
	if !strings.Contains(textContent(res), "pinned") {
		t.Errorf("expected 'pinned' on first toggle, got %q", textContent(res))
	}
}

// ---------------------------------------------------------------------------
// 2. Search — Recall, Intent, Hybrid Recall
// ---------------------------------------------------------------------------

func TestMCPRecall(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	rememberAndID(t, srv, "use TypeScript strict mode for all projects", "convention")
	rememberAndID(t, srv, "prefer table-driven tests in Go", "convention")
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	req := toolRequest("harrier_recall", map[string]any{
		"query": "TypeScript strict",
		"depth": float64(2),
		"limit": float64(10),
	})
	res, err := srv.handleRecall(ctx, req)
	if err != nil {
		t.Fatalf("handleRecall: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result from recall")
	}
	text := textContent(res)
	if text == "" || text == "null" {
		t.Error("expected non-empty recall results")
	}
}

func TestMCPRecallDepthLimitClamp(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	// Depth > 5 should be clamped to 2, not error.
	req := toolRequest("harrier_recall", map[string]any{
		"query": "test",
		"depth": float64(99),
		"limit": float64(5),
	})
	res, err := srv.handleRecall(ctx, req)
	if err != nil {
		t.Fatalf("recall with clamped depth should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPRecallZeroDepthClamp(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_recall", map[string]any{
		"query": "test",
		"depth": float64(0),
	})
	res, err := srv.handleRecall(ctx, req)
	if err != nil {
		t.Fatalf("recall with depth=0 should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPRecallLimitClamp(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	// Limit > 100 should be clamped to 10.
	req := toolRequest("harrier_recall", map[string]any{
		"query": "test",
		"limit": float64(500),
	})
	res, err := srv.handleRecall(ctx, req)
	if err != nil {
		t.Fatalf("recall with clamped limit should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPIntent(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	tests := []struct {
		query    string
		wantType string
	}{
		{"why did we choose SQLite?", "Why"},
		{"when was the last deploy?", "When"},
		{"how do I run migrations?", "How"},
		{"what is the API key format?", "What"},
	}

	for _, tt := range tests {
		req := toolRequest("harrier_intent", map[string]any{"query": tt.query})
		res, err := srv.handleIntent(ctx, req)
		if err != nil {
			t.Fatalf("handleIntent(%q): %v", tt.query, err)
		}
		text := textContent(res)
		if !strings.Contains(text, tt.wantType) {
			t.Errorf("intent(%q): expected %q in result, got %q", tt.query, tt.wantType, text)
		}
	}
}

func TestMCPHybridRecall(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	rememberAndID(t, srv, "use semantic versioning for releases", "convention")

	req := toolRequest("harrier_hybrid_recall", map[string]any{
		"query": "versioning",
		"depth": float64(2),
		"limit": float64(5),
	})
	res, err := srv.handleHybridRecall(ctx, req)
	if err != nil {
		t.Fatalf("handleHybridRecall: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result from hybrid recall")
	}
}

// ---------------------------------------------------------------------------
// 3. Tool handling — correct dispatch and edge linking
// ---------------------------------------------------------------------------

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
