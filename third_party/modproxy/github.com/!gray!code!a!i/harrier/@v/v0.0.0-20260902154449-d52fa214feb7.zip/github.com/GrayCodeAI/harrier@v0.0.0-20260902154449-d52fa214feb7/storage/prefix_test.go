package storage

import (
	"context"
	"path/filepath"
	"testing"
)

func TestFindByPrefix(t *testing.T) {
	store, err := NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()
	ctx := context.Background()

	// Create nodes with known IDs
	nodes := []*Node{
		{ID: "abcd-1111-aaaa", Type: "convention", Content: "first", ContentHash: "h1", Scope: "project", Project: "p1", Confidence: 1.0, Version: 1},
		{ID: "abcd-2222-bbbb", Type: "decision", Content: "second", ContentHash: "h2", Scope: "project", Project: "p1", Confidence: 1.0, Version: 1},
		{ID: "abce-3333-cccc", Type: "bug", Content: "third", ContentHash: "h3", Scope: "project", Project: "p1", Confidence: 1.0, Version: 1},
		{ID: "xyzz-4444-dddd", Type: "spec", Content: "fourth", ContentHash: "h4", Scope: "project", Project: "p1", Confidence: 1.0, Version: 1},
	}

	for _, n := range nodes {
		if err := store.CreateNode(ctx, n); err != nil {
			t.Fatalf("CreateNode(%s): %v", n.ID, err)
		}
	}

	// Find by 4-char prefix "abcd" — should match 2
	found, err := store.FindByPrefix(ctx, "abcd")
	if err != nil {
		t.Fatalf("FindByPrefix: %v", err)
	}
	if len(found) != 2 {
		t.Fatalf("expected 2 nodes with prefix 'abcd', got %d", len(found))
	}

	// Find by 3-char prefix "abc" — should match 3
	found, err = store.FindByPrefix(ctx, "abc")
	if err != nil {
		t.Fatalf("FindByPrefix: %v", err)
	}
	if len(found) != 3 {
		t.Fatalf("expected 3 nodes with prefix 'abc', got %d", len(found))
	}

	// Find by prefix "xyz" — should match 1
	found, err = store.FindByPrefix(ctx, "xyz")
	if err != nil {
		t.Fatalf("FindByPrefix: %v", err)
	}
	if len(found) != 1 {
		t.Fatalf("expected 1 node with prefix 'xyz', got %d", len(found))
	}
	if found[0].ID != "xyzz-4444-dddd" {
		t.Errorf("expected xyzz-4444-dddd, got %s", found[0].ID)
	}

	// Find by nonexistent prefix
	found, err = store.FindByPrefix(ctx, "zzz")
	if err != nil {
		t.Fatalf("FindByPrefix: %v", err)
	}
	if len(found) != 0 {
		t.Fatalf("expected 0 nodes, got %d", len(found))
	}
}

func TestFindByPrefix_EmptyPrefix(t *testing.T) {
	store, err := NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()
	ctx := context.Background()

	_, err = store.FindByPrefix(ctx, "")
	if err == nil {
		t.Fatal("expected error for empty prefix")
	}
}
