package privacy

import (
	"strings"
	"testing"
)

func TestFilter_APIKeys(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name  string
		input string
	}{
		{"OpenAI key", "my key is sk-abcdefghijklmnopqrstuvwxyz"},
		{"AWS key", "aws key: AKIAIOSFODNN7EXAMPLE"},
		{"GitHub PAT", "token: ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh1234"},
		{"GitLab PAT", "glpat-abc123def456ghi789jklmno"},
		{"Slack token", "xoxb-123456789012-abcdef"},
		{"Stripe key", "sk_live_" + "abcdefghijklmnopqrstuvwxyz"},
		{"npm token", "npm_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkl"},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := Filter(tt.input)
			if !strings.Contains(result, "[REDACTED]") {
				t.Errorf("expected redaction for %s, got: %s", tt.name, result)
			}
		})
	}
}

func TestFilter_JWT(t *testing.T) {
	t.Parallel()
	jwt := "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
	result := Filter("token: " + jwt)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("JWT not redacted: %s", result)
	}
}

func TestFilter_PrivateKeys(t *testing.T) {
	t.Parallel()
	key := "-----BEGIN RSA PRIVATE KEY-----\nMIIBogIBAAJ...\n-----END RSA PRIVATE KEY-----"
	result := Filter("my key: " + key)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("private key not redacted: %s", result)
	}
}

func TestFilter_PII(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name  string
		input string
	}{
		{"SSN", "ssn is 123-45-6789"},
		{"phone", "call 555-123-4567"},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := Filter(tt.input)
			if !strings.Contains(result, "[REDACTED]") {
				t.Errorf("expected PII redaction for %s, got: %s", tt.name, result)
			}
		})
	}
}

func TestFilter_Strict(t *testing.T) {
	t.Parallel()
	// Strict mode strips emails and all IPs
	result := FilterWithLevel("contact user@example.com for help", Strict)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("expected email redaction in Strict mode, got: %s", result)
	}
	result = FilterWithLevel("server at 203.0.113.5", Strict)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("expected IP redaction in Strict mode, got: %s", result)
	}
}

func TestFilter_Moderate(t *testing.T) {
	t.Parallel()
	// Moderate keeps work-related emails and infrastructure IPs
	result := FilterWithLevel("contact user@example.com for help", Moderate)
	if strings.Contains(result, "[REDACTED]") {
		t.Errorf("Moderate should keep emails, got: %s", result)
	}
	result = FilterWithLevel("server at 10.0.0.1", Moderate)
	if strings.Contains(result, "[REDACTED]") {
		t.Errorf("Moderate should keep infrastructure IPs, got: %s", result)
	}
	// But Moderate still strips SSN and secrets
	result = FilterWithLevel("ssn is 123-45-6789", Moderate)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("Moderate should redact SSN, got: %s", result)
	}
}

func TestFilter_Minimal(t *testing.T) {
	t.Parallel()
	// Minimal only strips high-entropy secrets and explicit API keys
	result := FilterWithLevel("my key is sk-abcdefghijklmnopqrstuvwxyz", Minimal)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("Minimal should redact API keys, got: %s", result)
	}
	// Minimal does NOT strip SSN or phone
	result = FilterWithLevel("ssn is 123-45-6789", Minimal)
	if strings.Contains(result, "[REDACTED]") {
		t.Errorf("Minimal should not redact SSN, got: %s", result)
	}
}

func TestFilter_ConnectionStrings(t *testing.T) {
	t.Parallel()
	input := "db url: postgres://admin:s3cret@db.example.com:5432/mydb"
	result := Filter(input)
	if !strings.Contains(result, "[REDACTED]") {
		t.Errorf("connection string not redacted: %s", result)
	}
}

func TestFilter_SafeContent(t *testing.T) {
	t.Parallel()
	safe := "This is normal code with no secrets. func main() { fmt.Println(hello) }"
	result := Filter(safe)
	if strings.Contains(result, "[REDACTED]") {
		t.Errorf("safe content incorrectly redacted: %s", result)
	}
}

func TestIsLikelySecret(t *testing.T) {
	t.Parallel()
	tests := []struct {
		token  string
		expect bool
	}{
		{"MAX_RETRY_COUNT", false},
		{"DEBUG_MODE_ENABLED", false},
		{"short", false},
		{"abcdefg", false},
		// Pure-alphanumeric high-entropy secrets (the previously-broken case):
		// hex digests, base64-no-symbol tokens, random alphanumeric API keys.
		{"a8f3kd9smxq74jdlepwo29shtybv", true},             // random alnum, 28 chars
		{"deadbeefcafebabe0123456789abcdef", true},         // 32-char hex
		{"YjY3ZmEwMjE5OGE0NjVkZWZmMTIzNDU2Nzg5YWJj", true}, // base64-ish, no padding
		// False-positive guards.
		{"thisisalonglowercasephrasewithnodigits", false}, // letters only, low entropy
		{"012345678901234567890123456789", false},         // digits only
		{"averylongbutrepetitiveaaaaaaaaaaaaaaa", false},  // low entropy
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.token, func(t *testing.T) {
			t.Parallel()
			got := IsLikelySecret(tt.token)
			if got != tt.expect {
				t.Errorf("IsLikelySecret(%q) = %v, want %v", tt.token, got, tt.expect)
			}
		})
	}
}

// TestFilter_HighEntropySecrets verifies the catch-all redacts pure-alphanumeric
// high-entropy tokens that no explicit regex matches — the case that previously
// silently leaked. Guards confirm ordinary prose is not over-redacted.
func TestFilter_HighEntropySecrets(t *testing.T) {
	t.Parallel()
	redact := []struct {
		name  string
		input string
	}{
		{"random alnum key", "the api key is a8f3kd9smxq74jdlepwo29shtybvz1"},
		{"hex digest", "checksum: deadbeefcafebabe0123456789abcdef1122"},
		{"base64 no padding", "secret YjY3ZmEwMjE5OGE0NjVkZWZmMTIzNDU2Nzg5YWJjZGVm"},
	}
	for _, tt := range redact {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := Filter(tt.input); !strings.Contains(got, "[REDACTED]") {
				t.Errorf("expected redaction for %s, got: %s", tt.name, got)
			}
		})
	}

	keep := []struct {
		name  string
		input string
	}{
		{"prose", "the quick brown fox jumps over the lazy dog repeatedly today"},
		{"identifier", "func calculateTotalRevenueForQuarterlyReport() error { return nil }"},
	}
	for _, tt := range keep {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := Filter(tt.input); strings.Contains(got, "[REDACTED]") {
				t.Errorf("over-redacted safe content %s, got: %s", tt.name, got)
			}
		})
	}
}

func TestIsUpperSnakeCase(t *testing.T) {
	t.Parallel()
	tests := []struct {
		input  string
		expect bool
	}{
		{"MAX_RETRY_COUNT", true},
		{"API_KEY_NAME", true},
		{"lowercase_var", false},
		{"MixedCase", false},
		{"SINGLEWORD", false},
	}
	for _, tt := range tests {
		tt := tt
		t.Run(tt.input, func(t *testing.T) {
			t.Parallel()
			got := isUpperSnakeCase(tt.input)
			if got != tt.expect {
				t.Errorf("isUpperSnakeCase(%q) = %v, want %v", tt.input, got, tt.expect)
			}
		})
	}
}
