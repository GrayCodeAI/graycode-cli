package storage

import (
	"container/heap"
	"context"
	"database/sql"
	"encoding/json"
	"math"
	"math/rand"
	"sort"
	"strconv"
	"sync"
	"time"
)

// HNSWIndex provides approximate nearest neighbor search for embeddings
// using a Hierarchical Navigable Small World graph with cosine distance.
type HNSWIndex struct {
	mu      sync.RWMutex
	vectors map[string][]float32
	// graph[nodeID][level] holds the neighbor list of nodeID at that level.
	graph      map[string]map[int][]string
	maxLevel   int
	entryPoint string
	// efConstruction, m and efSearch are the standard HNSW parameters.
	efConstruction int
	m              int
	efSearch       int
	// rng is seeded once per index so builds are reproducible per process.
	rng *rand.Rand
}

// NewHNSWIndex creates a new HNSW index with the given parameters.
func NewHNSWIndex(efConstruction, m, efSearch int) *HNSWIndex {
	return &HNSWIndex{
		vectors:        make(map[string][]float32),
		graph:          make(map[string]map[int][]string),
		efConstruction: efConstruction,
		m:              m,
		efSearch:       efSearch,
		rng:            rand.New(rand.NewSource(time.Now().UnixNano())),
	}
}

// item is a (node, distance) pair used in the search priority queues.
type item struct {
	id   string
	dist float32
}

// minHeap pops the closest (smallest distance) item first.
type minHeap []item

func (h minHeap) Len() int           { return len(h) }
func (h minHeap) Less(i, j int) bool { return h[i].dist < h[j].dist }
func (h minHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *minHeap) Push(x interface{}) {
	if it, ok := x.(item); ok {
		*h = append(*h, it)
	}
}

func (h *minHeap) Pop() interface{} {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

// maxHeap pops the farthest (largest distance) item first.
type maxHeap []item

func (h maxHeap) Len() int           { return len(h) }
func (h maxHeap) Less(i, j int) bool { return h[i].dist > h[j].dist }
func (h maxHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *maxHeap) Push(x interface{}) {
	if it, ok := x.(item); ok {
		*h = append(*h, it)
	}
}

func (h *maxHeap) Pop() interface{} {
	old := *h
	n := len(old)
	x := old[n-1]
	*h = old[:n-1]
	return x
}

// dist is the cosine distance between two vectors.
func (h *HNSWIndex) dist(a, b []float32) float32 {
	return 1 - cosineSim(a, b)
}

// Build loads all embeddings from the database and constructs the HNSW graph.
func (h *HNSWIndex) Build(ctx context.Context, s *Store, model string) error {
	embeddings, err := s.AllEmbeddings(ctx, model)
	if err != nil {
		return err
	}
	return h.buildFrom(ctx, s, model, embeddings)
}

// buildFrom constructs the graph from an in-memory embedding set and
// persists it.
func (h *HNSWIndex) buildFrom(ctx context.Context, s *Store, model string, embeddings map[string][]float32) error {
	h.mu.Lock()
	h.vectors = embeddings
	h.graph = make(map[string]map[int][]string)
	h.entryPoint = ""
	h.maxLevel = 0

	// Insert in sorted order for deterministic builds.
	ids := make([]string, 0, len(embeddings))
	for id := range embeddings {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		h.insert(id, embeddings[id])
	}
	h.mu.Unlock()

	return h.persist(ctx, s, model)
}

// neighborsPayload is the JSON shape persisted in embeddings_hnsw.neighbors.
// Parameters are recorded so a Restore can reject graphs built with a
// different configuration (link lists depend on m and efConstruction).
type neighborsPayload struct {
	Version        int                 `json:"version"`
	M              int                 `json:"m"`
	EfConstruction int                 `json:"efConstruction"`
	Levels         map[string][]string `json:"levels"`
}

const neighborsPayloadVersion = 1

// Restore reconstructs the index from the neighbors graph persisted by a
// previous Build/Upsert/Remove cycle, without recomputing distances. It
// returns true when a stored graph was loaded. It returns false (and leaves
// the index empty) when the stored graph is absent, structurally
// incompatible (different parameters, old payload shape), or out of sync
// with the embeddings table — callers should then fall back to Build.
func (h *HNSWIndex) Restore(ctx context.Context, s *Store, model string) (bool, error) {
	embeddings, err := s.AllEmbeddings(ctx, model)
	if err != nil {
		return false, err
	}
	if len(embeddings) == 0 {
		return false, nil // nothing indexed; nothing to restore
	}

	qctx, cancel := s.withTimeout(ctx)
	defer cancel()
	rows, err := s.db.QueryContext(qctx,
		`SELECT node_id, neighbors FROM embeddings_hnsw WHERE model=?`, model)
	if err != nil {
		return false, err
	}
	defer func() { _ = rows.Close() }()

	graph := make(map[string]map[string][]string)
	for rows.Next() {
		var nodeID string
		var neighbors sql.NullString
		if err := rows.Scan(&nodeID, &neighbors); err != nil {
			return false, err
		}
		var payload neighborsPayload
		var parsed map[string][]string
		if !neighbors.Valid || neighbors.String == "" {
			return false, nil // legacy or empty payload — must rebuild
		}
		if err := json.Unmarshal([]byte(neighbors.String), &payload); err != nil {
			return false, nil // unrecognized shape — must rebuild
		}
		if payload.Version != neighborsPayloadVersion ||
			payload.M != h.m || payload.EfConstruction != h.efConstruction {
			return false, nil // incompatible parameters — must rebuild
		}
		if parsed = payload.Levels; parsed == nil {
			return false, nil
		}
		graph[nodeID] = parsed
	}
	if err := rows.Err(); err != nil {
		return false, err
	}

	// Exact membership match: the graph is only reusable when it covers the
	// current embedding set for this model.
	if len(graph) != len(embeddings) {
		return false, nil
	}
	for nodeID := range graph {
		if _, ok := embeddings[nodeID]; !ok {
			return false, nil
		}
	}

	h.mu.Lock()
	defer h.mu.Unlock()
	h.vectors = embeddings
	h.graph = make(map[string]map[int][]string, len(graph))
	for nodeID, rawLevels := range graph {
		levels := make(map[int][]string, len(rawLevels))
		for key, links := range rawLevels {
			l, err := strconv.Atoi(key)
			if err != nil {
				return false, nil // corrupted payload — must rebuild
			}
			cleaned := make([]string, 0, len(links))
			for _, id := range links {
				if _, ok := embeddings[id]; ok {
					cleaned = append(cleaned, id)
				}
			}
			levels[l] = cleaned
		}
		h.graph[nodeID] = levels
	}
	entry, maxLevel := h.topNodeLocked()
	h.entryPoint = entry
	h.maxLevel = maxLevel
	return true, nil
}

// insert adds a single vector to the graph. Caller must hold h.mu.
func (h *HNSWIndex) insert(nodeID string, vec []float32) {
	if len(h.graph) == 0 {
		h.entryPoint = nodeID
		h.maxLevel = 0
		h.graph[nodeID] = map[int][]string{}
		return
	}

	level := h.randomLevel()
	entry := h.entryPoint

	// Greedy descent from the top level to level+1, tracking the closest node.
	for l := h.maxLevel; l > level; l-- {
		res := h.searchLayer(vec, 1, l, entry)
		if len(res) > 0 {
			entry = res[0].id
		}
	}

	// Connect at each level from min(level, maxLevel) down to 0.
	top := level
	if top > h.maxLevel {
		top = h.maxLevel
	}
	h.graph[nodeID] = make(map[int][]string)
	for l := top; l >= 0; l-- {
		neighbors := h.searchLayer(vec, h.efConstruction, l, entry)
		if len(neighbors) > h.m {
			neighbors = neighbors[:h.m]
		}
		picked := make([]string, 0, len(neighbors))
		for _, n := range neighbors {
			if n.id == nodeID {
				continue
			}
			picked = append(picked, n.id)
		}
		h.graph[nodeID][l] = picked

		// Add bidirectional links, pruning over-connected neighbors.
		for _, nid := range picked {
			links := h.graph[nid][l]
			if !containsString(links, nodeID) {
				links = append(links, nodeID)
			}
			if len(links) > h.m {
				links = h.prune(h.vectors[nid], links, h.m)
			}
			h.graph[nid][l] = links
		}

		if len(neighbors) > 0 {
			entry = neighbors[0].id
		}
	}

	if level > h.maxLevel {
		h.maxLevel = level
		h.entryPoint = nodeID
	}
}

// prune keeps the m closest links of a node with the given vector.
func (h *HNSWIndex) prune(vec []float32, links []string, m int) []string {
	scored := make([]item, 0, len(links))
	for _, id := range links {
		if v, ok := h.vectors[id]; ok {
			scored = append(scored, item{id, h.dist(vec, v)})
		}
	}
	sort.Slice(scored, func(i, j int) bool { return scored[i].dist < scored[j].dist })
	if len(scored) > m {
		scored = scored[:m]
	}
	out := make([]string, len(scored))
	for i, s := range scored {
		out[i] = s.id
	}
	return out
}

// searchLayer runs a best-first search at a single level and returns up to ef
// closest nodes sorted by ascending distance.
func (h *HNSWIndex) searchLayer(query []float32, ef, level int, entry string) []item {
	if _, ok := h.vectors[entry]; !ok {
		return nil
	}
	dEntry := h.dist(query, h.vectors[entry])

	visited := map[string]bool{entry: true}
	candidates := &minHeap{{entry, dEntry}}
	results := &maxHeap{{entry, dEntry}}
	heap.Init(candidates)
	heap.Init(results)

	for candidates.Len() > 0 {
		c, _ := heap.Pop(candidates).(item) // heap only ever holds items
		farthest := (*results)[0]
		if c.dist > farthest.dist && results.Len() >= ef {
			break
		}
		for _, nid := range h.graph[c.id][level] {
			if visited[nid] {
				continue
			}
			visited[nid] = true
			v, ok := h.vectors[nid]
			if !ok {
				continue
			}
			d := h.dist(query, v)
			if results.Len() < ef || d < (*results)[0].dist {
				heap.Push(candidates, item{nid, d})
				heap.Push(results, item{nid, d})
				if results.Len() > ef {
					heap.Pop(results)
				}
			}
		}
	}

	out := make([]item, 0, results.Len())
	for results.Len() > 0 {
		it, _ := heap.Pop(results).(item) // heap only ever holds items
		out = append(out, it)
	}
	// out is farthest-first from the max-heap pop order; reverse it.
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}

// Search returns the k nearest neighbor IDs with their cosine similarity
// scores (descending). ef controls the search beam width; <=0 uses the default.
func (h *HNSWIndex) Search(query []float32, k, ef int) ([]string, []float32) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	if ef <= 0 {
		ef = h.efSearch
	}
	if ef < k {
		ef = k
	}
	if h.entryPoint == "" {
		return nil, nil
	}

	entry := h.entryPoint
	for l := h.maxLevel; l > 0; l-- {
		res := h.searchLayer(query, 1, l, entry)
		if len(res) > 0 {
			entry = res[0].id
		}
	}
	res := h.searchLayer(query, ef, 0, entry)
	if len(res) > k {
		res = res[:k]
	}

	ids := make([]string, len(res))
	scores := make([]float32, len(res))
	for i, r := range res {
		ids[i] = r.id
		scores[i] = cosineSim(query, h.vectors[r.id])
	}
	return ids, scores
}

func (h *HNSWIndex) persist(ctx context.Context, s *Store, model string) error {
	h.mu.RLock()
	ids := make([]string, 0, len(h.graph))
	for id := range h.graph {
		ids = append(ids, id)
	}
	h.mu.RUnlock()
	return h.persistNodes(ctx, s, model, ids)
}

// persistNodes upserts the embeddings_hnsw rows for the given node IDs.
// IDs that are no longer in the graph are skipped.
func (h *HNSWIndex) persistNodes(ctx context.Context, s *Store, model string, ids []string) error {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	h.mu.RLock()
	defer h.mu.RUnlock()
	for _, nodeID := range ids {
		levels, ok := h.graph[nodeID]
		if !ok {
			continue
		}
		vec := h.vectors[nodeID]
		byLevel := make(map[string][]string, len(levels))
		for l, links := range levels {
			byLevel[strconv.Itoa(l)] = links
		}
		payload, err := json.Marshal(neighborsPayload{
			Version:        neighborsPayloadVersion,
			M:              h.m,
			EfConstruction: h.efConstruction,
			Levels:         byLevel,
		})
		if err != nil {
			return err
		}
		_, err = s.db.ExecContext(ctx, `
			INSERT INTO embeddings_hnsw (node_id, vector, model, neighbors, updated_at)
			VALUES (?, ?, ?, ?, ?)
			ON CONFLICT(node_id) DO UPDATE SET
				vector=excluded.vector, neighbors=excluded.neighbors, updated_at=excluded.updated_at
		`, nodeID, EncodeVector(vec), model, string(payload), time.Now().UTC())
		if err != nil {
			return err
		}
	}
	return nil
}

func (h *HNSWIndex) deleteRow(ctx context.Context, s *Store, nodeID string) error {
	ctx, cancel := s.withTimeout(ctx)
	defer cancel()
	_, err := s.db.ExecContext(ctx, `DELETE FROM embeddings_hnsw WHERE node_id=?`, nodeID)
	return err
}

// Upsert adds or replaces a single vector in the index and persists only the
// affected rows, avoiding a full Build. Callers must store the embedding in
// the embeddings table first so the DB stays the source of truth.
func (h *HNSWIndex) Upsert(ctx context.Context, s *Store, model, nodeID string, vec []float32) error {
	h.mu.Lock()
	affected := h.upsertLocked(nodeID, vec)
	h.mu.Unlock()
	return h.persistNodes(ctx, s, model, setKeys(affected))
}

// upsertLocked replaces (or adds) nodeID in the graph. Caller must hold h.mu.
func (h *HNSWIndex) upsertLocked(nodeID string, vec []float32) map[string]bool {
	affected := h.removeLocked(nodeID)
	h.vectors[nodeID] = vec
	h.insert(nodeID, vec)
	affected[nodeID] = true
	for _, links := range h.graph[nodeID] {
		for _, id := range links {
			affected[id] = true
		}
	}
	return affected
}

// Remove detaches nodeID from the graph (link pruning, entry-point repair)
// and deletes its persisted row. Removing an absent node is a no-op except
// for the row deletion, keeping the DB state consistent.
func (h *HNSWIndex) Remove(ctx context.Context, s *Store, model, nodeID string) error {
	h.mu.Lock()
	affected := h.removeLocked(nodeID)
	h.mu.Unlock()
	if err := h.persistNodes(ctx, s, model, setKeys(affected)); err != nil {
		return err
	}
	return h.deleteRow(ctx, s, nodeID)
}

// removeLocked detaches and drops nodeID, returning every node whose
// persisted state changed (the node itself plus all nodes that linked to
// it). Caller must hold h.mu.
func (h *HNSWIndex) removeLocked(nodeID string) map[string]bool {
	affected := map[string]bool{nodeID: true}
	levels, ok := h.graph[nodeID]
	if !ok {
		delete(h.vectors, nodeID)
		return affected
	}
	for l, links := range levels {
		for _, nid := range links {
			nl, ok := h.graph[nid]
			if !ok || nl[l] == nil {
				continue
			}
			without := removeString(nl[l], nodeID)
			if len(without) != len(nl[l]) {
				nl[l] = without
				affected[nid] = true
			}
		}
	}
	wasEntry := h.entryPoint == nodeID
	delete(h.graph, nodeID)
	delete(h.vectors, nodeID)
	if wasEntry {
		entry, maxLevel := h.topNodeLocked()
		h.entryPoint = entry
		h.maxLevel = maxLevel
		if entry != "" {
			affected[entry] = true
		}
	}
	return affected
}

// topNodeLocked returns the remaining node with the highest level, usable as
// a new entry point. Returns ("", 0) when the graph is empty.
// Caller must hold h.mu.
func (h *HNSWIndex) topNodeLocked() (string, int) {
	entry, maxLevel := "", 0
	for id, levels := range h.graph {
		top := 0
		for l := range levels {
			if l > top {
				top = l
			}
		}
		if entry == "" || top > maxLevel {
			entry, maxLevel = id, top
		}
	}
	return entry, maxLevel
}

func removeString(list []string, s string) []string {
	out := list[:0]
	for _, v := range list {
		if v != s {
			out = append(out, v)
		}
	}
	return out
}

// setKeys returns the keys of a string set as a slice.
func setKeys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}

func containsString(list []string, s string) bool {
	for _, v := range list {
		if v == s {
			return true
		}
	}
	return false
}

// randomLevel samples from the geometric distribution with mL = 1/ln(m).
func (h *HNSWIndex) randomLevel() int {
	ml := 1.0 / math.Log(float64(h.m))
	level := int(-math.Log(h.rng.Float64()) * ml)
	if level > 16 {
		level = 16
	}
	return level
}

func cosineSim(a, b []float32) float32 {
	var dot, normA, normB float32
	for i := range a {
		dot += a[i] * b[i]
		normA += a[i] * a[i]
		normB += b[i] * b[i]
	}
	if normA == 0 || normB == 0 {
		return 0
	}
	return dot / (float32(math.Sqrt(float64(normA))) * float32(math.Sqrt(float64(normB))))
}
