package storage

import (
	"context"
	"testing"
)

func TestAddAndGetReplayEvents(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.AddReplayEvent(ctx, "sess1", `{"k":1}`); err != nil {
		t.Fatalf("AddReplayEvent 1: %v", err)
	}
	if err := s.AddReplayEvent(ctx, "sess1", `{"k":2}`); err != nil {
		t.Fatalf("AddReplayEvent 2: %v", err)
	}
	// Different session should be isolated.
	if err := s.AddReplayEvent(ctx, "sess2", `{"k":99}`); err != nil {
		t.Fatalf("AddReplayEvent other: %v", err)
	}

	events, err := s.GetReplayEvents(ctx, "sess1")
	if err != nil {
		t.Fatalf("GetReplayEvents: %v", err)
	}
	if len(events) != 2 {
		t.Fatalf("expected 2 events for sess1, got %d", len(events))
	}
	// Ordered by id (insertion order).
	if events[0].Data != `{"k":1}` || events[1].Data != `{"k":2}` {
		t.Errorf("events out of order: %q, %q", events[0].Data, events[1].Data)
	}
	if events[0].SessionID != "sess1" {
		t.Errorf("session id = %q, want sess1", events[0].SessionID)
	}
	// AUTOINCREMENT ids must be strictly increasing.
	if events[1].ID <= events[0].ID {
		t.Errorf("expected increasing ids, got %d then %d", events[0].ID, events[1].ID)
	}
	if events[0].CreatedAt.IsZero() {
		t.Error("expected created_at to be set")
	}
}

func TestGetReplayEventsEmpty(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	events, err := s.GetReplayEvents(ctx, "nope")
	if err != nil {
		t.Fatalf("GetReplayEvents: %v", err)
	}
	if len(events) != 0 {
		t.Errorf("expected 0 events, got %d", len(events))
	}
}
