package engine

import (
	"context"
	"errors"
	"testing"
)

// mockExtractor is a test double for the entityExtractor seam used by
// extractEntitiesWithLLM. It returns canned entities or an error.
type mockExtractor struct {
	entities []Entity
	err      error
	calls    int
}

func (m *mockExtractor) ExtractWithError(_ context.Context, _ string) ([]Entity, error) {
	m.calls++
	return m.entities, m.err
}

func hasEntity(ents []Entity, name, typ string) bool {
	for _, e := range ents {
		if e.Name == name && e.Type == typ {
			return true
		}
	}
	return false
}

func countEntity(ents []Entity, normName, typ string) int {
	n := 0
	for _, e := range ents {
		if e.Type == typ && normalizeEntityName(e.Name) == normName {
			n++
		}
	}
	return n
}

func TestExtractEntitiesWithLLM_NilExtractorFallsBackToRegex(t *testing.T) {
	t.Parallel()
	content := "Edit server.go to fix the bug"
	got := ExtractEntitiesWithLLM(context.Background(), content, nil)
	want := ExtractEntities(content)
	if len(got) != len(want) {
		t.Fatalf("nil extractor should equal regex output: got %d, want %d", len(got), len(want))
	}
	if !hasEntity(got, "server.go", "file") {
		t.Errorf("expected regex file entity server.go, got %v", got)
	}
}

func TestExtractEntitiesWithLLM_Merge(t *testing.T) {
	t.Parallel()
	content := "Edit server.go to fix the bug"

	tests := []struct {
		name      string
		mock      *mockExtractor
		wantNames []struct {
			name string
			typ  string
		}
		wantFallback bool // result must contain regex entities
	}{
		{
			name: "merges distinct LLM entities with regex",
			mock: &mockExtractor{entities: []Entity{
				{Name: "PaymentService", Type: "project"},
				{Name: "Stripe", Type: "technology"},
			}},
			wantNames: []struct {
				name string
				typ  string
			}{
				{"server.go", "file"},         // from regex
				{"PaymentService", "project"}, // from LLM
				{"Stripe", "technology"},      // from LLM
			},
			wantFallback: true,
		},
		{
			name: "dedups overlapping entity by type and normalized name",
			mock: &mockExtractor{entities: []Entity{
				{Name: "SERVER.GO", Type: "file"}, // same as regex server.go, case-only diff
				{Name: "Redis", Type: "technology"},
			}},
			wantNames: []struct {
				name string
				typ  string
			}{
				{"server.go", "file"},
				{"Redis", "technology"},
			},
			wantFallback: true,
		},
		{
			name: "error falls back to regex only",
			mock: &mockExtractor{err: errors.New("api down")},
			wantNames: []struct {
				name string
				typ  string
			}{
				{"server.go", "file"},
			},
			wantFallback: true,
		},
		{
			name: "nil entities with no error yields regex set",
			mock: &mockExtractor{entities: nil},
			wantNames: []struct {
				name string
				typ  string
			}{
				{"server.go", "file"},
			},
			wantFallback: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := extractEntitiesWithLLM(context.Background(), content, tt.mock)

			for _, w := range tt.wantNames {
				if !hasEntity(got, w.name, w.typ) {
					t.Errorf("expected entity %q (%s) in result, got %v", w.name, w.typ, got)
				}
			}

			// Dedup invariant: no (type, normalized name) appears more than once.
			seen := map[string]bool{}
			for _, e := range got {
				key := e.Type + "\x00" + normalizeEntityName(e.Name)
				if seen[key] {
					t.Errorf("duplicate entity by (type, normalized name): %q (%s)", e.Name, e.Type)
				}
				seen[key] = true
			}

			if tt.wantFallback {
				regex := ExtractEntities(content)
				for _, r := range regex {
					if !hasEntity(got, r.Name, r.Type) {
						t.Errorf("regex entity %q (%s) missing from merged result", r.Name, r.Type)
					}
				}
			}

			if tt.mock.calls != 1 {
				t.Errorf("expected extractor to be called once, got %d", tt.mock.calls)
			}
		})
	}
}

func TestMergeEntities(t *testing.T) {
	t.Parallel()
	primary := []Entity{
		{Name: "auth.go", Type: "file"},
		{Name: "Postgres", Type: "technology"},
	}
	secondary := []Entity{
		{Name: "postgres", Type: "technology"}, // dup of primary (case-insensitive)
		{Name: "auth.go", Type: "project"},     // same name, different type -> kept
		{Name: "", Type: "entity"},             // empty name -> dropped
		{Name: "Kafka", Type: "technology"},    // new
	}

	got := mergeEntities(primary, secondary)

	if n := countEntity(got, "postgres", "technology"); n != 1 {
		t.Errorf("postgres/technology should appear once, got %d", n)
	}
	if !hasEntity(got, "auth.go", "project") {
		t.Errorf("auth.go/project should be kept (distinct type), got %v", got)
	}
	if hasEntity(got, "", "entity") {
		t.Errorf("empty-name entity should be dropped, got %v", got)
	}
	if !hasEntity(got, "Kafka", "technology") {
		t.Errorf("Kafka/technology should be present, got %v", got)
	}
	// Primary precedence/order: primary entities come first in original order.
	if got[0].Name != "auth.go" || got[0].Type != "file" {
		t.Errorf("expected primary entity first, got %v", got[0])
	}
}
