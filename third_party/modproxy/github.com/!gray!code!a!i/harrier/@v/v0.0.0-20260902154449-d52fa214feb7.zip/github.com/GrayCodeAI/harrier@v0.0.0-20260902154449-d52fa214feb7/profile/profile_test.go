package profile

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func seed(t *testing.T, store *storage.MockStorage, n *storage.Node) {
	t.Helper()
	if err := store.CreateNode(context.Background(), n); err != nil {
		t.Fatalf("seed CreateNode: %v", err)
	}
}

func TestBuild_CollectsStaticDynamicAndStack(t *testing.T) {
	t.Parallel()
	store := storage.NewMockStorage()
	ctx := context.Background()
	now := time.Now()

	// Static facts (high confidence).
	seed(t, store, &storage.Node{ID: "c1", Type: "convention", Project: "proj", Content: "Use tabs", Confidence: 0.9})
	seed(t, store, &storage.Node{ID: "d1", Type: "decision", Project: "proj", Content: "Chose NATS", Confidence: 0.8})
	seed(t, store, &storage.Node{ID: "p1", Type: "preference", Project: "proj", Content: "Functional style", Confidence: 0.7})
	// Low-confidence convention should be excluded (MinConfidence 0.5).
	seed(t, store, &storage.Node{ID: "c2", Type: "convention", Project: "proj", Content: "weak", Confidence: 0.2})

	// Dynamic: recent task within 7 days, and a stale bug outside the window.
	seed(t, store, &storage.Node{ID: "t1", Type: "task", Project: "proj", Content: "rate limiting", Confidence: 0.5, CreatedAt: now, UpdatedAt: now})
	old := now.AddDate(0, 0, -30)
	seed(t, store, &storage.Node{ID: "b1", Type: "bug", Project: "proj", Content: "ancient bug", Confidence: 0.5, CreatedAt: old, UpdatedAt: old})

	// Stack: tech entity + non-tech entity.
	seed(t, store, &storage.Node{ID: "e1", Type: "entity", Project: "proj", Content: "PostgreSQL", Confidence: 0.5})
	seed(t, store, &storage.Node{ID: "e2", Type: "entity", Project: "proj", Content: "SomeRandomName", Confidence: 0.5})
	// Different project must be ignored.
	seed(t, store, &storage.Node{ID: "x1", Type: "convention", Project: "other", Content: "not mine", Confidence: 0.9})

	p, err := Build(ctx, store, "proj")
	if err != nil {
		t.Fatalf("Build: %v", err)
	}

	if !contains(p.Static, "Use tabs") || !contains(p.Static, "Chose NATS") || !contains(p.Static, "Functional style") {
		t.Errorf("static facts missing: %v", p.Static)
	}
	if contains(p.Static, "weak") {
		t.Errorf("low-confidence node should be excluded: %v", p.Static)
	}
	if contains(p.Static, "not mine") {
		t.Errorf("other-project node leaked: %v", p.Static)
	}
	if !containsSub(p.Dynamic, "rate limiting") {
		t.Errorf("recent task missing from dynamic: %v", p.Dynamic)
	}
	if containsSub(p.Dynamic, "ancient bug") {
		t.Errorf("stale node should be excluded from dynamic: %v", p.Dynamic)
	}
	if !contains(p.Stack, "PostgreSQL") {
		t.Errorf("tech entity missing from stack: %v", p.Stack)
	}
	if contains(p.Stack, "SomeRandomName") {
		t.Errorf("non-tech entity should not be in stack: %v", p.Stack)
	}
	if p.Summary == "" {
		t.Error("summary should be populated")
	}
}

func TestBuild_CanceledContext(t *testing.T) {
	t.Parallel()
	store := storage.NewMockStorage()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Build(ctx, store, "proj"); err == nil {
		t.Error("expected error from canceled context")
	}
}

func TestBuild_EmptyGraph(t *testing.T) {
	t.Parallel()
	store := storage.NewMockStorage()
	p, err := Build(context.Background(), store, "empty")
	if err != nil {
		t.Fatalf("Build: %v", err)
	}
	if len(p.Static) != 0 || len(p.Dynamic) != 0 || len(p.Stack) != 0 {
		t.Errorf("expected empty profile, got %+v", p)
	}
	// Summary still reports zero facts.
	if !strings.Contains(p.Summary, "0 facts") {
		t.Errorf("summary should note 0 facts, got %q", p.Summary)
	}
}

func TestBuild_PropagatesStorageError(t *testing.T) {
	t.Parallel()
	store := storage.NewMockStorage()
	store.SetError(errors.New("boom"))
	// Build ignores per-call errors (uses _), so it should still succeed but be empty.
	p, err := Build(context.Background(), store, "proj")
	if err != nil {
		t.Fatalf("Build should tolerate storage errors, got %v", err)
	}
	if len(p.Static) != 0 {
		t.Errorf("expected empty static on storage error, got %v", p.Static)
	}
}

func TestFormat(t *testing.T) {
	t.Parallel()
	p := &Profile{
		Project: "proj",
		Summary: "Stack: go · 2 facts",
		Static:  []string{"Use tabs", "Chose NATS"},
		Dynamic: []string{"[task] rate limiting"},
	}
	out := p.Format()
	if !strings.Contains(out, "## User Profile") {
		t.Error("missing header")
	}
	if !strings.Contains(out, "**Stack: go · 2 facts**") {
		t.Error("summary not rendered bold")
	}
	if !strings.Contains(out, "- Use tabs") || !strings.Contains(out, "- Chose NATS") {
		t.Error("static facts not listed")
	}
	if !strings.Contains(out, "What's Happening") || !strings.Contains(out, "- [task] rate limiting") {
		t.Error("dynamic section not rendered")
	}
}

func TestFormat_EmptyProfileOmitsSections(t *testing.T) {
	t.Parallel()
	p := &Profile{Project: "proj"}
	out := p.Format()
	if strings.Contains(out, "What I Know") || strings.Contains(out, "What's Happening") {
		t.Errorf("empty profile should omit fact sections, got %q", out)
	}
}

func TestFormat_CapsLists(t *testing.T) {
	t.Parallel()
	var static []string
	for i := 0; i < 20; i++ {
		static = append(static, "fact")
	}
	p := &Profile{Static: static}
	out := p.Format()
	// Format caps the static list at 10 entries.
	if got := strings.Count(out, "- fact"); got != 10 {
		t.Errorf("expected static list capped at 10, got %d", got)
	}
}

func TestMerge(t *testing.T) {
	t.Parallel()
	a := &Profile{Project: "proj", Static: []string{"x"}, Dynamic: []string{"d1"}, Stack: []string{"go"}, Summary: "A"}
	b := &Profile{Project: "global", Static: []string{"x", "y"}, Dynamic: []string{"d2"}, Stack: []string{"go", "rust"}, Summary: "B"}
	m := Merge(a, b)
	if m.Project != "proj" {
		t.Errorf("merged project = %q, want proj", m.Project)
	}
	if m.Summary != "A" {
		t.Errorf("merged summary should be a's, got %q", m.Summary)
	}
	if len(m.Static) != 2 { // x deduped
		t.Errorf("static dedup failed: %v", m.Static)
	}
	if len(m.Dynamic) != 2 { // dynamic concatenated, not deduped
		t.Errorf("dynamic merge wrong: %v", m.Dynamic)
	}
	if len(m.Stack) != 2 { // go deduped
		t.Errorf("stack dedup failed: %v", m.Stack)
	}
}

func TestIsTech(t *testing.T) {
	t.Parallel()
	for _, tech := range []string{"go", "Go", "TYPESCRIPT", "PostgreSQL", "react"} {
		if !isTech(tech) {
			t.Errorf("isTech(%q) = false, want true", tech)
		}
	}
	for _, notTech := range []string{"banana", "", "myCustomThing"} {
		if isTech(notTech) {
			t.Errorf("isTech(%q) = true, want false", notTech)
		}
	}
}

func TestDedup(t *testing.T) {
	t.Parallel()
	in := []string{"Go", "go", "GO", "rust", "Rust"}
	out := dedup(in)
	if len(out) != 2 {
		t.Errorf("dedup(%v) = %v, want 2 unique (case-insensitive)", in, out)
	}
	// First occurrence is preserved.
	if out[0] != "Go" || out[1] != "rust" {
		t.Errorf("dedup should preserve first occurrence: %v", out)
	}
}

// --- helpers ---

func contains(haystack []string, needle string) bool {
	for _, s := range haystack {
		if s == needle {
			return true
		}
	}
	return false
}

func containsSub(haystack []string, sub string) bool {
	for _, s := range haystack {
		if strings.Contains(s, sub) {
			return true
		}
	}
	return false
}
