package engine

import (
	"context"
	"time"
)

// MemoryStats holds aggregate statistics about the memory graph.
type MemoryStats struct {
	TotalNodes  int
	NodesByType map[string]int
	TotalEdges  int
	LastUpdated time.Time
	TopTopics   []string // top 5 most-connected node subjects
}

// GetMemoryStats returns aggregate statistics about the memory graph.
func (e *Engine) GetMemoryStats(ctx context.Context) (*MemoryStats, error) {
	stats := &MemoryStats{NodesByType: make(map[string]int)}

	nodesByType, total, err := e.store.NodeStats(ctx)
	if err != nil {
		return nil, err
	}
	stats.NodesByType = nodesByType
	stats.TotalNodes = total

	totalEdges, err := e.store.CountAllEdges(ctx)
	if err != nil {
		return nil, err
	}
	stats.TotalEdges = totalEdges

	lastUpdated, err := e.store.LastUpdated(ctx)
	if err != nil {
		return nil, err
	}
	stats.LastUpdated = lastUpdated

	topTopics, err := e.store.TopConnected(ctx, 5)
	if err != nil {
		return nil, err
	}
	stats.TopTopics = topTopics

	return stats, nil
}

// NodeHistoryEntry represents one version of a memory node.
type NodeHistoryEntry struct {
	Version   int    `json:"version"`
	Content   string `json:"content"`
	ChangedBy string `json:"changed_by"`
	Reason    string `json:"reason"`
	ChangedAt string `json:"changed_at"`
}

// GetNodeHistory returns the version history of a memory node.
func (e *Engine) GetNodeHistory(ctx context.Context, nodeID string) ([]NodeHistoryEntry, error) {
	versions, err := e.store.GetVersions(ctx, nodeID)
	if err != nil {
		return nil, err
	}
	out := make([]NodeHistoryEntry, len(versions))
	for i, v := range versions {
		out[i] = NodeHistoryEntry{
			Version:   v.Version,
			Content:   v.Content,
			ChangedBy: v.ChangedBy,
			Reason:    v.Reason,
			ChangedAt: v.ChangedAt.Format("2006-01-02 15:04:05"),
		}
	}
	return out, nil
}
