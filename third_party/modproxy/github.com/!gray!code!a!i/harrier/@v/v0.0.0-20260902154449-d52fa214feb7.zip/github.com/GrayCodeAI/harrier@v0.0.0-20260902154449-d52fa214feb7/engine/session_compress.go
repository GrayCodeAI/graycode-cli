package engine

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
)

// CompressSessionEvents compresses replay events for a session to reduce storage.
// It reads all events for the session, compresses the data payloads, and stores
// a single compressed summary event. Returns the number of events compressed.
func (e *Engine) CompressSessionEvents(ctx context.Context, sessionID string) (int, error) {
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	events, err := e.store.GetReplayEvents(ctx, sessionID)
	if err != nil {
		return 0, fmt.Errorf("get replay events: %w", err)
	}
	if len(events) < 2 {
		return 0, nil // nothing to compress
	}

	// Collect all event data
	var allData []map[string]any
	for _, ev := range events {
		var entry map[string]any
		if err := json.Unmarshal([]byte(ev.Data), &entry); err != nil {
			continue // skip malformed events
		}
		entry["_ts"] = ev.CreatedAt.Unix()
		allData = append(allData, entry)
	}

	if len(allData) == 0 {
		return 0, nil
	}

	// Serialize and gzip compress
	raw, err := json.Marshal(allData)
	if err != nil {
		return 0, fmt.Errorf("marshal events: %w", err)
	}

	compressed, err := gzipBytes(raw)
	if err != nil {
		return 0, fmt.Errorf("compress: %w", err)
	}

	// Only store compressed version if it's smaller
	if len(compressed) >= len(raw) {
		return 0, nil // compression didn't help
	}

	// Store as a single compressed event with a marker prefix
	encoded := "GZIP:" + base64.StdEncoding.EncodeToString(compressed)
	if err := e.store.AddReplayEvent(ctx, sessionID, encoded); err != nil {
		return 0, fmt.Errorf("store compressed: %w", err)
	}

	compressedCount := len(events)
	slog.Debug("harrier: compressed session events", "session_id", sessionID, "events", compressedCount, "raw_bytes", len(raw), "compressed_bytes", len(compressed))
	return compressedCount, nil
}

// DecompressSessionData decompresses session replay data if it was gzip-compressed.
// Returns the original JSON data. If the data is not compressed, returns it as-is.
func DecompressSessionData(data string) ([]byte, error) {
	if len(data) > 5 && data[:5] == "GZIP:" {
		decoded, err := base64.StdEncoding.DecodeString(data[5:])
		if err != nil {
			return nil, fmt.Errorf("base64 decode: %w", err)
		}
		return gunzipBytes(decoded)
	}
	return []byte(data), nil
}

func gzipBytes(data []byte) ([]byte, error) {
	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	if _, err := w.Write(data); err != nil {
		return nil, err
	}
	if err := w.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func gunzipBytes(data []byte) ([]byte, error) {
	r, err := gzip.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	defer func() { _ = r.Close() }()
	return io.ReadAll(r)
}
