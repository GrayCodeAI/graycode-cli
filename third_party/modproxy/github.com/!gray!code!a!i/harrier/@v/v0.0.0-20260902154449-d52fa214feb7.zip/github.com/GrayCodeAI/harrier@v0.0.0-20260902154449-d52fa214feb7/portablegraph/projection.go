// Package portablegraph projects Harrier-owned memory subgraphs into the shared
// hawk-eco graph contract. Harrier's SQLite LPG remains the source of truth.
package portablegraph

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	graphcontracts "github.com/GrayCodeAI/harrier/portablegraph/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

const SchemaVersion = "harrier.graph/v1"

// Export is a deterministic, privacy-safe projection of one retrieved Harrier
// context subgraph.
type Export struct {
	SchemaVersion string                 `json:"schema_version"`
	GeneratedAt   time.Time              `json:"generated_at"`
	QuerySHA256   string                 `json:"query_sha256,omitempty"`
	Scope         graphcontracts.Scope   `json:"scope,omitempty"`
	Nodes         []graphcontracts.Node  `json:"nodes"`
	Edges         []graphcontracts.Edge  `json:"edges"`
	Events        []graphcontracts.Event `json:"events"`
}

// Input contains the Harrier-owned snapshots selected by existing retrieval.
type Input struct {
	Nodes           []*storage.Node
	Edges           []*storage.Edge
	Query           string
	GeneratedAt     time.Time
	Scope           graphcontracts.Scope
	ProducerVersion string
}

// Build projects and validates one retrieved memory subgraph. It never mutates
// Harrier storage, ranking, access logs, or graph topology.
func Build(input Input) (Export, error) {
	if input.GeneratedAt.IsZero() {
		return Export{}, fmt.Errorf("harrier portable graph: generated time is required")
	}
	generatedAt := input.GeneratedAt.UTC()
	querySHA256 := digest(input.Query)
	export := Export{
		SchemaVersion: SchemaVersion,
		GeneratedAt:   generatedAt,
		QuerySHA256:   querySHA256,
		Scope:         input.Scope,
		Nodes:         make([]graphcontracts.Node, 0, len(input.Nodes)),
		Edges:         make([]graphcontracts.Edge, 0, len(input.Edges)),
		Events:        make([]graphcontracts.Event, 0, len(input.Nodes)),
	}

	nodeIDs := make(map[string]struct{}, len(input.Nodes))
	sourceIDs := make(map[string]graphcontracts.Ref, len(input.Nodes))
	for _, memory := range input.Nodes {
		if memory == nil {
			continue
		}
		sourceID := strings.TrimSpace(memory.ID)
		if sourceID == "" {
			return Export{}, fmt.Errorf("harrier portable graph: memory ID is required")
		}
		ref := graphcontracts.Ref{
			Kind: graphcontracts.NodeKnowledge,
			ID:   memoryNodeID(sourceID),
		}
		if _, exists := nodeIDs[ref.ID]; exists {
			continue
		}

		createdAt := graphTime(memory.CreatedAt, generatedAt)
		attributes := map[string]string{
			"entity_type":         "memory",
			"data_classification": "metadata_only",
			"memory_type":         strings.TrimSpace(memory.Type),
			"tier":                strconv.Itoa(memory.Tier),
			"confidence":          strconv.FormatFloat(memory.Confidence, 'f', -1, 64),
			"pinned":              strconv.FormatBool(memory.Pinned),
			"version":             strconv.Itoa(memory.Version),
			"access_count":        strconv.Itoa(memory.AccessCount),
			"content_sha256":      contentDigest(memory),
		}
		addAttribute(attributes, "source_session_sha256", digest(memory.SourceSession))
		addAttribute(attributes, "source_agent_sha256", digest(memory.SourceAgent))
		node := graphcontracts.Node{
			ID:          ref.ID,
			Kind:        ref.Kind,
			Scope:       input.Scope,
			CreatedAt:   createdAt,
			EffectiveAt: graphTime(memory.UpdatedAt, createdAt),
			Provenance: graphcontracts.Provenance{
				Producer: "harrier",
				Version:  strings.TrimSpace(input.ProducerVersion),
				SourceID: sourceID,
				Evidence: []graphcontracts.ArtifactRef{{URI: "harrier://memory/" + sourceID}},
			},
			Attributes: attributes,
		}
		if err := node.Validate(); err != nil {
			return Export{}, fmt.Errorf("harrier portable graph: node %q: %w", ref.ID, err)
		}
		export.Nodes = append(export.Nodes, node)
		nodeIDs[ref.ID] = struct{}{}
		sourceIDs[sourceID] = ref

		event := graphcontracts.Event{
			ID:             observedEventID(sourceID, querySHA256),
			Type:           graphcontracts.EventObserved,
			Subject:        ref,
			Scope:          input.Scope,
			OccurredAt:     generatedAt,
			CorrelationID:  querySHA256,
			IdempotencyKey: observedEventID(sourceID, querySHA256),
			Provenance:     node.Provenance,
		}
		if err := event.Validate(); err != nil {
			return Export{}, fmt.Errorf("harrier portable graph: event %q: %w", event.ID, err)
		}
		export.Events = append(export.Events, event)
	}

	edgeIDs := make(map[string]struct{}, len(input.Edges))
	for _, relation := range input.Edges {
		if relation == nil {
			continue
		}
		from, fromExists := sourceIDs[strings.TrimSpace(relation.FromID)]
		to, toExists := sourceIDs[strings.TrimSpace(relation.ToID)]
		if !fromExists || !toExists {
			return Export{}, fmt.Errorf(
				"harrier portable graph: edge %q references memory outside the retrieved subgraph",
				relation.ID,
			)
		}
		sourceID := strings.TrimSpace(relation.ID)
		if sourceID == "" {
			sourceID = digest(relation.FromID + "\x00" + relation.Type + "\x00" + relation.ToID)
		}
		edge := graphcontracts.Edge{
			ID:          relationEdgeID(sourceID),
			Kind:        portableEdgeKind(relation.Type),
			From:        from,
			To:          to,
			Scope:       input.Scope,
			CreatedAt:   graphTime(relation.CreatedAt, generatedAt),
			EffectiveAt: graphTime(relation.ValidAt, graphTime(relation.CreatedAt, generatedAt)),
			Provenance: graphcontracts.Provenance{
				Producer: "harrier",
				Version:  strings.TrimSpace(input.ProducerVersion),
				SourceID: sourceID,
				Evidence: []graphcontracts.ArtifactRef{{URI: "harrier://edge/" + sourceID}},
			},
			Attributes: map[string]string{
				"entity_type":         "memory_relation",
				"data_classification": "metadata_only",
				"relation_type":       strings.TrimSpace(relation.Type),
				"acyclic":             strconv.FormatBool(relation.Acyclic),
				"weight":              strconv.FormatFloat(relation.Weight, 'f', -1, 64),
			},
		}
		if !relation.InvalidAt.IsZero() {
			edge.Attributes["invalid_at"] = relation.InvalidAt.UTC().Format(time.RFC3339Nano)
		}
		if err := edge.Validate(); err != nil {
			return Export{}, fmt.Errorf("harrier portable graph: edge %q: %w", edge.ID, err)
		}
		if _, exists := edgeIDs[edge.ID]; exists {
			continue
		}
		edgeIDs[edge.ID] = struct{}{}
		export.Edges = append(export.Edges, edge)
	}

	sort.Slice(export.Nodes, func(i, j int) bool { return export.Nodes[i].ID < export.Nodes[j].ID })
	sort.Slice(export.Edges, func(i, j int) bool { return export.Edges[i].ID < export.Edges[j].ID })
	sort.Slice(export.Events, func(i, j int) bool { return export.Events[i].ID < export.Events[j].ID })
	return export, nil
}

func portableEdgeKind(relationType string) graphcontracts.EdgeKind {
	switch strings.TrimSpace(relationType) {
	case "part_of":
		return graphcontracts.EdgeContains
	case "depends_on":
		return graphcontracts.EdgeDependsOn
	default:
		return graphcontracts.EdgeReferences
	}
}

func contentDigest(memory *storage.Node) string {
	if memory == nil {
		return ""
	}
	if value := normalizedSHA256(memory.ContentHash); value != "" {
		return value
	}
	return digest(memory.Content)
}

func normalizedSHA256(value string) string {
	value = strings.TrimSpace(value)
	if len(value) != sha256.Size*2 {
		return ""
	}
	decoded, err := hex.DecodeString(value)
	if err != nil || hex.EncodeToString(decoded) != value {
		return ""
	}
	return value
}

func memoryNodeID(sourceID string) string {
	return "harrier/memory/" + sourceID
}

func relationEdgeID(sourceID string) string {
	return "harrier/edge/" + sourceID
}

func observedEventID(sourceID, querySHA256 string) string {
	return "harrier/event/memory/" + sourceID + "/observed/" + querySHA256
}

func graphTime(value, fallback time.Time) time.Time {
	if value.IsZero() {
		return fallback
	}
	return value.UTC()
}

func addAttribute(attributes map[string]string, key, value string) {
	if value = strings.TrimSpace(value); value != "" {
		attributes[key] = value
	}
}

func digest(value string) string {
	if strings.TrimSpace(value) == "" {
		return ""
	}
	sum := sha256.Sum256([]byte(value))
	return hex.EncodeToString(sum[:])
}
