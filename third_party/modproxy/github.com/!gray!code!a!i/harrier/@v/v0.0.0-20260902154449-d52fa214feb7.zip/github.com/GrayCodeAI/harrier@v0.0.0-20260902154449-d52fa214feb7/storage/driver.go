// Package storage provides the persistence layer for harrier.
//
// This file defines the Driver interface for multi-backend storage support,
// inspired by cognee's multi-backend architecture (Neo4j, Postgres/PGVector,
// Kuzu, SQLite). The Driver interface abstracts the storage backend so that
// harrier can use SQLite for development and Neo4j/Dgraph for production.
//
// Currently, only the SQLite driver is fully implemented. Neo4j and Dgraph
// drivers are stubs that return errors until implemented.

package storage

import (
	"context"
	"fmt"
)

// DriverKind identifies a storage backend type.
type DriverKind string

const (
	DriverSQLite   DriverKind = "sqlite"
	DriverNeo4j    DriverKind = "neo4j"
	DriverDgraph   DriverKind = "dgraph"
	DriverPostgres DriverKind = "postgres"
)

// DriverConfig configures a storage driver.
type DriverConfig struct {
	Kind DriverKind
	// SQLite-specific
	Path string
	// Neo4j-specific
	Neo4jURI  string
	Neo4jUser string
	Neo4jPass string
	// Dgraph-specific
	DgraphURL string
	// Postgres-specific
	PostgresDSN string
}

// Driver is the multi-backend storage interface. It extends the Storage
// interface with backend-specific metadata and lifecycle methods.
//
// The Storage interface (defined in interface.go) provides the core
// node/edge/session operations. Driver adds:
//   - Kind() returns the backend type
//   - Close() releases backend resources
//   - Ping() checks backend connectivity
//
// All existing Storage methods are inherited.
type Driver interface {
	Storage

	// Kind returns the backend type.
	Kind() DriverKind

	// Ping checks backend connectivity.
	Ping(ctx context.Context) error

	// Close releases backend resources.
	Close() error
}

// NewDriver creates a storage driver for the given backend.
// Currently supports SQLite (fully implemented) and Neo4j/Dgraph/Postgres
// (stubs that return errors).
func NewDriver(ctx context.Context, cfg DriverConfig) (Driver, error) {
	switch cfg.Kind {
	case DriverSQLite, "":
		return NewSQLiteDriver(ctx, cfg.Path)
	case DriverNeo4j:
		return NewNeo4jDriver(ctx, cfg)
	case DriverDgraph:
		return NewDgraphDriver(ctx, cfg)
	case DriverPostgres:
		return NewPostgresDriver(ctx, cfg)
	default:
		return nil, fmt.Errorf("unsupported driver kind: %s", cfg.Kind)
	}
}

// --- SQLite Driver ---

// SQLiteDriver wraps the existing Store as a Driver.
type SQLiteDriver struct {
	*Store
}

// NewSQLiteDriver creates a SQLite-backed storage driver.
func NewSQLiteDriver(ctx context.Context, path string) (*SQLiteDriver, error) {
	store, err := NewStore(path)
	if err != nil {
		return nil, fmt.Errorf("create sqlite store: %w", err)
	}
	return &SQLiteDriver{Store: store}, nil
}

// Kind returns DriverSQLite.
func (d *SQLiteDriver) Kind() DriverKind { return DriverSQLite }

// Ping checks SQLite connectivity.
func (d *SQLiteDriver) Ping(ctx context.Context) error {
	return d.db.PingContext(ctx)
}

// --- Neo4j Driver (stub) ---

// Neo4jDriver is a stub for Neo4j-backed storage.
// TODO: Implement using github.com/neo4j/neo4j-go-driver/v5
type Neo4jDriver struct{}

// NewNeo4jDriver creates a Neo4j-backed storage driver (stub).
// Currently returns an error; Neo4j support is not yet implemented.
func NewNeo4jDriver(ctx context.Context, cfg DriverConfig) (Driver, error) {
	return nil, fmt.Errorf("neo4j driver not yet implemented (use sqlite for now)")
}

// --- Dgraph Driver (stub) ---

// DgraphDriver is a stub for Dgraph-backed storage.
// TODO: Implement using github.com/dgraph-io/dgo
type DgraphDriver struct{}

// NewDgraphDriver creates a Dgraph-backed storage driver (stub).
// Currently returns an error; Dgraph support is not yet implemented.
func NewDgraphDriver(ctx context.Context, cfg DriverConfig) (Driver, error) {
	return nil, fmt.Errorf("dgraph driver not yet implemented (use sqlite for now)")
}

// --- Postgres Driver (stub) ---

// PostgresDriver is a stub for Postgres-backed storage.
// TODO: Implement using github.com/jack/pgx/v5 + pgvector
type PostgresDriver struct{}

// NewPostgresDriver creates a Postgres-backed storage driver (stub).
// Currently returns an error; Postgres support is not yet implemented.
func NewPostgresDriver(ctx context.Context, cfg DriverConfig) (Driver, error) {
	return nil, fmt.Errorf("postgres driver not yet implemented (use sqlite for now)")
}
