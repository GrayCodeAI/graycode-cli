package engine

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// DecayScheduler runs decay and garbage collection on a periodic schedule.
// It applies half-life decay to memory confidence scores and removes nodes
// that fall below the minimum confidence threshold.
type DecayScheduler struct {
	store     storage.Storage
	cfg       DecayConfig
	interval  time.Duration
	gcEnabled bool
	stopCh    chan struct{}
	stopped   sync.Once
}

// NewDecayScheduler creates a scheduler that runs decay at the given interval.
// gcEnabled controls whether garbage collection runs after each decay pass.
func NewDecayScheduler(store storage.Storage, cfg DecayConfig, interval time.Duration, gcEnabled bool) *DecayScheduler {
	if interval <= 0 {
		interval = 1 * time.Hour
	}
	return &DecayScheduler{
		store:     store,
		cfg:       cfg,
		interval:  interval,
		gcEnabled: gcEnabled,
		stopCh:    make(chan struct{}),
	}
}

// Start begins the periodic decay loop. It runs decay immediately on start,
// then at the configured interval. Returns immediately (non-blocking).
func (ds *DecayScheduler) Start() {
	go ds.loop()
}

// Stop halts the scheduler. Safe to call multiple times.
func (ds *DecayScheduler) Stop() {
	ds.stopped.Do(func() {
		close(ds.stopCh)
	})
}

func (ds *DecayScheduler) loop() {
	// Run once immediately on start
	ds.run(context.Background())

	ticker := time.NewTicker(ds.interval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			ds.run(context.Background())
		case <-ds.stopCh:
			return
		}
	}
}

func (ds *DecayScheduler) run(ctx context.Context) {
	slog.Debug("harrier: decay scheduler: running decay pass")
	if err := RunDecay(ctx, ds.store, ds.cfg); err != nil {
		slog.Warn("harrier: decay scheduler: decay failed", "error", err)
		return
	}

	if ds.gcEnabled {
		slog.Debug("harrier: decay scheduler: running garbage collection")
		removed, err := GarbageCollect(ctx, ds.store, ds.cfg)
		if err != nil {
			slog.Warn("harrier: decay scheduler: gc failed", "error", err)
			return
		}
		if removed > 0 {
			slog.Info("harrier: decay scheduler: gc removed nodes", "count", removed)
		}
	}
}
