// Package engine is the core of harrier: it ties storage, the typed graph,
// dedup, decay, conflict resolution, and hybrid recall together behind the
// Engine type, the main entry point for remember/recall/forget operations.
package engine

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/GrayCodeAI/harrier/compact"
	"github.com/GrayCodeAI/harrier/conflict"
	"github.com/GrayCodeAI/harrier/dedup"
	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/engine/cognitive"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
	"github.com/GrayCodeAI/harrier/temporal"
)

// Validation and default constants.
const (
	maxContentLength   = 10000 // characters
	defaultRecallDepth = 3
	defaultRecallLimit = 10
	confidenceBoost    = 0.2
	minConfidence      = 0.1
	halfLifeDays       = 30.0
	busyTimeoutMs      = 5000
	compactThreshold   = 50000
	defaultDecayBoost  = 0.2
)

var validNodeTypes = map[string]bool{
	"convention": true,
	"decision":   true,
	"bug":        true,
	"spec":       true,
	"task":       true,
	"preference": true,
	"skill":      true,
	"file":       true,
	"entity":     true,
	"session":    true,
	// Structured entry types (cognee adoption)
	"qa":        true,
	"trace":     true,
	"feedback":  true,
	"skill_run": true,
}

// IsValidNodeType reports whether typ is a recognized node type.
func IsValidNodeType(typ string) bool {
	return validNodeTypes[typ]
}

// Metrics tracks basic engine operation counters.
type Metrics struct {
	Remembers        int64
	Recalls          int64
	Errors           int64
	NodesStored      int64
	InjectChecks     int64 // proactive injection checks performed
	InjectsPerformed int64 // memories actually injected
}

// Engine is the core memory engine wrapping graph + storage.
type Engine struct {
	store       storage.Storage
	graph       graph.Graph
	dedup       *dedup.Window
	temporal    *temporal.Backbone
	conflict    *conflict.Resolver
	access      *AccessTracker
	audit       *AuditLog
	summarizer  compact.Summarizer
	entities    *EntityIndex
	bloom       *BloomFilter
	hnsw        *HNSW
	hnswPath    string
	embedder    embeddings.Provider // optional; enables embedding the query for the vector path
	cache       *QueryCache
	integrity   *MemoryIntegrity
	scoring     ScoringConfig
	privacyCfg  PrivacyConfig
	metrics     Metrics
	DecayConfig DecayConfig

	// Cognitive engines (optional, wired via WithX constructors).
	zeigarnik    *cognitive.ZeigarnikEngine
	prospective  *cognitive.ProspectiveEngine
	epistemic    *cognitive.EpistemicEngine
	somatic      *cognitive.SomaticEngine
	curiosity    *cognitive.CuriosityEngine
	reconsol     *cognitive.ReconsolidationEngine
	procedural   *cognitive.ProceduralEngine
	boundary     *cognitive.BoundaryDetector
	consolidator *TopicConsolidator
	ranker       *MultiFactorRanker
	decaySched   *DecayScheduler // optional periodic decay+GC scheduler

	searchDecay  *SearchTimeDecay // optional non-destructive search-time decay
	memoryFile   string           // optional path to a human-readable MEMORY.md hot-pointer file
	llmExtractor *LLMExtractor    // optional LLM-based entity extractor (regex-only when nil)

	// addOnly enables Mem0-v3-style single-pass ADD ingestion: when true,
	// Remember skips the supersede/update/conflict-resolution path and only
	// appends new nodes. Contradictory memories both persist (no supersedes
	// edge, no confidence drop). Default false (preserves conflict
	// resolution). Toggle via WithAddOnly or the HARRIER_ADD_ONLY env var.
	addOnly bool

	// sessionTier is the fast in-memory cache for session-scoped memories.
	// When non-nil, RememberWithSession caches nodes here and RecallWithSession
	// checks it before falling through to the permanent graph.
	sessionTier *SessionTier

	// eventBus optionally fans out memory mutation events (created/updated/
	// deleted) to in-process subscribers such as the SSE broadcaster. Lazily
	// created on first SubscribeMemoryEvents; nil means no subscribers.
	eventBus *eventBus

	// consol holds the optional background "sleep-time" consolidation loop
	// (periodic decay + conflict re-scan + compaction). Nil when not started;
	// guarded by consolMu. Default OFF — see StartConsolidation.
	consol   *consolidationState
	consolMu sync.Mutex

	// mu serializes the multi-step critical path of high-level operations
	// (Remember, Forget, Feedback) so their sub-steps are atomic relative to
	// each other. It is NOT a global write lock: async linking, the access
	// tracker, and embedding writes run outside it and rely on SQLite's WAL
	// single-writer plus retryOnBusy back-off for write safety.
	mu sync.Mutex
}

// New creates a memory engine.
func New(store storage.Storage, g graph.Graph) *Engine {
	e := &Engine{
		store:       store,
		graph:       g,
		dedup:       dedup.New(5 * time.Minute),
		temporal:    temporal.New(store),
		conflict:    conflict.New(store),
		access:      NewAccessTracker(store, 30*time.Second),
		summarizer:  compact.DefaultSummarizer{},
		entities:    NewEntityIndex(),
		bloom:       NewBloomFilter(10000, 0.01),
		hnsw:        NewHNSW(384), // all-MiniLM-L6-v2 dimension
		cache:       NewQueryCache(64, 5*time.Minute),
		scoring:     DefaultScoringConfig(),
		privacyCfg:  DefaultPrivacyConfig(),
		DecayConfig: DefaultDecayConfig,
		sessionTier: NewSessionTier(),
	}
	// Entity index and HNSW load lazily on first use (not at startup).
	// This keeps startup time <50ms regardless of graph size.
	return e
}

// WithZeigarnik wires the open-loop detection engine.
func (e *Engine) WithZeigarnik(cfg cognitive.ZeigarnikConfig) *Engine {
	e.zeigarnik = cognitive.NewZeigarnikEngine(cfg)
	return e
}

// WithProspective wires the trigger-based future memory engine.
func (e *Engine) WithProspective(cfg cognitive.ProspectiveConfig) *Engine {
	e.prospective = cognitive.NewProspectiveEngine(cfg)
	return e
}

// WithEpistemic wires the knowledge gap detection engine.
func (e *Engine) WithEpistemic(cfg cognitive.EpistemicConfig) *Engine {
	e.epistemic = cognitive.NewEpistemicEngine(cfg)
	return e
}

// WithSomatic wires the valence/arousal outcome tracking engine.
func (e *Engine) WithSomatic(cfg cognitive.SomaticConfig) *Engine {
	e.somatic = cognitive.NewSomaticEngine(cfg)
	return e
}

// WithCuriosity wires the exploration target engine.
func (e *Engine) WithCuriosity(cfg cognitive.CuriosityConfig) *Engine {
	e.curiosity = cognitive.NewCuriosityEngine(cfg)
	return e
}

// WithReconsolidation wires the memory labile window engine.
func (e *Engine) WithReconsolidation(cfg cognitive.ReconsolidationConfig) *Engine {
	e.reconsol = cognitive.NewReconsolidationEngine(cfg)
	return e
}

// WithHNSWPath sets the path for persisting the HNSW vector index to disk.
// If a saved index exists at this path, it is loaded at Engine creation time.
// The index is saved after every insert and periodically to this path.
func (e *Engine) WithHNSWPath(path string) *Engine {
	e.hnswPath = path
	if e.hnsw != nil {
		e.hnsw.autoSavePath = path
	}
	return e
}

// WithEmbedder wires an embedding provider so the fused-recall vector path can
// embed the query text itself (true semantic retrieval). Without it, the vector
// signal falls back to using the top BM25 hit's stored embedding as a proxy,
// which biases the vector results toward what BM25 already found.
func (e *Engine) WithEmbedder(p embeddings.Provider) *Engine {
	e.embedder = p
	return e
}

// Zeigarnik returns the open-loop detection engine (may be nil).
func (e *Engine) Zeigarnik() *cognitive.ZeigarnikEngine { return e.zeigarnik }

// Prospective returns the trigger-based future memory engine (may be nil).
func (e *Engine) Prospective() *cognitive.ProspectiveEngine { return e.prospective }

// Epistemic returns the knowledge gap detection engine (may be nil).
func (e *Engine) Epistemic() *cognitive.EpistemicEngine { return e.epistemic }

// Somatic returns the valence/arousal outcome tracking engine (may be nil).
func (e *Engine) Somatic() *cognitive.SomaticEngine { return e.somatic }

// Curiosity returns the exploration target engine (may be nil).
func (e *Engine) Curiosity() *cognitive.CuriosityEngine { return e.curiosity }

// Reconsolidation returns the memory labile window engine (may be nil).
func (e *Engine) Reconsolidation() *cognitive.ReconsolidationEngine { return e.reconsol }

// WithProcedural wires the procedural/workflow memory engine.
func (e *Engine) WithProcedural(cfg cognitive.ProceduralConfig) *Engine {
	e.procedural = cognitive.NewProceduralEngine(cfg)
	return e
}

// Procedural returns the procedural memory engine (may be nil).
func (e *Engine) Procedural() *cognitive.ProceduralEngine { return e.procedural }

// WithBoundaryDetector wires the semantic boundary detector.
func (e *Engine) WithBoundaryDetector(cfg cognitive.BoundaryConfig) *Engine {
	e.boundary = cognitive.NewBoundaryDetector(cfg)
	return e
}

// Boundary returns the semantic boundary detector (may be nil).
func (e *Engine) Boundary() *cognitive.BoundaryDetector { return e.boundary }

// WithConsolidator wires the topic consolidation engine.
func (e *Engine) WithConsolidator(cfg ConsolidationConfig) *Engine {
	e.consolidator = NewTopicConsolidator(e.store, cfg)
	return e
}

// Consolidator returns the topic consolidator (may be nil).
func (e *Engine) Consolidator() *TopicConsolidator { return e.consolidator }

// WithMultiFactorRanker wires the multi-factor re-ranking engine.
func (e *Engine) WithMultiFactorRanker(cfg RankingWeights) *Engine {
	e.ranker = NewMultiFactorRanker(cfg)
	return e
}

// Ranker returns the multi-factor ranker (may be nil).
func (e *Engine) Ranker() *MultiFactorRanker { return e.ranker }

// WithDecayScheduler wires a periodic decay and garbage collection scheduler.
// The scheduler runs decay at the configured interval and optionally runs GC
// after each decay pass. Call Start() on the returned scheduler to begin.
func (e *Engine) WithDecayScheduler(interval time.Duration, gcEnabled bool) *Engine {
	e.decaySched = NewDecayScheduler(e.store, e.DecayConfig, interval, gcEnabled)
	return e
}

// DecayScheduler returns the periodic decay scheduler (may be nil).
func (e *Engine) DecayScheduler() *DecayScheduler { return e.decaySched }

// WithSummarizer sets a custom summarizer for compaction (e.g., LLM-backed).
func (e *Engine) WithSummarizer(s compact.Summarizer) *Engine {
	e.summarizer = s
	return e
}

// WithLLMExtractor wires an LLM-based entity extractor. When set, Remember
// uses ExtractEntitiesWithLLM (LLM results merged with regex, deduped) for
// anchor-node extraction, falling back to regex-only when the LLM call fails.
// When nil (the default), entity extraction is regex-only — no behavior change
// for users without an LLM configured.
func (e *Engine) WithLLMExtractor(x *LLMExtractor) *Engine {
	e.llmExtractor = x
	return e
}

// LLMExtractor returns the engine's LLM entity extractor (may be nil).
func (e *Engine) LLMExtractor() *LLMExtractor { return e.llmExtractor }

// WithIntegrity sets the memory integrity checker for signature persistence.
func (e *Engine) WithIntegrity(mi *MemoryIntegrity) *Engine {
	e.integrity = mi
	return e
}

// Integrity returns the engine's memory integrity checker (may be nil).
func (e *Engine) Integrity() *MemoryIntegrity { return e.integrity }

// WithAddOnly toggles Mem0-v3-style single-pass ADD ingestion. When enabled,
// Remember skips conflict resolution / supersede so contradictory memories
// both persist as independent nodes. Default is false (conflict resolution on).
func (e *Engine) WithAddOnly(on bool) *Engine {
	e.addOnly = on
	return e
}

// AddOnly reports whether single-pass ADD-only ingestion is enabled.
func (e *Engine) AddOnly() bool { return e.addOnly }

// WithAuditLog wires an audit log into the engine for operation tracing.
func (e *Engine) WithAuditLog(al *AuditLog) *Engine {
	e.audit = al
	return e
}

// WithSearchDecay enables non-destructive search-time decay re-ranking.
// When set, FusedRecall applies half-life exponential decay to result scores
// at query time WITHOUT modifying stored confidence values. This allows
// different queries to use different decay profiles and preserves the
// original confidence for audit and export.
func (e *Engine) WithSearchDecay(halfLife time.Duration) *Engine {
	e.searchDecay = &SearchTimeDecay{HalfLife: halfLife}
	return e
}

// SearchDecay returns the engine's search-time decay configuration (may be nil).
func (e *Engine) SearchDecay() *SearchTimeDecay { return e.searchDecay }

// WithMemoryFile sets a path for a human-readable MEMORY.md hot-pointer file.
// When set, Remember and Forget update this file with a summary of hot-tier
// memories, making memory inspectable without MCP tools or the database.
func (e *Engine) WithMemoryFile(path string) *Engine {
	e.memoryFile = path
	return e
}

// renderMemoryFile writes a human-readable summary of hot-tier memories to the
// configured memory file. It is best-effort: a no-op when no file is configured.
func (e *Engine) renderMemoryFile(ctx context.Context) error {
	if e.memoryFile == "" {
		return nil
	}

	hot, err := e.store.ListNodes(ctx, storage.NodeFilter{Tier: 1, Limit: 100})
	if err != nil {
		return err
	}

	var sb strings.Builder
	sb.WriteString("# Memory Index\n\n")
	fmt.Fprintf(&sb, "_Auto-generated by harrier. %d hot-tier memories._\n\n", len(hot))
	for _, n := range hot {
		label := n.Summary
		if label == "" {
			label = n.Content
		}
		label = strings.ReplaceAll(label, "\n", " ")
		if len(label) > 100 {
			label = label[:100] + "..."
		}
		fmt.Fprintf(&sb, "- **%s** [%s] (tier %d, conf %.1f)\n", label, n.Type, n.Tier, n.Confidence)
	}

	return os.WriteFile(e.memoryFile, []byte(sb.String()), 0o600)
}

// Close shuts down the engine and its background workers.
func (e *Engine) Close() {
	// Stop decay scheduler if running.
	if e.decaySched != nil {
		e.decaySched.Stop()
	}
	// Stop the background consolidation loop if running.
	e.StopConsolidation()
	// Clean up cognitive engine in-memory state before shutdown.
	if e.epistemic != nil {
		e.epistemic.ExpireOld()
	}
	if e.reconsol != nil {
		e.reconsol.Cleanup()
	}
	if e.prospective != nil {
		e.prospective.CleanExpired()
	}
	if e.procedural != nil {
		e.procedural.Cleanup()
	}
	if e.audit != nil {
		e.audit.Close()
	}
	if e.access != nil {
		e.access.Stop()
		e.access.Flush(context.Background())
	}
}

// Graph returns the underlying graph engine.
func (e *Engine) Graph() graph.Graph { return e.graph }

// Store returns the underlying store.
func (e *Engine) Store() storage.Storage { return e.store }

// GetMetrics returns a copy of the engine's operational metrics.
func (e *Engine) GetMetrics() Metrics {
	return Metrics{
		Remembers:   atomic.LoadInt64(&e.metrics.Remembers),
		Recalls:     atomic.LoadInt64(&e.metrics.Recalls),
		Errors:      atomic.LoadInt64(&e.metrics.Errors),
		NodesStored: atomic.LoadInt64(&e.metrics.NodesStored),
	}
}
