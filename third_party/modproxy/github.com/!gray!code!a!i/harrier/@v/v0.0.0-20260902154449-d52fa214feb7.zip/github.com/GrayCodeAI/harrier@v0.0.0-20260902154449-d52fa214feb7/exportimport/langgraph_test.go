package exportimport

import (
	"context"
	"encoding/json"
	"testing"
)

func TestImportLangGraph_Basic(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	data := `[
		{"id": "msg1", "role": "user", "content": "Hello world", "metadata": {"source": "test"}},
		{"id": "msg2", "parent_id": "msg1", "role": "assistant", "content": "Hi there", "metadata": {"model": "gpt-4"}}
	]`

	count, err := ImportLangGraph(ctx, store, []byte(data))
	if err != nil {
		t.Fatalf("ImportLangGraph: %v", err)
	}
	if count != 2 {
		t.Fatalf("expected 2 imported, got %d", count)
	}

	// Verify nodes exist
	node, err := store.GetNode(ctx, "msg1")
	if err != nil {
		t.Fatalf("GetNode msg1: %v", err)
	}
	if node.Content != "Hello world" {
		t.Errorf("expected 'Hello world', got %q", node.Content)
	}
	if node.Type != "entity" {
		t.Errorf("expected type 'entity', got %q", node.Type)
	}
	if node.Tags != "role:user" {
		t.Errorf("expected tags 'role:user', got %q", node.Tags)
	}

	// Check that metadata was stored in summary
	node2, _ := store.GetNode(ctx, "msg2")
	if node2.Summary == "" {
		t.Error("expected metadata to be stored in Summary")
	}
}

func TestImportLangGraph_EmptyEntries(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	// Entries with empty ID or content should be skipped
	data := `[
		{"id": "", "role": "user", "content": "should be skipped"},
		{"id": "valid1", "role": "user", "content": ""},
		{"id": "valid2", "role": "user", "content": "good entry"}
	]`

	count, err := ImportLangGraph(ctx, store, []byte(data))
	if err != nil {
		t.Fatalf("ImportLangGraph: %v", err)
	}
	if count != 1 {
		t.Fatalf("expected 1 imported (skipping empty id/content), got %d", count)
	}
}

func TestImportLangGraph_InvalidJSON(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	_, err := ImportLangGraph(ctx, store, []byte("not valid json"))
	if err == nil {
		t.Fatal("expected error for invalid JSON")
	}
}

func TestImportLangGraph_Duplicates(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	data := `[{"id": "dup1", "role": "user", "content": "hello"}]`

	count1, _ := ImportLangGraph(ctx, store, []byte(data))
	if count1 != 1 {
		t.Fatalf("expected 1 on first import, got %d", count1)
	}

	// Import again, duplicates should be skipped
	count2, err := ImportLangGraph(ctx, store, []byte(data))
	if err != nil {
		t.Fatalf("second import: %v", err)
	}
	if count2 != 0 {
		t.Fatalf("expected 0 on re-import (duplicates), got %d", count2)
	}
}

func TestExportForLangGraph_Basic(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	// Import some data first
	data := `[
		{"id": "exp1", "role": "user", "content": "Test export", "metadata": {"key": "val"}},
		{"id": "exp2", "parent_id": "exp1", "role": "assistant", "content": "Response here"}
	]`
	ImportLangGraph(ctx, store, []byte(data))

	// Export — note: nodes have no Project set via ImportLangGraph, so filter by empty project
	exported, err := ExportForLangGraph(ctx, store, "")
	if err != nil {
		t.Fatalf("ExportForLangGraph: %v", err)
	}

	var entries []LangGraphEntry
	if err := json.Unmarshal(exported, &entries); err != nil {
		t.Fatalf("unmarshal exported: %v", err)
	}
	if len(entries) < 2 {
		t.Fatalf("expected at least 2 entries, got %d", len(entries))
	}

	// Find exp1 and verify
	found := false
	for _, e := range entries {
		if e.ID == "exp1" {
			found = true
			if e.Role != "user" {
				t.Errorf("expected role 'user', got %q", e.Role)
			}
			if e.Content != "Test export" {
				t.Errorf("expected content 'Test export', got %q", e.Content)
			}
			if e.Metadata == nil || e.Metadata["key"] != "val" {
				t.Errorf("expected metadata with key=val, got %v", e.Metadata)
			}
		}
	}
	if !found {
		t.Error("expected to find exp1 in export")
	}

	// Find exp2 and verify parent_id
	for _, e := range entries {
		if e.ID == "exp2" {
			if e.ParentID != "exp1" {
				t.Errorf("expected parent_id 'exp1', got %q", e.ParentID)
			}
		}
	}
}

func TestExportForLangGraph_EmptyProject(t *testing.T) {
	t.Parallel()
	store := setupStore(t)
	ctx := context.Background()

	exported, err := ExportForLangGraph(ctx, store, "nonexistent")
	if err != nil {
		t.Fatalf("ExportForLangGraph: %v", err)
	}

	var entries []LangGraphEntry
	if err := json.Unmarshal(exported, &entries); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(entries) != 0 {
		t.Fatalf("expected 0 entries for empty project, got %d", len(entries))
	}
}

func TestExtractRole(t *testing.T) {
	t.Parallel()
	tests := []struct {
		tags     string
		expected string
	}{
		{"role:user", "user"},
		{"role:assistant", "assistant"},
		{"role:", ""},
		{"", ""},
		{"other:tag", ""},
	}
	for _, tc := range tests {
		got := extractRole(tc.tags)
		if got != tc.expected {
			t.Errorf("extractRole(%q) = %q, want %q", tc.tags, got, tc.expected)
		}
	}
}
