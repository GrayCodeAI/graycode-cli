// This file is part of package server tests. It holds the MCP link,
// subgraph, status, session, skill, feedback, context, and
// clamp/cancellation tests moved verbatim out of mcp_test.go for
// readability; behavior is unchanged.

package server

import (
	"context"
	"encoding/json"
	"runtime"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestMCPLinkAndUnlink(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	idA := rememberAndID(t, srv, "node A", "decision")
	idB := rememberAndID(t, srv, "node B", "convention")
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	// Link.
	req := toolRequest("harrier_link", map[string]any{
		"from_id": idA,
		"to_id":   idB,
		"type":    "relates_to",
	})
	res, err := srv.handleLink(ctx, req)
	if err != nil {
		t.Fatalf("handleLink: %v", err)
	}
	text := textContent(res)
	if !strings.Contains(text, idA) || !strings.Contains(text, idB) {
		t.Errorf("link result should contain node IDs, got %q", text)
	}

	// Parse edge to get ID for unlink.
	var edge storage.Edge
	json.Unmarshal([]byte(text), &edge)

	// Unlink.
	req = toolRequest("harrier_unlink", map[string]any{"id": edge.ID})
	res, err = srv.handleUnlink(ctx, req)
	if err != nil {
		t.Fatalf("handleUnlink: %v", err)
	}
	if textContent(res) != "unlinked" {
		t.Errorf("unlink result = %q, want 'unlinked'", textContent(res))
	}
}

func TestMCPLinkInvalidEdgeType(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	idA := rememberAndID(t, srv, "A", "decision")
	idB := rememberAndID(t, srv, "B", "decision")
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	req := toolRequest("harrier_link", map[string]any{
		"from_id": idA,
		"to_id":   idB,
		"type":    "invalid_edge_xyz",
	})
	_, err := srv.handleLink(ctx, req)
	if err == nil {
		t.Fatal("expected error for invalid edge type")
	}
	if !strings.Contains(err.Error(), "invalid edge type") {
		t.Errorf("error = %q, want 'invalid edge type'", err.Error())
	}
}

func TestMCPLinkMissingEdgeType(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	idA := rememberAndID(t, srv, "A", "decision")
	idB := rememberAndID(t, srv, "B", "decision")
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	req := toolRequest("harrier_link", map[string]any{
		"from_id": idA,
		"to_id":   idB,
	})
	_, err := srv.handleLink(ctx, req)
	if err == nil {
		t.Fatal("expected error for missing edge type")
	}
}

func TestMCPSubgraph(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	idA := rememberAndID(t, srv, "center node", "decision")
	idB := rememberAndID(t, srv, "neighbor node", "convention")
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	// Create an edge so BFS finds the neighbor.
	edgeReq := toolRequest("harrier_link", map[string]any{
		"from_id": idA,
		"to_id":   idB,
		"type":    "relates_to",
	})
	srv.handleLink(ctx, edgeReq)
	runtime.Gosched()
	time.Sleep(5 * time.Millisecond)

	req := toolRequest("harrier_subgraph", map[string]any{
		"id":    idA,
		"depth": float64(2),
	})
	res, err := srv.handleSubgraph(ctx, req)
	if err != nil {
		t.Fatalf("handleSubgraph: %v", err)
	}
	text := textContent(res)
	if text == "" || text == "null" {
		t.Error("expected non-empty subgraph")
	}
}

func TestMCPStatus(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	rememberAndID(t, srv, "status test node", "decision")

	req := toolRequest("harrier_status", map[string]any{})
	res, err := srv.handleStatus(ctx, req)
	if err != nil {
		t.Fatalf("handleStatus: %v", err)
	}
	text := textContent(res)
	if !strings.Contains(text, "Nodes") {
		t.Errorf("status result should contain 'Nodes', got %q", text)
	}
}

func TestMCPSessions(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_sessions", map[string]any{"limit": float64(5)})
	res, err := srv.handleSessions(ctx, req)
	if err != nil {
		t.Fatalf("handleSessions: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPSkillStoreAndGet(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	steps, _ := json.Marshal([]string{"Step 1: Write code", "Step 2: Write tests", "Step 3: Submit PR"})

	// Store skill.
	req := toolRequest("harrier_skill_store", map[string]any{
		"name":        "code-review-workflow",
		"description": "Standard code review workflow",
		"steps":       string(steps),
	})
	res, err := srv.handleSkillStore(ctx, req)
	if err != nil {
		t.Fatalf("handleSkillStore: %v", err)
	}
	text := textContent(res)
	if !strings.Contains(text, "code-review-workflow") {
		t.Errorf("skill store result = %q, want to contain skill name", text)
	}
}

func TestMCPSkillStoreInvalidSteps(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	req := toolRequest("harrier_skill_store", map[string]any{
		"name":        "bad-skill",
		"description": "invalid steps",
		"steps":       "not a json array",
	})
	_, err := srv.handleSkillStore(ctx, req)
	if err == nil {
		t.Fatal("expected error for invalid steps JSON")
	}
	if !strings.Contains(err.Error(), "JSON array") {
		t.Errorf("error = %q, want 'JSON array'", err.Error())
	}
}

func TestMCPFeedbackApprove(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "pending memory", "decision")

	req := toolRequest("harrier_feedback", map[string]any{
		"id":     id,
		"action": "approve",
	})
	res, err := srv.handleFeedback(ctx, req)
	if err != nil {
		t.Fatalf("handleFeedback approve: %v", err)
	}
	if !strings.Contains(textContent(res), "approve") {
		t.Errorf("expected 'approve' in result, got %q", textContent(res))
	}
}

func TestMCPFeedbackEdit(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "memory to edit", "decision")

	req := toolRequest("harrier_feedback", map[string]any{
		"id":      id,
		"action":  "edit",
		"content": "edited content",
	})
	res, err := srv.handleFeedback(ctx, req)
	if err != nil {
		t.Fatalf("handleFeedback edit: %v", err)
	}
	if !strings.Contains(textContent(res), "edit") {
		t.Errorf("expected 'edit' in result, got %q", textContent(res))
	}
}

func TestMCPFeedbackDiscard(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "memory to discard", "decision")

	req := toolRequest("harrier_feedback", map[string]any{
		"id":     id,
		"action": "discard",
	})
	res, err := srv.handleFeedback(ctx, req)
	if err != nil {
		t.Fatalf("handleFeedback discard: %v", err)
	}
	if !strings.Contains(textContent(res), "discard") {
		t.Errorf("expected 'discard' in result, got %q", textContent(res))
	}
}

func TestMCPFeedbackInvalidAction(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "some memory", "decision")

	req := toolRequest("harrier_feedback", map[string]any{
		"id":     id,
		"action": "invalid_action",
	})
	_, err := srv.handleFeedback(ctx, req)
	if err == nil {
		t.Fatal("expected error for invalid feedback action")
	}
}

// ---------------------------------------------------------------------------
// 4. Error handling — malformed requests, edge cases
// ---------------------------------------------------------------------------

func TestMCPRecallEmptyQuery(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	// Empty query should not error — it should list nodes.
	req := toolRequest("harrier_recall", map[string]any{
		"query": "",
		"limit": float64(5),
	})
	res, err := srv.handleRecall(ctx, req)
	if err != nil {
		t.Fatalf("recall with empty query should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPContext(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	rememberAndID(t, srv, "context test", "decision")

	req := toolRequest("harrier_context", map[string]any{})
	res, err := srv.handleContext(ctx, req)
	if err != nil {
		t.Fatalf("handleContext: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPContextCanceled(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	cancel() // cancel immediately

	req := toolRequest("harrier_context", map[string]any{})
	_, err := srv.handleContext(ctx, req)
	if err == nil {
		t.Fatal("expected error from canceled context")
	}
}

func TestMCPRecallCanceledContext(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	req := toolRequest("harrier_recall", map[string]any{"query": "test"})
	_, err := srv.handleRecall(ctx, req)
	if err == nil {
		t.Fatal("expected error from canceled context")
	}
}

func TestMCPRememberCanceledContext(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	req := toolRequest("harrier_remember", map[string]any{"content": "test"})
	_, err := srv.handleRemember(ctx, req)
	if err == nil {
		t.Fatal("expected error from canceled context")
	}
}

func TestMCPForgetCanceledContext(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	req := toolRequest("harrier_forget", map[string]any{"id": "any"})
	_, err := srv.handleForget(ctx, req)
	if err == nil {
		t.Fatal("expected error from canceled context")
	}
}

func TestMCPImpactCanceledContext(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	req := toolRequest("harrier_impact", map[string]any{"file": "/some/file.go"})
	_, err := srv.handleImpact(ctx, req)
	if err == nil {
		t.Fatal("expected error from canceled context")
	}
}

func TestMCPSubgraphDepthClamp(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	id := rememberAndID(t, srv, "depth test", "decision")

	// depth > 5 should be clamped to 2.
	req := toolRequest("harrier_subgraph", map[string]any{
		"id":    id,
		"depth": float64(99),
	})
	res, err := srv.handleSubgraph(ctx, req)
	if err != nil {
		t.Fatalf("subgraph with clamped depth should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPImpactDepthClamp(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	// depth > 5 should be clamped to 3.
	req := toolRequest("harrier_impact", map[string]any{
		"file":  "/some/file.go",
		"depth": float64(99),
	})
	res, err := srv.handleImpact(ctx, req)
	if err != nil {
		t.Fatalf("impact with clamped depth should not error: %v", err)
	}
	if res == nil {
		t.Fatal("expected non-nil result")
	}
}

func TestMCPRememberContentTooLong(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	longContent := strings.Repeat("x", 20000)
	req := toolRequest("harrier_remember", map[string]any{
		"content": longContent,
	})
	_, err := srv.handleRemember(ctx, req)
	if err == nil {
		t.Fatal("expected error for content exceeding max length")
	}
	if !strings.Contains(err.Error(), "max length") {
		t.Errorf("error = %q, want 'max length'", err.Error())
	}
}

func TestMCPVerifyWithoutIntegrity(t *testing.T) {
	t.Parallel()
	srv, _, cleanup := setupMCPServer(t)
	defer cleanup()

	ctx := context.Background()
	// Engine is created without WithIntegrity, so verify should fail.
	req := toolRequest("harrier_verify", map[string]any{})
	_, err := srv.handleVerify(ctx, req)
	if err == nil {
		t.Fatal("expected error when integrity checker not configured")
	}
	if !strings.Contains(err.Error(), "integrity checker not configured") {
		t.Errorf("error = %q, want 'integrity checker not configured'", err.Error())
	}
}

// ---------------------------------------------------------------------------
// 5. Concurrency — parallel memory operations
// ---------------------------------------------------------------------------
