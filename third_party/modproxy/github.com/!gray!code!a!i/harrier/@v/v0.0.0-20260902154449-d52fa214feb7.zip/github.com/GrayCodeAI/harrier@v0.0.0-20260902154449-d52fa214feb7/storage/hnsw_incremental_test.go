package storage

import (
	"context"
	"fmt"
	"testing"
)

// seedHNSW creates n nodes with angle-distinct embeddings (dim 0 = 1,
// dim 1 = i*step) and builds the HNSW index for the given model.
func seedHNSW(t *testing.T, s *Store, model string, n int, step float32) {
	t.Helper()
	ctx := context.Background()
	for i := 0; i < n; i++ {
		id := fmt.Sprintf("h-%d", i)
		if err := s.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h-" + id, Scope: "project", Project: "test",
		}); err != nil {
			t.Fatalf("CreateNode %s: %v", id, err)
		}
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = float32(i) * step
		if err := s.SaveEmbedding(ctx, id, model, vec); err != nil {
			t.Fatalf("SaveEmbedding %s: %v", id, err)
		}
	}
	if err := s.BuildHNSWIndex(ctx, model); err != nil {
		t.Fatalf("BuildHNSWIndex: %v", err)
	}
}

func dirVec(t *testing.T, d float32) []float32 {
	t.Helper()
	v := make([]float32, 8)
	v[0] = 1.0
	v[1] = d
	return v
}

// TestHNSWIncrementalUpsert verifies SaveEmbedding updates a built index
// without requiring an explicit BuildHNSWIndex.
func TestHNSWIncrementalUpsert(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	model := "inc-model"
	seedHNSW(t, s, model, 10, 0.1) // h-0..h-9 cover dir 0..0.9

	// Add a brand-new node; it must become searchable immediately.
	if err := s.CreateNode(ctx, &Node{
		ID: "h-new", Type: "convention", Content: "h-new",
		ContentHash: "h-h-new", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}
	// Exact match for direction 2.0, far outside the seeded range.
	newVec := make([]float32, 8)
	newVec[0] = 1.0
	newVec[1] = 2.0
	if err := s.SaveEmbedding(ctx, "h-new", model, newVec); err != nil {
		t.Fatalf("SaveEmbedding upsert: %v", err)
	}
	ids, _, err := s.SearchHNSW(ctx, model, dirVec(t, 2.0), 1, 50)
	if err != nil {
		t.Fatalf("SearchHNSW: %v", err)
	}
	if len(ids) != 1 || ids[0] != "h-new" {
		t.Fatalf("expected top result h-new, got %v", ids)
	}

	// The affected node must be persisted in embeddings_hnsw without a rebuild.
	var count int
	if err := s.DB().QueryRowContext(ctx,
		`SELECT COUNT(*) FROM embeddings_hnsw WHERE node_id=?`, "h-new").Scan(&count); err != nil {
		t.Fatal(err)
	}
	if count != 1 {
		t.Errorf("embeddings_hnsw rows for h-new = %d, want 1", count)
	}

	// Replace h-5's vector (was dir 0.5) with dir 3.0: it must now rank
	// first for queries in that direction.
	rep := make([]float32, 8)
	rep[0] = 1.0
	rep[1] = 3.0
	if err := s.SaveEmbedding(ctx, "h-5", model, rep); err != nil {
		t.Fatalf("SaveEmbedding replace: %v", err)
	}
	ids, _, err = s.SearchHNSW(ctx, model, dirVec(t, 3.0), 1, 50)
	if err != nil {
		t.Fatalf("SearchHNSW after replace: %v", err)
	}
	if len(ids) != 1 || ids[0] != "h-5" {
		t.Fatalf("expected top result h-5 after replace, got %v", ids)
	}
	// And it must NOT be the top hit for its old direction any more.
	ids, _, err = s.SearchHNSW(ctx, model, dirVec(t, 0.5), 1, 50)
	if err != nil {
		t.Fatal(err)
	}
	if len(ids) != 1 || ids[0] == "h-5" {
		t.Errorf("h-5 still top-ranked for old direction: %v", ids)
	}
}

// TestHNSWIncrementalDelete verifies DeleteEmbedding detaches the node from
// the index and clears its persisted graph row.
func TestHNSWIncrementalDelete(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	model := "del-model"
	seedHNSW(t, s, model, 10, 0.1)

	// h-9 (dir 0.9) is the only node near dir 0.9.
	ids, _, err := s.SearchHNSW(ctx, model, dirVec(t, 0.9), 1, 50)
	if err != nil {
		t.Fatal(err)
	}
	if len(ids) != 1 || ids[0] != "h-9" {
		t.Fatalf("expected h-9 initially, got %v", ids)
	}

	if err := s.DeleteEmbedding(ctx, "h-9"); err != nil {
		t.Fatalf("DeleteEmbedding: %v", err)
	}

	ids, _, err = s.SearchHNSW(ctx, model, dirVec(t, 0.9), 5, 50)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range ids {
		if id == "h-9" {
			t.Fatalf("h-9 still returned after delete: %v", ids)
		}
	}

	// Persisted graph row must be gone.
	var count int
	if err := s.DB().QueryRowContext(ctx,
		`SELECT COUNT(*) FROM embeddings_hnsw WHERE node_id=?`, "h-9").Scan(&count); err != nil {
		t.Fatal(err)
	}
	if count != 0 {
		t.Errorf("embeddings_hnsw rows for h-9 after delete = %d, want 0", count)
	}
}

// TestHNSWTransactionalInvalidation verifies embedding writes inside WithTx
// drop the cached index so the next search rebuilds from the embeddings table.
func TestHNSWTransactionalInvalidation(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	model := "tx-model"
	seedHNSW(t, s, model, 10, 0.1) // cache built for tx-model

	err := s.WithTx(ctx, func(tx Storage) error {
		if err := tx.CreateNode(ctx, &Node{
			ID: "tx-node", Type: "convention", Content: "tx-node",
			ContentHash: "h-tx-node", Scope: "project", Project: "test",
		}); err != nil {
			return err
		}
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = 5.0 // far outside seeded range
		return tx.SaveEmbedding(ctx, "tx-node", model, vec)
	})
	if err != nil {
		t.Fatalf("WithTx: %v", err)
	}

	// The cache must have been invalidated and rebuilt from the table.
	ids, _, err := s.SearchHNSW(ctx, model, dirVec(t, 5.0), 1, 50)
	if err != nil {
		t.Fatalf("SearchHNSW after tx: %v", err)
	}
	if len(ids) != 1 || ids[0] != "tx-node" {
		t.Fatalf("expected tx-node after transactional save, got %v", ids)
	}
}

// TestHNSWIncrementalVsFullBuild checks the incrementally-mutated index
// still agrees with a full rebuild on the same data.
func TestHNSWIncrementalVsFullBuild(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	model := "parity-model"
	seedHNSW(t, s, model, 10, 0.1)

	// Several incremental mutations.
	for i := 0; i < 3; i++ {
		id := fmt.Sprintf("extra-%d", i)
		if err := s.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h-" + id, Scope: "project", Project: "test",
		}); err != nil {
			t.Fatal(err)
		}
		v := make([]float32, 8)
		v[0] = 1.0
		v[1] = 1.0 + float32(i)*0.2
		if err := s.SaveEmbedding(ctx, id, model, v); err != nil {
			t.Fatal(err)
		}
	}
	for _, id := range []string{"h-0", "h-1", "extra-0"} {
		if err := s.DeleteEmbedding(ctx, id); err != nil {
			t.Fatalf("DeleteEmbedding %s: %v", id, err)
		}
	}

	query := dirVec(t, 1.2)
	incIDs, _, err := s.SearchHNSW(ctx, model, query, 5, 100)
	if err != nil {
		t.Fatal(err)
	}

	// Full rebuild must return the same membership for the top-5.
	if err := s.BuildHNSWIndex(ctx, model); err != nil {
		t.Fatal(err)
	}
	fullIDs, fullScores, err := s.SearchHNSW(ctx, model, query, 5, 100)
	if err != nil {
		t.Fatal(err)
	}

	if len(fullIDs) != len(incIDs) {
		t.Fatalf("result counts differ: incremental %d vs full %d", len(incIDs), len(fullIDs))
	}
	seen := make(map[string]bool, len(incIDs))
	for _, id := range incIDs {
		seen[id] = true
	}
	for _, id := range fullIDs {
		if !seen[id] {
			t.Errorf("full build returned %s missing from incremental results %v", id, incIDs)
		}
	}
	if len(fullScores) != 5 {
		t.Fatalf("expected 5 scores, got %d", len(fullScores))
	}
}
