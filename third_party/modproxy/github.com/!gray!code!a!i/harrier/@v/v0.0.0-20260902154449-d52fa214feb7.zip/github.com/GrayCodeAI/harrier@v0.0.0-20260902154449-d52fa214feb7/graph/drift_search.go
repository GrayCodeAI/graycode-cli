package graph

import (
	"sort"

	"github.com/GrayCodeAI/harrier/storage"
)

// DriftSearcher implements GraphRAG's "drift search" pattern: start at a high-level
// community, drill down based on relevance to the query, and return the most relevant
// nodes. This hierarchical approach is more effective than flat search for structured
// knowledge because it leverages the community topology to narrow focus quickly.
type DriftSearcher struct {
	// Searcher is used for BM25 ranking at each level.
	Searcher *CommunitySearcher
	// MaxResults caps the number of returned nodes.
	MaxResults int
}

// NewDriftSearcher creates a drift searcher with the given node data.
func NewDriftSearcher(nodes []*storage.Node, maxResults int) *DriftSearcher {
	if maxResults <= 0 {
		maxResults = 20
	}
	return &DriftSearcher{
		Searcher:   NewCommunitySearcher(nodes),
		MaxResults: maxResults,
	}
}

// DriftSearch performs hierarchical community-guided search.
//
// Algorithm (inspired by GraphRAG DRIFT):
//  1. Start at the highest (coarsest) level of the community hierarchy.
//  2. Rank communities at that level by relevance to the query.
//  3. Select the top-k most relevant communities.
//  4. Drill down: for each selected community, find its sub-communities at the next level.
//  5. Repeat until reaching Level 0 (finest granularity).
//  6. Expand the final communities into individual nodes, ranked by relevance.
//
// This is fundamentally different from flat vector search: it uses the graph's
// community structure as a "table of contents" to navigate to relevant regions
// without scoring every node individually.
func (ds *DriftSearcher) DriftSearch(query string, hierarchy [][]Community) []*storage.Node {
	if len(hierarchy) == 0 || query == "" {
		return nil
	}

	// Start from the top (coarsest) level.
	topLevel := len(hierarchy) - 1

	// Rank communities at the top level.
	ranked := ds.Searcher.RankCommunitiesByRelevance(query, hierarchy[topLevel])
	if len(ranked) == 0 {
		// Fallback: try each level from top to bottom.
		for lv := topLevel; lv >= 0; lv-- {
			ranked = ds.Searcher.RankCommunitiesByRelevance(query, hierarchy[lv])
			if len(ranked) > 0 {
				topLevel = lv
				break
			}
		}
		if len(ranked) == 0 {
			return nil
		}
	}

	// Select top-k at each level (beam width).
	const beamWidth = 3

	selectedNodeSets := topKNodeSets(ranked, beamWidth)

	// Drill down through levels.
	for lv := topLevel - 1; lv >= 0; lv-- {
		// Find sub-communities at this level whose nodes overlap with selected sets.
		candidates := ds.findSubCommunities(hierarchy[lv], selectedNodeSets)
		if len(candidates) == 0 {
			continue
		}

		// Rank candidates by query relevance.
		ranked = ds.Searcher.RankCommunitiesByRelevance(query, candidates)
		if len(ranked) == 0 {
			ranked = candidates
		}

		selectedNodeSets = topKNodeSets(ranked, beamWidth)
	}

	// Collect all node IDs from final selected communities.
	nodeIDSet := make(map[string]bool)
	for _, nodeSet := range selectedNodeSets {
		for nid := range nodeSet {
			nodeIDSet[nid] = true
		}
	}

	// Expand to full nodes and rank by content relevance.
	nodes := make([]*storage.Node, 0, len(nodeIDSet))
	for nid := range nodeIDSet {
		if n, ok := ds.Searcher.NodeLookup[nid]; ok {
			nodes = append(nodes, n)
		}
	}

	// Final ranking: score each node by BM25 against query.
	nodes = ds.rankNodesByRelevance(query, nodes)

	if len(nodes) > ds.MaxResults {
		nodes = nodes[:ds.MaxResults]
	}

	return nodes
}

// findSubCommunities returns communities from the given level whose nodes
// overlap with any of the selected node sets from the level above.
func (ds *DriftSearcher) findSubCommunities(levelCommunities []Community, parentNodeSets []map[string]bool) []Community {
	var result []Community
	for _, c := range levelCommunities {
		for _, parentSet := range parentNodeSets {
			if communityOverlaps(c, parentSet) {
				result = append(result, c)
				break
			}
		}
	}
	return result
}

// communityOverlaps checks if any node in the community belongs to the parent set.
func communityOverlaps(c Community, parentNodeSet map[string]bool) bool {
	for _, nid := range c.NodeIDs {
		if parentNodeSet[nid] {
			return true
		}
	}
	return false
}

// topKNodeSets extracts the node ID sets from the top-k communities.
func topKNodeSets(communities []Community, k int) []map[string]bool {
	if k > len(communities) {
		k = len(communities)
	}
	result := make([]map[string]bool, k)
	for i := 0; i < k; i++ {
		set := make(map[string]bool, len(communities[i].NodeIDs))
		for _, nid := range communities[i].NodeIDs {
			set[nid] = true
		}
		result[i] = set
	}
	return result
}

// rankNodesByRelevance scores individual nodes against the query using term matching.
func (ds *DriftSearcher) rankNodesByRelevance(query string, nodes []*storage.Node) []*storage.Node {
	queryTerms := tokenize(query)
	if len(queryTerms) == 0 {
		return nodes
	}

	type scored struct {
		node  *storage.Node
		score float64
	}

	items := make([]scored, 0, len(nodes))
	for _, n := range nodes {
		content := n.Content
		if n.Summary != "" {
			content += " " + n.Summary
		}
		docTerms := tokenize(content)

		// Simple term frequency scoring.
		tf := make(map[string]int)
		for _, t := range docTerms {
			tf[t]++
		}

		score := 0.0
		for _, qt := range queryTerms {
			score += float64(tf[qt])
		}

		// Boost by confidence and recency (higher tier = more relevant).
		score *= n.Confidence
		if n.Tier == 1 {
			score *= 1.5
		}

		items = append(items, scored{node: n, score: score})
	}

	sort.Slice(items, func(i, j int) bool {
		return items[i].score > items[j].score
	})

	result := make([]*storage.Node, len(items))
	for i, item := range items {
		result[i] = item.node
	}
	return result
}
