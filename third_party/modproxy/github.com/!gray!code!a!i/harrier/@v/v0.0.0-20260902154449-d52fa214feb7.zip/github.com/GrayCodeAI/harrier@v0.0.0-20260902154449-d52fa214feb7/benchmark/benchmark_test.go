// Package benchmark provides Go benchmarks for key harrier memory engine operations.
// These benchmarks measure real-world performance using SQLite-backed storage
// to capture actual I/O costs, not just in-memory mock overhead.
//
// Run all benchmarks:
//
//	go test ./benchmark/ -bench=. -benchmem -benchtime=3s
//
// Run a specific benchmark:
//
//	go test ./benchmark/ -bench=BenchmarkRemember -benchmem
package benchmark

import (
	"context"
	"fmt"
	"math/rand"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// benchEngine creates a real SQLite-backed engine for benchmarking.
func benchEngine(b *testing.B) (*engine.Engine, func()) {
	b.Helper()
	dir := b.TempDir()
	dbPath := filepath.Join(dir, "bench.db")
	store, err := storage.NewStore(dbPath)
	if err != nil {
		b.Fatalf("NewStore: %v", err)
	}
	g := graph.New(store, store.DB())
	eng := engine.New(store, g)
	return eng, func() {
		eng.Close()   // stop AccessTracker background goroutine
		store.Close() //nolint:errcheck // test cleanup
	}
}

// seedNodesFast inserts n distinct memory nodes directly into the store.
// Bypasses Remember's pipeline (privacy filter, entity extraction, self-linking)
// for fast setup of graph-only benchmarks (BFS, subgraph).
func seedNodesFast(b *testing.B, eng *engine.Engine, count int) []string {
	b.Helper()
	ctx := context.Background()
	store := eng.Store()
	ids := make([]string, 0, count)
	types := []string{"convention", "decision", "bug", "spec", "task", "preference"}
	contents := []string{
		"Use jose instead of jsonwebtoken for Edge runtime compatibility",
		"We chose NATS over Kafka for event bus due to simpler ops and backpressure support",
		"Auth middleware fails silently when JWT secret is rotated without restart",
		"The user authentication spec requires RS256 with 15min access token expiry",
		"Implement rate limiting on public API endpoints using token bucket algorithm",
		"Prefer functional style over class-based OOP in TypeScript modules",
		"Database queries should use DataLoader to prevent N+1 problems in GraphQL resolvers",
		"CI pipeline runs pnpm test on every PR with coverage threshold of 80 percent",
		"All new endpoints must have integration tests before merge to main branch",
		"Use Zod for runtime schema validation instead of manual type guards",
	}
	for i := 0; i < count; i++ {
		id := fmt.Sprintf("seed-node-%d", i)
		node := &storage.Node{
			ID:          id,
			Type:        types[i%len(types)],
			Content:     fmt.Sprintf("%s [seed-%d]", contents[i%len(contents)], i),
			ContentHash: fmt.Sprintf("hash-%d", i),
			Scope:       "project",
			Project:     "bench-project",
			Tier:        (i % 3) + 1,
			Confidence:  0.8,
		}
		if err := store.CreateNode(ctx, node); err != nil {
			b.Fatalf("seedNodesFast CreateNode[%d]: %v", i, err)
		}
		ids = append(ids, id)
	}
	return ids
}

// seedNodes inserts n distinct memory nodes via the full Remember pipeline.
// This populates FTS5, entity index, bloom filter, and creates self-links.
func seedNodes(b *testing.B, eng *engine.Engine, count int) []string {
	b.Helper()
	ctx := context.Background()
	ids := make([]string, 0, count)
	types := []string{"convention", "decision", "bug", "spec", "task", "preference"}
	contents := []string{
		"Use jose instead of jsonwebtoken for Edge runtime compatibility",
		"We chose NATS over Kafka for event bus due to simpler ops and backpressure support",
		"Auth middleware fails silently when JWT secret is rotated without restart",
		"The user authentication spec requires RS256 with 15min access token expiry",
		"Implement rate limiting on public API endpoints using token bucket algorithm",
		"Prefer functional style over class-based OOP in TypeScript modules",
		"Database queries should use DataLoader to prevent N+1 problems in GraphQL resolvers",
		"CI pipeline runs pnpm test on every PR with coverage threshold of 80 percent",
		"All new endpoints must have integration tests before merge to main branch",
		"Use Zod for runtime schema validation instead of manual type guards",
	}
	for i := 0; i < count; i++ {
		node, err := eng.Remember(ctx, engine.RememberInput{
			Type:    types[i%len(types)],
			Content: fmt.Sprintf("%s [seed-%d]", contents[i%len(contents)], i),
			Scope:   "project",
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("seedNodes Remember[%d]: %v", i, err)
		}
		ids = append(ids, node.ID)
	}
	return ids
}

// seedEdges creates edges between existing nodes to build a realistic graph.
func seedEdges(b *testing.B, eng *engine.Engine, ids []string, edgeCount int) {
	b.Helper()
	ctx := context.Background()
	rng := rand.New(rand.NewSource(42))
	edgeTypes := []string{"relates_to", "depends_on", "touches", "caused_by", "led_to"}
	for i := 0; i < edgeCount; i++ {
		from := ids[rng.Intn(len(ids))]
		to := ids[rng.Intn(len(ids))]
		if from == to {
			continue
		}
		_ = eng.Graph().AddEdge(ctx, &storage.Edge{
			ID:     fmt.Sprintf("edge-%d", i),
			FromID: from,
			ToID:   to,
			Type:   edgeTypes[i%len(edgeTypes)],
			Weight: 1.0,
		})
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Remember (Store Memory)
// ---------------------------------------------------------------------------

func BenchmarkRemember(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ctx := context.Background()
	contents := []string{
		"Use jose instead of jsonwebtoken for Edge runtime compatibility",
		"We chose NATS over Kafka for event bus due to simpler ops and backpressure",
		"Auth middleware fails silently when JWT secret is rotated without restart",
		"Database queries must use DataLoader to prevent N+1 in GraphQL resolvers",
		"Prefer functional style over class-based OOP in TypeScript modules",
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Remember(ctx, engine.RememberInput{
			Type:    "convention",
			Content: fmt.Sprintf("%s [bench-%d]", contents[i%len(contents)], i),
			Scope:   "project",
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("Remember: %v", err)
		}
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Recall (Search)
// ---------------------------------------------------------------------------

func BenchmarkRecall(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	seedNodes(b, eng, 50)

	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		// Use unique query per iteration to avoid cache hits.
		_, err := eng.Recall(ctx, engine.RecallOpts{
			Query:   fmt.Sprintf("query-%d authentication middleware", i),
			Depth:   2,
			Limit:   10,
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("Recall: %v", err)
		}
	}
}

func BenchmarkRecallLargeGraph(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodes(b, eng, 30)
	seedEdges(b, eng, ids, 60)

	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Recall(ctx, engine.RecallOpts{
			Query:   fmt.Sprintf("query-%d auth jose token", i),
			Depth:   3,
			Limit:   10,
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("Recall: %v", err)
		}
	}
}

// BenchmarkRecallEmptyQuery measures listing without a search query.
func BenchmarkRecallEmptyQuery(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	seedNodes(b, eng, 50)

	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Recall(ctx, engine.RecallOpts{
			Depth:   2,
			Limit:   10,
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("Recall: %v", err)
		}
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Context Loading
// ---------------------------------------------------------------------------

func BenchmarkContext(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	seedNodes(b, eng, 50)

	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Context(ctx, "bench-project")
		if err != nil {
			b.Fatalf("Context: %v", err)
		}
	}
}

func BenchmarkContextLargeGraph(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodes(b, eng, 50)
	seedEdges(b, eng, ids, 100)

	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Context(ctx, "bench-project")
		if err != nil {
			b.Fatalf("Context: %v", err)
		}
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Graph Traversal (BFS)
// ---------------------------------------------------------------------------

func BenchmarkGraphBFS(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodesFast(b, eng, 50)
	seedEdges(b, eng, ids, 100)

	// Pick a node in the middle of the graph as the BFS start.
	startID := ids[len(ids)/2]
	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Graph().BFS(ctx, startID, 3)
		if err != nil {
			b.Fatalf("BFS: %v", err)
		}
	}
}

func BenchmarkGraphBFSShallow(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodesFast(b, eng, 50)
	seedEdges(b, eng, ids, 100)

	startID := ids[0]
	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Graph().BFS(ctx, startID, 1)
		if err != nil {
			b.Fatalf("BFS: %v", err)
		}
	}
}

func BenchmarkGraphBFSDeep(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodesFast(b, eng, 50)
	seedEdges(b, eng, ids, 100)

	startID := ids[0]
	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Graph().BFS(ctx, startID, 5)
		if err != nil {
			b.Fatalf("BFS: %v", err)
		}
	}
}

// BenchmarkGraphExtractSubgraph measures BFS + node/edge batch fetch.
func BenchmarkGraphExtractSubgraph(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ids := seedNodesFast(b, eng, 50)
	seedEdges(b, eng, ids, 100)

	startID := ids[len(ids)/2]
	ctx := context.Background()

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Graph().ExtractSubgraph(ctx, startID, 3)
		if err != nil {
			b.Fatalf("ExtractSubgraph: %v", err)
		}
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Memory Compression (Compact)
// ---------------------------------------------------------------------------

func BenchmarkCompact(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ctx := context.Background()

	// Insert low-confidence nodes that are eligible for compaction.
	for i := 0; i < 30; i++ {
		node, err := eng.Remember(ctx, engine.RememberInput{
			Type:    "convention",
			Content: fmt.Sprintf("Low confidence memory %d for compaction testing with enough content", i),
			Scope:   "project",
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("seed: %v", err)
		}
		// Lower confidence so the compactor picks these up.
		node.Confidence = 0.3
		node.AccessCount = 1
		if err := eng.Store().UpdateNode(ctx, node); err != nil {
			b.Fatalf("update: %v", err)
		}
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		// Reset timer for compaction itself (setup is above).
		_, err := eng.Compact(ctx, "bench-project")
		if err != nil {
			b.Fatalf("Compact: %v", err)
		}
	}
}

// BenchmarkCompactSmall measures compaction on a small dataset.
func BenchmarkCompactSmall(b *testing.B) {
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ctx := context.Background()

	for i := 0; i < 10; i++ {
		node, err := eng.Remember(ctx, engine.RememberInput{
			Type:    "decision",
			Content: fmt.Sprintf("Small compaction test memory item number %d", i),
			Scope:   "project",
			Project: "bench-project",
		})
		if err != nil {
			b.Fatalf("seed: %v", err)
		}
		node.Confidence = 0.2
		node.AccessCount = 0
		if err := eng.Store().UpdateNode(ctx, node); err != nil {
			b.Fatalf("update: %v", err)
		}
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, err := eng.Compact(ctx, "bench-project")
		if err != nil {
			b.Fatalf("Compact: %v", err)
		}
	}
}

// ---------------------------------------------------------------------------
// Benchmark: HNSW Vector Index
// ---------------------------------------------------------------------------

func BenchmarkHNSWInsert(b *testing.B) {
	h := engine.NewHNSW(384)
	rng := rand.New(rand.NewSource(42))

	vecs := make([][]float32, b.N)
	for i := range vecs {
		vec := make([]float32, 384)
		for j := range vec {
			vec[j] = rng.Float32()
		}
		vecs[i] = vec
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.Insert(fmt.Sprintf("vec-%d", i), vecs[i])
	}
}

func BenchmarkHNSWSearch(b *testing.B) {
	h := engine.NewHNSW(384)
	rng := rand.New(rand.NewSource(42))

	for i := 0; i < 1000; i++ {
		vec := make([]float32, 384)
		for j := range vec {
			vec[j] = rng.Float32()
		}
		h.Insert(fmt.Sprintf("vec-%d", i), vec)
	}

	query := make([]float32, 384)
	for j := range query {
		query[j] = rng.Float32()
	}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		h.Search(query, 10)
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Entity Extraction
// ---------------------------------------------------------------------------

func BenchmarkExtractEntities(b *testing.B) {
	content := "Use jose instead of jsonwebtoken for Edge runtime compatibility. " +
		"Import from github.com/GrayCodeAI/harrier/storage and connect to " +
		"postgresql://localhost:5432/mydb. Call handleAuth() in auth.ts " +
		"with the NATS event bus at nats://localhost:4222."

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		engine.ExtractEntities(content)
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Privacy Filter
// ---------------------------------------------------------------------------

func BenchmarkPrivacyFilter(b *testing.B) {
	// Note: privacy.Filter is called internally by Remember.
	// This benchmarks the raw store path to isolate I/O cost.
	eng, cleanup := benchEngine(b)
	defer cleanup()

	ctx := context.Background()
	_ = seedNodes(b, eng, 20)

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = eng.Store().ListNodes(ctx, storage.NodeFilter{
			Project: "bench-project",
			Limit:   100,
		})
	}
}

// ---------------------------------------------------------------------------
// Benchmark: Bloom Filter
// ---------------------------------------------------------------------------

func BenchmarkBloomFilter(b *testing.B) {
	bloom := engine.NewBloomFilter(10000, 0.01)
	terms := []string{"jose", "jsonwebtoken", "authentication", "middleware", "NATS", "kafka"}

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		bloom.MayContainAny(terms[i%len(terms)])
	}
}

// ---------------------------------------------------------------------------
// Benchmark: ContextPacker
// ---------------------------------------------------------------------------

func BenchmarkContextPacker(b *testing.B) {
	nodes := make([]*storage.Node, 50)
	for i := range nodes {
		nodes[i] = &storage.Node{
			ID:         fmt.Sprintf("node-%d", i),
			Type:       []string{"convention", "decision", "bug", "spec", "task"}[i%5],
			Content:    fmt.Sprintf("Memory content for node %d with enough text to be realistic", i),
			Confidence: 0.8,
			Tier:       (i % 3) + 1,
		}
	}
	packer := engine.NewContextPacker(2000)

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		packer.Pack(nodes)
	}
}
