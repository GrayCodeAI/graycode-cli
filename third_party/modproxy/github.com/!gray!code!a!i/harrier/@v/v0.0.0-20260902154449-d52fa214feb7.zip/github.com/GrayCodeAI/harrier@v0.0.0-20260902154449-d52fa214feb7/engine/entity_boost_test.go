package engine

import (
	"context"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestEntityIndex_IndexAndBoost(t *testing.T) {
	t.Parallel()
	idx := NewEntityIndex()

	node1 := &storage.Node{ID: "n1", Content: "Use `jose` library for JWT in auth.ts"}
	node2 := &storage.Node{ID: "n2", Content: "The auth.ts file handles authentication"}
	node3 := &storage.Node{ID: "n3", Content: "Deploy to fly.io using Dockerfile"}

	idx.IndexNode(node1)
	idx.IndexNode(node2)
	idx.IndexNode(node3)

	if idx.Size() == 0 {
		t.Fatal("entity index is empty after indexing")
	}

	// Query about auth.ts should boost n1 and n2
	boosts := idx.BoostScores("what is auth.ts?")
	if boosts == nil {
		t.Fatal("expected boosts for auth.ts query")
	}
	if boosts["n1"] <= 1.0 && boosts["n2"] <= 1.0 {
		t.Errorf("expected n1 or n2 to be boosted for auth.ts query, got: %v", boosts)
	}

	// Query about Dockerfile should boost n3
	boosts2 := idx.BoostScores("Dockerfile")
	if boosts2 == nil || boosts2["n3"] <= 1.0 {
		t.Errorf("expected n3 boosted for Dockerfile query, got: %v", boosts2)
	}
}

func TestEntityIndex_RemoveNode(t *testing.T) {
	t.Parallel()
	idx := NewEntityIndex()

	node := &storage.Node{ID: "n1", Content: "Use jose for JWT tokens"}
	idx.IndexNode(node)

	sizeBefore := idx.Size()
	idx.RemoveNode("n1")

	if idx.Size() >= sizeBefore {
		t.Error("size should decrease after removal")
	}

	boosts := idx.BoostScores("jose JWT")
	if boosts != nil && boosts["n1"] > 1.0 {
		t.Error("removed node should not be boosted")
	}
}

func TestEntityIndex_EmptyContent(t *testing.T) {
	t.Parallel()
	idx := NewEntityIndex()
	idx.IndexNode(nil)
	idx.IndexNode(&storage.Node{ID: "x", Content: ""})
	if idx.Size() != 0 {
		t.Error("empty content should not add entities")
	}
}

func TestEntityIndex_LoadFromStore(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	defer func() { _ = store.Close() }()

	ctx := context.Background()
	_ = store.CreateNode(ctx, &storage.Node{
		ID: "t1", Type: "convention", Content: "Always use `prettier` for formatting",
		Scope: "project", Confidence: 0.8,
	})
	_ = store.CreateNode(ctx, &storage.Node{
		ID: "t2", Type: "decision", Content: "Chose PostgreSQL for database",
		Scope: "project", Confidence: 0.9,
	})

	idx := NewEntityIndex()
	if err := idx.LoadFromStore(ctx, store); err != nil {
		t.Fatalf("LoadFromStore failed: %v", err)
	}
	if idx.Size() == 0 {
		t.Error("expected entities after loading from store")
	}
}
