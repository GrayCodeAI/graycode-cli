package storage

import (
	"context"
	"fmt"
	"testing"
)

func TestSaveLoadNodeMetadataRoundTrip(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{ID: "n1", Type: "convention", Content: "c", ContentHash: "h1", Scope: "project"}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}

	meta := map[string]string{"lang": "go", "owner": "alice"}
	if err := s.SaveNodeMetadata(ctx, "n1", meta); err != nil {
		t.Fatalf("SaveNodeMetadata: %v", err)
	}

	loaded, err := s.LoadNodeMetadata(ctx, []string{"n1"})
	if err != nil {
		t.Fatalf("LoadNodeMetadata: %v", err)
	}
	got := loaded["n1"]
	if got["lang"] != "go" || got["owner"] != "alice" {
		t.Errorf("metadata mismatch: got %v", got)
	}
}

func TestSaveNodeMetadataReplaceSemantics(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{ID: "n1", Type: "convention", Content: "c", ContentHash: "h1", Scope: "project"}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}
	if err := s.SaveNodeMetadata(ctx, "n1", map[string]string{"a": "1", "b": "2"}); err != nil {
		t.Fatalf("first save: %v", err)
	}
	// Second save deletes existing rows then inserts new ones (upsert semantics):
	// the "a" key from the first save must be gone.
	if err := s.SaveNodeMetadata(ctx, "n1", map[string]string{"b": "20", "c": "3"}); err != nil {
		t.Fatalf("second save: %v", err)
	}

	loaded, err := s.LoadNodeMetadata(ctx, []string{"n1"})
	if err != nil {
		t.Fatalf("LoadNodeMetadata: %v", err)
	}
	got := loaded["n1"]
	if _, ok := got["a"]; ok {
		t.Errorf("key 'a' should have been replaced away, got %v", got)
	}
	if got["b"] != "20" {
		t.Errorf("b = %q, want 20", got["b"])
	}
	if got["c"] != "3" {
		t.Errorf("c = %q, want 3", got["c"])
	}
	if len(got) != 2 {
		t.Errorf("expected 2 metadata entries, got %d (%v)", len(got), got)
	}
}

func TestSaveNodeMetadataEmptyIsNoop(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.CreateNode(ctx, &Node{ID: "n1", Type: "convention", Content: "c", ContentHash: "h1", Scope: "project"}); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}
	if err := s.SaveNodeMetadata(ctx, "n1", map[string]string{"k": "v"}); err != nil {
		t.Fatalf("seed save: %v", err)
	}
	// saveNodeMetadataQ returns early for an empty map without deleting existing
	// rows, so the previously-stored value must survive.
	if err := s.SaveNodeMetadata(ctx, "n1", nil); err != nil {
		t.Fatalf("empty save: %v", err)
	}
	loaded, err := s.LoadNodeMetadata(ctx, []string{"n1"})
	if err != nil {
		t.Fatalf("LoadNodeMetadata: %v", err)
	}
	if loaded["n1"]["k"] != "v" {
		t.Errorf("empty save should not clear metadata, got %v", loaded["n1"])
	}
}

func TestLoadNodeMetadataEmptyInput(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	res, err := s.LoadNodeMetadata(ctx, nil)
	if err != nil {
		t.Fatalf("LoadNodeMetadata(nil): %v", err)
	}
	if res != nil {
		t.Errorf("expected nil result for empty input, got %v", res)
	}
}

func TestFillNodeMetadata(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"n1", "n2", "n3"} {
		if err := s.CreateNode(ctx, &Node{ID: id, Type: "convention", Content: id, ContentHash: "h" + id, Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}
	if err := s.SaveNodeMetadata(ctx, "n1", map[string]string{"x": "1"}); err != nil {
		t.Fatalf("SaveNodeMetadata n1: %v", err)
	}
	if err := s.SaveNodeMetadata(ctx, "n2", map[string]string{"y": "2"}); err != nil {
		t.Fatalf("SaveNodeMetadata n2: %v", err)
	}
	// n3 has no metadata on purpose.

	nodes := []*Node{
		{ID: "n1"}, {ID: "n2"}, {ID: "n3"},
	}
	if err := s.FillNodeMetadata(ctx, nodes); err != nil {
		t.Fatalf("FillNodeMetadata: %v", err)
	}
	if nodes[0].Metadata["x"] != "1" {
		t.Errorf("n1 metadata = %v, want x=1", nodes[0].Metadata)
	}
	if nodes[1].Metadata["y"] != "2" {
		t.Errorf("n2 metadata = %v, want y=2", nodes[1].Metadata)
	}
	if nodes[2].Metadata != nil {
		t.Errorf("n3 metadata should be nil, got %v", nodes[2].Metadata)
	}
}

func TestFillNodeMetadataEmptyIsNoop(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	if err := s.FillNodeMetadata(ctx, nil); err != nil {
		t.Errorf("FillNodeMetadata(nil): %v", err)
	}
}

// TestLoadNodeMetadataChunks is a regression test for the missing chunking in
// LoadNodeMetadata: it used to build a single IN (...) with every ID, which
// exceeds SQLite's host-parameter limit (maxSQLVariables = 900) once the ID
// set grew large enough. More than 900 IDs must load without error.
func TestLoadNodeMetadataChunks(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	const total = maxSQLVariables + 50 // forces at least two chunks
	ids := make([]string, total)
	for i := 0; i < total; i++ {
		ids[i] = fmt.Sprintf("meta-chunk-%d", i)
		if err := s.CreateNode(ctx, &Node{ID: ids[i], Type: "convention", Content: ids[i], ContentHash: "h" + ids[i], Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", ids[i], err)
		}
		if err := s.SaveNodeMetadata(ctx, ids[i], map[string]string{"idx": fmt.Sprintf("%d", i)}); err != nil {
			t.Fatalf("SaveNodeMetadata(%s): %v", ids[i], err)
		}
	}

	loaded, err := s.LoadNodeMetadata(ctx, ids)
	if err != nil {
		t.Fatalf("LoadNodeMetadata with %d ids: %v", total, err)
	}
	if len(loaded) != total {
		t.Fatalf("expected metadata for %d nodes, got %d", total, len(loaded))
	}
	// Spot-check the first and last IDs (they land in different chunks).
	if got := loaded[ids[0]]["idx"]; got != "0" {
		t.Errorf("first node metadata idx = %q, want 0", got)
	}
	if got := loaded[ids[total-1]]["idx"]; got != fmt.Sprintf("%d", total-1) {
		t.Errorf("last node metadata idx = %q, want %d", got, total-1)
	}

	// FillNodeMetadata drives the same query path.
	nodes := make([]*Node, total)
	for i, id := range ids {
		nodes[i] = &Node{ID: id}
	}
	if err := s.FillNodeMetadata(ctx, nodes); err != nil {
		t.Fatalf("FillNodeMetadata with %d nodes: %v", total, err)
	}
	if nodes[0].Metadata["idx"] != "0" || nodes[total-1].Metadata["idx"] != fmt.Sprintf("%d", total-1) {
		t.Errorf("FillNodeMetadata chunk merge mismatch: first=%v last=%v", nodes[0].Metadata, nodes[total-1].Metadata)
	}
}
