package engine

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

func TestBranch(t *testing.T) {
	t.Parallel()
	store, err := storage.NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	g := graph.New(store, store.DB())
	eng := New(store, g)
	defer eng.Close()
	ctx := context.Background()

	// Create a parent node via Remember
	parent, err := eng.Remember(ctx, RememberInput{
		Type:    "decision",
		Content: "We chose PostgreSQL for the database layer",
		Scope:   "project",
		Project: "myproject",
	})
	if err != nil {
		t.Fatalf("Remember parent: %v", err)
	}

	// Branch off a new node
	branch, err := eng.Branch(ctx, parent.ID, "Actually, switching to SQLite for dev", "decision")
	if err != nil {
		t.Fatalf("Branch: %v", err)
	}

	// Verify the branch node exists and inherits project/scope
	if branch.Project != parent.Project {
		t.Errorf("project mismatch: got %q, want %q", branch.Project, parent.Project)
	}
	if branch.Scope != parent.Scope {
		t.Errorf("scope mismatch: got %q, want %q", branch.Scope, parent.Scope)
	}
	if branch.Content != "Actually, switching to SQLite for dev" {
		t.Errorf("content mismatch: got %q", branch.Content)
	}
	if branch.Type != "decision" {
		t.Errorf("type mismatch: got %q, want %q", branch.Type, "decision")
	}

	// Verify edge from branch → parent exists
	edges, err := store.GetEdgesFrom(ctx, branch.ID)
	if err != nil {
		t.Fatalf("GetEdgesFrom: %v", err)
	}
	found := false
	for _, e := range edges {
		if e.ToID == parent.ID && e.Type == "caused_by" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected edge from branch to parent not found")
	}
}

func TestBranch_EmptyContent(t *testing.T) {
	t.Parallel()
	store, err := storage.NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	g := graph.New(store, store.DB())
	eng := New(store, g)
	defer eng.Close()
	ctx := context.Background()

	parent, err := eng.Remember(ctx, RememberInput{
		Type:    "convention",
		Content: "Use gofmt",
		Scope:   "project",
		Project: "proj",
	})
	if err != nil {
		t.Fatal(err)
	}

	_, err = eng.Branch(ctx, parent.ID, "", "convention")
	if err == nil {
		t.Fatal("expected error for empty content")
	}
}

func TestBranch_ParentNotFound(t *testing.T) {
	t.Parallel()
	store, err := storage.NewStore(filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer store.Close()

	g := graph.New(store, store.DB())
	eng := New(store, g)
	defer eng.Close()
	ctx := context.Background()

	_, err = eng.Branch(ctx, "nonexistent-id", "some content", "decision")
	if err == nil {
		t.Fatal("expected error for nonexistent parent")
	}
}
