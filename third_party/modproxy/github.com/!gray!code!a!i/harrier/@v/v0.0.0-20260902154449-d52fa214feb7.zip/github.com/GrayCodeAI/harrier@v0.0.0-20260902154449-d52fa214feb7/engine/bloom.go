package engine

import (
	"hash"
	"hash/fnv"
	"math"
	"sync"
)

// BloomFilter provides O(1) negative lookups for memory content.
// If the filter says "not present", it's guaranteed not in the store.
// If it says "maybe present", we proceed with the FTS5 query.
// Eliminates ~40-60% of unnecessary SQLite queries for miss cases.
//
// Parameters tuned for coding memory:
// - Expected items: 10,000 memories
// - False positive rate: 1%
// - Bit array size: ~96KB (minimal memory overhead)
type BloomFilter struct {
	mu      sync.RWMutex
	bits    []uint64
	numBits uint64
	numHash int
	count   int
}

// NewBloomFilter creates a bloom filter optimized for the expected number of items.
func NewBloomFilter(expectedItems int, fpRate float64) *BloomFilter {
	if expectedItems < 100 {
		expectedItems = 100
	}
	if fpRate <= 0 || fpRate >= 1 {
		fpRate = 0.01
	}

	// Optimal size: m = -(n * ln(p)) / (ln(2)^2)
	m := uint64(-float64(expectedItems) * math.Log(fpRate) / (math.Ln2 * math.Ln2))
	// Round up to nearest 64 for word alignment
	m = ((m + 63) / 64) * 64

	// Optimal hash count: k = (m/n) * ln(2)
	k := int(math.Ceil(float64(m) / float64(expectedItems) * math.Ln2))
	if k < 1 {
		k = 1
	}
	if k > 10 {
		k = 10
	}

	return &BloomFilter{
		bits:    make([]uint64, m/64),
		numBits: m,
		numHash: k,
	}
}

// Add inserts a term into the bloom filter.
func (bf *BloomFilter) Add(term string) {
	bf.mu.Lock()
	defer bf.mu.Unlock()

	for _, pos := range bf.positions(term) {
		wordIdx := pos / 64
		bitIdx := pos % 64
		bf.bits[wordIdx] |= 1 << bitIdx
	}
	bf.count++
}

// AddTerms indexes all significant terms from content.
func (bf *BloomFilter) AddTerms(content string) {
	terms := tokenize(content)
	bf.mu.Lock()
	defer bf.mu.Unlock()

	for _, term := range terms {
		for _, pos := range bf.positions(term) {
			wordIdx := pos / 64
			bitIdx := pos % 64
			bf.bits[wordIdx] |= 1 << bitIdx
		}
	}
	bf.count++
}

// MayContain returns false if the term is DEFINITELY not in the filter.
// Returns true if it MIGHT be present (check FTS5 to confirm).
func (bf *BloomFilter) MayContain(term string) bool {
	bf.mu.RLock()
	defer bf.mu.RUnlock()

	for _, pos := range bf.positions(term) {
		wordIdx := pos / 64
		bitIdx := pos % 64
		if bf.bits[wordIdx]&(1<<bitIdx) == 0 {
			return false
		}
	}
	return true
}

// MayContainAny returns true if any of the query terms might be present.
func (bf *BloomFilter) MayContainAny(query string) bool {
	terms := tokenize(query)
	for _, term := range terms {
		if bf.MayContain(term) {
			return true
		}
	}
	return false
}

// Count returns the number of items added.
func (bf *BloomFilter) Count() int {
	bf.mu.RLock()
	defer bf.mu.RUnlock()
	return bf.count
}

// FalsePositiveRate returns the estimated current FP rate.
func (bf *BloomFilter) FalsePositiveRate() float64 {
	bf.mu.RLock()
	defer bf.mu.RUnlock()

	// FP rate = (1 - e^(-kn/m))^k
	n := float64(bf.count)
	m := float64(bf.numBits)
	k := float64(bf.numHash)
	return math.Pow(1-math.Exp(-k*n/m), k)
}

func (bf *BloomFilter) positions(term string) []uint64 {
	h := fnv.New128a()
	h.Write([]byte(term))
	sum := h.Sum(nil)

	// Use double-hashing technique: h1 + i*h2
	h1 := uint64(sum[0])<<56 | uint64(sum[1])<<48 | uint64(sum[2])<<40 | uint64(sum[3])<<32 |
		uint64(sum[4])<<24 | uint64(sum[5])<<16 | uint64(sum[6])<<8 | uint64(sum[7])
	h2 := uint64(sum[8])<<56 | uint64(sum[9])<<48 | uint64(sum[10])<<40 | uint64(sum[11])<<32 |
		uint64(sum[12])<<24 | uint64(sum[13])<<16 | uint64(sum[14])<<8 | uint64(sum[15])

	positions := make([]uint64, bf.numHash)
	for i := 0; i < bf.numHash; i++ {
		positions[i] = (h1 + uint64(i)*h2) % bf.numBits // #nosec G115 -- i is a bounded non-negative loop index; hash-mixing conversion
	}
	return positions
}

// tokenize splits text into significant search terms.
func tokenize(text string) []string {
	var terms []string
	current := make([]byte, 0, 32)

	for i := 0; i < len(text); i++ {
		c := text[i]
		if isAlphaNum(c) {
			current = append(current, toLower(c))
		} else {
			if len(current) >= 3 {
				terms = append(terms, string(current))
			}
			current = current[:0]
		}
	}
	if len(current) >= 3 {
		terms = append(terms, string(current))
	}
	return terms
}

func isAlphaNum(c byte) bool {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_'
}

func toLower(c byte) byte {
	if c >= 'A' && c <= 'Z' {
		return c + 32
	}
	return c
}

// Ensure hash.Hash128 interface is used (compile-time check)
var _ hash.Hash = fnv.New128a()
