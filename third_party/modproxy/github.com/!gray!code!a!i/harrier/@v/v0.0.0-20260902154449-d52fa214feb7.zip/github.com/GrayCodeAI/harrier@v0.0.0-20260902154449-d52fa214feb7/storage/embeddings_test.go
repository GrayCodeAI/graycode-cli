package storage

import (
	"context"
	"database/sql"
	"errors"
	"testing"
)

func seedEmbeddingNode(t *testing.T, s *Store, id string) {
	t.Helper()
	if err := s.CreateNode(context.Background(), &Node{
		ID: id, Type: "convention", Content: id, ContentHash: "h" + id, Scope: "project",
	}); err != nil {
		t.Fatalf("CreateNode(%s): %v", id, err)
	}
}

func vecEqual(a, b []float32) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func TestSaveGetEmbeddingRoundTrip(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedEmbeddingNode(t, s, "n1")
	want := []float32{1.5, -2.25, 0, 3.0e10}
	if err := s.SaveEmbedding(ctx, "n1", "model-x", want); err != nil {
		t.Fatalf("SaveEmbedding: %v", err)
	}

	got, model, err := s.GetEmbedding(ctx, "n1")
	if err != nil {
		t.Fatalf("GetEmbedding: %v", err)
	}
	if model != "model-x" {
		t.Errorf("model = %q, want model-x", model)
	}
	if !vecEqual(got, want) {
		t.Errorf("vector = %v, want %v", got, want)
	}
}

func TestSaveEmbeddingUpsert(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedEmbeddingNode(t, s, "n1")
	if err := s.SaveEmbedding(ctx, "n1", "m1", []float32{1, 2, 3}); err != nil {
		t.Fatalf("first SaveEmbedding: %v", err)
	}
	// Saving again for the same node should overwrite (ON CONFLICT DO UPDATE).
	if err := s.SaveEmbedding(ctx, "n1", "m2", []float32{9, 8}); err != nil {
		t.Fatalf("second SaveEmbedding: %v", err)
	}

	got, model, err := s.GetEmbedding(ctx, "n1")
	if err != nil {
		t.Fatalf("GetEmbedding: %v", err)
	}
	if model != "m2" {
		t.Errorf("model = %q, want m2", model)
	}
	if !vecEqual(got, []float32{9, 8}) {
		t.Errorf("vector = %v, want [9 8]", got)
	}

	all, err := s.AllEmbeddings(ctx, "")
	if err != nil {
		t.Fatalf("AllEmbeddings: %v", err)
	}
	if len(all) != 1 {
		t.Errorf("expected 1 embedding after upsert, got %d", len(all))
	}
}

func TestGetEmbeddingNotFound(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	_, _, err := s.GetEmbedding(ctx, "missing")
	if !errors.Is(err, sql.ErrNoRows) {
		t.Errorf("expected sql.ErrNoRows for missing embedding, got %v", err)
	}
}

func TestDeleteEmbedding(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	seedEmbeddingNode(t, s, "n1")
	if err := s.SaveEmbedding(ctx, "n1", "m", []float32{1, 2}); err != nil {
		t.Fatalf("SaveEmbedding: %v", err)
	}
	if err := s.DeleteEmbedding(ctx, "n1"); err != nil {
		t.Fatalf("DeleteEmbedding: %v", err)
	}
	if _, _, err := s.GetEmbedding(ctx, "n1"); !errors.Is(err, sql.ErrNoRows) {
		t.Errorf("expected sql.ErrNoRows after delete, got %v", err)
	}
	// Deleting a non-existent embedding is a no-op (no error).
	if err := s.DeleteEmbedding(ctx, "n1"); err != nil {
		t.Errorf("DeleteEmbedding on missing: %v", err)
	}
}

func TestAllEmbeddings(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	all, err := s.AllEmbeddings(ctx, "")
	if err != nil {
		t.Fatalf("AllEmbeddings empty: %v", err)
	}
	if len(all) != 0 {
		t.Errorf("expected 0 embeddings initially, got %d", len(all))
	}

	for _, id := range []string{"a", "b", "c"} {
		seedEmbeddingNode(t, s, id)
		if err := s.SaveEmbedding(ctx, id, "m", []float32{float32(len(id))}); err != nil {
			t.Fatalf("SaveEmbedding(%s): %v", id, err)
		}
	}
	all, err = s.AllEmbeddings(ctx, "")
	if err != nil {
		t.Fatalf("AllEmbeddings: %v", err)
	}
	if len(all) != 3 {
		t.Fatalf("expected 3 embeddings, got %d", len(all))
	}
	if !vecEqual(all["a"], []float32{1}) {
		t.Errorf("embedding a = %v, want [1]", all["a"])
	}
}

func TestGetEmbeddingsBatch(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b", "c", "d", "e"} {
		seedEmbeddingNode(t, s, id)
		if err := s.SaveEmbedding(ctx, id, "m", []float32{1}); err != nil {
			t.Fatalf("SaveEmbedding(%s): %v", id, err)
		}
	}

	// First page of 2.
	page1, err := s.GetEmbeddingsBatch(ctx, "", 0, 2)
	if err != nil {
		t.Fatalf("GetEmbeddingsBatch page1: %v", err)
	}
	if len(page1) != 2 {
		t.Errorf("page1 size = %d, want 2", len(page1))
	}

	// Walk all pages and confirm full coverage with no duplicates.
	seen := map[string]bool{}
	for offset := 0; ; offset += 2 {
		page, err := s.GetEmbeddingsBatch(ctx, "", offset, 2)
		if err != nil {
			t.Fatalf("GetEmbeddingsBatch offset=%d: %v", offset, err)
		}
		if len(page) == 0 {
			break
		}
		for id := range page {
			if seen[id] {
				t.Errorf("duplicate id %q across pages", id)
			}
			seen[id] = true
		}
	}
	if len(seen) != 5 {
		t.Errorf("expected 5 distinct embeddings across pages, got %d", len(seen))
	}

	// Offset past the end yields an empty (non-nil) result.
	empty, err := s.GetEmbeddingsBatch(ctx, "", 100, 10)
	if err != nil {
		t.Fatalf("GetEmbeddingsBatch past end: %v", err)
	}
	if len(empty) != 0 {
		t.Errorf("expected empty page past end, got %d", len(empty))
	}
}

// TestEmbeddingsModelFilter pins fix B: read paths must segregate vectors by
// model so a cosine/ANN scan never mixes incompatible embedding spaces.
func TestEmbeddingsModelFilter(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Two nodes embedded by modelA, one by modelB.
	seed := []struct {
		id, model string
	}{
		{"a1", "modelA"},
		{"a2", "modelA"},
		{"b1", "modelB"},
	}
	for _, e := range seed {
		seedEmbeddingNode(t, s, e.id)
		if err := s.SaveEmbedding(ctx, e.id, e.model, []float32{1}); err != nil {
			t.Fatalf("SaveEmbedding(%s): %v", e.id, err)
		}
	}

	// AllEmbeddings filtered to modelA returns only modelA's two vectors.
	a, err := s.AllEmbeddings(ctx, "modelA")
	if err != nil {
		t.Fatalf("AllEmbeddings(modelA): %v", err)
	}
	if len(a) != 2 || a["b1"] != nil {
		t.Errorf("model filter leaked across models: got %v", a)
	}

	// Empty filter still returns everything (maintenance/migration path).
	all, err := s.AllEmbeddings(ctx, "")
	if err != nil {
		t.Fatalf("AllEmbeddings(all): %v", err)
	}
	if len(all) != 3 {
		t.Errorf("empty filter should return all 3, got %d", len(all))
	}

	// GetEmbeddingsBatch honors the filter too.
	batch, err := s.GetEmbeddingsBatch(ctx, "modelB", 0, 100)
	if err != nil {
		t.Fatalf("GetEmbeddingsBatch(modelB): %v", err)
	}
	if len(batch) != 1 || batch["b1"] == nil {
		t.Errorf("batch model filter wrong: got %v", batch)
	}
}
