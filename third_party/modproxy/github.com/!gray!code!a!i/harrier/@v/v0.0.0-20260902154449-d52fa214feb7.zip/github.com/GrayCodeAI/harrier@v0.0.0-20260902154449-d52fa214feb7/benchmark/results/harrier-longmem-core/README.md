# `harrier-longmem-core` Published Runs

Current published runs:

- `2026-06-27/`

Each published run includes:

- `report.md`
- `result.txt` or `result.json`
- `notes.md`

Reference manifest: `../../manifests/harrier-longmem-core.yaml`
