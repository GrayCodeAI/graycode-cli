//nolint:gocritic
package engine

import (
	"context"
	"sync"
	"testing"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// Note: the mockStorage and mockGraph test doubles were moved verbatim into
// engine_mock_storage_test.go and engine_mock_graph_test.go for
// readability. This file keeps the engine behavior tests.

func TestMockStorageCompiles(t *testing.T) {
	t.Parallel()
	var _ storage.Storage = newMockStorage()
}

// TestMockGraphCompiles verifies mockGraph implements graph.Graph.
func TestMockGraphCompiles(t *testing.T) {
	t.Parallel()
	var _ graph.Graph = newMockGraph(newMockStorage())
}

// TestEngineWithMocks verifies engine.New accepts mock implementations.
func TestEngineWithMocks(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	if eng == nil {
		t.Fatal("expected non-nil engine")
	}
	if eng.Store() == nil {
		t.Error("expected non-nil store")
	}
	if eng.Graph() == nil {
		t.Error("expected non-nil graph")
	}
}

// TestRememberAndRecall creates a node and recalls it.
func TestRememberAndRecall(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{
		Type:    "convention",
		Content: "Always use context.Context as first parameter",
		Scope:   "project",
		Project: "testproj",
	})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}
	if node.ID == "" {
		t.Error("expected node ID")
	}
	if node.Content != "Always use context.Context as first parameter" {
		t.Errorf("unexpected content: %s", node.Content)
	}

	res, err := eng.Recall(context.Background(), RecallOpts{Query: "context.Context", Project: "testproj"})
	if err != nil {
		t.Fatalf("Recall failed: %v", err)
	}
	if len(res.Nodes) == 0 {
		t.Error("expected at least one recalled node")
	}
	found := false
	for _, n := range res.Nodes {
		if n.ID == node.ID {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected recalled node to contain the remembered node")
	}
}

// TestRecallFilters verifies type/tier/project filtering.
func TestRecallFilters(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "conv1", Project: "p1"})
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "bug", Content: "bug1", Project: "p1"})
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "conv2", Project: "p2"})

	res, err := eng.Recall(context.Background(), RecallOpts{Query: "conv", Type: "convention", Project: "p1"})
	if err != nil {
		t.Fatalf("Recall failed: %v", err)
	}
	// Seeds are filtered; graph expansion may include connected nodes of other types.
	// Just verify recall succeeds and at least one seed node is in the result.
	if len(res.Nodes) == 0 {
		t.Error("expected at least one node in recall result")
	}
}

// TestContext verifies hot-tier + active tasks retrieval.
func TestContext(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	// hot tier node
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "hot memory", Project: "p1", Tier: 1})
	// active task
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "task", Content: "active task", Project: "p1"})
	// irrelevant (different project)
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "other project", Project: "p2", Tier: 1})

	ctx, err := eng.Context(context.Background(), "p1")
	if err != nil {
		t.Fatalf("Context failed: %v", err)
	}
	if len(ctx.Nodes) == 0 {
		t.Fatal("expected context nodes")
	}
	for _, n := range ctx.Nodes {
		if n.Project != "p1" {
			t.Errorf("expected only p1 nodes in context, got %s", n.Project)
		}
	}
}

// TestForget archives a node.
func TestForget(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{Type: "decision", Content: "drop feature X", Project: "p1"})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	if err := eng.Forget(context.Background(), node.ID); err != nil {
		t.Fatalf("Forget failed: %v", err)
	}

	got, err := eng.store.GetNode(context.Background(), node.ID)
	if err != nil {
		t.Fatalf("GetNode failed: %v", err)
	}
	if got.Confidence != 0 {
		t.Errorf("expected confidence 0 after forget, got %f", got.Confidence)
	}
}

// TestStatus verifies node/edge/session counting.
func TestStatus(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "c1", Project: "p1"})
	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "c2", Project: "p1"})
	_, _ = eng.StartSession(context.Background(), "p1", "agent-a")

	st, err := eng.Status(context.Background(), "p1")
	if err != nil {
		t.Fatalf("Status failed: %v", err)
	}
	if st.Nodes < 2 {
		t.Errorf("expected at least 2 nodes, got %d", st.Nodes)
	}
	if st.Sessions < 1 {
		t.Errorf("expected at least 1 session, got %d", st.Sessions)
	}
}

// TestFeedback verifies approve/edit/discard actions.
func TestFeedback(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{Type: "bug", Content: "old bug desc", Project: "p1"})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// Approve
	if err := eng.Feedback(context.Background(), node.ID, FeedbackApprove, ""); err != nil {
		t.Fatalf("Feedback approve failed: %v", err)
	}
	got, _ := eng.store.GetNode(context.Background(), node.ID)
	if got.Confidence != 1.0 {
		t.Errorf("expected confidence 1.0 after approve, got %f", got.Confidence)
	}

	// Edit
	if err := eng.Feedback(context.Background(), node.ID, FeedbackEdit, "new bug desc"); err != nil {
		t.Fatalf("Feedback edit failed: %v", err)
	}
	got, _ = eng.store.GetNode(context.Background(), node.ID)
	if got.Content != "new bug desc" {
		t.Errorf("expected content 'new bug desc', got %s", got.Content)
	}

	// Discard
	if err := eng.Feedback(context.Background(), node.ID, FeedbackDiscard, ""); err != nil {
		t.Fatalf("Feedback discard failed: %v", err)
	}
	got, _ = eng.store.GetNode(context.Background(), node.ID)
	if got.Confidence != 0 {
		t.Errorf("expected confidence 0 after discard, got %f", got.Confidence)
	}
}

// TestRollback restores a node to a previous version.
func TestRollback(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, err := eng.Remember(context.Background(), RememberInput{Type: "decision", Content: "v1 content", Project: "p1"})
	if err != nil {
		t.Fatalf("Remember failed: %v", err)
	}

	// Save a version manually
	_ = eng.store.SaveVersion(context.Background(), node.ID, "v1 content", "user", "saved")
	// Edit to create v2
	_ = eng.Feedback(context.Background(), node.ID, FeedbackEdit, "v2 content")

	// Rollback to v1
	if err := eng.Rollback(context.Background(), node.ID, 1); err != nil {
		t.Fatalf("Rollback failed: %v", err)
	}

	got, _ := eng.store.GetNode(context.Background(), node.ID)
	if got.Content != "v1 content" {
		t.Errorf("expected content 'v1 content' after rollback, got %s", got.Content)
	}
}

// TestPendingNodes returns low-confidence nodes.
func TestPendingNodes(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	node, _ := eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "low confidence", Project: "p1"})
	_ = eng.Feedback(context.Background(), node.ID, FeedbackDiscard, "")
	// re-create with low confidence manually
	node.Confidence = 0.3
	_ = eng.store.UpdateNode(context.Background(), node)

	pending, err := eng.PendingNodes(context.Background(), "p1", 0.5)
	if err != nil {
		t.Fatalf("PendingNodes failed: %v", err)
	}
	found := false
	for _, n := range pending {
		if n.ID == node.ID {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected pending node to be found")
	}
}

// TestEmptyDatabase verifies operations on empty store return empty results, not errors.
func TestEmptyDatabase(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	res, err := eng.Recall(context.Background(), RecallOpts{Query: "anything", Project: "empty"})
	if err != nil {
		t.Fatalf("Recall on empty DB failed: %v", err)
	}
	if len(res.Nodes) != 0 {
		t.Errorf("expected 0 nodes, got %d", len(res.Nodes))
	}

	ctx, err := eng.Context(context.Background(), "empty")
	if err != nil {
		t.Fatalf("Context on empty DB failed: %v", err)
	}
	if len(ctx.Nodes) != 0 {
		t.Errorf("expected 0 context nodes, got %d", len(ctx.Nodes))
	}

	st, err := eng.Status(context.Background(), "empty")
	if err != nil {
		t.Fatalf("Status on empty DB failed: %v", err)
	}
	if st.Nodes != 0 {
		t.Errorf("expected 0 nodes in status, got %d", st.Nodes)
	}
}

// TestNonexistentNode verifies Forget, GetNode, Link with bad IDs return errors.
func TestNonexistentNode(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	if err := eng.Forget(context.Background(), "nonexistent-id"); err == nil {
		t.Error("expected error forgetting nonexistent node")
	}

	_, err := eng.store.GetNode(context.Background(), "nonexistent-id")
	if err == nil {
		t.Error("expected error getting nonexistent node")
	}
}

// TestConcurrentRemember verifies multiple goroutines calling Remember is safe.
func TestConcurrentRemember(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			_, err := eng.Remember(context.Background(), RememberInput{
				Type:    "convention",
				Content: "concurrent memory " + string(rune('a'+idx)),
				Project: "concurrent-proj",
			})
			if err != nil {
				t.Errorf("Remember goroutine %d failed: %v", idx, err)
			}
		}(i)
	}
	wg.Wait()

	st, err := eng.Status(context.Background(), "concurrent-proj")
	if err != nil {
		t.Fatalf("Status failed: %v", err)
	}
	if st.Nodes < 20 {
		t.Errorf("expected at least 20 nodes, got %d", st.Nodes)
	}
}

// TestConcurrentReadWrite verifies Recall and Remember concurrently.
func TestConcurrentReadWrite(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	// Seed some data
	for i := 0; i < 10; i++ {
		_, _ = eng.Remember(context.Background(), RememberInput{
			Type:    "convention",
			Content: "seed memory " + string(rune('a'+i)),
			Project: "rw-proj",
		})
	}

	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(2)
		idx := i
		go func() {
			defer wg.Done()
			_, _ = eng.Remember(context.Background(), RememberInput{
				Type:    "convention",
				Content: "writer memory " + string(rune('a'+idx)),
				Project: "rw-proj",
			})
		}()
		go func() {
			defer wg.Done()
			_, _ = eng.Recall(context.Background(), RecallOpts{Query: "memory", Project: "rw-proj"})
		}()
	}
	wg.Wait()
}

// TestRememberEmptyContent verifies Remember with empty content is handled.
func TestRememberEmptyContent(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	cases := []struct {
		name    string
		content string
		wantErr bool
	}{
		{"empty content", "", true}, // empty content is rejected
		{"normal content", "valid content", false},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			node, err := eng.Remember(context.Background(), RememberInput{
				Type:    "convention",
				Content: tc.content,
				Project: "empty-test",
			})
			if tc.wantErr {
				if err == nil {
					t.Error("expected error")
				}
				return
			}
			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if node.ID == "" {
				t.Error("expected node ID")
			}
		})
	}
}

// TestSessionFlow verifies StartSession and CompressSession.
func TestSessionFlow(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	sessID, err := eng.StartSession(context.Background(), "p1", "agent-a")
	if err != nil {
		t.Fatalf("StartSession failed: %v", err)
	}
	if sessID == "" {
		t.Error("expected session ID")
	}

	_, _ = eng.Remember(context.Background(), RememberInput{Type: "convention", Content: "sess mem", Project: "p1", Session: sessID})

	summary, err := eng.CompressSession(context.Background(), sessID, "p1")
	if err != nil {
		t.Fatalf("CompressSession failed: %v", err)
	}
	if summary == nil {
		t.Fatal("expected session summary node")
	}
	if summary.Type != "session" {
		t.Errorf("expected type session, got %s", summary.Type)
	}
}
