package engine

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func seedNode(t *testing.T, eng *Engine, id, content string, confidence float64) {
	t.Helper()
	n := &storage.Node{
		ID:         id,
		Content:    content,
		Confidence: confidence,
		Type:       "fact",
		Scope:      "global",
		Project:    "test",
		Tier:       1,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}
	if err := eng.store.CreateNode(context.Background(), n); err != nil {
		t.Fatalf("seed node %s: %v", id, err)
	}
}

// --- Feedback ---

func TestFeedbackApprove(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "hello world", 0.3)

	err := eng.Feedback(context.Background(), "n1", FeedbackApprove, "")
	if err != nil {
		t.Fatalf("approve: %v", err)
	}
	n, _ := eng.store.GetNode(context.Background(), "n1")
	if n.Confidence != 1.0 {
		t.Errorf("approve: want confidence=1.0, got %f", n.Confidence)
	}
}

func TestFeedbackEdit(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "old content", 0.5)

	err := eng.Feedback(context.Background(), "n1", FeedbackEdit, "new content")
	if err != nil {
		t.Fatalf("edit: %v", err)
	}
	n, _ := eng.store.GetNode(context.Background(), "n1")
	if n.Content != "new content" {
		t.Errorf("edit: want content='new content', got %q", n.Content)
	}
	if n.Version != 1 {
		t.Errorf("edit: want version=1, got %d", n.Version)
	}
	if n.Confidence != 1.0 {
		t.Errorf("edit: want confidence=1.0, got %f", n.Confidence)
	}
}

func TestFeedbackEditEmptyContent(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "hello", 0.5)

	err := eng.Feedback(context.Background(), "n1", FeedbackEdit, "")
	if err == nil {
		t.Fatal("edit empty: want error, got nil")
	}
}

func TestFeedbackDiscard(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "to discard", 0.5)

	err := eng.Feedback(context.Background(), "n1", FeedbackDiscard, "")
	if err != nil {
		t.Fatalf("discard: %v", err)
	}
	n, _ := eng.store.GetNode(context.Background(), "n1")
	if n.Confidence != 0 {
		t.Errorf("discard: want confidence=0, got %f", n.Confidence)
	}
}

func TestFeedbackUnknownAction(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "hello", 0.5)

	err := eng.Feedback(context.Background(), "n1", FeedbackAction("bogus"), "")
	if err == nil {
		t.Fatal("unknown action: want error, got nil")
	}
}

func TestFeedbackContextCancelled(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	err := eng.Feedback(ctx, "n1", FeedbackApprove, "")
	if err == nil {
		t.Fatal("cancelled ctx: want error, got nil")
	}
}

func TestFeedbackNodeNotFound(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	err := eng.Feedback(context.Background(), "nonexistent", FeedbackApprove, "")
	if err == nil {
		t.Fatal("missing node: want error, got nil")
	}
}

// --- Rollback ---

func TestRollbackValidVersion(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "current content", 0.8)

	_ = eng.store.SaveVersion(context.Background(), "n1", "original content", "user", "initial save")

	err := eng.Rollback(context.Background(), "n1", 1)
	if err != nil {
		t.Fatalf("rollback: %v", err)
	}
	n, _ := eng.store.GetNode(context.Background(), "n1")
	if n.Content != "original content" {
		t.Errorf("rollback: want content='original content', got %q", n.Content)
	}
	if n.Version != 1 {
		t.Errorf("rollback: want version=1, got %d", n.Version)
	}
}

func TestRollbackVersionNotFound(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "n1", "current content", 0.8)

	err := eng.Rollback(context.Background(), "n1", 99)
	if err == nil {
		t.Fatal("missing version: want error, got nil")
	}
}

func TestRollbackContextCancelled(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	err := eng.Rollback(ctx, "n1", 1)
	if err == nil {
		t.Fatal("cancelled ctx: want error, got nil")
	}
}

// --- PendingNodes ---

func TestPendingNodesFilters(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	seedNode(t, eng, "high", "high confidence", 0.9)
	seedNode(t, eng, "low", "low confidence", 0.2)
	seedNode(t, eng, "mid", "mid confidence", 0.5)
	seedNode(t, eng, "zero", "zero confidence", 0)

	pending, err := eng.PendingNodes(context.Background(), "test", 0.6)
	if err != nil {
		t.Fatalf("pending: %v", err)
	}
	if len(pending) != 2 {
		t.Errorf("pending: want 2 nodes, got %d", len(pending))
	}
}

func TestPendingNodesEmptyProject(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()

	pending, err := eng.PendingNodes(context.Background(), "empty", 0.5)
	if err != nil {
		t.Fatalf("pending empty: %v", err)
	}
	if len(pending) != 0 {
		t.Errorf("pending empty: want 0, got %d", len(pending))
	}
}

func TestPendingNodesCap(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	for i := 0; i < 1001; i++ {
		n := &storage.Node{
			ID:         fmt.Sprintf("n%d", i),
			Content:    fmt.Sprintf("node %d", i),
			Confidence: 0.1,
			Type:       "fact",
			Scope:      "global",
			Project:    "test",
			Tier:       1,
			CreatedAt:  time.Now(),
			UpdatedAt:  time.Now(),
		}
		_ = eng.store.CreateNode(context.Background(), n)
	}

	pending, err := eng.PendingNodes(context.Background(), "test", 0.5)
	if err != nil {
		t.Fatalf("pending cap: %v", err)
	}
	if len(pending) != 1000 {
		t.Errorf("pending cap: want 1000, got %d", len(pending))
	}
}

func TestPendingNodesContextCancelled(t *testing.T) {
	t.Parallel()
	eng := newTestEngine()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	_, err := eng.PendingNodes(ctx, "test", 0.5)
	if err == nil {
		t.Fatal("cancelled ctx: want error, got nil")
	}
}
