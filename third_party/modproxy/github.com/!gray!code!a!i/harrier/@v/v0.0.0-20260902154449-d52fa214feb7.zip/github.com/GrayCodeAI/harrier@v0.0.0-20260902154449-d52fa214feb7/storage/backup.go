package storage

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

// Backup creates a consistent snapshot of the database at backupPath using
// SQLite's VACUUM INTO, which reads the live database without blocking
// writers for more than a moment and produces a compact, standalone file.
// The backup is written atomically (temp file + rename) and its permissions
// are restricted to owner-only, matching the main database file.
func (s *Store) Backup(ctx context.Context, backupPath string) error {
	if backupPath == "" {
		return fmt.Errorf("backup path must not be empty")
	}

	dir := filepath.Dir(backupPath)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return fmt.Errorf("create backup directory: %w", err)
	}

	tq, cancel := s.withTimeout(ctx)
	defer cancel()

	// VACUUM INTO cannot target an existing file, so write to a temp file
	// in the same directory and rename it into place.
	tmp := backupPath + fmt.Sprintf(".%d.tmp", time.Now().UnixNano())
	if _, err := s.q().ExecContext(tq, `VACUUM INTO ?`, tmp); err != nil {
		_ = os.Remove(tmp) // best-effort cleanup of any partial file
		return fmt.Errorf("backup database: %w", err)
	}
	if err := os.Chmod(tmp, 0o600); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("restrict backup file permissions: %w", err)
	}
	// fsync the snapshot before the rename: once renamed, the file reads as
	// a complete backup, so its contents must already be on durable storage.
	if err := syncFile(tmp); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("sync backup file: %w", err)
	}
	if err := os.Rename(tmp, backupPath); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("finalize backup: %w", err)
	}
	// Best-effort fsync of the directory so the rename itself survives a
	// crash. Directory Sync is a no-op / unsupported on some platforms
	// (Windows rejects fsync on directory handles), hence the ignore.
	_ = syncDir(dir)
	return nil
}

// syncFile flushes a file's contents to durable storage.
func syncFile(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func() { _ = f.Close() }()
	return f.Sync()
}

// syncDir fsyncs a directory entry so a rename inside it is durable. Errors
// are ignored by callers: several platforms cannot sync directory handles.
func syncDir(path string) error {
	d, err := os.Open(path)
	if err != nil {
		return err
	}
	defer func() { _ = d.Close() }()
	return d.Sync()
}
