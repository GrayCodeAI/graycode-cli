package exportimport

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// LangGraphEntry represents a single entry in the LangGraph-compatible JSON format.
type LangGraphEntry struct {
	ID       string                 `json:"id"`
	ParentID string                 `json:"parent_id,omitempty"`
	Role     string                 `json:"role"`
	Content  string                 `json:"content"`
	Metadata map[string]interface{} `json:"metadata,omitempty"`
}

// ImportLangGraph imports LangGraph-format JSON into harrier storage.
// Each entry is mapped to a harrier Node with Type="entity".
// Returns the count of successfully imported nodes.
func ImportLangGraph(ctx context.Context, store storage.Storage, jsonData []byte) (int, error) {
	var entries []LangGraphEntry
	if err := json.Unmarshal(jsonData, &entries); err != nil {
		return 0, fmt.Errorf("parsing langgraph JSON: %w", err)
	}

	imported := 0
	for _, entry := range entries {
		if entry.ID == "" || entry.Content == "" {
			continue
		}

		hash := fmt.Sprintf("%x", sha256.Sum256([]byte(entry.ID+entry.Content)))
		node := &storage.Node{
			ID:          entry.ID,
			Type:        "entity",
			Content:     entry.Content,
			ContentHash: hash,
			Confidence:  1.0,
			Version:     1,
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
		}

		// Map role to tags
		if entry.Role != "" {
			node.Tags = "role:" + entry.Role
		}

		// Store metadata as summary if present
		if entry.Metadata != nil {
			if metaBytes, err := json.Marshal(entry.Metadata); err == nil {
				node.Summary = string(metaBytes)
			}
		}

		if err := store.CreateNode(ctx, node); err != nil {
			continue // skip duplicates
		}
		imported++

		// Create edge to parent if parent_id is specified
		if entry.ParentID != "" {
			edge := &storage.Edge{
				ID:        fmt.Sprintf("%s->%s", entry.ParentID, entry.ID),
				FromID:    entry.ParentID,
				ToID:      entry.ID,
				Type:      "parent",
				CreatedAt: time.Now(),
			}
			_ = store.CreateEdge(ctx, edge) // best-effort; parent edge creation failure shouldn't abort the import
		}
	}

	return imported, nil
}

// ExportForLangGraph exports harrier nodes for a project as LangGraph-compatible JSON.
func ExportForLangGraph(ctx context.Context, store storage.Storage, project string) ([]byte, error) {
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: project})
	if err != nil {
		return nil, fmt.Errorf("listing nodes: %w", err)
	}

	entries := make([]LangGraphEntry, 0, len(nodes))
	for _, n := range nodes {
		entry := LangGraphEntry{
			ID:      n.ID,
			Role:    extractRole(n.Tags),
			Content: n.Content,
		}

		// Reconstruct metadata from summary
		if n.Summary != "" {
			var meta map[string]interface{}
			if err := json.Unmarshal([]byte(n.Summary), &meta); err == nil {
				entry.Metadata = meta
			}
		}

		// Look up parent edge
		edges, _ := store.GetEdgesTo(ctx, n.ID)
		for _, e := range edges {
			if e.Type == "parent" {
				entry.ParentID = e.FromID
				break
			}
		}

		entries = append(entries, entry)
	}

	return json.MarshalIndent(entries, "", "  ")
}

// extractRole extracts the role from a tags string like "role:assistant".
func extractRole(tags string) string {
	if len(tags) > 5 && tags[:5] == "role:" {
		return tags[5:]
	}
	return ""
}
