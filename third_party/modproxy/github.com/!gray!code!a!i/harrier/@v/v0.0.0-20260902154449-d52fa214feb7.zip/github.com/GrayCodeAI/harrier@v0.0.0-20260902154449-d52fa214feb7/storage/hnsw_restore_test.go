package storage

import (
	"context"
	"fmt"
	"testing"
)

// TestHNSWRestoreAcrossRestart verifies a fresh store on the same database
// restores the persisted HNSW graph instead of recomputing it.
func TestHNSWRestoreAcrossRestart(t *testing.T) {
	dir := t.TempDir()
	dbPath := dir + "/restart.db"
	ctx := context.Background()
	model := "restart-model"

	s1, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 10; i++ {
		id := fmt.Sprintf("r-%d", i)
		if err := s1.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h-" + id, Scope: "project", Project: "test",
		}); err != nil {
			t.Fatal(err)
		}
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = float32(i) * 0.1
		if err := s1.SaveEmbedding(ctx, id, model, vec); err != nil {
			t.Fatal(err)
		}
	}
	if err := s1.BuildHNSWIndex(ctx, model); err != nil {
		t.Fatal(err)
	}
	wantIDs, _, err := s1.SearchHNSW(ctx, model, dirVec(t, 0.5), 3, 50)
	if err != nil {
		t.Fatal(err)
	}
	// Close releases the process lock; the second store simulates a restart.
	if err := s1.Close(); err != nil {
		t.Fatal(err)
	}

	s2, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = s2.Close() }()

	// The index cache is empty in a new process; Restore must load the
	// persisted graph without a fallback build.
	idx := NewHNSWIndex(200, 16, 50)
	restored, err := idx.Restore(ctx, s2, model)
	if err != nil {
		t.Fatalf("Restore: %v", err)
	}
	if !restored {
		t.Fatal("expected persisted graph to be restorable, got false")
	}

	// And the full search path must return identical results after restart.
	gotIDs, _, err := s2.SearchHNSW(ctx, model, dirVec(t, 0.5), 3, 50)
	if err != nil {
		t.Fatal(err)
	}
	if len(gotIDs) != len(wantIDs) {
		t.Fatalf("result count changed across restart: %v vs %v", gotIDs, wantIDs)
	}
	for i := range wantIDs {
		if gotIDs[i] != wantIDs[i] {
			t.Errorf("result %d: got %s want %s", i, gotIDs[i], wantIDs[i])
		}
	}
}

// TestHNSWRestoreFallbackOnStaleGraph verifies that a persisted graph which
// no longer matches the embeddings table is rejected and a rebuild takes
// over (via the SearchHNSW fallback path).
func TestHNSWRestoreFallbackOnStaleGraph(t *testing.T) {
	dir := t.TempDir()
	dbPath := dir + "/stale.db"
	ctx := context.Background()
	model := "stale-model"

	s1, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 10; i++ {
		id := fmt.Sprintf("s-%d", i)
		if err := s1.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h-" + id, Scope: "project", Project: "test",
		}); err != nil {
			t.Fatal(err)
		}
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = float32(i) * 0.1
		if err := s1.SaveEmbedding(ctx, id, model, vec); err != nil {
			t.Fatal(err)
		}
	}
	if err := s1.BuildHNSWIndex(ctx, model); err != nil {
		t.Fatal(err)
	}
	if err := s1.Close(); err != nil {
		t.Fatal(err)
	}

	s2, err := NewStore(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = s2.Close() }()

	// Simulate an out-of-band embedding write that bypassed the index API:
	// a row in embeddings with no corresponding graph row.
	if err := s2.CreateNode(ctx, &Node{
		ID: "s-ghost", Type: "convention", Content: "s-ghost",
		ContentHash: "h-s-ghost", Scope: "project", Project: "test",
	}); err != nil {
		t.Fatal(err)
	}
	if _, err := s2.DB().ExecContext(ctx,
		`INSERT INTO embeddings(node_id, vector, model) VALUES('s-ghost', X'0000803F0000803F0000803F0000803F0000803F0000803F0000803F0000803F', ?)`, model); err != nil {
		t.Fatal(err)
	}

	idx := NewHNSWIndex(200, 16, 50)
	restored, err := idx.Restore(ctx, s2, model)
	if err != nil {
		t.Fatalf("Restore: %v", err)
	}
	if restored {
		t.Fatal("expected stale graph to be rejected, but Restore returned true")
	}

	// SearchHNSW must fall back to a full build and still return results.
	ids, _, err := s2.SearchHNSW(ctx, model, dirVec(t, 0.9), 1, 50)
	if err != nil {
		t.Fatalf("SearchHNSW after stale graph: %v", err)
	}
	if len(ids) == 0 {
		t.Fatal("expected results after rebuild fallback")
	}

	// The fallback build must have re-persisted the graph so the next
	// process can restore it again.
	idx2 := NewHNSWIndex(200, 16, 50)
	restored2, err := idx2.Restore(ctx, s2, model)
	if err != nil {
		t.Fatalf("Restore after rebuild: %v", err)
	}
	if !restored2 {
		t.Fatal("expected rebuilt graph to be restorable")
	}
}

// TestHNSWRestoreRejectsForeignParameters verifies graphs persisted by an
// index with different construction parameters are rejected.
func TestHNSWRestoreRejectsForeignParameters(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	model := "param-model"
	seedHNSW(t, s, model, 6, 0.1) // persists via Build (m=16, ef=200)

	other := NewHNSWIndex(400, 32, 50) // different construction parameters
	restored, err := other.Restore(ctx, s, model)
	if err != nil {
		t.Fatalf("Restore: %v", err)
	}
	if restored {
		t.Fatal("expected parameter-mismatched graph to be rejected")
	}
}
