package engine

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/GrayCodeAI/harrier/storage"
)

// ExportHTML generates a standalone HTML file with an interactive memory graph.
// The file can be shared — no server required, opens in any browser.
func ExportHTML(ctx context.Context, store storage.Storage) (string, error) {
	nodes, err := store.ListNodes(ctx, storage.NodeFilter{Limit: 500, MinConfidence: 0.2})
	if err != nil {
		return "", err
	}

	// Collect edges between these nodes
	nodeIDs := make([]string, len(nodes))
	for i, n := range nodes {
		nodeIDs[i] = n.ID
	}
	edges, _ := store.GetEdgesBetween(ctx, nodeIDs)

	// Build JSON data for D3
	type jsNode struct {
		ID         string  `json:"id"`
		Type       string  `json:"type"`
		Content    string  `json:"content"`
		Confidence float64 `json:"confidence"`
		Pinned     bool    `json:"pinned"`
	}
	type jsEdge struct {
		Source string `json:"source"`
		Target string `json:"target"`
		Type   string `json:"type"`
	}

	jsNodes := make([]jsNode, len(nodes))
	for i, n := range nodes {
		content := n.Content
		if len(content) > 100 {
			content = content[:100] + "..."
		}
		jsNodes[i] = jsNode{ID: n.ID, Type: n.Type, Content: content, Confidence: n.Confidence, Pinned: n.Pinned}
	}

	jsEdges := make([]jsEdge, 0, len(edges))
	nodeSet := make(map[string]bool)
	for _, n := range nodes {
		nodeSet[n.ID] = true
	}
	for _, e := range edges {
		if nodeSet[e.FromID] && nodeSet[e.ToID] {
			jsEdges = append(jsEdges, jsEdge{Source: e.FromID, Target: e.ToID, Type: e.Type})
		}
	}

	nodesJSON, _ := json.Marshal(jsNodes)
	edgesJSON, _ := json.Marshal(jsEdges)

	// Use strings.NewReplacer instead of fmt.Sprintf to avoid corruption
	// when node content contains % characters.
	html := strings.NewReplacer(
		"__NODES_JSON__", string(nodesJSON),
		"__EDGES_JSON__", string(edgesJSON),
		"__NODE_COUNT__", fmt.Sprintf("%d", len(nodes)),
		"__EDGE_COUNT__", fmt.Sprintf("%d", len(jsEdges)),
	).Replace(exportHTMLTemplate)
	return html, nil
}

var exportHTMLTemplate = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Harrier Memory Graph</title>
<script src="https://d3js.org/d3.v7.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui;background:#0f1117;color:#e2e8f0;overflow:hidden}
#info{position:fixed;top:12px;left:12px;font-size:13px;color:#718096;z-index:10}
#tooltip{position:fixed;background:#1a1d27;border:1px solid #4a5568;border-radius:8px;padding:10px;font-size:12px;max-width:300px;display:none;z-index:100;pointer-events:none}
.node{cursor:pointer} .link{stroke-opacity:0.3}
</style></head><body>
<div id="info">Harrier Memory Graph — __NODE_COUNT__ nodes, __EDGE_COUNT__ edges — drag to move, scroll to zoom</div>
<div id="tooltip"></div>
<svg id="g" width="100%" height="100%"></svg>
<script>
const COLORS={convention:'#a78bfa',decision:'#63b3ed',bug:'#fc8181',spec:'#68d391',task:'#f6e05e',file:'#4fd1c5',entity:'#b794f4',preference:'#ed8936',skill:'#f687b3'};
const nodes=__NODES_JSON__;
const edges=__EDGES_JSON__;
const w=window.innerWidth,h=window.innerHeight;
const svg=d3.select('#g').attr('viewBox',[0,0,w,h]);
const g=svg.append('g');
svg.call(d3.zoom().scaleExtent([0.1,5]).on('zoom',e=>g.attr('transform',e.transform)));
const sim=d3.forceSimulation(nodes).force('link',d3.forceLink(edges).id(d=>d.id).distance(60)).force('charge',d3.forceManyBody().strength(-150)).force('center',d3.forceCenter(w/2,h/2));
const links=g.append('g').selectAll('line').data(edges).enter().append('line').attr('class','link').attr('stroke','#4a5568');
const ns=g.append('g').selectAll('g').data(nodes).enter().append('g').attr('class','node').call(d3.drag().on('start',(e,d)=>{if(!e.active)sim.alphaTarget(0.3).restart();d.fx=d.x;d.fy=d.y}).on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y}).on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null}));
ns.append('circle').attr('r',d=>5+d.confidence*5+(d.pinned?3:0)).attr('fill',d=>COLORS[d.type]||'#a0aec0').attr('opacity',d=>0.5+d.confidence*0.5);
ns.append('text').attr('dx',10).attr('dy',4).attr('font-size','9px').attr('fill','#718096').text(d=>d.content.slice(0,25));
const tt=document.getElementById('tooltip');
ns.on('mouseover',(e,d)=>{tt.style.display='block';tt.style.left=(e.clientX+10)+'px';tt.style.top=(e.clientY+10)+'px';tt.innerHTML='<b style="color:'+COLORS[d.type]+'">'+d.type+'</b><br>'+d.content+'<br><small>confidence: '+(d.confidence*100).toFixed(0)+'%%</small>'}).on('mouseout',()=>tt.style.display='none');
sim.on('tick',()=>{links.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);ns.attr('transform',d=>'translate('+d.x+','+d.y+')')});
</script></body></html>`

// Templates provides pre-built memory sets for common tech stacks.
type Templates struct{}

// TemplateSet is a collection of starter memories for a stack.
type TemplateSet struct {
	Name     string
	Stack    string
	Memories []TemplateMemory
}

// TemplateMemory is a pre-built memory.
type TemplateMemory struct {
	Content string
	Type    string
}

// Available returns all available templates.
func (t *Templates) Available() []TemplateSet {
	return []TemplateSet{
		{
			Name: "nextjs", Stack: "Next.js + TypeScript",
			Memories: []TemplateMemory{
				{"Use App Router (not Pages Router)", "convention"},
				{"Server Components by default, 'use client' only when needed", "convention"},
				{"Use next/image for all images (auto-optimization)", "convention"},
				{"Environment variables: NEXT_PUBLIC_ prefix for client-side", "convention"},
				{"API routes in app/api/ directory", "convention"},
			},
		},
		{
			Name: "go-api", Stack: "Go REST API",
			Memories: []TemplateMemory{
				{"Error handling: always wrap with fmt.Errorf and %%w", "convention"},
				{"Use context.Context as first parameter in all functions", "convention"},
				{"Table-driven tests with t.Run() for subtests", "convention"},
				{"No global state — pass dependencies via constructors", "convention"},
				{"Use interfaces for external dependencies (testability)", "convention"},
			},
		},
		{
			Name: "react", Stack: "React + TypeScript",
			Memories: []TemplateMemory{
				{"Functional components only (no class components)", "convention"},
				{"Use React Query for server state, Zustand for client state", "convention"},
				{"Named exports only, no default exports", "convention"},
				{"Co-locate tests with components (Component.test.tsx)", "convention"},
				{"Use absolute imports via tsconfig paths", "convention"},
			},
		},
		{
			Name: "python-api", Stack: "Python FastAPI",
			Memories: []TemplateMemory{
				{"Use Pydantic models for all request/response validation", "convention"},
				{"Async endpoints by default (def → async def)", "convention"},
				{"Use dependency injection for database sessions", "convention"},
				{"Alembic for database migrations", "convention"},
				{"pytest with fixtures for testing", "convention"},
			},
		},
	}
}

// Apply stores a template's memories into the engine.
func (t *Templates) Apply(ctx context.Context, eng *Engine, templateName string) (int, error) {
	templates := t.Available()
	for _, tmpl := range templates {
		if !strings.EqualFold(tmpl.Name, templateName) {
			continue
		}
		count := 0
		for _, m := range tmpl.Memories {
			_, err := eng.Remember(ctx, RememberInput{
				Type:    m.Type,
				Content: m.Content,
				Scope:   "project",
			})
			if err == nil {
				count++
			}
		}
		return count, nil
	}
	return 0, fmt.Errorf("template %q not found. Available: nextjs, go-api, react, python-api", templateName)
}
