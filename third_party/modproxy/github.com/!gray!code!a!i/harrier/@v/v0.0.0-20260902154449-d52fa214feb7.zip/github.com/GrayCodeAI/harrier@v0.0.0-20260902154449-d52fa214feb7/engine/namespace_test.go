package engine

import (
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestSubagentNamespace(t *testing.T) {
	mgr := NewNamespaceManager()
	ns := mgr.RegisterNamespace("sess-1", "codebase-researcher", "proj-a")

	expectedID := "sess-1:codebase-researcher"
	if ns.ID != expectedID {
		t.Fatalf("expected namespace ID %s, got %s", expectedID, ns.ID)
	}

	nodes := []*storage.Node{
		{ID: "n1", Metadata: map[string]string{"namespace": expectedID}},
		{ID: "n2", Metadata: map[string]string{"namespace": "sess-1:other-agent"}},
	}

	filtered := FilterNodesByNamespace(nodes, expectedID)
	if len(filtered) != 1 || filtered[0].ID != "n1" {
		t.Fatalf("expected only n1 to pass filter, got %d nodes", len(filtered))
	}
}

func TestTeamNamespaceFilter(t *testing.T) {
	nodes := []*storage.Node{
		{ID: "n1", Scope: "team"},
		{ID: "n2", Scope: "project", Metadata: map[string]string{"namespace": "other"}},
	}
	filtered := FilterNodesByNamespace(nodes, "target-ns")
	if len(filtered) != 1 || filtered[0].ID != "n1" {
		t.Fatalf("expected team scoped node n1 to pass filter, got %d nodes", len(filtered))
	}
}
