package cognitive

import (
	"sync"
)

type SomaticMarker struct {
	Region     string  `json:"region"`
	Valence    float64 `json:"valence"`
	Arousal    float64 `json:"arousal"`
	Confidence float64 `json:"confidence"`
	Accesses   int     `json:"accesses"`
}

type SomaticConfig struct {
	Enabled        bool    `json:"enabled"`
	SkipThreshold  float64 `json:"skip_threshold"`
	BoostThreshold float64 `json:"boost_threshold"`
}

func DefaultSomaticConfig() SomaticConfig {
	return SomaticConfig{
		Enabled:        true,
		SkipThreshold:  -0.5,
		BoostThreshold: 0.5,
	}
}

type SomaticEngine struct {
	mu      sync.RWMutex
	markers map[string]*SomaticMarker
	config  SomaticConfig
}

func NewSomaticEngine(config SomaticConfig) *SomaticEngine {
	return &SomaticEngine{
		markers: make(map[string]*SomaticMarker),
		config:  config,
	}
}

func (e *SomaticEngine) RecordOutcome(region string, success bool) {
	if !e.config.Enabled {
		return
	}
	e.mu.Lock()
	defer e.mu.Unlock()

	marker, ok := e.markers[region]
	if !ok {
		marker = &SomaticMarker{Region: region, Confidence: 0.5}
		e.markers[region] = marker
	}

	marker.Accesses++
	if success {
		marker.Valence = marker.Valence*0.8 + 0.2
	} else {
		marker.Valence = marker.Valence*0.8 - 0.2
	}
	marker.Confidence = 1.0 - 1.0/float64(marker.Accesses+1)
}

func (e *SomaticEngine) ShouldSkip(region string) bool {
	e.mu.RLock()
	defer e.mu.RUnlock()

	marker, ok := e.markers[region]
	if !ok {
		return false
	}
	return marker.Valence < e.config.SkipThreshold && marker.Confidence > 0.6
}

func (e *SomaticEngine) ShouldBoost(region string) bool {
	e.mu.RLock()
	defer e.mu.RUnlock()

	marker, ok := e.markers[region]
	if !ok {
		return false
	}
	return marker.Valence > e.config.BoostThreshold && marker.Confidence > 0.6
}

func (e *SomaticEngine) GetMarker(region string) *SomaticMarker {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.markers[region]
}
