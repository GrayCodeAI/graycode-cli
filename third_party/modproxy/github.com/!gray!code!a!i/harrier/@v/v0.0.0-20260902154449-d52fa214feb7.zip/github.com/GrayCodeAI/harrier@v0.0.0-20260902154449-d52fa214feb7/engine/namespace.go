package engine

import (
	"context"
	"fmt"
	"sync"

	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// NamespaceManager provides thread-safe memory isolation for concurrent subagents.
type NamespaceManager struct {
	mu         sync.RWMutex
	namespaces map[string]*SubagentNamespace
}

// SubagentNamespace represents an isolated memory subgraph for a specific subagent.
type SubagentNamespace struct {
	ID        string `json:"id"`
	SessionID string `json:"session_id"`
	Role      string `json:"role"`
	Project   string `json:"project"`
}

// NewNamespaceManager initializes a SubagentNamespaceManager.
func NewNamespaceManager() *NamespaceManager {
	return &NamespaceManager{
		namespaces: make(map[string]*SubagentNamespace),
	}
}

// FormatNamespaceID creates a deterministic namespace key from sessionID and role.
func FormatNamespaceID(sessionID, role string) string {
	return fmt.Sprintf("%s:%s", sessionID, role)
}

// RegisterNamespace creates a thread-safe namespace entry for a subagent.
func (nm *NamespaceManager) RegisterNamespace(sessionID, role, project string) *SubagentNamespace {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	id := FormatNamespaceID(sessionID, role)
	ns := &SubagentNamespace{
		ID:        id,
		SessionID: sessionID,
		Role:      role,
		Project:   project,
	}
	nm.namespaces[id] = ns
	return ns
}

// TeamNamespace represents a shared memory scope across developers and agents in a team.
type TeamNamespace struct {
	TeamID   string   `json:"team_id"`
	Name     string   `json:"name"`
	Projects []string `json:"projects"`
}

// MultiProjectLink represents a cross-project connection between memory graphs.
type MultiProjectLink struct {
	SourceProject string `json:"source_project"`
	TargetProject string `json:"target_project"`
	Relation      string `json:"relation"`
}

// FilterNodesByNamespace restricts nodes to those belonging to the given namespace or team scope.
func FilterNodesByNamespace(nodes []*storage.Node, namespaceID string) []*storage.Node {
	if namespaceID == "" {
		return nodes
	}
	var filtered []*storage.Node
	for _, n := range nodes {
		if n.Metadata == nil || n.Metadata["namespace"] == namespaceID || n.Metadata["namespace"] == "" || n.Scope == "team" {
			filtered = append(filtered, n)
		}
	}
	return filtered
}

// LinkProjects creates a cross-project relationship between two project spaces.
func LinkProjects(ctx context.Context, g graph.Graph, store storage.Storage, sourceProj, targetProj, relation string) (*storage.Edge, error) {
	if sourceProj == "" || targetProj == "" {
		return nil, fmt.Errorf("source and target projects must be non-empty")
	}
	if relation == "" {
		relation = "relates_to"
	}

	// Fetch root or file nodes for each project
	srcNodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: sourceProj, Limit: 1})
	if err != nil || len(srcNodes) == 0 {
		return nil, fmt.Errorf("source project %s has no nodes: %v", sourceProj, err)
	}
	tgtNodes, err := store.ListNodes(ctx, storage.NodeFilter{Project: targetProj, Limit: 1})
	if err != nil || len(tgtNodes) == 0 {
		return nil, fmt.Errorf("target project %s has no nodes: %v", targetProj, err)
	}

	edge := &storage.Edge{
		FromID: srcNodes[0].ID,
		ToID:   tgtNodes[0].ID,
		Type:   relation,
	}
	return edge, g.AddEdge(ctx, edge)
}
