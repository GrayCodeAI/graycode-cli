package engine

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

// SessionHandoff implements MemGPT-style automatic session summary generation.
// At session end, it produces a concise handoff summary that captures:
//   - What was accomplished
//   - Decisions made
//   - Conventions established
//   - Bugs found/fixed
//   - What's in progress
//
// The next session gets this injected automatically so the agent picks up
// exactly where it left off.
type SessionHandoff struct {
	store storage.Storage
}

// HandoffSummary is the structured output of session analysis.
type HandoffSummary struct {
	SessionID    string   `json:"session_id"`
	Duration     string   `json:"duration"`
	Accomplished []string `json:"accomplished"`
	Decisions    []string `json:"decisions"`
	Conventions  []string `json:"conventions"`
	BugsFound    []string `json:"bugs_found"`
	InProgress   []string `json:"in_progress"`
	NextSteps    []string `json:"next_steps"`
}

// NewSessionHandoff creates a handoff generator.
func NewSessionHandoff(store storage.Storage) *SessionHandoff {
	return &SessionHandoff{store: store}
}

// Generate produces a handoff summary from memories created during a session.
func (sh *SessionHandoff) Generate(ctx context.Context, sessionID string, duration time.Duration) (*HandoffSummary, error) {
	summary := &HandoffSummary{
		SessionID: sessionID,
		Duration:  duration.Round(time.Second).String(),
	}

	// Get all nodes from this session
	nodes, err := sh.store.ListNodes(ctx, storage.NodeFilter{
		SourceSession: sessionID,
		Limit:         100,
	})
	if err != nil {
		return summary, err
	}

	// Categorize by type
	for _, n := range nodes {
		content := n.Content
		if len(content) > 120 {
			content = content[:120] + "..."
		}

		switch n.Type {
		case "decision":
			summary.Decisions = append(summary.Decisions, content)
		case "convention":
			summary.Conventions = append(summary.Conventions, content)
		case "bug":
			summary.BugsFound = append(summary.BugsFound, content)
		case "task":
			if strings.Contains(strings.ToLower(content), "in progress") ||
				strings.Contains(content, "→") {
				summary.InProgress = append(summary.InProgress, content)
			} else {
				summary.Accomplished = append(summary.Accomplished, content)
			}
		case "spec", "skill":
			summary.Accomplished = append(summary.Accomplished, content)
		}
	}

	return summary, nil
}

// FormatForInjection converts the handoff into a markdown string for prompt injection.
func (sh *SessionHandoff) FormatForInjection(summary *HandoffSummary) string {
	if summary == nil {
		return ""
	}

	var sb strings.Builder
	sb.WriteString("## Previous Session Recap\n")
	fmt.Fprintf(&sb, "*Duration: %s*\n\n", summary.Duration)

	if len(summary.Decisions) > 0 {
		sb.WriteString("### Decisions Made\n")
		for _, d := range summary.Decisions {
			fmt.Fprintf(&sb, "- %s\n", d)
		}
		sb.WriteString("\n")
	}

	if len(summary.Conventions) > 0 {
		sb.WriteString("### Conventions Established\n")
		for _, c := range summary.Conventions {
			fmt.Fprintf(&sb, "- %s\n", c)
		}
		sb.WriteString("\n")
	}

	if len(summary.BugsFound) > 0 {
		sb.WriteString("### Bugs Found\n")
		for _, b := range summary.BugsFound {
			fmt.Fprintf(&sb, "- %s\n", b)
		}
		sb.WriteString("\n")
	}

	if len(summary.InProgress) > 0 {
		sb.WriteString("### In Progress\n")
		for _, p := range summary.InProgress {
			fmt.Fprintf(&sb, "- %s\n", p)
		}
		sb.WriteString("\n")
	}

	return sb.String()
}

// GetLastSessionSummary retrieves and formats the previous session's handoff.
func (sh *SessionHandoff) GetLastSessionSummary(ctx context.Context, project string) string {
	sessions, err := sh.store.ListSessions(ctx, project, 2)
	if err != nil || len(sessions) < 2 {
		return ""
	}

	// The previous session is sessions[1] (sessions[0] is current)
	prev := sessions[1]
	if prev.Summary != "" {
		return prev.Summary
	}

	// Generate from nodes if no stored summary
	duration := time.Duration(0)
	if !prev.EndedAt.IsZero() {
		duration = prev.EndedAt.Sub(prev.StartedAt)
	}
	summary, err := sh.Generate(ctx, prev.ID, duration)
	if err != nil {
		return ""
	}
	return sh.FormatForInjection(summary)
}
