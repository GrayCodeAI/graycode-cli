package server

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	gitwatch "github.com/GrayCodeAI/harrier/git"
	"github.com/GrayCodeAI/harrier/skill"
	"github.com/mark3labs/mcp-go/mcp"
)

// --- resources ---

func (s *MCPServer) registerResources() {
	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://context",
		Name:        "context",
		Description: "Hot-tier context nodes for session injection",
		MIMEType:    "application/json",
	}, s.handleResourceContext)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://graph/stats",
		Name:        "graph_stats",
		Description: "Node/edge counts and health metrics",
		MIMEType:    "application/json",
	}, s.handleResourceStats)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://stale",
		Name:        "stale",
		Description: "Potentially stale memory nodes based on git changes",
		MIMEType:    "application/json",
	}, s.handleResourceStale)

	// Task #152: Additional MCP resources

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://memory/{id}",
		Name:        "memory",
		Description: "Retrieve a specific memory node by ID",
		MIMEType:    "application/json",
	}, s.handleResourceMemory)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://skills",
		Name:        "skills",
		Description: "List all stored procedural skills",
		MIMEType:    "application/json",
	}, s.handleResourceSkills)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://profile",
		Name:        "profile",
		Description: "User/project profile with static facts and dynamic context",
		MIMEType:    "application/json",
	}, s.handleResourceProfile)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://mental-model",
		Name:        "mental_model",
		Description: "Auto-evolving project summary: conventions, decisions, architecture",
		MIMEType:    "application/json",
	}, s.handleResourceMentalModel)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://sessions",
		Name:        "sessions",
		Description: "Recent session history and summaries",
		MIMEType:    "application/json",
	}, s.handleResourceSessions)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://export",
		Name:        "export",
		Description: "Export memory graph as interactive HTML visualization",
		MIMEType:    "text/html",
	}, s.handleResourceExport)

	s.srv.AddResource(mcp.Resource{
		URI:         "harrier://communities",
		Name:        "communities",
		Description: "Memory communities and thematic clusters",
		MIMEType:    "application/json",
	}, s.handleResourceCommunities)
}

func (s *MCPServer) handleResourceContext(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	result, err := s.eng.Context(ctx, "")
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://context", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceStats(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	status, err := s.eng.Status(ctx, "")
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(status, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://graph/stats", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceStale(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	watcher, err := gitwatch.New(s.eng.Store(), s.eng.Graph(), "")
	if err != nil {
		return []mcp.ResourceContents{
			mcp.TextResourceContents{URI: "harrier://stale", MIMEType: "application/json", Text: "[]"},
		}, nil
	}
	stale, err := watcher.StalesSince(ctx, time.Now().Add(-24*time.Hour))
	if err != nil {
		return []mcp.ResourceContents{
			mcp.TextResourceContents{URI: "harrier://stale", MIMEType: "application/json", Text: "[]"},
		}, nil
	}
	b, err := json.MarshalIndent(stale, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://stale", MIMEType: "application/json", Text: string(b)},
	}, nil
}

// Task #152: Additional resource handlers

func (s *MCPServer) handleResourceMemory(ctx context.Context, req mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	// Extract ID from URI: harrier://memory/{id}
	id := req.Params.URI
	if idx := strings.LastIndex(id, "/"); idx >= 0 {
		id = id[idx+1:]
	}
	node, err := s.eng.Store().GetNode(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("memory %q not found: %w", id, err)
	}
	b, err := json.MarshalIndent(node, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: req.Params.URI, MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceSkills(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	project, _ := os.Getwd()
	skills, err := skill.ListSkills(ctx, s.eng.Store(), project)
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(skills, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://skills", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceProfile(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	p, err := s.eng.Profile(ctx, "")
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(p, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://profile", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceMentalModel(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	model, err := s.eng.MentalModel(ctx, "")
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(model, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://mental-model", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceSessions(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	sessions, err := s.eng.Store().ListSessions(ctx, "", 20)
	if err != nil {
		return nil, err
	}
	b, err := json.MarshalIndent(sessions, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://sessions", MIMEType: "application/json", Text: string(b)},
	}, nil
}

func (s *MCPServer) handleResourceExport(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	html, err := engine.ExportHTML(ctx, s.eng.Store())
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://export", MIMEType: "text/html", Text: html},
	}, nil
}

func (s *MCPServer) handleResourceCommunities(ctx context.Context, _ mcp.ReadResourceRequest) ([]mcp.ResourceContents, error) {
	cd := engine.NewCommunityDetector(s.eng.Store())
	communities, err := cd.Detect(ctx, 10)
	if err != nil {
		return nil, err
	}
	communities = cd.Summarize(ctx, communities)
	b, err := json.MarshalIndent(communities, "", "  ")
	if err != nil {
		return nil, err
	}
	return []mcp.ResourceContents{
		mcp.TextResourceContents{URI: "harrier://communities", MIMEType: "application/json", Text: string(b)},
	}, nil
}
