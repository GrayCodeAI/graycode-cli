package storage

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"log/slog"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// removeBackupFile deletes a pruned backup (or stale temp file), logging any
// error other than "already gone" so rotation failures are visible instead of
// silently leaving the directory over retention.
func removeBackupFile(path string) {
	if err := os.Remove(path); err != nil && !errors.Is(err, fs.ErrNotExist) {
		slog.Warn("backup rotation: failed to remove backup file", "path", path, "error", err)
	}
}

// defaultTmpMaxAge bounds how long aborted Backup temp files may linger
// before RotateBackups sweeps them.
const defaultTmpMaxAge = 24 * time.Hour

// RotateBackups prunes the backup directory after a Backup so it does not
// grow without bound. It keeps the newest `keep` backup files (0 = no count
// limit), then deletes any remaining backups older than `maxAge` (0 = no
// age limit). The newest backup is never deleted by age alone — rotation
// must not leave a healthy database with zero backups if it was simply idle.
//
// Only regular files directly inside dir are considered; stale "*.tmp" files
// left behind by aborted Backup writes are removed after 24h.
func (s *Store) RotateBackups(ctx context.Context, dir string, keep int, maxAge time.Duration) error {
	if dir == "" {
		return fmt.Errorf("backup directory must not be empty")
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return fmt.Errorf("read backup directory: %w", err)
	}

	type backup struct {
		path    string
		modTime time.Time
	}
	backups := make([]backup, 0, len(entries))
	for _, e := range entries {
		if !e.Type().IsRegular() {
			continue
		}
		name := e.Name()
		info, err := e.Info()
		if err != nil {
			continue // disappearing mid-scan; nothing to do
		}
		path := filepath.Join(dir, name)
		// Sweep abandoned VACUUM INTO temp files from failed backups.
		if strings.HasSuffix(name, ".tmp") {
			if time.Since(info.ModTime()) > defaultTmpMaxAge {
				removeBackupFile(path)
			}
			continue
		}
		backups = append(backups, backup{path: path, modTime: info.ModTime()})
	}
	if len(backups) == 0 {
		return nil
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}

	sort.Slice(backups, func(i, j int) bool { return backups[i].modTime.After(backups[j].modTime) })

	for i, b := range backups {
		tooMany := keep > 0 && i >= keep
		tooOld := maxAge > 0 && time.Since(b.modTime) > maxAge && i > 0
		if tooMany || tooOld {
			removeBackupFile(b.path)
		}
	}
	return nil
}
