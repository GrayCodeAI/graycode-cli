package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/google/uuid"
)

func setupStore(t *testing.T) (*Store, func()) {
	t.Helper()
	dir := t.TempDir()
	store, err := NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	return store, func() { _ = store.Close(); os.RemoveAll(dir) }
}

func TestCreateAndGetNode(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	node := &Node{
		ID:          uuid.New().String(),
		Type:        "convention",
		Content:     "Use jose not jsonwebtoken",
		ContentHash: "abc123",
		Scope:       "project",
		Project:     "testproj",
		Confidence:  1.0,
	}
	if err := s.CreateNode(ctx, node); err != nil {
		t.Fatalf("CreateNode: %v", err)
	}

	got, err := s.GetNode(ctx, node.ID)
	if err != nil {
		t.Fatalf("GetNode: %v", err)
	}
	if got.Content != node.Content {
		t.Errorf("content mismatch: got %q, want %q", got.Content, node.Content)
	}
}

func TestGetNodeNotFound(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	_, err := s.GetNode(ctx, "nonexistent")
	if err == nil {
		t.Fatal("expected error for nonexistent node")
	}
	if !errors.Is(err, ErrNodeNotFound) {
		t.Errorf("expected ErrNodeNotFound, got: %v", err)
	}
}

func TestDuplicateNode(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	node := &Node{
		ID:          uuid.New().String(),
		Type:        "convention",
		Content:     "dup test",
		ContentHash: "hash1",
		Scope:       "project",
		Project:     "testproj",
	}
	if err := s.CreateNode(ctx, node); err != nil {
		t.Fatal(err)
	}

	// Same hash, scope, project should fail
	node2 := &Node{
		ID:          uuid.New().String(),
		Type:        "decision",
		Content:     "different content",
		ContentHash: "hash1",
		Scope:       "project",
		Project:     "testproj",
	}
	err := s.CreateNode(ctx, node2)
	if err == nil {
		t.Fatal("expected duplicate error")
	}
	if !errors.Is(err, ErrDuplicateNode) {
		t.Errorf("expected ErrDuplicateNode, got: %v", err)
	}
}

func TestCreateAndGetEdge(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Need nodes first
	for _, id := range []string{"a", "b"} {
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"})
	}

	e := &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0}
	if err := s.CreateEdge(ctx, e); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}

	got, err := s.GetEdge(ctx, "e1")
	if err != nil {
		t.Fatalf("GetEdge: %v", err)
	}
	if got.Type != "led_to" {
		t.Errorf("type mismatch: got %q, want led_to", got.Type)
	}
}

func TestGetEdgeNotFound(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	_, err := s.GetEdge(ctx, "nonexistent")
	if err == nil {
		t.Fatal("expected error")
	}
	if !errors.Is(err, ErrEdgeNotFound) {
		t.Errorf("expected ErrEdgeNotFound, got: %v", err)
	}
}

func TestDuplicateEdge(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b"} {
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"})
	}

	_ = s.CreateEdge(ctx, &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0})
	err := s.CreateEdge(ctx, &Edge{ID: "e2", FromID: "a", ToID: "b", Type: "led_to", Weight: 0.5})
	if err == nil {
		t.Fatal("expected duplicate edge error")
	}
	if !errors.Is(err, ErrDuplicateEdge) {
		t.Errorf("expected ErrDuplicateEdge, got: %v", err)
	}
}

func TestGetNodesBatchChunks(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Create more nodes than maxSQLVariables to test chunking
	var ids []string
	for i := 0; i < 100; i++ {
		id := uuid.New().String()
		ids = append(ids, id)
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "convention", Content: "batch", ContentHash: "h" + id, Scope: "project"})
	}

	nodes, err := s.GetNodesBatch(ctx, ids)
	if err != nil {
		t.Fatalf("GetNodesBatch: %v", err)
	}
	if len(nodes) != 100 {
		t.Errorf("expected 100 nodes, got %d", len(nodes))
	}
}

func TestAccessLog(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	node := &Node{ID: "n1", Type: "convention", Content: "test", ContentHash: "h1", Scope: "project"}
	_ = s.CreateNode(ctx, node)

	// Log multiple accesses
	for i := 0; i < 5; i++ {
		if err := s.LogAccess(ctx, "n1"); err != nil {
			t.Fatalf("LogAccess: %v", err)
		}
	}

	// Flush should update access_count
	n, err := s.FlushAccessLog(ctx)
	if err != nil {
		t.Fatalf("FlushAccessLog: %v", err)
	}
	if n != 1 {
		t.Errorf("expected 1 node updated, got %d", n)
	}

	got, _ := s.GetNode(ctx, "n1")
	if got.AccessCount != 5 {
		t.Errorf("expected access_count=5, got %d", got.AccessCount)
	}
	if got.AccessedAt.IsZero() {
		t.Error("expected accessed_at to be set")
	}
}

func TestGetEdgesBetween(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b", "c", "d"} {
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"})
	}
	_ = s.CreateEdge(ctx, &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0})
	_ = s.CreateEdge(ctx, &Edge{ID: "e2", FromID: "b", ToID: "c", Type: "led_to", Weight: 1.0})
	_ = s.CreateEdge(ctx, &Edge{ID: "e3", FromID: "c", ToID: "d", Type: "relates_to", Weight: 1.0})

	// Edges between a,b,c (should get e1 and e2)
	edges, err := s.GetEdgesBetween(ctx, []string{"a", "b", "c"})
	if err != nil {
		t.Fatalf("GetEdgesBetween: %v", err)
	}
	if len(edges) != 2 {
		t.Errorf("expected 2 edges, got %d", len(edges))
	}
}

func TestCheckCycle(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	for _, id := range []string{"a", "b", "c"} {
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: "h" + id, Scope: "project"})
	}
	_ = s.CreateEdge(ctx, &Edge{ID: "e1", FromID: "a", ToID: "b", Type: "led_to", Weight: 1.0, Acyclic: true})
	_ = s.CreateEdge(ctx, &Edge{ID: "e2", FromID: "b", ToID: "c", Type: "led_to", Weight: 1.0, Acyclic: true})

	// a -> b -> c, so c -> a would create cycle
	hasCycle, err := s.CheckCycle(ctx, "c", "a")
	if err != nil {
		t.Fatalf("CheckCycle: %v", err)
	}
	if !hasCycle {
		t.Error("expected cycle detected for c -> a")
	}

	// a -> b is not a cycle
	hasCycle, _ = s.CheckCycle(ctx, "a", "b")
	if hasCycle {
		t.Error("expected no cycle for a -> b")
	}
}

func TestSessions(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	sess := &Session{
		ID:        "s1",
		Project:   "p1",
		Agent:     "test-agent",
		StartedAt: time.Now(),
	}
	if err := s.CreateSession(ctx, sess); err != nil {
		t.Fatalf("CreateSession: %v", err)
	}

	if err := s.EndSession(ctx, "s1", "completed"); err != nil {
		t.Fatalf("EndSession: %v", err)
	}

	sessions, err := s.ListSessions(ctx, "p1", 10)
	if err != nil {
		t.Fatalf("ListSessions: %v", err)
	}
	if len(sessions) != 1 {
		t.Fatalf("expected 1 session, got %d", len(sessions))
	}
	if sessions[0].Summary != "completed" {
		t.Errorf("summary mismatch: got %q", sessions[0].Summary)
	}
	if sessions[0].EndedAt.IsZero() {
		t.Error("expected ended_at to be set")
	}
}

func TestVersions(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	node := &Node{ID: "n1", Type: "convention", Content: "v1", ContentHash: "h1", Scope: "project"}
	_ = s.CreateNode(ctx, node)

	_ = s.SaveVersion(ctx, "n1", "v1", "user", "saved")
	_ = s.SaveVersion(ctx, "n1", "v2", "user", "edited")

	versions, err := s.GetVersions(ctx, "n1")
	if err != nil {
		t.Fatalf("GetVersions: %v", err)
	}
	if len(versions) != 2 {
		t.Errorf("expected 2 versions, got %d", len(versions))
	}
}

func TestWithTx(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	err := s.WithTx(ctx, func(tx Storage) error {
		return tx.CreateNode(ctx, &Node{ID: "tx1", Type: "convention", Content: "tx", ContentHash: "htx", Scope: "project"})
	})
	if err != nil {
		t.Fatalf("WithTx: %v", err)
	}

	node, err := s.GetNode(ctx, "tx1")
	if err != nil {
		t.Fatalf("GetNode after tx: %v", err)
	}
	if node.ID != "tx1" {
		t.Errorf("expected tx1, got %s", node.ID)
	}
}

func TestSearchNodesWithSpecialChars(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Node with content that contains FTS5 special chars
	_ = s.CreateNode(ctx, &Node{
		ID: uuid.New().String(), Type: "convention",
		Content: "Use auth* with JWT tokens", ContentHash: "h1", Scope: "project",
	})
	_ = s.CreateNode(ctx, &Node{
		ID: uuid.New().String(), Type: "convention",
		Content: "Use OAuth not basic auth", ContentHash: "h2", Scope: "project",
	})

	// Search with * should not crash or inject
	results, err := s.SearchNodes(ctx, "auth*", 10)
	if err != nil {
		t.Fatalf("SearchNodes: %v", err)
	}
	if len(results) == 0 {
		t.Error("expected at least one result for auth*")
	}

	// Search with quoted content
	results, err = s.SearchNodes(ctx, `OAuth "not"`, 10)
	if err != nil {
		t.Fatalf("SearchNodes: %v", err)
	}
	if len(results) == 0 {
		t.Error("expected at least one result for quoted search")
	}
}

func TestEscapeFTS5(t *testing.T) {
	cases := []struct {
		input string
		want  string
	}{
		{"auth", `"auth"`},
		{"auth JWT", `"auth" OR "JWT"`},
		{`auth"injection`, `"auth""injection"`},
		{"auth*", `"auth*"`},
		{"auth -JWT", `"auth" OR "-JWT"`},
	}
	for _, tc := range cases {
		got := escapeFTS5(tc.input)
		if got != tc.want {
			t.Errorf("escapeFTS5(%q) = %q, want %q", tc.input, got, tc.want)
		}
	}
}

func TestWithTxRollback(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	err := s.WithTx(ctx, func(tx Storage) error {
		_ = tx.CreateNode(ctx, &Node{ID: "rollback", Type: "convention", Content: "x", ContentHash: "h", Scope: "project"})
		return errors.New("intentional failure")
	})
	if err == nil {
		t.Fatal("expected error from WithTx")
	}

	_, err = s.GetNode(ctx, "rollback")
	if err == nil {
		t.Error("expected node to not exist after rollback")
	}
}

func TestSignaturePersistence(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Create nodes first — the signatures table has a FOREIGN KEY constraint
	// on node_id that was never enforced before (the DSN's _foreign_keys=on
	// was silently ignored by modernc.org/sqlite). Now that _pragma properly
	// sets foreign_keys(ON), the constraint actually fires.
	for _, id := range []string{"node-a", "node-b"} {
		if err := s.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h" + id, Scope: "project",
		}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}

	// Save signatures for two nodes
	if err := s.SaveSignature(ctx, "node-a", "sig-aaa"); err != nil {
		t.Fatalf("SaveSignature: %v", err)
	}
	if err := s.SaveSignature(ctx, "node-b", "sig-bbb"); err != nil {
		t.Fatalf("SaveSignature: %v", err)
	}

	// Retrieve all signatures
	sigs, err := s.GetAllSignatures(ctx)
	if err != nil {
		t.Fatalf("GetAllSignatures: %v", err)
	}
	if len(sigs) != 2 {
		t.Fatalf("expected 2 signatures, got %d", len(sigs))
	}
	if sigs["node-a"] != "sig-aaa" {
		t.Errorf("expected sig-aaa, got %q", sigs["node-a"])
	}
	if sigs["node-b"] != "sig-bbb" {
		t.Errorf("expected sig-bbb, got %q", sigs["node-b"])
	}

	// Overwrite a signature (INSERT OR REPLACE)
	if err := s.SaveSignature(ctx, "node-a", "sig-updated"); err != nil {
		t.Fatalf("SaveSignature update: %v", err)
	}
	sigs, _ = s.GetAllSignatures(ctx)
	if sigs["node-a"] != "sig-updated" {
		t.Errorf("expected sig-updated after overwrite, got %q", sigs["node-a"])
	}
	if len(sigs) != 2 {
		t.Errorf("expected still 2 signatures after overwrite, got %d", len(sigs))
	}
}

func TestListNodesTagFilter(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()
	mk := func(id, tags string) {
		if err := s.CreateNode(ctx, &Node{ID: id, Type: "decision", Content: id, ContentHash: id, Tags: tags, Confidence: 1}); err != nil {
			t.Fatalf("CreateNode(%s): %v", id, err)
		}
	}
	mk("n1", "topic:foo,other")
	mk("n2", "topic:foobar") // must NOT match topic:foo
	mk("n3", "a,topic:foo")  // match, tag in middle/end
	mk("n4", "unrelated")

	got, err := s.ListNodes(ctx, NodeFilter{Tag: "topic:foo"})
	if err != nil {
		t.Fatal(err)
	}
	ids := map[string]bool{}
	for _, n := range got {
		ids[n.ID] = true
	}
	if !ids["n1"] || !ids["n3"] {
		t.Errorf("expected n1 and n3, got %v", ids)
	}
	if ids["n2"] {
		t.Errorf("topic:foo must not match topic:foobar (n2 leaked)")
	}
	if ids["n4"] {
		t.Errorf("unrelated node n4 leaked")
	}
}

func TestProcessLock(t *testing.T) {
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "test.db")

	// First store acquires lock
	s1, err := NewStore(dbPath)
	if err != nil {
		t.Fatalf("NewStore #1: %v", err)
	}

	// Second store on the same path succeeds in-process: the process lock
	// is refcounted per path, so multiple stores in one process (the common
	// case for hosts that open the memory bridge from several callsites)
	// share the OS lock instead of blocking each other.
	s2, err := NewStore(dbPath)
	if err != nil {
		t.Fatalf("NewStore #2 (same process, refcounted): %v", err)
	}

	// Release s1; s2 still holds the refcount, so the lock remains.
	s1.Close()

	// s2 alone keeps the database openable across its own close.
	s2.Close()

	// After the last in-process release, a fresh store still succeeds.
	s3, err := NewStore(dbPath)
	if err != nil {
		t.Fatalf("NewStore after release: %v", err)
	}
	s3.Close()

	// In-memory DSN should bypass lock
	mem1, err := NewStore(":memory:")
	if err != nil {
		t.Fatalf("in-memory #1: %v", err)
	}
	mem2, err := NewStore(":memory:")
	if err != nil {
		t.Fatalf("in-memory #2: %v", err)
	}
	mem1.Close()
	mem2.Close()

	// file::memory: DSN should also bypass lock
	fileMem1, err := NewStore("file::memory:")
	if err != nil {
		t.Fatalf("file::memory #1: %v", err)
	}
	fileMem2, err := NewStore("file::memory:")
	if err != nil {
		t.Fatalf("file::memory #2: %v", err)
	}
	fileMem1.Close()
	fileMem2.Close()
}

func TestHNSWIndex(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	// Create nodes with embeddings. All vectors share a first dimension of 1
	// and vary the second so their angles (and cosine similarities) differ;
	// node-5 points exactly in the query direction.
	model := "test-model"
	for i := 0; i < 10; i++ {
		id := fmt.Sprintf("node-%d", i)
		_ = s.CreateNode(ctx, &Node{
			ID: id, Type: "convention", Content: id,
			ContentHash: "h" + id, Scope: "project", Project: "test",
		})
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = float32(i) * 0.1
		_ = s.SaveEmbedding(ctx, id, model, vec)
	}

	// Build HNSW index
	if err := s.BuildHNSWIndex(ctx, model); err != nil {
		t.Fatalf("BuildHNSWIndex: %v", err)
	}

	// Search for vectors similar to [1, 0.5, 0, ...] (exact match: node-5)
	query := make([]float32, 8)
	query[0] = 1.0
	query[1] = 0.5
	ids, scores, err := s.SearchHNSW(ctx, model, query, 3, 50)
	if err != nil {
		t.Fatalf("SearchHNSW: %v", err)
	}
	if len(ids) != 3 {
		t.Fatalf("expected 3 results, got %d", len(ids))
	}
	// First result should be node-5 (exact match)
	if ids[0] != "node-5" {
		t.Errorf("expected first result node-5, got %s", ids[0])
	}
	// Scores should be in descending order (highest similarity first)
	if scores[0] < scores[1] || scores[1] < scores[2] {
		t.Errorf("scores not in descending order: %v", scores)
	}

	// Test with different model (should build new index)
	model2 := "other-model"
	for i := 0; i < 5; i++ {
		id := fmt.Sprintf("other-%d", i)
		_ = s.CreateNode(ctx, &Node{ID: id, Type: "convention", Content: id, ContentHash: "h" + id, Scope: "project", Project: "test"})
		vec := make([]float32, 8)
		vec[0] = 1.0
		vec[1] = float32(i) * 0.2
		_ = s.SaveEmbedding(ctx, id, model2, vec)
	}
	ids, _, err = s.SearchHNSW(ctx, model2, query, 2, 50)
	if err != nil {
		t.Fatalf("SearchHNSW model2: %v", err)
	}
	if len(ids) != 2 {
		t.Fatalf("expected 2 results for model2, got %d", len(ids))
	}
}

// TestDeleteNodeRemovesChildren is a regression test for the FK-violation bug
// where deleteNodeQ only deleted edges + nodes. With foreign_keys(ON) and no
// ON DELETE CASCADE on embeddings / file_watch / node_signatures, deleting a
// node with child rows used to fail; node_versions and node_metadata rows
// leaked orphans. DeleteNode must remove every child and succeed.
func TestDeleteNodeRemovesChildren(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	a := &Node{
		ID:          "node-child-a",
		Type:        "convention",
		Content:     "content A",
		ContentHash: "hash-a",
		Scope:       "project",
		Project:     "test",
		Metadata:    map[string]string{"k": "v"},
	}
	b := &Node{ID: "node-child-b", Type: "convention", Content: "content B", ContentHash: "hash-b", Scope: "project", Project: "test"}
	if err := s.CreateNode(ctx, a); err != nil {
		t.Fatalf("CreateNode a: %v", err)
	}
	if err := s.CreateNode(ctx, b); err != nil {
		t.Fatalf("CreateNode b: %v", err)
	}

	// Populate every child table that references the node.
	if err := s.CreateEdge(ctx, &Edge{ID: "e1", FromID: a.ID, ToID: b.ID, Type: "relates"}); err != nil {
		t.Fatalf("CreateEdge: %v", err)
	}
	if err := s.SaveEmbedding(ctx, a.ID, "default", []float32{1, 0, 0}); err != nil {
		t.Fatalf("SaveEmbedding: %v", err)
	}
	if err := s.SaveSignature(ctx, a.ID, "sig-a"); err != nil {
		t.Fatalf("SaveSignature: %v", err)
	}
	if err := s.AddFileWatch(ctx, "/tmp/file.go", a.ID, "githash"); err != nil {
		t.Fatalf("AddFileWatch: %v", err)
	}
	if err := s.SaveVersion(ctx, a.ID, "v1 content", "tester", "regression"); err != nil {
		t.Fatalf("SaveVersion: %v", err)
	}
	// embeddings_hnsw rows are normally written by the HNSW index persist
	// path; insert one directly to prove the FK chain is honored.
	if _, err := s.db.ExecContext(ctx,
		`INSERT INTO embeddings_hnsw (node_id, vector, model, neighbors, updated_at) VALUES (?, ?, 'default', '[]', CURRENT_TIMESTAMP)`,
		a.ID, EncodeVector([]float32{1, 0, 0})); err != nil {
		t.Fatalf("insert embeddings_hnsw: %v", err)
	}

	if err := s.DeleteNode(ctx, a.ID); err != nil {
		t.Fatalf("DeleteNode with children: %v", err)
	}

	if _, err := s.GetNode(ctx, a.ID); err == nil {
		t.Error("node still present after DeleteNode")
	}
	for _, tbl := range []string{"edges", "embeddings", "embeddings_hnsw", "file_watch", "node_signatures", "node_versions", "node_metadata"} {
		var n int
		col := "node_id"
		if tbl == "edges" {
			col = "from_id"
		}
		if err := s.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM "+tbl+" WHERE "+col+"=?", a.ID).Scan(&n); err != nil {
			t.Fatalf("count %s: %v", tbl, err)
		}
		if n != 0 {
			t.Errorf("table %s still has %d rows for deleted node", tbl, n)
		}
	}

	// The other endpoint of the edge must survive untouched.
	if _, err := s.GetNode(ctx, b.ID); err != nil {
		t.Errorf("unrelated node b deleted: %v", err)
	}
}

// TestPerConnectionPragmas verifies the per-connection pragmas (synchronous,
// cache_size, temp_store, foreign_keys, recursive_triggers) are configured on
// EVERY pooled connection, not just the first one opened. Each open
// transaction pins a distinct connection, so holding MaxOpenOpenConns(5)
// transactions at once forces the checks below onto all five connections.
func TestPerConnectionPragmas(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	const pool = 5
	txs := make([]*sql.Tx, 0, pool)
	defer func() {
		for _, tx := range txs {
			_ = tx.Rollback()
		}
	}()
	for i := 0; i < pool; i++ {
		tx, err := s.db.BeginTx(ctx, nil)
		if err != nil {
			t.Fatalf("begin tx %d: %v", i, err)
		}
		txs = append(txs, tx)
	}

	checks := []struct {
		pragma string
		want   int
	}{
		{"synchronous", 1},        // NORMAL
		{"cache_size", -32768},    // 32MB
		{"temp_store", 2},         // MEMORY
		{"foreign_keys", 1},       // ON
		{"recursive_triggers", 1}, // ON
		{"wal_autocheckpoint", 1000},
	}
	for i, tx := range txs {
		for _, c := range checks {
			var got int
			if err := tx.QueryRowContext(ctx, "PRAGMA "+c.pragma).Scan(&got); err != nil {
				t.Fatalf("conn %d: PRAGMA %s: %v", i, c.pragma, err)
			}
			if got != c.want {
				t.Errorf("conn %d: PRAGMA %s = %d, want %d", i, c.pragma, got, c.want)
			}
		}
	}
}

// TestCountEdgesBatchChunks is a regression test for the missing chunking in
// CountEdgesBatch: it built a single IN (...) with every node ID, exceeding
// SQLite's host-parameter limit (maxSQLVariables = 900) for large ID sets.
// Edges deliberately span the chunk boundary and cross directions.
func TestCountEdgesBatchChunks(t *testing.T) {
	s, cleanup := setupStore(t)
	defer cleanup()
	ctx := context.Background()

	const total = maxSQLVariables + 50 // forces at least two chunks
	ids := make([]string, total)
	for i := 0; i < total; i++ {
		ids[i] = fmt.Sprintf("count-chunk-%d", i)
		if err := s.CreateNode(ctx, &Node{ID: ids[i], Type: "convention", Content: ids[i], ContentHash: "h" + ids[i], Scope: "project"}); err != nil {
			t.Fatalf("CreateNode(%s): %v", ids[i], err)
		}
	}
	// Outbound edges from the first node (chunk 1) to nodes in chunk 2, and
	// inbound edges into the last node from nodes in chunk 1.
	for i := maxSQLVariables - 2; i < maxSQLVariables+2; i++ {
		e := &Edge{ID: fmt.Sprintf("e-out-%d", i), FromID: ids[0], ToID: ids[i], Type: "relates"}
		if err := s.CreateEdge(ctx, e); err != nil {
			t.Fatalf("CreateEdge out %d: %v", i, err)
		}
		e2 := &Edge{ID: fmt.Sprintf("e-in-%d", i), FromID: ids[i], ToID: ids[total-1], Type: "relates"}
		if err := s.CreateEdge(ctx, e2); err != nil {
			t.Fatalf("CreateEdge in %d: %v", i, err)
		}
	}

	counts, err := s.CountEdgesBatch(ctx, ids)
	if err != nil {
		t.Fatalf("CountEdgesBatch with %d ids: %v", total, err)
	}
	if len(counts) != total {
		t.Fatalf("expected counts for %d nodes, got %d", total, len(counts))
	}
	if got := counts[ids[0]][1]; got != 4 {
		t.Errorf("first node outbound = %d, want 4", got)
	}
	if got := counts[ids[0]][0]; got != 0 {
		t.Errorf("first node inbound = %d, want 0", got)
	}
	if got := counts[ids[total-1]][0]; got != 4 {
		t.Errorf("last node inbound = %d, want 4", got)
	}
	if got := counts[ids[total-1]][1]; got != 0 {
		t.Errorf("last node outbound = %d, want 0", got)
	}
	if got := counts[ids[10]]; got != [2]int{0, 0} {
		t.Errorf("isolated node counts = %v, want zeros", got)
	}
}
