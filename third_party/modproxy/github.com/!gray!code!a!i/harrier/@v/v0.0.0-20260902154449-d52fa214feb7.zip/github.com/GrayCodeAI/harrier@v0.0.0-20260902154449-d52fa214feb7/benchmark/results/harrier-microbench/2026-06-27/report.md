# Harrier Microbenchmark Baseline

## Metadata

- Suite: `harrier-microbench`
- Date: `2026-06-27`
- Model: none
- Provider: none
- Commit: current workspace snapshot
- Command: `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./benchmark -bench=. -benchmem -benchtime=1x'`

## Headline Metrics

- Remember: `4.41ms/op`, `186496 B/op`, `1838 allocs/op`
- Recall: `3.74ms/op`, `248232 B/op`, `6639 allocs/op`
- RecallLargeGraph: `3.28ms/op`, `246336 B/op`, `6617 allocs/op`
- RecallEmptyQuery: `1.61ms/op`, `17608 B/op`, `483 allocs/op`
- Context: `1.69ms/op`, `56760 B/op`, `1453 allocs/op`
- GraphBFS: `2.88ms/op`, `7232 B/op`, `167 allocs/op`
- HNSWSearch: `584708 ns/op`, `66168 B/op`, `946 allocs/op`

## Notes

- This is the first committed repo-owned baseline artifact for `harrier-microbench`.
- The command used `-benchtime=1x` to generate a quick, single-iteration baseline suitable for a committed first snapshot.
- A fuller publication pass may also commit `-benchtime=1s` or longer stabilized runs later.

## Comparison Summary

- Previous baseline: none committed
- Change since baseline: initial published baseline
- Interpretation: the current engine is already in the low-single-digit millisecond range for major storage and recall operations on the local benchmark harness.
