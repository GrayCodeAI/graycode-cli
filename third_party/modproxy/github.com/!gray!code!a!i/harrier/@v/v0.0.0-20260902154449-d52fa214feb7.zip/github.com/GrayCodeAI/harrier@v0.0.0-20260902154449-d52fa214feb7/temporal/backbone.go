// Package temporal implements an immutable temporal backbone.
// Every memory node is auto-linked to the previous node in chronological order.
// Based on MAGMA's temporal graph and Zep's Graphiti temporal knowledge graph.
//
// The temporal backbone enables:
// - "When did we decide X?" → walk the timeline
// - "What happened before/after Y?" → traverse prev/next edges
// - Chronological ordering for session reconstruction
package temporal

import (
	"context"
	"log/slog"
	"sync"

	"github.com/GrayCodeAI/harrier/storage"
	"github.com/google/uuid"
)

// Backbone maintains the immutable temporal chain per project.
type Backbone struct {
	store    storage.Storage
	lastNode map[string]string // project → last node ID
	mu       sync.Mutex
}

func New(store storage.Storage) *Backbone {
	return &Backbone{store: store, lastNode: map[string]string{}}
}

// Link adds a node to the temporal backbone.
// Creates an immutable "next" edge from the previous node to this one.
// This edge is never modified or deleted — it's the ground truth timeline.
func (b *Backbone) Link(ctx context.Context, nodeID, project string) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	b.mu.Lock()
	prevID := b.lastNode[project]
	if prevID == "" {
		// On restart, recover the tail of the temporal chain from storage.
		prevID = b.recoverTail(ctx, project)
	}
	b.lastNode[project] = nodeID
	b.mu.Unlock()

	if prevID == "" || prevID == nodeID {
		// Persist tail even for the first node
		go b.persistTail(ctx, project, nodeID)
		return nil
	}

	err := b.store.CreateEdge(ctx, &storage.Edge{
		ID:      uuid.New().String(),
		FromID:  prevID,
		ToID:    nodeID,
		Type:    "learned_in",
		Acyclic: true,
		Weight:  1.0,
	})
	if err == nil {
		go b.persistTail(ctx, project, nodeID)
	}
	return err
}

// recoverTail finds the tail of the temporal chain. First checks for a
// persisted tail marker (O(1) lookup by key). Falls back to scanning only
// if the marker is missing (first run or migration).
func (b *Backbone) recoverTail(ctx context.Context, project string) string {
	// Fast path: look up persisted tail marker
	key := "_temporal_tail"
	if node, err := b.store.GetNodeByKey(ctx, key, project); err == nil && node != nil {
		return node.Content // content stores the tail node ID
	}

	// Slow path (migration): scan for the tail node
	nodes, err := b.store.ListNodes(ctx, storage.NodeFilter{Project: project})
	if err != nil || len(nodes) == 0 {
		return ""
	}
	for i := len(nodes) - 1; i >= 0; i-- {
		edges, _ := b.store.GetEdgesFrom(ctx, nodes[i].ID)
		hasOutgoing := false
		for _, e := range edges {
			if e.Type == "learned_in" {
				hasOutgoing = true
				break
			}
		}
		if !hasOutgoing {
			edgesTo, _ := b.store.GetEdgesTo(ctx, nodes[i].ID)
			for _, e := range edgesTo {
				if e.Type == "learned_in" {
					// Persist for next time
					b.persistTail(ctx, project, nodes[i].ID)
					return nodes[i].ID
				}
			}
		}
	}
	if len(nodes) > 0 {
		return nodes[len(nodes)-1].ID
	}
	return ""
}

// persistTail saves the tail node ID as a metadata node for O(1) recovery.
// It is best-effort (often invoked from a goroutine): failures degrade tail
// recovery to the slow scan path, so they are logged rather than propagated —
// but never silently discarded.
func (b *Backbone) persistTail(ctx context.Context, project, nodeID string) {
	key := "_temporal_tail"
	if existing, err := b.store.GetNodeByKey(ctx, key, project); err == nil && existing != nil {
		if uerr := b.store.UpdateNodeContent(ctx, existing.ID, nodeID); uerr != nil {
			slog.Warn("temporal: failed to update tail marker (recovery will fall back to scan)",
				"project", project, "marker_id", existing.ID, "tail_node_id", nodeID, "error", uerr)
		}
		return
	}
	if cerr := b.store.CreateNode(ctx, &storage.Node{
		ID:      uuid.New().String(),
		Type:    "meta",
		Content: nodeID,
		Key:     key,
		Project: project,
		Scope:   "system",
		Tier:    1,
	}); cerr != nil {
		slog.Warn("temporal: failed to create tail marker (recovery will fall back to scan)",
			"project", project, "tail_node_id", nodeID, "error", cerr)
	}
}

// Timeline returns nodes in chronological order for a project,
// walking the temporal backbone from the given start node.
func (b *Backbone) Timeline(ctx context.Context, startID string, direction string, limit int) ([]*storage.Node, error) {
	if limit <= 0 {
		limit = 20
	}

	var nodes []*storage.Node
	currentID := startID

	for i := 0; i < limit; i++ {
		node, err := b.store.GetNode(ctx, currentID)
		if err != nil {
			break
		}
		nodes = append(nodes, node)

		// Walk forward or backward
		var edges []*storage.Edge
		if direction == "forward" {
			edges, _ = b.store.GetEdgesFrom(ctx, currentID)
		} else {
			edges, _ = b.store.GetEdgesTo(ctx, currentID)
		}

		found := false
		for _, e := range edges {
			if e.Type == "learned_in" {
				if direction == "forward" {
					currentID = e.ToID
				} else {
					currentID = e.FromID
				}
				found = true
				break
			}
		}
		if !found {
			break
		}
	}
	return nodes, nil
}
