// Package ingest - semantic code chunker.
// Splits code files into meaningful chunks for memory and retrieval,
// using AST-based parsing for Go, indentation-based parsing for Python,
// regex-based parsing for TypeScript, and blank-line splitting as a fallback.
package ingest

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"path/filepath"
	"regexp"
	"strings"
)

// Chunk represents a semantically meaningful unit of code.
type Chunk struct {
	ID            string
	FilePath      string
	StartLine     int
	EndLine       int
	Content       string
	Type          string // "function", "class", "method", "import", "type", "const", "module"
	Name          string // symbol name
	Language      string
	TokenEstimate int
	ParentChunk   string // ID of parent (e.g., class for a method)
}

// Chunker splits source files into semantic chunks.
type Chunker struct {
	MaxChunkTokens int
	MinChunkTokens int
	OverlapLines   int
}

// NewChunker returns a Chunker with default settings.
func NewChunker() *Chunker {
	return &Chunker{
		MaxChunkTokens: 500,
		MinChunkTokens: 50,
		OverlapLines:   2,
	}
}

// ChunkFile detects the language from path extension and dispatches to
// the appropriate language-specific chunker. Falls back to generic line-based chunking.
func (c *Chunker) ChunkFile(path string, content string) ([]Chunk, error) {
	if content == "" {
		return nil, nil
	}

	lang := detectLanguage(path)
	var chunks []Chunk

	switch {
	case lang == "go":
		chunks = c.chunkGo(path, content)
	case lang == "python":
		chunks = c.chunkPython(path, content)
	case lang == "typescript" || lang == "javascript":
		chunks = c.chunkTypeScript(path, content)
	case isBraceLang(lang):
		// Brace-delimited C-family languages without a dedicated parser. Pure-Go
		// brace-block splitting keeps whole functions/types together — far better
		// than blank-line splitting, without pulling in CGO/tree-sitter. Ruby is
		// intentionally excluded (def/end, not brace-based) and stays generic.
		chunks = c.chunkBraceLang(path, content)
	default:
		chunks = c.chunkGeneric(path, content)
	}

	// Assign language and estimate tokens for all chunks
	for i := range chunks {
		chunks[i].Language = lang
		chunks[i].TokenEstimate = EstimateTokens(chunks[i].Content)
		if chunks[i].ID == "" {
			chunks[i].ID = chunkID(path, chunks[i].StartLine, chunks[i].EndLine)
		}
		chunks[i].FilePath = path
	}

	return chunks, nil
}

// chunkGo uses go/parser + go/ast to find function/type/const/var boundaries.
func (c *Chunker) chunkGo(path, content string) []Chunk {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, path, content, parser.ParseComments)
	if err != nil {
		// Fall back to generic if parsing fails
		return c.chunkGeneric(path, content)
	}

	lines := strings.Split(content, "\n")
	var chunks []Chunk

	// Import block
	for _, imp := range f.Imports {
		// We aggregate all imports into one chunk below
		_ = imp
	}
	if len(f.Imports) > 0 {
		startPos := fset.Position(f.Imports[0].Pos())
		endPos := fset.Position(f.Imports[len(f.Imports)-1].End())
		// Expand to include the "import (" line
		startLine := startPos.Line
		endLine := endPos.Line
		// Check if there's a grouped import statement
		for _, decl := range f.Decls {
			gd, ok := decl.(*ast.GenDecl)
			if ok && gd.Tok == token.IMPORT {
				sl := fset.Position(gd.Pos()).Line
				el := fset.Position(gd.End()).Line
				if sl < startLine {
					startLine = sl
				}
				if el > endLine {
					endLine = el
				}
			}
		}
		chunks = append(chunks, Chunk{
			StartLine: startLine,
			EndLine:   endLine,
			Content:   joinLines(lines, startLine, endLine),
			Type:      "import",
			Name:      "imports",
		})
	}

	// Process declarations
	for _, decl := range f.Decls {
		switch d := decl.(type) {
		case *ast.FuncDecl:
			startLine := fset.Position(d.Pos()).Line
			endLine := fset.Position(d.End()).Line
			name := d.Name.Name
			chunkType := "function"
			parentID := ""
			if d.Recv != nil && len(d.Recv.List) > 0 {
				chunkType = "method"
				// Extract receiver type name
				recvType := exprName(d.Recv.List[0].Type)
				if recvType != "" {
					parentID = chunkID(path, 0, 0) + ":" + recvType
					name = recvType + "." + name
				}
			}
			chunk := Chunk{
				StartLine:   startLine,
				EndLine:     endLine,
				Content:     joinLines(lines, startLine, endLine),
				Type:        chunkType,
				Name:        name,
				ParentChunk: parentID,
			}
			// Split if too large
			if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
				chunks = append(chunks, c.splitLargeChunk(chunk)...)
			} else {
				chunks = append(chunks, chunk)
			}

		case *ast.GenDecl:
			if d.Tok == token.IMPORT {
				continue // already handled
			}
			startLine := fset.Position(d.Pos()).Line
			endLine := fset.Position(d.End()).Line
			chunkType := "const"
			name := ""
			switch d.Tok {
			case token.TYPE:
				chunkType = "type"
				if len(d.Specs) > 0 {
					if ts, ok := d.Specs[0].(*ast.TypeSpec); ok {
						name = ts.Name.Name
					}
				}
			case token.CONST:
				chunkType = "const"
				if len(d.Specs) > 0 {
					if vs, ok := d.Specs[0].(*ast.ValueSpec); ok && len(vs.Names) > 0 {
						name = vs.Names[0].Name
					}
				}
			case token.VAR:
				chunkType = "const" // treat var blocks like const for chunking
				if len(d.Specs) > 0 {
					if vs, ok := d.Specs[0].(*ast.ValueSpec); ok && len(vs.Names) > 0 {
						name = vs.Names[0].Name
					}
				}
			}
			chunk := Chunk{
				StartLine: startLine,
				EndLine:   endLine,
				Content:   joinLines(lines, startLine, endLine),
				Type:      chunkType,
				Name:      name,
			}
			if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
				chunks = append(chunks, c.splitLargeChunk(chunk)...)
			} else {
				chunks = append(chunks, chunk)
			}
		}
	}

	if len(chunks) == 0 {
		return c.chunkGeneric(path, content)
	}
	return chunks
}

// chunkPython uses indentation-based parsing to find function/class boundaries.
func (c *Chunker) chunkPython(path, content string) []Chunk {
	lines := strings.Split(content, "\n")
	var chunks []Chunk

	// Collect imports at top
	importStart := -1
	importEnd := -1
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "import ") || strings.HasPrefix(trimmed, "from ") {
			if importStart == -1 {
				importStart = i
			}
			importEnd = i
		} else if trimmed != "" && trimmed != "#" && !strings.HasPrefix(trimmed, "#") && importStart != -1 {
			break
		}
	}
	if importStart != -1 {
		chunks = append(chunks, Chunk{
			StartLine: importStart + 1,
			EndLine:   importEnd + 1,
			Content:   joinLines(lines, importStart+1, importEnd+1),
			Type:      "import",
			Name:      "imports",
		})
	}

	// Find class and function definitions at module level (no indentation)
	type defBlock struct {
		startLine int
		endLine   int
		name      string
		kind      string // "class" or "function"
	}

	var blocks []defBlock
	defRe := regexp.MustCompile(`^(class|def)\s+(\w+)`)

	i := 0
	for i < len(lines) {
		line := lines[i]
		if m := defRe.FindStringSubmatch(line); m != nil {
			kind := m[1]
			name := m[2]
			chunkType := "function"
			if kind == "class" {
				chunkType = "class"
			}
			startLine := i + 1
			endLine := i + 1

			// Find the end of this block (next unindented non-empty line or EOF)
			j := i + 1
			for j < len(lines) {
				l := lines[j]
				if l == "" || strings.HasPrefix(l, " ") || strings.HasPrefix(l, "\t") {
					endLine = j + 1
					j++
					continue
				}
				// Check if it's a decorator for the next def
				if strings.HasPrefix(strings.TrimSpace(l), "@") {
					break
				}
				// Another top-level def/class
				if defRe.MatchString(l) {
					break
				}
				// Some other top-level code — still part of block? No, break.
				break
			}

			blocks = append(blocks, defBlock{
				startLine: startLine,
				endLine:   endLine,
				name:      name,
				kind:      chunkType,
			})
			i = j
		} else {
			i++
		}
	}

	// Convert blocks to chunks
	for _, b := range blocks {
		chunk := Chunk{
			StartLine: b.startLine,
			EndLine:   b.endLine,
			Content:   joinLines(lines, b.startLine, b.endLine),
			Type:      b.kind,
			Name:      b.name,
		}

		// If class is too large, split into methods
		if b.kind == "class" && EstimateTokens(chunk.Content) > c.MaxChunkTokens {
			methodChunks := c.splitPythonClass(path, lines, b.startLine, b.endLine, b.name)
			if len(methodChunks) > 0 {
				chunks = append(chunks, methodChunks...)
				continue
			}
		}

		if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
			chunks = append(chunks, c.splitLargeChunk(chunk)...)
		} else {
			chunks = append(chunks, chunk)
		}
	}

	if len(chunks) == 0 {
		return c.chunkGeneric(path, content)
	}
	return chunks
}

// splitPythonClass splits a Python class into its methods.
func (c *Chunker) splitPythonClass(path string, lines []string, startLine, endLine int, className string) []Chunk {
	var chunks []Chunk
	methodRe := regexp.MustCompile(`^\s+def\s+(\w+)`)
	parentID := chunkID(path, startLine, endLine)

	// Add class header (class line + any class-level code before first method)
	headerEnd := startLine
	for i := startLine; i < endLine; i++ {
		if methodRe.MatchString(lines[i]) {
			break
		}
		headerEnd = i + 1
	}
	if headerEnd > startLine {
		chunks = append(chunks, Chunk{
			StartLine:   startLine,
			EndLine:     headerEnd,
			Content:     joinLines(lines, startLine, headerEnd),
			Type:        "class",
			Name:        className,
			ParentChunk: "",
		})
	}

	// Find methods
	i := startLine - 1 // 0-indexed
	for i < endLine-1 {
		line := lines[i]
		if m := methodRe.FindStringSubmatch(line); m != nil {
			methodName := m[1]
			methodStart := i + 1 // 1-indexed
			methodEnd := i + 1
			indent := len(line) - len(strings.TrimLeft(line, " \t"))

			j := i + 1
			for j < endLine-1 {
				l := lines[j]
				if l == "" {
					methodEnd = j + 1
					j++
					continue
				}
				currIndent := len(l) - len(strings.TrimLeft(l, " \t"))
				if currIndent <= indent && strings.TrimSpace(l) != "" {
					break
				}
				methodEnd = j + 1
				j++
			}

			chunks = append(chunks, Chunk{
				StartLine:   methodStart,
				EndLine:     methodEnd,
				Content:     joinLines(lines, methodStart, methodEnd),
				Type:        "method",
				Name:        className + "." + methodName,
				ParentChunk: parentID,
			})
			i = j
		} else {
			i++
		}
	}

	return chunks
}

// chunkTypeScript uses regex-based parsing for TypeScript/JavaScript files.
func (c *Chunker) chunkTypeScript(path, content string) []Chunk {
	lines := strings.Split(content, "\n")
	var chunks []Chunk

	// Collect imports at top
	importStart := -1
	importEnd := -1
	inMultiLineImport := false
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "import ") || inMultiLineImport {
			if importStart == -1 {
				importStart = i
			}
			importEnd = i
			if strings.Contains(line, "{") && !strings.Contains(line, "}") {
				inMultiLineImport = true
			}
			if inMultiLineImport && strings.Contains(line, "}") {
				inMultiLineImport = false
			}
		} else if importStart != -1 && trimmed != "" {
			break
		}
	}
	if importStart != -1 {
		chunks = append(chunks, Chunk{
			StartLine: importStart + 1,
			EndLine:   importEnd + 1,
			Content:   joinLines(lines, importStart+1, importEnd+1),
			Type:      "import",
			Name:      "imports",
		})
	}

	// Patterns for TypeScript declarations
	patterns := []struct {
		re        *regexp.Regexp
		chunkType string
	}{
		{regexp.MustCompile(`^(?:export\s+)?(?:async\s+)?function\s+(\w+)`), "function"},
		{regexp.MustCompile(`^(?:export\s+)?class\s+(\w+)`), "class"},
		{regexp.MustCompile(`^(?:export\s+)?interface\s+(\w+)`), "type"},
		{regexp.MustCompile(`^(?:export\s+)?type\s+(\w+)`), "type"},
		{regexp.MustCompile(`^(?:export\s+)?(?:const|let|var)\s+(\w+)`), "const"},
		{regexp.MustCompile(`^(?:export\s+)?enum\s+(\w+)`), "type"},
	}

	i := 0
	for i < len(lines) {
		line := lines[i]
		trimmed := strings.TrimSpace(line)

		matched := false
		for _, p := range patterns {
			if m := p.re.FindStringSubmatch(trimmed); m != nil {
				name := m[1]
				startLine := i + 1
				endLine := findBlockEnd(lines, i)

				chunk := Chunk{
					StartLine: startLine,
					EndLine:   endLine,
					Content:   joinLines(lines, startLine, endLine),
					Type:      p.chunkType,
					Name:      name,
				}

				// If class is too large, split into methods
				if p.chunkType == "class" && EstimateTokens(chunk.Content) > c.MaxChunkTokens {
					methodChunks := c.splitTSClass(path, lines, startLine, endLine, name)
					if len(methodChunks) > 0 {
						chunks = append(chunks, methodChunks...)
						i = endLine
						matched = true
						break
					}
				}

				if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
					chunks = append(chunks, c.splitLargeChunk(chunk)...)
				} else {
					chunks = append(chunks, chunk)
				}
				i = endLine
				matched = true
				break
			}
		}
		if !matched {
			i++
		}
	}

	if len(chunks) == 0 {
		return c.chunkGeneric(path, content)
	}
	return chunks
}

// splitTSClass splits a TypeScript class into its methods.
func (c *Chunker) splitTSClass(path string, lines []string, startLine, endLine int, className string) []Chunk {
	var chunks []Chunk
	parentID := chunkID(path, startLine, endLine)
	methodRe := regexp.MustCompile(`^\s+(?:(?:public|private|protected|static|async|readonly)\s+)*(\w+)\s*\(`)

	i := startLine - 1 // 0-indexed
	for i < endLine-1 {
		line := lines[i]
		if m := methodRe.FindStringSubmatch(line); m != nil {
			methodName := m[1]
			// Skip constructors named as keywords
			methodStart := i + 1
			methodEnd := findBlockEnd(lines, i)
			if methodEnd > endLine {
				methodEnd = endLine
			}

			chunks = append(chunks, Chunk{
				StartLine:   methodStart,
				EndLine:     methodEnd,
				Content:     joinLines(lines, methodStart, methodEnd),
				Type:        "method",
				Name:        className + "." + methodName,
				ParentChunk: parentID,
			})
			i = methodEnd
		} else {
			i++
		}
	}

	return chunks
}

// braceDeclRe matches a top-level declaration that introduces a brace block in a
// C-family language (Rust, Java, C, C++, C#, Kotlin, Swift, Scala, etc.). It is
// deliberately language-agnostic: rather than enumerate keywords per language, it
// recognizes a top-level (column-0) signature line and captures the declared
// name. It does NOT require the opening "{" on the same line — chunkBraceLang
// scans forward for it — so Allman-brace styles ("public class Foo\n{") are
// handled as well as K&R ("public class Foo {").
//
// Each leading keyword may carry an immediately-attached generic/lifetime group
// ("impl<'a>"), and a free-standing "<...>" group is also skipped, so the captured
// name is always the declared type or function — never a lifetime like 'a or a
// generic param. The trailing portion tolerates generic args, parameter lists,
// return types, base lists, and where-clauses up to the brace or line end.
// Examples it catches: "pub fn foo()", "impl Bar", "impl<'a> Foo<'a>",
// "impl<'a, T> Wrapper<'a, T>", "public class Baz", "struct Point",
// "namespace app", "func compute() -> Int", "fun greet(): String" (Kotlin),
// "object Util" (Scala).
var braceDeclRe = regexp.MustCompile(`^(?:[A-Za-z_]\w*(?:<[^>]*>)?\s+)*(?:<[^>]*>\s*)*\b([A-Za-z_]\w*)\b\s*(?:<[^>]*>)?\s*(?:\([^;{]*\)?)?[^;{]*$`)

// braceLangExts lists the source extensions whose languages are brace-delimited
// and routed to chunkBraceLang. Kept beside the regex so the set of languages we
// claim to support and the set we actually route stay in sync.
var braceLangExts = map[string]string{
	".rs":   "rust",
	".java": "java",
	".c":    "c",
	".h":    "c",
	".cpp":  "cpp", ".cc": "cpp", ".cxx": "cpp", ".c++": "cpp",
	".hpp": "cpp", ".hh": "cpp", ".hxx": "cpp", ".h++": "cpp",
	".ipp": "cpp", ".tcc": "cpp", ".cppm": "cpp",
	".cs": "csharp",
	".kt": "kotlin", ".kts": "kotlin",
	".swift": "swift",
	".scala": "scala",
}

// maxBraceLookahead bounds how many lines past a signature chunkBraceLang scans
// for the opening brace before giving up (handles Allman style and multi-line
// signatures without letting an unmatched signature swallow the file).
const maxBraceLookahead = 4

// chunkBraceLang chunks brace-delimited C-family languages that have no dedicated
// parser, by splitting at top-level brace blocks. It is a pure-Go fallback (no
// CGO / tree-sitter): far better than blank-line splitting because it keeps whole
// functions/types/impl-blocks together, but it does not build a real AST.
// Languages with a dedicated chunker (Go, Python, TS/JS) never reach here. Falls
// back to chunkGeneric when no top-level block is found.
func (c *Chunker) chunkBraceLang(path, content string) []Chunk {
	lines := strings.Split(content, "\n")
	var chunks []Chunk

	i := 0
	for i < len(lines) {
		line := lines[i]
		// Only treat column-0 (non-indented) lines as top-level declarations, so
		// nested blocks stay inside their parent chunk.
		if line != "" && !strings.HasPrefix(line, " ") && !strings.HasPrefix(line, "\t") && !strings.HasPrefix(strings.TrimSpace(line), "//") {
			if name, braceLine, ok := matchBraceDecl(lines, i); ok {
				startLine := i + 1
				endLine := findBlockEnd(lines, braceLine)
				chunk := Chunk{
					StartLine: startLine,
					EndLine:   endLine,
					Content:   joinLines(lines, startLine, endLine),
					Type:      "block",
					Name:      name,
				}
				if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
					chunks = append(chunks, c.splitLargeChunk(chunk)...)
				} else {
					chunks = append(chunks, chunk)
				}
				if endLine > i {
					i = endLine
				} else {
					i++
				}
				continue
			}
		}
		i++
	}

	if len(chunks) == 0 {
		return c.chunkGeneric(path, content)
	}
	return chunks
}

// matchBraceDecl decides whether the line at index i begins a top-level brace
// block. It returns the declared name and the index of the line carrying the
// opening "{". The brace may be on the signature line (K&R) or on one of the next
// few lines (Allman / wrapped signatures). A statement terminated by ";" before
// any "{" (e.g. a forward declaration or field) is not a block and is rejected.
func matchBraceDecl(lines []string, i int) (name string, braceLine int, ok bool) {
	first := lines[i]
	// The signature line itself must not contain a ";" before a "{" (that would be
	// a statement, not a block opener).
	if semi := strings.IndexByte(first, ';'); semi >= 0 {
		if brace := strings.IndexByte(first, '{'); brace < 0 || semi < brace {
			return "", 0, false
		}
	}

	// Match the name on the signature line, allowing the part before "{" only.
	sig := first
	if brace := strings.IndexByte(first, '{'); brace >= 0 {
		sig = first[:brace]
	}
	m := braceDeclRe.FindStringSubmatch(strings.TrimRight(sig, " \t"))
	if m == nil {
		return "", 0, false
	}

	// Find the opening brace: on this line, or within the lookahead window.
	if strings.ContainsRune(first, '{') {
		return m[1], i, true
	}
	for j := i + 1; j < len(lines) && j <= i+maxBraceLookahead; j++ {
		l := strings.TrimSpace(lines[j])
		if l == "" {
			continue
		}
		if strings.HasPrefix(l, "{") {
			return m[1], j, true
		}
		// A ";" or a new column-0 declaration before any brace means this was not
		// a block (e.g. an abstract method or a field), so reject.
		if strings.Contains(l, ";") || strings.Contains(l, "{") {
			return "", 0, false
		}
	}
	return "", 0, false
}

// chunkGeneric falls back to splitting at blank line boundaries.
func (c *Chunker) chunkGeneric(path, content string) []Chunk {
	lines := strings.Split(content, "\n")
	var chunks []Chunk

	blockStart := 0
	for i := 0; i <= len(lines); i++ {
		isBlank := i == len(lines) || strings.TrimSpace(lines[i]) == ""
		if isBlank && i > blockStart {
			blockContent := joinLines(lines, blockStart+1, i)
			if strings.TrimSpace(blockContent) != "" {
				chunk := Chunk{
					StartLine: blockStart + 1,
					EndLine:   i,
					Content:   blockContent,
					Type:      "module",
					Name:      "",
				}
				if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
					chunks = append(chunks, c.splitLargeChunk(chunk)...)
				} else {
					chunks = append(chunks, chunk)
				}
			}
			blockStart = i + 1
		} else if isBlank {
			blockStart = i + 1
		}
	}

	// Handle trailing content without a trailing blank line
	if blockStart < len(lines) {
		blockContent := joinLines(lines, blockStart+1, len(lines))
		if strings.TrimSpace(blockContent) != "" {
			chunk := Chunk{
				StartLine: blockStart + 1,
				EndLine:   len(lines),
				Content:   blockContent,
				Type:      "module",
				Name:      "",
			}
			if EstimateTokens(chunk.Content) > c.MaxChunkTokens {
				chunks = append(chunks, c.splitLargeChunk(chunk)...)
			} else {
				chunks = append(chunks, chunk)
			}
		}
	}

	return chunks
}

// MergeSmallChunks combines adjacent small chunks (< MinChunkTokens) into larger ones,
// respecting type boundaries (don't merge a function into an import).
func (c *Chunker) MergeSmallChunks(chunks []Chunk) []Chunk {
	if len(chunks) <= 1 {
		return chunks
	}

	var merged []Chunk
	i := 0
	for i < len(chunks) {
		current := chunks[i]
		if current.TokenEstimate >= c.MinChunkTokens {
			merged = append(merged, current)
			i++
			continue
		}

		// Try to merge with subsequent small chunks of the same type
		j := i + 1
		for j < len(chunks) && chunks[j].TokenEstimate < c.MinChunkTokens && chunks[j].Type == current.Type {
			// Merge chunks[j] into current
			current.EndLine = chunks[j].EndLine
			current.Content = current.Content + "\n" + chunks[j].Content
			current.TokenEstimate = EstimateTokens(current.Content)
			if current.Name == "" {
				current.Name = chunks[j].Name
			} else if chunks[j].Name != "" {
				current.Name = current.Name + "+" + chunks[j].Name
			}
			current.ID = chunkID(current.FilePath, current.StartLine, current.EndLine)
			j++

			// Stop merging if we've reached the max
			if current.TokenEstimate >= c.MaxChunkTokens {
				break
			}
		}
		merged = append(merged, current)
		i = j
	}

	return merged
}

// AddOverlap adds lines of overlap from the previous chunk to the start of each chunk.
func (c *Chunker) AddOverlap(chunks []Chunk, overlapLines int) []Chunk {
	if overlapLines <= 0 || len(chunks) <= 1 {
		return chunks
	}

	result := make([]Chunk, len(chunks))
	result[0] = chunks[0]

	for i := 1; i < len(chunks); i++ {
		prev := chunks[i-1]
		curr := chunks[i]

		prevLines := strings.Split(prev.Content, "\n")
		overlapStart := len(prevLines) - overlapLines
		if overlapStart < 0 {
			overlapStart = 0
		}
		overlap := strings.Join(prevLines[overlapStart:], "\n")

		curr.Content = overlap + "\n" + curr.Content
		curr.StartLine -= overlapLines
		if curr.StartLine < 1 {
			curr.StartLine = 1
		}
		curr.TokenEstimate = EstimateTokens(curr.Content)
		curr.ID = chunkID(curr.FilePath, curr.StartLine, curr.EndLine)
		result[i] = curr
	}

	return result
}

// EstimateTokens returns the estimated token count for the given text.
// Uses a local BPE-first estimator to avoid engine-to-engine coupling on tok
// while preserving the old chunking behavior closely.
func EstimateTokens(content string) int {
	return estimateTokens(content)
}

// splitLargeChunk splits a chunk that exceeds MaxChunkTokens into smaller pieces.
func (c *Chunker) splitLargeChunk(chunk Chunk) []Chunk {
	lines := strings.Split(chunk.Content, "\n")
	maxLines := (c.MaxChunkTokens * 4) / avgLineLen(lines)
	if maxLines < 5 {
		maxLines = 5
	}

	var chunks []Chunk
	for start := 0; start < len(lines); start += maxLines {
		end := start + maxLines
		if end > len(lines) {
			end = len(lines)
		}
		subContent := strings.Join(lines[start:end], "\n")
		subChunk := Chunk{
			StartLine:   chunk.StartLine + start,
			EndLine:     chunk.StartLine + end - 1,
			Content:     subContent,
			Type:        chunk.Type,
			Name:        chunk.Name,
			ParentChunk: chunk.ParentChunk,
			FilePath:    chunk.FilePath,
		}
		subChunk.ID = chunkID(subChunk.FilePath, subChunk.StartLine, subChunk.EndLine)
		subChunk.TokenEstimate = EstimateTokens(subContent)
		chunks = append(chunks, subChunk)
	}
	return chunks
}

// --- Helpers ---

// detectLanguage returns the language name based on file extension.
func detectLanguage(path string) string {
	ext := strings.ToLower(filepath.Ext(path))
	switch ext {
	case ".go":
		return "go"
	case ".py":
		return "python"
	case ".ts", ".tsx":
		return "typescript"
	case ".js", ".jsx", ".mjs", ".cjs":
		return "javascript"
	case ".rb":
		// Ruby is def/end-delimited, not brace-based, so it uses the generic
		// fallback rather than chunkBraceLang.
		return "ruby"
	}
	// Brace-delimited C-family languages share a single chunker; their extensions
	// live in braceLangExts so the regex's claimed coverage and the routing table
	// cannot drift apart.
	if lang, ok := braceLangExts[ext]; ok {
		return lang
	}
	return "generic"
}

// isBraceLang reports whether lang is a brace-delimited language routed to
// chunkBraceLang.
func isBraceLang(lang string) bool {
	switch lang {
	case "rust", "java", "c", "cpp", "csharp", "kotlin", "swift", "scala":
		return true
	default:
		return false
	}
}

// chunkID generates a deterministic ID from file path and line range.
func chunkID(path string, startLine, endLine int) string {
	data := fmt.Sprintf("%s:%d:%d", path, startLine, endLine)
	h := sha256.Sum256([]byte(data))
	return hex.EncodeToString(h[:16])
}

// joinLines joins lines[startLine-1:endLine] (1-indexed, inclusive).
func joinLines(lines []string, startLine, endLine int) string {
	if startLine < 1 {
		startLine = 1
	}
	if endLine > len(lines) {
		endLine = len(lines)
	}
	if startLine > endLine {
		return ""
	}
	return strings.Join(lines[startLine-1:endLine], "\n")
}

// findBlockEnd finds the end of a brace-delimited block starting at line index i.
// For single-line declarations without braces (e.g. type aliases), returns the next line.
func findBlockEnd(lines []string, i int) int {
	braceCount := 0
	started := false

	// First check: if the starting line has no opening brace, this may be a
	// single-line declaration (e.g., "export type Foo = ...;"). In that case,
	// scan only until the statement ends (semicolon or next blank line).
	firstLine := lines[i]
	if !strings.Contains(firstLine, "{") {
		// Single-line or multi-line declaration without braces.
		// Look for the end: semicolon on this line, or next blank line.
		if strings.HasSuffix(strings.TrimSpace(firstLine), ";") {
			return i + 1
		}
		for j := i + 1; j < len(lines); j++ {
			trimmed := strings.TrimSpace(lines[j])
			if trimmed == "" {
				return j
			}
			if strings.HasSuffix(trimmed, ";") {
				return j + 1
			}
			// If we encounter an opening brace, fall through to brace matching
			if strings.Contains(lines[j], "{") {
				break
			}
		}
	}

	for j := i; j < len(lines); j++ {
		line := lines[j]
		for _, ch := range line {
			switch ch {
			case '{':
				braceCount++
				started = true
			case '}':
				braceCount--
			}
		}
		if started && braceCount <= 0 {
			return j + 1 // 1-indexed end
		}
	}
	// If no matching brace found, find next blank line or end of file
	for j := i + 1; j < len(lines); j++ {
		if strings.TrimSpace(lines[j]) == "" {
			return j
		}
	}
	return len(lines)
}

// exprName extracts the name from a Go AST expression (for receiver types).
func exprName(expr ast.Expr) string {
	switch t := expr.(type) {
	case *ast.Ident:
		return t.Name
	case *ast.StarExpr:
		return exprName(t.X)
	case *ast.IndexExpr:
		return exprName(t.X)
	default:
		return ""
	}
}

// avgLineLen returns the average line length in bytes.
func avgLineLen(lines []string) int {
	if len(lines) == 0 {
		return 40
	}
	total := 0
	for _, l := range lines {
		total += len(l)
	}
	avg := total / len(lines)
	if avg < 10 {
		return 10
	}
	return avg
}
