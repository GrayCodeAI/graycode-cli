package storage

import (
	"strings"
	"testing"
)

func TestBehaviorTracker_Track(t *testing.T) {
	bt := NewBehaviorTracker()

	bt.Track("run tests", "before commit")
	bt.Track("run tests", "before commit")
	bt.Track("format code", "before commit")

	if len(bt.behaviors) != 2 {
		t.Fatalf("expected 2 behaviors, got %d", len(bt.behaviors))
	}

	var runTests Behavior
	for _, b := range bt.behaviors {
		if b.Pattern == "run tests" {
			runTests = b
			break
		}
	}
	if runTests.Frequency != 2 {
		t.Errorf("expected frequency 2 for 'run tests', got %d", runTests.Frequency)
	}
	if runTests.Context != "before commit" {
		t.Errorf("expected context 'before commit', got %q", runTests.Context)
	}
}

func TestBehaviorTracker_Predict(t *testing.T) {
	bt := NewBehaviorTracker()

	bt.Track("run tests", "before commit")
	bt.Track("run tests", "before commit")
	bt.Track("run tests", "before commit")
	bt.Track("format code", "before commit")
	bt.Track("deploy", "after merge")

	predictions := bt.Predict("before commit")
	if len(predictions) != 2 {
		t.Fatalf("expected 2 predictions for 'before commit', got %d", len(predictions))
	}
	// "run tests" has higher frequency so should be first.
	if predictions[0].Pattern != "run tests" {
		t.Errorf("expected first prediction to be 'run tests', got %q", predictions[0].Pattern)
	}

	// Different context should not return "before commit" behaviors.
	afterMerge := bt.Predict("after merge")
	if len(afterMerge) != 1 {
		t.Fatalf("expected 1 prediction for 'after merge', got %d", len(afterMerge))
	}
	if afterMerge[0].Pattern != "deploy" {
		t.Errorf("expected 'deploy', got %q", afterMerge[0].Pattern)
	}
}

func TestBehaviorTracker_GetTopPatterns(t *testing.T) {
	bt := NewBehaviorTracker()

	bt.Track("action-a", "ctx1")
	bt.Track("action-a", "ctx1")
	bt.Track("action-a", "ctx1")
	bt.Track("action-b", "ctx2")
	bt.Track("action-b", "ctx2")
	bt.Track("action-c", "ctx3")

	top := bt.GetTopPatterns(2)
	if len(top) != 2 {
		t.Fatalf("expected 2 top patterns, got %d", len(top))
	}
	if top[0].Pattern != "action-a" {
		t.Errorf("expected top pattern 'action-a', got %q", top[0].Pattern)
	}
	if top[1].Pattern != "action-b" {
		t.Errorf("expected second pattern 'action-b', got %q", top[1].Pattern)
	}

	// Requesting more than available should return all.
	all := bt.GetTopPatterns(100)
	if len(all) != 3 {
		t.Errorf("expected 3 patterns, got %d", len(all))
	}
}

func TestFormatPredictions(t *testing.T) {
	predictions := []Behavior{
		{Pattern: "run tests", Frequency: 5, Confidence: 0.85, Context: "before commit"},
		{Pattern: "lint", Frequency: 2, Confidence: 0.5, Context: "before commit"},
	}

	result := FormatPredictions(predictions)
	if !strings.Contains(result, "run tests") {
		t.Error("expected output to contain 'run tests'")
	}
	if !strings.Contains(result, "lint") {
		t.Error("expected output to contain 'lint'")
	}

	empty := FormatPredictions(nil)
	if empty != "No predictions available." {
		t.Errorf("unexpected empty output: %q", empty)
	}
}

func TestBehaviorTracker_ConfidenceGrows(t *testing.T) {
	bt := NewBehaviorTracker()

	bt.Track("action", "ctx")
	conf1 := bt.behaviors[0].Confidence

	bt.Track("action", "ctx")
	conf2 := bt.behaviors[0].Confidence

	if conf2 <= conf1 {
		t.Errorf("expected confidence to grow with frequency, got %f then %f", conf1, conf2)
	}
}
