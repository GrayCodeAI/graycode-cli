package engine

import (
	"testing"
)

func TestBloomFilter_BasicOps(t *testing.T) {
	t.Parallel()
	bf := NewBloomFilter(1000, 0.01)

	bf.Add("authentication")
	bf.Add("jwt")
	bf.Add("postgresql")

	if !bf.MayContain("authentication") {
		t.Error("bloom filter should contain 'authentication'")
	}
	if !bf.MayContain("jwt") {
		t.Error("bloom filter should contain 'jwt'")
	}
	if !bf.MayContain("postgresql") {
		t.Error("bloom filter should contain 'postgresql'")
	}

	// This term was never added — should likely return false (with very low FP chance)
	if bf.MayContain("xyzzynonexistent123") {
		t.Log("unexpected potential false positive (acceptable at low rate)")
	}
}

func TestBloomFilter_MayContainAny(t *testing.T) {
	t.Parallel()
	bf := NewBloomFilter(1000, 0.01)
	bf.Add("jose")
	bf.Add("jsonwebtoken")
	bf.Add("auth")

	if !bf.MayContainAny("what jose library") {
		t.Error("should match 'jose' in query")
	}
	if !bf.MayContainAny("auth middleware") {
		t.Error("should match 'auth' in query")
	}
}

func TestBloomFilter_AddTerms(t *testing.T) {
	t.Parallel()
	bf := NewBloomFilter(1000, 0.01)
	bf.AddTerms("Use jose library for JWT authentication in auth.ts")

	if !bf.MayContain("jose") {
		t.Error("should contain 'jose' after AddTerms")
	}
	if !bf.MayContain("authentication") {
		t.Error("should contain 'authentication' after AddTerms")
	}
	if bf.Count() != 1 {
		t.Errorf("Count = %d, want 1 (one AddTerms call)", bf.Count())
	}
}

func TestBloomFilter_FalsePositiveRate(t *testing.T) {
	t.Parallel()
	bf := NewBloomFilter(1000, 0.01)

	// Add 100 items
	for i := 0; i < 100; i++ {
		bf.Add(string(rune('a'+i%26)) + string(rune('0'+i%10)) + "term")
	}

	fpr := bf.FalsePositiveRate()
	if fpr > 0.05 {
		t.Errorf("FP rate too high: %f (expected < 0.05 at 10%% fill)", fpr)
	}
}

func TestBloomFilter_EmptyFilter(t *testing.T) {
	t.Parallel()
	bf := NewBloomFilter(100, 0.01)

	if bf.MayContain("anything") {
		t.Error("empty filter should return false for everything")
	}
	if bf.Count() != 0 {
		t.Error("empty filter count should be 0")
	}
}

func TestTokenize(t *testing.T) {
	t.Parallel()
	tests := []struct {
		input string
		want  int // minimum number of tokens expected
	}{
		{"Use jose for JWT", 2},      // "use" is 3 chars, "jose", "for" is 3 chars, "jwt" is 3 chars
		{"a b c", 0},                 // all too short
		{"authentication system", 2}, // both are long enough
		{"go_build_command", 1},      // underscore-connected treated as one
	}

	for _, tt := range tests {
		tokens := tokenize(tt.input)
		if len(tokens) < tt.want {
			t.Errorf("tokenize(%q) = %d tokens, want >= %d. Got: %v", tt.input, len(tokens), tt.want, tokens)
		}
	}
}
