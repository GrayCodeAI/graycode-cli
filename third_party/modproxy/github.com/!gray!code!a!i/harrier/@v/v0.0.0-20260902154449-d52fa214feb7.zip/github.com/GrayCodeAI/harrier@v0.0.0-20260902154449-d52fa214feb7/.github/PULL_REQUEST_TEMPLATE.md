<!--
  Thanks for your contribution! Please fill out this template so reviewers can
  understand the change quickly. Anything that does not apply can be left in
  place; do not delete unanswered sections — write "n/a".
-->

## Summary

<!--
  One paragraph describing what this PR does and why. Link the related
  issue(s) with `Fixes #N` or `Refs #N` if applicable.
-->

## Changes

<!--
  Bullet list of what changed, grouped by area (engine, storage, graph,
  ingest, embeddings, MCP/REST server, CLI, SDK, CI, docs). Reviewers
  should be able to skim this and know what to look at first.
-->

-

## Memory / retrieval-quality impact

<!--
  Does this affect ranking, recall, decay, compaction, conflict resolution,
  or graph structure? Paste before/after numbers from `make bench` or any
  fused-recall fixture. If irrelevant, write "n/a".
-->

## Schema / data-format impact

<!--
  Does this change `storage/sqlite.go`, the embeddings layout, or the
  exported memory format? Migrations must be reversible and tested. If no
  schema change, write "n/a".
-->

## Testing

<!--
  Describe how you tested. Paste output of `make test` and `make lint`.
  If you added new tests, list them. Note any flaky tests you encountered.
-->

```text
$ make test
...
$ make lint
...
```

## Checklist

- [ ] Commits follow [Conventional Commits](https://www.conventionalcommits.org/)
      (`feat:`, `fix:`, `perf:`, `refactor:`, `docs:`, `test:`, etc.)
- [ ] `make build` passes
- [ ] `make lint` passes (no new lint findings, no `nolint:…` without justification)
- [ ] `make test` passes locally with `-race` enabled
- [ ] New or changed code has tests (table-driven where appropriate)
- [ ] Public APIs have godoc comments
- [ ] `CHANGELOG.md` updated under `## [Unreleased]` if user-visible
- [ ] OpenAPI / SDK type changes are reflected in `openapi.yaml`,
      `sdk/python/`, and `sdk/typescript/` together
- [ ] No regression in retrieval quality on the standard fixtures
- [ ] No secrets, tokens, or PII added to the repo (especially not
      `.harrier/integrity.key`)
- [ ] No `Co-authored-by:` trailers (this is individual-developer work)
