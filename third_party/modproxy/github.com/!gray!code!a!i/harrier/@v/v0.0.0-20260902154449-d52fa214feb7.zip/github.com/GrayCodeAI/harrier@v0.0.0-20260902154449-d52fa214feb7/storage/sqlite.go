// Package storage is harrier's persistence layer: a CGO-free SQLite store with
// FTS5 search, prepared-statement caching, and busy-retry, plus the Storage
// interface the rest of the system depends on.
package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	sqlite3 "modernc.org/sqlite"
	sqlite3lib "modernc.org/sqlite/lib"
)

// Note: node, edge, and transaction storage operations were moved
// verbatim into sqlite_nodes.go, sqlite_edges.go, and sqlite_tx.go for
// readability. This file keeps shared infra (schema, busy-retry, stmt
// cache, sessions, file-watch, and scan helpers).

// isSQLITEBusy reports whether err wraps an SQLITE_BUSY (code 5) error.
//
// It type-asserts the driver's *sqlite.Error rather than matching on the error
// string, so a future driver release that rewords the message cannot silently
// disable retries. The low byte of the result code is compared because SQLite
// busy variants (e.g. SQLITE_BUSY_SNAPSHOT = 261) share the primary code 5. A
// string check is retained only as a last-resort fallback for wrapped errors
// that lose the concrete type.
func isSQLITEBusy(err error) bool {
	if err == nil {
		return false
	}
	var se *sqlite3.Error
	if errors.As(err, &se) {
		code := se.Code()
		return code == sqlite3lib.SQLITE_BUSY ||
			code == sqlite3lib.SQLITE_LOCKED ||
			code&0xFF == sqlite3lib.SQLITE_BUSY ||
			code&0xFF == sqlite3lib.SQLITE_LOCKED
	}
	return strings.Contains(err.Error(), "SQLITE_BUSY") || strings.Contains(err.Error(), "database is locked")
}

// retryOnBusy retries fn up to maxRetries times when it returns an
// SQLITE_BUSY error, using exponential back-off starting at baseDelay.
// Non-busy errors are returned immediately.
func retryOnBusy(fn func() error, maxRetries int, baseDelay time.Duration) error {
	var err error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		err = fn()
		if !isSQLITEBusy(err) {
			return err
		}
		if attempt < maxRetries {
			delay := baseDelay * (1 << attempt) // exponential back-off
			time.Sleep(delay)
		}
	}
	return err
}

// retryOnBusyVal is like retryOnBusy but for functions returning (T, error).
func retryOnBusyVal[T any](fn func() (T, error), maxRetries int, baseDelay time.Duration) (T, error) {
	var zero T
	var val T
	var err error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		val, err = fn()
		if !isSQLITEBusy(err) {
			return val, err
		}
		if attempt < maxRetries {
			delay := baseDelay * (1 << attempt)
			time.Sleep(delay)
		}
	}
	return zero, err
}

// Types

// Node represents a memory node in the Harrier graph.
type Node struct {
	ID, Type, Content, ContentHash, Summary, Scope, Project, Tags string
	Key                                                           string // optional unique key per project (upsert semantics)
	Pinned                                                        bool   // pinned nodes always appear in context
	Tier                                                          int
	Confidence                                                    float64
	AccessCount                                                   int
	CreatedAt, UpdatedAt, AccessedAt                              time.Time
	SourceSession, SourceAgent                                    string
	Version                                                       int
	Metadata                                                      map[string]string // structured key-value metadata (stored in node_metadata table)
}

// Edge represents a relationship between two nodes in the graph.
type Edge struct {
	ID, FromID, ToID, Type, Metadata string
	Acyclic                          bool
	Weight                           float64
	ValidAt                          time.Time // when the fact became true (zero = since creation)
	InvalidAt                        time.Time // when the fact stopped being true (zero = still valid)
	CreatedAt                        time.Time
}

// Session tracks a session.
type Session struct {
	ID, Project, Summary, Agent string
	StartedAt, EndedAt          time.Time
}

// NodeVersion stores a historical version of a node for audit/rollback.
type NodeVersion struct {
	NodeID, Content, ChangedBy, Reason string
	Version                            int
	ChangedAt                          time.Time
}

// NodeFilter specifies criteria for listing nodes.
type NodeFilter struct {
	Type, Scope, Project string
	Tier                 int
	MinConfidence        float64
	SourceSession        string
	Pinned               *bool             // filter by pinned status (nil = no filter)
	Tag                  string            // exact tag match within the CSV tags column (delimiter-aware)
	MetadataFilters      map[string]string // key-value metadata filters (all must match, AND semantics)
	Limit                int               // max results (0 = default 1000)
	Offset               int               // skip first N results (for pagination)
}

// queryable abstracts *sql.DB and *sql.Tx so shared query logic is written once.
type queryable interface {
	QueryContext(ctx context.Context, query string, args ...interface{}) (*sql.Rows, error)
	QueryRowContext(ctx context.Context, query string, args ...interface{}) *sql.Row
	ExecContext(ctx context.Context, query string, args ...interface{}) (sql.Result, error)
}

// stmtCache is a queryable that wraps a *sql.DB and lazily prepares + reuses a
// *sql.Stmt per distinct SQL string. database/sql transparently re-prepares a
// cached statement on whichever pooled connection serves a call, so a single
// *sql.Stmt is safe for concurrent use across the pool. This removes the
// per-call SQL re-parse on the hot read/write paths (GetNode, dedup lookup,
// CreateNode/Edge, LogAccess, BM25 search), which previously recompiled their
// SQL on every Recall/Remember.
//
// Only the non-transactional *Store path uses this cache. The txStore path
// keeps using the raw *sql.Tx: a pooled *sql.Stmt runs on its own connection,
// not the transaction's, so caching there would silently execute outside the
// tx. Dynamic-placeholder queries (IN-clauses whose SQL varies by argument
// count) produce a distinct cache entry per shape, which is bounded in practice
// and still correct.
type stmtCache struct {
	db    *sql.DB
	mu    sync.RWMutex
	stmts map[string]*sql.Stmt
}

func newStmtCache(db *sql.DB) *stmtCache {
	return &stmtCache{db: db, stmts: make(map[string]*sql.Stmt)}
}

// prepare returns a cached *sql.Stmt for query, preparing it once on first use.
// On preparation failure it returns nil; callers fall back to the raw db so a
// transient prepare error never breaks a query.
func (c *stmtCache) prepare(ctx context.Context, query string) *sql.Stmt {
	c.mu.RLock()
	st := c.stmts[query]
	c.mu.RUnlock()
	if st != nil {
		return st
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if cached := c.stmts[query]; cached != nil { // re-check after acquiring write lock
		return cached
	}
	st, err := c.db.PrepareContext(ctx, query)
	if err != nil {
		return nil
	}
	c.stmts[query] = st
	return st
}

func (c *stmtCache) QueryContext(ctx context.Context, query string, args ...interface{}) (*sql.Rows, error) {
	if st := c.prepare(ctx, query); st != nil {
		return st.QueryContext(ctx, args...)
	}
	return c.db.QueryContext(ctx, query, args...)
}

func (c *stmtCache) QueryRowContext(ctx context.Context, query string, args ...interface{}) *sql.Row {
	if st := c.prepare(ctx, query); st != nil {
		return st.QueryRowContext(ctx, args...)
	}
	return c.db.QueryRowContext(ctx, query, args...)
}

func (c *stmtCache) ExecContext(ctx context.Context, query string, args ...interface{}) (sql.Result, error) {
	if st := c.prepare(ctx, query); st != nil {
		return st.ExecContext(ctx, args...)
	}
	return c.db.ExecContext(ctx, query, args...)
}

// close releases all prepared statements. Safe to call once at Store shutdown.
func (c *stmtCache) close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	var firstErr error
	for k, st := range c.stmts {
		if err := st.Close(); err != nil && firstErr == nil {
			firstErr = err
		}
		delete(c.stmts, k)
	}
	return firstErr
}

// Store

// Store is the SQLite-backed storage layer for Harrier.
const defaultBusyTimeoutMs = 30000

type Store struct {
	db           *sql.DB
	dbPath       string
	cache        *stmtCache
	queryTimeout time.Duration
	processLock  *ProcessLock
	hnswMu       sync.Mutex
	hnswIndexes  map[string]*HNSWIndex // keyed by embedding model

	cipherMu   sync.RWMutex
	nodeCipher *NodeCipher // nil until EnableEncryption; guards progressive activation
}

// EnableEncryption activates at-rest encryption of node content/summary using
// keys from the given provider. Call it right after NewStore, before any
// reads, so no plaintext can be served by the API once writes start
// encrypting. It is idempotent: the first call wins; later calls are no-ops.
func (s *Store) EnableEncryption(p KeyProvider) error {
	c, err := NewNodeCipher(p)
	if err != nil {
		return err
	}
	s.cipherMu.Lock()
	defer s.cipherMu.Unlock()
	if s.nodeCipher == nil {
		s.nodeCipher = c
	}
	return nil
}

// cipher returns the active node cipher, or nil when encryption is disabled.
func (s *Store) cipher() *NodeCipher {
	s.cipherMu.RLock()
	defer s.cipherMu.RUnlock()
	return s.nodeCipher
}

// DB returns the underlying database connection for direct queries.
func (s *Store) DB() *sql.DB { return s.db }

func NewStore(dbPath string) (*Store, error) {
	// The store holds personal/agent memory content, so its directory and
	// files must not be group/world-readable regardless of the process
	// umask. In-memory DSNs (":memory:", "file::memory:...") have no
	// directory to create or file to lock down.
	if !isMemoryDSN(dbPath) {
		if dir := filepath.Dir(dbPath); dir != "" && dir != "." {
			if err := os.MkdirAll(dir, 0o700); err != nil {
				return nil, fmt.Errorf("create db directory: %w", err)
			}
		}
	}

	// modernc.org/sqlite v1.34.4 only processes _pragma query parameters
	// (unlike mattn/go-sqlite3 which accepts _busy_timeout, _journal_mode,
	// and _foreign_keys as top-level keys). Without this fix, these DSN
	// parameters were silently ignored — the database was not in WAL mode
	// and the busy timeout was effectively 0, causing all SQLITE_BUSY
	// failures the audit fixes had worked around.
	//
	// The driver applies every _pragma parameter on EACH new pooled
	// connection (driver applyQueryParams), which is where per-connection
	// settings must live: synchronous, temp_store, cache_size, mmap_size,
	// wal_autocheckpoint, and recursive_triggers issued once through
	// db.ExecContext would only configure whichever single connection
	// happened to serve that call, leaving the rest of the pool (5 conns)
	// on defaults. page_size is deliberately absent: it cannot change after
	// the database file is created. PRAGMA optimize runs at Close instead
	// (it is designed to run near connection close, not at startup).
	pragmas := []string{
		"journal_mode(WAL)",
		"foreign_keys(ON)",
		fmt.Sprintf("busy_timeout(%d)", defaultBusyTimeoutMs),
		"synchronous(NORMAL)",
		"wal_autocheckpoint(1000)",
		"temp_store(MEMORY)",
		"mmap_size(268435456)", // 256MB
		"cache_size(-32768)",   // 32MB
		"recursive_triggers(ON)",
	}
	dsn := dbPath + "?_pragma=" + strings.Join(pragmas, "&_pragma=")
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, err
	}
	if err := db.PingContext(context.Background()); err != nil {
		return nil, err
	}
	if !isMemoryDSN(dbPath) {
		// Ping (and the WAL pragma above) may have just created the db/-wal/-shm
		// files under the process umask (commonly 0644); tighten them to owner-only.
		for _, suffix := range []string{"", "-wal", "-shm"} {
			if err := os.Chmod(dbPath+suffix, 0o600); err != nil && !os.IsNotExist(err) {
				return nil, fmt.Errorf("restrict db file permissions: %w", err)
			}
		}
	}
	// WAL mode supports concurrent readers alongside a single writer.
	// A small pool (5) allows concurrent read operations while _busy_timeout
	// handles brief write contention. WAL mode ensures readers never block.
	db.SetMaxOpenConns(5)
	db.SetMaxIdleConns(5)
	s := &Store{db: db, dbPath: dbPath, queryTimeout: 30 * time.Second, hnswIndexes: make(map[string]*HNSWIndex)}
	if err := s.createTables(); err != nil {
		return nil, err
	}
	// Run migrations (idempotent, forward-only)
	if err := s.Migrate(context.Background()); err != nil {
		return nil, err
	}
	// Integrity check (fail fast on corruption)
	if !isMemoryDSN(dbPath) {
		var integrity string
		err := s.db.QueryRowContext(context.Background(), "PRAGMA integrity_check").Scan(&integrity)
		if err != nil || integrity != "ok" {
			return nil, fmt.Errorf("integrity check failed: %s", integrity)
		}
	}
	// Cross-process advisory lock
	lock, err := AcquireProcessLock(dbPath)
	if err != nil {
		return nil, err
	}
	s.processLock = lock
	// Prepared-statement cache is created after table creation so DDL runs on
	// the raw connection. Hot read/write helpers query through s.cache.
	s.cache = newStmtCache(db)
	return s, nil
}

// isMemoryDSN reports whether dbPath refers to an in-memory SQLite database
// (no on-disk file/directory to create or lock down).
func isMemoryDSN(dbPath string) bool {
	return dbPath == ":memory:" || strings.HasPrefix(dbPath, "file::memory:")
}

// withTimeout returns a child context with the store's query timeout applied.
// If the parent context already has a shorter deadline, it is returned unchanged.
func (s *Store) withTimeout(ctx context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, s.queryTimeout)
}

func (s *Store) Close() error {
	if s.cache != nil {
		_ = s.cache.close() // best-effort; closing the db below frees statements anyway
	}
	// PRAGMA optimize updates SQLite's internal statistics so future queries
	// pick good plans; it is designed to run near connection close, not at
	// startup. It only reaches one pooled connection here, which matches the
	// documented best-effort usage. Errors are ignored on the shutdown path.
	_, _ = s.db.ExecContext(context.Background(), "PRAGMA optimize")
	if s.processLock != nil {
		_ = s.processLock.Release()
	}
	return s.db.Close()
}

// q returns the queryable used for non-transactional reads/writes: the
// prepared-statement cache when available, falling back to the raw db.
func (s *Store) q() queryable {
	if s.cache != nil {
		return s.cache
	}
	return s.db
}

// SearchNodeByHash finds a node by content hash + scope + project (dedup check).
// Returns (nil, nil) when not found — used for dedup checks where "not found" is not an error.
// SearchNodeByHash looks up a node by content hash within a scope/project.
// Returns (nil, nil) when no matching node is found (dedup check pattern).
func (s *Store) SearchNodeByHash(ctx context.Context, hash, scope, project string) (*Node, error) {
	return retryOnBusyVal(func() (*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return searchNodeByHashQ(ctx, s.q(), hash, scope, project, s.cipher())
	}, 5, 50*time.Millisecond)
}

func searchNodeByHashQ(ctx context.Context, q queryable, hash, scope, project string, c *NodeCipher) (*Node, error) {
	n := &Node{}
	var at sql.NullTime
	var key sql.NullString
	err := q.QueryRowContext(ctx,
		`SELECT id,type,content,content_hash,summary,scope,project,tier,tags,key,pinned,confidence,
		access_count,created_at,updated_at,accessed_at,source_session,source_agent,version
		FROM nodes WHERE content_hash=? AND scope=? AND (project=? OR project IS NULL) LIMIT 1`,
		hash, scope, project).Scan(&n.ID, &n.Type, &n.Content, &n.ContentHash, &n.Summary, &n.Scope, &n.Project,
		&n.Tier, &n.Tags, &key, &n.Pinned, &n.Confidence, &n.AccessCount, &n.CreatedAt, &n.UpdatedAt, &at,
		&n.SourceSession, &n.SourceAgent, &n.Version)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	if at.Valid {
		n.AccessedAt = at.Time
	}
	if key.Valid {
		n.Key = key.String
	}
	if err := decryptNodeInplace(n, c); err != nil {
		return nil, err
	}
	return n, nil
}

func (s *Store) createTables() error {
	// Create schema_version table if it doesn't exist
	_, err := s.db.ExecContext(context.Background(), `
		CREATE TABLE IF NOT EXISTS schema_version (
			version INTEGER NOT NULL
		);
	`)
	if err != nil {
		return fmt.Errorf("failed to create schema_version table: %w", err)
	}

	// Apply initial schema (migration 1) if not already applied
	var currentVersion int
	err = s.db.QueryRowContext(context.Background(), "SELECT COALESCE(MAX(version), 0) FROM schema_version").Scan(&currentVersion)
	if err != nil && err != sql.ErrNoRows {
		return fmt.Errorf("failed to read schema version: %w", err)
	}

	if currentVersion == 0 {
		if _, err := s.db.ExecContext(context.Background(), schema); err != nil {
			return fmt.Errorf("failed to apply initial schema: %w", err)
		}
		if _, err := s.db.ExecContext(context.Background(), "INSERT INTO schema_version (version) VALUES (1)"); err != nil {
			return fmt.Errorf("failed to set schema version: %w", err)
		}
	}

	return nil
}

const schema = `
CREATE TABLE IF NOT EXISTS nodes (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  content TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  summary TEXT,
  scope TEXT NOT NULL,
  project TEXT,
  tier INTEGER DEFAULT 2,
  tags TEXT,
  key TEXT,
  pinned BOOLEAN DEFAULT 0,
  confidence REAL DEFAULT 1.0,
  access_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  accessed_at DATETIME,
  source_session TEXT,
  source_agent TEXT,
  version INTEGER DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_nodes_hash ON nodes(content_hash, scope, project);
CREATE UNIQUE INDEX IF NOT EXISTS idx_nodes_key ON nodes(key, project) WHERE key IS NOT NULL AND key != '';
CREATE INDEX IF NOT EXISTS idx_nodes_project ON nodes(project);
CREATE INDEX IF NOT EXISTS idx_nodes_project_type ON nodes(project, type);
CREATE INDEX IF NOT EXISTS idx_nodes_tier ON nodes(tier);
CREATE INDEX IF NOT EXISTS idx_nodes_pinned ON nodes(pinned) WHERE pinned = 1;
CREATE INDEX IF NOT EXISTS idx_nodes_confidence ON nodes(confidence);
CREATE INDEX IF NOT EXISTS idx_nodes_accessed ON nodes(accessed_at);

CREATE TABLE IF NOT EXISTS edges (
  id TEXT PRIMARY KEY,
  from_id TEXT NOT NULL,
  to_id TEXT NOT NULL,
  type TEXT NOT NULL,
  acyclic BOOLEAN NOT NULL,
  weight REAL DEFAULT 1.0,
  metadata TEXT,
  valid_at DATETIME,
  invalid_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (from_id) REFERENCES nodes(id),
  FOREIGN KEY (to_id) REFERENCES nodes(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_edges_unique ON edges(from_id, to_id, type);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_id);
CREATE INDEX IF NOT EXISTS idx_edges_to ON edges(to_id);
CREATE INDEX IF NOT EXISTS idx_edges_acyclic ON edges(acyclic, from_id, to_id);
CREATE INDEX IF NOT EXISTS idx_edges_validity ON edges(valid_at, invalid_at);
CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(type);

CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(content, summary, tags, content=nodes, content_rowid=rowid);

CREATE TABLE IF NOT EXISTS embeddings (
  node_id TEXT PRIMARY KEY,
  vector BLOB,
  model TEXT,
  FOREIGN KEY (node_id) REFERENCES nodes(id)
);

CREATE TABLE IF NOT EXISTS embeddings_hnsw (
  node_id TEXT PRIMARY KEY,
  vector BLOB,
  model TEXT,
  neighbors TEXT,
  updated_at DATETIME,
  FOREIGN KEY (node_id) REFERENCES embeddings(node_id)
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  project TEXT,
  started_at DATETIME,
  ended_at DATETIME,
  summary TEXT,
  agent TEXT
);

CREATE TABLE IF NOT EXISTS file_watch (
  file_path TEXT,
  node_id TEXT,
  git_hash TEXT,
  FOREIGN KEY (node_id) REFERENCES nodes(id)
);
CREATE INDEX IF NOT EXISTS idx_file_watch_path ON file_watch(file_path);

CREATE TABLE IF NOT EXISTS node_versions (
  node_id TEXT,
  version INTEGER,
  content TEXT,
  changed_at DATETIME,
  changed_by TEXT,
  reason TEXT,
  PRIMARY KEY (node_id, version)
);

CREATE TABLE IF NOT EXISTS replay_events (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  data       TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_replay_session ON replay_events(session_id);

CREATE TABLE IF NOT EXISTS access_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  node_id    TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_access_log_node ON access_log(node_id);

CREATE TABLE IF NOT EXISTS node_signatures (
  node_id   TEXT PRIMARY KEY,
  signature TEXT NOT NULL,
  signed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (node_id) REFERENCES nodes(id)
);

-- FTS5 triggers
CREATE TRIGGER IF NOT EXISTS nodes_ai AFTER INSERT ON nodes BEGIN
  INSERT INTO nodes_fts(rowid, content, summary, tags) VALUES (new.rowid, new.content, new.summary, new.tags);
END;
CREATE TRIGGER IF NOT EXISTS nodes_au AFTER UPDATE ON nodes BEGIN
  INSERT INTO nodes_fts(nodes_fts, rowid, content, summary, tags) VALUES ('delete', old.rowid, old.content, old.summary, old.tags);
  INSERT INTO nodes_fts(rowid, content, summary, tags) VALUES (new.rowid, new.content, new.summary, new.tags);
END;
CREATE TRIGGER IF NOT EXISTS nodes_ad AFTER DELETE ON nodes BEGIN
  INSERT INTO nodes_fts(nodes_fts, rowid, content, summary, tags) VALUES ('delete', old.rowid, old.content, old.summary, old.tags);
END;
`

// --- Sessions ---

func (s *Store) CreateSession(ctx context.Context, sess *Session) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return createSessionQ(ctx, s.q(), sess)
	}, 5, 50*time.Millisecond)
}

func createSessionQ(ctx context.Context, q queryable, sess *Session) error {
	_, err := q.ExecContext(ctx, `INSERT INTO sessions (id, project, started_at, ended_at, summary, agent) VALUES (?, ?, ?, ?, ?, ?)`,
		sess.ID, sess.Project, sess.StartedAt, nullTime(sess.EndedAt), sess.Summary, sess.Agent)
	return err
}

func (s *Store) EndSession(ctx context.Context, id string, summary string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return endSessionQ(ctx, s.q(), id, summary)
	}, 5, 50*time.Millisecond)
}

func endSessionQ(ctx context.Context, q queryable, id string, summary string) error {
	_, err := q.ExecContext(ctx, `UPDATE sessions SET ended_at=?, summary=? WHERE id=?`, time.Now().UTC(), summary, id)
	return err
}

func (s *Store) ListSessions(ctx context.Context, project string, limit int) ([]*Session, error) {
	return retryOnBusyVal(func() ([]*Session, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return listSessionsQ(ctx, s.q(), project, limit)
	}, 5, 50*time.Millisecond)
}

func listSessionsQ(ctx context.Context, q queryable, project string, limit int) ([]*Session, error) {
	if limit <= 0 {
		limit = 10
	}
	query := "SELECT id, project, started_at, ended_at, summary, agent FROM sessions"
	var args []any
	if project != "" {
		query += " WHERE project=?"
		args = append(args, project)
	}
	query += " ORDER BY started_at DESC LIMIT ?"
	args = append(args, limit)
	rows, err := q.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	var out []*Session
	for rows.Next() {
		sess := &Session{}
		var endedAt sql.NullTime
		if err := rows.Scan(&sess.ID, &sess.Project, &sess.StartedAt, &endedAt, &sess.Summary, &sess.Agent); err != nil {
			return nil, err
		}
		if endedAt.Valid {
			sess.EndedAt = endedAt.Time
		}
		out = append(out, sess)
	}
	return out, rows.Err()
}

// --- File Watch ---

func (s *Store) AddFileWatch(ctx context.Context, filePath, nodeID, gitHash string) error {
	return retryOnBusy(func() error {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		return addFileWatchQ(ctx, s.q(), filePath, nodeID, gitHash)
	}, 5, 50*time.Millisecond)
}

func addFileWatchQ(ctx context.Context, q queryable, filePath, nodeID, gitHash string) error {
	_, err := q.ExecContext(ctx, `INSERT INTO file_watch (file_path, node_id, git_hash) VALUES (?, ?, ?)`, filePath, nodeID, gitHash)
	return err
}

func (s *Store) GetNodesByFile(ctx context.Context, filePath string) ([]*Node, error) {
	return retryOnBusyVal(func() ([]*Node, error) {
		ctx, cancel := s.withTimeout(ctx)
		defer cancel()
		rows, err := s.db.QueryContext(ctx, `SELECT n.id, n.type, n.content, n.content_hash, n.summary, n.scope, n.project, n.tier, n.tags, n.key, n.pinned, n.confidence, n.access_count, n.created_at, n.updated_at, n.accessed_at, n.source_session, n.source_agent, n.version
			FROM nodes n JOIN file_watch fw ON fw.node_id = n.id WHERE fw.file_path = ?`, filePath)
		if err != nil {
			return nil, err
		}
		defer func() { _ = rows.Close() }()
		return scanNodes(rows, s.cipher())
	}, 5, 50*time.Millisecond)
}

// --- Helpers ---

func nullTime(t time.Time) sql.NullTime {
	if t.IsZero() {
		return sql.NullTime{}
	}
	return sql.NullTime{Time: t, Valid: true}
}

func nullString(s string) sql.NullString {
	if s == "" {
		return sql.NullString{}
	}
	return sql.NullString{String: s, Valid: true}
}

func scanNodes(rows *sql.Rows, c *NodeCipher) ([]*Node, error) {
	var out []*Node
	for rows.Next() {
		n := &Node{}
		var accessedAt sql.NullTime
		var key sql.NullString
		if err := rows.Scan(&n.ID, &n.Type, &n.Content, &n.ContentHash, &n.Summary, &n.Scope, &n.Project, &n.Tier, &n.Tags, &key, &n.Pinned, &n.Confidence, &n.AccessCount, &n.CreatedAt, &n.UpdatedAt, &accessedAt, &n.SourceSession, &n.SourceAgent, &n.Version); err != nil {
			return nil, err
		}
		if accessedAt.Valid {
			n.AccessedAt = accessedAt.Time
		}
		if key.Valid {
			n.Key = key.String
		}
		if err := decryptNodeInplace(n, c); err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

func scanEdges(rows *sql.Rows) ([]*Edge, error) {
	var out []*Edge
	for rows.Next() {
		e := &Edge{}
		var validAt, invalidAt sql.NullTime
		if err := rows.Scan(&e.ID, &e.FromID, &e.ToID, &e.Type, &e.Acyclic, &e.Weight, &e.Metadata, &validAt, &invalidAt, &e.CreatedAt); err != nil {
			return nil, err
		}
		if validAt.Valid {
			e.ValidAt = validAt.Time
		}
		if invalidAt.Valid {
			e.InvalidAt = invalidAt.Time
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// maxSQLVariables is the maximum number of SQLite host parameters per query.
// SQLite default is 999; we stay well under it for safety.
const maxSQLVariables = 900
