// Package telemetry provides OpenTelemetry metric instruments for harrier.
//
// All instruments are created lazily on first use via the global Meter.
// If no OTel exporter is configured, the default no-op implementation is used
// (zero overhead). To export metrics, configure an OTel SDK MeterProvider
// before calling any harrier functions.
package telemetry

import (
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/metric"
)

const meterName = "github.com/GrayCodeAI/harrier"

var meter = otel.Meter(meterName)

// ---------------------------------------------------------------------------
// HTTP server metrics
// ---------------------------------------------------------------------------

// HTTPRequestDuration records the latency of HTTP requests, labelled by
// method, path, and status code.
var HTTPRequestDuration, _ = meter.Float64Histogram(
	"harrier.http.request.duration",
	metric.WithDescription("HTTP request duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10),
)

// HTTPRequestCount counts total HTTP requests, labelled by method, path, and
// status code.
var HTTPRequestCount, _ = meter.Int64Counter(
	"harrier.http.request.count",
	metric.WithDescription("Total HTTP requests"),
	metric.WithUnit("{request}"),
)

// ---------------------------------------------------------------------------
// Engine / memory-operation metrics
// ---------------------------------------------------------------------------

// MemoryRememberDuration records how long Remember takes (save operation).
var MemoryRememberDuration, _ = meter.Float64Histogram(
	"harrier.memory.remember.duration",
	metric.WithDescription("Memory Remember (save) operation duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5),
)

// MemoryRecallDuration records how long Recall (search) takes.
var MemoryRecallDuration, _ = meter.Float64Histogram(
	"harrier.memory.recall.duration",
	metric.WithDescription("Memory Recall (search) operation duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5),
)

// MemoryRetrieveDuration records how long single-node retrieval takes (GetNode).
var MemoryRetrieveDuration, _ = meter.Float64Histogram(
	"harrier.memory.retrieve.duration",
	metric.WithDescription("Memory Retrieve (GetNode) operation duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1),
)

// MemoryFusedRecallDuration records how long FusedRecall takes.
var MemoryFusedRecallDuration, _ = meter.Float64Histogram(
	"harrier.memory.fused_recall.duration",
	metric.WithDescription("Memory FusedRecall (multi-signal search) duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5),
)

// ---------------------------------------------------------------------------
// SQLite storage metrics
// ---------------------------------------------------------------------------

// SQLiteQueryDuration records individual SQLite query latency.
var SQLiteQueryDuration, _ = meter.Float64Histogram(
	"harrier.sqlite.query.duration",
	metric.WithDescription("SQLite query duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1),
)

// SQLiteQueryCount counts SQLite queries, labelled by operation name.
var SQLiteQueryCount, _ = meter.Int64Counter(
	"harrier.sqlite.query.count",
	metric.WithDescription("Total SQLite queries executed"),
	metric.WithUnit("{query}"),
)

// ---------------------------------------------------------------------------
// HNSW vector-index metrics
// ---------------------------------------------------------------------------

// HNSWSearchDuration records HNSW nearest-neighbour search latency.
var HNSWSearchDuration, _ = meter.Float64Histogram(
	"harrier.hnsw.search.duration",
	metric.WithDescription("HNSW approximate nearest-neighbor search duration in seconds"),
	metric.WithUnit("s"),
	metric.WithExplicitBucketBoundaries(0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5),
)

// HNSWSearchCount counts HNSW searches.
var HNSWSearchCount, _ = meter.Int64Counter(
	"harrier.hnsw.search.count",
	metric.WithDescription("Total HNSW searches performed"),
	metric.WithUnit("{search}"),
)
