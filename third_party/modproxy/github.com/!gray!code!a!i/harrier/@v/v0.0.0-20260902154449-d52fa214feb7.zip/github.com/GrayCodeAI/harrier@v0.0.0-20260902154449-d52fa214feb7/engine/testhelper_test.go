package engine

import (
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/harrier/storage"
)

// setupTestStore creates a temporary SQLite store for testing.
func setupTestStore(t *testing.T) *storage.Store {
	t.Helper()
	dir := t.TempDir()
	dbPath := filepath.Join(dir, "test.db")
	store, err := storage.NewStore(dbPath)
	if err != nil {
		t.Fatalf("failed to create test store: %v", err)
	}
	return store
}
