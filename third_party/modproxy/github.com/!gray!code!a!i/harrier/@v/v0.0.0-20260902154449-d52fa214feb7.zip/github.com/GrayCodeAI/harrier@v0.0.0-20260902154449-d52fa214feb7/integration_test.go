//go:build integration

//nolint:noctx
package harrier_test

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/GrayCodeAI/harrier/embeddings"
	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/exportimport"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/hooks"
	"github.com/GrayCodeAI/harrier/storage"
)

func setup(t *testing.T) (*engine.Engine, func()) {
	t.Helper()
	dir := t.TempDir()
	store, err := storage.NewStore(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatal(err)
	}
	eng := engine.New(store, graph.New(store, store.DB()))
	return eng, func() { store.Close(); os.RemoveAll(dir) }
}

func TestRememberRecallContext(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// --- Remember ---
	nodes := []engine.RememberInput{
		{Type: "convention", Content: "Use jose not jsonwebtoken for Edge compatibility", Scope: "project"},
		{Type: "decision", Content: "Chose RS256 over HS256 for JWT compliance", Scope: "project"},
		{Type: "bug", Content: "Token refresh race: use mutex in src/middleware/auth.ts", Scope: "project", Tags: "auth"},
		{Type: "task", Content: "Add rate limiting to /auth/token", Scope: "project"},
	}
	var ids []string
	for _, in := range nodes {
		n, err := eng.Remember(context.Background(), in)
		if err != nil {
			t.Fatalf("Remember(%q): %v", in.Content, err)
		}
		ids = append(ids, n.ID)
	}
	if len(ids) != 4 {
		t.Fatalf("expected 4 nodes, got %d", len(ids))
	}

	// --- Dedup: same content returns same ID ---
	n2, err := eng.Remember(context.Background(), engine.RememberInput{
		Type: "convention", Content: "Use jose not jsonwebtoken for Edge compatibility", Scope: "project",
	})
	if err != nil {
		t.Fatal(err)
	}
	if n2.ID != ids[0] {
		t.Errorf("dedup failed: expected id %s, got %s", ids[0], n2.ID)
	}

	// --- Recall ---
	result, err := eng.Recall(context.Background(), engine.RecallOpts{Query: "auth JWT", Depth: 2, Limit: 10})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Nodes) == 0 {
		t.Error("recall returned no nodes")
	}
	// Should find the bug and decision nodes
	found := map[string]bool{}
	for _, n := range result.Nodes {
		found[n.Type] = true
	}
	if !found["bug"] && !found["decision"] {
		t.Errorf("recall missing expected types, got: %v", found)
	}

	// --- Context (hot tier) ---
	ctx, err := eng.Context(context.Background(), "")
	if err != nil {
		t.Fatal(err)
	}
	// Hot tier should include convention (tier=1) and task (tier=1)
	hotTypes := map[string]bool{}
	for _, n := range ctx.Nodes {
		hotTypes[n.Type] = true
	}
	if !hotTypes["convention"] {
		t.Errorf("context missing convention nodes, got: %v", hotTypes)
	}
	if !hotTypes["task"] {
		t.Errorf("context missing task nodes, got: %v", hotTypes)
	}

	// --- Forget ---
	if err := eng.Forget(context.Background(), ids[3]); err != nil {
		t.Fatal(err)
	}
	forgotten, _ := eng.Store().GetNode(context.Background(), ids[3])
	if forgotten.Confidence != 0 {
		t.Errorf("forget: expected confidence=0, got %f", forgotten.Confidence)
	}
}

func TestGraphLinkAndSubgraph(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	a, err := eng.Remember(context.Background(), engine.RememberInput{Type: "decision", Content: "Use NATS for event bus", Scope: "project"})
	if err != nil {
		t.Fatalf("Remember(a): %v", err)
	}
	b, err := eng.Remember(context.Background(), engine.RememberInput{Type: "convention", Content: "Use NATS client v2", Scope: "project"})
	if err != nil {
		t.Fatalf("Remember(b): %v", err)
	}

	// Link: decision led_to convention
	err = eng.Graph().AddEdge(context.Background(), &storage.Edge{
		ID: "e1", FromID: a.ID, ToID: b.ID, Type: "led_to", Weight: 1.0,
	})
	if err != nil {
		t.Fatalf("AddEdge: %v", err)
	}

	// Subgraph from decision should include convention
	sg, err := eng.Graph().ExtractSubgraph(context.Background(), a.ID, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(sg.Nodes) < 2 {
		t.Errorf("subgraph: expected ≥2 nodes, got %d", len(sg.Nodes))
	}

	// Cycle detection: led_to is acyclic — b→a should fail
	err = eng.Graph().AddEdge(context.Background(), &storage.Edge{
		ID: "e2", FromID: b.ID, ToID: a.ID, Type: "led_to", Weight: 1.0,
	})
	if err == nil {
		t.Error("cycle detection failed: should have rejected b→a led_to edge")
	}

	// relates_to allows cycles
	err = eng.Graph().AddEdge(context.Background(), &storage.Edge{
		ID: "e3", FromID: b.ID, ToID: a.ID, Type: "relates_to", Weight: 1.0,
	})
	if err != nil {
		t.Errorf("relates_to cycle should be allowed: %v", err)
	}
}

func TestPhase3EmbeddingsAndHybridSearch(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	// Store some nodes
	nodes := []engine.RememberInput{
		{Type: "convention", Content: "Use jose not jsonwebtoken", Scope: "project"},
		{Type: "decision", Content: "Chose RS256 for JWT compliance", Scope: "project"},
		{Type: "bug", Content: "Token refresh race in auth middleware", Scope: "project"},
	}
	for _, in := range nodes {
		eng.Remember(context.Background(), in)
	}

	// Embed all nodes with local stub provider
	provider := embeddings.NewLocal()
	allNodes, _ := eng.Store().ListNodes(context.Background(), storage.NodeFilter{})
	for _, n := range allNodes {
		vec, err := provider.Embed(context.Background(), n.Content)
		if err != nil {
			t.Fatalf("Embed: %v", err)
		}
		if err := eng.Store().SaveEmbedding(context.Background(), n.ID, provider.Name(), vec); err != nil {
			t.Fatalf("SaveEmbedding: %v", err)
		}
	}

	// Verify embeddings stored
	embs, err := eng.Store().AllEmbeddings(context.Background(), "")
	if err != nil {
		t.Fatal(err)
	}
	if len(embs) == 0 {
		t.Error("no embeddings stored")
	}

	// Hybrid search
	hs := engine.NewHybridSearch(eng.Store(), eng.Graph(), provider)
	scored, err := hs.Search(context.Background(), "auth JWT", engine.RecallOpts{Depth: 2, Limit: 10})
	if err != nil {
		t.Fatal(err)
	}
	if len(scored) == 0 {
		t.Error("hybrid search returned no results")
	}

	// Re-rank
	reranked := engine.Rerank(context.Background(), scored, eng.Store())
	if len(reranked) == 0 {
		t.Error("rerank returned no results")
	}
}

func TestPhase3DecayAndGC(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	n, _ := eng.Remember(context.Background(), engine.RememberInput{Type: "decision", Content: "Old decision", Scope: "project"})

	// Manually set low confidence
	node, _ := eng.Store().GetNode(context.Background(), n.ID)
	node.Confidence = 0.05
	eng.Store().UpdateNode(context.Background(), node)

	// GC should remove it
	removed, err := engine.GarbageCollect(context.Background(), eng.Store(), engine.DefaultDecayConfig)
	if err != nil {
		t.Fatal(err)
	}
	if removed == 0 {
		t.Error("GC should have removed low-confidence node")
	}
}

func TestPhase3ProactiveContext(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	eng.Remember(context.Background(), engine.RememberInput{Type: "convention", Content: "Use TypeScript strict mode", Scope: "project"})
	eng.Remember(context.Background(), engine.RememberInput{Type: "task", Content: "Add rate limiting", Scope: "project"})
	eng.Remember(context.Background(), engine.RememberInput{Type: "decision", Content: "Use NATS for events", Scope: "project"})

	hs := engine.NewHybridSearch(eng.Store(), eng.Graph(), nil)
	pc := engine.NewProactiveContext(eng, hs)
	nodes, err := pc.Predict(context.Background(), "", 2000)
	if err != nil {
		t.Fatal(err)
	}
	if len(nodes) == 0 {
		t.Error("proactive context returned no nodes")
	}

	// FormatContext should produce markdown
	ctx := engine.FormatContext(nodes)
	if ctx == "" {
		t.Error("FormatContext returned empty string")
	}
}

func TestPhase4HooksAndReplay(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	dir := t.TempDir()
	runner := hooks.New(eng, dir)

	// SessionStart
	in := &hooks.HookInput{Agent: "test-agent", Project: dir}
	if err := runner.SessionStart(context.Background(), in); err != nil {
		t.Fatalf("SessionStart: %v", err)
	}

	// PostToolUse — should create a memory node
	toolIn := &hooks.HookInput{
		ToolName:   "Write",
		ToolInput:  "src/auth.ts",
		ToolOutput: "wrote JWT middleware",
		Agent:      "test-agent",
	}
	if err := runner.PostToolUse(context.Background(), toolIn); err != nil {
		t.Fatalf("PostToolUse: %v", err)
	}
	// Store replay event
	if err := runner.StoreToolEvent(context.Background(), toolIn, eng.Store()); err != nil {
		t.Fatalf("StoreToolEvent: %v", err)
	}

	// Verify node was created
	result, err := eng.Recall(context.Background(), engine.RecallOpts{Query: "JWT middleware", Limit: 5})
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Nodes) == 0 {
		t.Error("PostToolUse should have created a memory node")
	}

	// SessionEnd
	endIn := &hooks.HookInput{Summary: "Implemented JWT auth middleware", Agent: "test-agent"}
	if err := runner.SessionEnd(context.Background(), endIn); err != nil {
		t.Fatalf("SessionEnd: %v", err)
	}
}

func TestPhase5ExportImport(t *testing.T) {
	eng, cleanup := setup(t)
	defer cleanup()

	eng.Remember(context.Background(), engine.RememberInput{Type: "convention", Content: "Use jose not jsonwebtoken", Scope: "project"})
	eng.Remember(context.Background(), engine.RememberInput{Type: "decision", Content: "Chose RS256 for JWT", Scope: "project"})

	// JSON export
	data, err := exportimport.ExportJSON(context.Background(), eng.Store(), "")
	if err != nil {
		t.Fatal(err)
	}
	if len(data) == 0 {
		t.Error("JSON export is empty")
	}

	// JSON import into fresh store
	eng2, cleanup2 := setup(t)
	defer cleanup2()
	nodes, edges, err := exportimport.ImportJSON(context.Background(), eng2.Store(), data)
	if err != nil {
		t.Fatal(err)
	}
	if nodes == 0 {
		t.Error("import: expected nodes > 0")
	}
	_ = edges

	// Markdown export
	md, err := exportimport.ExportMarkdown(context.Background(), eng.Store(), "")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(md, "jose") {
		t.Error("markdown export missing content")
	}

	// Obsidian export
	vaultDir := t.TempDir()
	n, err := exportimport.ExportObsidian(context.Background(), eng.Store(), "", vaultDir)
	if err != nil {
		t.Fatal(err)
	}
	if n == 0 {
		t.Error("obsidian export: expected files > 0")
	}
}
