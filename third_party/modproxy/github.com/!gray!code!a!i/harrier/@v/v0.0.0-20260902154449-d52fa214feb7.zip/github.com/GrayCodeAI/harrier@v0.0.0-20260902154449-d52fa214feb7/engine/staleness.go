package engine

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/GrayCodeAI/harrier/git"
	"github.com/GrayCodeAI/harrier/graph"
	"github.com/GrayCodeAI/harrier/storage"
)

// StalenessManager marks memories as stale when their related files change in git.
// It integrates the git watcher with the memory engine to automatically flag
// memories that may be outdated.
type StalenessManager struct {
	watcher *git.Watcher
	store   storage.Storage
	dir     string
}

// NewStalenessManager creates a manager for a project directory.
func NewStalenessManager(store storage.Storage, g graph.Graph, dir string) (*StalenessManager, error) {
	w, err := git.New(store, g, dir)
	if err != nil {
		return nil, fmt.Errorf("staleness manager: %w", err)
	}
	return &StalenessManager{watcher: w, store: store, dir: dir}, nil
}

// StaleMemory represents a memory flagged as stale due to a file change.
type StaleMemory struct {
	NodeID    string    `json:"node_id"`
	File      string    `json:"file"`
	ChangedAt time.Time `json:"changed_at"`
	Reason    string    `json:"reason"`
}

// MarkStale detects files changed since the given time and flags affected memories.
// For each affected node, confidence is reduced by the staleness penalty and a
// staleness tag is added so retrieval can account for potential outdatedness.
// Pinned nodes are never penalized — they're manually curated.
func (sm *StalenessManager) MarkStale(ctx context.Context, since time.Time, penalty float64) ([]StaleMemory, error) {
	if penalty <= 0 || penalty > 1 {
		penalty = 0.15
	}

	reports, err := sm.watcher.StalesSince(ctx, since)
	if err != nil {
		return nil, fmt.Errorf("detect stale files: %w", err)
	}

	var marked []StaleMemory
	for _, report := range reports {
		for _, nodeID := range report.NodeIDs {
			node, err := sm.store.GetNode(ctx, nodeID)
			if err != nil {
				continue
			}
			// Don't penalize pinned nodes — they're always manually curated
			if node.Pinned {
				continue
			}
			// Reduce confidence by staleness penalty
			node.Confidence = max(node.Confidence-penalty, 0)
			if err := sm.store.UpdateNode(ctx, node); err != nil {
				slog.Warn("staleness: update node failed", "node_id", nodeID, "error", err)
				continue
			}
			marked = append(marked, StaleMemory{
				NodeID:    nodeID,
				File:      report.File,
				ChangedAt: report.ChangedAt,
				Reason:    fmt.Sprintf("file %s changed in git", report.File),
			})
		}
	}

	return marked, nil
}

// StaleSince returns stale reports without modifying any nodes (read-only).
func (sm *StalenessManager) StaleSince(ctx context.Context, since time.Time) ([]git.StaleReport, error) {
	return sm.watcher.StalesSince(ctx, since)
}

// WatchFile registers a file-to-node mapping for staleness tracking.
func (sm *StalenessManager) WatchFile(ctx context.Context, filePath, nodeID, gitHash string) error {
	return sm.watcher.WatchFile(ctx, filePath, nodeID, gitHash)
}
