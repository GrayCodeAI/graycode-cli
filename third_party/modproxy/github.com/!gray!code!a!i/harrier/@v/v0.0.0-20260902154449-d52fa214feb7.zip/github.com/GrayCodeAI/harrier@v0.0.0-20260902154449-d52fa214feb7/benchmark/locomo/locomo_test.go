package locomo

import (
	"strings"
	"testing"
)

// fixtureJSON is a small, hand-written stand-in for LoCoMo-10's real shape
// (one sample, two sessions, a mix of QA categories including adversarial)
// so tests don't depend on network access or the multi-MB real dataset.
const fixtureJSON = `[
  {
    "sample_id": "conv-test-1",
    "qa": [
      {"question": "What did Alice go to yesterday?", "answer": "a support group", "evidence": ["D1:2"], "category": 1},
      {"question": "How old is Bob's dog?", "answer": 3, "evidence": ["D2:1"], "category": 2},
      {"question": "What did Alice realize?", "evidence": ["D1:2"], "category": 5, "adversarial_answer": "self-care matters"}
    ],
    "conversation": {
      "speaker_a": "Alice",
      "speaker_b": "Bob",
      "session_1_date_time": "1:00 pm on 1 May, 2023",
      "session_1": [
        {"speaker": "Alice", "dia_id": "D1:1", "text": "Hey Bob!"},
        {"speaker": "Alice", "dia_id": "D1:2", "text": "I went to a support group yesterday."}
      ],
      "session_2_date_time": "2:00 pm on 2 May, 2023",
      "session_2": [
        {"speaker": "Bob", "dia_id": "D2:1", "text": "My dog is 3 years old."}
      ]
    }
  }
]`

func TestParse(t *testing.T) {
	samples, err := Parse(strings.NewReader(fixtureJSON))
	if err != nil {
		t.Fatalf("Parse: %v", err)
	}
	if len(samples) != 1 {
		t.Fatalf("len(samples) = %d, want 1", len(samples))
	}
	s := samples[0]
	if s.SampleID != "conv-test-1" {
		t.Errorf("SampleID = %q, want conv-test-1", s.SampleID)
	}
	if len(s.QA) != 3 {
		t.Fatalf("len(QA) = %d, want 3", len(s.QA))
	}
}

func TestSample_Sessions(t *testing.T) {
	samples, err := Parse(strings.NewReader(fixtureJSON))
	if err != nil {
		t.Fatalf("Parse: %v", err)
	}
	sessions := samples[0].Sessions()
	if len(sessions) != 2 {
		t.Fatalf("len(sessions) = %d, want 2", len(sessions))
	}
	if sessions[0].Number != 1 || sessions[0].DateTime != "1:00 pm on 1 May, 2023" {
		t.Errorf("sessions[0] = %+v, unexpected", sessions[0])
	}
	if len(sessions[0].Turns) != 2 {
		t.Fatalf("len(sessions[0].Turns) = %d, want 2", len(sessions[0].Turns))
	}
	if sessions[0].Turns[1].Text != "I went to a support group yesterday." {
		t.Errorf("sessions[0].Turns[1].Text = %q, unexpected", sessions[0].Turns[1].Text)
	}
	if len(sessions[1].Turns) != 1 {
		t.Fatalf("len(sessions[1].Turns) = %d, want 1", len(sessions[1].Turns))
	}
}

func TestQAPair_AnswerText(t *testing.T) {
	samples, err := Parse(strings.NewReader(fixtureJSON))
	if err != nil {
		t.Fatalf("Parse: %v", err)
	}
	qa := samples[0].QA
	if got := qa[0].AnswerText(); got != "a support group" {
		t.Errorf("qa[0].AnswerText() = %q, want %q", got, "a support group")
	}
	if got := qa[1].AnswerText(); got != "3" {
		t.Errorf("qa[1].AnswerText() (numeric answer) = %q, want %q", got, "3")
	}
	if got := qa[2].AnswerText(); got != "" {
		t.Errorf("qa[2].AnswerText() (adversarial, no answer field) = %q, want empty", got)
	}
}

func TestSample_SeedInputs(t *testing.T) {
	samples, err := Parse(strings.NewReader(fixtureJSON))
	if err != nil {
		t.Fatalf("Parse: %v", err)
	}
	inputs := samples[0].SeedInputs()
	if len(inputs) != 3 {
		t.Fatalf("len(inputs) = %d, want 3 (2 turns in session 1 + 1 in session 2)", len(inputs))
	}
	for _, in := range inputs {
		if in.Type != "session" {
			t.Errorf("input Type = %q, want session", in.Type)
		}
		if in.Project != "conv-test-1" {
			t.Errorf("input Project = %q, want conv-test-1", in.Project)
		}
	}
	if inputs[1].Content != "Alice: I went to a support group yesterday." {
		t.Errorf("inputs[1].Content = %q, unexpected", inputs[1].Content)
	}
}

func TestSample_ToQAs_SkipsAdversarial(t *testing.T) {
	samples, err := Parse(strings.NewReader(fixtureJSON))
	if err != nil {
		t.Fatalf("Parse: %v", err)
	}
	qas := samples[0].ToQAs()
	if len(qas) != 2 {
		t.Fatalf("len(qas) = %d, want 2 (category-5 adversarial question excluded)", len(qas))
	}
	for _, qa := range qas {
		if qa.ExpectedContent == "" {
			t.Errorf("qa %q has empty ExpectedContent", qa.Question)
		}
	}
	if qas[0].ExpectedContent != "a support group" {
		t.Errorf("qas[0].ExpectedContent = %q, want %q", qas[0].ExpectedContent, "a support group")
	}
	if qas[1].ExpectedContent != "3" {
		t.Errorf("qas[1].ExpectedContent = %q, want %q", qas[1].ExpectedContent, "3")
	}
}
