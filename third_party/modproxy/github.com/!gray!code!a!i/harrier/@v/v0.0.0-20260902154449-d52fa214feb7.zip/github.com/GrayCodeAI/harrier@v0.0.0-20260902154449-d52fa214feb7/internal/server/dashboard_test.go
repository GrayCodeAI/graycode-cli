package server

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestServeDashboardReturnsHTML(t *testing.T) {
	t.Parallel()
	mux := http.NewServeMux()
	ServeDashboard(mux)

	req := httptest.NewRequest("GET", "/harrier/ui", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)

	if rr.Code != 200 {
		t.Fatalf("expected 200, got %d", rr.Code)
	}

	ct := rr.Header().Get("Content-Type")
	if !strings.Contains(ct, "text/html") {
		t.Errorf("Content-Type = %q, want text/html", ct)
	}

	body := rr.Body.String()
	if body == "" {
		t.Error("dashboard response body is empty")
	}
}

func TestServeDashboardCharset(t *testing.T) {
	t.Parallel()
	mux := http.NewServeMux()
	ServeDashboard(mux)

	req := httptest.NewRequest("GET", "/harrier/ui", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)

	ct := rr.Header().Get("Content-Type")
	if !strings.Contains(ct, "charset=utf-8") {
		t.Errorf("Content-Type should include charset=utf-8, got %q", ct)
	}
}

func TestServeDashboardEmbedNotEmpty(t *testing.T) {
	t.Parallel()
	// The embedded HTML should not be empty
	if len(dashboardHTML) == 0 {
		t.Error("dashboardHTML embed is empty")
	}
}

func TestServeDashboardContainsHTML(t *testing.T) {
	t.Parallel()
	// The embedded content should look like HTML
	html := string(dashboardHTML)
	if !strings.Contains(html, "<") {
		t.Error("dashboardHTML does not contain HTML tags")
	}
}

func TestServeDashboardMethodNotAllowed(t *testing.T) {
	t.Parallel()
	mux := http.NewServeMux()
	ServeDashboard(mux)

	// POST should not match the GET-only route
	req := httptest.NewRequest("POST", "/harrier/ui", nil)
	rr := httptest.NewRecorder()
	mux.ServeHTTP(rr, req)

	// Go 1.22+ method routing returns 405 for method mismatch
	if rr.Code != http.StatusMethodNotAllowed {
		t.Logf("POST /harrier/ui returned %d (may be 404 or 405 depending on Go version)", rr.Code)
	}
}
