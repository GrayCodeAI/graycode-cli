# Provenance Notes

- Command:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./benchmark -bench=. -benchmem -benchtime=1x'`
- Environment:
  `goos=darwin`
  `goarch=arm64`
  `cpu=Apple M1`
- Verification:
  benchmark command exited successfully with `PASS`
- Caveats:
  single-iteration baseline (`-benchtime=1x`) chosen for a fast first committed snapshot
  output contains temporal tail-marker warnings that should be investigated separately before treating those warnings as acceptable long-term benchmark noise
