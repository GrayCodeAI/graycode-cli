package engine

import (
	"context"
	"errors"
	"strings"
	"testing"
)

type fakeKeygen struct {
	out string
	err error
}

func (f fakeKeygen) GenerateKeywords(_ context.Context, _ string) (string, error) {
	return f.out, f.err
}

func TestRewriteQuery_NilLLMUsesSynonyms(t *testing.T) {
	t.Parallel()
	got := RewriteQuery(context.Background(), nil, KeygenLLMThenSynonyms, "auth bug")
	// ExpandQuery expands "auth" → adds authentication/authorize/login.
	if !strings.Contains(got, "auth") || !strings.Contains(got, "authentication") {
		t.Errorf("expected synonym expansion, got %q", got)
	}
}

func TestRewriteQuery_EmptyQuery(t *testing.T) {
	t.Parallel()
	if got := RewriteQuery(context.Background(), fakeKeygen{out: "x"}, KeygenLLMOnly, "   "); got != "" {
		t.Errorf("empty query should rewrite to empty, got %q", got)
	}
}

func TestRewriteQuery_LLMOnly(t *testing.T) {
	t.Parallel()
	got := RewriteQuery(context.Background(), fakeKeygen{out: "login session cookie"}, KeygenLLMOnly, "why am I logged out?")
	if got != "login session cookie" {
		t.Errorf("LLMOnly should return raw keywords, got %q", got)
	}
}

func TestRewriteQuery_LLMErrorFallsBack(t *testing.T) {
	t.Parallel()
	got := RewriteQuery(context.Background(), fakeKeygen{err: errors.New("boom")}, KeygenLLMOnly, "db config")
	// Falls back to synonym expansion of the original query.
	if !strings.Contains(got, "database") || !strings.Contains(got, "configuration") {
		t.Errorf("expected fallback to synonyms, got %q", got)
	}
}

func TestRewriteQuery_LLMThenSynonymsUnionDedup(t *testing.T) {
	t.Parallel()
	// LLM returns "auth token"; synonym expansion of "auth" also yields auth/...
	got := RewriteQuery(context.Background(), fakeKeygen{out: "auth token"}, KeygenLLMThenSynonyms, "auth")
	fields := strings.Fields(got)
	seen := map[string]int{}
	for _, f := range fields {
		seen[strings.ToLower(f)]++
	}
	for term, n := range seen {
		if n > 1 {
			t.Errorf("term %q appears %d times, want deduped: %q", term, n, got)
		}
	}
	// LLM terms come first.
	if fields[0] != "auth" {
		t.Errorf("expected LLM terms first, got %q", got)
	}
	if !strings.Contains(got, "token") {
		t.Errorf("expected LLM keyword 'token' retained, got %q", got)
	}
}

func TestRewriteQuery_SynonymsStrategyIgnoresLLM(t *testing.T) {
	t.Parallel()
	got := RewriteQuery(context.Background(), fakeKeygen{out: "SHOULD_NOT_APPEAR"}, KeygenSynonyms, "config")
	if strings.Contains(got, "SHOULD_NOT_APPEAR") {
		t.Errorf("KeygenSynonyms must not call the LLM, got %q", got)
	}
}
