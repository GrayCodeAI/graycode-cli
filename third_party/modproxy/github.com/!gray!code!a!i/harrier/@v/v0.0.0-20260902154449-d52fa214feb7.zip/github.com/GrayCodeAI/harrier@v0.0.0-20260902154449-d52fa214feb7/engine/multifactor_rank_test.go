package engine

import (
	"context"
	"testing"
	"time"

	"github.com/GrayCodeAI/harrier/storage"
)

func TestMultiFactorRanker_Rank(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	ctx := context.Background()

	// Create test nodes
	nodes := []*storage.Node{
		{
			ID:          "node-1",
			Type:        "decision",
			Content:     "Use PostgreSQL for the database",
			Tier:        1,
			Confidence:  0.9,
			AccessCount: 10,
			AccessedAt:  time.Now(),
			Pinned:      true,
		},
		{
			ID:          "node-2",
			Type:        "convention",
			Content:     "Always use TypeScript for new files",
			Tier:        2,
			Confidence:  0.7,
			AccessCount: 5,
			AccessedAt:  time.Now().Add(-24 * time.Hour),
		},
		{
			ID:          "node-3",
			Type:        "spec",
			Content:     "API rate limit is 100 requests per minute",
			Tier:        3,
			Confidence:  0.5,
			AccessCount: 1,
			AccessedAt:  time.Now().Add(-30 * 24 * time.Hour),
		},
	}

	baseScores := map[string]float64{
		"node-1": 0.8,
		"node-2": 0.6,
		"node-3": 0.4,
	}

	ranker := NewMultiFactorRanker(DefaultRankingWeights())
	ranked := ranker.Rank(ctx, nodes, baseScores, store)

	if len(ranked) != 3 {
		t.Fatalf("expected 3 ranked nodes, got %d", len(ranked))
	}

	// node-1 should rank highest (pinned, high confidence, high relevance, recent)
	if ranked[0].Node.ID != "node-1" {
		t.Errorf("expected node-1 first, got %s", ranked[0].Node.ID)
	}

	// Scores should be descending
	for i := 1; i < len(ranked); i++ {
		if ranked[i].Score > ranked[i-1].Score {
			t.Errorf("scores not in descending order: %f > %f", ranked[i].Score, ranked[i-1].Score)
		}
	}

	// Each ranked node should have factor breakdown
	for _, r := range ranked {
		if r.Factors == nil {
			t.Error("expected factors map, got nil")
		}
		if _, ok := r.Factors["recency"]; !ok {
			t.Error("expected recency factor")
		}
		if _, ok := r.Factors["relevance"]; !ok {
			t.Error("expected relevance factor")
		}
	}
}

func TestMultiFactorRanker_Empty(t *testing.T) {
	t.Parallel()
	store := setupTestStore(t)
	ranker := NewMultiFactorRanker(DefaultRankingWeights())
	ranked := ranker.Rank(context.Background(), nil, nil, store)
	if ranked != nil {
		t.Error("expected nil for empty input")
	}
}

func TestDefaultRankingWeights(t *testing.T) {
	t.Parallel()
	w := DefaultRankingWeights()
	total := w.Recency + w.Relevance + w.Frequency + w.Confidence + w.Tier + w.Centrality + w.Pinned
	if total < 0.99 || total > 1.01 {
		t.Errorf("default weights should sum to ~1.0, got %f", total)
	}
}

func TestNormalizeWeights(t *testing.T) {
	t.Parallel()
	w := RankingWeights{
		Recency:    2.0,
		Relevance:  3.0,
		Frequency:  1.0,
		Confidence: 2.0,
		Tier:       1.0,
		Centrality: 1.0,
		Pinned:     0.5,
	}
	n := normalizeWeights(w)
	total := n.Recency + n.Relevance + n.Frequency + n.Confidence + n.Tier + n.Centrality + n.Pinned
	if total < 0.99 || total > 1.01 {
		t.Errorf("normalized weights should sum to ~1.0, got %f", total)
	}
}

func TestNormalizeWeights_ZeroTotal(t *testing.T) {
	t.Parallel()
	w := RankingWeights{}
	n := normalizeWeights(w)
	// Should fall back to defaults
	if n.Recency != DefaultRankingWeights().Recency {
		t.Error("expected default weights when total is zero")
	}
}

func TestRecencyScore(t *testing.T) {
	t.Parallel()
	now := time.Now()

	// Recent node
	recent := &storage.Node{AccessedAt: now}
	s := recencyScore(recent, now)
	if s < 0.9 {
		t.Errorf("expected high recency for just-accessed node, got %f", s)
	}

	// Old node
	old := &storage.Node{AccessedAt: now.Add(-90 * 24 * time.Hour)}
	s = recencyScore(old, now)
	if s > 0.5 {
		t.Errorf("expected low recency for old node, got %f", s)
	}

	// Zero time (never accessed)
	never := &storage.Node{}
	s = recencyScore(never, now)
	if s != 0.1 {
		t.Errorf("expected 0.1 for never-accessed node, got %f", s)
	}
}

func TestFrequencyScore(t *testing.T) {
	t.Parallel()
	// No accesses
	s := frequencyScore(&storage.Node{AccessCount: 0})
	if s != 0 {
		t.Errorf("expected 0 for no accesses, got %f", s)
	}

	// Many accesses
	s = frequencyScore(&storage.Node{AccessCount: 100})
	if s < 0.8 {
		t.Errorf("expected high score for 100 accesses, got %f", s)
	}
}

func TestTierLevelScore(t *testing.T) {
	t.Parallel()
	if tierLevelScore(1) != 1.0 {
		t.Error("tier 1 should score 1.0")
	}
	if tierLevelScore(2) != 0.6 {
		t.Error("tier 2 should score 0.6")
	}
	if tierLevelScore(3) != 0.3 {
		t.Error("tier 3 should score 0.3")
	}
	if tierLevelScore(0) != 0.1 {
		t.Error("tier 0 should score 0.1")
	}
}

func TestPinnedScore(t *testing.T) {
	t.Parallel()
	if pinnedScore(true) != 1.0 {
		t.Error("pinned should score 1.0")
	}
	if pinnedScore(false) != 0.0 {
		t.Error("unpinned should score 0.0")
	}
}

func TestRankedNodesToNodes(t *testing.T) {
	t.Parallel()
	ranked := []*RankedNode{
		{Node: &storage.Node{ID: "a"}, Score: 1.0},
		{Node: &storage.Node{ID: "b"}, Score: 0.5},
	}
	nodes := RankedNodesToNodes(ranked)
	if len(nodes) != 2 {
		t.Fatalf("expected 2 nodes, got %d", len(nodes))
	}
	if nodes[0].ID != "a" || nodes[1].ID != "b" {
		t.Error("node order should be preserved")
	}
}
