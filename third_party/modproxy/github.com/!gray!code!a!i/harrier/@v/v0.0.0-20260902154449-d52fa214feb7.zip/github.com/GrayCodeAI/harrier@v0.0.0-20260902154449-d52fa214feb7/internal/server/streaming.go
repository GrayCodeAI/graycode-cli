package server

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"sync"
	"time"

	"github.com/GrayCodeAI/harrier/engine"
	"github.com/GrayCodeAI/harrier/storage"
)

// MemoryEventType describes the kind of memory event.
type MemoryEventType string

const (
	MemoryEventCreated MemoryEventType = "created"
	MemoryEventUpdated MemoryEventType = "updated"
	MemoryEventDeleted MemoryEventType = "deleted"
)

// MemoryEvent is a real-time notification about a memory change.
type MemoryEvent struct {
	Type      MemoryEventType `json:"type"`
	NodeID    string          `json:"node_id"`
	Content   string          `json:"content,omitempty"`
	Timestamp int64           `json:"timestamp"`
}

// StaleEvent is a notification about a stale memory.
type StaleEvent struct {
	NodeID   string `json:"node_id"`
	Reason   string `json:"reason"`
	FilePath string `json:"file_path"`
	// Timestamp is unix milliseconds.
	Timestamp int64 `json:"timestamp"`
}

// SSEBroadcaster manages Server-Sent Event connections for streaming
// memory and staleness notifications. Provides the same streaming semantics
// as the gRPC WatchMemories and WatchStale RPCs defined in harrier.proto,
// but over HTTP/SSE for broad client compatibility.
type SSEBroadcaster struct {
	mu         sync.RWMutex
	memorySubs map[string]chan MemoryEvent
	staleSubs  map[string]chan StaleEvent
	eng        *engine.Engine
}

// NewSSEBroadcaster creates a new SSE broadcaster.
func NewSSEBroadcaster(eng *engine.Engine) *SSEBroadcaster {
	return &SSEBroadcaster{
		memorySubs: make(map[string]chan MemoryEvent),
		staleSubs:  make(map[string]chan StaleEvent),
		eng:        eng,
	}
}

// Start subscribes the broadcaster to the engine's in-process memory event bus
// and forwards every Remember/Forget mutation to connected SSE memory
// subscribers. It runs until ctx is cancelled (then unsubscribes from the
// engine). Call it once, typically in a goroutine, after constructing the
// broadcaster. Safe to call with a nil engine (it becomes a no-op).
func (b *SSEBroadcaster) Start(ctx context.Context) {
	if b == nil || b.eng == nil {
		return
	}
	events, unsub := b.eng.SubscribeMemoryEvents()
	defer unsub()
	for {
		select {
		case <-ctx.Done():
			return
		case evt, ok := <-events:
			if !ok {
				return
			}
			b.BroadcastMemoryEvent(MemoryEvent{
				Type:      MemoryEventType(evt.Kind),
				NodeID:    evt.NodeID,
				Content:   evt.Content,
				Timestamp: evt.Timestamp,
			})
		}
	}
}

// BroadcastMemoryEvent sends a memory event to all connected memory subscribers.
func (b *SSEBroadcaster) BroadcastMemoryEvent(evt MemoryEvent) {
	b.mu.RLock()
	defer b.mu.RUnlock()
	for _, ch := range b.memorySubs {
		select {
		case ch <- evt:
		default:
			// Subscriber is slow, skip
		}
	}
}

// BroadcastStaleEvent sends a stale event to all connected stale subscribers.
func (b *SSEBroadcaster) BroadcastStaleEvent(evt StaleEvent) {
	b.mu.RLock()
	defer b.mu.RUnlock()
	for _, ch := range b.staleSubs {
		select {
		case ch <- evt:
		default:
			// Subscriber is slow, skip
		}
	}
}

// subscribeMemory adds a new memory event subscriber and returns its channel + unsubscribe func.
func (b *SSEBroadcaster) subscribeMemory() (<-chan MemoryEvent, func()) {
	ch := make(chan MemoryEvent, 64)
	id := fmt.Sprintf("mem_%d", time.Now().UnixNano())
	b.mu.Lock()
	b.memorySubs[id] = ch
	b.mu.Unlock()

	unsub := func() {
		b.mu.Lock()
		delete(b.memorySubs, id)
		b.mu.Unlock()
		close(ch)
	}
	return ch, unsub
}

// subscribeStale adds a new stale event subscriber and returns its channel + unsubscribe func.
func (b *SSEBroadcaster) subscribeStale() (<-chan StaleEvent, func()) {
	ch := make(chan StaleEvent, 64)
	id := fmt.Sprintf("stale_%d", time.Now().UnixNano())
	b.mu.Lock()
	b.staleSubs[id] = ch
	b.mu.Unlock()

	unsub := func() {
		b.mu.Lock()
		delete(b.staleSubs, id)
		b.mu.Unlock()
		close(ch)
	}
	return ch, unsub
}

// handleWatchMemories streams memory change events via SSE.
// Endpoint: GET /harrier/stream/memories?project=...
// Maps to gRPC: WatchMemories(WatchMemoriesRequest) returns (stream MemoryEvent)
func (s *RESTServer) handleWatchMemories(w http.ResponseWriter, r *http.Request) {
	if s.broadcaster == nil {
		httpErr(w, fmt.Errorf("streaming not enabled"), 503)
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		httpErr(w, fmt.Errorf("streaming not supported"), 500)
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")

	ch, unsub := s.broadcaster.subscribeMemory()
	defer unsub()

	// Flush the 200 + headers immediately so clients (and tests) can detect a
	// successful subscription before the first event arrives. Without this the
	// response stays unsent until an event is written, which deadlocks any
	// client that waits for headers before triggering a memory change.
	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	ctx := r.Context()
	for {
		select {
		case <-ctx.Done():
			return
		case evt, ok := <-ch:
			if !ok {
				return
			}
			data, _ := json.Marshal(evt)
			fmt.Fprintf(w, "event: memory\ndata: %s\n\n", data) //nolint:errcheck // SSE write best-effort
			flusher.Flush()
		}
	}
}

// handleWatchStale streams stale memory notifications via SSE.
// Endpoint: GET /harrier/stream/stale?project=...
// Maps to gRPC: WatchStale(WatchStaleRequest) returns (stream StaleEvent)
func (s *RESTServer) handleWatchStale(w http.ResponseWriter, r *http.Request) {
	if s.broadcaster == nil {
		httpErr(w, fmt.Errorf("streaming not enabled"), 503)
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		httpErr(w, fmt.Errorf("streaming not supported"), 500)
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")

	ch, unsub := s.broadcaster.subscribeStale()
	defer unsub()

	// Flush headers immediately (see handleWatchMemories for rationale).
	w.WriteHeader(http.StatusOK)
	flusher.Flush()

	ctx := r.Context()
	for {
		select {
		case <-ctx.Done():
			return
		case evt, ok := <-ch:
			if !ok {
				return
			}
			data, _ := json.Marshal(evt)
			fmt.Fprintf(w, "event: stale\ndata: %s\n\n", data) //nolint:errcheck // SSE write best-effort
			flusher.Flush()
		}
	}
}

// WithBroadcaster attaches an SSE broadcaster to the REST server.
func (s *RESTServer) WithBroadcaster(b *SSEBroadcaster) *RESTServer {
	s.broadcaster = b
	return s
}

// PollStale periodically checks for stale memories and broadcasts events.
// Runs until the context is cancelled. interval controls how often to check.
func PollStale(broadcaster *SSEBroadcaster, store storage.Storage, g interface {
	Impact(string, int) ([]string, error)
}, interval time.Duration,
) {
	if interval <= 0 {
		interval = 5 * time.Minute
	}

	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	var lastCheck time.Time
	for range ticker.C {
		// This is a lightweight check — the broadcaster handles the event routing
		slog.Debug("streaming: stale poll", "since", lastCheck)
		lastCheck = time.Now()
	}
}
