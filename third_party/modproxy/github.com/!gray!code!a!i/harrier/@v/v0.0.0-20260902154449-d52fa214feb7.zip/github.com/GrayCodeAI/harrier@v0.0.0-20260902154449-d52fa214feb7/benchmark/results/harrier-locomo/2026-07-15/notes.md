# Provenance Notes

- Command:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go run ./benchmark/cmd/locomobench --cache /tmp/locomo10_cache.json'`
  (the `--cache` flag is optional; omitting it downloads the dataset from
  `locomo.DatasetURL` — `https://raw.githubusercontent.com/snap-research/locomo/main/data/locomo10.json`
  — on first run)
- Verification:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./benchmark/locomo -count=1'`
- Environment:
  local workspace run on `2026-07-15`, dataset fetched live from the public
  `snap-research/locomo` GitHub repo (10 samples, 1,984 total QA pairs)
- Dataset: LoCoMo-10 (`snap-research/locomo`), the standard external
  long-term conversational memory benchmark — this is the first run against
  an external corpus; the prior `harrier-longmem-core` baseline uses a
  first-party, self-seeded 18-question QA set.

## Caveats — read before comparing these numbers to anything else

1. **This is a retrieval-hit proxy score, not LoCoMo's official metric.**
   LoCoMo's own published evaluation grades free-text answer *generation*
   via an LLM judge. `internal/bench.Run` (reused unmodified here) instead
   checks whether the expected answer text appears as a case-insensitive
   substring of a retrieved node's content within the top-K. These are
   related but genuinely different measurements — do not read these numbers
   as comparable to a LoCoMo leaderboard entry.
2. **Category 5 (adversarial/unanswerable) questions are excluded.** 444 of
   the ~1,984 total QA pairs have no `answer` field (only
   `adversarial_answer`, explaining why the question is unanswerable from
   the conversation) — a substring-match harness has no way to score
   "correctly recalled nothing," so scoring them would just inflate the
   miss count without measuring anything real. 1,540 non-adversarial QA
   pairs were evaluated.
3. **The much lower scores vs. `harrier-longmem-core` (R@1 3.1% vs. 66.7%) are
   expected, not a regression.** The self-seeded baseline's answers are
   near-verbatim substrings of their source memories by construction; real
   LoCoMo answers are frequently paraphrased, computed (e.g. relative
   dates), or require synthesizing multiple dialogue turns — exactly the
   kind of question a substring-match proxy underscores relative to a real
   generation-based judge. Treat this run as establishing a first honest
   external-corpus baseline, not as evidence retrieval quality regressed.
4. **Each of the 10 LoCoMo conversations is benchmarked against its own
   freshly seeded engine**, not a shared one — see
   `benchmark/locomo/adapter.go`'s `SeedInputs` doc comment for why (cross-
   conversation recall would be a correctness bug, not a harder benchmark).
5. The broader `harrier-locomo-beam-publication` suite id already named as
   "planned" in `benchmark/README.md` implies eventual BEAM-benchmark
   coverage too — this run covers LoCoMo only. `BEAM` ingestion was not
   attempted in this pass.
