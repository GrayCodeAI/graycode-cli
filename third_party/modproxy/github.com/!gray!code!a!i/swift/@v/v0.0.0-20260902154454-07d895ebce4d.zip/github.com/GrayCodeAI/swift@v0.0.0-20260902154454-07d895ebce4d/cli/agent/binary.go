package agent

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// Binary names for hook-command generation and recognition.
//
// These live in the shared agent package (not package cli) because both the
// strategy layer (git hooks) and every agent integration (wrapper probes)
// need them, while package cli imports both of those and cannot be imported
// by them without a cycle.
const (
	// BinaryName is the canonical name of this CLI's binary. It is the name
	// hooks assume when nothing more specific can be resolved, and the name
	// the root cobra command reports (see cli.NewRootCmd).
	BinaryName = "swift"

	// LegacyBinaryName is the pre-rebrand binary name. Hook commands and
	// config files installed by older builds still reference it, so it is
	// kept as a recognition and fallback name.
	LegacyBinaryName = "entire"

	// EmbeddedHostPrefix is the invocation prefix used when this CLI runs
	// inside the hawk binary, which embeds the root command as its `swift`
	// subcommand (hawk's cmd/swift.go: rootCmd.AddCommand(tracecli.NewRootCmd())).
	EmbeddedHostPrefix = "hawk swift"
)

// hookBinaryExecutable and hookBinaryLookPath are indirected so tests can
// simulate the running binary and the searchable PATH. Override them via
// SetHookBinaryResolutionForTesting.
var (
	hookBinaryExecutable = os.Executable
	hookBinaryLookPath   = exec.LookPath
)

// SetHookBinaryResolutionForTesting overrides how HookCommandPrefix observes
// the running executable and the PATH, and returns a restore function.
// Test-only; non-parallel tests only (parallel tests read these vars).
func SetHookBinaryResolutionForTesting(exe func() (string, error), lookPath func(string) (string, error)) func() {
	oldExe, oldLookPath := hookBinaryExecutable, hookBinaryLookPath
	hookBinaryExecutable = exe
	hookBinaryLookPath = lookPath
	return func() {
		hookBinaryExecutable = oldExe
		hookBinaryLookPath = oldLookPath
	}
}

// PinLegacyHookBinaryForTesting pins hook-binary resolution to the legacy
// name so tests asserting the historical wrapper strings stay deterministic
// regardless of what swift/entire binaries happen to be on the host PATH
// (e.g. macOS ships an unrelated /usr/bin/swift). Test-only; non-parallel
// tests only.
func PinLegacyHookBinaryForTesting() func() {
	notFound := func(string) (string, error) {
		return "", &os.PathError{Op: "exec.LookPath", Path: "x", Err: os.ErrNotExist}
	}
	return SetHookBinaryResolutionForTesting(func() (string, error) {
		return "/usr/local/bin/entire", nil
	}, notFound)
}

// HookCommandPrefix returns the command prefix installed hooks should use to
// invoke this CLI ("swift", "entire", or "hawk swift"), resolved in priority
// order:
//
//  1. the basename of the running executable, when it is a known name
//     (swift, entire, or the hawk host that embeds this CLI);
//  2. BinaryName ("swift"), when a binary of that name is reachable on PATH;
//  3. LegacyBinaryName ("entire"), when only the legacy name is on PATH;
//  4. LegacyBinaryName — the final fallback, matching the historical baked
//     default so resolution is never worse than older builds' behavior.
//
// Callers that offer an explicit override (the local-dev launcher or
// --absolute-git-hook-path) apply it before consulting this function.
//
// Like UseWindowsProductionHooks, this is deliberately not memoized: it runs
// once per hook install, and re-probing lets a host that gains or loses a
// binary migrate its hooks on the next install.
func HookCommandPrefix() string {
	if exe, err := hookBinaryExecutable(); err == nil {
		if prefix, ok := knownExecutableHookPrefix(filepath.Base(exe)); ok {
			return prefix
		}
	}
	if _, err := hookBinaryLookPath(BinaryName); err == nil {
		return BinaryName
	}
	if _, err := hookBinaryLookPath(LegacyBinaryName); err == nil {
		return LegacyBinaryName
	}
	return LegacyBinaryName
}

// knownExecutableHookPrefix maps a known executable basename to the hook
// invocation prefix for it. Windows basenames keep their ".exe" suffix.
func knownExecutableHookPrefix(base string) (string, bool) {
	base = strings.TrimSuffix(base, ".exe")
	switch base {
	case BinaryName:
		return BinaryName, true
	case LegacyBinaryName:
		return LegacyBinaryName, true
	case "hawk":
		return EmbeddedHostPrefix, true
	}
	return "", false
}

// hookBinaryProbeNames lists every binary name that generated wrappers may
// probe for. Recognition uses the full set so hooks installed under any name
// (including by older builds) stay recognizable for removal and upgrade.
func hookBinaryProbeNames() []string {
	return []string{BinaryName, LegacyBinaryName, "hawk"}
}

// managedBinaryCommandPrefixes are command prefixes for every binary-name
// form hooks may be invoked through, independent of caller-supplied prefix
// lists. They keep uninstall/upgrade flows recognizing hooks after the rebrand
// renamed the binary (swift) and hawk embedding introduced the "hawk swift"
// form, without requiring every agent package to extend its own prefix list.
func managedBinaryCommandPrefixes() []string {
	return []string{
		BinaryName + " ",
		LegacyBinaryName + " ",
		EmbeddedHostPrefix + " ",
	}
}

// productionHookWrapperTarget resolves the binary a production wrapper should
// probe and exec. The wrapped command's leading legacy binary token (agents
// still build commands as "entire hooks <agent> <verb>") is rewritten to the
// resolved invocation prefix; commands that do not start with the legacy
// binary name (local-dev launchers, absolute paths) pass through unchanged.
func productionHookWrapperTarget(command string) (probe, adaptedCommand string) {
	prefix := HookCommandPrefix()
	adapted := command
	if prefix != LegacyBinaryName && strings.HasPrefix(command, LegacyBinaryName+" ") {
		adapted = prefix + command[len(LegacyBinaryName):]
	}
	return hookCommandProbeName(prefix), adapted
}

// hookCommandProbeName returns the single PATH entry name a wrapper probes
// for the given invocation prefix ("hawk swift" probes "hawk").
func hookCommandProbeName(prefix string) string {
	name, _, _ := strings.Cut(prefix, " ")
	return name
}
