# Changelog

All notable changes to this project will be documented in this file.

Format based on [Keep a Changelog](https://keepachangelog.com/). This project adheres to [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Added — New features
- `swift fork` — clone a checkpoint into a new independent session for A/B testing from any point.
- Three-mode commit attribution — `Co-authored-by:` trailer (default on), plus opt-in `attribute_author` and `attribute_committer` to set the git author/committer to the agent.
- Pre-edit dirty-working-tree auto-commit — saves work-in-progress before an agent session (default on; `--no-dirty-commits` to skip).
- Per-session and per-tool USD cost attribution derived from recorded token usage and model pricing.
- Webhook notifications on session lifecycle events via the `webhooks` config (default off).
- `swift ci-init` — configure Swift to auto-capture sessions in CI.
- `swift annotate` — attach a comment to a session or checkpoint.
- asciinema export — `swift session export --format asciinema` renders a transcript as a playable v2 cast.

### Changed
- **README truth fixes** — Quick Start now describes both composition
  surfaces accurately (library embedded as `hawk swift ...`, plus the
  buildable-but-unreleased `cmd/swift` standalone entrypoint), workflow
  examples note the `hawk swift` prefix, the Configuration section documents
  the legacy `.entire/` read compat, and the Development section points at
  `docs/architecture.md` instead of the GitNexus-boilerplate CLAUDE.md.
- **ogen generator pin aligned with go.mod** — the `//go:generate` directive
  in `internal/coreapi/gen.go` now pins ogen@v1.23.0 (go.mod requires
  v1.23.0; the directive previously pinned v1.20.3). Regenerating the
  oas_*.go files is still pending (large diff, tracked separately).
- **Settings moved to `.swift/` with a read-compat shim** — the canonical
  settings files are now `.swift/settings.json` and
  `.swift/settings.local.json` (matching the README), replacing the
  pre-rebrand `.entire/` locations. Reads fall back to the legacy `.entire/`
  files when the canonical ones are absent (including setup detection via
  `IsSetUp`/`IsSetUpAny` and the raw read-modify-write API), and the first
  save copies the legacy content to the canonical location — a lazy,
  non-destructive migration that never deletes or rewrites the legacy files.
  Session data keeps using `.entire/metadata` on the checkpoint branch, and
  both directories are excluded from checkpoints and cleaned up by
  `uninstall --force`.
- **Hook binary resolution survives the rebrand and hawk embedding** — the
  default git-hook prefix and the production wrapper probes no longer hardcode
  the literal `entire`. They resolve through the new `agent.HookCommandPrefix`
  in priority order: the basename of the running executable when it is a known
  name (`swift`, `entire`, or `hawk`, which embeds this CLI as `hawk swift`),
  then `swift` when reachable on PATH, then legacy `entire`, with `entire` as
  the final fallback so already-installed setups keep working. Under hawk
  distributions (no `entire` on PATH) wrappers now probe and exec `hawk swift`
  instead of silently exiting and disabling capture. Wrapper recognition
  (uninstall/upgrade) accepts every binary-name form, including wrappers
  installed by older builds.
- **Root command rebranded to `swift`** — `cli.NewRootCmd()` now reports
  `Use: "swift"` (was `entire`), `Short` matches the README tagline ("Git-native
  session capture for AI coding agents"), the getting-started help no longer
  points at the defunct `docs.entire.io` docs, the version banner reads
  `Swift CLI`, hidden-alias deprecation hints name `swift …` commands, and the
  agent-help drill-down pointer derives from the live root command name.
- **Version re-baselined to `0.1.0`** in
  `cli/versioninfo/versioninfo.go`. Aligns swift with the rest
  of the hawk-eco ecosystem (`hawk`, `shrike`, `eyrie`, `harrier`, `kestrel`,
  `merlin`).

### Added
- SWIFT_TAG_* env var session metadata
- gen_ai.* OTel span aliases
- OpenTelemetry collector client with batching and retry

### Added — Production hygiene (top-50 OSS parity)
- `.gitattributes` — LF line-ending normalization, binary detection,
  GitHub linguist hints (collapse `go.sum` in PR diffs, mark `docs/**`
  and the symlinked `AGENTS.md` as documentation).
- `.editorconfig` — consistent formatting across editors (UTF-8, LF
  newlines, 2-space YAML, tabs for Go, final newline + trim trailing
  whitespace).
- `.github/PULL_REQUEST_TEMPLATE.md` — Summary / Changes / Privacy &
  redaction impact / Agent compatibility / Testing / Checklist. The
  privacy/redaction section is specific to swift because every change
  in `redact/` can leak PII or secrets if regressed.

## [0.1.0] - 2026-05-03

### Added

- Initial release of Swift CLI
- Git-native session capture for AI coding agents
- Support for Claude Code, Codex, Gemini CLI, OpenCode, Cursor, Factory AI Droid, and Copilot CLI
- Checkpoint rewind and session resume
- Auto-summarization with AI providers
- Checkpoint remote support (push session data to separate repos)
- `swift enable` / `swift disable` lifecycle management
- `swift checkpoint rewind` for restoring previous states
- `swift session resume` for cross-branch session recovery
- `swift doctor` for diagnostics and repair
- `swift clean` for state cleanup
- `swift explain` for checkpoint summaries
- Device auth login flow
- Git worktree support
- Concurrent session handling
- Automatic secret redaction in transcripts
- Accessible mode for screen readers
