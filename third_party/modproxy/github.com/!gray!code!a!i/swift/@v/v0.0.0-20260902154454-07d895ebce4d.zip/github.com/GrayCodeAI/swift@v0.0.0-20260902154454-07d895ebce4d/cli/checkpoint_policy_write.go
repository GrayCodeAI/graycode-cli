package cli

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/GrayCodeAI/swift/cli/checkpointpolicy"
	"github.com/GrayCodeAI/swift/cli/versioncheck"
	"github.com/GrayCodeAI/swift/cli/versioninfo"
	"github.com/go-git/go-git/v6"
)

var (
	errUnsupportedCheckpointPolicy = errors.New("checkpoint policy cannot be satisfied by this Entire CLI")
	errUnreadableCheckpointPolicy  = errors.New("checkpoint policy could not be read")
)

func ensureCheckpointPolicyAllowsCheckpointData(ctx context.Context, repo *git.Repository) error {
	policy, err := checkpointPolicyForCheckpointData(ctx, repo)
	if err != nil {
		return err
	}
	if checkpointpolicy.CanSatisfyPolicy(policy) {
		return nil
	}
	return unsupportedCheckpointPolicyError(policy)
}

func checkpointPolicyForCheckpointData(ctx context.Context, repo *git.Repository) (checkpointpolicy.Policy, error) {
	state, err := checkpointpolicy.ReadLocal(ctx, repo)
	if err != nil {
		return checkpointpolicy.Policy{}, unreadableCheckpointPolicyError(err)
	}
	return state.Policy, nil
}

func unsupportedCheckpointPolicyError(policy checkpointpolicy.Policy) error {
	message := strings.TrimSpace(checkpointpolicy.UnsupportedPolicyMessage(
		policy,
		versioncheck.UpdateCommandForCurrentBinary(versioninfo.Version),
	))
	return fmt.Errorf("%w:\n%s", errUnsupportedCheckpointPolicy, message)
}

func unreadableCheckpointPolicyError(err error) error {
	return fmt.Errorf("%w: %w", errUnreadableCheckpointPolicy, err)
}
