package checkpoint

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/GrayCodeAI/swift/cli/agent"
	"github.com/GrayCodeAI/swift/cli/agent/types"
	"github.com/GrayCodeAI/swift/cli/jsonutil"
	"github.com/GrayCodeAI/swift/cli/logging"
	"github.com/GrayCodeAI/swift/cli/paths"
	"github.com/GrayCodeAI/swift/cli/trailers"
	"github.com/GrayCodeAI/swift/cli/validation"
	"github.com/GrayCodeAI/swift/redact"

	"github.com/go-git/go-git/v6"
	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/object"
)

const (
	// ShadowBranchPrefix is the prefix for shadow branches.
	ShadowBranchPrefix = "entire/"

	// ShadowBranchHashLength is the number of hex characters used in shadow branch names.
	// Shadow branches are named "entire/<hash>" using the first 7 characters of the commit hash.
	ShadowBranchHashLength = 7

	// WorktreeIDHashLength is the number of hex characters used for worktree ID hash.
	WorktreeIDHashLength = 6
)

// HashWorktreeID returns a short hash of the worktree identifier.
// Used to create unique shadow branch names per worktree.
func HashWorktreeID(worktreeID string) string {
	h := sha256.Sum256([]byte(worktreeID))
	return hex.EncodeToString(h[:])[:WorktreeIDHashLength]
}

// writeCheckpoint writes a temporary checkpoint to a shadow branch.
// Shadow branches are named entire/<base-commit-short-hash>.
// Returns the result containing commit hash and whether it was skipped.
// If the new tree hash matches the last checkpoint's tree hash, the checkpoint
// is skipped to avoid duplicate commits (deduplication).
func (s *ephemeralStore) writeCheckpoint(ctx context.Context, opts WriteEphemeralOptions) (WriteEphemeralResult, error) {
	// Validate base commit - required for shadow branch naming
	if opts.BaseCommit == "" {
		return WriteEphemeralResult{}, errors.New("BaseCommit is required for temporary checkpoint")
	}

	// Validate session ID to prevent path traversal
	if err := validation.ValidateSessionID(opts.SessionID); err != nil {
		return WriteEphemeralResult{}, fmt.Errorf("invalid temporary checkpoint options: %w", err)
	}

	// Get shadow branch name
	shadowBranchName := ShadowBranchNameForCommit(opts.BaseCommit, opts.WorktreeID)

	// Collect file lists once — the worktree state is stable across retries,
	// so this work doesn't repeat per CAS attempt. Tree-building (which
	// depends on the parent tree) is what re-runs inside the retry loop.
	var allFiles []string
	var allDeletedFiles []string
	if opts.IsFirstCheckpoint {
		// For the first checkpoint, capture all changed files (modified tracked + untracked)
		// using `git status --porcelain -z` which respects both repo and global .gitignore.
		// This is much faster than filesystem walk. The base tree from HEAD already contains
		// all unchanged tracked files. We also capture user's pre-existing deletions.
		result, err := collectChangedFiles(ctx, s.repo)
		if err != nil {
			return WriteEphemeralResult{}, fmt.Errorf("failed to collect changed files: %w", err)
		}
		allFiles = result.Changed
		// Merge user's pre-existing deletions with agent's deletions
		allDeletedFiles = result.Deleted
		allDeletedFiles = append(allDeletedFiles, opts.DeletedFiles...)
	} else {
		// For subsequent checkpoints, only include modified/new files.
		// Filter out gitignored files — agent transcripts may report files like .env
		// that exist on disk but are gitignored. Without filtering, secrets in gitignored
		// files would leak into the shadow branch and could be pushed to remotes.
		candidateFiles := make([]string, 0, len(opts.ModifiedFiles)+len(opts.NewFiles))
		candidateFiles = append(candidateFiles, opts.ModifiedFiles...)
		candidateFiles = append(candidateFiles, opts.NewFiles...)
		allFiles = filterGitIgnoredFiles(ctx, s.repo, candidateFiles)
		allDeletedFiles = opts.DeletedFiles
	}

	commitMsg := trailers.FormatShadowCommit(opts.CommitMessage, opts.MetadataDir, opts.SessionID)

	repoRoot, commonDir, err := s.repoDirs(ctx)
	if err != nil {
		return WriteEphemeralResult{}, fmt.Errorf("failed to resolve repo dirs: %w", err)
	}

	var result WriteEphemeralResult
	// withShadowBranchFlock serializes all writers targeting this shadow
	// branch — across goroutines and across processes — so the inner CAS
	// only sees contention from external `git update-ref` callers (rare).
	err = withShadowBranchFlock(commonDir, shadowBranchName, func() error {
		// Tiny CAS retry budget: with the flock held, races against our own
		// code are impossible. Retries cover the pathological case of an
		// external writer (a user invoking `git update-ref` manually, etc.).
		for attempt := range shadowRefMaxRetries {
			parentHash, baseTreeHash, gErr := s.getOrCreateShadowBranch(shadowBranchName)
			if gErr != nil {
				return fmt.Errorf("failed to get shadow branch: %w", gErr)
			}

			// Get the last checkpoint's tree hash for deduplication
			var lastTreeHash plumbing.Hash
			if parentHash != plumbing.ZeroHash {
				if lastCommit, lcErr := s.repo.CommitObject(parentHash); lcErr == nil {
					lastTreeHash = lastCommit.TreeHash
				}
			}

			treeHash, tErr := s.buildTreeWithChanges(ctx, baseTreeHash, allFiles, allDeletedFiles, opts.MetadataDir, opts.MetadataDirAbs)
			if tErr != nil {
				return fmt.Errorf("failed to build tree: %w", tErr)
			}

			// Deduplication: skip if tree hash matches the current shadow tip.
			if lastTreeHash != plumbing.ZeroHash && treeHash == lastTreeHash {
				result = WriteEphemeralResult{
					CommitHash: parentHash,
					Skipped:    true,
				}
				return nil
			}

			commitHash, cErr := CreateCommit(ctx, s.repo, treeHash, parentHash, commitMsg, opts.AuthorName, opts.AuthorEmail)
			if cErr != nil {
				return fmt.Errorf("failed to create commit: %w", cErr)
			}

			refErr := casUpdateShadowBranchRef(ctx, repoRoot, shadowBranchName, commitHash, parentHash)
			if refErr == nil {
				result = WriteEphemeralResult{
					CommitHash: commitHash,
					Skipped:    false,
				}
				return nil
			}
			if !errors.Is(refErr, ErrShadowRefBusy) {
				return fmt.Errorf("failed to update shadow branch reference: %w", refErr)
			}
			// Our commit is now dangling — best-effort remove it so we don't
			// leak loose objects across many losing attempts.
			tryDeleteLooseObject(commonDir, commitHash)
			if bErr := shadowRefBackoff(ctx, attempt); bErr != nil {
				return bErr
			}
		}
		// Retry budget exhausted. With the flock held this means an external
		// writer beat us shadowRefMaxRetries times in a row — surface it in
		// .entire/logs/ so operators can see a stuck shadow branch.
		logging.Warn(
			logging.WithComponent(ctx, "checkpoint"),
			"shadow branch CAS retry budget exhausted",
			slog.String("shadow_branch", shadowBranchName),
			slog.Int("retries", shadowRefMaxRetries),
		)
		return fmt.Errorf("failed to update shadow branch reference after %d CAS retries: %w", shadowRefMaxRetries, ErrShadowRefBusy)
	})
	if err != nil {
		return WriteEphemeralResult{}, err
	}
	return result, nil
}

// Read reads the latest checkpoint from a shadow branch.
// Returns nil if the shadow branch doesn't exist.
// worktreeID should be empty for main worktree or the internal git worktree name for linked worktrees.
func (s *ephemeralStore) Read(ctx context.Context, baseCommit, worktreeID string) (*ReadEphemeralResult, error) {
	if err := ctx.Err(); err != nil {
		return nil, err //nolint:wrapcheck // Propagating context cancellation
	}

	shadowBranchName := ShadowBranchNameForCommit(baseCommit, worktreeID)
	refName := plumbing.NewBranchReferenceName(shadowBranchName)

	ref, err := s.repo.Reference(refName, true)
	if err != nil {
		return nil, nil //nolint:nilnil,nilerr // Branch not found is an expected case
	}

	commit, err := s.repo.CommitObject(ref.Hash())
	if err != nil {
		return nil, fmt.Errorf("failed to get commit object: %w", err)
	}

	// Extract session ID and metadata dir from commit trailers
	sessionID, _ := trailers.ParseSession(commit.Message)
	metadataDir, _ := trailers.ParseMetadata(commit.Message)

	return &ReadEphemeralResult{
		CommitHash:  ref.Hash(),
		TreeHash:    commit.TreeHash,
		SessionID:   sessionID,
		MetadataDir: metadataDir,
		Timestamp:   commit.Author.When,
	}, nil
}

// List lists all shadow branches with their checkpoint info.
func (s *ephemeralStore) List(ctx context.Context) ([]EphemeralInfo, error) {
	if err := ctx.Err(); err != nil {
		return nil, err //nolint:wrapcheck // Propagating context cancellation
	}

	iter, err := s.repo.Branches()
	if err != nil {
		return nil, fmt.Errorf("failed to list branches: %w", err)
	}

	var results []EphemeralInfo
	err = iter.ForEach(func(ref *plumbing.Reference) error {
		if err := ctx.Err(); err != nil {
			return err //nolint:wrapcheck // Propagating context cancellation
		}
		branchName := ref.Name().Short()
		if !strings.HasPrefix(branchName, ShadowBranchPrefix) {
			return nil
		}

		// Skip the primary metadata ref when it's a branch (shares the
		// entire/ prefix but isn't a shadow branch).
		if s.refs.Primary.IsBranch() && branchName == s.refs.Primary.Short() {
			return nil
		}

		commit, commitErr := s.repo.CommitObject(ref.Hash())
		if commitErr != nil {
			//nolint:nilerr // Skip branches we can't read (non-fatal)
			return nil
		}

		sessionID, _ := trailers.ParseSession(commit.Message)

		// Extract base commit from branch name (handles new "entire/<commit>-<worktreeHash>" format)
		baseCommit, _, _ := ParseShadowBranchName(branchName)

		results = append(results, EphemeralInfo{
			BranchName:   branchName,
			BaseCommit:   baseCommit,
			LatestCommit: ref.Hash(),
			SessionID:    sessionID,
			Timestamp:    commit.Author.When,
		})

		return nil
	})
	if err != nil {
		return nil, fmt.Errorf("failed to iterate branches: %w", err)
	}

	return results, nil
}

// writeTask writes a task checkpoint to a shadow branch.
// Task checkpoints include both code changes and task-specific metadata.
// Returns the commit hash of the created checkpoint.
func (s *ephemeralStore) writeTask(ctx context.Context, opts WriteEphemeralTaskOptions) (plumbing.Hash, error) {
	// Validate base commit - required for shadow branch naming
	if opts.BaseCommit == "" {
		return plumbing.ZeroHash, errors.New("BaseCommit is required for task checkpoint")
	}

	// Validate identifiers to prevent path traversal and malformed data
	if err := validation.ValidateSessionID(opts.SessionID); err != nil {
		return plumbing.ZeroHash, fmt.Errorf("invalid task checkpoint options: %w", err)
	}
	if err := validation.ValidateToolUseID(opts.ToolUseID); err != nil {
		return plumbing.ZeroHash, fmt.Errorf("invalid task checkpoint options: %w", err)
	}
	if err := validation.ValidateAgentID(opts.AgentID); err != nil {
		return plumbing.ZeroHash, fmt.Errorf("invalid task checkpoint options: %w", err)
	}

	// Get shadow branch name
	shadowBranchName := ShadowBranchNameForCommit(opts.BaseCommit, opts.WorktreeID)

	// Collect all files to include in the commit.
	// Filter out gitignored files — subagent transcripts may report files like .env
	// that exist on disk but are gitignored. Without filtering, secrets would leak
	// into the shadow branch.
	candidateFiles := make([]string, 0, len(opts.ModifiedFiles)+len(opts.NewFiles))
	candidateFiles = append(candidateFiles, opts.ModifiedFiles...)
	candidateFiles = append(candidateFiles, opts.NewFiles...)
	allFiles := filterGitIgnoredFiles(ctx, s.repo, candidateFiles)

	repoRoot, commonDir, err := s.repoDirs(ctx)
	if err != nil {
		return plumbing.ZeroHash, fmt.Errorf("failed to resolve repo dirs: %w", err)
	}

	var resultHash plumbing.Hash
	err = withShadowBranchFlock(commonDir, shadowBranchName, func() error {
		for attempt := range shadowRefMaxRetries {
			parentHash, baseTreeHash, gErr := s.getOrCreateShadowBranch(shadowBranchName)
			if gErr != nil {
				return fmt.Errorf("failed to get shadow branch: %w", gErr)
			}

			newTreeHash, tErr := s.buildTreeWithChanges(ctx, baseTreeHash, allFiles, opts.DeletedFiles, "", "")
			if tErr != nil {
				return fmt.Errorf("failed to build tree: %w", tErr)
			}

			newTreeHash, tErr = s.addTaskMetadataToTree(ctx, newTreeHash, opts)
			if tErr != nil {
				return fmt.Errorf("failed to add task metadata: %w", tErr)
			}

			commitHash, cErr := CreateCommit(ctx, s.repo, newTreeHash, parentHash, opts.CommitMessage, opts.AuthorName, opts.AuthorEmail)
			if cErr != nil {
				return fmt.Errorf("failed to create commit: %w", cErr)
			}

			refErr := casUpdateShadowBranchRef(ctx, repoRoot, shadowBranchName, commitHash, parentHash)
			if refErr == nil {
				resultHash = commitHash
				return nil
			}
			if !errors.Is(refErr, ErrShadowRefBusy) {
				return fmt.Errorf("failed to update shadow branch reference: %w", refErr)
			}
			tryDeleteLooseObject(commonDir, commitHash)
			if bErr := shadowRefBackoff(ctx, attempt); bErr != nil {
				return bErr
			}
		}
		logging.Warn(
			logging.WithComponent(ctx, "checkpoint"),
			"shadow branch CAS retry budget exhausted (task checkpoint)",
			slog.String("shadow_branch", shadowBranchName),
			slog.Int("retries", shadowRefMaxRetries),
		)
		return fmt.Errorf("failed to update shadow branch reference after %d CAS retries: %w", shadowRefMaxRetries, ErrShadowRefBusy)
	})
	if err != nil {
		return plumbing.ZeroHash, err
	}
	return resultHash, nil
}

// addTaskMetadataToTree adds task checkpoint metadata to a git tree.
// When IsIncremental is true, only adds the incremental checkpoint file.
//
// Uses ApplyTreeChanges (tree surgery) instead of FlattenTree+BuildTreeFromEntries,
// so only affected subtrees are read/rebuilt.
func (s *ephemeralStore) addTaskMetadataToTree(ctx context.Context, baseTreeHash plumbing.Hash, opts WriteEphemeralTaskOptions) (plumbing.Hash, error) {
	// Compute metadata paths
	sessionMetadataDir := paths.EntireMetadataDir + "/" + opts.SessionID
	taskMetadataDir := sessionMetadataDir + "/tasks/" + opts.ToolUseID

	var changes []TreeChange

	if opts.IsIncremental {
		// Incremental checkpoint: only add the checkpoint file
		var incData json.RawMessage
		if opts.IncrementalData != nil {
			redacted, redactErr := redact.JSONLBytes(opts.IncrementalData)
			if redactErr != nil {
				return plumbing.ZeroHash, fmt.Errorf("failed to redact incremental checkpoint: %w", redactErr)
			}
			incData = json.RawMessage(redacted.Bytes())
		}
		incrementalCheckpoint := struct {
			Type      string          `json:"type"`
			ToolUseID string          `json:"tool_use_id"`
			Timestamp time.Time       `json:"timestamp"`
			Data      json.RawMessage `json:"data"`
		}{
			Type:      opts.IncrementalType,
			ToolUseID: opts.ToolUseID,
			Timestamp: time.Now().UTC(),
			Data:      incData,
		}
		cpData, err := jsonutil.MarshalIndentWithNewline(incrementalCheckpoint, "", "  ")
		if err != nil {
			return plumbing.ZeroHash, fmt.Errorf("failed to marshal incremental checkpoint: %w", err)
		}

		cpBlobHash, err := CreateBlobFromContent(s.repo, cpData)
		if err != nil {
			return plumbing.ZeroHash, fmt.Errorf("failed to create incremental checkpoint blob: %w", err)
		}
		cpFilename := fmt.Sprintf("%03d-%s.json", opts.IncrementalSequence, opts.ToolUseID)
		cpPath := taskMetadataDir + "/checkpoints/" + cpFilename
		changes = append(changes, TreeChange{
			Path:  cpPath,
			Entry: &object.TreeEntry{Mode: filemode.Regular, Hash: cpBlobHash},
		})
	} else {
		// Final checkpoint: add transcripts and checkpoint.json

		// Add session transcript (with chunking support for large transcripts)
		if opts.TranscriptPath != "" {
			if transcriptContent, readErr := os.ReadFile(opts.TranscriptPath); readErr == nil {
				agentType := agent.DetectAgentTypeFromContent(transcriptContent)

				// Chunk if necessary
				chunks, chunkErr := agent.ChunkTranscript(ctx, transcriptContent, agentType)
				if chunkErr != nil {
					logging.Warn(
						ctx, "failed to chunk transcript, checkpoint will be saved without transcript",
						slog.String("error", chunkErr.Error()),
						slog.String("session_id", opts.SessionID),
					)
				} else {
					for i, chunk := range chunks {
						chunkPath := sessionMetadataDir + "/" + agent.ChunkFileName(paths.TranscriptFileName, i)
						blobHash, blobErr := CreateBlobFromContent(s.repo, chunk)
						if blobErr != nil {
							logging.Warn(
								ctx, "failed to create blob for transcript chunk",
								slog.String("error", blobErr.Error()),
								slog.String("session_id", opts.SessionID),
								slog.Int("chunk_index", i),
							)
							continue
						}
						changes = append(changes, TreeChange{
							Path:  chunkPath,
							Entry: &object.TreeEntry{Mode: filemode.Regular, Hash: blobHash},
						})
					}
				}
			}
		}

		// Add subagent transcript if available
		if opts.SubagentTranscriptPath != "" && opts.AgentID != "" {
			if agentContent, readErr := os.ReadFile(opts.SubagentTranscriptPath); readErr == nil {
				redacted, jsonlErr := redact.JSONLBytes(agentContent)
				if jsonlErr != nil {
					logging.Warn(
						ctx, "subagent transcript is not valid JSONL, falling back to plain redaction",
						slog.String("path", opts.SubagentTranscriptPath),
						slog.String("error", jsonlErr.Error()),
					)
					agentContent = redact.Bytes(agentContent)
				} else {
					agentContent = redacted.Bytes()
				}
				if blobHash, blobErr := CreateBlobFromContent(s.repo, agentContent); blobErr == nil {
					agentPath := taskMetadataDir + "/agent-" + opts.AgentID + ".jsonl"
					changes = append(changes, TreeChange{
						Path:  agentPath,
						Entry: &object.TreeEntry{Mode: filemode.Regular, Hash: blobHash},
					})
				}
			}
		}

		// Add checkpoint.json
		checkpointJSON := fmt.Sprintf(`{
  "session_id": %q,
  "tool_use_id": %q,
  "checkpoint_uuid": %q,
  "agent_id": %q
}`, opts.SessionID, opts.ToolUseID, opts.CheckpointUUID, opts.AgentID)

		blobHash, err := CreateBlobFromContent(s.repo, []byte(checkpointJSON))
		if err != nil {
			return plumbing.ZeroHash, fmt.Errorf("failed to create checkpoint blob: %w", err)
		}
		checkpointPath := taskMetadataDir + "/checkpoint.json"
		changes = append(changes, TreeChange{
			Path:  checkpointPath,
			Entry: &object.TreeEntry{Mode: filemode.Regular, Hash: blobHash},
		})
	}

	return ApplyTreeChanges(ctx, s.repo, baseTreeHash, changes)
}

// ListCheckpoints lists all checkpoint commits on a shadow branch.
// This returns individual commits (rewind points), not just branch info.
// The sessionID filter, if provided, limits results to commits from that session.
// worktreeID should be empty for main worktree or the internal git worktree name for linked worktrees.
func (s *ephemeralStore) ListCheckpoints(ctx context.Context, baseCommit, worktreeID, sessionID string, limit int) ([]EphemeralCheckpointInfo, error) {
	shadowBranchName := ShadowBranchNameForCommit(baseCommit, worktreeID)
	return s.listCheckpointsForBranch(ctx, shadowBranchName, sessionID, limit)
}

// ListCheckpointsForBranch lists checkpoint commits for a shadow branch by name.
// Use this when you already have the full branch name (e.g., from List).
// The sessionID filter, if provided, limits results to commits from that session.
func (s *ephemeralStore) ListCheckpointsForBranch(ctx context.Context, branchName, sessionID string, limit int) ([]EphemeralCheckpointInfo, error) {
	return s.listCheckpointsForBranch(ctx, branchName, sessionID, limit)
}

// listCheckpointsForBranch lists checkpoint commits for a specific shadow branch name.
// This is an internal helper used by ListCheckpoints, ListCheckpointsForBranch, and ListAllCheckpoints.
func (s *ephemeralStore) listCheckpointsForBranch(ctx context.Context, shadowBranchName, sessionID string, limit int) ([]EphemeralCheckpointInfo, error) {
	if err := ctx.Err(); err != nil {
		return nil, err //nolint:wrapcheck // Propagating context cancellation
	}

	refName := plumbing.NewBranchReferenceName(shadowBranchName)

	ref, err := s.repo.Reference(refName, true)
	if err != nil {
		return nil, nil //nolint:nilerr // No shadow branch is expected case
	}

	iter, err := s.repo.Log(&git.LogOptions{From: ref.Hash()})
	if err != nil {
		return nil, fmt.Errorf("failed to get commit log: %w", err)
	}

	var results []EphemeralCheckpointInfo
	count := 0

	err = iter.ForEach(func(c *object.Commit) error {
		if err := ctx.Err(); err != nil {
			return err //nolint:wrapcheck // Propagating context cancellation
		}
		if count >= limit*5 { // Scan more to allow for session filtering
			return errStop
		}
		count++

		// Verify commit belongs to target session via Entire-Session trailer
		commitSessionID, hasTrailer := trailers.ParseSession(c.Message)
		if !hasTrailer {
			return nil // Skip commits without session trailer
		}
		if sessionID != "" && commitSessionID != sessionID {
			return nil // Skip commits from other sessions
		}

		// Get first line of message
		message := c.Message
		if idx := strings.Index(message, "\n"); idx > 0 {
			message = message[:idx]
		}

		info := EphemeralCheckpointInfo{
			CommitHash: c.Hash,
			Message:    message,
			SessionID:  commitSessionID,
			Timestamp:  c.Author.When,
		}

		// Check for task checkpoint first
		taskMetadataDir, foundTask := trailers.ParseTaskMetadata(c.Message)
		if foundTask {
			info.IsTaskCheckpoint = true
			info.MetadataDir = taskMetadataDir
			info.ToolUseID = extractToolUseIDFromPath(taskMetadataDir)
		} else {
			metadataDir, found := trailers.ParseMetadata(c.Message)
			if found {
				info.MetadataDir = metadataDir
			}
		}

		results = append(results, info)

		if len(results) >= limit {
			return errStop
		}
		return nil
	})

	if err != nil && !errors.Is(err, errStop) {
		return nil, fmt.Errorf("error iterating commits: %w", err)
	}

	return results, nil
}

// ListAllCheckpoints lists checkpoint commits from ALL shadow branches.
// This is used for checkpoint lookup when the base commit is unknown (e.g., HEAD advanced since session start).
// The sessionID filter, if provided, limits results to commits from that session.
func (s *ephemeralStore) ListAllCheckpoints(ctx context.Context, sessionID string, limit int) ([]EphemeralCheckpointInfo, error) {
	if err := ctx.Err(); err != nil {
		return nil, err //nolint:wrapcheck // Propagating context cancellation
	}

	// List all shadow branches
	branches, err := s.List(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to list shadow branches: %w", err)
	}

	var results []EphemeralCheckpointInfo

	// Iterate through each shadow branch and collect checkpoints
	for _, branch := range branches {
		// Use the branch name directly to get checkpoints
		branchCheckpoints, branchErr := s.listCheckpointsForBranch(ctx, branch.BranchName, sessionID, limit)
		if branchErr != nil {
			if errors.Is(branchErr, context.Canceled) || errors.Is(branchErr, context.DeadlineExceeded) {
				return nil, branchErr
			}
			continue // Skip branches we can't read
		}
		results = append(results, branchCheckpoints...)
		if len(results) >= limit {
			results = results[:limit]
			break
		}
	}

	return results, nil
}

// extractToolUseIDFromPath extracts the ToolUseID from a task metadata directory path.
// Task metadata dirs have format: .entire/metadata/<session>/tasks/<toolUseID>
func extractToolUseIDFromPath(metadataDir string) string {
	parts := strings.Split(metadataDir, "/")
	if len(parts) >= 2 && parts[len(parts)-2] == "tasks" {
		return parts[len(parts)-1]
	}
	return ""
}

// errStop is a sentinel error used to break out of git log iteration.
var errStop = errors.New("stop iteration")

// GetTranscriptFromCommit retrieves the transcript from a specific commit's tree.
// This is used for shadow branch checkpoints where the transcript is stored in the commit tree
// rather than on the entire/checkpoints/v1 branch.
// commitHash is the commit to read from, metadataDir is the path within the tree.
// agentType is used for reassembling chunked transcripts in the correct format.
// Handles both chunked and non-chunked transcripts.
func (s *ephemeralStore) GetTranscriptFromCommit(ctx context.Context, commitHash plumbing.Hash, metadataDir string, agentType types.AgentType) ([]byte, error) {
	commit, err := s.repo.CommitObject(commitHash)
	if err != nil {
		return nil, fmt.Errorf("failed to get commit: %w", err)
	}

	tree, err := commit.Tree()
	if err != nil {
		return nil, fmt.Errorf("failed to get commit tree: %w", err)
	}

	// Try to get the metadata subtree for chunk detection
	subTree, subTreeErr := tree.Tree(metadataDir)
	if subTreeErr == nil {
		// Use the helper function that handles chunking.
		// Wrap in FetchingTree with nil fetcher (temporary reads are always local).
		ft := &FetchingTree{inner: subTree}
		transcript, err := readTranscriptFromTree(ctx, ft, agentType)
		if err == nil && transcript != nil {
			return transcript, nil
		}
	}

	// Fall back to direct file access (for backwards compatibility)
	transcriptPath := metadataDir + "/" + paths.TranscriptFileName
	if file, fileErr := tree.File(transcriptPath); fileErr == nil {
		content, contentErr := file.Contents()
		if contentErr == nil {
			return []byte(content), nil
		}
	}

	transcriptPath = metadataDir + "/" + paths.TranscriptFileNameLegacy
	if file, fileErr := tree.File(transcriptPath); fileErr == nil {
		content, contentErr := file.Contents()
		if contentErr == nil {
			return []byte(content), nil
		}
	}

	return nil, ErrNoTranscript
}

// ShadowBranchExists checks if a shadow branch exists for the given base commit and worktree.
// worktreeID should be empty for main worktree or the internal git worktree name for linked worktrees.
func (s *ephemeralStore) ShadowBranchExists(baseCommit, worktreeID string) bool {
	shadowBranchName := ShadowBranchNameForCommit(baseCommit, worktreeID)
	refName := plumbing.NewBranchReferenceName(shadowBranchName)
	_, err := s.repo.Reference(refName, true)
	return err == nil
}

// DeleteShadowBranch deletes the shadow branch for the given base commit and worktree.
// worktreeID should be empty for main worktree or the internal git worktree name for linked worktrees.
// Uses git CLI instead of go-git's RemoveReference because go-git v5 doesn't properly
// persist deletions with packed refs or worktrees.
func (s *ephemeralStore) DeleteShadowBranch(ctx context.Context, baseCommit, worktreeID string) error {
	shadowBranchName := ShadowBranchNameForCommit(baseCommit, worktreeID)
	cmd := exec.CommandContext(ctx, "git", "branch", "-D", "--", shadowBranchName)
	if output, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("failed to delete shadow branch %s: %s: %w", shadowBranchName, strings.TrimSpace(string(output)), err)
	}
	return nil
}

// ShadowBranchNameForCommit returns the shadow branch name for a base commit hash
// and worktree identifier. The worktree ID should be empty for the main worktree
// or the internal git worktree name for linked worktrees.
// Format: entire/<commit[:7]>-<hash(worktreeID)[:6]>
func ShadowBranchNameForCommit(baseCommit, worktreeID string) string {
	commitPart := baseCommit
	if len(baseCommit) >= ShadowBranchHashLength {
		commitPart = baseCommit[:ShadowBranchHashLength]
	}
	worktreeHash := HashWorktreeID(worktreeID)
	return ShadowBranchPrefix + commitPart + "-" + worktreeHash
}

// ParseShadowBranchName extracts the commit prefix and worktree hash from a shadow branch name.
// Input format: "entire/<commit[:7]>-<worktreeHash[:6]>"
// Returns (commitPrefix, worktreeHash, ok). Returns ("", "", false) if not a valid shadow branch.
func ParseShadowBranchName(branchName string) (commitPrefix, worktreeHash string, ok bool) {
	if !strings.HasPrefix(branchName, ShadowBranchPrefix) {
		return "", "", false
	}
	suffix := strings.TrimPrefix(branchName, ShadowBranchPrefix)

	// Find the last dash - everything before is commit prefix, after is worktree hash
	lastDash := strings.LastIndex(suffix, "-")
	if lastDash == -1 || lastDash == 0 || lastDash == len(suffix)-1 {
		// No dash, or dash at start/end - invalid format
		// Could be old format "entire/<commit[:7]>" without worktree hash
		return suffix, "", true // Return as commit prefix with empty worktree hash
	}

	return suffix[:lastDash], suffix[lastDash+1:], true
}

// getOrCreateShadowBranch gets or creates the shadow branch for checkpoints.
// Returns (parentHash, baseTreeHash, error).
func (s *ephemeralStore) getOrCreateShadowBranch(branchName string) (plumbing.Hash, plumbing.Hash, error) {
	refName := plumbing.NewBranchReferenceName(branchName)
	ref, err := s.repo.Reference(refName, true)

	if err == nil {
		// Branch exists
		commit, err := s.repo.CommitObject(ref.Hash())
		if err != nil {
			return plumbing.ZeroHash, plumbing.ZeroHash, fmt.Errorf("failed to get commit object: %w", err)
		}
		return ref.Hash(), commit.TreeHash, nil
	}

	// Branch doesn't exist, use current HEAD's tree as base
	head, err := s.repo.Head()
	if err != nil {
		return plumbing.ZeroHash, plumbing.ZeroHash, fmt.Errorf("failed to get HEAD: %w", err)
	}

	headCommit, err := s.repo.CommitObject(head.Hash())
	if err != nil {
		return plumbing.ZeroHash, plumbing.ZeroHash, fmt.Errorf("failed to get HEAD commit: %w", err)
	}

	return plumbing.ZeroHash, headCommit.TreeHash, nil
}

// buildTreeWithChanges builds a git tree with the given changes.
// metadataDir is the relative path for git tree entries, metadataDirAbs is the absolute path
// for filesystem operations (needed when CLI is run from a subdirectory).
//
// Uses ApplyTreeChanges (tree surgery) instead of FlattenTree+BuildTreeFromEntries,
// so only affected subtrees are read/rebuilt — O(changed dirs) instead of O(total files).
func (s *ephemeralStore) buildTreeWithChanges(
	ctx context.Context,
	baseTreeHash plumbing.Hash,
	modifiedFiles, deletedFiles []string,
	metadataDir, metadataDirAbs string,
) (plumbing.Hash, error) {
	// Get worktree root for resolving file paths
	// This is critical because fileExists() and createBlobFromFile() use os.Stat()
	// which resolves relative to CWD. The modifiedFiles are repo-relative paths,
	// so we must resolve them against repo root, not CWD.
	repoRoot, err := paths.WorktreeRoot(ctx)
	if err != nil {
		return plumbing.ZeroHash, fmt.Errorf("failed to get worktree root: %w", err)
	}

	// Build list of tree changes
	changes := make([]TreeChange, 0, len(modifiedFiles)+len(deletedFiles))

	// Deleted files → nil Entry means deletion
	for _, file := range deletedFiles {
		relPath, relErr := normalizeRepoRelativeTreePath(repoRoot, file)
		if relErr != nil {
			logInvalidGitTreePath(ctx, "delete shadow branch entry", file, relErr)
			continue
		}
		changes = append(changes, TreeChange{Path: relPath, Entry: nil})
	}

	// Modified/new files → create blobs from disk
	for _, file := range modifiedFiles {
		relPath, relErr := normalizeRepoRelativeTreePath(repoRoot, file)
		if relErr != nil {
			logInvalidGitTreePath(ctx, "add shadow branch entry", file, relErr)
			continue
		}

		absPath := filepath.Join(repoRoot, filepath.FromSlash(relPath))
		if !fileExists(absPath) {
			// File disappeared since detection — treat as deletion
			changes = append(changes, TreeChange{Path: relPath, Entry: nil})
			continue
		}

		blobHash, mode, blobErr := createBlobFromFile(s.repo, absPath)
		if blobErr != nil {
			// Skip files that can't be staged (may have been deleted since detection)
			continue
		}

		changes = append(changes, TreeChange{
			Path: relPath,
			Entry: &object.TreeEntry{
				Mode: mode,
				Hash: blobHash,
			},
		})
	}

	// Metadata directory files
	if metadataDir != "" && metadataDirAbs != "" {
		metadataRel, relErr := normalizeRepoRelativeTreePath(repoRoot, metadataDir)
		if relErr != nil {
			logInvalidGitTreePath(ctx, "add metadata directory", metadataDir, relErr)
		} else {
			metaChanges, metaErr := addDirectoryToChanges(ctx, s.repo, metadataDirAbs, metadataRel)
			if metaErr != nil {
				return plumbing.ZeroHash, fmt.Errorf("failed to add metadata directory: %w", metaErr)
			}
			changes = append(changes, metaChanges...)
		}
	}

	return ApplyTreeChanges(ctx, s.repo, baseTreeHash, changes)
}

// Helper functions extracted from strategy/common.go
// These are exported for use by strategy package (push_common.go, session_test.go)

// FlattenTree recursively flattens a tree into a map of full paths to entries.
func FlattenTree(repo *git.Repository, tree *object.Tree, prefix string, entries map[string]object.TreeEntry) error {
	for _, entry := range tree.Entries {
		fullPath := entry.Name
		if prefix != "" {
			fullPath = prefix + "/" + entry.Name
		}

		if entry.Mode == filemode.Dir {
			// Recurse into subtree
			subtree, err := repo.TreeObject(entry.Hash)
			if err != nil {
				return fmt.Errorf("failed to get subtree %s: %w", fullPath, err)
			}
			if err := FlattenTree(repo, subtree, fullPath, entries); err != nil {
				return err
			}
		} else {
			entries[fullPath] = object.TreeEntry{
				Name: fullPath,
				Mode: entry.Mode,
				Hash: entry.Hash,
			}
		}
	}
	return nil
}

// fileExists checks if a file exists at the given path.
func fileExists(path string) bool {
	_, err := os.Lstat(path)
	return err == nil
}

// createBlobFromFile creates a blob object from a file in the working directory.
func createBlobFromFile(repo *git.Repository, filePath string) (plumbing.Hash, filemode.FileMode, error) {
	info, err := os.Lstat(filePath)
	if err != nil {
		return plumbing.ZeroHash, 0, fmt.Errorf("failed to stat file: %w", err)
	}

	// Determine file mode
	mode := filemode.Regular
	if info.Mode()&os.ModeSymlink != 0 {
		mode = filemode.Symlink
	} else if info.Mode()&0o111 != 0 {
		mode = filemode.Executable
	}

	// Read file contents
	var content []byte
	if mode == filemode.Symlink {
		target, readErr := os.Readlink(filePath)
		if readErr != nil {
			return plumbing.ZeroHash, 0, fmt.Errorf("failed to read symlink: %w", readErr)
		}
		content = []byte(target)
	} else {
		content, err = os.ReadFile(filePath) //nolint:gosec // filePath comes from walking the repository
		if err != nil {
			return plumbing.ZeroHash, 0, fmt.Errorf("failed to read file: %w", err)
		}
	}

	// Create blob object
	obj := repo.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	obj.SetSize(int64(len(content)))

	writer, err := obj.Writer()
	if err != nil {
		return plumbing.ZeroHash, 0, fmt.Errorf("failed to get object writer: %w", err)
	}

	_, err = writer.Write(content)
	if err != nil {
		_ = writer.Close()
		return plumbing.ZeroHash, 0, fmt.Errorf("failed to write blob content: %w", err)
	}
	if err := writer.Close(); err != nil {
		return plumbing.ZeroHash, 0, fmt.Errorf("failed to close blob writer: %w", err)
	}

	hash, err := repo.Storer.SetEncodedObject(obj)
	if err != nil {
		return plumbing.ZeroHash, 0, fmt.Errorf("failed to store blob object: %w", err)
	}

	return hash, mode, nil
}

// treeNode represents a node in our tree structure.
type treeNode struct {
	entries map[string]*treeNode // subdirectories
	files   []object.TreeEntry   // files in this directory
}

// addDirectoryToChanges walks a filesystem directory and returns TreeChange entries
// for each file, suitable for use with ApplyTreeChanges.
// dirPathAbs is the absolute filesystem path; dirPathRel is the git tree-relative path.
func addDirectoryToChanges(ctx context.Context, repo *git.Repository, dirPathAbs, dirPathRel string) ([]TreeChange, error) {
	var changes []TreeChange
	err := filepath.Walk(dirPathAbs, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// Skip symlinks to prevent reading files outside the metadata directory.
		// A symlink could point to sensitive files (e.g., /etc/passwd) which would
		// then be captured in the checkpoint and stored in git history.
		// NOTE: filepath.Walk uses os.Stat (follows symlinks), so info.Mode() never
		// reports ModeSymlink. We use os.Lstat to check the entry itself.
		// This check MUST come before IsDir() because Walk follows symlinked
		// directories and would recurse into them otherwise.
		linfo, lstatErr := os.Lstat(path)
		if lstatErr != nil {
			return fmt.Errorf("failed to lstat %s: %w", path, lstatErr)
		}
		if linfo.Mode()&os.ModeSymlink != 0 {
			if info.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		if info.IsDir() {
			return nil
		}

		relWithinDir, relErr := filepath.Rel(dirPathAbs, path)
		if relErr != nil {
			return fmt.Errorf("failed to get relative path for %s: %w", path, relErr)
		}
		if paths.IsRelativeTraversal(relWithinDir) {
			return fmt.Errorf("path traversal detected: %s", relWithinDir)
		}

		treePath := filepath.ToSlash(filepath.Join(dirPathRel, relWithinDir))

		blobHash, mode, blobErr := createRedactedBlobFromFile(ctx, repo, path, treePath)
		if blobErr != nil {
			return fmt.Errorf("failed to create blob for %s: %w", path, blobErr)
		}
		changes = append(changes, TreeChange{
			Path:  treePath,
			Entry: &object.TreeEntry{Mode: mode, Hash: blobHash},
		})
		return nil
	})
	if err != nil {
		return nil, fmt.Errorf("failed to walk directory %s: %w", dirPathAbs, err)
	}
	return changes, nil
}

// BuildTreeFromEntries builds a proper git tree structure from flattened file entries.
// Exported for use by strategy package (push_common.go, session_test.go)
func BuildTreeFromEntries(ctx context.Context, repo *git.Repository, entries map[string]object.TreeEntry) (plumbing.Hash, error) {
	// Build a tree structure
	root := &treeNode{
		entries: make(map[string]*treeNode),
		files:   []object.TreeEntry{},
	}

	// Insert all entries into the tree structure
	for fullPath, entry := range entries {
		normalizedPath, err := normalizeGitTreePath(fullPath)
		if err != nil {
			logInvalidGitTreePath(ctx, "build tree entry", fullPath, err)
			continue
		}
		parts := strings.Split(normalizedPath, "/")
		insertIntoTree(root, parts, entry)
	}

	// Recursively build tree objects from bottom up
	return buildTreeObject(repo, root)
}

func normalizeRepoRelativeTreePath(repoRoot, path string) (string, error) {
	if rel := paths.ToRelativePath(path, repoRoot); rel != "" && rel != "." {
		return normalizeGitTreePath(rel)
	}

	return normalizeGitTreePath(path)
}

// insertIntoTree inserts a file entry into the tree structure.
func insertIntoTree(node *treeNode, pathParts []string, entry object.TreeEntry) {
	if len(pathParts) == 1 {
		// This is a file in the current directory
		node.files = append(node.files, object.TreeEntry{
			Name: pathParts[0],
			Mode: entry.Mode,
			Hash: entry.Hash,
		})
		return
	}

	// This is in a subdirectory
	dirName := pathParts[0]
	if node.entries[dirName] == nil {
		node.entries[dirName] = &treeNode{
			entries: make(map[string]*treeNode),
			files:   []object.TreeEntry{},
		}
	}
	insertIntoTree(node.entries[dirName], pathParts[1:], entry)
}

// buildTreeObject recursively builds tree objects from a treeNode.
func buildTreeObject(repo *git.Repository, node *treeNode) (plumbing.Hash, error) {
	var treeEntries []object.TreeEntry

	// Add files
	treeEntries = append(treeEntries, node.files...)

	// Recursively build subtrees
	for name, subnode := range node.entries {
		subHash, err := buildTreeObject(repo, subnode)
		if err != nil {
			return plumbing.ZeroHash, err
		}
		treeEntries = append(treeEntries, object.TreeEntry{
			Name: name,
			Mode: filemode.Dir,
			Hash: subHash,
		})
	}

	// Sort entries (git requires sorted entries)
	sortTreeEntries(treeEntries)

	// Create tree object
	tree := &object.Tree{Entries: treeEntries}

	obj := repo.Storer.NewEncodedObject()
	if err := tree.Encode(obj); err != nil {
		return plumbing.ZeroHash, fmt.Errorf("failed to encode tree: %w", err)
	}

	hash, err := repo.Storer.SetEncodedObject(obj)
	if err != nil {
		return plumbing.ZeroHash, fmt.Errorf("failed to store tree: %w", err)
	}

	return hash, nil
}

// sortTreeEntries sorts tree entries in git's required order.
// Git sorts tree entries by name, with directories having a trailing /
func sortTreeEntries(entries []object.TreeEntry) {
	sort.Slice(entries, func(i, j int) bool {
		nameI := entries[i].Name
		nameJ := entries[j].Name
		if entries[i].Mode == filemode.Dir {
			nameI += "/"
		}
		if entries[j].Mode == filemode.Dir {
			nameJ += "/"
		}
		return nameI < nameJ
	})
}

// collectChangedFiles collects all changed files (modified tracked + untracked non-ignored)
// using git CLI. This is much faster than filesystem walk and respects all gitignore sources
// including global gitignore (core.excludesfile).
//
// Uses git CLI instead of go-git because go-git's worktree.Status() does not respect
// global gitignore, which can cause globally ignored files to appear as untracked.
// See: https://github.com/GrayCodeAI/swift/pull/129
//
// changedFilesResult contains both changed and deleted files from git status.
type changedFilesResult struct {
	Changed []string // Files to include (modified, added, untracked, renamed, etc.)
	Deleted []string // Files that were deleted (need to be excluded from checkpoint tree)
}

// filterGitIgnoredFiles removes gitignored files from the list using `git check-ignore`.
// This prevents secrets in gitignored files (e.g., .env) from leaking into shadow branch
// commits when agents report them as modified/new in their transcripts.
// On failure, fails closed (returns nil) to avoid leaking secrets.
func filterGitIgnoredFiles(ctx context.Context, repo *git.Repository, files []string) []string {
	if len(files) == 0 {
		return files
	}

	wt, err := repo.Worktree()
	if err != nil {
		logging.Warn(logging.WithComponent(ctx, "checkpoint"),
			"failed to inspect worktree for gitignore filtering, excluding all files from checkpoint",
			slog.String("error", err.Error()))
		return nil
	}
	repoRoot := wt.Filesystem().Root()

	// Use git check-ignore to identify which files are ignored.
	// Pass files via stdin (-z for NUL-separated, --stdin) to handle special characters.
	// Use --no-index so even tracked files that still match ignore rules are filtered.
	cmd := exec.CommandContext(ctx, "git", "check-ignore", "--no-index", "-z", "--stdin")
	cmd.Dir = repoRoot
	cmd.Stdin = strings.NewReader(strings.Join(files, "\x00") + "\x00")

	output, err := cmd.Output()
	if err != nil {
		exitErr := &exec.ExitError{}
		if errors.As(err, &exitErr) && exitErr.ExitCode() == 1 {
			// Exit code 1 means no files are ignored — all files are safe.
			return files
		}
		// Any other failure (exit 128, git not found, etc.): fail closed.
		// A missing checkpoint is better than leaked secrets.
		logging.Warn(logging.WithComponent(ctx, "checkpoint"),
			"git check-ignore failed, excluding all files from checkpoint",
			slog.String("error", err.Error()))
		return nil
	}

	// Parse NUL-separated output of ignored file names
	ignored := make(map[string]struct{})
	for _, name := range strings.Split(string(output), "\x00") {
		if name != "" {
			ignored[name] = struct{}{}
		}
	}

	// Filter: keep only files that are not ignored
	var kept []string
	filteredCount := 0
	for _, file := range files {
		if _, isIgnored := ignored[file]; isIgnored {
			filteredCount++
			continue
		}
		kept = append(kept, file)
	}

	if filteredCount > 0 {
		logging.Debug(logging.WithComponent(ctx, "checkpoint"),
			"filtered gitignored files from checkpoint",
			slog.Int("count", filteredCount))
	}

	return kept
}

// isProtectedCheckpointPath reports whether a repo-relative path must be kept
// out of checkpoint snapshots: the .entire infrastructure dir, or any
// registered agent's declared protected dir/file (e.g. .claude, or an external
// plugin's protected_dirs).
//
// This mirrors shouldIgnoreSessionTrackingPath in the cli package. The two
// cannot share an implementation because cli imports checkpoint, so the logic
// is duplicated deliberately. The first-checkpoint path (collectChangedFiles)
// must apply the same exclusions as the session-tracking and rewind paths, or
// protected-dir content is captured into the shadow tree on session start
// (see the DetectFileChanges / isProtectedPath call sites).
func isProtectedCheckpointPath(relPath string) bool {
	cleanPath := filepath.Clean(filepath.FromSlash(relPath))
	if paths.IsInfrastructurePath(cleanPath) {
		return true
	}
	for _, file := range agent.AllProtectedFiles() {
		if paths.Equal(cleanPath, file) {
			return true
		}
	}
	for _, dir := range agent.AllProtectedDirs() {
		if paths.IsProtectedSubpath(filepath.Clean(filepath.FromSlash(dir)), cleanPath) {
			return true
		}
	}
	return false
}

// collectChangedFiles returns all changed files from git status for the first checkpoint.
//
// For the first checkpoint, we need to capture:
// - Modified tracked files (user's uncommitted changes)
// - Untracked non-ignored files (new files not yet added to git)
// - Renamed/copied files (both source removal and destination)
// - Deleted files (to exclude from checkpoint tree)
//
// The base tree from HEAD already contains all unchanged tracked files.
//
// Uses `git status --porcelain -z` for reliable parsing of filenames with special characters.
func collectChangedFiles(ctx context.Context, repo *git.Repository) (changedFilesResult, error) {
	// Get worktree root directory for running git command
	wt, err := repo.Worktree()
	if err != nil {
		return changedFilesResult{}, fmt.Errorf("failed to get worktree: %w", err)
	}
	repoRoot := wt.Filesystem().Root()

	// Use -z for NUL-separated output (handles quoted filenames with spaces/special chars)
	// Use -uall to list individual untracked files instead of collapsed directories.
	// Note: CLAUDE.md warns against -uall for user-facing display, but we need the full list
	// for checkpointing.
	cmd := exec.CommandContext(ctx, "git", "status", "--porcelain", "-z", "-uall")
	cmd.Dir = repoRoot
	output, err := cmd.Output()
	if err != nil {
		return changedFilesResult{}, fmt.Errorf("failed to get git status in %s: %w", repoRoot, err)
	}

	changedSeen := make(map[string]struct{})
	deletedSeen := make(map[string]struct{})

	// Parse NUL-separated output
	// Format: XY filename\0 (for most entries)
	// For renames/copies: XY newname\0oldname\0
	entries := strings.Split(string(output), "\x00")

	for i := 0; i < len(entries); i++ {
		entry := entries[i]
		if len(entry) < 3 {
			continue
		}

		// git status --porcelain format: XY filename
		// X = staging status, Y = worktree status
		staging := entry[0]
		wtStatus := entry[1]
		filename := entry[3:] // No TrimSpace needed with -z format

		// Handle R/C (rename/copy) first - they have a second entry we must skip
		// even if the new filename is a protected path
		if staging == 'R' || staging == 'C' {
			// Renamed or copied: current entry is new name, next entry is old name
			if !isProtectedCheckpointPath(filename) {
				changedSeen[filename] = struct{}{}
			}
			// The old name follows as the next NUL-separated entry - must always skip it
			if i+1 < len(entries) && entries[i+1] != "" {
				oldName := entries[i+1]
				if staging == 'R' && !isProtectedCheckpointPath(oldName) {
					// For renames, old file is effectively deleted
					deletedSeen[oldName] = struct{}{}
				}
				i++ // Skip the old name entry
			}
			continue
		}

		// Skip .entire and agent-protected dirs/files for non-R/C entries
		if isProtectedCheckpointPath(filename) {
			continue
		}

		// Handle different status codes
		switch {
		case staging == 'D' || wtStatus == 'D':
			// Deleted file - track separately
			deletedSeen[filename] = struct{}{}

		case wtStatus == 'M' || wtStatus == 'A':
			// Modified or added in worktree
			changedSeen[filename] = struct{}{}

		case staging == '?' && wtStatus == '?':
			// Untracked file
			changedSeen[filename] = struct{}{}

		case staging == 'A' || staging == 'M':
			// Staged add or modify
			changedSeen[filename] = struct{}{}

		case staging == 'T' || wtStatus == 'T':
			// Type change (e.g., file to symlink)
			changedSeen[filename] = struct{}{}

		case staging == 'U' || wtStatus == 'U':
			// Unmerged (conflict) - include current file state
			changedSeen[filename] = struct{}{}
		}
	}

	changed := make([]string, 0, len(changedSeen))
	for file := range changedSeen {
		changed = append(changed, file)
	}

	deleted := make([]string, 0, len(deletedSeen))
	for file := range deletedSeen {
		deleted = append(deleted, file)
	}

	return changedFilesResult{Changed: changed, Deleted: deleted}, nil
}
