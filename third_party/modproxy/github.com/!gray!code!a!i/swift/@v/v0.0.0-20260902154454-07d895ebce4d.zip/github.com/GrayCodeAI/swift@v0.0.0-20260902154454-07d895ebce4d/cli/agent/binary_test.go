package agent

import (
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// fakeExe returns an executable resolver pointing at a binary named name.
func fakeExe(name string) func() (string, error) {
	return func() (string, error) { return filepath.Join("/usr/local/bin", name), nil }
}

// failingExe simulates an os.Executable that cannot resolve the running binary.
func failingExe() func() (string, error) {
	return func() (string, error) { return "", errors.New("unavailable") }
}

// notOnPath simulates LookPath finding nothing.
func notOnPath(string) (string, error) {
	return "", &os.PathError{Op: "exec.LookPath", Path: "x", Err: os.ErrNotExist}
}

// onPath returns a LookPath stub that resolves exactly the given names.
func onPath(names ...string) func(string) (string, error) {
	return func(name string) (string, error) {
		for _, want := range names {
			if name == want {
				return filepath.Join("/bin", name), nil
			}
		}
		return "", &os.PathError{Op: "exec.LookPath", Path: name, Err: os.ErrNotExist}
	}
}

// TestHookCommandPrefix_ResolutionOrder covers the priority order with
// injected executable/PATH probes:
//
//  1. known executable basename (swift / entire / hawk, ".exe" stripped)
//  2. "swift" reachable on PATH
//  3. legacy "entire" reachable on PATH
//  4. legacy "entire" as final fallback (the historical baked default)
func TestHookCommandPrefix_ResolutionOrder(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	cases := []struct {
		name     string
		exe      func() (string, error)
		lookPath func(string) (string, error)
		want     string
	}{
		{"swift executable wins over PATH", fakeExe("swift"), onPath("entire"), "swift"},
		{"entire executable keeps legacy name", fakeExe("entire"), notOnPath, "entire"},
		{"hawk executable embeds as hawk swift", fakeExe("hawk"), notOnPath, "hawk swift"},
		{"windows exe suffix is stripped", fakeExe("hawk.exe"), notOnPath, "hawk swift"},
		{"unknown executable falls back to swift on PATH", fakeExe("cli.test"), onPath("swift"), "swift"},
		{"unknown executable prefers swift over legacy entire", fakeExe("cli.test"), onPath("swift", "entire"), "swift"},
		{"unknown executable falls back to legacy entire", fakeExe("cli.test"), onPath("entire"), "entire"},
		{"nothing resolvable keeps historical default", failingExe(), notOnPath, "entire"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			restore := SetHookBinaryResolutionForTesting(tc.exe, tc.lookPath)
			defer restore()
			if got := HookCommandPrefix(); got != tc.want {
				t.Fatalf("HookCommandPrefix() = %q, want %q", got, tc.want)
			}
		})
	}
}

// TestHookCommandPrefix_FakePATH exercises the PATH-probing steps with the
// real exec.LookPath against a controlled PATH containing fake binaries.
func TestHookCommandPrefix_FakePATH(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam and PATH.

	makeBinDir := func(t *testing.T, names ...string) string {
		t.Helper()
		dir := t.TempDir()
		for _, name := range names {
			if err := os.WriteFile(filepath.Join(dir, name), []byte("#!/bin/sh\nexit 0\n"), 0o755); err != nil {
				t.Fatalf("writing fake %s: %v", name, err)
			}
		}
		return dir
	}

	cases := []struct {
		name string
		bins []string
		want string
	}{
		{"swift on PATH", []string{"swift"}, "swift"},
		{"only legacy entire on PATH", []string{"entire"}, "entire"},
		{"both on PATH prefers swift", []string{"swift", "entire"}, "swift"},
		{"empty PATH keeps legacy default", nil, "entire"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			t.Setenv("PATH", makeBinDir(t, tc.bins...))
			restore := SetHookBinaryResolutionForTesting(failingExe(), exec.LookPath)
			defer restore()
			if got := HookCommandPrefix(); got != tc.want {
				t.Fatalf("HookCommandPrefix() = %q, want %q", got, tc.want)
			}
		})
	}
}

// TestWrapProductionSilentHookCommand_AdaptsResolvedBinary verifies the
// wrapper probes and execs the resolved binary instead of the legacy literal.
func TestWrapProductionSilentHookCommand_AdaptsResolvedBinary(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	restore := SetHookBinaryResolutionForTesting(fakeExe("hawk"), notOnPath)
	defer restore()

	command := WrapProductionSilentHookCommand("entire hooks claude-code stop")

	if !strings.Contains(command, "command -v hawk >/dev/null 2>&1") {
		t.Fatalf("wrapper should probe the embedding host binary, got %q", command)
	}
	if !strings.Contains(command, "exec hawk swift hooks claude-code stop") {
		t.Fatalf("wrapper should exec the embedded command path, got %q", command)
	}
	if strings.Contains(command, "exec entire") {
		t.Fatalf("wrapper must not exec the legacy binary once resolved, got %q", command)
	}
}

// TestWrapWindowsProductionSilentHookCommand_AdaptsResolvedBinary is the
// cmd.exe-wrapper counterpart of the adaptation check.
func TestWrapWindowsProductionSilentHookCommand_AdaptsResolvedBinary(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	restore := SetHookBinaryResolutionForTesting(fakeExe("swift"), notOnPath)
	defer restore()

	command := WrapWindowsProductionSilentHookCommand("entire hooks codex stop")

	if !strings.Contains(command, "where.exe swift >nul 2>nul") {
		t.Fatalf("windows wrapper should probe the resolved binary, got %q", command)
	}
	if !strings.Contains(command, "(swift hooks codex stop)") {
		t.Fatalf("windows wrapper should exec the resolved binary, got %q", command)
	}
}

// TestWrapProductionSilentHookCommand_KeepsNonLegacyCommands verifies local-dev
// and absolute-path commands pass through the wrapper unmodified.
func TestWrapProductionSilentHookCommand_KeepsNonLegacyCommands(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	restore := SetHookBinaryResolutionForTesting(fakeExe("hawk"), notOnPath)
	defer restore()

	command := WrapProductionSilentHookCommand(`"$(git rev-parse --show-toplevel)"/scripts/entire-dev hooks cursor stop`)

	if !strings.Contains(command, `exec "$(git rev-parse --show-toplevel)"/scripts/entire-dev hooks cursor stop`) {
		t.Fatalf("non-legacy command should pass through unchanged, got %q", command)
	}
}

// TestWrapProductionSilentHookCommand_LegacyResolutionIsUnchanged pins the
// historical output when resolution lands on the legacy binary.
func TestWrapProductionSilentHookCommand_LegacyResolutionIsUnchanged(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	restore := SetHookBinaryResolutionForTesting(fakeExe("entire"), notOnPath)
	defer restore()

	command := WrapProductionSilentHookCommand("entire hooks codex stop")
	want := `sh -c 'if ! command -v entire >/dev/null 2>&1; then exit 0; fi; exec entire hooks codex stop'`
	if command != want {
		t.Fatalf("legacy resolution should reproduce the historical wrapper:\ngot:  %s\nwant: %s", command, want)
	}
}

// TestIsManagedHookCommand_RecognizesRebrandedForms verifies uninstall/upgrade
// recognition keeps working for hooks baked with the new binary names even
// when the caller's prefix list still names only the legacy binary.
func TestIsManagedHookCommand_RecognizesRebrandedForms(t *testing.T) {
	// No t.Parallel(): mutates the package-level resolution seam.

	restore := SetHookBinaryResolutionForTesting(fakeExe("hawk"), notOnPath)
	defer restore()
	legacyOnly := []string{"entire "}

	direct := []string{
		"swift hooks codex stop",
		"hawk swift hooks claude-code session-start",
		"entire hooks codex stop", // legacy direct form still recognized
	}
	for _, command := range direct {
		if !IsManagedHookCommand(command, legacyOnly) {
			t.Errorf("expected direct command to be managed: %q", command)
		}
	}

	wrapped := []string{
		WrapProductionSilentHookCommand("entire hooks cursor stop"),
		WrapProductionJSONWarningHookCommand("entire hooks claude-code session-start", WarningFormatSingleLine),
		WrapWindowsProductionSilentHookCommand("entire hooks codex stop"),
	}
	for _, command := range wrapped {
		if !IsManagedHookCommand(command, legacyOnly) {
			t.Errorf("expected rebranded wrapper to be managed: %q", command)
		}
	}

	// Legacy wrappers written by older builds remain recognized.
	legacyWrapper := `sh -c 'if ! command -v entire >/dev/null 2>&1; then exit 0; fi; exec entire hooks codex stop'`
	if !IsManagedHookCommand(legacyWrapper, legacyOnly) {
		t.Error("expected legacy wrapper to remain managed")
	}
}
