package agent

import (
	"context"
	"io"
	"testing"

	"github.com/GrayCodeAI/swift/cli/agent/types"
)

const (
	mockAgentName types.AgentName = "mock" // Used by mock implementations
	mockAgentType types.AgentType = "Mock Agent"
)

// mockAgent is a minimal implementation of Agent for testing interface compliance.
type mockAgent struct{}

var _ Agent = (*mockAgent)(nil) // Compile-time interface check

func (m *mockAgent) Name() types.AgentName                          { return mockAgentName }
func (m *mockAgent) Type() types.AgentType                          { return mockAgentType }
func (m *mockAgent) Description() string                            { return "Mock agent for testing" }
func (m *mockAgent) IsPreview() bool                                { return false }
func (m *mockAgent) DetectPresence(_ context.Context) (bool, error) { return false, nil }

func (m *mockAgent) GetSessionID(_ *HookInput) string { return "" }
func (m *mockAgent) ProtectedDirs() []string          { return nil }

func (m *mockAgent) ReadTranscript(_ string) ([]byte, error) { return nil, nil }
func (m *mockAgent) ChunkTranscript(_ context.Context, content []byte, _ int) ([][]byte, error) {
	return [][]byte{content}, nil
}

func (m *mockAgent) ReassembleTranscript(chunks [][]byte) ([]byte, error) {
	var result []byte
	for _, c := range chunks {
		result = append(result, c...)
	}
	return result, nil
}
func (m *mockAgent) GetSessionDir(_ string) (string, error) { return "", nil }
func (m *mockAgent) ResolveSessionFile(sessionDir, agentSessionID string) string {
	return sessionDir + "/" + agentSessionID + ".jsonl"
}

//nolint:nilnil // Mock implementation
func (m *mockAgent) ReadSession(_ *HookInput) (*AgentSession, error)       { return nil, nil }
func (m *mockAgent) WriteSession(_ context.Context, _ *AgentSession) error { return nil }
func (m *mockAgent) FormatResumeCommand(_ string) string                   { return "" }

// mockHookSupport implements both Agent and HookSupport interfaces.
type mockHookSupport struct {
	mockAgent
}

var _ HookSupport = (*mockHookSupport)(nil) // Compile-time interface check

func (m *mockHookSupport) HookNames() []string { return nil }

//nolint:nilnil // Mock implementation
func (m *mockHookSupport) ParseHookEvent(_ context.Context, _ string, _ io.Reader) (*Event, error) {
	return nil, nil
}
func (m *mockHookSupport) InstallHooks(_ context.Context, _, _ bool) (int, error) { return 0, nil }
func (m *mockHookSupport) UninstallHooks(_ context.Context) error                 { return nil }
func (m *mockHookSupport) AreHooksInstalled(_ context.Context) bool               { return false }

// mockFileWatcher implements both Agent and FileWatcher interfaces.
type mockFileWatcher struct {
	mockAgent
}

var _ FileWatcher = (*mockFileWatcher)(nil) // Compile-time interface check

func (m *mockFileWatcher) GetWatchPaths() ([]string, error) { return nil, nil }

//nolint:nilnil // Mock implementation
func (m *mockFileWatcher) OnFileChange(_ string) (*SessionChange, error) { return nil, nil }

func TestAgentInterfaceCompliance(t *testing.T) {
	t.Parallel()

	t.Run("Agent interface can be implemented", func(t *testing.T) {
		t.Parallel()

		var agent Agent = &mockAgent{}
		if agent.Name() != mockAgentName {
			t.Errorf("expected Name() to return %q, got %q", mockAgentName, agent.Name())
		}
	})

	t.Run("HookSupport embeds Agent", func(t *testing.T) {
		t.Parallel()

		var hookSupport HookSupport = &mockHookSupport{}
		// HookSupport should satisfy Agent interface
		var agent Agent = hookSupport
		if agent.Name() != mockAgentName {
			t.Errorf("expected Name() to return %q, got %q", mockAgentName, agent.Name())
		}
	})

	t.Run("FileWatcher embeds Agent", func(t *testing.T) {
		t.Parallel()

		var fileWatcher FileWatcher = &mockFileWatcher{}
		// FileWatcher should satisfy Agent interface
		var agent Agent = fileWatcher
		if agent.Name() != mockAgentName {
			t.Errorf("expected Name() to return %q, got %q", mockAgentName, agent.Name())
		}
	})
}

func TestHookTypeConstants(t *testing.T) {
	t.Parallel()

	tests := []struct {
		hookType HookType
		expected string
	}{
		{HookSessionStart, "session_start"},
		{HookUserPromptSubmit, "user_prompt_submit"},
		{HookStop, "stop"},
		{HookPreToolUse, "pre_tool_use"},
		{HookPostToolUse, "post_tool_use"},
	}

	for _, tt := range tests {
		t.Run(string(tt.hookType), func(t *testing.T) {
			t.Parallel()

			if string(tt.hookType) != tt.expected {
				t.Errorf("expected %q, got %q", tt.expected, string(tt.hookType))
			}
		})
	}
}

func TestEntryTypeConstants(t *testing.T) {
	t.Parallel()

	tests := []struct {
		entryType EntryType
		expected  string
	}{
		{EntryUser, "user"},
		{EntryAssistant, "assistant"},
		{EntryTool, "tool"},
		{EntrySystem, "system"},
	}

	for _, tt := range tests {
		t.Run(string(tt.entryType), func(t *testing.T) {
			t.Parallel()

			if string(tt.entryType) != tt.expected {
				t.Errorf("expected %q, got %q", tt.expected, string(tt.entryType))
			}
		})
	}
}

//nolint:govet // testing struct field assignment
func TestHookInputStructure(t *testing.T) {
	t.Parallel()

	input := HookInput{
		HookType:  HookPreToolUse,
		SessionID: "test-session",
		RawData:   map[string]interface{}{"extra": "data"},
	}

	if input.HookType != HookPreToolUse {
		t.Errorf("expected HookType %q, got %q", HookPreToolUse, input.HookType)
	}
	if input.SessionID != "test-session" {
		t.Errorf("expected SessionID %q, got %q", "test-session", input.SessionID)
	}
}

func TestSessionChangeStructure(t *testing.T) {
	t.Parallel()

	change := SessionChange{
		SessionID: "test-session",
		EventType: HookSessionStart,
	}

	if change.SessionID != "test-session" {
		t.Errorf("expected SessionID %q, got %q", "test-session", change.SessionID)
	}
	if change.EventType != HookSessionStart {
		t.Errorf("expected EventType %q, got %q", HookSessionStart, change.EventType)
	}
}
