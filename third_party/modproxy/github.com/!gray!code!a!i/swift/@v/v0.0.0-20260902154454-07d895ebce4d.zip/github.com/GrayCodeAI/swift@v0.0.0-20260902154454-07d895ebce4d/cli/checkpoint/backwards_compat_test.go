package checkpoint

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/swift/cli/agent"
	"github.com/GrayCodeAI/swift/cli/checkpoint/id"
	"github.com/GrayCodeAI/swift/cli/testutil"
	"github.com/GrayCodeAI/swift/redact"

	"github.com/go-git/go-git/v6"
	"github.com/go-git/go-git/v6/plumbing/object"
)

// TestReadCommitted_MissingTokenUsage verifies that reading metadata without
// token_usage field doesn't cause errors (for very old checkpoints that
// predate token tracking).
//
// Background: TokenUsage was moved from the checkpoint package to the agent
// package. The struct definition is identical, so JSON unmarshaling is
// inherently compatible. This test verifies graceful handling of old
// checkpoints that don't have token tracking at all.
func TestReadCommitted_MissingTokenUsage(t *testing.T) {
	tempDir := t.TempDir()

	testutil.InitRepo(t, tempDir)
	repo, err := git.PlainOpen(tempDir)
	if err != nil {
		t.Fatalf("failed to open git repo: %v", err)
	}

	worktree, err := repo.Worktree()
	if err != nil {
		t.Fatalf("failed to get worktree: %v", err)
	}

	readmeFile := filepath.Join(tempDir, "README.md")
	if err := os.WriteFile(readmeFile, []byte("# Test"), 0o644); err != nil {
		t.Fatalf("failed to write README: %v", err)
	}
	if _, err := worktree.Add("README.md"); err != nil {
		t.Fatalf("failed to add README: %v", err)
	}
	if _, err := worktree.Commit("Initial commit", &git.CommitOptions{
		Author: &object.Signature{Name: "Test", Email: "test@test.com"},
	}); err != nil {
		t.Fatalf("failed to commit: %v", err)
	}

	store := NewGitStore(repo, DefaultV1Refs())
	checkpointID := id.MustCheckpointID("def456abc123")

	// Write checkpoint WITHOUT token usage (simulates old checkpoints)
	err = store.Write(context.Background(), Session{
		CheckpointID: checkpointID,
		SessionID:    "test-session-old",
		Strategy:     "manual-commit",
		Agent:        agent.AgentTypeClaudeCode,
		Transcript:   redact.AlreadyRedacted([]byte("ancient transcript")),
		AuthorName:   "Test Author",
		AuthorEmail:  "test@example.com",
		// TokenUsage is nil - simulates old checkpoint
		TokenUsage: nil,
	})
	if err != nil {
		t.Fatalf("WriteCommitted() error = %v", err)
	}

	// Reading should succeed with nil TokenUsage
	summary, err := store.Read(context.Background(), checkpointID)
	if err != nil {
		t.Fatalf("Read() error = %v", err)
	}

	if summary.CheckpointID != checkpointID {
		t.Errorf("CheckpointID = %v, want %v", summary.CheckpointID, checkpointID)
	}

	// TokenUsage should be nil for old checkpoints without token tracking
	if summary.TokenUsage != nil {
		t.Errorf("TokenUsage should be nil for metadata without token_usage field, got %+v", summary.TokenUsage)
	}
}
