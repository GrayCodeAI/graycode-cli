package codex

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestWaitForRolloutSettle_StaleFile_ReturnsFast(t *testing.T) {
	t.Parallel()

	rollout := filepath.Join(t.TempDir(), "rollout.jsonl")
	if err := os.WriteFile(rollout, []byte(`{"type":"session_meta","payload":{}}`+"\n"), 0o644); err != nil {
		t.Fatalf("failed to write rollout: %v", err)
	}
	staleTime := time.Now().Add(-10 * time.Minute)
	if err := os.Chtimes(rollout, staleTime, staleTime); err != nil {
		t.Fatalf("failed to set mtime: %v", err)
	}

	start := time.Now()
	waitForRolloutSettle(context.Background(), rollout)
	elapsed := time.Since(start)

	// Stale rollouts (agent no longer running) must not burn the 3s maxWait.
	if elapsed > 500*time.Millisecond {
		t.Errorf("expected fast return for stale rollout, but took %v", elapsed)
	}
}

func TestWaitForRolloutSettle_StableFile_ReturnsFast(t *testing.T) {
	t.Parallel()

	// A recent rollout that has stopped growing (healthy turn-end: the final
	// response_item and task_completed markers have been flushed). The wait
	// must settle on size stability and return well under maxWait.
	rollout := filepath.Join(t.TempDir(), "rollout.jsonl")
	if err := os.WriteFile(rollout, []byte(`{"type":"response_item","payload":{"type":"message"}}`+"\n"), 0o644); err != nil {
		t.Fatalf("failed to write rollout: %v", err)
	}

	start := time.Now()
	waitForRolloutSettle(context.Background(), rollout)
	elapsed := time.Since(start)

	if elapsed > 1500*time.Millisecond {
		t.Errorf("expected fast return for a stable recent rollout, but took %v", elapsed)
	}
}

func TestWaitForRolloutSettle_GrowingFile_WaitsUntilSettled(t *testing.T) {
	t.Parallel()

	// A rollout still being appended to (async codex writer mid-turn) must NOT
	// be declared settled while it grows; the wait returns only after the
	// writes stop.
	rollout := filepath.Join(t.TempDir(), "rollout.jsonl")
	if err := os.WriteFile(rollout, []byte(`{"type":"event_msg","payload":{}}`+"\n"), 0o644); err != nil {
		t.Fatalf("failed to write rollout: %v", err)
	}

	const growFor = 600 * time.Millisecond
	stop := make(chan struct{})
	go func() {
		f, err := os.OpenFile(rollout, os.O_APPEND|os.O_WRONLY, 0o644)
		if err != nil {
			return
		}
		defer f.Close()
		ticker := time.NewTicker(40 * time.Millisecond)
		defer ticker.Stop()
		deadline := time.Now().Add(growFor)
		for {
			select {
			case <-stop:
				return
			case <-ticker.C:
				if time.Now().After(deadline) {
					return
				}
				if _, werr := f.WriteString(`{"type":"response_item","payload":{"type":"message"}}` + "\n"); werr != nil {
					return
				}
			}
		}
	}()

	start := time.Now()
	waitForRolloutSettle(context.Background(), rollout)
	elapsed := time.Since(start)
	close(stop)

	// Keep waiting while the file grows, but return once writes stop (bounded
	// by the 3s cap).
	if elapsed < 300*time.Millisecond {
		t.Errorf("expected to keep waiting while rollout grew, returned after only %v", elapsed)
	}
	if elapsed > 3500*time.Millisecond {
		t.Errorf("expected to return once settled/within cap, but took %v", elapsed)
	}
}

func TestWaitForRolloutSettle_MissingFile_ReturnsFast(t *testing.T) {
	t.Parallel()

	// turn-end for a session whose rollout path is null or not yet created
	// (e.g. --ephemeral mode) must not block.
	start := time.Now()
	waitForRolloutSettle(context.Background(), filepath.Join(t.TempDir(), "missing.jsonl"))
	elapsed := time.Since(start)

	if elapsed > 500*time.Millisecond {
		t.Errorf("expected fast return for missing rollout, but took %v", elapsed)
	}
}

func TestCodexAgent_PrepareTranscript_TurnEndContract(t *testing.T) {
	t.Parallel()

	// PrepareTranscript must always succeed (best-effort flush in a hook path:
	// a failure would otherwise abort the agent's turn).
	ag := &CodexAgent{}
	if err := ag.PrepareTranscript(context.Background(), filepath.Join(t.TempDir(), "does-not-exist.jsonl")); err != nil {
		t.Fatalf("PrepareTranscript must not error on missing transcript, got: %v", err)
	}
}
