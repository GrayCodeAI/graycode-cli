package factoryaidroid

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"github.com/GrayCodeAI/swift/cli/agent"
	"github.com/GrayCodeAI/swift/cli/transcript"
	"github.com/GrayCodeAI/swift/cli/validation"
)

// TranscriptLine is an alias to the shared transcript.Line type.
type TranscriptLine = transcript.Line

// droidEnvelope is the top-level structure of a Factory AI Droid JSONL line.
// Droid wraps messages as {"type":"message","id":"...","message":{"role":"assistant","content":[...]}},
// unlike Claude Code which uses {"type":"assistant","uuid":"...","message":{"content":[...]}}.
type droidEnvelope struct {
	Type    string          `json:"type"`
	ID      string          `json:"id"`
	Message json.RawMessage `json:"message"`
}

// droidMessageRole extracts just the role from the inner message.
type droidMessageRole struct {
	Role string `json:"role"`
}

// ParseDroidTranscript parses a Droid JSONL file into normalized transcript.Line entries.
// It transforms the Droid envelope format (type="message", role inside message) into the
// shared transcript.Line format (type="assistant"/"user", message=inner content).
// Non-message entries (session_start, etc.) are skipped.
func ParseDroidTranscript(path string, startLine int) ([]transcript.Line, int, error) {
	file, err := os.Open(path) //nolint:gosec // path is a controlled transcript file path
	if err != nil {
		return nil, 0, fmt.Errorf("failed to open transcript: %w", err)
	}
	defer func() { _ = file.Close() }()

	return parseDroidTranscriptFromReader(file, startLine)
}

// ParseDroidTranscriptFromBytes parses Droid JSONL content from a byte slice.
// startLine skips the first N raw JSONL lines before parsing (0 = parse all).
// Returns parsed lines, total raw line count, and any error.
// This mirrors ParseDroidTranscript's startLine parameter, applying the offset
// at the raw line level before filtering out non-message entries.
func ParseDroidTranscriptFromBytes(content []byte, startLine int) ([]transcript.Line, int, error) {
	return parseDroidTranscriptFromReader(bytes.NewReader(content), startLine)
}

func parseDroidTranscriptFromReader(r io.Reader, startLine int) ([]transcript.Line, int, error) {
	reader := bufio.NewReader(r)
	var lines []transcript.Line
	totalLines := 0

	for {
		lineBytes, err := reader.ReadBytes('\n')
		if err != nil && err != io.EOF {
			return nil, 0, fmt.Errorf("failed to read transcript: %w", err)
		}

		if len(lineBytes) == 0 {
			if err == io.EOF {
				break
			}
			continue
		}

		if totalLines >= startLine {
			if line, ok := parseDroidLine(lineBytes); ok {
				lines = append(lines, line)
			}
		}
		totalLines++

		if err == io.EOF {
			break
		}
	}

	return lines, totalLines, nil
}

// parseDroidLine converts a single Droid JSONL line into a normalized transcript.Line.
// Returns false if the line is not a message entry (e.g., session_start).
func parseDroidLine(lineBytes []byte) (transcript.Line, bool) {
	var env droidEnvelope
	if err := json.Unmarshal(lineBytes, &env); err != nil {
		return transcript.Line{}, false
	}

	// Only process "message" type entries — skip session_start, etc.
	if env.Type != "message" {
		return transcript.Line{}, false
	}

	// Extract role from the inner message
	var role droidMessageRole
	if err := json.Unmarshal(env.Message, &role); err != nil {
		return transcript.Line{}, false
	}

	return transcript.Line{
		Type:    role.Role, // "assistant" or "user"
		UUID:    env.ID,
		Message: env.Message,
	}, true
}

// ExtractModifiedFiles extracts files modified by tool calls from transcript.
func ExtractModifiedFiles(lines []TranscriptLine) []string {
	fileSet := make(map[string]bool)
	var files []string

	for _, line := range lines {
		if line.Type != "assistant" {
			continue
		}

		var msg transcript.AssistantMessage
		if err := json.Unmarshal(line.Message, &msg); err != nil {
			continue
		}

		for _, block := range msg.Content {
			if block.Type != "tool_use" || !slices.Contains(FileModificationTools, block.Name) {
				continue
			}

			var input transcript.ToolInput
			if err := json.Unmarshal(block.Input, &input); err != nil {
				continue
			}

			file := input.FilePath
			if file == "" {
				file = input.NotebookPath
			}

			if file != "" && !fileSet[file] {
				fileSet[file] = true
				files = append(files, file)
			}
		}
	}

	return files
}

// CalculateTokenUsage calculates token usage from a Factory AI Droid transcript.
// Due to streaming, multiple transcript rows may share the same message.id.
// We deduplicate by taking the row with the highest output_tokens for each message.id.
func CalculateTokenUsage(transcriptLines []TranscriptLine) *agent.TokenUsage {
	// Map from message.id to the usage with highest output_tokens
	usageByMessageID := make(map[string]messageUsage)

	for _, line := range transcriptLines {
		if line.Type != "assistant" {
			continue
		}

		var msg messageWithUsage
		if err := json.Unmarshal(line.Message, &msg); err != nil {
			continue
		}

		if msg.ID == "" {
			continue
		}

		// Keep the entry with highest output_tokens (final streaming state)
		existing, exists := usageByMessageID[msg.ID]
		if !exists || msg.Usage.OutputTokens > existing.OutputTokens {
			usageByMessageID[msg.ID] = msg.Usage
		}
	}

	// Sum up all unique messages
	usage := &agent.TokenUsage{
		APICallCount: len(usageByMessageID),
	}
	for _, u := range usageByMessageID {
		usage.InputTokens += u.InputTokens
		usage.CacheCreationTokens += u.CacheCreationInputTokens
		usage.CacheReadTokens += u.CacheReadInputTokens
		usage.OutputTokens += u.OutputTokens
	}

	return usage
}

// CalculateTokenUsageFromFile calculates token usage from a transcript file.
// If startLine > 0, only considers lines from startLine onwards.
func CalculateTokenUsageFromFile(path string, startLine int) (*agent.TokenUsage, error) {
	if path == "" {
		return &agent.TokenUsage{}, nil
	}

	lines, _, err := ParseDroidTranscript(path, startLine)
	if err != nil {
		return nil, err
	}

	return CalculateTokenUsage(lines), nil
}

// ExtractSpawnedAgentIDs extracts agent IDs from Task tool results in a transcript.
// When a Task tool completes, the tool_result contains "agentId: <id>" in its content.
// Returns a map of agentID -> toolUseID for all spawned agents.
func ExtractSpawnedAgentIDs(transcriptLines []TranscriptLine) map[string]string {
	agentIDs := make(map[string]string)

	for _, line := range transcriptLines {
		if line.Type != "user" {
			continue
		}

		// Parse as array of content blocks (tool results)
		var contentBlocks []struct {
			Type      string          `json:"type"`
			ToolUseID string          `json:"tool_use_id"`
			Content   json.RawMessage `json:"content"`
		}

		var msg struct {
			Content json.RawMessage `json:"content"`
		}
		if err := json.Unmarshal(line.Message, &msg); err != nil {
			continue
		}

		if err := json.Unmarshal(msg.Content, &contentBlocks); err != nil {
			continue
		}

		for _, block := range contentBlocks {
			if block.Type != "tool_result" {
				continue
			}

			// Content can be a string or array of text blocks
			var textContent string

			// Try as array of text blocks first
			var textBlocks []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			}
			if err := json.Unmarshal(block.Content, &textBlocks); err == nil {
				var sb strings.Builder
				for _, tb := range textBlocks {
					if tb.Type == "text" {
						sb.WriteString(tb.Text + "\n")
					}
				}
				textContent = sb.String()
			} else {
				// Try as plain string
				var str string
				if err := json.Unmarshal(block.Content, &str); err == nil {
					textContent = str
				}
			}

			// Look for agentId in the text. Drop any ID that isn't path-safe:
			// callers build agent-<id>.jsonl from it and read that file, so this
			// is the choke point that keeps the path inside subagentsDir,
			// independent of extractAgentIDFromText's character handling.
			if agentID := extractAgentIDFromText(textContent); agentID != "" && validation.ValidateAgentID(agentID) == nil {
				agentIDs[agentID] = block.ToolUseID
			}
		}
	}

	return agentIDs
}

// droidSettings represents the .settings.json file that Factory AI Droid
// stores alongside each session transcript JSONL.
type droidSettings struct {
	Model string `json:"model"`
}

// ExtractModelFromTranscript extracts the LLM model name from the Factory AI Droid
// session settings file. Factory AI Droid stores a .settings.json file alongside
// each transcript JSONL (e.g., <session-id>.settings.json next to <session-id>.jsonl).
// The settings file contains the actual model being used, unlike the transcript's
// system-reminder text which can be stale after provider switches.
// Returns empty string if the settings file cannot be read or has no model.
func ExtractModelFromTranscript(transcriptPath string) string {
	if transcriptPath == "" {
		return ""
	}

	settingsPath := strings.TrimSuffix(transcriptPath, ".jsonl") + ".settings.json"
	data, err := os.ReadFile(settingsPath) //nolint:gosec // Path derived from agent hook input
	if err != nil {
		return ""
	}

	var settings droidSettings
	if err := json.Unmarshal(data, &settings); err != nil {
		slog.Warn("corrupt settings file, cannot extract model",
			slog.String("path", settingsPath),
			slog.Any("error", err))
		return ""
	}

	return cleanModelName(settings.Model)
}

// cleanModelName normalizes a Factory AI Droid model identifier into a display name.
// For example, "custom:Gemini-2.5-Pro-0" becomes "Gemini-2.5-Pro-0".
func cleanModelName(raw string) string {
	// Strip known prefixes that Factory AI Droid adds to model identifiers
	if after, found := strings.CutPrefix(raw, "custom:"); found {
		return after
	}
	return raw
}

// extractAgentIDFromText extracts an agent ID from text containing "agentId: <id>".
func extractAgentIDFromText(text string) string {
	const prefix = "agentId: "
	idx := strings.Index(text, prefix)
	if idx == -1 {
		return ""
	}

	// Extract the ID (alphanumeric characters after the prefix)
	start := idx + len(prefix)
	end := start
	for end < len(text) && (text[end] >= 'a' && text[end] <= 'z' ||
		text[end] >= 'A' && text[end] <= 'Z' ||
		text[end] >= '0' && text[end] <= '9') {
		end++
	}

	if end > start {
		return text[start:end]
	}
	return ""
}

// CalculateTotalTokenUsageFromBytes calculates token usage from pre-loaded transcript bytes,
// including subagents. It parses the main transcript bytes from startLine, extracts spawned
// agent IDs, and calculates their token usage from transcript files in subagentsDir.
func CalculateTotalTokenUsageFromBytes(data []byte, startLine int, subagentsDir string) (*agent.TokenUsage, error) {
	if len(data) == 0 {
		return &agent.TokenUsage{}, nil
	}

	parsed, _, err := ParseDroidTranscriptFromBytes(data, startLine)
	if err != nil {
		return nil, fmt.Errorf("failed to parse transcript: %w", err)
	}

	mainUsage := CalculateTokenUsage(parsed)

	if subagentsDir == "" {
		return mainUsage, nil
	}

	// Extract spawned agent IDs from the FULL transcript (startLine=0): a
	// subagent spawned before this checkpoint's startLine can keep writing to
	// its transcript, so scanning only the slice would undercount it (#329).
	//
	// PERF (considered, retained deliberately): this re-parses the full
	// transcript in addition to the sliced parse above — two JSONL parses per
	// call, growing with session length. A single-pass version was rejected:
	// the Droid parser drops non-message / malformed lines, so a parsed-entry
	// index does not map to a raw line number and naively slicing the full parse
	// at startLine would misattribute main-agent usage; doing it safely would
	// mean threading raw-line numbers through the shared parser. The common
	// no-subagent case already avoids this via the subagentsDir == "" guard.
	fullParsed, _, err := ParseDroidTranscriptFromBytes(data, 0)
	if err != nil {
		return nil, fmt.Errorf("failed to parse full transcript: %w", err)
	}
	agentIDs := ExtractSpawnedAgentIDs(fullParsed)
	// This re-reads each subagent transcript from line 0 on every call below, so
	// mainUsage.SubagentTokens ends up cumulative-since-session-start — see the
	// CalculateTotalTokenUsage interface contract in cmd/entire/cli/agent for how
	// callers must accumulate it (shared with Claude Code).
	if len(agentIDs) > 0 {
		subagentUsage := &agent.TokenUsage{}
		for agentID := range agentIDs {
			agentPath := filepath.Join(subagentsDir, fmt.Sprintf("agent-%s.jsonl", agentID))
			agentUsage, err := CalculateTokenUsageFromFile(agentPath, 0)
			if err != nil {
				continue
			}
			subagentUsage.InputTokens += agentUsage.InputTokens
			subagentUsage.CacheCreationTokens += agentUsage.CacheCreationTokens
			subagentUsage.CacheReadTokens += agentUsage.CacheReadTokens
			subagentUsage.OutputTokens += agentUsage.OutputTokens
			subagentUsage.APICallCount += agentUsage.APICallCount
		}
		if subagentUsage.APICallCount > 0 {
			mainUsage.SubagentTokens = subagentUsage
		}
	}

	return mainUsage, nil
}

// ExtractAllModifiedFilesFromBytes extracts files modified by both the main agent and
// any subagents from pre-loaded transcript bytes. It parses the main transcript bytes from
// startLine, collects modified files, then reads each subagent's transcript from
// subagentsDir to collect their modified files too.
func ExtractAllModifiedFilesFromBytes(data []byte, startLine int, subagentsDir string) ([]string, error) {
	if len(data) == 0 {
		return nil, nil
	}

	parsed, _, err := ParseDroidTranscriptFromBytes(data, startLine)
	if err != nil {
		return nil, fmt.Errorf("failed to parse transcript: %w", err)
	}

	files := ExtractModifiedFiles(parsed)
	fileSet := make(map[string]bool, len(files))
	for _, f := range files {
		fileSet[f] = true
	}

	if subagentsDir == "" {
		return files, nil
	}

	// Find spawned subagents from the FULL transcript (startLine=0): a subagent
	// spawned before this checkpoint's startLine may keep modifying files in
	// later turns, and scanning only the slice would miss it (#329). Main-agent
	// file extraction above stays scoped to the slice.
	//
	// PERF: the second full-transcript parse is retained deliberately for the
	// same reasons documented on CalculateTotalTokenUsageFromBytes above; the
	// common no-subagent case is short-circuited by the subagentsDir == "" guard.
	fullParsed, _, err := ParseDroidTranscriptFromBytes(data, 0)
	if err != nil {
		return nil, fmt.Errorf("failed to parse full transcript: %w", err)
	}
	agentIDs := ExtractSpawnedAgentIDs(fullParsed)
	for agentID := range agentIDs {
		agentPath := filepath.Join(subagentsDir, fmt.Sprintf("agent-%s.jsonl", agentID))
		agentLines, _, agentErr := ParseDroidTranscript(agentPath, 0)
		if agentErr != nil {
			continue
		}
		for _, f := range ExtractModifiedFiles(agentLines) {
			if !fileSet[f] {
				fileSet[f] = true
				files = append(files, f)
			}
		}
	}

	return files, nil
}
