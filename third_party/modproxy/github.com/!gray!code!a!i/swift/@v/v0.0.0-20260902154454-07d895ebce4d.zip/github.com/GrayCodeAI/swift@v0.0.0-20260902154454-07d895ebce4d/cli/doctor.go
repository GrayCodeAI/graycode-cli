package cli

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"

	"charm.land/huh/v2"
	"github.com/GrayCodeAI/swift/cli/agent/claudecode"
	"github.com/GrayCodeAI/swift/cli/agent/codex"
	"github.com/GrayCodeAI/swift/cli/checkpoint"
	"github.com/GrayCodeAI/swift/cli/paths"
	"github.com/GrayCodeAI/swift/cli/session"
	"github.com/GrayCodeAI/swift/cli/strategy"

	"github.com/go-git/go-git/v6"
	"github.com/go-git/go-git/v6/plumbing"
	"github.com/spf13/cobra"
)

func newDoctorCmd() *cobra.Command {
	var forceFlag bool

	cmd := &cobra.Command{
		Use:   "doctor",
		Short: "Diagnose and fix session issues",
		Long: `Scan for session issues and offer to fix them.

Checks performed:
  1. Disconnected metadata branches: detects when local and remote
     entire/checkpoints/v1 branches share no common ancestor (caused by a
     previous bug). Fixes by cherry-picking local checkpoints onto remote tip.

  When Codex hooks are installed:
  2. Codex hook trust: warn when hooks declared in .codex/hooks.json
     lack a trusted_hash entry in the user's Codex config (i.e. /hooks
     review hasn't run yet on this machine, or a newer entire release
     added a hook the user hasn't approved yet).

  When Claude Code hooks are installed:
  3. Claude Code hook config: warn when the installed hooks are out of
     date (e.g. an older release wrote tool matchers that no longer fire).
     Fix by re-running 'entire enable --force'.

  4. Stuck sessions: sessions stuck in ACTIVE or ENDED phase that need cleanup.

A session is considered stuck if:
  - It is in ACTIVE phase with no interaction for over 1 hour
  - It is in ENDED phase with uncondensed checkpoint data on a shadow branch

For each stuck session, you can choose to:
  - Condense: Save session data to permanent storage
  - Discard: Remove the session state and shadow branch data
  - Skip: Leave the session as-is

Use --force to condense all fixable sessions without prompting.  Sessions that can't
be condensed will be discarded.`,
		PreRun: func(_ *cobra.Command, _ []string) {
			strategy.EnsureRedactionConfigured()
		},
		RunE: func(cmd *cobra.Command, _ []string) error {
			return runSessionsFix(cmd, forceFlag)
		},
	}

	cmd.Flags().BoolVarP(&forceFlag, "force", "f", false, "Auto-fix all issues without prompting")

	// Diagnostic subcommands.
	cmd.AddCommand(newSwiftCmd())
	cmd.AddCommand(newDoctorLogsCmd())
	cmd.AddCommand(newDoctorBundleCmd())
	cmd.AddCommand(newDoctorMigrateCheckpointsCmd())

	return cmd
}

// stuckSession holds a session state along with diagnostic info.
type stuckSession struct {
	State             *strategy.SessionState
	Reason            string
	ShadowBranch      string
	HasShadowBranch   bool
	CheckpointCount   int
	FilesTouchedCount int
}

func runSessionsFix(cmd *cobra.Command, force bool) error {
	var finalErr error

	// Check 1: Disconnected metadata branches
	metadataErr := checkDisconnectedMetadata(cmd, force)
	if metadataErr != nil {
		fmt.Fprintf(cmd.ErrOrStderr(), "Error: metadata check failed: %v\n", metadataErr)
		finalErr = NewSilentError(fmt.Errorf("metadata check failed: %w", metadataErr))
	}

	fmt.Fprintln(cmd.OutOrStdout())

	ctx := cmd.Context()

	// Agent-specific: Codex hook trust state.
	checkCodexHookTrust(cmd)

	// Agent-specific: Claude Code hook config drift.
	checkClaudeCodeHookDrift(cmd)

	// Where checkpoints land, when the repo's remotes make that ambiguous.
	printCheckpointDestinationNote(ctx, cmd.OutOrStdout(), "Checkpoint destination: REVIEW")

	// Stuck sessions
	// Load all session states
	states, err := strategy.ListSessionStates(ctx)
	if err != nil {
		return fmt.Errorf("failed to list session states: %w", err)
	}

	if len(states) == 0 {
		fmt.Fprintln(cmd.OutOrStdout(), "No stuck sessions found.")
		if finalErr != nil {
			return finalErr
		}
		return nil
	}

	// Open repository to check shadow branches (uses worktree-aware helper)
	repo, err := openRepository(ctx)
	if err != nil {
		return fmt.Errorf("failed to open repository: %w", err)
	}
	defer repo.Close()

	// Finalize any ACTIVE session whose agent process has exited (no SessionStop
	// hook fired). A gone process is unambiguous, so these are condensed on the
	// spot rather than left for the interactive prompt below; the sweep marks
	// them ended in place so classifySession won't re-flag them.
	if n := finalizeExitedSessions(ctx, states); n > 0 {
		fmt.Fprintf(cmd.OutOrStdout(), "Finalized %d exited session(s) (agent process gone).\n\n", n)
	}

	// Identify stuck sessions
	now := time.Now()
	var stuck []stuckSession

	for _, state := range states {
		ss := classifySession(state, repo, now)
		if ss != nil {
			stuck = append(stuck, *ss)
		}
	}

	if len(stuck) == 0 {
		fmt.Fprintln(cmd.OutOrStdout(), "No stuck sessions found.")
		if finalErr != nil {
			return finalErr
		}
		return nil
	}

	// Get the current strategy for condense operations
	start := GetStrategy(ctx)

	fmt.Fprintf(cmd.OutOrStdout(), "Found %d stuck session(s):\n\n", len(stuck))

	for _, ss := range stuck {
		displayStuckSession(cmd, ss)

		if force {
			if ss.HasShadowBranch && ss.CheckpointCount > 0 {
				if err := start.CondenseSessionByID(ctx, ss.State.SessionID); err != nil {
					fmt.Fprintf(cmd.ErrOrStderr(), "Warning: failed to condense session %s: %v\n", ss.State.SessionID, err)
				} else {
					fmt.Fprintf(cmd.OutOrStdout(), "  ✓ Condensed session %s\n\n", ss.State.SessionID)
				}
			} else {
				// Discard if we can't condense
				if err := discardSession(ctx, ss, repo, cmd.ErrOrStderr()); err != nil {
					fmt.Fprintf(cmd.ErrOrStderr(), "Warning: failed to discard session %s: %v\n", ss.State.SessionID, err)
				} else {
					fmt.Fprintf(cmd.OutOrStdout(), "  ✓ Discarded session %s\n\n", ss.State.SessionID)
				}
			}
			continue
		}

		// Interactive: prompt for action
		action, err := promptSessionAction(ss)
		if err != nil {
			if errors.Is(err, huh.ErrUserAborted) {
				return nil
			}
			return fmt.Errorf("failed to get action: %w", err)
		}

		switch action {
		case "condense":
			if err := start.CondenseSessionByID(ctx, ss.State.SessionID); err != nil {
				fmt.Fprintf(cmd.ErrOrStderr(), "Warning: failed to condense session %s: %v\n", ss.State.SessionID, err)
			} else {
				fmt.Fprintf(cmd.OutOrStdout(), "  ✓ Condensed session %s\n\n", ss.State.SessionID)
			}
		case "discard":
			if err := discardSession(ctx, ss, repo, cmd.ErrOrStderr()); err != nil {
				fmt.Fprintf(cmd.ErrOrStderr(), "Warning: failed to discard session %s: %v\n", ss.State.SessionID, err)
			} else {
				fmt.Fprintf(cmd.OutOrStdout(), "  ✓ Discarded session %s\n\n", ss.State.SessionID)
			}
		case "skip":
			fmt.Fprintf(cmd.OutOrStdout(), "  -> Skipped\n\n")
		}
	}

	if finalErr != nil {
		return finalErr
	}

	return nil
}

// classifySession determines if a session is stuck and returns diagnostic info.
// Returns nil if the session is healthy.
func classifySession(state *strategy.SessionState, repo *git.Repository, now time.Time) *stuckSession {
	// Determine shadow branch info
	shadowBranch := checkpoint.ShadowBranchNameForCommit(state.BaseCommit, state.WorktreeID)
	refName := plumbing.NewBranchReferenceName(shadowBranch)
	_, refErr := repo.Reference(refName, true)
	hasShadowBranch := refErr == nil

	switch {
	case state.Phase.IsActive():
		var reason string
		switch {
		case state.OwnerExited():
			// Detected immediately (no timeout wait): the owning agent process
			// is gone. Normally finalized up front in runSessionsFix; this
			// branch covers a session that couldn't be finalized there.
			pid := 0
			if state.Owner != nil {
				pid = state.Owner.PID
			}
			reason = fmt.Sprintf("agent process %d exited (no longer running)", pid)
		case !state.IsStuckActive():
			return nil
		case state.LastInteractionTime != nil:
			reason = fmt.Sprintf("active, last interaction %s ago", now.Sub(*state.LastInteractionTime).Truncate(time.Minute))
		default:
			reason = fmt.Sprintf("active, started %s ago with no recorded interaction", now.Sub(state.StartedAt).Truncate(time.Minute))
		}

		return &stuckSession{
			State:             state,
			Reason:            reason,
			ShadowBranch:      shadowBranch,
			HasShadowBranch:   hasShadowBranch,
			CheckpointCount:   state.StepCount,
			FilesTouchedCount: len(state.FilesTouched),
		}

	case state.Phase == session.PhaseEnded:
		// Ended sessions are stuck if they have uncondensed data
		if state.StepCount <= 0 || !hasShadowBranch {
			return nil
		}

		return &stuckSession{
			State:             state,
			Reason:            "ended with uncondensed checkpoint data",
			ShadowBranch:      shadowBranch,
			HasShadowBranch:   hasShadowBranch,
			CheckpointCount:   state.StepCount,
			FilesTouchedCount: len(state.FilesTouched),
		}

	default:
		return nil
	}
}

// displayStuckSession prints diagnostic info for a stuck session.
func displayStuckSession(cmd *cobra.Command, ss stuckSession) {
	w := cmd.OutOrStdout()

	fmt.Fprintf(w, "  Session: %s\n", ss.State.SessionID)
	fmt.Fprintf(w, "  Phase:   %s\n", ss.State.Phase)
	fmt.Fprintf(w, "  Reason:  %s\n", ss.Reason)

	if ss.State.AgentType != "" {
		fmt.Fprintf(w, "  Agent:   %s\n", ss.State.AgentType)
	}

	if ss.State.LastInteractionTime != nil {
		fmt.Fprintf(w, "  Last interaction: %s\n", ss.State.LastInteractionTime.Format(time.RFC3339))
	}

	shadowStatus := "not found"
	if ss.HasShadowBranch {
		shadowStatus = fmt.Sprintf("exists (%s)", ss.ShadowBranch)
	}
	fmt.Fprintf(w, "  Shadow branch: %s\n", shadowStatus)
	fmt.Fprintf(w, "  Checkpoints: %d, Files touched: %d\n", ss.CheckpointCount, ss.FilesTouchedCount)
}

// promptSessionAction asks the user what to do with a stuck session.
func promptSessionAction(ss stuckSession) (string, error) {
	var action string

	options := make([]huh.Option[string], 0, 3)
	if ss.HasShadowBranch && ss.CheckpointCount > 0 {
		options = append(options, huh.NewOption("Condense (save to permanent storage)", "condense"))
	}
	options = append(
		options,
		huh.NewOption("Discard (remove session data)", "discard"),
		huh.NewOption("Skip (leave as-is)", "skip"),
	)

	form := NewAccessibleForm(
		huh.NewGroup(
			huh.NewSelect[string]().
				Title(fmt.Sprintf("Fix session %s?", ss.State.SessionID)).
				Options(options...).
				Value(&action),
		),
	)

	if err := form.Run(); err != nil {
		return "", fmt.Errorf("session fix prompt failed: %w", err)
	}

	return action, nil
}

// discardSession removes session state and cleans up the shadow branch.
func discardSession(ctx context.Context, ss stuckSession, _ *git.Repository, errW io.Writer) error {
	// Clear session state file
	if err := strategy.ClearSessionState(ctx, ss.State.SessionID); err != nil {
		return fmt.Errorf("failed to clear session state: %w", err)
	}

	// Delete shadow branch if it exists and no other sessions need it
	if ss.HasShadowBranch {
		if shouldDelete, err := canDeleteShadowBranch(ctx, ss.ShadowBranch, ss.State.SessionID); err != nil {
			fmt.Fprintf(errW, "Warning: could not check other sessions for shadow branch: %v\n", err)
		} else if shouldDelete {
			if err := strategy.DeleteBranchCLI(ctx, ss.ShadowBranch); err != nil {
				// Branch already gone is not an error — keeps discard idempotent
				if !errors.Is(err, strategy.ErrBranchNotFound) {
					return fmt.Errorf("failed to delete shadow branch: %w", err)
				}
			}
		}
	}

	return nil
}

// checkDisconnectedMetadata detects and optionally repairs disconnected
// local/remote metadata branches (the "empty-orphan bug").
func checkDisconnectedMetadata(cmd *cobra.Command, force bool) error {
	repo, err := openRepository(cmd.Context())
	if err != nil {
		return fmt.Errorf("failed to open repository: %w", err)
	}
	defer repo.Close()

	ctx := cmd.Context()
	refs := checkpoint.ResolveRefs(ctx)
	w := cmd.OutOrStdout()
	if !refs.PrimaryFetchableFromOrigin() {
		fmt.Fprintf(w, "✓ Metadata branches: OK (primary ref %s is not pushed to origin)\n", refs.Primary)
		return nil
	}
	remoteRefName := plumbing.NewRemoteReferenceName("origin", refs.Primary.Short())
	disconnected, err := strategy.IsMetadataDisconnected(ctx, repo, remoteRefName)
	if err != nil {
		return fmt.Errorf("could not check metadata branch state: %w", err)
	}

	if !disconnected {
		fmt.Fprintln(w, "✓ Metadata branches: OK")
		return nil
	}

	fmt.Fprintln(w, "Metadata branches: DISCONNECTED")
	fmt.Fprintf(w, "  Local and remote %s branches share no common ancestor.\n", refs.Primary.Short())
	fmt.Fprintln(w, "  Some remote checkpoints may not be visible locally.")
	fmt.Fprintln(w, "  Fix: cherry-pick local checkpoints onto remote tip (preserves all data).")

	if !force {
		proceed, promptErr := confirmDoctorFix(ctx, w, "Fix disconnected metadata branches?")
		if promptErr != nil {
			return promptErr
		}
		if !proceed {
			return nil
		}
	}

	if fixErr := strategy.ReconcileDisconnectedMetadataRef(ctx, repo, refs.Primary, remoteRefName, cmd.ErrOrStderr()); fixErr != nil {
		return fmt.Errorf("failed to reconcile metadata branches: %w", fixErr)
	}

	fmt.Fprintln(w, "  ✓ Fixed: metadata branches reconciled")
	return nil
}

// confirmDoctorFix prompts to apply a doctor fix. Declining (which prints
// "-> Skipped"), aborting (Ctrl+C), and context cancellation all return false
// with no error.
func confirmDoctorFix(ctx context.Context, w io.Writer, title string) (bool, error) {
	// huh opens the TTY during form startup regardless of context state, so
	// guard explicitly to honor an already-cancelled command context.
	if ctx.Err() != nil {
		return false, nil //nolint:nilerr // cancelled context is a clean skip, not an error
	}
	var confirmed bool
	form := NewAccessibleForm(
		huh.NewGroup(
			huh.NewConfirm().
				Title(title).
				Value(&confirmed),
		),
	)
	if err := form.RunWithContext(ctx); err != nil {
		if errors.Is(err, huh.ErrUserAborted) || errors.Is(err, context.Canceled) {
			return false, nil
		}
		return false, fmt.Errorf("prompt failed: %w", err)
	}
	if !confirmed {
		fmt.Fprintln(w, "  -> Skipped")
	}
	return confirmed, nil
}

// checkClaudeCodeHookDrift warns when Entire's Claude Code hooks are installed
// but out of date — e.g. an older release wrote tool matchers that no longer
// fire on current Claude Code. Read-only; the fix is `entire enable --force`.
// Stays silent when Claude Code hooks aren't installed here.
func checkClaudeCodeHookDrift(cmd *cobra.Command) {
	w := cmd.OutOrStdout()
	switch claudecode.CheckHookConfig(cmd.Context()) {
	case claudecode.HooksAbsent:
		// Not installed in this repo — nothing to report.
	case claudecode.HooksCurrent:
		fmt.Fprintln(w, "✓ Claude Code hook config: OK")
	case claudecode.HooksOutdated:
		fmt.Fprintln(w, "Claude Code hooks: OUT OF DATE")
		fmt.Fprintln(w, "  The installed hooks use outdated tool matchers and no longer fire.")
		fmt.Fprintln(w, "  Run `entire enable --force` to update the hooks file.")
	}
}

// checkCodexHookTrust warns about two kinds of drift in the Codex hook
// setup:
//
//  1. .codex/hooks.json is stale relative to what the CLI installs
//     today (e.g. a release added PostToolUse after the user enabled
//     Codex). Fix: re-run `entire enable`.
//
//  2. A declared hook lacks a `trusted_hash` entry in the user's Codex
//     config — either a fresh clone or a newer hook on the file the
//     user hasn't approved yet. Fix: open /hooks in Codex.
//
// Both checks are structural (file/key presence). Stays silent when
// this repo doesn't have codex hooks installed or when we can't
// resolve the worktree root. Warn-only.
func checkCodexHookTrust(cmd *cobra.Command) {
	repoRoot, err := paths.WorktreeRoot(cmd.Context())
	if err != nil {
		return
	}
	if _, statErr := os.Stat(filepath.Join(repoRoot, ".codex", "hooks.json")); statErr != nil {
		return
	}

	w := cmd.OutOrStdout()
	missing := codex.MissingEntireHooks(repoRoot)
	gaps := codex.HookTrustGaps(repoRoot)

	if len(missing) == 0 && len(gaps) == 0 {
		fmt.Fprintln(w, "✓ Codex hook trust: OK")
		return
	}

	if len(missing) > 0 {
		fmt.Fprintln(w, "Codex hooks: OUT OF DATE")
		fmt.Fprintf(w, "  %d hook(s) the CLI installs today aren't declared in .codex/hooks.json:\n", len(missing))
		for _, ev := range missing {
			fmt.Fprintf(w, "    - %s\n", ev)
		}
		fmt.Fprintln(w, "  Run `entire enable` to refresh the hooks file.")
	}

	if len(gaps) > 0 {
		fmt.Fprintln(w, "Codex hook trust: REVIEW NEEDED")
		fmt.Fprintf(w, "  %d hook(s) declared in .codex/hooks.json have no trusted_hash entry yet:\n", len(gaps))
		for _, ev := range gaps {
			fmt.Fprintf(w, "    - %s\n", ev)
		}
		fmt.Fprintln(w, "  Open /hooks inside Codex to approve them.")
	}
}

// canDeleteShadowBranch checks if a shadow branch can be safely deleted.
// Returns true if no other sessions (besides excludeSessionID) need this branch.
func canDeleteShadowBranch(ctx context.Context, shadowBranch, excludeSessionID string) (bool, error) {
	states, err := strategy.ListSessionStates(ctx)
	if err != nil {
		return false, fmt.Errorf("failed to list session states: %w", err)
	}

	for _, state := range states {
		if state.SessionID == excludeSessionID {
			continue
		}
		otherShadow := checkpoint.ShadowBranchNameForCommit(state.BaseCommit, state.WorktreeID)
		if otherShadow == shadowBranch && state.StepCount > 0 {
			return false, nil
		}
	}

	return true, nil
}
