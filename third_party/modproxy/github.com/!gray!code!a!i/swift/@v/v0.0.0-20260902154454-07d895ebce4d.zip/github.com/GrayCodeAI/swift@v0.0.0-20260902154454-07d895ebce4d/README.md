<p align="center">
  <h1 align="center">Swift</h1>
  <p align="center">
    <strong>Git-native session capture for AI coding agents</strong>
  </p>
  <p align="center">
    <a href="#quick-start">Quick Start</a> &bull;
    <a href="#how-it-works">How It Works</a> &bull;
    <a href="#commands">Commands</a> &bull;
    <a href="#configuration">Configuration</a> &bull;
    <a href="CONTRIBUTING.md">Contributing</a>
  </p>
</p>

---

Swift hooks into your Git workflow to capture AI agent sessions as you work. Sessions are indexed alongside commits, creating a searchable record of *how* code was written — not just *what* changed.

## Ecosystem Boundaries

Swift is a Hawk support engine. Keep the dependency edge one-way:

- swift keeps redaction and storage types local; portable graph exports use
  `swift/graph` (vendored local copy)
- do not import `hawk/internal/*`
- do not import removed legacy path `hawk/shared/types`
- do not import other engines (`eyrie`, `harrier`, `shrike`, `kestrel`, `merlin`) — engines are peers, not dependencies

Hawk embeds Swift through one supported composition surface:
`cli.NewRootCmd()`. Hawk must not import Swift's `cli/internal` collaborators or
individual strategy, checkpoint, agent, storage, or UI packages. Changes to
`NewRootCmd` are therefore cross-repository compatibility changes.

### What you get

| Capability | Description |
|---|---|
| **Understand why code changed** | Full prompt/response transcripts, files touched, token usage |
| **Rewind instantly** | Go back to any checkpoint when an agent goes sideways |
| **Fork & A/B** | Branch a new independent session from any checkpoint to explore alternatives |
| **Resume seamlessly** | Pick up where you or a coworker left off on any branch |
| **Cost attribution** | USD cost broken down per session and per tool from recorded token usage |
| **Clean git history** | All session data lives on a separate branch — zero noise |
| **Audit & compliance** | Searchable, versioned record of every AI interaction |

### Supported Agents

| Agent | Status |
|---|---|
| Claude Code | Fully supported |
| Codex | Fully supported |
| Gemini CLI | Fully supported |
| OpenCode | Fully supported |
| Cursor | Supported (rewind unavailable) |
| Factory AI Droid | Fully supported |
| Copilot CLI | Fully supported |

---

## Quick Start

Swift is a **library first**: its full command tree is built by `cli.NewRootCmd()`
and surfaced inside the **Hawk** CLI as `hawk swift ...` (Hawk is in development —
no public install yet). A minimal standalone entrypoint also exists at
`cmd/swift/main.go`; it is not built or released by the Makefile, but contributors
can produce a local `swift` binary with `go build ./cmd/swift`.

**Contributors — build/test the library from source:**

```bash
git clone https://github.com/GrayCodeAI/swift && cd swift
go build ./...
go test ./...
```

Once Hawk is available, use the commands under `hawk swift`:

```bash
# Enable in your project
cd your-project
hawk swift enable

# Check status
hawk swift status
```

That's it. Swift runs silently in the background via Git hooks.

---

## How It Works

```
Your Branch                    swift/checkpoints/v1
     |                                  |
     v                                  |
[Base Commit]                           |
     |                                  |
     |  +--- Agent works ---+           |
     |  |  Step 1           |           |
     |  |  Step 2           |           |
     |  |  Step 3           |           |
     |  +-------------------+           |
     |                                  |
     v                                  v
[Your Commit] ----------------------> [Session Metadata]
     |                           (transcript, prompts,
     v                            files touched, tokens)
```

**Key principles:**

- Zero commits on your active branch
- Session data stored on `swift/checkpoints/v1` orphan branch
- Checkpoints created automatically at each commit
- Non-destructive rewind — restores files without altering history
- Works on any branch (main, feature, etc.)

---

## Typical Workflow

The examples below use the standalone `swift` binary; under Hawk the same
commands run as `hawk swift ...`.

### 1. Enable

```bash
swift enable                     # Interactive setup
swift enable --agent claude-code # Non-interactive
```

### 2. Work normally

Use your AI agent as before. Swift captures everything in the background.

```bash
swift status   # Check session anytime
```

### 3. Rewind if needed

```bash
swift checkpoint rewind   # Select a checkpoint to restore
```

### 4. Resume on another branch

```bash
swift session resume <branch>   # Restore session metadata & continue
```

### 5. Disable (optional)

```bash
swift disable   # Removes hooks, code untouched
```

---

## Commands

| Command | Description |
|---|---|
| `swift enable` | Enable Swift in your repository |
| `swift disable` | Remove hooks from repository |
| `swift status` | Show current session info |
| `swift agent` | Add, remove, or list agent integrations |
| `swift configure` | Update non-agent settings |
| `swift checkpoint` | List, explain, rewind, search checkpoints |
| `swift checkpoint rewind` | Rewind to a previous checkpoint |
| `swift checkpoint explain` | Explain a session or checkpoint |
| `swift graph export` | Export sessions and checkpoints as portable graph nodes, edges, and events |
| `swift graph correlation --hawk-session <id>` | Resolve exact Swift session/checkpoint IDs captured for a Hawk persisted session |
| `swift fork` | Clone a checkpoint into a new independent session for A/B testing |
| `swift annotate` | Attach a comment to a session or checkpoint |
| `swift ci-init` | Configure Swift to auto-capture sessions in CI |
| `swift session` | View and manage sessions |
| `swift session resume` | Restore session on a branch |
| `swift session attach` | Attach to a detached session |
| `swift session export` | Export a session (JSON envelope or asciinema cast) |
| `swift clean` | Clean up orphaned session data |
| `swift doctor` | Diagnose and fix issues |
| `swift login` | Authenticate with Swift |
| `swift version` | Show CLI version |

### Hawk correlation

Set `SWIFT_TAG_HAWK_SESSION_ID` to the Hawk persisted-session ID before Swift's
session-start hook runs. Swift stores it through the existing session-tag
mechanism:

```bash
SWIFT_TAG_HAWK_SESSION_ID=hawk-session-123 <start-agent-command>
swift graph correlation --hawk-session hawk-session-123
```

The correlation command is read-only. It returns `swift.correlation/v1` JSON
with every exact Swift session match and its committed checkpoint IDs.
`checkpoint_lookup_complete` states whether checkpoint enumeration succeeded;
session identity remains usable when it is false, but consumers must ignore
the checkpoint list. A missing mapping produces `"matches": []`; Swift never
guesses from a branch, commit, timestamp, prompt, or similar-looking session
ID. The response exposes only correlation IDs and lifecycle fields, not
arbitrary session metadata.

Run `swift <command> --help` for detailed usage.

---

## Configuration

Swift stores config in `.swift/` at the repo root. Repositories set up before
the rebrand keep working: a legacy `.entire/settings.json` (or
`.entire/settings.local.json`) is still read when the `.swift/` file is absent,
and its content is copied to the new location on the first save.

### Project settings (`.swift/settings.json`)

Shared with the team, committed to git:

```json
{
  "enabled": true,
  "strategy_options": {
    "push_sessions": true,
    "summarize": { "enabled": true }
  }
}
```

### Local overrides (`.swift/settings.local.json`)

Personal, gitignored:

```json
{
  "log_level": "debug"
}
```

### All options

| Option | Values | Description |
|---|---|---|
| `enabled` | `true` / `false` | Toggle Swift |
| `log_level` | `debug`, `info`, `warn`, `error` | Logging verbosity |
| `strategy_options.push_sessions` | `true` / `false` | Auto-push checkpoints on git push |
| `strategy_options.checkpoint_remote` | `{"provider": "github", "repo": "..."}` | Push checkpoints to separate repo |
| `strategy_options.summarize.enabled` | `true` / `false` | AI summaries at commit time |
| `attribution.attribute_co_authored_by` | `true` / `false` | Append `Co-authored-by: <agent>` trailer (default on) |
| `attribution.attribute_author` | `true` / `false` | Set the git author to the agent (default off) |
| `attribution.attribute_committer` | `true` / `false` | Set the git committer to the agent (default off) |
| `dirty_commits` | `true` / `false` | Auto-commit a dirty working tree before an agent session (default on; `--no-dirty-commits` to skip) |
| `webhooks` | `{"urls": ["..."], "events": ["..."]}` | POST a JSON notification on session lifecycle events (default off) |
| `telemetry` | `true` / `false` | Anonymous usage analytics |

### Checkpoint Remote

Push session data to a separate private repo:

```bash
swift enable --checkpoint-remote github:myorg/checkpoints-private
```

---

## Security & Privacy

- Session transcripts live on `swift/checkpoints/v1` in your repo
- Secrets are automatically redacted (API keys, tokens, credentials) — best-effort
- Shadow branches used during sessions are local-only and never pushed
- See [docs/security-and-privacy.md](docs/security-and-privacy.md) for details

---

## Troubleshooting

| Issue | Fix |
|---|---|
| "Not a git repository" | `cd` into a git repo first |
| "Swift is disabled" | `swift enable` |
| "No rewind points" | Work with your agent, then commit |
| Shadow branch conflict | `swift clean --force` |

**Debug mode:**

```bash
SWIFT_LOG_LEVEL=debug swift status
```

**Reset everything:**

```bash
swift clean --all --force
```

**Accessibility:**

```bash
export ACCESSIBLE=1   # Screen reader friendly mode
```

---

## Development

```bash
git clone https://github.com/GrayCodeAI/swift.git
cd swift

# With make (recommended — consistent with all other hawk-eco repos)
make build
make test
make ci             # lint + test + security
make cover          # coverage report

# With mise (alternative)
mise install && mise trust
mise run build
mise run test
mise run test:ci
mise run fmt && mise run lint
```

See [docs/architecture.md](docs/architecture.md) for architecture details.

---

## License

MIT &mdash; see [LICENSE](LICENSE)

---

<p align="center">
  Built by <a href="https://github.com/GrayCodeAI">GrayCode AI</a>
</p>
