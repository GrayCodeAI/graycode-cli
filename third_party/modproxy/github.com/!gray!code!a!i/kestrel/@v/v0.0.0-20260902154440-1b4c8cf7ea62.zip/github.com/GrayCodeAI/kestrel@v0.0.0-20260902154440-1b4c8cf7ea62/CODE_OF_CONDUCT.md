# Code of Conduct

## Our pledge

We — the maintainers and contributors of the kestrel project — pledge to
make participation in our community a harassment-free experience for everyone,
regardless of age, body size, visible or invisible disability, ethnicity, sex
characteristics, gender identity and expression, level of experience,
education, socio-economic status, nationality, personal appearance, race,
religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our standards

Examples of behaviour that contributes to a positive environment:

- Demonstrating empathy and kindness toward other people.
- Being respectful of differing opinions, viewpoints, and experiences.
- Giving and gracefully accepting constructive feedback.
- Accepting responsibility, apologising to those affected by mistakes, and
  learning from the experience.
- Focusing on what is best not just for us as individuals, but for the
  overall community.

Examples of unacceptable behaviour:

- The use of sexualised language or imagery, and sexual attention or advances.
- Trolling, insulting or derogatory comments, and personal or political
  attacks.
- Public or private harassment.
- Publishing others' private information, such as a physical or email
  address, without their explicit permission.
- Other conduct which could reasonably be considered inappropriate in a
  professional setting.

## Enforcement

Community leaders are responsible for clarifying and enforcing our standards
of acceptable behaviour, and will take appropriate and fair corrective
action in response to any behaviour they deem inappropriate, threatening,
offensive, or harmful.

Instances of abusive, harassing, or otherwise unacceptable behaviour may be
reported to the maintainers via the contact in `SECURITY.md` or by opening a
confidential GitHub Security Advisory at
<https://github.com/GrayCodeAI/kestrel/security/advisories>. All
complaints will be reviewed and investigated promptly and fairly.

All community leaders are obligated to respect the privacy and security of
the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant, version 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html).

For answers to common questions about this code of conduct, see the
Contributor Covenant FAQ at <https://www.contributor-covenant.org/faq>.
