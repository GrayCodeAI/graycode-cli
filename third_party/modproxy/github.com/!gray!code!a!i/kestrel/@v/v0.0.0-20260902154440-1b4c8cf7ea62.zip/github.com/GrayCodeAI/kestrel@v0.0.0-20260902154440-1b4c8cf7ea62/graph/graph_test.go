package graph

import (
	"encoding/json"
	"testing"
	"time"
)

// TestSchemaParity locks kestrel/graph's JSON shape to eagle/graph's so hawk's
// reconciliation round-trips keep working. The expected string was computed by
// marshaling the identical value with eagle/graph while it was still a
// dependency.
func TestSchemaParity(t *testing.T) {
	n := Node{
		ID:        "n1",
		Kind:      NodeOperations,
		Scope:     Scope{RepositoryID: "repo"},
		CreatedAt: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Provenance: Provenance{
			Producer: "test",
		},
	}
	if err := n.Validate(); err != nil {
		t.Fatalf("Validate() error: %v", err)
	}

	got, err := json.Marshal(n)
	if err != nil {
		t.Fatalf("Marshal error: %v", err)
	}

	want := `{"id":"n1","kind":"operations","scope":{"repository_id":"repo"},"created_at":"2024-01-01T00:00:00Z","effective_at":"0001-01-01T00:00:00Z","provenance":{"producer":"test"}}`
	if string(got) != want {
		t.Fatalf("JSON mismatch:\n got: %s\nwant: %s", got, want)
	}
}
