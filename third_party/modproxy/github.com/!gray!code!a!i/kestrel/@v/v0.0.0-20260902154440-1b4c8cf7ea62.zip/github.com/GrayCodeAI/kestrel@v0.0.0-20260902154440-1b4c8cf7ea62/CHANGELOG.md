# Changelog

All notable changes to kestrel are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Changed
- Extracted the out-of-range confidence fallback in `toPublicFindings`
  into a documented package constant, `defaultConfidence` (0.6). No
  behavior change.

### Fixed
- **Configured fail thresholds now survive contract conversion.**
  `ToContractResult` copied `FailOn` by field assignment, leaving the
  contract's `FailOnSet` false so its `Failed()` ignored a
  user-configured below-critical threshold (e.g. `WithFailOn(High)`
  from the `CI` preset). Conversion now records the threshold via
  `SetFailOn`, so the contract `Result.Failed()` honors it.
- **Provider failures are now visible in `Stats`.** A review in which
  every LLM call failed previously succeeded silently — errors only
  appeared in the human-readable `Report`. `Stats.LLMErrors` now
  records one entry per failed call (concern calls and the
  self-reflection pass), and `ToContractResult` carries them into the
  shared `reviewcontracts.Stats.LLMErrors` field so hawk can surface
  partial results.

### Removed
- **Dead audit/graph API surface** (breaking, pre-1.0). The
  `WithGraph`, `WithAuditMode`, and `WithAuditTargets` options and the
  `AuditMode`, `AuditTarget`, `AuditTargetType`, `AuditOption`, and
  `ParseAuditMode` types configured `Reviewer` fields that were never
  read, and the `internal/graph` and `internal/audit` packages had no
  callers. Removed the options, types, packages, the unused `Reviewer`
  fields, and the `graph`/`audit` `.kestrel.toml` keys (the keys were
  silently ignored in effect; they now remain unparsed, which is the
  same behavior). Consumers should use `qualitygraph` for graph
  projection and `merlin` for deployed-surface auditing.

## [0.1.2] - 2026-07-04

### Changed
- **MCP server scaffolding moved to the shared
  [`falcon`](https://github.com/GrayCodeAI/falcon) module.**
  `mcp/server.go` now delegates server construction, the stdio and
  streamable-HTTP transports, and argument/result helpers to the kit.
  Tool names, schemas, and behavior are unchanged. The advertised MCP
  server version now tracks the `VERSION` file (`kestrel.Version`)
  instead of a hardcoded string.
- **Version re-baselined to `0.1.0`** across the MCP server advertisement
  and both SARIF driver-version sites. Aligns kestrel with the rest of
  the hawk-eco ecosystem (`hawk`, `shrike`, `eyrie`, `harrier`, `swift`,
  `merlin`).
  - `mcp/server.go`: `mcpserver.NewMCPServer("kestrel", "0.1.0", ...)`
  - `sarif.go`: `Driver.Version`/`Driver.SemanticVersion` → `"0.1.0"`
    (the SARIF spec version remains `"2.1.0"` — that's a different
    field; it identifies the SARIF format, not the tool)
  - `internal/output/output.go`: same fix in the duplicated SARIF code
    (`FormatSARIF` driver-version site)

### Added
- Numeric confidence scoring (0.0-1.0) on every finding
- SAST-LLM fusion for combining static analysis with LLM review
- Fix suggestion pipeline with 7 built-in remediation rules
- Memory bridge for harrier integration (context-aware reviews)

### Added — Production hygiene (top-50 OSS parity)
- `CODE_OF_CONDUCT.md` — Contributor Covenant 2.1.
- `.gitattributes` — LF normalization, binary detection, GitHub
  linguist hints (collapse `go.sum` in PR diffs).
- `.editorconfig` — UTF-8, LF, final newline, trim trailing whitespace,
  tabs for Go, 2-space indent for YAML/JSON/TOML.
- `.github/PULL_REQUEST_TEMPLATE.md` — Summary / Changes / Review-
  quality impact (eval-set numbers) / Testing / Checklist.
- `.github/ISSUE_TEMPLATE/bug_report.yml` — structured bug report
  with surface dropdown (library API / MCP / SARIF output / eval).
- `.github/ISSUE_TEMPLATE/feature_request.yml` — feature request with
  a `kind` selector (review concerns / static rules / SARIF / MCP /
  config / eval / output) and developer fit checks.
- `.github/ISSUE_TEMPLATE/config.yml` — routes security to advisories,
  questions to discussions, blocks blank issues.

---

## [0.4.0] — 2026-05-08

### Added
- Multi-concern parallel review with configurable concern specs
- Self-reflection pass for false-positive elimination
- Incremental review with last-reviewed commit tracking
- Eval framework for review quality regression testing
- Custom checks via .kestrel/checks/ markdown files
- Project rules ingestion from CLAUDE.md, CONTRIBUTING.md, .cursor/rules/
- SARIF output format
- MCP server integration (kestrel_review, kestrel_describe, kestrel_improve)

### Changed
- Improved token budget estimation with 4:1 input:output ratio
- Finding deduplication across concerns

---

## [0.1.0] — 2026-04-30

### Added
- Describe operation (PR description generation)
- Improve operation (code improvement suggestions)
- Filter findings with LLM validation
- InlineComment mapping for GitHub/GitLab posting
- TOML/JSON configuration file support
- File exclusion patterns

---

## [0.1.0] — 2026-04-28

### Added
- Initial release: Review() function with Provider interface
- Finding type with severity, CWE, file/line location
- Functional options pattern for configuration
- Quick, Standard, Thorough presets
- Concurrent concern processing
