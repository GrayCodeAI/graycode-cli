package types

import (
	"encoding/json"
	"testing"
	"time"
)

// TestTypesParity locks kestrel/types's JSON shape to eagle/types's so hawk's
// reconciliation round-trips keep working. The expected string was computed by
// marshaling the identical value with eagle/types while it was still a
// dependency.
func TestTypesParity(t *testing.T) {
	f := Finding{
		ID:         "f1",
		Source:     "hawk",
		Concern:    "con",
		Severity:   SeverityHigh,
		File:       "file.go",
		Line:       10,
		Message:    "msg",
		Confidence: 0.8,
		CreatedAt:  time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
	}
	if err := f.Validate(); err != nil {
		t.Fatalf("Validate() error: %v", err)
	}

	got, err := json.Marshal(f)
	if err != nil {
		t.Fatalf("Marshal error: %v", err)
	}

	want := `{"id":"f1","source":"hawk","concern":"con","severity":3,"file":"file.go","line":10,"message":"msg","confidence":0.8,"created_at":"2024-01-01T00:00:00Z"}`
	if string(got) != want {
		t.Fatalf("JSON mismatch:\n got: %s\nwant: %s", got, want)
	}
}
