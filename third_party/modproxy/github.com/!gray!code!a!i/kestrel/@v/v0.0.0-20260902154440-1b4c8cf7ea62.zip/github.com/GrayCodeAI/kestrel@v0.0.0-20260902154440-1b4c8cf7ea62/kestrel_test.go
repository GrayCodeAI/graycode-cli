package kestrel_test

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"testing"

	"github.com/GrayCodeAI/kestrel"
	"github.com/GrayCodeAI/kestrel/internal/review"
)

// mockProvider implements kestrel.Provider for testing.
type mockProvider struct {
	response string
	err      error
	calls    int64
	mu       sync.Mutex
}

func (m *mockProvider) Chat(ctx context.Context, messages []kestrel.Message, opts kestrel.ChatOpts) (*kestrel.Response, error) {
	m.mu.Lock()
	m.calls++
	m.mu.Unlock()
	if m.err != nil {
		return nil, m.err
	}
	return &kestrel.Response{
		Content:    m.response,
		TokensUsed: 500,
	}, nil
}

func (m *mockProvider) getCalls() int64 {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.calls
}

const testDiff = `diff --git a/handler.go b/handler.go
index abc1234..def5678 100644
--- a/handler.go
+++ b/handler.go
@@ -10,6 +10,10 @@ func handleRequest(w http.ResponseWriter, r *http.Request) {
 	userID := r.URL.Query().Get("id")

-	user, err := db.GetUser(userID)
+	query := "SELECT * FROM users WHERE id = '" + userID + "'"
+	user, err := db.RawQuery(query)
+	if err != nil {
+		log.Printf("Error: %v, query: %s", err, query)
+	}

 	json.NewEncoder(w).Encode(user)
 }
`

func mockFindings() string {
	findings := []struct {
		File      string `json:"file"`
		Line      int    `json:"line"`
		EndLine   int    `json:"end_line"`
		Severity  string `json:"severity"`
		Message   string `json:"message"`
		Fix       string `json:"fix"`
		Reasoning string `json:"reasoning"`
	}{
		{
			File:      "handler.go",
			Line:      13,
			EndLine:   14,
			Severity:  "critical",
			Message:   "SQL injection via string concatenation",
			Fix:       `query := "SELECT * FROM users WHERE id = $1"\nuser, err := db.Query(query, userID)`,
			Reasoning: "User input directly concatenated into SQL allows arbitrary query execution",
		},
		{
			File:      "handler.go",
			Line:      15,
			Severity:  "high",
			Message:   "SQL query logged with user data, potential information disclosure",
			Fix:       `log.Printf("Error fetching user: %v", err)`,
			Reasoning: "Logging raw SQL queries can expose sensitive data in log aggregators",
		},
	}
	out, _ := json.Marshal(findings)
	return string(out)
}

func TestReview_Basic(t *testing.T) {
	provider := &mockProvider{response: mockFindings()}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
		kestrel.WithConcerns("security"),
		kestrel.WithParallel(false),
	)
	if err != nil {
		t.Fatalf("Review failed: %v", err)
	}

	if len(result.Findings) != 2 {
		t.Fatalf("expected 2 findings, got %d", len(result.Findings))
	}

	if result.Findings[0].Severity != kestrel.SeverityCritical {
		t.Errorf("expected critical severity, got %v", result.Findings[0].Severity)
	}
	if result.Findings[0].File != "handler.go" {
		t.Errorf("expected handler.go, got %s", result.Findings[0].File)
	}
	if result.Stats.FilesReviewed != 1 {
		t.Errorf("expected 1 file reviewed, got %d", result.Stats.FilesReviewed)
	}
	if result.Stats.TokensUsed != 500 {
		t.Errorf("expected 500 tokens used, got %d", result.Stats.TokensUsed)
	}
}

func TestReview_MultipleConcerns(t *testing.T) {
	provider := &mockProvider{response: mockFindings()}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
		kestrel.WithConcerns("security", "bugs"),
		kestrel.WithParallel(true),
	)
	if err != nil {
		t.Fatalf("Review failed: %v", err)
	}

	if provider.getCalls() != 2 {
		t.Errorf("expected 2 provider calls (one per concern), got %d", provider.getCalls())
	}

	if result.Stats.TokensUsed != 1000 {
		t.Errorf("expected 1000 tokens (500 per call), got %d", result.Stats.TokensUsed)
	}
}

func TestReview_NoProvider(t *testing.T) {
	_, err := kestrel.Review(context.Background(), testDiff)
	if err != kestrel.ErrNoProvider {
		t.Errorf("expected ErrNoProvider, got %v", err)
	}
}

func TestReview_EmptyDiff(t *testing.T) {
	provider := &mockProvider{response: "[]"}
	_, err := kestrel.Review(
		context.Background(), "",
		kestrel.WithProvider(provider),
	)
	if err != kestrel.ErrEmptyDiff {
		t.Errorf("expected ErrEmptyDiff, got %v", err)
	}
}

func TestReview_ProviderError(t *testing.T) {
	provider := &mockProvider{err: fmt.Errorf("rate limited")}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
		kestrel.WithConcerns("security"),
		kestrel.WithParallel(false),
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(result.Findings) != 0 {
		t.Errorf("expected 0 findings on provider error, got %d", len(result.Findings))
	}
}

func TestResult_Failed(t *testing.T) {
	r := &kestrel.Result{
		FailOn: kestrel.SeverityHigh,
		Findings: []kestrel.Finding{
			{Severity: kestrel.SeverityLow, Message: "minor"},
		},
	}
	if r.Failed() {
		t.Error("should not fail on low finding when threshold is high")
	}

	r.Findings = append(r.Findings, kestrel.Finding{
		Severity: kestrel.SeverityHigh, Message: "major",
	})
	if !r.Failed() {
		t.Error("should fail when finding meets threshold")
	}
}

func TestResult_MaxSeverity(t *testing.T) {
	r := &kestrel.Result{
		Findings: []kestrel.Finding{
			{Severity: kestrel.SeverityLow},
			{Severity: kestrel.SeverityCritical},
			{Severity: kestrel.SeverityMedium},
		},
	}
	if r.MaxSeverity() != kestrel.SeverityCritical {
		t.Errorf("expected critical, got %v", r.MaxSeverity())
	}
}

func TestReview_Presets(t *testing.T) {
	provider := &mockProvider{response: "[]"}

	presets := []kestrel.Option{kestrel.Quick, kestrel.Thorough, kestrel.SecurityFocus, kestrel.CI}
	for _, preset := range presets {
		_, err := kestrel.Review(
			context.Background(), testDiff,
			kestrel.WithProvider(provider),
			preset,
		)
		if err != nil {
			t.Errorf("preset review failed: %v", err)
		}
	}
}

func TestReview_Deduplication(t *testing.T) {
	// Same finding from two concerns should be deduped
	response := `[{"file": "handler.go", "line": 13, "severity": "high", "message": "SQL injection", "fix": "use params"}]`
	provider := &mockProvider{response: response}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
		kestrel.WithConcerns("security", "bugs"),
		kestrel.WithParallel(false),
	)
	if err != nil {
		t.Fatalf("Review failed: %v", err)
	}

	if len(result.Findings) != 1 {
		t.Errorf("expected 1 finding after dedup, got %d", len(result.Findings))
	}
}

func TestReview_StatsLLMErrorsWhenAllProvidersFail(t *testing.T) {
	provider := &mockProvider{err: fmt.Errorf("rate limited")}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
	)
	if err != nil {
		t.Fatalf("Review() error = %v, want nil (provider errors are non-fatal)", err)
	}

	if len(result.Stats.LLMErrors) == 0 {
		t.Fatal("Stats.LLMErrors is empty; want one entry per failed concern")
	}

	// The default config reviews five concerns; every one of them must
	// report its error so callers can tell the review was partial.
	concerns := map[string]bool{}
	for _, e := range result.Stats.LLMErrors {
		if !strings.Contains(e, "rate limited") {
			t.Errorf("LLMErrors entry %q does not mention the provider error", e)
		}
		name := e
		if idx := strings.Index(name, "]"); idx >= 0 {
			name = strings.Trim(name[:idx], "[]")
		}
		concerns[name] = true
	}
	for _, want := range []string{"security", "bugs", "performance", "correctness", "style"} {
		if !concerns[want] {
			t.Errorf("no LLM error reported for concern %q; got %v", want, result.Stats.LLMErrors)
		}
	}

	contract := kestrel.ToContractResult(result)
	if len(contract.Stats.LLMErrors) != len(result.Stats.LLMErrors) {
		t.Errorf("contract Stats.LLMErrors len = %d, want %d", len(contract.Stats.LLMErrors), len(result.Stats.LLMErrors))
	}
}

// reflectFailProvider succeeds for concern calls but fails the
// self-reflection call, which is identifiable by its system prompt.
type reflectFailProvider struct {
	response string
	calls    int64
	mu       sync.Mutex
}

func (p *reflectFailProvider) Chat(ctx context.Context, messages []kestrel.Message, opts kestrel.ChatOpts) (*kestrel.Response, error) {
	p.mu.Lock()
	p.calls++
	p.mu.Unlock()
	if opts.System == review.ReflectSystemPrompt {
		return nil, fmt.Errorf("reflection backend down")
	}
	return &kestrel.Response{Content: p.response, TokensUsed: 10}, nil
}

func TestReview_StatsLLMErrorsIncludesReflectionFailure(t *testing.T) {
	provider := &reflectFailProvider{
		response: `[{"file": "handler.go", "line": 13, "severity": "high", "message": "SQL injection", "fix": "use params"}]`,
	}

	result, err := kestrel.Review(
		context.Background(), testDiff,
		kestrel.WithProvider(provider),
		kestrel.WithConcerns("security"),
		kestrel.WithParallel(false),
		kestrel.WithReflection(true),
	)
	if err != nil {
		t.Fatalf("Review() error = %v, want nil (reflection errors are non-fatal)", err)
	}

	if len(result.Stats.LLMErrors) != 1 {
		t.Fatalf("Stats.LLMErrors = %v, want exactly one reflection entry", result.Stats.LLMErrors)
	}
	if !strings.HasPrefix(result.Stats.LLMErrors[0], "[reflection]") || !strings.Contains(result.Stats.LLMErrors[0], "reflection backend down") {
		t.Errorf("unexpected reflection error entry: %q", result.Stats.LLMErrors[0])
	}

	// The pre-reflection findings must survive the failed reflection pass.
	if len(result.Findings) == 0 {
		t.Error("findings were lost when the reflection pass failed")
	}
}
