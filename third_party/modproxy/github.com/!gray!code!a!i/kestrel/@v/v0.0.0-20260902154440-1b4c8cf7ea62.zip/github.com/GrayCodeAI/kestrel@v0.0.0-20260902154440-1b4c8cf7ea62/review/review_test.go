package review

import (
	"encoding/json"
	"testing"

	contracts "github.com/GrayCodeAI/kestrel/types"
)

// TestReviewParity locks kestrel/review's JSON shape to eagle/review's so
// hawk's reconciliation round-trips keep working. The expected string was
// computed by marshaling the identical value with eagle/review while it was
// still a dependency.
func TestReviewParity(t *testing.T) {
	r := Result{
		Findings: []Finding{
			{
				Concern:    "con",
				Severity:   contracts.SeverityHigh,
				File:       "file.go",
				Line:       10,
				Message:    "msg",
				Confidence: 0.8,
			},
		},
	}
	if err := r.Findings[0].Validate(); err != nil {
		t.Fatalf("Validate() error: %v", err)
	}

	got, err := json.Marshal(r)
	if err != nil {
		t.Fatalf("Marshal error: %v", err)
	}

	want := `{"findings":[{"concern":"con","severity":3,"file":"file.go","line":10,"message":"msg","confidence":0.8}],"comments":null,"stats":{"files_reviewed":0,"hunks_analyzed":0,"findings_total":0,"by_severity":null,"by_concern":null,"tokens_used":0,"duration_per_concern":null,"average_confidence":0,"high_confidence_count":0,"low_confidence_count":0},"report":"","fail_on":0}`
	if string(got) != want {
		t.Fatalf("JSON mismatch:\n got: %s\nwant: %s", got, want)
	}
}
