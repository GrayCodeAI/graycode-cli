<p align="center">
  <h1 align="center">Kestrel</h1>
  <p align="center">
    <strong>AI-powered code review for diffs</strong>
  </p>
  <p align="center">
    <a href="https://golang.org/"><img src="https://img.shields.io/badge/Go-1.26+-00ADD8?style=flat-square&logo=go&logoColor=white" alt="Go"></a>
    <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue?style=flat-square" alt="License"></a>
    <a href="https://github.com/GrayCodeAI/kestrel/actions/workflows/ci.yml"><img src="https://img.shields.io/github/actions/workflow/status/GrayCodeAI/kestrel/ci.yml?style=flat-square&label=tests" alt="CI"></a>
  </p>
</p>

---

Kestrel provides intelligent code review capabilities by analyzing diffs with AI. It understands context, identifies issues, and suggests improvements.

## Product boundary

Kestrel reviews source changes, diffs, dependency structure, and static-analysis
results. It does not crawl or audit a running website. Browser or deployed-URL
auditing belongs to `merlin`; Hawk is responsible for composing results when a
workflow needs both source review and live-target verification.

## Ecosystem Boundaries

Kestrel is a Hawk support engine. Keep the dependency edge one-way:

- use `eagle` for any cross-repo shared contracts (severity/finding vocabulary)
- do not import `hawk/internal/*`
- do not import removed legacy path `hawk/shared/types`; use `eagle/types`
- do not import other engines (`eyrie`, `harrier`, `shrike`, `swift`, `merlin`) — engines are peers, not dependencies

> **Note:** `memory_bridge.go` is an intentional boundary exception — it calls
> `harrier` directly for automated memory persistence after reviews. This is documented
> as a known trade-off; the canonical integration path is via hawk.

## Features

- **Diff-aware analysis** - Reviews only changed code with full context
- **Severity classification** - Categorizes findings by impact
- **Provider agnostic** - Works with any LLM provider through the `Provider` interface
- **Extensible rules** - Add custom review rules for your codebase

## Quick Start

```bash
go get github.com/GrayCodeAI/kestrel
```

```go
import "github.com/GrayCodeAI/kestrel"

reviewer := kestrel.NewReviewer(
    kestrel.WithProvider(myLLMProvider),
    kestrel.Thorough,
)

result, err := reviewer.Review(ctx, diff)
for _, f := range result.Findings {
    fmt.Printf("[%s] %s:%d - %s\n", f.Severity, f.File, f.Line, f.Message)
}
```

## Examples

See the [examples/](examples/) directory for runnable code samples.

## Portable quality graph

`qualitygraph.Build` projects a completed `kestrel.Result` into bounded shared
quality nodes, report-to-finding `contains` edges, and observation events.
Source diffs, paths, report text, messages, fixes, and reasoning are retained
only as SHA-256 digests. Kestrel remains the review source of truth; consumers
such as Hawk may journal and compose the projection.

## Provider Interface

Implement the `Provider` interface to use any LLM:

```go
type Provider interface {
    Chat(ctx context.Context, messages []Message, opts ChatOpts) (*Response, error)
}
```

## Installation

```bash
go get github.com/GrayCodeAI/kestrel@latest
```

Requires Go 1.26+.

## Contributing

Contributions are welcome — please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

## License

MIT - see [LICENSE](LICENSE) for details.
