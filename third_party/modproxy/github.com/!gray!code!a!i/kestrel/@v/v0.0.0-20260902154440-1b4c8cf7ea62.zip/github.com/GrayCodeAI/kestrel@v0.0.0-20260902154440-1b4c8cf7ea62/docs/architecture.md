<div align="center">

# 👁️ kestrel Architecture

**AI-Powered Code Review on Diffs**

[![Go](https://img.shields.io/badge/Go-1.26+-00ADD8?logo=go)](https://go.dev/)
[![Protocol](https://img.shields.io/badge/Protocol-MCP-purple)]()

</div>

---

## 🎯 Overview

kestrel is an AI-powered code review library for Go. It parses unified diffs, enriches with **code context** and **git history**, and runs **parallel multi-concern reviews** through an LLM provider.

> 💡 No LLM client bundled — consumers inject their own via the `Provider` interface.

---

## 🧱 Components

```
kestrel/
├── api/openapi.yaml          📜 MCP tool surface reference
├── examples/basic/main.go    🧪 Library usage example (Review with a mock provider)
├── kestrel.go                  📤 Public API: Review(), Finding, Result, Stats
├── reviewer.go               🔄 Reviewer: parallel concern orchestration
├── options.go                ⚙️ config, With* functions, presets
├── provider.go               🔌 Provider interface (consumers implement)
├── qualitygraph/             🕸️ Privacy-safe shared quality graph projection
├── severity.go               📊 Re-exports from eagle/types
├── static_rules.go           🛡️ 30+ static analysis rules
├── taint_analysis.go         🔗 SSA-based taint tracking
├── sast_integration.go       🔒 SAST-LLM fusion
├── autofix.go                🔧 Fix suggestion pipeline
├── eval.go                   📊 Evaluation harness
├── mcp/                      🔌 MCP server (stdio + HTTP)
└── internal/
    ├── diff/                 📄 Unified diff parser
    ├── review/               🧠 Concerns, prompts, response parsing
    ├── comment/              💬 Inline comment formatting
    ├── context/              📖 Code context + git blame
    └── output/               📊 SARIF and terminal formatters
```

`qualitygraph.Build` is an explicit read-only boundary after review. It never
runs a review or persists graph state, and it excludes source and human-readable
review content from graph attributes.

---

## 📤 Public API

```go
// 🚀 One-shot review
result, err := kestrel.Review(ctx, diffText,
    kestrel.WithProvider(myLLMProvider),
    kestrel.Thorough,
)

// 🔄 Reusable reviewer
reviewer := kestrel.NewReviewer(kestrel.WithProvider(myLLMProvider))
result, err := reviewer.Review(ctx, diffText)

// ❌ Check if any findings are above threshold
if result.Failed() {
    fmt.Printf("Review failed: %d findings\n", len(result.Findings))
}
```

---

## 🔌 Provider Interface

```go
type Provider interface {
    Chat(ctx context.Context, messages []Message, opts ChatOpts) (*Response, error)
}
```

> Consumers implement this with their LLM client (e.g., using eyrie). hawk wires eyrie as the provider via `internal/bridge/kestrel/bridge.go`.

---

## ⚡ Presets

| Preset | Concerns | Speed |
|--------|----------|:-----:|
| 🏃 `Quick` | security, correctness | Fast |
| 📊 `Standard` | security, correctness, style, docs | Medium |
| 🔬 `Thorough` | all concerns | Slow |
| 🔒 `SecurityFocus` | security, taint only | Fast |
| 🤖 `CI` | Standard, fail on High+ | Medium |

---

## 🔌 MCP Server

kestrel ships no standalone binary — the MCP server is an embeddable component
that the host program (e.g. `hawk`) starts after injecting a `Provider`:

```go
srv := mcp.New(myProvider, kestrel.Thorough)
srv.ServeStdio()             // 📡 stdio transport
srv.ServeHTTP("127.0.0.1:8080") // 🌐 streamable HTTP transport, served at /mcp
```

**Tools:** `kestrel_review` · `kestrel_describe` · `kestrel_improve` · `kestrel_taint`

---

## 🔎 Findings

| Field | Description |
|-------|-------------|
| `Concern` | Review category (security, style, etc.) |
| `Severity` | 🟢 Info · 🟡 Low · 🟠 Medium · 🔴 High · 🟥 Critical |
| `File` / `Line` | Location in the diff |
| `Message` | What was found and why |
| `Fix` | Suggested fix |
| `CWE` | CWE reference (security findings) |
| `Confidence` | 0.0–1.0 score |
| `InlineComment` | PR-ready inline comment |

---

## 🛡️ Static Rules + Taint Analysis

**30+ built-in rules** run without LLM overhead — hardcoded secret patterns, SQL injection sinks, unsafe deserialization, etc. Fused with LLM results.

**Taint analysis** (exposed via the `kestrel_taint` MCP tool and the taint-analysis API) uses SSA-based cross-function tracking to detect source→sink data flows. Sources, sinks, and sanitizers are configurable.

---

## 🌐 Browser Automation Tools

The `internal/tool` package provides **HTTP-based browser automation** capabilities:

**Key capabilities:**
- HTTP client with configurable timeouts and redirects
- Browser tool with GET, POST, and header management
- Response parsing with JSON support
- Webhook testing: send test payloads and validate responses
- Formatter for structured output

**Usage:**
```go
// Create browser tool
browser := tool.NewBrowserTool()

// Make requests
resp, err := browser.Get(ctx, "https://example.com")
if err == nil && resp.IsSuccess() {
    fmt.Printf("Status: %d\n", resp.StatusCode)
}

// Test webhooks
webhook := tool.NewWebhookTester()
resp, err := webhook.SendTestRequest(ctx, "https://webhook.example.com", payload)
```
