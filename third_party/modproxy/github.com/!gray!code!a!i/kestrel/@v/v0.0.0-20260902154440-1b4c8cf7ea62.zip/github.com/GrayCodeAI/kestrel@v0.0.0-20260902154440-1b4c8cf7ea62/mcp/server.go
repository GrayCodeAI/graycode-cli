package mcp

import (
	"context"
	"fmt"
	"strings"
	"time"

	mcpkit "github.com/GrayCodeAI/kestrel/internal/mcpkit"
	mcplib "github.com/mark3labs/mcp-go/mcp"

	"github.com/GrayCodeAI/kestrel"
)

// Server wraps the kestrel library as an MCP server, exposing code review
// capabilities to any MCP-compatible agent.
type Server struct {
	kit      *mcpkit.Server
	provider kestrel.Provider
	opts     []kestrel.Option
}

// New creates a kestrel MCP server with the given LLM provider and options.
func New(provider kestrel.Provider, opts ...kestrel.Option) *Server {
	s := &Server{
		kit:      mcpkit.New("kestrel", kestrel.Version),
		provider: provider,
		opts:     opts,
	}
	s.registerTools()
	return s
}

// ServeStdio starts the MCP server on stdin/stdout.
func (s *Server) ServeStdio() error {
	return s.kit.ServeStdio()
}

// ServeHTTP starts the MCP server on a streamable HTTP endpoint. Clients
// connect to http://<addr>/mcp.
func (s *Server) ServeHTTP(addr string) error {
	return s.kit.ServeHTTP(addr)
}

func (s *Server) registerTools() {
	s.kit.AddTool(mcplib.NewTool(
		"kestrel_review",
		mcplib.WithDescription("Run AI code review on a unified diff"),
		mcplib.WithString("diff", mcplib.Required(), mcplib.Description("Unified diff text to review")),
	), s.handleReview)

	s.kit.AddTool(mcplib.NewTool(
		"kestrel_describe",
		mcplib.WithDescription("Generate a PR description from a unified diff"),
		mcplib.WithString("diff", mcplib.Required(), mcplib.Description("Unified diff text")),
	), s.handleDescribe)

	s.kit.AddTool(mcplib.NewTool(
		"kestrel_improve",
		mcplib.WithDescription("Suggest code improvements (non-bug focused)"),
		mcplib.WithString("diff", mcplib.Required(), mcplib.Description("Unified diff text")),
	), s.handleImprove)

	s.kit.AddTool(mcplib.NewTool(
		"kestrel_taint",
		mcplib.WithDescription("Run SSA-based cross-function taint analysis on Go packages and return security findings (no LLM required)"),
		mcplib.WithString("path", mcplib.Required(), mcplib.Description("Filesystem path to the module/directory to analyze")),
		mcplib.WithString("patterns", mcplib.Description("Comma-separated go package patterns to load (default \"./...\")")),
	), s.handleTaint)
}

func (s *Server) handleTaint(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	path := mcpkit.StrArg(req, "path")
	if path == "" {
		return mcplib.NewToolResultError("path is required"), nil
	}
	var patterns []string
	if p := mcpkit.StrArg(req, "patterns"); p != "" {
		for _, part := range strings.Split(p, ",") {
			if part = strings.TrimSpace(part); part != "" {
				patterns = append(patterns, part)
			}
		}
	}

	ctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
	defer cancel()

	analyzer := kestrel.NewSSATaintAnalyzer()
	findings, err := analyzer.AnalyzePackagesContext(ctx, path, patterns...)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("taint analysis failed: %v", err)), nil
	}
	return mcpkit.JSONResult(findings)
}

func (s *Server) handleReview(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	diff := mcpkit.StrArg(req, "diff")
	if diff == "" {
		return mcplib.NewToolResultError("diff is required"), nil
	}

	opts := append([]kestrel.Option{kestrel.WithProvider(s.provider)}, s.opts...)
	result, err := kestrel.Review(ctx, diff, opts...)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("review failed: %v", err)), nil
	}
	return mcpkit.JSONResult(result)
}

func (s *Server) handleDescribe(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	diff := mcpkit.StrArg(req, "diff")
	if diff == "" {
		return mcplib.NewToolResultError("diff is required"), nil
	}

	opts := append([]kestrel.Option{kestrel.WithProvider(s.provider)}, s.opts...)
	desc, err := kestrel.Describe(ctx, diff, opts...)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("describe failed: %v", err)), nil
	}
	return mcpkit.JSONResult(desc)
}

func (s *Server) handleImprove(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	diff := mcpkit.StrArg(req, "diff")
	if diff == "" {
		return mcplib.NewToolResultError("diff is required"), nil
	}

	opts := append([]kestrel.Option{kestrel.WithProvider(s.provider)}, s.opts...)
	result, err := kestrel.Improve(ctx, diff, opts...)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("improve failed: %v", err)), nil
	}
	return mcpkit.JSONResult(result)
}
