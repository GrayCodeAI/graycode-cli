package graph

import (
	"encoding/json"
	"testing"
	"time"
)

// TestSchemaParity pins the vendored Node contract to the exact wire JSON
// shared across the hawk-eco ecosystem. It guards against accidental schema
// drift between eagle/graph and merlin/graph.
func TestSchemaParity(t *testing.T) {
	n := Node{
		ID:        "n1",
		Kind:      NodeOperations,
		Scope:     Scope{RepositoryID: "repo"},
		CreatedAt: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Provenance: Provenance{
			Producer: "test",
		},
	}
	if err := n.Validate(); err != nil {
		t.Fatalf("fixture must satisfy Validate: %v", err)
	}

	got, err := json.Marshal(n)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	const want = `{"id":"n1","kind":"operations","scope":{"repository_id":"repo"},"created_at":"2024-01-01T00:00:00Z","effective_at":"0001-01-01T00:00:00Z","provenance":{"producer":"test"}}`
	if string(got) != want {
		t.Fatalf("schema parity mismatch\n got: %s\nwant: %s", got, want)
	}
}
