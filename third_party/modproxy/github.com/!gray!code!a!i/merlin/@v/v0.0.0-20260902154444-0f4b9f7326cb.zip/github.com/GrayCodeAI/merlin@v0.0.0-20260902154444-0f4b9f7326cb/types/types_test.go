package types

import (
	"encoding/json"
	"testing"
	"time"
)

// TestTypesParity pins the vendored Finding contract to the exact wire JSON
// produced by eagle/types. It guards against accidental schema drift between
// eagle/types and merlin/types.
func TestTypesParity(t *testing.T) {
	f := Finding{
		ID:         "kestrel:SQLInjection:app.go:42",
		Source:     "kestrel",
		Concern:    "SQLInjection",
		Severity:   SeverityHigh,
		File:       "app.go",
		Line:       42,
		Message:    "unsafe SQL concatenation",
		CWE:        "CWE-89",
		Confidence: 0.9,
		CreatedAt:  time.Date(2024, 1, 2, 3, 4, 5, 0, time.UTC),
	}
	if err := f.Validate(); err != nil {
		t.Fatalf("fixture must satisfy Validate: %v", err)
	}

	got, err := json.Marshal(f)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	const want = `{"id":"kestrel:SQLInjection:app.go:42","source":"kestrel","concern":"SQLInjection","severity":3,"file":"app.go","line":42,"message":"unsafe SQL concatenation","cwe":"CWE-89","confidence":0.9,"created_at":"2024-01-02T03:04:05Z"}`
	if string(got) != want {
		t.Fatalf("parity mismatch\n got: %s\nwant: %s", got, want)
	}
}
