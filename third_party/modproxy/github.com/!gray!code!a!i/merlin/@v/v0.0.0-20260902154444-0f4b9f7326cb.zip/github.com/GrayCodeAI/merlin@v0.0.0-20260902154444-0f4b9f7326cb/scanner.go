package merlin

import (
	"context"
	"fmt"
	"os"
	"sort"
	"sync"
	"time"

	"github.com/GrayCodeAI/merlin/internal/check"
	"github.com/GrayCodeAI/merlin/internal/crawler"
)

// Scanner is a reusable site auditor. Create one with NewScanner and call
// Scan multiple times. It is safe for concurrent use.
type Scanner struct {
	cfg *config
}

// NewScanner creates a configured Scanner. Apply presets and options:
//
//	s := merlin.NewScanner(merlin.Standard, merlin.WithDepth(3))
func NewScanner(opts ...Option) *Scanner {
	return &Scanner{cfg: buildConfig(opts)}
}

// Scan crawls the target URL and runs all configured checks against the
// discovered pages. Returns a complete Report with findings and stats.
func (s *Scanner) Scan(ctx context.Context, target string) (*Report, error) {
	return s.scan(ctx, target, nil)
}

// scan is the shared implementation of Scan and ScanDir. allowPrivateAddrs
// lists exact host:port addresses exempt from the crawler's SSRF private-IP
// blocking for this scan only; ScanDir uses it for the ephemeral local file
// server it starts. It must only ever contain addresses the scanner itself
// brought up, never user-supplied input.
func (s *Scanner) scan(ctx context.Context, target string, allowPrivateAddrs []string) (*Report, error) {
	if s.cfg.timeout > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, s.cfg.timeout)
		defer cancel()
	}

	start := time.Now()

	crawlCfg := crawler.Config{
		MaxDepth:           s.cfg.depth,
		Concurrency:        s.cfg.concurrency,
		Timeout:            s.cfg.timeout,
		PageTimeout:        s.cfg.pageTimeout,
		RateLimit:          s.cfg.rateLimit,
		UserAgent:          s.cfg.userAgent,
		FollowRedirects:    s.cfg.followRedirects,
		RespectRobots:      s.cfg.respectRobots,
		Exclude:            s.cfg.exclude,
		AuthHeader:         s.cfg.authHeader,
		AuthValue:          s.cfg.authValue,
		CookieJar:          s.cfg.cookieJar,
		AllowPrivateIPs:    !s.cfg.blockPrivateIPs,
		PrivateIPAllowlist: allowPrivateAddrs,
		Logger:             s.cfg.logger,
		MaxPages:           s.cfg.maxPages,
	}

	if s.cfg.circuitBreakerOn {
		threshold := s.cfg.circuitBreakerThreshold
		if threshold <= 0 {
			threshold = 5
		}
		cooldown := s.cfg.circuitBreakerCooldown
		if cooldown <= 0 {
			cooldown = 30 * time.Second
		}
		crawlCfg.CircuitBreaker = crawler.NewCircuitBreakerRegistry(threshold, cooldown)
	}

	// Route page retrieval through a headless browser when one is configured,
	// so JavaScript-rendered content is analyzed instead of raw HTTP responses.
	if s.cfg.browser != nil {
		crawlCfg.Fetcher = newBrowserFetcher(s.cfg.browser, s.cfg.userAgent, s.cfg.pageTimeout)
	}

	if s.cfg.logger != nil {
		s.cfg.logger.Info("merlin: starting crawl", "target", target, "depth", s.cfg.depth)
	}

	c := crawler.New(crawlCfg)
	pages, err := c.Crawl(ctx, target)
	if err != nil {
		return nil, fmt.Errorf("merlin: crawl failed: %w", err)
	}

	if s.cfg.logger != nil {
		s.cfg.logger.Info("merlin: crawl complete", "pages", len(pages))
	}

	registry := check.DefaultRegistry()
	// Apply accepted status codes to the links checker
	if len(s.cfg.acceptedStatusCodes) > 0 {
		registry.Register(&check.LinksCheck{AcceptedStatusCodes: s.cfg.acceptedStatusCodes})
	}
	for _, custom := range getCustomInternalChecks(s.cfg.customChecks, s.cfg.customRules) {
		registry.Register(custom)
	}
	for _, custom := range getGlobalCustomInternalChecks() {
		registry.Register(custom)
	}
	enabledChecks := registry.Filter(s.cfg.checks)

	var (
		mu          sync.Mutex
		allFindings []Finding
		durations   = make(map[string]time.Duration)
	)

	const perCheckTimeout = 30 * time.Second

	var wg sync.WaitGroup
	for _, chk := range enabledChecks {
		wg.Add(1)
		go func(chk check.Checker) {
			defer wg.Done()
			checkStart := time.Now()

			checkCtx, checkCancel := context.WithTimeout(ctx, perCheckTimeout)
			defer checkCancel()

			type checkResult struct {
				findings []check.Finding
			}
			done := make(chan checkResult, 1)
			go func() {
				done <- checkResult{findings: chk.Run(checkCtx, pages)}
			}()

			var findings []check.Finding
			var timedOut bool
			select {
			case res := <-done:
				findings = res.findings
			case <-checkCtx.Done():
				timedOut = true
			}
			elapsed := time.Since(checkStart)

			var converted []Finding
			if timedOut {
				converted = []Finding{{
					Check:    chk.Name(),
					Severity: SeverityLow,
					URL:      target,
					Message:  fmt.Sprintf("check %q timed out after %s", chk.Name(), perCheckTimeout),
				}}
			} else {
				converted = make([]Finding, len(findings))
				for i, f := range findings {
					converted[i] = Finding{
						Check:    chk.Name(),
						Severity: f.Severity,
						URL:      f.URL,
						Element:  f.Element,
						Message:  f.Message,
						Fix:      f.Fix,
						Evidence: f.Evidence,
					}
				}
			}

			mu.Lock()
			allFindings = append(allFindings, converted...)
			durations[chk.Name()] = elapsed
			mu.Unlock()
		}(chk)
	}
	wg.Wait()

	sort.Slice(allFindings, func(i, j int) bool {
		if allFindings[i].Severity != allFindings[j].Severity {
			return allFindings[i].Severity > allFindings[j].Severity
		}
		return allFindings[i].URL < allFindings[j].URL
	})

	bySev := make(map[Severity]int)
	byCheck := make(map[string]int)
	for _, f := range allFindings {
		bySev[f.Severity]++
		byCheck[f.Check]++
	}

	report := &Report{
		Target:      target,
		Findings:    allFindings,
		CrawledURLs: len(pages),
		Duration:    time.Since(start),
		FailOn:      s.cfg.failOn,
		Stats: Stats{
			PagesScanned:     len(pages),
			FindingsTotal:    len(allFindings),
			BySeverity:       bySev,
			ByCheck:          byCheck,
			DurationPerCheck: durations,
		},
	}

	return report, nil
}

// ScanDir scans a local directory by starting a temporary file server.
// Useful for auditing build output before deployment.
func (s *Scanner) ScanDir(ctx context.Context, dir string) (*Report, error) {
	info, err := os.Stat(dir)
	if err != nil {
		return nil, fmt.Errorf("merlin: cannot access directory %q: %w", dir, err)
	}
	if !info.IsDir() {
		return nil, fmt.Errorf("merlin: %q is not a directory", dir)
	}
	srv, addr, err := crawler.ServeDir(ctx, dir)
	if err != nil {
		return nil, err
	}
	defer srv.Close()
	// The temporary file server listens on loopback, which the crawler's
	// SSRF protection (enabled by default) would reject. Exempt exactly
	// this listener address for the duration of the scan so ScanDir works
	// with default options; every other private address stays blocked.
	return s.scan(ctx, "http://"+addr, []string{addr})
}
