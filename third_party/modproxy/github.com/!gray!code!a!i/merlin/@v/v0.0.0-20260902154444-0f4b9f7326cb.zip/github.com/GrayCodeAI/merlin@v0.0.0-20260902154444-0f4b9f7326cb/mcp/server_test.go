package mcp

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	mcplib "github.com/mark3labs/mcp-go/mcp"
	mcpserver "github.com/mark3labs/mcp-go/server"

	"github.com/GrayCodeAI/merlin"
)

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

// jsonRPCRequest builds a raw JSON-RPC 2.0 request body.
func jsonRPCRequest(id int, method string, params map[string]any) map[string]any {
	return map[string]any{
		"jsonrpc": "2.0",
		"id":      id,
		"method":  method,
		"params":  params,
	}
}

// postJSON sends a POST with Content-Type application/json.
func postJSON(url string, body any) (*http.Response, error) {
	b, _ := json.Marshal(body)
	req, _ := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(b))
	req.Header.Set("Content-Type", "application/json")
	return http.DefaultClient.Do(req)
}

// postSessionJSON sends a POST with both Content-Type and session ID header.
func postSessionJSON(url, sessionID string, body any) (*http.Response, error) {
	b, _ := json.Marshal(body)
	req, _ := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(b))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set(mcpserver.HeaderKeySessionID, sessionID)
	return http.DefaultClient.Do(req)
}

// readBody reads and closes a response body.
func readBody(t *testing.T, resp *http.Response) []byte {
	t.Helper()
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	return data
}

// initAndSession performs the initialize handshake against a stateful
// streamable-HTTP test server and returns the session ID.
func initAndSession(t *testing.T, ts *httptest.Server) string {
	t.Helper()
	resp, err := postJSON(ts.URL, jsonRPCRequest(1, "initialize", map[string]any{
		"protocolVersion": mcplib.LATEST_PROTOCOL_VERSION,
		"clientInfo": map[string]any{
			"name":    "test-client",
			"version": "1.0.0",
		},
	}))
	if err != nil {
		t.Fatalf("initialize request: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		t.Fatalf("initialize: status %d, body: %s", resp.StatusCode, body)
	}
	sid := resp.Header.Get(mcpserver.HeaderKeySessionID)
	if sid == "" {
		t.Fatal("expected session ID in initialize response header")
	}
	return sid
}

// newTestHTTPServer creates a stateful streamable-HTTP test server backed by
// the merlin MCP server with the given options.
func newTestHTTPServer(t *testing.T, opts ...merlin.Option) (*httptest.Server, *Server) {
	t.Helper()
	s := New(opts...)
	ts := mcpserver.NewTestStreamableHTTPServer(s.kit.MCP(), mcpserver.WithStateful(true))
	t.Cleanup(ts.Close)
	return ts, s
}

// ---------------------------------------------------------------------------
// 1. Protocol handling -- initialize, tools/list, tools/call over HTTP
// ---------------------------------------------------------------------------

func TestProtocol_Initialize(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	defer ts.Close()

	resp, err := postJSON(ts.URL, jsonRPCRequest(1, "initialize", map[string]any{
		"protocolVersion": mcplib.LATEST_PROTOCOL_VERSION,
		"clientInfo": map[string]any{
			"name":    "test-client",
			"version": "1.0.0",
		},
	}))
	if err != nil {
		t.Fatalf("initialize: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}

	body := readBody(t, resp)
	var result struct {
		ID      int    `json:"id"`
		JSONRPC string `json:"jsonrpc"`
		Result  struct {
			ProtocolVersion string `json:"protocolVersion"`
			ServerInfo      struct {
				Name    string `json:"name"`
				Version string `json:"version"`
			} `json:"serverInfo"`
			Capabilities map[string]any `json:"capabilities"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if result.JSONRPC != "2.0" {
		t.Errorf("jsonrpc: want 2.0, got %s", result.JSONRPC)
	}
	if result.Result.ProtocolVersion != mcplib.LATEST_PROTOCOL_VERSION {
		t.Errorf("protocol version: want %s, got %s",
			mcplib.LATEST_PROTOCOL_VERSION, result.Result.ProtocolVersion)
	}
	if result.Result.ServerInfo.Name != "merlin" {
		t.Errorf("server name: want merlin, got %s", result.Result.ServerInfo.Name)
	}
	if result.Result.ServerInfo.Version != merlin.Version {
		t.Errorf("server version: want %s, got %s", merlin.Version, result.Result.ServerInfo.Version)
	}
}

func TestProtocol_InitializeMissingClientInfo(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	defer ts.Close()

	// Send initialize without clientInfo -- should still succeed because
	// the mcp-go library is lenient on this field.
	resp, err := postJSON(ts.URL, jsonRPCRequest(1, "initialize", map[string]any{
		"protocolVersion": mcplib.LATEST_PROTOCOL_VERSION,
	}))
	if err != nil {
		t.Fatalf("initialize: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}
}

func TestProtocol_ToolsList(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	sid := initAndSession(t, ts)

	resp, err := postSessionJSON(ts.URL, sid, jsonRPCRequest(2, "tools/list", map[string]any{}))
	if err != nil {
		t.Fatalf("tools/list: %v", err)
	}

	body := readBody(t, resp)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}

	var result struct {
		Result struct {
			Tools []struct {
				Name        string `json:"name"`
				Description string `json:"description"`
			} `json:"tools"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}

	if len(result.Result.Tools) != 4 {
		t.Fatalf("expected 4 tools, got %d", len(result.Result.Tools))
	}

	names := make(map[string]bool)
	for _, tool := range result.Result.Tools {
		names[tool.Name] = true
	}
	for _, expected := range []string{"merlin_scan", "merlin_scan_dir", "merlin_checks", "merlin_status"} {
		if !names[expected] {
			t.Errorf("%s tool not found in tools/list", expected)
		}
	}
}

func TestProtocol_ToolsCall_Scan(t *testing.T) {
	// Start a simple HTTP server to act as the scan target.
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<!DOCTYPE html><html><head><title>Test</title></head><body><p>Hello</p></body></html>`)
	}))
	defer target.Close()

	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	sid := initAndSession(t, ts)

	resp, err := postSessionJSON(ts.URL, sid, jsonRPCRequest(3, "tools/call", map[string]any{
		"name":      "merlin_scan",
		"arguments": map[string]any{"url": target.URL},
	}))
	if err != nil {
		t.Fatalf("tools/call: %v", err)
	}

	body := readBody(t, resp)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}

	// The response should contain a result with content array.
	var rpcResp struct {
		Result struct {
			Content []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			} `json:"content"`
			IsError bool `json:"isError"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &rpcResp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if len(rpcResp.Result.Content) == 0 {
		t.Fatal("expected at least one content item in result")
	}
	if rpcResp.Result.IsError {
		t.Fatalf("expected successful result, got error: %s", rpcResp.Result.Content[0].Text)
	}

	// The text content should be valid JSON (an merlin.Report).
	var report merlin.Report
	if err := json.Unmarshal([]byte(rpcResp.Result.Content[0].Text), &report); err != nil {
		t.Fatalf("content is not valid JSON report: %v\nraw: %s", err, rpcResp.Result.Content[0].Text)
	}
	if report.Target != target.URL {
		t.Errorf("report target: want %s, got %s", target.URL, report.Target)
	}
}

// ---------------------------------------------------------------------------
// 2. Tool execution -- direct handler calls
// ---------------------------------------------------------------------------

func TestHandleScan_EmptyURL(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": ""}

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	if !result.IsError {
		t.Fatal("expected error result for empty URL")
	}
	// Should contain an error message
	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			if tc.Text == "" {
				t.Fatal("expected non-empty error message")
			}
		}
	}
}

func TestHandleScan_MissingURL(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	// Arguments is nil -- no url key at all
	req.Params.Arguments = nil

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	if !result.IsError {
		t.Fatal("expected error result for missing URL argument")
	}
}

func TestHandleScan_HTTPTest(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<!DOCTYPE html><html><head><title>Test</title></head><body>
			<a href="/broken-link">Broken</a>
			<img src="/missing.png">
		</body></html>`)
	}))
	defer ts.Close()

	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": ts.URL}

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	if result.IsError {
		t.Fatal("did not expect error result for valid URL")
	}

	// Parse JSON response
	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			var report merlin.Report
			if err := json.Unmarshal([]byte(tc.Text), &report); err != nil {
				t.Fatalf("expected valid JSON report: %v", err)
			}
			if report.Target != ts.URL {
				t.Fatalf("expected target=%s, got %s", ts.URL, report.Target)
			}
		}
	}
}

func TestHandleScan_WithDepth(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<!DOCTYPE html><html><head><title>Test</title></head><body><p>OK</p></body></html>`)
	}))
	defer ts.Close()

	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": ts.URL, "depth": float64(1)}

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
}

func TestHandleScan_NonexistentHost(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": "http://192.0.2.1:1"} // TEST-NET, guaranteed unreachable

	// Use a short context timeout so we don't wait the full 2 minutes.
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	result, err := s.handleScan(ctx, req)
	if err != nil {
		t.Fatalf("handler should not return Go error: %v", err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	// The scanner reports unreachable hosts as findings (e.g. timeout),
	// not as a tool-level error. Verify it returns a valid report.
	if result.IsError {
		t.Fatal("did not expect tool-level error; scan issues are reported as findings")
	}
	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			var report merlin.Report
			if err := json.Unmarshal([]byte(tc.Text), &report); err != nil {
				t.Fatalf("expected valid JSON report: %v", err)
			}
			if report.Target != "http://192.0.2.1:1" {
				t.Errorf("report target: want http://192.0.2.1:1, got %s", report.Target)
			}
			// Should contain at least one finding describing the failure.
			if len(report.Findings) == 0 {
				t.Error("expected at least one finding for unreachable host")
			}
		}
	}
}

func TestHandleScanDir(t *testing.T) {
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "index.html")
	if err := os.WriteFile(indexPath, []byte(`<!DOCTYPE html><html><head><title>Test</title></head><body><h1>Hello</h1></body></html>`), 0o644); err != nil {
		t.Fatal(err)
	}

	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"path": dir}

	result, err := s.handleScanDir(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}

	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			var report merlin.Report
			if err := json.Unmarshal([]byte(tc.Text), &report); err != nil {
				t.Fatalf("expected valid JSON report: %v", err)
			}
		}
	}
}

func TestHandleScanDir_EmptyPath(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"path": ""}

	result, err := s.handleScanDir(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	if !result.IsError {
		t.Fatal("expected error result for empty path")
	}
}

func TestHandleScanDir_MissingPath(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = nil

	result, err := s.handleScanDir(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	if !result.IsError {
		t.Fatal("expected error result for missing path argument")
	}
}

func TestHandleScanDir_NonexistentDir(t *testing.T) {
	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"path": "/nonexistent/path/that/does/not/exist"}

	result, err := s.handleScanDir(context.Background(), req)
	if err != nil {
		t.Fatalf("handler should not return Go error: %v", err)
	}
	if result == nil {
		t.Fatal("expected result")
	}
	// ScanDir calls os.Stat on the path; a nonexistent directory returns an
	// error, which handleScanDir surfaces as a tool-level error result.
	if !result.IsError {
		t.Fatal("expected tool-level error for nonexistent directory")
	}
	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			if tc.Text == "" {
				t.Fatal("expected non-empty error message")
			}
		}
	}
}

func TestHandleScan_ReportContainsFindings(t *testing.T) {
	// Serve HTML with a broken image to generate at least one finding.
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<!DOCTYPE html><html><head><title>Findings Test</title></head><body>
			<img src="/nonexistent-image.png">
		</body></html>`)
	}))
	defer ts.Close()

	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": ts.URL}

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}
	if result == nil || result.IsError {
		t.Fatal("expected successful result")
	}

	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			var report merlin.Report
			if err := json.Unmarshal([]byte(tc.Text), &report); err != nil {
				t.Fatalf("unmarshal report: %v", err)
			}
			// The report should have valid stats
			if report.Stats.PagesScanned < 1 {
				t.Errorf("expected at least 1 page scanned, got %d", report.Stats.PagesScanned)
			}
		}
	}
}

func TestHandleScan_ReportJSONStructure(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, `<!DOCTYPE html><html><head><title>Struct Test</title></head><body><p>OK</p></body></html>`)
	}))
	defer ts.Close()

	s := New(merlin.Quick, merlin.WithAllowPrivateIPs())
	req := mcplib.CallToolRequest{}
	req.Params.Arguments = map[string]interface{}{"url": ts.URL}

	result, err := s.handleScan(context.Background(), req)
	if err != nil {
		t.Fatal(err)
	}

	for _, c := range result.Content {
		if tc, ok := c.(mcplib.TextContent); ok {
			// Verify the JSON is well-formed by round-tripping through a raw map.
			var raw map[string]json.RawMessage
			if err := json.Unmarshal([]byte(tc.Text), &raw); err != nil {
				t.Fatalf("not valid JSON: %v", err)
			}
			// Must contain the key fields.
			for _, key := range []string{"target", "findings", "stats", "duration"} {
				if _, ok := raw[key]; !ok {
					t.Errorf("report missing key %q", key)
				}
			}
		}
	}
}

// ---------------------------------------------------------------------------
// 3. Error handling -- malformed requests, unknown methods, bad params
// ---------------------------------------------------------------------------

func TestErrorHandling_InvalidJSON(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	defer ts.Close()

	req, _ := http.NewRequest(http.MethodPost, ts.URL, strings.NewReader("{not valid json"))
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400 for invalid JSON, got %d", resp.StatusCode)
	}
}

func TestErrorHandling_InvalidContentType(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	defer ts.Close()

	req, _ := http.NewRequest(http.MethodPost, ts.URL, strings.NewReader(`{"jsonrpc":"2.0","id":1,"method":"ping"}`))
	req.Header.Set("Content-Type", "text/plain")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400 for wrong content-type, got %d", resp.StatusCode)
	}
}

func TestErrorHandling_UnknownMethod(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	sid := initAndSession(t, ts)

	resp, err := postSessionJSON(ts.URL, sid, jsonRPCRequest(10, "nonexistent/method", map[string]any{}))
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	// Unknown method should return a JSON-RPC error (either in body or as HTTP status).
	body, _ := io.ReadAll(resp.Body)
	var rpcErr struct {
		Error *struct {
			Code    int    `json:"code"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if err := json.Unmarshal(body, &rpcErr); err == nil && rpcErr.Error != nil {
		// Got a JSON-RPC error -- this is the expected behaviour.
		if rpcErr.Error.Code == 0 {
			t.Error("expected a non-zero error code for unknown method")
		}
	} else {
		// Some implementations may return 400/404 at the HTTP level instead.
		if resp.StatusCode >= 200 && resp.StatusCode < 300 {
			t.Errorf("expected error for unknown method, got HTTP %d", resp.StatusCode)
		}
	}
}

// ---------------------------------------------------------------------------
// merlin_checks and merlin_status tools
// ---------------------------------------------------------------------------

func TestProtocol_ToolsCall_Checks(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	sid := initAndSession(t, ts)

	resp, err := postSessionJSON(ts.URL, sid, jsonRPCRequest(3, "tools/call", map[string]any{
		"name":      "merlin_checks",
		"arguments": map[string]any{},
	}))
	if err != nil {
		t.Fatalf("tools/call: %v", err)
	}

	body := readBody(t, resp)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}

	var rpcResp struct {
		Result struct {
			Content []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			} `json:"content"`
			IsError bool `json:"isError"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &rpcResp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if rpcResp.Result.IsError {
		t.Fatalf("expected success, got error: %s", rpcResp.Result.Content[0].Text)
	}
	if len(rpcResp.Result.Content) == 0 {
		t.Fatal("expected at least one content item")
	}

	// The text content should be a JSON object with a "checks" array.
	var payload struct {
		Checks []struct {
			Name        string `json:"name"`
			Description string `json:"description"`
		} `json:"checks"`
	}
	if err := json.Unmarshal([]byte(rpcResp.Result.Content[0].Text), &payload); err != nil {
		t.Fatalf("content is not valid JSON: %v\nraw: %s", err, rpcResp.Result.Content[0].Text)
	}
	if len(payload.Checks) == 0 {
		t.Fatal("expected at least one audit check in the catalog")
	}

	// Spot-check that a known check is present.
	found := map[string]bool{}
	for _, c := range payload.Checks {
		found[c.Name] = true
	}
	for _, want := range []string{"links", "security", "a11y"} {
		if !found[want] {
			t.Errorf("expected %q check in catalog, not found", want)
		}
	}
}

func TestProtocol_ToolsCall_Status(t *testing.T) {
	ts, _ := newTestHTTPServer(t, merlin.Quick, merlin.WithAllowPrivateIPs())
	sid := initAndSession(t, ts)

	resp, err := postSessionJSON(ts.URL, sid, jsonRPCRequest(3, "tools/call", map[string]any{
		"name":      "merlin_status",
		"arguments": map[string]any{},
	}))
	if err != nil {
		t.Fatalf("tools/call: %v", err)
	}

	body := readBody(t, resp)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("expected 200, got %d: %s", resp.StatusCode, body)
	}

	var rpcResp struct {
		Result struct {
			Content []struct {
				Type string `json:"type"`
				Text string `json:"text"`
			} `json:"content"`
			IsError bool `json:"isError"`
		} `json:"result"`
	}
	if err := json.Unmarshal(body, &rpcResp); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if rpcResp.Result.IsError {
		t.Fatalf("expected success, got error: %s", rpcResp.Result.Content[0].Text)
	}
	if len(rpcResp.Result.Content) == 0 {
		t.Fatal("expected at least one content item")
	}

	var payload struct {
		Name    string   `json:"name"`
		Version string   `json:"version"`
		Tools   []string `json:"tools"`
	}
	if err := json.Unmarshal([]byte(rpcResp.Result.Content[0].Text), &payload); err != nil {
		t.Fatalf("content is not valid JSON: %v\nraw: %s", err, rpcResp.Result.Content[0].Text)
	}
	if payload.Name != "merlin" {
		t.Errorf("name: want merlin, got %q", payload.Name)
	}
	if payload.Version != merlin.Version {
		t.Errorf("version: want %s, got %s", merlin.Version, payload.Version)
	}
	if len(payload.Tools) == 0 {
		t.Error("expected at least one tool in status output")
	}
}

// Note: additional tests for the mcp package live in server_more_test.go
// (split out for file size/clarity). Shared test helpers remain in this file.
