package mcp

import (
	"context"
	"fmt"
	"time"

	mcpkit "github.com/GrayCodeAI/merlin/internal/mcpkit"
	mcplib "github.com/mark3labs/mcp-go/mcp"

	"github.com/GrayCodeAI/merlin"
)

// Server wraps the merlin library as an MCP server, exposing website
// auditing capabilities to any MCP-compatible agent.
type Server struct {
	kit     *mcpkit.Server
	scanner *merlin.Scanner
}

// New creates an merlin MCP server with the given scanner options.
func New(opts ...merlin.Option) *Server {
	s := &Server{
		kit:     mcpkit.New("merlin", merlin.Version),
		scanner: merlin.NewScanner(opts...),
	}
	s.registerTools()
	return s
}

// ServeStdio starts the MCP server on stdin/stdout.
func (s *Server) ServeStdio() error {
	return s.kit.ServeStdio()
}

// ServeHTTP starts the MCP server on a streamable HTTP endpoint. Clients
// connect to http://<addr>/mcp.
func (s *Server) ServeHTTP(addr string) error {
	return s.kit.ServeHTTP(addr)
}

func (s *Server) registerTools() {
	s.kit.AddTool(mcplib.NewTool(
		"merlin_scan",
		mcplib.WithDescription("Scan a website for broken links, security issues, and accessibility problems"),
		mcplib.WithString("url", mcplib.Required(), mcplib.Description("Target URL to scan")),
	), s.handleScan)

	s.kit.AddTool(mcplib.NewTool(
		"merlin_scan_dir",
		mcplib.WithDescription("Scan a local directory of HTML files"),
		mcplib.WithString("path", mcplib.Required(), mcplib.Description("Local directory path")),
	), s.handleScanDir)

	s.kit.AddTool(mcplib.NewTool(
		"merlin_checks",
		mcplib.WithDescription("List all available audit checks and what they detect"),
	), s.handleChecks)

	s.kit.AddTool(mcplib.NewTool(
		"merlin_status",
		mcplib.WithDescription("Return the merlin server version and capabilities"),
	), s.handleStatus)
}

func (s *Server) handleScan(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	url := mcpkit.StrArg(req, "url")
	if url == "" {
		return mcplib.NewToolResultError("url is required"), nil
	}

	ctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
	defer cancel()

	report, err := s.scanner.Scan(ctx, url)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("scan failed: %v", err)), nil
	}
	return mcpkit.JSONResult(report)
}

func (s *Server) handleScanDir(ctx context.Context, req mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	path := mcpkit.StrArg(req, "path")
	if path == "" {
		return mcplib.NewToolResultError("path is required"), nil
	}

	ctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
	defer cancel()

	report, err := s.scanner.ScanDir(ctx, path)
	if err != nil {
		return mcplib.NewToolResultError(fmt.Sprintf("scan_dir failed: %v", err)), nil
	}
	return mcpkit.JSONResult(report)
}

func (s *Server) handleChecks(_ context.Context, _ mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	checks := []map[string]string{
		{"name": "links", "description": "Broken links, redirect chains, and dead anchors"},
		{"name": "security", "description": "Security headers (CSP, HSTS, X-Frame-Options), mixed content"},
		{"name": "forms", "description": "Form accessibility, autocomplete, and sensitive field handling"},
		{"name": "a11y", "description": "Accessibility: alt text, ARIA roles, contrast, heading structure"},
		{"name": "perf", "description": "Performance: render-blocking resources, image optimization hints"},
		{"name": "seo", "description": "SEO: meta tags, canonical URLs, structured data"},
		{"name": "sri", "description": "Subresource Integrity hashes on external scripts and styles"},
		{"name": "aiready", "description": "AI-readiness: robots.txt, llms.txt, structured data for crawlers"},
		{"name": "reachability", "description": "URL reachability and HTTP status codes"},
	}
	return mcpkit.JSONResult(map[string]interface{}{"checks": checks})
}

func (s *Server) handleStatus(_ context.Context, _ mcplib.CallToolRequest) (*mcplib.CallToolResult, error) {
	return mcpkit.JSONResult(map[string]interface{}{
		"name":    "merlin",
		"version": merlin.Version,
		"tools":   []string{"merlin_scan", "merlin_scan_dir", "merlin_checks", "merlin_status"},
	})
}
