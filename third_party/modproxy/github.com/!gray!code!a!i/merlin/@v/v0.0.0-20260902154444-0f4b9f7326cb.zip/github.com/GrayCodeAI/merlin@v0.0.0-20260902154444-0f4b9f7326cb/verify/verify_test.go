package verify

import (
	"encoding/json"
	"testing"
	"time"

	contracts "github.com/GrayCodeAI/merlin/types"
)

// TestVerifyParity pins the vendored Report contract to the exact wire JSON
// produced by eagle/verify. It guards against accidental schema drift between
// eagle/verify and merlin/verify.
func TestVerifyParity(t *testing.T) {
	r := Report{
		Target: "https://example.com",
		Findings: []Finding{{
			Check:    "sql-injection",
			Severity: contracts.SeverityHigh,
			URL:      "https://example.com/",
			Message:  "unsafe SQL concatenation",
		}},
		Stats:       Stats{},
		CrawledURLs: 1,
		Duration:    time.Second,
		FailOn:      contracts.SeverityHigh,
		FailOnSet:   true,
	}

	got, err := json.Marshal(r)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	const want = `{"target":"https://example.com","findings":[{"check":"sql-injection","severity":3,"url":"https://example.com/","message":"unsafe SQL concatenation"}],"stats":{"pages_scanned":0,"findings_total":0,"by_severity":null,"by_check":null,"duration_per_check":null},"crawled_urls":1,"duration":1000000000,"fail_on":3,"fail_on_set":true}`
	if string(got) != want {
		t.Fatalf("parity mismatch\n got: %s\nwant: %s", got, want)
	}
}
