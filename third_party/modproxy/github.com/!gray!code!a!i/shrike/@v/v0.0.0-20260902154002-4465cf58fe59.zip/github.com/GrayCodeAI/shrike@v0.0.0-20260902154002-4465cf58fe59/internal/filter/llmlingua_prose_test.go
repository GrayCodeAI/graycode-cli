package filter

import (
	"strings"
	"testing"
)

func proseSample() string {
	return strings.Join([]string{
		"The deployment pipeline runs every night at midnight.",
		"It is a process that has been running for a very long time now.",
		"A critical error was detected in the authentication service yesterday.",
		"The weather outside is quite nice and the sky is blue and clear.",
		"This failure must be addressed before the next release because it blocks login.",
		"Everything else seems fine and there is nothing else to report at this time.",
		"The team decided to roll back the change to restore service quickly.",
		"Lunch will be served at noon in the main cafeteria as usual today.",
	}, " ")
}

func TestLLMLinguaProse_BasicCompression(t *testing.T) {
	f := NewLLMLinguaProseFilter()
	input := proseSample()

	output, saved := f.Apply(input, ModeAggressive)

	if len(output) > len(input) {
		t.Fatalf("output larger than input: %d > %d", len(output), len(input))
	}
	if saved < 0 {
		t.Fatalf("negative tokens saved: %d", saved)
	}
	if len(output) >= len(input) {
		t.Errorf("expected aggressive prose compression to shrink input, got %d >= %d", len(output), len(input))
	}
	// First and last sentence must be preserved for continuity.
	if !strings.Contains(output, "deployment pipeline runs every night") {
		t.Errorf("first sentence not preserved: %q", output)
	}
}

func TestLLMLinguaProse_PreservesImportantSentences(t *testing.T) {
	f := NewLLMLinguaProseFilter()
	output, _ := f.Apply(proseSample(), ModeAggressive)

	// Sentences carrying importance keywords ("critical error", "must ... because")
	// should survive aggressive pruning.
	if !strings.Contains(output, "critical error") {
		t.Errorf("critical-error sentence dropped: %q", output)
	}
}

func TestLLMLinguaProse_CodePassThrough(t *testing.T) {
	f := NewLLMLinguaProseFilter()
	code := strings.Repeat("func handler(w http.ResponseWriter, r *http.Request) {\n\treturn\n}\n", 8)

	if f.IsApplicable(code) {
		t.Errorf("code should not be applicable to the prose layer")
	}
	output, saved := f.Apply(code, ModeAggressive)
	if output != code {
		t.Errorf("code input was modified by prose layer")
	}
	if saved != 0 {
		t.Errorf("expected zero savings on code, got %d", saved)
	}
}

func TestLLMLinguaProse_ShortAndEmptyInputs(t *testing.T) {
	f := NewLLMLinguaProseFilter()
	tests := []string{"", "Hello world.", "Short text that is under the minimum length threshold."}
	for _, in := range tests {
		out, saved := f.Apply(in, ModeAggressive)
		if out != in {
			t.Errorf("short input %q was modified to %q", in, out)
		}
		if saved != 0 {
			t.Errorf("short input %q reported savings %d", in, saved)
		}
	}
}

func TestLLMLinguaProse_ModeNoneIsNoop(t *testing.T) {
	f := NewLLMLinguaProseFilter()
	in := proseSample()
	out, saved := f.Apply(in, ModeNone)
	if out != in || saved != 0 {
		t.Errorf("ModeNone should be a no-op; got saved=%d, changed=%v", saved, out != in)
	}
}

func TestLLMLinguaProse_InterfaceContracts(t *testing.T) {
	var _ Filter = (*LLMLinguaProseFilter)(nil)
	var _ EnableCheck = (*LLMLinguaProseFilter)(nil)
	var _ ApplicabilityCheck = (*LLMLinguaProseFilter)(nil)

	f := NewLLMLinguaProseFilter()
	if f.Name() != "llmlingua_prose" {
		t.Errorf("unexpected name: %q", f.Name())
	}
	if !f.IsEnabled() {
		t.Errorf("filter should be enabled by default")
	}
}

func TestLLMLinguaProse_ConfigOverrides(t *testing.T) {
	f := NewLLMLinguaProseFilterWithConfig(0.4, 50)
	if f.keepRatio != 0.4 {
		t.Errorf("keepRatio override not applied: %v", f.keepRatio)
	}
	if f.minLength != 50 {
		t.Errorf("minLength override not applied: %v", f.minLength)
	}
	// Invalid overrides fall back to defaults.
	g := NewLLMLinguaProseFilterWithConfig(-1, -1)
	if g.keepRatio <= 0 || g.minLength <= 0 {
		t.Errorf("invalid overrides should fall back to defaults")
	}
}

func TestLLMLinguaProse_PipelineWiring(t *testing.T) {
	cfg := &PipelineConfig{EnableLLMLinguaProse: true}
	p := NewPipelineCoordinator(cfg)
	found := false
	for _, l := range p.layers {
		if l.name == LayerLLMLinguaProse {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("LLMLingua prose layer not registered in pipeline when enabled")
	}
}
