package secrets

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// Verifier makes a live network call to confirm whether a detected secret
// value is an active credential, following TruffleHog's live-verification
// model. Verifiers are never invoked by DetectSecrets — only by
// DetectSecretsVerified, which callers must opt into explicitly.
type Verifier func(ctx context.Context, client *http.Client, value string) (bool, error)

// defaultVerifyClient is used when DetectSecretsVerified is called with a
// nil client.
var defaultVerifyClient = &http.Client{Timeout: 5 * time.Second}

// patternVerifiers maps a secretPattern's Type to its live-verification
// function. Types with no entry here are never verified (Verified stays nil
// even under DetectSecretsVerified) — either because no reasonable API
// exists to check them (e.g. "Generic Password") or because verification
// needs more than the single matched value (AWS Access Key, handled
// separately in DetectSecretsVerified via pairing with AWS Secret Key).
var patternVerifiers = map[string]Verifier{
	"GitHub Token":              verifyGitHubToken,
	"GitHub Fine-grained Token": verifyGitHubToken,
	"Slack Bot Token":           verifySlackToken,
	"Slack User Token":          verifySlackToken,
	"Stripe Secret Key":         verifyStripeKey,
}

func verifyGitHubToken(ctx context.Context, client *http.Client, token string) (bool, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.github.com/user", nil)
	if err != nil {
		return false, err
	}
	req.Header.Set("Authorization", "token "+token)
	req.Header.Set("Accept", "application/vnd.github+json")

	resp, err := client.Do(req)
	if err != nil {
		return false, err
	}
	defer func() { _ = resp.Body.Close() }()
	return resp.StatusCode == http.StatusOK, nil
}

func verifySlackToken(ctx context.Context, client *http.Client, token string) (bool, error) {
	form := url.Values{"token": {token}}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://slack.com/api/auth.test", strings.NewReader(form.Encode()))
	if err != nil {
		return false, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := client.Do(req)
	if err != nil {
		return false, err
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		return false, nil
	}

	var body struct {
		OK bool `json:"ok"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return false, err
	}
	return body.OK, nil
}

func verifyStripeKey(ctx context.Context, client *http.Client, key string) (bool, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.stripe.com/v1/balance", nil)
	if err != nil {
		return false, err
	}
	req.SetBasicAuth(key, "")

	resp, err := client.Do(req)
	if err != nil {
		return false, err
	}
	defer func() { _ = resp.Body.Close() }()
	return resp.StatusCode == http.StatusOK, nil
}

// awsSTSBaseURL is the AWS STS endpoint used for AWS key-pair verification.
// It is a var (not a const) so tests can point it at a local mock server.
var awsSTSBaseURL = "https://sts.amazonaws.com"

// verifyAWSKeyPair verifies an AWS access key + secret key pair via STS
// GetCallerIdentity, signed with AWS Signature Version 4. Unlike the other
// verifiers, this needs two values (an access key ID alone can't be
// signed) — DetectSecretsVerified only calls this when both an "AWS Access
// Key" and an "AWS Secret Key" were matched in the same scan.
func verifyAWSKeyPair(ctx context.Context, client *http.Client, accessKey, secretKey string) (bool, error) {
	const (
		region  = "us-east-1"
		service = "sts"
	)

	base, err := url.Parse(awsSTSBaseURL)
	if err != nil {
		return false, err
	}
	host := base.Host

	now := time.Now().UTC()
	amzDate := now.Format("20060102T150405Z")
	dateStamp := now.Format("20060102")

	canonicalQuery := url.Values{
		"Action":  {"GetCallerIdentity"},
		"Version": {"2011-06-15"},
	}.Encode()

	canonicalHeaders := "host:" + host + "\n" + "x-amz-date:" + amzDate + "\n"
	signedHeaders := "host;x-amz-date"
	payloadHash := sha256Hex("")

	canonicalRequest := strings.Join([]string{
		http.MethodGet,
		"/",
		canonicalQuery,
		canonicalHeaders,
		signedHeaders,
		payloadHash,
	}, "\n")

	credentialScope := dateStamp + "/" + region + "/" + service + "/aws4_request"
	stringToSign := strings.Join([]string{
		"AWS4-HMAC-SHA256",
		amzDate,
		credentialScope,
		sha256Hex(canonicalRequest),
	}, "\n")

	signingKey := deriveAWSSigningKey(secretKey, dateStamp, region, service)
	signature := hex.EncodeToString(hmacSHA256(signingKey, stringToSign))

	authHeader := fmt.Sprintf(
		"AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s",
		accessKey, credentialScope, signedHeaders, signature,
	)

	reqURL := awsSTSBaseURL + "/?" + canonicalQuery
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, reqURL, nil)
	if err != nil {
		return false, err
	}
	req.Host = host
	req.Header.Set("X-Amz-Date", amzDate)
	req.Header.Set("Authorization", authHeader)

	resp, err := client.Do(req)
	if err != nil {
		return false, err
	}
	defer func() { _ = resp.Body.Close() }()
	return resp.StatusCode == http.StatusOK, nil
}

func sha256Hex(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func hmacSHA256(key []byte, data string) []byte {
	h := hmac.New(sha256.New, key)
	h.Write([]byte(data))
	return h.Sum(nil)
}

func deriveAWSSigningKey(secretKey, dateStamp, region, service string) []byte {
	kDate := hmacSHA256([]byte("AWS4"+secretKey), dateStamp)
	kRegion := hmacSHA256(kDate, region)
	kService := hmacSHA256(kRegion, service)
	return hmacSHA256(kService, "aws4_request")
}
