# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

> **shrike is a Go library**, not a CLI. Install with
> `go get github.com/GrayCodeAI/shrike` and import `github.com/GrayCodeAI/shrike`.
> CLI-style verbs such as `shrike compress` are exposed by
> [Hawk](https://github.com/GrayCodeAI/hawk), which embeds this library.
> Older entries below mentioning CLI commands, shell hooks, agent installers,
> a TUI, or an HTTP `tokd` server describe prototype work that did not ship in
> the library; see the historical note under `[0.29.0]`.

## [Unreleased]

### Changed
- **BPE estimator cache no longer retains input texts** (`internal/core`).
  The 8192-entry sharded LRU previously stored the full original string per
  entry for collision checks and copied every input to `[]byte` on each hash.
  It now hashes with `hash/maphash` (zero-copy, random per-process seed),
  validates hits by `(hash, length)`, and skips caching texts above a 1 MiB
  cutoff. This bounds the cache at small fixed-size records regardless of
  prompt size — previously, `Compress` estimating the original plus every
  intermediate layer output could pin hundreds of MB in the cache.

### Fixed
- **`RestorationTracker` no longer retains file contents unboundedly.**
  `Track` previously did an O(n) linear dedup scan per call (O(n²) over a
  session) and kept every tracked file's full content in memory until
  `Clear()`. Dedup is now O(1) via a path-indexed map, and total retained
  content is capped by a token budget (`DefaultRetainedTokenBudget`,
  200_000 tokens — one default context window, ~800 KB) that evicts the
  least recently tracked entries; configurable via
  `WithRetainedTokenBudget`. The most recently tracked entry is always kept.
- **Version re-baselined to `0.1.0`** across `CITATION.cff` and the embedded
  `Version` constant, aligning shrike with the rest of the hawk-eco ecosystem
  (`hawk`, `eyrie`, `harrier`, `kestrel`, `merlin`). No git tag has been cut yet.

### Removed
- Dead `ParallelExecutor` (`internal/filter`): ran every layer on the full
  input concurrently and kept the shortest output. No production callers in
  shrike or hawk, no tests, and it measured output size in bytes rather than
  tokens, so it could never be wired into the token-budget pipeline as-is.
- Unused internal config structs `QuestionAwareLayerConfig`,
  `DensityAdaptiveLayerConfig`, `NumericalQuantLayerConfig`, and
  `DynamicRatioLayerConfig` (and their fields on the internal `LayerConfig`)
  that were marked "reserved for future implementation" and never referenced.
- `scripts/deploy.sh` — referenced a Dockerfile, k8s manifests, and an
  `internal/integration/` package that never existed. shrike is a Go library
  (no binary, no HTTP server); deployment happens via `go get`.

## [0.1.0] (unreleased)

### Added
- **Custom filter DSL** — define regex find/replace rules in a TOML file
  (e.g. `~/.shrike/filters.toml`) and apply them via `shrike.LoadFilterRules` +
  `shrike.WithCustomFilters`. Opt-in; rules run in priority order, invalid
  patterns are skipped.
- **Team / shared compression profiles** — named, versioned TOML profiles
  (`shrike.LoadProfile` / `LoadProfiles`, built-ins `default`, `aggressive`,
  `code-safe`) bundling mode + tier + budget, resolvable via `Profile.Options()`.
- **Code-aware (symbol-preserving) compression** — `shrike.WithCodeAware(lang)`
  guards function/type/export signatures so the pipeline can never strip them;
  pluggable `SymbolProvider` (regex default, `WithSymbolProvider` for LSP-backed).
- **Perplexity-guided selective token dropping** (LLMLingua-style) —
  `shrike.WithPerplexityGuided` / `shrike.CompressPerplexityGuided` drop lowest-importance
  tokens first via a pluggable `PerplexityScorer` (zero-dependency heuristic
  default; experimental `OllamaScorer` available with `-tags experimental_ollama`).
  Opt-in.
- **HTTP server mode (`tokd`)** — _removed before release_. Earlier work
  on a standalone HTTP server lived in `./server` but did not ship; the
  core library exposes no HTTP surface. See the historical note in
  `[0.29.0]` for context.
- **Compression-quality benchmark harness** (`benchmarks/quality`) — offline
  harness reporting compression ratio, char retention, and a ROUGE-1
  lexical-fidelity proxy against an LLMLingua-style baseline arm.
- Dollar-based cost savings tracking in Stats
- Model-aware BPE encoding selection

### Added — Round 2 porting (2026-06-01)
- **`shrike.PromptCompress(text, intensity)`** — public Go API for the
  prompt-compression prompt-compression algorithm. Three intensity levels
  (`IntensityLite`, `IntensityFull`, `IntensityUltra`) with drop-lists for
  articles / filler / pleasantries and ~150 phrase substitutions.
  Auto-clarity: security / destructive segments pass through verbatim.
  Returns a `PromptStats` struct (OriginalBytes, CompressedBytes,
  BytesSaved, PercentOff, PassThroughSegments, etc.).
- **`shrike.IsSensitiveFilename(path)`** — 3-layer path-based sensitive
  detection (exact basename, sensitive directory, name token).
  Companion to the content-based `SecretDetector`.
  Categories: `CatExactBasename`, `CatSensitiveDirectory`, `CatNameToken`.
- **`filter.SmartTruncate`** with the `kept + dropped == total` line-accounting
  invariant. Returns `TruncateStats` so callers can verify the
  accounting from the output text alone.
- **`shrike.ExtractJSON` / `shrike.ExtractJSONArray` / `shrike.ExtractAllJSON`** —
  brace-balanced JSON extractor. Handles LLM output with surrounding
  prose, markdown code fences, and unterminated objects.
- **`shrike.NewTracker(ctx)`** — persistent SQLite gain tracker
  (WAL mode, 90-day retention, pure Go via `modernc.org/sqlite`).
  Records per-event compression stats and supports aggregate
  queries. Default path `~/.shrike/tracker.db`.
- **`shrike.EstimateTokensFast/WithEncoding/ForModel`** — model-aware
  token estimation exposed at the top level (was previously internal).
- **`filter.CompressWithRetry`** — validate-fix-retry loop. Caller
  supplies a `Validator` and `AdjustFunc`; the loop escalates
  mode/intensity and retries up to `MaxRetries` times. Includes
  `MustContainsValidator` and `MaxTokensValidator` helpers.
- **`filter.NewTOMLFilter` / `LoadTOMLFilterFile`** — full 8-stage TOML pipeline (strip_ansi, replace regex, match_output
  short-circuit, strip/keep_lines, truncate_lines, head/tail,
  max_lines, on_empty) as a `Filter` implementation. Plugs into
  the main pipeline via the existing `tomlFilterWrapper` slot.
- Bug fix: `RetryStats.FinalPipelineStats` is now `*PipelineStats`
  to avoid copying `sync.RWMutex` per Go vet `copylocks` warning.

### Added — Production Hardening (top-50 OSS parity)
- Same-style hardening pass already on this branch:
  strict `golangci-lint` v2 config (`errcheck`, `staticcheck`, `gocritic`
  diagnostic+performance, `unused`, `ineffassign`, `misspell`, `noctx`,
  `bodyclose`, `unconvert`, `whitespace`), unchecked-error fixes across
  `internal/cache`, `internal/filter`, `internal/utils`, dead-code removal,
  and `gofmt` cleanup of the residual blank-line drift.
- `.github/PULL_REQUEST_TEMPLATE.md` — contributor checklist.
- `.github/ISSUE_TEMPLATE/bug_report.yml` — structured bug report form.
- `.github/ISSUE_TEMPLATE/feature_request.yml` — feature request with
  developer fit checks.
- `.github/ISSUE_TEMPLATE/config.yml` — routes security to GitHub Security
  Advisories, questions to Discussions, blocks blank issues.

## [1.1.0](https://github.com/GrayCodeAI/shrike/compare/v1.0.0...v1.1.0) (2026-04-30)


### Features

* achieve 100% quality (A+) - add security, performance, and resilience fixes ([a0b6add](https://github.com/GrayCodeAI/shrike/commit/a0b6addc004a3de8f619050ad36b309e3a4694da))
* add 11 more important git commands ([9236cb8](https://github.com/GrayCodeAI/shrike/commit/9236cb88d421cd824408d2ef6198de69cbee70ba))
* add 14 more test files, 4 TOML filters ([9c4e332](https://github.com/GrayCodeAI/shrike/commit/9c4e332d15a30a2a9da051a158033fe94d32ee6e))
* add 15 more git commands ([7b0360d](https://github.com/GrayCodeAI/shrike/commit/7b0360d98f88a3e8bc4b04de303ccd25e33187ec))
* add 50-layer registry roadmap and gating framework ([fad93eb](https://github.com/GrayCodeAI/shrike/commit/fad93ebf74d3f7eabc4599de6d39d74b7b43bb7d))
* add 7 new 2026 research layers, tier-based compression, and code quality improvements ([0b1365b](https://github.com/GrayCodeAI/shrike/commit/0b1365b07f76dafc297ec6096224bbb31733268a))
* add adaptive evaluation script and report generator ([5837dd1](https://github.com/GrayCodeAI/shrike/commit/5837dd127bbf3ace2660cee038e7fd0c7a32f4f3))
* add adaptive layer selection based on content type ([3527f8e](https://github.com/GrayCodeAI/shrike/commit/3527f8e33304bd04311a8bc63cd0dd5e4a48a8dd))
* add adaptive tier system for automatic layer selection ([d48cfd1](https://github.com/GrayCodeAI/shrike/commit/d48cfd15f40ff64b4abd3e6c0c82d5da27e4931d))
* add agent/model/provider attribution for token savings ([c8213f1](https://github.com/GrayCodeAI/shrike/commit/c8213f1d84f8c8e0378852ae4a701588f4fb294b))
* add ALL 152 official git commands ([b48bc18](https://github.com/GrayCodeAI/shrike/commit/b48bc189e54976a5280d389cc8365fc866055744))
* add all competitor features - tee recovery, cost tracking, live monitor, prompt debugger, discover, session tracking, dup detection ([dc23fda](https://github.com/GrayCodeAI/shrike/commit/dc23fda6f237ebb2b529386bad7ceb3d64da3a0c))
* add full compression stack features to shrike ([87b26bf](https://github.com/GrayCodeAI/shrike/commit/87b26bf8b9dfcb4419e29cda1edd3758212b95d6))
* add compression features and performance optimizations ([98295cd](https://github.com/GrayCodeAI/shrike/commit/98295cd93d2f341b4c34b27e6e3b5919b21d9d4f))
* add beautiful real-time TUI dashboard ([01bd0d8](https://github.com/GrayCodeAI/shrike/commit/01bd0d84b9de5786a486e9404f5d3d869e7844b5))
* add benchmark CI reporting and adaptive profile validation ([bb1ca2f](https://github.com/GrayCodeAI/shrike/commit/bb1ca2f850343b5f591491e0f36642fca8056198))
* add benchmark suite + fix quality command linter warning ([826a90e](https://github.com/GrayCodeAI/shrike/commit/826a90e1fcb8a911a7f2936cc97b138fa8336cfa))
* add Beyond Parity features - plugins, dashboard, CI/CD, tests ([fdc3095](https://github.com/GrayCodeAI/shrike/commit/fdc3095cec171f7278af8b30a6114e42897474af))
* add cargo install and proxy commands ([c990e82](https://github.com/GrayCodeAI/shrike/commit/c990e829c50c6d88599a8c27be66e8e41c13d9d4))
* add cargo nextest and gh pr view support ([4a29148](https://github.com/GrayCodeAI/shrike/commit/4a29148f6e615a43fc7ab6f17c43eb4ca6e3d01c))
* add community TOML filter marketplace (T40) ([deaa28a](https://github.com/GrayCodeAI/shrike/commit/deaa28a01cac0aa78c15c613df41c96f818096f4))
* add competitive features - quality scoring, visual diff, multi-file merging ([9400311](https://github.com/GrayCodeAI/shrike/commit/94003114835d769c060b440373932c0f3eed72e6))
* add comprehensive benchmark suite for Shrike performance comparison ([357a872](https://github.com/GrayCodeAI/shrike/commit/357a87232f8fcf3788ad38af9f939a2aba9d1842))
* add Crush/HERM-like features ([0cb5bc7](https://github.com/GrayCodeAI/shrike/commit/0cb5bc79862af010788decc0283e19fba16ae1e0))
* add distribution and deployment support ([87c9567](https://github.com/GrayCodeAI/shrike/commit/87c9567b6e4ea8c4b22af0e38ba140a1657e86d8))
* add Docker support with multi-stage builds and compose ([90e7ea6](https://github.com/GrayCodeAI/shrike/commit/90e7ea693e754a3d046d88f1f24000e1b087fae9))
* add dynamic frequency estimation (T11) for +15-20% entropy accuracy ([0beeb6a](https://github.com/GrayCodeAI/shrike/commit/0beeb6a906759c55a77c569e9cc34b36cbec2652))
* add extensive command wrappers for token reduction ([2c2a2ba](https://github.com/GrayCodeAI/shrike/commit/2c2a2ba4326400d6554a90a533caf87fcda5813c))
* add Go SDK for native token compression ([72d216d](https://github.com/GrayCodeAI/shrike/commit/72d216d0f726dc6e19d7e0e1fd066c91dc796ad8))
* add IDE plugins and cloud features ([ac77f93](https://github.com/GrayCodeAI/shrike/commit/ac77f93fcd8238c95eec4d04f0b1a9f664c1d0de))
* add integrity verification and economics analysis ([d7b7a90](https://github.com/GrayCodeAI/shrike/commit/d7b7a90fecd646967ef3ce7ca29586dfa218595c))
* add interactive Bubbletea TUI dashboard ([9853a7b](https://github.com/GrayCodeAI/shrike/commit/9853a7b90fc081eaa32b3546d6ddc39fc9796990))
* add internationalization (i18n) - 6 languages ([29fae2c](https://github.com/GrayCodeAI/shrike/commit/29fae2c5bacb05d9a247a5acc826aa68348ed5ef))
* add LangChain and LlamaIndex integration examples ([2328d0f](https://github.com/GrayCodeAI/shrike/commit/2328d0f7f6d5aeec2cbc0f8ae80ced732c1d0812))
* add language support, API server, WASM plugins ([fbf7059](https://github.com/GrayCodeAI/shrike/commit/fbf70599c4986bc60464661055551aba00e2f2b5))
* add Layer 12 Attribution Filter (ProCut-style pruning) ([788f0f8](https://github.com/GrayCodeAI/shrike/commit/788f0f847774492ef525c2c4d4c8f4c8434050d5))
* add Layer 13 H2O Filter (Heavy-Hitter Oracle compression) ([da7aeb7](https://github.com/GrayCodeAI/shrike/commit/da7aeb76142ff46353876cacfa437f29db0380ce))
* add Layer 14 (Attention Sink Filter) with benchmarks ([f58f06a](https://github.com/GrayCodeAI/shrike/commit/f58f06a4e460972288c07f0a9b7758d370bd1f72))
* add Learning Mode (auto-discover patterns) + CLI commands ([9d7f2b7](https://github.com/GrayCodeAI/shrike/commit/9d7f2b70100153a153bfa4dd670345b0596c4a39))
* add MCP server mode for AI assistant integration ([80218a9](https://github.com/GrayCodeAI/shrike/commit/80218a9d73baadadc4ba85a2680cd5bba3c1b9ac))
* add parity commands (config, proxy, hook-audit, gain, discover, learn, err) ([9e6f149](https://github.com/GrayCodeAI/shrike/commit/9e6f1497204ccf75dc56b6b089ad3b1719971a67))
* add performance optimizations and layer configuration ([e204db7](https://github.com/GrayCodeAI/shrike/commit/e204db71498fbdf1bcbcaef308eb3f0d94d18f79))
* add performance optimizations and new features ([e997bfa](https://github.com/GrayCodeAI/shrike/commit/e997bfa22f0c7565337fab0224b014b085efcf3a))
* add pipeline manager, config layer, audit command, and docs ([95a1a64](https://github.com/GrayCodeAI/shrike/commit/95a1a64b19b5fc01ec6e142d6ac7277eb29b109f))
* add production-ready features ([af9921a](https://github.com/GrayCodeAI/shrike/commit/af9921adcd16f74bdbe69d4fae06f373712707fa))
* add production-ready infrastructure ([6adbc79](https://github.com/GrayCodeAI/shrike/commit/6adbc79e36da3aac23aa431220a8df0893e6d83a))
* add Prometheus metrics and structured logging ([c30c026](https://github.com/GrayCodeAI/shrike/commit/c30c026149e4a5f8ed11001fcd8ca5d851e775bd))
* add Python SDK for token compression ([cef5caf](https://github.com/GrayCodeAI/shrike/commit/cef5caf3e716f5dc55bd851dbcad298b441f39e6))
* add research roadmap and adaptive prefilter scaffolds ([31d4bd7](https://github.com/GrayCodeAI/shrike/commit/31d4bd7dc39992c94f2329bc8617d1868d51edd5))
* add reversible compression and restore command ([714a837](https://github.com/GrayCodeAI/shrike/commit/714a8370cac43f0101dd82d0eaa468787b0e3df3))
* add Ruby ecosystem commands and new AI agent integrations ([f700936](https://github.com/GrayCodeAI/shrike/commit/f700936b561e6b880677811c446182b0ebebe5a2))
* add session command for adoption tracking ([1ecb7cb](https://github.com/GrayCodeAI/shrike/commit/1ecb7cbb4db3f4f7d09faa9910b8060ef2585249))
* add session recovery (OMNI parity) + 44 new tests across new packages ([6d13c80](https://github.com/GrayCodeAI/shrike/commit/6d13c80bb21fc425d5a8d04479728877cd602b45))
* add SIMD-optimized operations for compression hot paths ([5018549](https://github.com/GrayCodeAI/shrike/commit/50185499b8f45ba8227dc477f0a0d17743cb38e0))
* add stage gates and adaptive attention sinks (T7, T14) ([2a44e69](https://github.com/GrayCodeAI/shrike/commit/2a44e69d2244b79f49334114c235b27802eaf93c))
* add streaming API for real-time compression ([e24302e](https://github.com/GrayCodeAI/shrike/commit/e24302e181ffd7f2d184c1dee0ada34ba0b17a7b))
* add support for all git commands ([d9b97a5](https://github.com/GrayCodeAI/shrike/commit/d9b97a5e1119bfc45107d70e5cd7eb000cd85427))
* add T12, T17, T30 - question-aware, density-adaptive, and binary optimization ([f87dfb8](https://github.com/GrayCodeAI/shrike/commit/f87dfb85e9dd4c12634c499be258c84acfa9bfda))
* add terraform and helm commands with specialized filters ([8d55e73](https://github.com/GrayCodeAI/shrike/commit/8d55e7307fed6849155d83c2ad3974599251aaec))
* add test coverage, SIMD support, and WASM plugin system ([43bd17c](https://github.com/GrayCodeAI/shrike/commit/43bd17cfa58c220c57e06facef602fbf08fd3070))
* add tests, multi-language READMEs, expand TOML filters ([6f76a1a](https://github.com/GrayCodeAI/shrike/commit/6f76a1a4ac44c1e272db4b0d9ff1c2ae81a9609b))
* add tiered compression system and practical CLI tools ([151c6ad](https://github.com/GrayCodeAI/shrike/commit/151c6ad04102bc36a9fae0e5f334d7cccae2dcba))
* add timestamps to shrike gain output ([6ef0a97](https://github.com/GrayCodeAI/shrike/commit/6ef0a9754ed417503fd7c3f6ffdfc183ac6b5a91))
* add TOML filters for modern development tools ([e042680](https://github.com/GrayCodeAI/shrike/commit/e0426802ba36b484e26b2a4938dd822ddd013e13))
* add TUI, AI providers, Docker sandbox, slash commands ([a026fdb](https://github.com/GrayCodeAI/shrike/commit/a026fdb1d37005d08957fc55998c78b38d3c763a))
* add TypeScript/Node.js SDK ([224d690](https://github.com/GrayCodeAI/shrike/commit/224d69098ca91298ce584e5183ea4c0f76bb734c))
* add ultra-compact mode and TeeOnFailure to all major commands ([e429ad5](https://github.com/GrayCodeAI/shrike/commit/e429ad5451834caa828c193e19a0f099475de8e8))
* add version support with ldflags ([a3e2f92](https://github.com/GrayCodeAI/shrike/commit/a3e2f9262bb7aaec56f34dbe4a1c6d41906a034c))
* add WASM build for browser-based compression ([2bff3fc](https://github.com/GrayCodeAI/shrike/commit/2bff3fc1456da0942e7d390120bbeaba9cece43a))
* add welcome screen to TUI ([30027be](https://github.com/GrayCodeAI/shrike/commit/30027bef3f6f0c0f22542f1ef1d734e8a2bee7e5))
* add Welcome To Shrike header ([1f12677](https://github.com/GrayCodeAI/shrike/commit/1f126775bcd023272cc0dcd9588ce06e5301a93e))
* add YAML filter support (Snip parity) + MCP documentation ([a55eb63](https://github.com/GrayCodeAI/shrike/commit/a55eb6332050bc63be50d436934214d6ca7c0c4c))
* add ZSH-specific shell integration with precmd/preexec hooks ([4b65b1b](https://github.com/GrayCodeAI/shrike/commit/4b65b1b341594573f0ea453ccba6de770e52fba6))
* adopt WOZCODE features into Shrike ([2f48b98](https://github.com/GrayCodeAI/shrike/commit/2f48b985e1178f643c64d0637d8ee2544a543b2c))
* all black background - clean professional look ([13c9a3a](https://github.com/GrayCodeAI/shrike/commit/13c9a3acbb7173da69f7f7bc42e57ac9a238ae90))
* ASCII art Shrike logo ([1911ec0](https://github.com/GrayCodeAI/shrike/commit/1911ec04747abab55c09aba717cbdc5d7f4af68e))
* ASCII Shrike with 2 spaces from top ([8bd909b](https://github.com/GrayCodeAI/shrike/commit/8bd909b66d454144cab3afcb9f1efc662a92243e))
* **audit:** add adaptive budget control, intent profiles, anchor retention, and agent budget analytics ([fc68803](https://github.com/GrayCodeAI/shrike/commit/fc688036e80569e0f39953361c0018a1b8c6670e))
* **audit:** add detector registry, checkpoint telemetry, drift fingerprints, and turn analytics ([fb12899](https://github.com/GrayCodeAI/shrike/commit/fb128990b18c79024b43b3eb409ca723939bbdca))
* **audit:** add shrike audit engine with quality, waste, checkpoint and snapshot analysis ([1ead7d5](https://github.com/GrayCodeAI/shrike/commit/1ead7d50bd165daa76406742805657e3d5098ec3))
* auto-dismiss welcome screen after 2 seconds ([558ea47](https://github.com/GrayCodeAI/shrike/commit/558ea47c0d58eb266f454023642e8f907b16f91d))
* **bill:** attribute shrike savings against real provider invoices ([b65dbe8](https://github.com/GrayCodeAI/shrike/commit/b65dbe830a0af0dd6330f8ccd3393b3f66e2a373))
* btop-style multi-panel TUI with rounded borders ([441888b](https://github.com/GrayCodeAI/shrike/commit/441888b8de97f9bc85ed8ddae6bc6af3a969b851))
* Claude Code-style CLI with big prominent input box ([12bf912](https://github.com/GrayCodeAI/shrike/commit/12bf91240bafa9a02e416250f0735bc847c4c939))
* Claude Code-style interface with open input box ([e46fde2](https://github.com/GrayCodeAI/shrike/commit/e46fde2cdcacbba9d842e05899755d8e7b94dd98))
* clean chat-style CLI like Mistral Vibe ([fc2228e](https://github.com/GrayCodeAI/shrike/commit/fc2228e32dff4a2b4c4cc4bea49ff5b489d3c8bb))
* **cli:** add compaction flags for Layer 11 ([f9c868c](https://github.com/GrayCodeAI/shrike/commit/f9c868c987fe478109628ef9ba6baeb689f576c2))
* close 9 world-class compression parity gaps ([f0059eb](https://github.com/GrayCodeAI/shrike/commit/f0059ebc2201cbe3c0ad5a8776b5f656e1bc8c87))
* close last two prompt-compression gaps ([3028726](https://github.com/GrayCodeAI/shrike/commit/302872695f5482bb8a8e5c340e1613755a31dd1c))
* close shrike compression parity gaps ([760f326](https://github.com/GrayCodeAI/shrike/commit/760f3268c5de816c00e6f92657f8f19834457942))
* complete honest competitor analysis - cloned and analyzed 15 OSS tools ([3000897](https://github.com/GrayCodeAI/shrike/commit/3000897d43294cebc80fe4ad37f8c22142e2e642))
* complete integration test suite with archive fixes and MCP tools ([669293c](https://github.com/GrayCodeAI/shrike/commit/669293c6fe9589696197e2dcbe9f22c5d5b71535))
* complete SIMD optimization with Go 1.26 ([a3dbc85](https://github.com/GrayCodeAI/shrike/commit/a3dbc857d662ab98690cc06e90d888491bf0f0fa))
* complete tasks 1-20 - project foundation & structure ([de2e3a5](https://github.com/GrayCodeAI/shrike/commit/de2e3a58f32be8f8eacff0ba2a3bb18357121f11))
* complete tasks 21-230 - README, examples, installers, RewindStore ([67a19e6](https://github.com/GrayCodeAI/shrike/commit/67a19e6dc64e820ca1c139c77b50c1e222959465))
* **config:** add full environment variable compatibility ([e6ece2c](https://github.com/GrayCodeAI/shrike/commit/e6ece2c32d57500d2e1eef915d4fb4bb009ba24f))
* **config:** add ignore_files and env var compatibility ([1676b62](https://github.com/GrayCodeAI/shrike/commit/1676b622fed5ba1872996553c1fb1dbc6b5f3d33))
* **config:** add Windows XDG path support ([2f8c04d](https://github.com/GrayCodeAI/shrike/commit/2f8c04d6d08db52bbe1b5ebe925ca8115fa271a6))
* continue i18n - README French, i18n loader package ([e8ad621](https://github.com/GrayCodeAI/shrike/commit/e8ad621961a3620ff5a34deb597ebdf018d3b9c6))
* **core:** precise BPE for user-visible token counts ([6435bdd](https://github.com/GrayCodeAI/shrike/commit/6435bdd3081f6cf40c28f4d2bf383d6de19af7c4))
* different colors for footer keys + clarify timestamp ([5a9ae26](https://github.com/GrayCodeAI/shrike/commit/5a9ae26a3b73765f4666bc1055df60d5cddef133))
* enable compaction automatically by default ([aa55927](https://github.com/GrayCodeAI/shrike/commit/aa55927af043178ba7b4ec5deb049efc5aa9fca5))
* enhance CLI with powerful welcome and agent modes ([46feee7](https://github.com/GrayCodeAI/shrike/commit/46feee78e9b6c9d5bb20a68482e56890ab6dfcd1))
* enhance dotnet with 6 subcommand filters, add ansible/ansible-playbook/ansible-inventory ([68e9fb7](https://github.com/GrayCodeAI/shrike/commit/68e9fb78f317f3b8538c6f6f27b836794bdac4f1))
* enhance vitest and playwright test runners ([36d65c6](https://github.com/GrayCodeAI/shrike/commit/36d65c67b900751c6736ad23afafe33717a0540f))
* expand Docker, kubectl, AWS, npm, pnpm, pip, and go commands ([71aab9e](https://github.com/GrayCodeAI/shrike/commit/71aab9e7d2f36d8ae84de06440c95e69ba194159))
* **filter:** add layers 21-25 from COMI, DART, TokenSkip, SWE-Pruner, Perception Compressor ([be6d489](https://github.com/GrayCodeAI/shrike/commit/be6d4896b5ce6c2a5f3a3d084166a251c64bfb91))
* **filter:** add layers 26-30 from LightThinker, ThinkSwitcher, GMSA, CARL, SlimInfer ([4c8962a](https://github.com/GrayCodeAI/shrike/commit/4c8962aed785e0e6c5d60e32a986b2413054da3f))
* **filter:** implement baseline planned layers 30-49 ([ceae1c2](https://github.com/GrayCodeAI/shrike/commit/ceae1c2d220ab1f32c53bf4bd4dac7b048b979f1))
* **filter:** wire layer 17 as semantic cache within 20-layer core ([d22d813](https://github.com/GrayCodeAI/shrike/commit/d22d813f82dacdc2c02dc99b7d45795d0c458d0f))
* full screen black background TUI ([d32d349](https://github.com/GrayCodeAI/shrike/commit/d32d349a406f8b99da87d605ebe9ef6032055729))
* gh/vercel-inspired CLI with clean professional design ([3d8266e](https://github.com/GrayCodeAI/shrike/commit/3d8266e4a4aba1dc0c3fede267e932a3be8060b4))
* **git:** add global flags and missing subcommands (parity) ([5b47e4c](https://github.com/GrayCodeAI/shrike/commit/5b47e4c7611b4e1155409cf7d6c04c623031f08f))
* gray background for footer keys ([476e668](https://github.com/GrayCodeAI/shrike/commit/476e668d4132baea1b2bdb0f48f78c1fedfa7bcf))
* gray footer background ([4f925b7](https://github.com/GrayCodeAI/shrike/commit/4f925b7f4971e21af47472d48bef89f8a484c90e))
* implement 10-layer world-class token reduction pipeline ([70a72e0](https://github.com/GrayCodeAI/shrike/commit/70a72e011ab0691f8500dc0c2ffe51df1df54e73))
* implement 24 research-backed compression techniques (34 papers, 2023-2026) ([58ec3aa](https://github.com/GrayCodeAI/shrike/commit/58ec3aa0b7c861689dc79fa81511543f7bd8b502))
* implement 7 research-backed compression layers (Layers 15-20) ([cfe87ba](https://github.com/GrayCodeAI/shrike/commit/cfe87bab387fba456a02ff601571c4b77c9f1a93))
* implement all 22 missing compression features with 95% parity ([03cb0d9](https://github.com/GrayCodeAI/shrike/commit/03cb0d9a37f0f3237bfb093334ff9508b414cfa8))
* implement all competitive features from 10 repos (200 tasks complete) ([f6a54bd](https://github.com/GrayCodeAI/shrike/commit/f6a54bd23eb4b17fcb8f870bda85e43c6db93462))
* implement all phases 1-5 from TASK_PLAN_500.md ([a4aa7c6](https://github.com/GrayCodeAI/shrike/commit/a4aa7c66f58a81544eb918155d55189456b04e24))
* implement all Quick Wins - distribution, install script, Makefile, aliases ([c070829](https://github.com/GrayCodeAI/shrike/commit/c0708291923bb7547a0d33e175d174b74c8e8ba3))
* implement full compression feature parity ([21f4b49](https://github.com/GrayCodeAI/shrike/commit/21f4b49ebb51741738d909db98bba34edca0c574))
* implement guardrails and adaptive benchmark/ablation baselines ([b791be7](https://github.com/GrayCodeAI/shrike/commit/b791be7bddbc5e10efd8454bce6e8d8bc523000f))
* implement JSON/CSV export for economics command ([2204261](https://github.com/GrayCodeAI/shrike/commit/2204261937150bf4c71637e4c658084ac7341cf8))
* implement Lua script plugins and visual animation features ([bc2c3a0](https://github.com/GrayCodeAI/shrike/commit/bc2c3a0e41093dd8c1b530e3fe294fcee40e9bd1))
* implement microservice architecture ([e3a12d3](https://github.com/GrayCodeAI/shrike/commit/e3a12d3ff31705e746c6d6fe22289fa60723083a))
* implement persistent query cache for 56s → 1s speedup ([79aed45](https://github.com/GrayCodeAI/shrike/commit/79aed45c86bac61a4102b3e5705128144ff7c727))
* implement Phase 2 innovation features - MCP server, session recovery, marketplace, WASM plugins ([5c90030](https://github.com/GrayCodeAI/shrike/commit/5c900303330b4d82c7de5fdef85765b4556e2367))
* implement Phase 5-7 of compression migration (Ruby, AI integrations, Extended commands) ([7e257f8](https://github.com/GrayCodeAI/shrike/commit/7e257f8e371e7b28bd7e1a9b93fcdf9e02175f54))
* improve attention score simulation (T13) for heavy-hitter identification ([5d0b1f9](https://github.com/GrayCodeAI/shrike/commit/5d0b1f9b39b8bcf9f23b2080cb2d09a07edb554c))
* improve flag pass-through and compact output formatting ([000037f](https://github.com/GrayCodeAI/shrike/commit/000037f6ed6d8834d92376f86c1774d393019102))
* improve grep, tree, and prisma commands ([d18e411](https://github.com/GrayCodeAI/shrike/commit/d18e411be41a250f67c2a99cab11f40aa0942cba))
* improved status bar with better visuals ([9ea24f7](https://github.com/GrayCodeAI/shrike/commit/9ea24f7ff08cb6deaa201a5330a178d7455f9ba8))
* industry-standard shrike — merge shrike+tork, consolidate architecture, add output abstraction layer ([bfdb38c](https://github.com/GrayCodeAI/shrike/commit/bfdb38cf284c7617208352fefc7ad25cadc9fcaf))
* **init:** expand to 20 wired agents, CLI-first ordering ([3a484c5](https://github.com/GrayCodeAI/shrike/commit/3a484c5b3a4a5468c9c18821cbf318812e00ba51))
* initial implementation of Shrike CLI ([d7427e6](https://github.com/GrayCodeAI/shrike/commit/d7427e66a9dd6a17a7b0dd38fc0e6151249cdae7))
* integrate all 10 token-clone projects into shrike ([c5ce2bc](https://github.com/GrayCodeAI/shrike/commit/c5ce2bc30bf159602246ac0f8d4f0100e3b6f45c))
* integrate runtime integrity checks for operational commands ([2dd5d7a](https://github.com/GrayCodeAI/shrike/commit/2dd5d7a8d59c4d350c856a49ae1cd4618d90ecd7))
* larger welcome text + remove border line ([6a3a957](https://github.com/GrayCodeAI/shrike/commit/6a3a9571b518f1c71906235ce2ab638a35d5a579))
* merge all shrike and tork features into unified shrike CLI ([cbe8970](https://github.com/GrayCodeAI/shrike/commit/cbe8970374bcd69fcab94c634521c829ffecc5ee))
* modern btop/lazygit-style TUI with boxed panels ([21e2caa](https://github.com/GrayCodeAI/shrike/commit/21e2caa33acfee37639b8d46ce874c8308822dd2))
* modern TUI with single accent color, solid colors, no gradients ([6ab4c62](https://github.com/GrayCodeAI/shrike/commit/6ab4c625d895fa4cd973527e9055b501feb0a399))
* optimize pipeline, add tests, and fix bugs ([c9637f2](https://github.com/GrayCodeAI/shrike/commit/c9637f27c52719761a3c3e40a6ca197027602f5a))
* performance benchmarks, code quality, and continued task execution ([ae1ba83](https://github.com/GrayCodeAI/shrike/commit/ae1ba83f534043d8f4ac1a8a4b9a25de5b7a63eb))
* Phase 2 - Delegating Hook System with Exit Code Protocol ([f6435d8](https://github.com/GrayCodeAI/shrike/commit/f6435d8bf6897d8921263bafec982c50c6652294))
* Phase 3 - Filter System Enhancements with inline tests and validation ([ffd4043](https://github.com/GrayCodeAI/shrike/commit/ffd404356a27b3bff6b6ee74543bd666a746138c))
* PI-style CLI with prominent input box ([fd041ec](https://github.com/GrayCodeAI/shrike/commit/fd041ec5d382d91b331f5d22c1476b81b1aa7fd0))
* port all shrike features to shrike ([7e7ce4a](https://github.com/GrayCodeAI/shrike/commit/7e7ce4a4a7f43b0bfb2f95d1119a9b153ee239bb))
* port Shrike enhancements to shrike ([560b530](https://github.com/GrayCodeAI/shrike/commit/560b530b6f94ad6501fee3cea375ce0fbed0000a))
* professional CLI based on OSS research ([110e5ad](https://github.com/GrayCodeAI/shrike/commit/110e5ad38435908ceb7884cb0a191ebf696e20c5))
* professional CLI with clean, modern interface ([1052fd0](https://github.com/GrayCodeAI/shrike/commit/1052fd0a28c6a22a4d373ed2b05cc9980fb335d8))
* professional TUI with 20+ solid colors ([eafebac](https://github.com/GrayCodeAI/shrike/commit/eafebac22267e3dfc391ebfde4fe39c9a920c2b0))
* prominent input box with &gt; prompt ([ca8e231](https://github.com/GrayCodeAI/shrike/commit/ca8e2313b5182b9ad901b4fa5ea40c3d9a428f3a))
* proper box drawing with corners like Claude Code ([7243ff6](https://github.com/GrayCodeAI/shrike/commit/7243ff6b0121a046c72e8708eaf66b5a9374b736))
* rebuild TUI with clean minimal htop/lazygit style design ([181a888](https://github.com/GrayCodeAI/shrike/commit/181a888831db9997689b7331f36f31a29fe276bd))
* rebuild TUI with modern MVU architecture and real-time updates ([b02be5c](https://github.com/GrayCodeAI/shrike/commit/b02be5c768552f27e4667e671cf3a4aa65daa741))
* rebuild TUI with OpenCode-style split-pane design ([d9e79ac](https://github.com/GrayCodeAI/shrike/commit/d9e79ac22ab65b9495ca9967d7d839d8d12f673f))
* refresh every 30 seconds ([61e8b87](https://github.com/GrayCodeAI/shrike/commit/61e8b875ad880b9e49bda1dcdb5fb1f7746f90ac))
* sidebar navigation with arrow keys ([986feb0](https://github.com/GrayCodeAI/shrike/commit/986feb08993154ba693c3849c4540d4a50602b91))
* task 11 - distributed stress testing support ([feb456b](https://github.com/GrayCodeAI/shrike/commit/feb456b762dec21a31f60650075413f591e74764))
* tasks 1-6 - benchmark enhancements (JSON, CSV, trends, charts, DSL) ([09bc6eb](https://github.com/GrayCodeAI/shrike/commit/09bc6ebbeb3f7e9c8b06ec258f8123cad9444943))
* tasks 101-120 - cost policy enforcement, cost center hierarchy, encryption at rest ([120d821](https://github.com/GrayCodeAI/shrike/commit/120d821ab8fd8455a65fe6c3c37393347930dc25))
* tasks 12-21 - custom scenarios, reports, scheduling, chaos experiments ([9c97ba2](https://github.com/GrayCodeAI/shrike/commit/9c97ba212da6db99c34a7ee63dd9e4a556c107ac))
* tasks 121-130 - data retention policies, anonymization, security scanning ([e8a8a60](https://github.com/GrayCodeAI/shrike/commit/e8a8a60016f97c21fdf3e14e5fb07c14e7cf773f))
* tasks 131-140 - CLI enhancements: shell completion, aliases, progress indicators, dry-run, batch ops ([f8c5cb1](https://github.com/GrayCodeAI/shrike/commit/f8c5cb1e7b0144a7516cf33117336713619aa198))
* tasks 141-200 - undo, history, favorites, scheduling, intelligent filtering, sentiment, autotuning, workload prediction ([78ac4df](https://github.com/GrayCodeAI/shrike/commit/78ac4df1046381f12e64fbcd65ea85487068b87a))
* tasks 22-40 - chaos experiments, test coverage for abtest, costforecast, budgetalerts, teamcosts ([82071de](https://github.com/GrayCodeAI/shrike/commit/82071ded87ef8fa6c0e9d1247613eabfae9fc0a2))
* tasks 41-50 - canary tests, CI/CD workflows, chaos testing, performance regression checks ([8633f98](https://github.com/GrayCodeAI/shrike/commit/8633f983ba13b7807c73fbb6315d7454ce15673f))
* tasks 41-50 - canary tests, CI/CD workflows, chaos testing, performance regression checks ([a9db19a](https://github.com/GrayCodeAI/shrike/commit/a9db19a7862acf5f7511ead17fe8f50d41176097))
* tasks 41-60 - canary, mcphost, iteragent tests + multi-platform build CI ([235873a](https://github.com/GrayCodeAI/shrike/commit/235873a323982b148089e26a583f906b07d4660d))
* tasks 61-70 - LLM provider integration and agent framework enhancements ([8eacb30](https://github.com/GrayCodeAI/shrike/commit/8eacb30b8f0f7cb6d05b7c323a36d83ab742dfe0))
* tasks 7-8 - parallel execution and regression detection ([f2ed1a0](https://github.com/GrayCodeAI/shrike/commit/f2ed1a0fca489dcad17add2fb97c185e9515951b))
* tasks 71-90 - cost intelligence dashboard, weekly digest, API endpoints, audit logging, RBAC ([1ea59b0](https://github.com/GrayCodeAI/shrike/commit/1ea59b0cb9ac5d40e5b7942adf326e880c327374))
* tasks 9-10 - CI/CD integration and SQLite storage for benchmarks ([760dd8b](https://github.com/GrayCodeAI/shrike/commit/760dd8bd3f048e579682cc7fa533247171ed9304))
* tasks 91-100 - cost anomaly detection, multi-currency, chargeback automation ([efe42e1](https://github.com/GrayCodeAI/shrike/commit/efe42e1b3687db472a14828e849143825fd18de2))
* **tui,tracking:** live event pipeline, scroll, welcome, nav fixes ([0547bc4](https://github.com/GrayCodeAI/shrike/commit/0547bc418850b896bb0b041ad62331d64091c8b1))
* **tui:** add core UX primitives for section build-out ([738cd73](https://github.com/GrayCodeAI/shrike/commit/738cd73c1c5971e01d2fd8826a2fd7ca3e26c39f))
* **tui:** add final four sections — Pipeline, Rewards, Logs, Config ([c5fa0df](https://github.com/GrayCodeAI/shrike/commit/c5fa0df93e6c037be7a6ce9ee820d12d023a7b28))
* **tui:** add Models, Agents, and Commands sections ([6e0193d](https://github.com/GrayCodeAI/shrike/commit/6e0193d5a025fe3d2ce0d33721b6e259f9ff59e8))
* **tui:** add Today, Trends, and Providers sections ([70cb167](https://github.com/GrayCodeAI/shrike/commit/70cb16791cc942ea29088153e4210c5b71c3f993))
* **tui:** implement 7 major TUI improvements ([a0e522b](https://github.com/GrayCodeAI/shrike/commit/a0e522b0cbf0f06b4025deea6b818504b9cc3a90))
* **tui:** implement Sessions section with drill-down ([7bbc297](https://github.com/GrayCodeAI/shrike/commit/7bbc29796dd74470a55c07872b9b14f52d00c210))
* **tui:** Phase 3 polish — env guards, mouse, yank, export, themes, confirm ([d089abd](https://github.com/GrayCodeAI/shrike/commit/d089abd5b13cf77433ef927ca3e954395f2e0abd))
* unify 51 layers into 20 with consolidated filters ([ffabd08](https://github.com/GrayCodeAI/shrike/commit/ffabd081b27c7697af9c6efe83525f25ddadb08f))
* unique colors for footer keys + clearer timestamp label ([83bed6d](https://github.com/GrayCodeAI/shrike/commit/83bed6d9f8e39aa9c60dfe6ba99c88f4ff7e0ff3))
* update compaction defaults for 1M-2M context ([92cf3c6](https://github.com/GrayCodeAI/shrike/commit/92cf3c63334aab8c2fed94ae6fcf57be0cc5e8d3))
* update hooks to delegating pattern + homebrew tap structure ([afc31c6](https://github.com/GrayCodeAI/shrike/commit/afc31c6187d2a4f1c5baae81b2ce17bbea167885))
* v0.9.0 - Research-based compression with shrike parity ([13254ff](https://github.com/GrayCodeAI/shrike/commit/13254ffab89e5e7eb651cc480bad28fe85c0d104))
* vibrant high-contrast TUI with all features ([fa5d2b4](https://github.com/GrayCodeAI/shrike/commit/fa5d2b4f05432d06b15e978bb4c5e9539a286626))
* wire adaptive routing config and benchmark profile ([dbd5b63](https://github.com/GrayCodeAI/shrike/commit/dbd5b63ff2ddcf197dbcc8e67b34fb1227636a58))
* world-class TUI dashboard with comprehensive features ([d2bc49f](https://github.com/GrayCodeAI/shrike/commit/d2bc49f718722ced4cd9342afef2bd0f99e128f6))
* world-class TUI with purpose-driven colors ([cc0eade](https://github.com/GrayCodeAI/shrike/commit/cc0eadea0dc0e85971e32e0382b5c103ac76e092))


### Bug Fixes

* address code review findings across filter/cache/toml ([1de474b](https://github.com/GrayCodeAI/shrike/commit/1de474b71a4204b17489d866fa77e191de1aa6ee))
* align README claims with implementation accuracy ([59a3c35](https://github.com/GrayCodeAI/shrike/commit/59a3c358417cf643e167a692e5d86b82400cea17))
* all text styles have black background ([31e1aaa](https://github.com/GrayCodeAI/shrike/commit/31e1aaa6a43a98748138ac5fd983ffa2fd7a1fa5))
* apply remaining changes from code review session ([9343a12](https://github.com/GrayCodeAI/shrike/commit/9343a12bf46fe6d4a19c5ee1a889247888a24aef))
* black background for all footer keys ([a3cc53d](https://github.com/GrayCodeAI/shrike/commit/a3cc53da817fd5f8daaf15ad005b56856cd0dc73))
* clean up filter tests for consistent validation ([1706f3b](https://github.com/GrayCodeAI/shrike/commit/1706f3bf5724bbb9466aecb3012d2ed4d50f71b0))
* clear remaining staticcheck + go mod tidy findings ([48f5aa9](https://github.com/GrayCodeAI/shrike/commit/48f5aa9fe2f8eec9d693dec2ee7d3cc704cbd857))
* commit six_layer_pipeline.go (was untracked, breaking CI) ([8e9fb06](https://github.com/GrayCodeAI/shrike/commit/8e9fb06b71e693260ef351e026a4cb21b84e244a))
* **compaction:** fix tests and improve compaction logic ([9e201e6](https://github.com/GrayCodeAI/shrike/commit/9e201e61a0e1c41c5e98c4daedda1c9d4c4be109))
* convert verbose flag from bool to count-based int ([ff9dcc5](https://github.com/GrayCodeAI/shrike/commit/ff9dcc5fa45d56aa4579d74d9cd47f73096d65ec))
* correct unit tests for new compression layers (L15-L19) ([497de4c](https://github.com/GrayCodeAI/shrike/commit/497de4cf284fa4ef6b2f21d3c02e91b8008f8bd3))
* deep code review — 13 bugs, security issues, and build failures ([1c281d1](https://github.com/GrayCodeAI/shrike/commit/1c281d113eb271aba18187ac1cc72d8787a6ff3c))
* disable flag parsing for git add to support -A, -u flags ([18f5029](https://github.com/GrayCodeAI/shrike/commit/18f5029b775da2158c65c4f098125dd43bac9550))
* disable flag parsing for git commit and push to support all flags ([6fcda6a](https://github.com/GrayCodeAI/shrike/commit/6fcda6a4a6eadd748c3ea83f8813b7efd2d3bd1a))
* eliminate all gray areas, pure black everywhere ([ba23639](https://github.com/GrayCodeAI/shrike/commit/ba23639749a115a23108801d2944dcb161274792))
* eliminate gray gaps in footer ([feddd53](https://github.com/GrayCodeAI/shrike/commit/feddd53801758dd2b40087346d2a327355a366ab))
* enable flag pass-through for aws and psql commands ([7cda4fd](https://github.com/GrayCodeAI/shrike/commit/7cda4fd98811f326781473879fa2214a39ff7197))
* enable flag pass-through for tree command ([c8a1076](https://github.com/GrayCodeAI/shrike/commit/c8a10764f4b8e2ed26b557ae5c6d1618f20a05c7))
* fix rewrite command tests - use E2E subprocess testing ([23c9b31](https://github.com/GrayCodeAI/shrike/commit/23c9b316fbb58f1f06f4c4178c07d63e461eaca4))
* footer pure black background ([5d49739](https://github.com/GrayCodeAI/shrike/commit/5d49739ff153ffb87f0ba4adecf0a13f227b03c2))
* git add supports -A and --all flags by default ([d61ab8c](https://github.com/GrayCodeAI/shrike/commit/d61ab8c0153ac6cb52413906d297d4a5513b3eb1))
* **git:** enable TraverseChildren for global flags before subcommand ([8c99e30](https://github.com/GrayCodeAI/shrike/commit/8c99e305c01177ae70ac82bc2142671d1815dba7))
* handle short strings in analyze test preview ([6801134](https://github.com/GrayCodeAI/shrike/commit/68011349622e3f15a4e121ee3ee6258383573cf1))
* improve error handling and remove emojis ([bd3924b](https://github.com/GrayCodeAI/shrike/commit/bd3924bab7718dbc1d45028d371911d9644ceb66))
* prevent over-pruning on small inputs in compression layers ([ea25908](https://github.com/GrayCodeAI/shrike/commit/ea259085b8122489e1c5d89ac1146555cb906526))
* proper spacing in footer keys ([626ccd3](https://github.com/GrayCodeAI/shrike/commit/626ccd3026930caf4f1cb1d97fadb82f649f0a1b))
* proper TOML escaping for all 100 inline filter tests ([35ae549](https://github.com/GrayCodeAI/shrike/commit/35ae549e6a1f555bb05318c2f9aabc95281addd2))
* proxy command --help handling ([9d2a99b](https://github.com/GrayCodeAI/shrike/commit/9d2a99b39035815c9081e9725494453b52697d6f))
* pure black background everywhere ([a1bf186](https://github.com/GrayCodeAI/shrike/commit/a1bf18665359d20f93fa74539d716684e4887a16))
* quality improvements - error handling, JSON modes, import order ([470bdc7](https://github.com/GrayCodeAI/shrike/commit/470bdc77cd6cf4c5278ce071607bf347201ce9e6))
* re-apply docker.go S1039 + add staticcheck.conf ([12379d6](https://github.com/GrayCodeAI/shrike/commit/12379d6631ba8e460d2fdced457d11b6c2ba0e22))
* register new command packages (tui, ai, sandbox, skills, api) in root.go ([760a0ba](https://github.com/GrayCodeAI/shrike/commit/760a0ba801c2eaddc0ed2fbe1d94874c8a29642d))
* remove all remaining gray backgrounds ([5f0037a](https://github.com/GrayCodeAI/shrike/commit/5f0037ab58bc2c7707ea1526552bac150c94d426))
* remove conflicting -q shorthand from audit command ([e819535](https://github.com/GrayCodeAI/shrike/commit/e8195357ffdd1c882ac36709b23a8ea13f6812ac))
* remove double boxes, single clean layout ([95d1851](https://github.com/GrayCodeAI/shrike/commit/95d18513df9ddb5524929475848f25002d4a5eb3))
* remove unused imports in TUI dashboard ([706bb13](https://github.com/GrayCodeAI/shrike/commit/706bb135c1e7685cc574ecee1ed45d8e54b69537))
* resolve 17 code quality issues ([f2bc16a](https://github.com/GrayCodeAI/shrike/commit/f2bc16a121938248f6a9b62112d2a2bf428b6146))
* resolve 27 security, resource leak, and error handling issues ([4287908](https://github.com/GrayCodeAI/shrike/commit/428790877de192d6909178bc507aaf817b2e5cda))
* resolve all critical issues from comprehensive code review ([3e3125d](https://github.com/GrayCodeAI/shrike/commit/3e3125d4009b592dd498ec8a80edd0e95a422793))
* resolve all issues and achieve A+ code quality ([be1f287](https://github.com/GrayCodeAI/shrike/commit/be1f287bf6636fdb825037493e24c3095c23402f))
* resolve build failures - unused imports, context leak, team ID collision ([d9f47df](https://github.com/GrayCodeAI/shrike/commit/d9f47df4e80fb02b7eba8a51498325038de30486))
* resolve compilation errors and reorganize command structure ([cf0a627](https://github.com/GrayCodeAI/shrike/commit/cf0a62748634696e34acfa6c4ed875fabbd359ff))
* resolve compilation errors in filter package ([64b0b78](https://github.com/GrayCodeAI/shrike/commit/64b0b78f658bab6f3b95f9d43c4794843c5a40ad))
* resolve critical test failures and add missing implementations ([a5525e3](https://github.com/GrayCodeAI/shrike/commit/a5525e3a201d13dce92e16aca11d54edfa3af0ea))
* resolve duplicate command registrations ([0c56c39](https://github.com/GrayCodeAI/shrike/commit/0c56c397d2be560e2e81d7f7619cca8f67ea9c45))
* resolve i18n embed path, all tests passing now ([26951f2](https://github.com/GrayCodeAI/shrike/commit/26951f27becd207e9da5a6c8c3f00eff4d916fea))
* resolve import cycle between shared and telemetry packages ([ca40ef2](https://github.com/GrayCodeAI/shrike/commit/ca40ef240de589507de9b7db7289ea4e939a202b))
* resolve integration test issues ([c043bd8](https://github.com/GrayCodeAI/shrike/commit/c043bd8ae00addcfa7408e9b835cd908db7555ad))
* resolve ProcessResult redeclaration, add parallel processor, SIMD optimizations, bytepool ([0e63033](https://github.com/GrayCodeAI/shrike/commit/0e6303356daeffa8d432b50063e336e411454947))
* resolve race conditions, null derefs, and code quality issues across 19 files ([da38fee](https://github.com/GrayCodeAI/shrike/commit/da38fee1fc0e0e8a28073f8bda624984e3fcf56c))
* resolve remaining CI failures ([14c9976](https://github.com/GrayCodeAI/shrike/commit/14c9976148cd0058dcd905ea8ea555f6d4a1032f))
* resolve syntax errors and build issues ([ba3409e](https://github.com/GrayCodeAI/shrike/commit/ba3409e35c38a1f10107167ecb7cda751f810b3a))
* resolve unicode test failures, all tests passing ([1d13ec1](https://github.com/GrayCodeAI/shrike/commit/1d13ec1f4bbd0a30675f3578415bf00ef0d6fbbd))
* satisfy staticcheck + unblock golangci-lint ([3e054db](https://github.com/GrayCodeAI/shrike/commit/3e054dbf2e5a774d5f3b6fb21fae220e8b98e809))
* security and stability improvements ([76f7271](https://github.com/GrayCodeAI/shrike/commit/76f7271e504662af13badd64705a7cbde9e71233))
* **tui:** stop section renderers from overflowing the Main pane ([592f49c](https://github.com/GrayCodeAI/shrike/commit/592f49c92bdbcbfdfd27d6635f61e4cad593d092))
* **tui:** stop slog from smearing stderr across the alt-screen ([5469408](https://github.com/GrayCodeAI/shrike/commit/54694082bd6515d4137ef9749a78183dedcdb097))
* welcome text black background ([108f81b](https://github.com/GrayCodeAI/shrike/commit/108f81b2d18f75ff4124d6e2933e074f6b932b91))


### Performance

* **filter:** deduplicate overlapping planned layer execution ([19b1c4e](https://github.com/GrayCodeAI/shrike/commit/19b1c4e997b8da5c0657111df860e7a8e2fc0345))
* optimize H2O filter memory for large contexts ([c9cd268](https://github.com/GrayCodeAI/shrike/commit/c9cd26879d10be33d5e1a03351571e166c3639c3))
* streaming memory optimization for large contexts ([0e216ae](https://github.com/GrayCodeAI/shrike/commit/0e216ae3c793e5f2caa6ecd43efe80fcb81aabb0))


### Refactoring

* add Pipeline interface, clean codebase ([d5e537f](https://github.com/GrayCodeAI/shrike/commit/d5e537f82218f934287c9c749dda319065bd4dbe))
* clean up code and improve naming ([d6f4be7](https://github.com/GrayCodeAI/shrike/commit/d6f4be75282237a6a7b9de14b4c3980701bf46c1))
* consolidate duplicates, fix rate limiter, remove dead code ([8fd87cf](https://github.com/GrayCodeAI/shrike/commit/8fd87cf787e7c7a075aeab1164f2ee1ed5baa6d9))
* consolidate filter packages and update codebase ([e417fdd](https://github.com/GrayCodeAI/shrike/commit/e417fdd8376b24c768070c94eb5cbd2b3ee95c74))
* consolidate layers to achieve 51-layer architecture ([a75a2bc](https://github.com/GrayCodeAI/shrike/commit/a75a2bc0a8bab4bdfce96085a553c0f81ed7aadb))
* drop undocumented undo + changelog subcommands ([5bbefa4](https://github.com/GrayCodeAI/shrike/commit/5bbefa4531459ec14ce887a0d6edb2802155fc20))
* extract shared HTTP middleware to httpmw package ([c82edd0](https://github.com/GrayCodeAI/shrike/commit/c82edd0736711bee3b42920eee7f6fbbddb36870))
* **filter:** enforce practical 20-layer runtime core ([eb7f964](https://github.com/GrayCodeAI/shrike/commit/eb7f9648442e1c61ebc3116b7ed419cd9228e4d7))
* **filter:** keep only curated experimental layers and merge redundant ones ([1c23bb6](https://github.com/GrayCodeAI/shrike/commit/1c23bb6acd3d01b382d95a60bbeb586a1f2c639b))
* fix proxy error handling, remove dead code, clean codebase ([5266cb3](https://github.com/GrayCodeAI/shrike/commit/5266cb3d1ce863dcb4eb5f2bf5e8a249b0b6f3ab))
* improve code quality and add tests ([c1e849e](https://github.com/GrayCodeAI/shrike/commit/c1e849ec9f6e1db3e8c74191ee021ea1db5c7079))
* introduce AppState struct to eliminate global state pattern ([6f21ae6](https://github.com/GrayCodeAI/shrike/commit/6f21ae6374f5faee415851f983dfae704e62d7b0))
* merge plugin/plugins, fix status/gain, add tests ([4f4182a](https://github.com/GrayCodeAI/shrike/commit/4f4182a3d7dec611d41519ecbe2b49d5545f0744))
* organize code following Go industry standards ([0b7b359](https://github.com/GrayCodeAI/shrike/commit/0b7b359274f3c6edc3f6c386d7615489110ac4ea))
* remove 33 dead code files across 16 unused packages ([9c64633](https://github.com/GrayCodeAI/shrike/commit/9c646331ac5a6a1991ea505fb1d7137b7edbef72))
* remove all external tool references from code ([7a81c09](https://github.com/GrayCodeAI/shrike/commit/7a81c09d5a1492f1903c4b695af7ec4317f41d45))
* remove dead code and cleanup codebase ([ea34956](https://github.com/GrayCodeAI/shrike/commit/ea34956c14671a132c7a5862876cf3d978ae23f6))
* remove orphan internal packages and unused bfcl cmd ([d4a5eb0](https://github.com/GrayCodeAI/shrike/commit/d4a5eb0928c7bd0e4b0e48801cf8a40d663f08f1))
* remove task IDs from code comments ([47284fa](https://github.com/GrayCodeAI/shrike/commit/47284fa50a0b7fb08477cca05c950d2da9a194ad))
* remove unused internal agent/hook/quality/tokenizer/undo packages ([2a91f70](https://github.com/GrayCodeAI/shrike/commit/2a91f708d4522235d2da31955844bc6f6a755523))
* rename 56 files to meaningful descriptive names ([09381f3](https://github.com/GrayCodeAI/shrike/commit/09381f3c48c5eb14a3327e69a604efb06144bb90))
* rename tfidf stage label to pre_tfidf ([9e5bf81](https://github.com/GrayCodeAI/shrike/commit/9e5bf8117f6d62d0f4ce436c5cfae455a4a6b9b8))
* rename ShrikeStatus/ShrikeRule to ShrikeStatus/ShrikeRule ([b49d3cd](https://github.com/GrayCodeAI/shrike/commit/b49d3cd0f000349196ec2c4427d2cfb351e05eaf))
* renumber late pipeline layer IDs to 20-29 ([8435f32](https://github.com/GrayCodeAI/shrike/commit/8435f3296364013615855d7b1fd066c690206b2a))
* replace all Shrike references with Shrike ([3427f61](https://github.com/GrayCodeAI/shrike/commit/3427f61c1e82bd8789fa988819cfcc25325e8bba))
* simplify welcome screen and status bar ([e87569d](https://github.com/GrayCodeAI/shrike/commit/e87569d2cc732fde264fa75fd45f462c90817041))
* split god files into focused files and extract embedded HTML ([99881c3](https://github.com/GrayCodeAI/shrike/commit/99881c39120926848992a6ef92b10ed8d8fe7d07))
* **tui:** harden foundation before section build-out ([515250f](https://github.com/GrayCodeAI/shrike/commit/515250f6236163d361b42fabe76d1b71a26afed5))
* unexport internal functions, add interfaces ([f77e04a](https://github.com/GrayCodeAI/shrike/commit/f77e04a56d62d6002138f18aa07a17482cdedab8))
* update module path to GrayCodeAI org ([9d382ba](https://github.com/GrayCodeAI/shrike/commit/9d382ba17801fa69dffae9ce8bfa7b7165fa7baa))


### Tests

* add 6 more inline tests (kotlinc, jest, vitest, npm, cargo) ([e8eb477](https://github.com/GrayCodeAI/shrike/commit/e8eb4772dc4984720b8ea821e945769b7ab66a43))
* add 8 more inline tests (gradle, mvn, mix, make) ([8100c5d](https://github.com/GrayCodeAI/shrike/commit/8100c5de4407e66cd92ae7b73a1d4e06a72140e2))
* add comprehensive test coverage (filter, core, commands, tracking) ([52882c0](https://github.com/GrayCodeAI/shrike/commit/52882c0d9606d58cc99740315768cd797863f226))
* add inline tests to 3 more filters (pip-install, tsc, ls) ([b44b864](https://github.com/GrayCodeAI/shrike/commit/b44b864312fc9a78a03be74ef427940d38cc9371))
* add inline tests to 4 more critical filter files ([fcf9772](https://github.com/GrayCodeAI/shrike/commit/fcf9772cc6826b5e3744f7a928c04b5e8f92ebc3))
* add inline tests to 4 more system command filters (grep, find, tree, df) ([c4a1964](https://github.com/GrayCodeAI/shrike/commit/c4a196444be5778ab0113fbe82efa56528719de8))
* add inline tests to docker.toml and go.toml ([db8f85e](https://github.com/GrayCodeAI/shrike/commit/db8f85ef4ff824dd733c9864b6599520c631cb1c))
* add inline tests to jest.toml and vitest.toml ([7f18c1d](https://github.com/GrayCodeAI/shrike/commit/7f18c1d65357286df5ac48ab19b0a314ed877d0d))
* add inline tests to npm, aws, kubectl-get, trivy filters ([3f23dbc](https://github.com/GrayCodeAI/shrike/commit/3f23dbcec158cdea20f1f21669f6119de85ce876))
* add inline tests to pip, curl, rustc, basedpyright ([5f52944](https://github.com/GrayCodeAI/shrike/commit/5f52944549f930a25df4bdecca591f785a8ef8a9))
* add inline tests to playwright.toml and trivy.toml ([6ae3e71](https://github.com/GrayCodeAI/shrike/commit/6ae3e7155ad20c683e5c190e10fd7799a3a2fed8))
* add inline tests to pnpm and du filters ([1b89852](https://github.com/GrayCodeAI/shrike/commit/1b8985234b5e45f6b9e12edb65460bf18f795f5d))
* add inline tests to rg, fd, brew-install filters ([d08718c](https://github.com/GrayCodeAI/shrike/commit/d08718c43d7a9fde3a3e953f6a9760bcc520596f))
* add inline tests to ruff.toml (Python linting) ([876f764](https://github.com/GrayCodeAI/shrike/commit/876f764e6df2d1a9e1d26651ea2208c459e303ae))
* add inline tests to terraform-apply.toml ([266d189](https://github.com/GrayCodeAI/shrike/commit/266d189cffa9fd5da6982f81b4b83288c7e4bbfe))
* add inline tests to terraform-init.toml ([fc1c588](https://github.com/GrayCodeAI/shrike/commit/fc1c588606dd27468554bd479081336d5b4bfca4))
* add inline tests to webpack, helm, ansible-playbook, gcc ([c365e16](https://github.com/GrayCodeAI/shrike/commit/c365e168475ec4285a1637c642bd21a2fa0e6943))
* add inline tests to yarn, bundle-install, kubectl-logs ([bdcb727](https://github.com/GrayCodeAI/shrike/commit/bdcb72757179ffc9430eb7a10308ae9df8e346a6))
* add integration test suite for 20-layer pipeline ([ffc6e6b](https://github.com/GrayCodeAI/shrike/commit/ffc6e6b13fb3087dcad739bc9f12cfbec58441b9))
* add integration tests for new commands ([f3f4269](https://github.com/GrayCodeAI/shrike/commit/f3f42696878477eddacad49f935fd6ca19fa8e59))
* **ci:** harden audit stability with regression fixtures and migration compatibility checks ([63314ad](https://github.com/GrayCodeAI/shrike/commit/63314ad03b912118f99ee85f5355125c1742f6ce))
* **commands:** add root registration guard and refresh layer docs ([34d5232](https://github.com/GrayCodeAI/shrike/commit/34d523272ffb482a75abbcff45d3dee880951022))
* comprehensive utils package coverage ([382a67b](https://github.com/GrayCodeAI/shrike/commit/382a67bc545c737aa72afb01b07fb7ddcca96e2b))
* cover wenyan + commit-msg + review-diff ([7a84c22](https://github.com/GrayCodeAI/shrike/commit/7a84c22bb152c6d52e7fcce8d228931b5362d878))
* expand core package test coverage ([e82d53c](https://github.com/GrayCodeAI/shrike/commit/e82d53cdd925a854b27dcad17b00962680207e1c))
* **filters:** golden-file harness + fix non-deterministic filter selection ([6c9897e](https://github.com/GrayCodeAI/shrike/commit/6c9897e9042ad4555b04cc80a2117f77186cfae9))
* fix slack token pattern to avoid secret scanning false positive ([488e2b8](https://github.com/GrayCodeAI/shrike/commit/488e2b865c6717b2c30375aff26154d60eb95080))
* **init:** end-to-end round-trip for top-5 wired agents ([aa043c9](https://github.com/GrayCodeAI/shrike/commit/aa043c9e9981aee90d0b26af61625f565a0e88db))
* reach 100 inline tests milestone! (+2 in wc, watch) ([bd1bb53](https://github.com/GrayCodeAI/shrike/commit/bd1bb532f783ec2894ded62b5f28c2de4387c63e))


### Documentation

* acknowledge 15+ real OSS token reduction competitors ([a06a516](https://github.com/GrayCodeAI/shrike/commit/a06a5163fa9cc3ca422f140e00b16654ce8b3893))
* add CHANGELOG and update README for v1.1.0 release ([4a506c3](https://github.com/GrayCodeAI/shrike/commit/4a506c37998f9929c4b744b9c0ad03bc8fc50f77))
* add CHANGELOG for v2.0.0 - SIMD and 20-layer release ([38da3ed](https://github.com/GrayCodeAI/shrike/commit/38da3ed5ec1501c52b71830907222ea633042bb0))
* add CHANGELOG for v2.1.0 - MCP server, proxy mode, T12/T17/T35 ([c9f0c4a](https://github.com/GrayCodeAI/shrike/commit/c9f0c4adf4443f089da770c01ccc8b8cfedfd4dd))
* add competitor comparison table, improve README structure ([5f149af](https://github.com/GrayCodeAI/shrike/commit/5f149aff129fe9c88e5647cd1d6f2177672d9d8f))
* add comprehensive ARCHITECTURE.md ([d132793](https://github.com/GrayCodeAI/shrike/commit/d132793326dbf3f3c77c5c32a44a70cd4cedfb55))
* add comprehensive benchmark dashboard ([d7c6e0b](https://github.com/GrayCodeAI/shrike/commit/d7c6e0baa3b746ef4e4500f53d9d8e20be782ec9))
* add comprehensive comparison with top 20 competitors ([43ce8f1](https://github.com/GrayCodeAI/shrike/commit/43ce8f1837987f1ff5275e9fb44bc94fe9bc71e8))
* add comprehensive completion report for Quick Wins ([e68b2f9](https://github.com/GrayCodeAI/shrike/commit/e68b2f94fc48a60a475f76a3bc06429f75782d95))
* add comprehensive documentation site ([11e835b](https://github.com/GrayCodeAI/shrike/commit/11e835bf4e83c70eac5c199b7c9faef23e193355))
* add comprehensive feature checklist ([fb81094](https://github.com/GrayCodeAI/shrike/commit/fb81094ab4a3fd7c3acf6a991f800c657bf11886))
* add comprehensive usage guide for competitive features ([841b8d9](https://github.com/GrayCodeAI/shrike/commit/841b8d9bf3f7c33a800edbe8f02d596852e3f5a1))
* add detailed feature-by-feature comparison table for top 20 competitors ([ff1dc07](https://github.com/GrayCodeAI/shrike/commit/ff1dc07ed646b71ba4f33b57425342760ba2a308))
* add Discord badge and link ([be96259](https://github.com/GrayCodeAI/shrike/commit/be9625962e066711fe0be19596ae4a86650560dc))
* add LAYERS.md documentation for Layers 15-20 ([d5e1562](https://github.com/GrayCodeAI/shrike/commit/d5e1562da0c8748087bfe7678d547c8185915651))
* add live demo examples to README ([a3c3296](https://github.com/GrayCodeAI/shrike/commit/a3c32966761a6551ebebb7ad07b71db3bef4ed5a))
* add Phase 2 completion report ([9567389](https://github.com/GrayCodeAI/shrike/commit/9567389997568b9adde41fc935e9c438e4f2125b))
* add Phase 9 testing and documentation ([badea13](https://github.com/GrayCodeAI/shrike/commit/badea13310aad1f320bfe43f2362507b3efd54a2))
* add progress report in Chinese ([902e12c](https://github.com/GrayCodeAI/shrike/commit/902e12c43a387c50ac970b8fa18cc341f6576788))
* add README translations (Chinese, Japanese) ([373ed5b](https://github.com/GrayCodeAI/shrike/commit/373ed5be122fec5d03c23be92a8cc6f31a3baf1d))
* add v1.2.0 changelog for 14-layer pipeline ([bd1981a](https://github.com/GrayCodeAI/shrike/commit/bd1981aef0c88b2f0d5bc2cacb58ae533ba0b545))
* clarify what shrike actually does — honest token savings breakdown ([48f726d](https://github.com/GrayCodeAI/shrike/commit/48f726de63346da6a38b323f3aaaa49a83cd60d2))
* complete Phase 8 of compression migration plan ([2acc505](https://github.com/GrayCodeAI/shrike/commit/2acc505a647d72b2dfc3348799bfffed73f18cb1))
* complete README translations for all 7 languages ([98ec19e](https://github.com/GrayCodeAI/shrike/commit/98ec19e2ca629ec5ffb77b5b8d2e957970be3ad3))
* comprehensive documentation update for v0.1.0 release ([5945d38](https://github.com/GrayCodeAI/shrike/commit/5945d3896c585b7b0fed12385c051f3d7635fe81))
* comprehensive implementation plan from competitor analysis ([8b324c9](https://github.com/GrayCodeAI/shrike/commit/8b324c930984aa0b84e21acdcfd6bc824b236cf6))
* comprehensive OSS competitor research (honest, in-progress) ([f6ca6bb](https://github.com/GrayCodeAI/shrike/commit/f6ca6bbcfe80b2bc7d8a7ad93aaee9284c09e917))
* consolidate 51 layers to 20 essential layers ([1889f3c](https://github.com/GrayCodeAI/shrike/commit/1889f3c2308475af4cc60a48390fa83a061370a7))
* correct research paper count to 30+ ([70b2052](https://github.com/GrayCodeAI/shrike/commit/70b20529e4677a75886dfb58b9ce3be07d700a61))
* create framework for deep competitor analysis ([05f913e](https://github.com/GrayCodeAI/shrike/commit/05f913e5c107f34761db6e67dcb600180f16b13b))
* deep check functionalities in shrike ([9eae3bb](https://github.com/GrayCodeAI/shrike/commit/9eae3bbc55e60370b66d529e4c9342855c7f1ed5))
* **filter:** align project to strict practical 20-layer core ([251dcf2](https://github.com/GrayCodeAI/shrike/commit/251dcf2fddf29213ce0f4b2ed06e965f620a6c09))
* fix layer count to actual 31 layers, add all layers to table ([24b313d](https://github.com/GrayCodeAI/shrike/commit/24b313db104d43f1e31733caa274afe2b7cb4cd5))
* fix README discrepancies - correct dashboard command and SIMD status ([d13d857](https://github.com/GrayCodeAI/shrike/commit/d13d857a147ae77d3b23444faa8910b7008ec4e3))
* harmonize layer architecture and naming across guides ([c01711f](https://github.com/GrayCodeAI/shrike/commit/c01711fa633940e22eefc74e950a5028b401f3de))
* honest analysis of real competitors vs adjacent tools ([e7b91c5](https://github.com/GrayCodeAI/shrike/commit/e7b91c5fcfdec1c13a1a9f264c7a649f75ff45ed))
* modernize documentation and remove unnecessary files ([7df0532](https://github.com/GrayCodeAI/shrike/commit/7df0532c3ee8fdba5d835a1f27e2ce23be4862b1))
* modernize README, CONTRIBUTING, SECURITY, CHANGELOG, AUTHORS ([f36fbac](https://github.com/GrayCodeAI/shrike/commit/f36fbac233ec50919f62554a8c654b0673f5b47c))
* overhaul README with competitor analysis, token savings table, research links ([8e5476c](https://github.com/GrayCodeAI/shrike/commit/8e5476c52e654e82ee344592ebca8bbc7d5145a5))
* reconcile LAYERS.md compression claims with measured numbers ([a9f0a6a](https://github.com/GrayCodeAI/shrike/commit/a9f0a6a4f6b90516f30202b5620bd1b68e014e13))
* redesign README with cleaner layout, real examples, and better visual hierarchy ([dc85029](https://github.com/GrayCodeAI/shrike/commit/dc850294892bdf1b1da0393ea10d1d4876987384))
* remove 10 stale files (CLAW_*, PRE_TUI_*, DASHBOARD_*, TUI_*) ([9c31cfd](https://github.com/GrayCodeAI/shrike/commit/9c31cfdbdd475af979c530bb29e36f8414f4f6c6))
* remove references from README ([74edaaa](https://github.com/GrayCodeAI/shrike/commit/74edaaaf629f83fd52a51b86635d1cab0d7288f6))
* start research on real OSS token reduction competitors ([6fc1ea6](https://github.com/GrayCodeAI/shrike/commit/6fc1ea6eb0f38a18ad523df8eb985e33305fff09))
* update AGENTS.md files to reflect renamed files ([b0a9e0a](https://github.com/GrayCodeAI/shrike/commit/b0a9e0a0e79ed67c87037d1515ef93d06dbbff0e))
* update clone URL to GrayCodeAI org ([017bb4f](https://github.com/GrayCodeAI/shrike/commit/017bb4f567ef58dc6ff50661b47a9dd438b5f05c))
* update LAYERS.md for 14-layer architecture ([84d3859](https://github.com/GrayCodeAI/shrike/commit/84d3859d02931b6d95dd67a407fb0ea6159c6a04))
* update README for 14-layer compression pipeline ([5786925](https://github.com/GrayCodeAI/shrike/commit/578692521264969ffa2e72304ce23b5930611f68))
* update README for 20-layer pipeline architecture ([29929a1](https://github.com/GrayCodeAI/shrike/commit/29929a14b84ae68e187f4c6d2ec04e6a23bebf36))
* update README with 40+ enterprise packages and v1.5.0 changelog ([cd8611d](https://github.com/GrayCodeAI/shrike/commit/cd8611dffe93c743fb14df735fec2598cd74933f))
* update README with all new commands and features ([81481bd](https://github.com/GrayCodeAI/shrike/commit/81481bdf33c5ddf01cccf1cadfc44de16d30062c))
* update compression migration plan to reflect actual 87% completion ([28bb224](https://github.com/GrayCodeAI/shrike/commit/28bb22422b94aa6f5e3b66bcee5646d129f2614e))

## 1.0.0 (2026-04-20)


### Features

* achieve 100% quality (A+) - add security, performance, and resilience fixes ([a0b6add](https://github.com/GrayCodeAI/shrike/commit/a0b6addc004a3de8f619050ad36b309e3a4694da))
* add 11 more important git commands ([9236cb8](https://github.com/GrayCodeAI/shrike/commit/9236cb88d421cd824408d2ef6198de69cbee70ba))
* add 14 more test files, 4 TOML filters ([9c4e332](https://github.com/GrayCodeAI/shrike/commit/9c4e332d15a30a2a9da051a158033fe94d32ee6e))
* add 15 more git commands ([7b0360d](https://github.com/GrayCodeAI/shrike/commit/7b0360d98f88a3e8bc4b04de303ccd25e33187ec))
* add 50-layer registry roadmap and gating framework ([fad93eb](https://github.com/GrayCodeAI/shrike/commit/fad93ebf74d3f7eabc4599de6d39d74b7b43bb7d))
* add 7 new 2026 research layers, tier-based compression, and code quality improvements ([0b1365b](https://github.com/GrayCodeAI/shrike/commit/0b1365b07f76dafc297ec6096224bbb31733268a))
* add adaptive evaluation script and report generator ([5837dd1](https://github.com/GrayCodeAI/shrike/commit/5837dd127bbf3ace2660cee038e7fd0c7a32f4f3))
* add adaptive layer selection based on content type ([3527f8e](https://github.com/GrayCodeAI/shrike/commit/3527f8e33304bd04311a8bc63cd0dd5e4a48a8dd))
* add adaptive tier system for automatic layer selection ([d48cfd1](https://github.com/GrayCodeAI/shrike/commit/d48cfd15f40ff64b4abd3e6c0c82d5da27e4931d))
* add agent/model/provider attribution for token savings ([c8213f1](https://github.com/GrayCodeAI/shrike/commit/c8213f1d84f8c8e0378852ae4a701588f4fb294b))
* add ALL 152 official git commands ([b48bc18](https://github.com/GrayCodeAI/shrike/commit/b48bc189e54976a5280d389cc8365fc866055744))
* add all competitor features - tee recovery, cost tracking, live monitor, prompt debugger, discover, session tracking, dup detection ([dc23fda](https://github.com/GrayCodeAI/shrike/commit/dc23fda6f237ebb2b529386bad7ceb3d64da3a0c))
* add full compression stack features to shrike ([87b26bf](https://github.com/GrayCodeAI/shrike/commit/87b26bf8b9dfcb4419e29cda1edd3758212b95d6))
* add compression features and performance optimizations ([98295cd](https://github.com/GrayCodeAI/shrike/commit/98295cd93d2f341b4c34b27e6e3b5919b21d9d4f))
* add beautiful real-time TUI dashboard ([01bd0d8](https://github.com/GrayCodeAI/shrike/commit/01bd0d84b9de5786a486e9404f5d3d869e7844b5))
* add benchmark CI reporting and adaptive profile validation ([bb1ca2f](https://github.com/GrayCodeAI/shrike/commit/bb1ca2f850343b5f591491e0f36642fca8056198))
* add benchmark suite + fix quality command linter warning ([826a90e](https://github.com/GrayCodeAI/shrike/commit/826a90e1fcb8a911a7f2936cc97b138fa8336cfa))
* add Beyond Parity features - plugins, dashboard, CI/CD, tests ([fdc3095](https://github.com/GrayCodeAI/shrike/commit/fdc3095cec171f7278af8b30a6114e42897474af))
* add cargo install and proxy commands ([c990e82](https://github.com/GrayCodeAI/shrike/commit/c990e829c50c6d88599a8c27be66e8e41c13d9d4))
* add cargo nextest and gh pr view support ([4a29148](https://github.com/GrayCodeAI/shrike/commit/4a29148f6e615a43fc7ab6f17c43eb4ca6e3d01c))
* add community TOML filter marketplace (T40) ([deaa28a](https://github.com/GrayCodeAI/shrike/commit/deaa28a01cac0aa78c15c613df41c96f818096f4))
* add competitive features - quality scoring, visual diff, multi-file merging ([9400311](https://github.com/GrayCodeAI/shrike/commit/94003114835d769c060b440373932c0f3eed72e6))
* add comprehensive benchmark suite for Shrike performance comparison ([357a872](https://github.com/GrayCodeAI/shrike/commit/357a87232f8fcf3788ad38af9f939a2aba9d1842))
* add Crush/HERM-like features ([0cb5bc7](https://github.com/GrayCodeAI/shrike/commit/0cb5bc79862af010788decc0283e19fba16ae1e0))
* add distribution and deployment support ([87c9567](https://github.com/GrayCodeAI/shrike/commit/87c9567b6e4ea8c4b22af0e38ba140a1657e86d8))
* add Docker support with multi-stage builds and compose ([90e7ea6](https://github.com/GrayCodeAI/shrike/commit/90e7ea693e754a3d046d88f1f24000e1b087fae9))
* add dynamic frequency estimation (T11) for +15-20% entropy accuracy ([0beeb6a](https://github.com/GrayCodeAI/shrike/commit/0beeb6a906759c55a77c569e9cc34b36cbec2652))
* add extensive command wrappers for token reduction ([2c2a2ba](https://github.com/GrayCodeAI/shrike/commit/2c2a2ba4326400d6554a90a533caf87fcda5813c))
* add Go SDK for native token compression ([72d216d](https://github.com/GrayCodeAI/shrike/commit/72d216d0f726dc6e19d7e0e1fd066c91dc796ad8))
* add IDE plugins and cloud features ([ac77f93](https://github.com/GrayCodeAI/shrike/commit/ac77f93fcd8238c95eec4d04f0b1a9f664c1d0de))
* add integrity verification and economics analysis ([d7b7a90](https://github.com/GrayCodeAI/shrike/commit/d7b7a90fecd646967ef3ce7ca29586dfa218595c))
* add interactive Bubbletea TUI dashboard ([9853a7b](https://github.com/GrayCodeAI/shrike/commit/9853a7b90fc081eaa32b3546d6ddc39fc9796990))
* add internationalization (i18n) - 6 languages ([29fae2c](https://github.com/GrayCodeAI/shrike/commit/29fae2c5bacb05d9a247a5acc826aa68348ed5ef))
* add LangChain and LlamaIndex integration examples ([2328d0f](https://github.com/GrayCodeAI/shrike/commit/2328d0f7f6d5aeec2cbc0f8ae80ced732c1d0812))
* add language support, API server, WASM plugins ([fbf7059](https://github.com/GrayCodeAI/shrike/commit/fbf70599c4986bc60464661055551aba00e2f2b5))
* add Layer 12 Attribution Filter (ProCut-style pruning) ([788f0f8](https://github.com/GrayCodeAI/shrike/commit/788f0f847774492ef525c2c4d4c8f4c8434050d5))
* add Layer 13 H2O Filter (Heavy-Hitter Oracle compression) ([da7aeb7](https://github.com/GrayCodeAI/shrike/commit/da7aeb76142ff46353876cacfa437f29db0380ce))
* add Layer 14 (Attention Sink Filter) with benchmarks ([f58f06a](https://github.com/GrayCodeAI/shrike/commit/f58f06a4e460972288c07f0a9b7758d370bd1f72))
* add Learning Mode (auto-discover patterns) + CLI commands ([9d7f2b7](https://github.com/GrayCodeAI/shrike/commit/9d7f2b70100153a153bfa4dd670345b0596c4a39))
* add MCP server mode for AI assistant integration ([80218a9](https://github.com/GrayCodeAI/shrike/commit/80218a9d73baadadc4ba85a2680cd5bba3c1b9ac))
* add parity commands (config, proxy, hook-audit, gain, discover, learn, err) ([9e6f149](https://github.com/GrayCodeAI/shrike/commit/9e6f1497204ccf75dc56b6b089ad3b1719971a67))
* add performance optimizations and layer configuration ([e204db7](https://github.com/GrayCodeAI/shrike/commit/e204db71498fbdf1bcbcaef308eb3f0d94d18f79))
* add performance optimizations and new features ([e997bfa](https://github.com/GrayCodeAI/shrike/commit/e997bfa22f0c7565337fab0224b014b085efcf3a))
* add pipeline manager, config layer, audit command, and docs ([95a1a64](https://github.com/GrayCodeAI/shrike/commit/95a1a64b19b5fc01ec6e142d6ac7277eb29b109f))
* add production-ready features ([af9921a](https://github.com/GrayCodeAI/shrike/commit/af9921adcd16f74bdbe69d4fae06f373712707fa))
* add production-ready infrastructure ([6adbc79](https://github.com/GrayCodeAI/shrike/commit/6adbc79e36da3aac23aa431220a8df0893e6d83a))
* add Prometheus metrics and structured logging ([c30c026](https://github.com/GrayCodeAI/shrike/commit/c30c026149e4a5f8ed11001fcd8ca5d851e775bd))
* add Python SDK for token compression ([cef5caf](https://github.com/GrayCodeAI/shrike/commit/cef5caf3e716f5dc55bd851dbcad298b441f39e6))
* add research roadmap and adaptive prefilter scaffolds ([31d4bd7](https://github.com/GrayCodeAI/shrike/commit/31d4bd7dc39992c94f2329bc8617d1868d51edd5))
* add reversible compression and restore command ([714a837](https://github.com/GrayCodeAI/shrike/commit/714a8370cac43f0101dd82d0eaa468787b0e3df3))
* add Ruby ecosystem commands and new AI agent integrations ([f700936](https://github.com/GrayCodeAI/shrike/commit/f700936b561e6b880677811c446182b0ebebe5a2))
* add session command for adoption tracking ([1ecb7cb](https://github.com/GrayCodeAI/shrike/commit/1ecb7cbb4db3f4f7d09faa9910b8060ef2585249))
* add session recovery (OMNI parity) + 44 new tests across new packages ([6d13c80](https://github.com/GrayCodeAI/shrike/commit/6d13c80bb21fc425d5a8d04479728877cd602b45))
* add SIMD-optimized operations for compression hot paths ([5018549](https://github.com/GrayCodeAI/shrike/commit/50185499b8f45ba8227dc477f0a0d17743cb38e0))
* add stage gates and adaptive attention sinks (T7, T14) ([2a44e69](https://github.com/GrayCodeAI/shrike/commit/2a44e69d2244b79f49334114c235b27802eaf93c))
* add streaming API for real-time compression ([e24302e](https://github.com/GrayCodeAI/shrike/commit/e24302e181ffd7f2d184c1dee0ada34ba0b17a7b))
* add support for all git commands ([d9b97a5](https://github.com/GrayCodeAI/shrike/commit/d9b97a5e1119bfc45107d70e5cd7eb000cd85427))
* add T12, T17, T30 - question-aware, density-adaptive, and binary optimization ([f87dfb8](https://github.com/GrayCodeAI/shrike/commit/f87dfb85e9dd4c12634c499be258c84acfa9bfda))
* add terraform and helm commands with specialized filters ([8d55e73](https://github.com/GrayCodeAI/shrike/commit/8d55e7307fed6849155d83c2ad3974599251aaec))
* add test coverage, SIMD support, and WASM plugin system ([43bd17c](https://github.com/GrayCodeAI/shrike/commit/43bd17cfa58c220c57e06facef602fbf08fd3070))
* add tests, multi-language READMEs, expand TOML filters ([6f76a1a](https://github.com/GrayCodeAI/shrike/commit/6f76a1a4ac44c1e272db4b0d9ff1c2ae81a9609b))
* add tiered compression system and practical CLI tools ([151c6ad](https://github.com/GrayCodeAI/shrike/commit/151c6ad04102bc36a9fae0e5f334d7cccae2dcba))
* add timestamps to shrike gain output ([6ef0a97](https://github.com/GrayCodeAI/shrike/commit/6ef0a9754ed417503fd7c3f6ffdfc183ac6b5a91))
* add TOML filters for modern development tools ([e042680](https://github.com/GrayCodeAI/shrike/commit/e0426802ba36b484e26b2a4938dd822ddd013e13))
* add TUI, AI providers, Docker sandbox, slash commands ([a026fdb](https://github.com/GrayCodeAI/shrike/commit/a026fdb1d37005d08957fc55998c78b38d3c763a))
* add TypeScript/Node.js SDK ([224d690](https://github.com/GrayCodeAI/shrike/commit/224d69098ca91298ce584e5183ea4c0f76bb734c))
* add ultra-compact mode and TeeOnFailure to all major commands ([e429ad5](https://github.com/GrayCodeAI/shrike/commit/e429ad5451834caa828c193e19a0f099475de8e8))
* add version support with ldflags ([a3e2f92](https://github.com/GrayCodeAI/shrike/commit/a3e2f9262bb7aaec56f34dbe4a1c6d41906a034c))
* add WASM build for browser-based compression ([2bff3fc](https://github.com/GrayCodeAI/shrike/commit/2bff3fc1456da0942e7d390120bbeaba9cece43a))
* add welcome screen to TUI ([30027be](https://github.com/GrayCodeAI/shrike/commit/30027bef3f6f0c0f22542f1ef1d734e8a2bee7e5))
* add Welcome To Shrike header ([1f12677](https://github.com/GrayCodeAI/shrike/commit/1f126775bcd023272cc0dcd9588ce06e5301a93e))
* add YAML filter support (Snip parity) + MCP documentation ([a55eb63](https://github.com/GrayCodeAI/shrike/commit/a55eb6332050bc63be50d436934214d6ca7c0c4c))
* add ZSH-specific shell integration with precmd/preexec hooks ([4b65b1b](https://github.com/GrayCodeAI/shrike/commit/4b65b1b341594573f0ea453ccba6de770e52fba6))
* adopt WOZCODE features into Shrike ([2f48b98](https://github.com/GrayCodeAI/shrike/commit/2f48b985e1178f643c64d0637d8ee2544a543b2c))
* all black background - clean professional look ([13c9a3a](https://github.com/GrayCodeAI/shrike/commit/13c9a3acbb7173da69f7f7bc42e57ac9a238ae90))
* ASCII art Shrike logo ([1911ec0](https://github.com/GrayCodeAI/shrike/commit/1911ec04747abab55c09aba717cbdc5d7f4af68e))
* ASCII Shrike with 2 spaces from top ([8bd909b](https://github.com/GrayCodeAI/shrike/commit/8bd909b66d454144cab3afcb9f1efc662a92243e))
* **audit:** add adaptive budget control, intent profiles, anchor retention, and agent budget analytics ([fc68803](https://github.com/GrayCodeAI/shrike/commit/fc688036e80569e0f39953361c0018a1b8c6670e))
* **audit:** add detector registry, checkpoint telemetry, drift fingerprints, and turn analytics ([fb12899](https://github.com/GrayCodeAI/shrike/commit/fb128990b18c79024b43b3eb409ca723939bbdca))
* **audit:** add shrike audit engine with quality, waste, checkpoint and snapshot analysis ([1ead7d5](https://github.com/GrayCodeAI/shrike/commit/1ead7d50bd165daa76406742805657e3d5098ec3))
* auto-dismiss welcome screen after 2 seconds ([558ea47](https://github.com/GrayCodeAI/shrike/commit/558ea47c0d58eb266f454023642e8f907b16f91d))
* btop-style multi-panel TUI with rounded borders ([441888b](https://github.com/GrayCodeAI/shrike/commit/441888b8de97f9bc85ed8ddae6bc6af3a969b851))
* Claude Code-style CLI with big prominent input box ([12bf912](https://github.com/GrayCodeAI/shrike/commit/12bf91240bafa9a02e416250f0735bc847c4c939))
* Claude Code-style interface with open input box ([e46fde2](https://github.com/GrayCodeAI/shrike/commit/e46fde2cdcacbba9d842e05899755d8e7b94dd98))
* clean chat-style CLI like Mistral Vibe ([fc2228e](https://github.com/GrayCodeAI/shrike/commit/fc2228e32dff4a2b4c4cc4bea49ff5b489d3c8bb))
* **cli:** add compaction flags for Layer 11 ([f9c868c](https://github.com/GrayCodeAI/shrike/commit/f9c868c987fe478109628ef9ba6baeb689f576c2))
* close 9 world-class compression parity gaps ([f0059eb](https://github.com/GrayCodeAI/shrike/commit/f0059ebc2201cbe3c0ad5a8776b5f656e1bc8c87))
* close last two prompt-compression gaps ([3028726](https://github.com/GrayCodeAI/shrike/commit/302872695f5482bb8a8e5c340e1613755a31dd1c))
* close shrike compression parity gaps ([760f326](https://github.com/GrayCodeAI/shrike/commit/760f3268c5de816c00e6f92657f8f19834457942))
* complete honest competitor analysis - cloned and analyzed 15 OSS tools ([3000897](https://github.com/GrayCodeAI/shrike/commit/3000897d43294cebc80fe4ad37f8c22142e2e642))
* complete integration test suite with archive fixes and MCP tools ([669293c](https://github.com/GrayCodeAI/shrike/commit/669293c6fe9589696197e2dcbe9f22c5d5b71535))
* complete SIMD optimization with Go 1.26 ([a3dbc85](https://github.com/GrayCodeAI/shrike/commit/a3dbc857d662ab98690cc06e90d888491bf0f0fa))
* complete tasks 1-20 - project foundation & structure ([de2e3a5](https://github.com/GrayCodeAI/shrike/commit/de2e3a58f32be8f8eacff0ba2a3bb18357121f11))
* complete tasks 21-230 - README, examples, installers, RewindStore ([67a19e6](https://github.com/GrayCodeAI/shrike/commit/67a19e6dc64e820ca1c139c77b50c1e222959465))
* **config:** add full environment variable compatibility ([e6ece2c](https://github.com/GrayCodeAI/shrike/commit/e6ece2c32d57500d2e1eef915d4fb4bb009ba24f))
* **config:** add ignore_files and env var compatibility ([1676b62](https://github.com/GrayCodeAI/shrike/commit/1676b622fed5ba1872996553c1fb1dbc6b5f3d33))
* **config:** add Windows XDG path support ([2f8c04d](https://github.com/GrayCodeAI/shrike/commit/2f8c04d6d08db52bbe1b5ebe925ca8115fa271a6))
* continue i18n - README French, i18n loader package ([e8ad621](https://github.com/GrayCodeAI/shrike/commit/e8ad621961a3620ff5a34deb597ebdf018d3b9c6))
* different colors for footer keys + clarify timestamp ([5a9ae26](https://github.com/GrayCodeAI/shrike/commit/5a9ae26a3b73765f4666bc1055df60d5cddef133))
* enable compaction automatically by default ([aa55927](https://github.com/GrayCodeAI/shrike/commit/aa55927af043178ba7b4ec5deb049efc5aa9fca5))
* enhance CLI with powerful welcome and agent modes ([46feee7](https://github.com/GrayCodeAI/shrike/commit/46feee78e9b6c9d5bb20a68482e56890ab6dfcd1))
* enhance dotnet with 6 subcommand filters, add ansible/ansible-playbook/ansible-inventory ([68e9fb7](https://github.com/GrayCodeAI/shrike/commit/68e9fb78f317f3b8538c6f6f27b836794bdac4f1))
* enhance vitest and playwright test runners ([36d65c6](https://github.com/GrayCodeAI/shrike/commit/36d65c67b900751c6736ad23afafe33717a0540f))
* expand Docker, kubectl, AWS, npm, pnpm, pip, and go commands ([71aab9e](https://github.com/GrayCodeAI/shrike/commit/71aab9e7d2f36d8ae84de06440c95e69ba194159))
* **filter:** add layers 21-25 from COMI, DART, TokenSkip, SWE-Pruner, Perception Compressor ([be6d489](https://github.com/GrayCodeAI/shrike/commit/be6d4896b5ce6c2a5f3a3d084166a251c64bfb91))
* **filter:** add layers 26-30 from LightThinker, ThinkSwitcher, GMSA, CARL, SlimInfer ([4c8962a](https://github.com/GrayCodeAI/shrike/commit/4c8962aed785e0e6c5d60e32a986b2413054da3f))
* **filter:** implement baseline planned layers 30-49 ([ceae1c2](https://github.com/GrayCodeAI/shrike/commit/ceae1c2d220ab1f32c53bf4bd4dac7b048b979f1))
* **filter:** wire layer 17 as semantic cache within 20-layer core ([d22d813](https://github.com/GrayCodeAI/shrike/commit/d22d813f82dacdc2c02dc99b7d45795d0c458d0f))
* full screen black background TUI ([d32d349](https://github.com/GrayCodeAI/shrike/commit/d32d349a406f8b99da87d605ebe9ef6032055729))
* gh/vercel-inspired CLI with clean professional design ([3d8266e](https://github.com/GrayCodeAI/shrike/commit/3d8266e4a4aba1dc0c3fede267e932a3be8060b4))
* **git:** add global flags and missing subcommands (parity) ([5b47e4c](https://github.com/GrayCodeAI/shrike/commit/5b47e4c7611b4e1155409cf7d6c04c623031f08f))
* gray background for footer keys ([476e668](https://github.com/GrayCodeAI/shrike/commit/476e668d4132baea1b2bdb0f48f78c1fedfa7bcf))
* gray footer background ([4f925b7](https://github.com/GrayCodeAI/shrike/commit/4f925b7f4971e21af47472d48bef89f8a484c90e))
* implement 10-layer world-class token reduction pipeline ([70a72e0](https://github.com/GrayCodeAI/shrike/commit/70a72e011ab0691f8500dc0c2ffe51df1df54e73))
* implement 24 research-backed compression techniques (34 papers, 2023-2026) ([58ec3aa](https://github.com/GrayCodeAI/shrike/commit/58ec3aa0b7c861689dc79fa81511543f7bd8b502))
* implement 7 research-backed compression layers (Layers 15-20) ([cfe87ba](https://github.com/GrayCodeAI/shrike/commit/cfe87bab387fba456a02ff601571c4b77c9f1a93))
* implement all 22 missing compression features with 95% parity ([03cb0d9](https://github.com/GrayCodeAI/shrike/commit/03cb0d9a37f0f3237bfb093334ff9508b414cfa8))
* implement all competitive features from 10 repos (200 tasks complete) ([f6a54bd](https://github.com/GrayCodeAI/shrike/commit/f6a54bd23eb4b17fcb8f870bda85e43c6db93462))
* implement all phases 1-5 from TASK_PLAN_500.md ([a4aa7c6](https://github.com/GrayCodeAI/shrike/commit/a4aa7c66f58a81544eb918155d55189456b04e24))
* implement all Quick Wins - distribution, install script, Makefile, aliases ([c070829](https://github.com/GrayCodeAI/shrike/commit/c0708291923bb7547a0d33e175d174b74c8e8ba3))
* implement full compression feature parity ([21f4b49](https://github.com/GrayCodeAI/shrike/commit/21f4b49ebb51741738d909db98bba34edca0c574))
* implement guardrails and adaptive benchmark/ablation baselines ([b791be7](https://github.com/GrayCodeAI/shrike/commit/b791be7bddbc5e10efd8454bce6e8d8bc523000f))
* implement JSON/CSV export for economics command ([2204261](https://github.com/GrayCodeAI/shrike/commit/2204261937150bf4c71637e4c658084ac7341cf8))
* implement Lua script plugins and visual animation features ([bc2c3a0](https://github.com/GrayCodeAI/shrike/commit/bc2c3a0e41093dd8c1b530e3fe294fcee40e9bd1))
* implement microservice architecture ([e3a12d3](https://github.com/GrayCodeAI/shrike/commit/e3a12d3ff31705e746c6d6fe22289fa60723083a))
* implement persistent query cache for 56s → 1s speedup ([79aed45](https://github.com/GrayCodeAI/shrike/commit/79aed45c86bac61a4102b3e5705128144ff7c727))
* implement Phase 2 innovation features - MCP server, session recovery, marketplace, WASM plugins ([5c90030](https://github.com/GrayCodeAI/shrike/commit/5c900303330b4d82c7de5fdef85765b4556e2367))
* implement Phase 5-7 of compression migration (Ruby, AI integrations, Extended commands) ([7e257f8](https://github.com/GrayCodeAI/shrike/commit/7e257f8e371e7b28bd7e1a9b93fcdf9e02175f54))
* improve attention score simulation (T13) for heavy-hitter identification ([5d0b1f9](https://github.com/GrayCodeAI/shrike/commit/5d0b1f9b39b8bcf9f23b2080cb2d09a07edb554c))
* improve flag pass-through and compact output formatting ([000037f](https://github.com/GrayCodeAI/shrike/commit/000037f6ed6d8834d92376f86c1774d393019102))
* improve grep, tree, and prisma commands ([d18e411](https://github.com/GrayCodeAI/shrike/commit/d18e411be41a250f67c2a99cab11f40aa0942cba))
* improved status bar with better visuals ([9ea24f7](https://github.com/GrayCodeAI/shrike/commit/9ea24f7ff08cb6deaa201a5330a178d7455f9ba8))
* industry-standard shrike — merge shrike+tork, consolidate architecture, add output abstraction layer ([bfdb38c](https://github.com/GrayCodeAI/shrike/commit/bfdb38cf284c7617208352fefc7ad25cadc9fcaf))
* initial implementation of Shrike CLI ([d7427e6](https://github.com/GrayCodeAI/shrike/commit/d7427e66a9dd6a17a7b0dd38fc0e6151249cdae7))
* integrate all 10 token-clone projects into shrike ([c5ce2bc](https://github.com/GrayCodeAI/shrike/commit/c5ce2bc30bf159602246ac0f8d4f0100e3b6f45c))
* integrate runtime integrity checks for operational commands ([2dd5d7a](https://github.com/GrayCodeAI/shrike/commit/2dd5d7a8d59c4d350c856a49ae1cd4618d90ecd7))
* larger welcome text + remove border line ([6a3a957](https://github.com/GrayCodeAI/shrike/commit/6a3a9571b518f1c71906235ce2ab638a35d5a579))
* merge all shrike and tork features into unified shrike CLI ([cbe8970](https://github.com/GrayCodeAI/shrike/commit/cbe8970374bcd69fcab94c634521c829ffecc5ee))
* modern btop/lazygit-style TUI with boxed panels ([21e2caa](https://github.com/GrayCodeAI/shrike/commit/21e2caa33acfee37639b8d46ce874c8308822dd2))
* modern TUI with single accent color, solid colors, no gradients ([6ab4c62](https://github.com/GrayCodeAI/shrike/commit/6ab4c625d895fa4cd973527e9055b501feb0a399))
* optimize pipeline, add tests, and fix bugs ([c9637f2](https://github.com/GrayCodeAI/shrike/commit/c9637f27c52719761a3c3e40a6ca197027602f5a))
* performance benchmarks, code quality, and continued task execution ([ae1ba83](https://github.com/GrayCodeAI/shrike/commit/ae1ba83f534043d8f4ac1a8a4b9a25de5b7a63eb))
* Phase 2 - Delegating Hook System with Exit Code Protocol ([f6435d8](https://github.com/GrayCodeAI/shrike/commit/f6435d8bf6897d8921263bafec982c50c6652294))
* Phase 3 - Filter System Enhancements with inline tests and validation ([ffd4043](https://github.com/GrayCodeAI/shrike/commit/ffd404356a27b3bff6b6ee74543bd666a746138c))
* PI-style CLI with prominent input box ([fd041ec](https://github.com/GrayCodeAI/shrike/commit/fd041ec5d382d91b331f5d22c1476b81b1aa7fd0))
* port all shrike features to shrike ([7e7ce4a](https://github.com/GrayCodeAI/shrike/commit/7e7ce4a4a7f43b0bfb2f95d1119a9b153ee239bb))
* port Shrike enhancements to shrike ([560b530](https://github.com/GrayCodeAI/shrike/commit/560b530b6f94ad6501fee3cea375ce0fbed0000a))
* professional CLI based on OSS research ([110e5ad](https://github.com/GrayCodeAI/shrike/commit/110e5ad38435908ceb7884cb0a191ebf696e20c5))
* professional CLI with clean, modern interface ([1052fd0](https://github.com/GrayCodeAI/shrike/commit/1052fd0a28c6a22a4d373ed2b05cc9980fb335d8))
* professional TUI with 20+ solid colors ([eafebac](https://github.com/GrayCodeAI/shrike/commit/eafebac22267e3dfc391ebfde4fe39c9a920c2b0))
* prominent input box with &gt; prompt ([ca8e231](https://github.com/GrayCodeAI/shrike/commit/ca8e2313b5182b9ad901b4fa5ea40c3d9a428f3a))
* proper box drawing with corners like Claude Code ([7243ff6](https://github.com/GrayCodeAI/shrike/commit/7243ff6b0121a046c72e8708eaf66b5a9374b736))
* rebuild TUI with clean minimal htop/lazygit style design ([181a888](https://github.com/GrayCodeAI/shrike/commit/181a888831db9997689b7331f36f31a29fe276bd))
* rebuild TUI with modern MVU architecture and real-time updates ([b02be5c](https://github.com/GrayCodeAI/shrike/commit/b02be5c768552f27e4667e671cf3a4aa65daa741))
* rebuild TUI with OpenCode-style split-pane design ([d9e79ac](https://github.com/GrayCodeAI/shrike/commit/d9e79ac22ab65b9495ca9967d7d839d8d12f673f))
* refresh every 30 seconds ([61e8b87](https://github.com/GrayCodeAI/shrike/commit/61e8b875ad880b9e49bda1dcdb5fb1f7746f90ac))
* sidebar navigation with arrow keys ([986feb0](https://github.com/GrayCodeAI/shrike/commit/986feb08993154ba693c3849c4540d4a50602b91))
* task 11 - distributed stress testing support ([feb456b](https://github.com/GrayCodeAI/shrike/commit/feb456b762dec21a31f60650075413f591e74764))
* tasks 1-6 - benchmark enhancements (JSON, CSV, trends, charts, DSL) ([09bc6eb](https://github.com/GrayCodeAI/shrike/commit/09bc6ebbeb3f7e9c8b06ec258f8123cad9444943))
* tasks 101-120 - cost policy enforcement, cost center hierarchy, encryption at rest ([120d821](https://github.com/GrayCodeAI/shrike/commit/120d821ab8fd8455a65fe6c3c37393347930dc25))
* tasks 12-21 - custom scenarios, reports, scheduling, chaos experiments ([9c97ba2](https://github.com/GrayCodeAI/shrike/commit/9c97ba212da6db99c34a7ee63dd9e4a556c107ac))
* tasks 121-130 - data retention policies, anonymization, security scanning ([e8a8a60](https://github.com/GrayCodeAI/shrike/commit/e8a8a60016f97c21fdf3e14e5fb07c14e7cf773f))
* tasks 131-140 - CLI enhancements: shell completion, aliases, progress indicators, dry-run, batch ops ([f8c5cb1](https://github.com/GrayCodeAI/shrike/commit/f8c5cb1e7b0144a7516cf33117336713619aa198))
* tasks 141-200 - undo, history, favorites, scheduling, intelligent filtering, sentiment, autotuning, workload prediction ([78ac4df](https://github.com/GrayCodeAI/shrike/commit/78ac4df1046381f12e64fbcd65ea85487068b87a))
* tasks 22-40 - chaos experiments, test coverage for abtest, costforecast, budgetalerts, teamcosts ([82071de](https://github.com/GrayCodeAI/shrike/commit/82071ded87ef8fa6c0e9d1247613eabfae9fc0a2))
* tasks 41-50 - canary tests, CI/CD workflows, chaos testing, performance regression checks ([8633f98](https://github.com/GrayCodeAI/shrike/commit/8633f983ba13b7807c73fbb6315d7454ce15673f))
* tasks 41-50 - canary tests, CI/CD workflows, chaos testing, performance regression checks ([a9db19a](https://github.com/GrayCodeAI/shrike/commit/a9db19a7862acf5f7511ead17fe8f50d41176097))
* tasks 41-60 - canary, mcphost, iteragent tests + multi-platform build CI ([235873a](https://github.com/GrayCodeAI/shrike/commit/235873a323982b148089e26a583f906b07d4660d))
* tasks 61-70 - LLM provider integration and agent framework enhancements ([8eacb30](https://github.com/GrayCodeAI/shrike/commit/8eacb30b8f0f7cb6d05b7c323a36d83ab742dfe0))
* tasks 7-8 - parallel execution and regression detection ([f2ed1a0](https://github.com/GrayCodeAI/shrike/commit/f2ed1a0fca489dcad17add2fb97c185e9515951b))
* tasks 71-90 - cost intelligence dashboard, weekly digest, API endpoints, audit logging, RBAC ([1ea59b0](https://github.com/GrayCodeAI/shrike/commit/1ea59b0cb9ac5d40e5b7942adf326e880c327374))
* tasks 9-10 - CI/CD integration and SQLite storage for benchmarks ([760dd8b](https://github.com/GrayCodeAI/shrike/commit/760dd8bd3f048e579682cc7fa533247171ed9304))
* tasks 91-100 - cost anomaly detection, multi-currency, chargeback automation ([efe42e1](https://github.com/GrayCodeAI/shrike/commit/efe42e1b3687db472a14828e849143825fd18de2))
* unify 51 layers into 20 with consolidated filters ([ffabd08](https://github.com/GrayCodeAI/shrike/commit/ffabd081b27c7697af9c6efe83525f25ddadb08f))
* unique colors for footer keys + clearer timestamp label ([83bed6d](https://github.com/GrayCodeAI/shrike/commit/83bed6d9f8e39aa9c60dfe6ba99c88f4ff7e0ff3))
* update compaction defaults for 1M-2M context ([92cf3c6](https://github.com/GrayCodeAI/shrike/commit/92cf3c63334aab8c2fed94ae6fcf57be0cc5e8d3))
* update hooks to delegating pattern + homebrew tap structure ([afc31c6](https://github.com/GrayCodeAI/shrike/commit/afc31c6187d2a4f1c5baae81b2ce17bbea167885))
* v0.9.0 - Research-based compression with shrike parity ([13254ff](https://github.com/GrayCodeAI/shrike/commit/13254ffab89e5e7eb651cc480bad28fe85c0d104))
* vibrant high-contrast TUI with all features ([fa5d2b4](https://github.com/GrayCodeAI/shrike/commit/fa5d2b4f05432d06b15e978bb4c5e9539a286626))
* wire adaptive routing config and benchmark profile ([dbd5b63](https://github.com/GrayCodeAI/shrike/commit/dbd5b63ff2ddcf197dbcc8e67b34fb1227636a58))
* world-class TUI dashboard with comprehensive features ([d2bc49f](https://github.com/GrayCodeAI/shrike/commit/d2bc49f718722ced4cd9342afef2bd0f99e128f6))
* world-class TUI with purpose-driven colors ([cc0eade](https://github.com/GrayCodeAI/shrike/commit/cc0eadea0dc0e85971e32e0382b5c103ac76e092))


### Bug Fixes

* address code review findings across filter/cache/toml ([1de474b](https://github.com/GrayCodeAI/shrike/commit/1de474b71a4204b17489d866fa77e191de1aa6ee))
* align README claims with implementation accuracy ([59a3c35](https://github.com/GrayCodeAI/shrike/commit/59a3c358417cf643e167a692e5d86b82400cea17))
* all text styles have black background ([31e1aaa](https://github.com/GrayCodeAI/shrike/commit/31e1aaa6a43a98748138ac5fd983ffa2fd7a1fa5))
* apply remaining changes from code review session ([9343a12](https://github.com/GrayCodeAI/shrike/commit/9343a12bf46fe6d4a19c5ee1a889247888a24aef))
* black background for all footer keys ([a3cc53d](https://github.com/GrayCodeAI/shrike/commit/a3cc53da817fd5f8daaf15ad005b56856cd0dc73))
* clean up filter tests for consistent validation ([1706f3b](https://github.com/GrayCodeAI/shrike/commit/1706f3bf5724bbb9466aecb3012d2ed4d50f71b0))
* clear remaining staticcheck + go mod tidy findings ([48f5aa9](https://github.com/GrayCodeAI/shrike/commit/48f5aa9fe2f8eec9d693dec2ee7d3cc704cbd857))
* commit six_layer_pipeline.go (was untracked, breaking CI) ([8e9fb06](https://github.com/GrayCodeAI/shrike/commit/8e9fb06b71e693260ef351e026a4cb21b84e244a))
* **compaction:** fix tests and improve compaction logic ([9e201e6](https://github.com/GrayCodeAI/shrike/commit/9e201e61a0e1c41c5e98c4daedda1c9d4c4be109))
* convert verbose flag from bool to count-based int ([ff9dcc5](https://github.com/GrayCodeAI/shrike/commit/ff9dcc5fa45d56aa4579d74d9cd47f73096d65ec))
* correct unit tests for new compression layers (L15-L19) ([497de4c](https://github.com/GrayCodeAI/shrike/commit/497de4cf284fa4ef6b2f21d3c02e91b8008f8bd3))
* deep code review — 13 bugs, security issues, and build failures ([1c281d1](https://github.com/GrayCodeAI/shrike/commit/1c281d113eb271aba18187ac1cc72d8787a6ff3c))
* disable flag parsing for git add to support -A, -u flags ([18f5029](https://github.com/GrayCodeAI/shrike/commit/18f5029b775da2158c65c4f098125dd43bac9550))
* disable flag parsing for git commit and push to support all flags ([6fcda6a](https://github.com/GrayCodeAI/shrike/commit/6fcda6a4a6eadd748c3ea83f8813b7efd2d3bd1a))
* eliminate all gray areas, pure black everywhere ([ba23639](https://github.com/GrayCodeAI/shrike/commit/ba23639749a115a23108801d2944dcb161274792))
* eliminate gray gaps in footer ([feddd53](https://github.com/GrayCodeAI/shrike/commit/feddd53801758dd2b40087346d2a327355a366ab))
* enable flag pass-through for aws and psql commands ([7cda4fd](https://github.com/GrayCodeAI/shrike/commit/7cda4fd98811f326781473879fa2214a39ff7197))
* enable flag pass-through for tree command ([c8a1076](https://github.com/GrayCodeAI/shrike/commit/c8a10764f4b8e2ed26b557ae5c6d1618f20a05c7))
* fix rewrite command tests - use E2E subprocess testing ([23c9b31](https://github.com/GrayCodeAI/shrike/commit/23c9b316fbb58f1f06f4c4178c07d63e461eaca4))
* footer pure black background ([5d49739](https://github.com/GrayCodeAI/shrike/commit/5d49739ff153ffb87f0ba4adecf0a13f227b03c2))
* git add supports -A and --all flags by default ([d61ab8c](https://github.com/GrayCodeAI/shrike/commit/d61ab8c0153ac6cb52413906d297d4a5513b3eb1))
* **git:** enable TraverseChildren for global flags before subcommand ([8c99e30](https://github.com/GrayCodeAI/shrike/commit/8c99e305c01177ae70ac82bc2142671d1815dba7))
* handle short strings in analyze test preview ([6801134](https://github.com/GrayCodeAI/shrike/commit/68011349622e3f15a4e121ee3ee6258383573cf1))
* improve error handling and remove emojis ([bd3924b](https://github.com/GrayCodeAI/shrike/commit/bd3924bab7718dbc1d45028d371911d9644ceb66))
* prevent over-pruning on small inputs in compression layers ([ea25908](https://github.com/GrayCodeAI/shrike/commit/ea259085b8122489e1c5d89ac1146555cb906526))
* proper spacing in footer keys ([626ccd3](https://github.com/GrayCodeAI/shrike/commit/626ccd3026930caf4f1cb1d97fadb82f649f0a1b))
* proper TOML escaping for all 100 inline filter tests ([35ae549](https://github.com/GrayCodeAI/shrike/commit/35ae549e6a1f555bb05318c2f9aabc95281addd2))
* proxy command --help handling ([9d2a99b](https://github.com/GrayCodeAI/shrike/commit/9d2a99b39035815c9081e9725494453b52697d6f))
* pure black background everywhere ([a1bf186](https://github.com/GrayCodeAI/shrike/commit/a1bf18665359d20f93fa74539d716684e4887a16))
* quality improvements - error handling, JSON modes, import order ([470bdc7](https://github.com/GrayCodeAI/shrike/commit/470bdc77cd6cf4c5278ce071607bf347201ce9e6))
* re-apply docker.go S1039 + add staticcheck.conf ([12379d6](https://github.com/GrayCodeAI/shrike/commit/12379d6631ba8e460d2fdced457d11b6c2ba0e22))
* register new command packages (tui, ai, sandbox, skills, api) in root.go ([760a0ba](https://github.com/GrayCodeAI/shrike/commit/760a0ba801c2eaddc0ed2fbe1d94874c8a29642d))
* remove all remaining gray backgrounds ([5f0037a](https://github.com/GrayCodeAI/shrike/commit/5f0037ab58bc2c7707ea1526552bac150c94d426))
* remove conflicting -q shorthand from audit command ([e819535](https://github.com/GrayCodeAI/shrike/commit/e8195357ffdd1c882ac36709b23a8ea13f6812ac))
* remove double boxes, single clean layout ([95d1851](https://github.com/GrayCodeAI/shrike/commit/95d18513df9ddb5524929475848f25002d4a5eb3))
* remove unused imports in TUI dashboard ([706bb13](https://github.com/GrayCodeAI/shrike/commit/706bb135c1e7685cc574ecee1ed45d8e54b69537))
* resolve 17 code quality issues ([f2bc16a](https://github.com/GrayCodeAI/shrike/commit/f2bc16a121938248f6a9b62112d2a2bf428b6146))
* resolve 27 security, resource leak, and error handling issues ([4287908](https://github.com/GrayCodeAI/shrike/commit/428790877de192d6909178bc507aaf817b2e5cda))
* resolve all critical issues from comprehensive code review ([3e3125d](https://github.com/GrayCodeAI/shrike/commit/3e3125d4009b592dd498ec8a80edd0e95a422793))
* resolve all issues and achieve A+ code quality ([be1f287](https://github.com/GrayCodeAI/shrike/commit/be1f287bf6636fdb825037493e24c3095c23402f))
* resolve build failures - unused imports, context leak, team ID collision ([d9f47df](https://github.com/GrayCodeAI/shrike/commit/d9f47df4e80fb02b7eba8a51498325038de30486))
* resolve compilation errors and reorganize command structure ([cf0a627](https://github.com/GrayCodeAI/shrike/commit/cf0a62748634696e34acfa6c4ed875fabbd359ff))
* resolve compilation errors in filter package ([64b0b78](https://github.com/GrayCodeAI/shrike/commit/64b0b78f658bab6f3b95f9d43c4794843c5a40ad))
* resolve critical test failures and add missing implementations ([a5525e3](https://github.com/GrayCodeAI/shrike/commit/a5525e3a201d13dce92e16aca11d54edfa3af0ea))
* resolve duplicate command registrations ([0c56c39](https://github.com/GrayCodeAI/shrike/commit/0c56c397d2be560e2e81d7f7619cca8f67ea9c45))
* resolve i18n embed path, all tests passing now ([26951f2](https://github.com/GrayCodeAI/shrike/commit/26951f27becd207e9da5a6c8c3f00eff4d916fea))
* resolve integration test issues ([c043bd8](https://github.com/GrayCodeAI/shrike/commit/c043bd8ae00addcfa7408e9b835cd908db7555ad))
* resolve ProcessResult redeclaration, add parallel processor, SIMD optimizations, bytepool ([0e63033](https://github.com/GrayCodeAI/shrike/commit/0e6303356daeffa8d432b50063e336e411454947))
* resolve race conditions, null derefs, and code quality issues across 19 files ([da38fee](https://github.com/GrayCodeAI/shrike/commit/da38fee1fc0e0e8a28073f8bda624984e3fcf56c))
* resolve remaining CI failures ([14c9976](https://github.com/GrayCodeAI/shrike/commit/14c9976148cd0058dcd905ea8ea555f6d4a1032f))
* resolve syntax errors and build issues ([ba3409e](https://github.com/GrayCodeAI/shrike/commit/ba3409e35c38a1f10107167ecb7cda751f810b3a))
* resolve unicode test failures, all tests passing ([1d13ec1](https://github.com/GrayCodeAI/shrike/commit/1d13ec1f4bbd0a30675f3578415bf00ef0d6fbbd))
* satisfy staticcheck + unblock golangci-lint ([3e054db](https://github.com/GrayCodeAI/shrike/commit/3e054dbf2e5a774d5f3b6fb21fae220e8b98e809))
* security and stability improvements ([76f7271](https://github.com/GrayCodeAI/shrike/commit/76f7271e504662af13badd64705a7cbde9e71233))
* welcome text black background ([108f81b](https://github.com/GrayCodeAI/shrike/commit/108f81b2d18f75ff4124d6e2933e074f6b932b91))


### Performance

* **filter:** deduplicate overlapping planned layer execution ([19b1c4e](https://github.com/GrayCodeAI/shrike/commit/19b1c4e997b8da5c0657111df860e7a8e2fc0345))
* optimize H2O filter memory for large contexts ([c9cd268](https://github.com/GrayCodeAI/shrike/commit/c9cd26879d10be33d5e1a03351571e166c3639c3))
* streaming memory optimization for large contexts ([0e216ae](https://github.com/GrayCodeAI/shrike/commit/0e216ae3c793e5f2caa6ecd43efe80fcb81aabb0))


### Refactoring

* add Pipeline interface, clean codebase ([d5e537f](https://github.com/GrayCodeAI/shrike/commit/d5e537f82218f934287c9c749dda319065bd4dbe))
* clean up code and improve naming ([d6f4be7](https://github.com/GrayCodeAI/shrike/commit/d6f4be75282237a6a7b9de14b4c3980701bf46c1))
* consolidate duplicates, fix rate limiter, remove dead code ([8fd87cf](https://github.com/GrayCodeAI/shrike/commit/8fd87cf787e7c7a075aeab1164f2ee1ed5baa6d9))
* consolidate filter packages and update codebase ([e417fdd](https://github.com/GrayCodeAI/shrike/commit/e417fdd8376b24c768070c94eb5cbd2b3ee95c74))
* consolidate layers to achieve 51-layer architecture ([a75a2bc](https://github.com/GrayCodeAI/shrike/commit/a75a2bc0a8bab4bdfce96085a553c0f81ed7aadb))
* extract shared HTTP middleware to httpmw package ([c82edd0](https://github.com/GrayCodeAI/shrike/commit/c82edd0736711bee3b42920eee7f6fbbddb36870))
* **filter:** enforce practical 20-layer runtime core ([eb7f964](https://github.com/GrayCodeAI/shrike/commit/eb7f9648442e1c61ebc3116b7ed419cd9228e4d7))
* **filter:** keep only curated experimental layers and merge redundant ones ([1c23bb6](https://github.com/GrayCodeAI/shrike/commit/1c23bb6acd3d01b382d95a60bbeb586a1f2c639b))
* fix proxy error handling, remove dead code, clean codebase ([5266cb3](https://github.com/GrayCodeAI/shrike/commit/5266cb3d1ce863dcb4eb5f2bf5e8a249b0b6f3ab))
* improve code quality and add tests ([c1e849e](https://github.com/GrayCodeAI/shrike/commit/c1e849ec9f6e1db3e8c74191ee021ea1db5c7079))
* introduce AppState struct to eliminate global state pattern ([6f21ae6](https://github.com/GrayCodeAI/shrike/commit/6f21ae6374f5faee415851f983dfae704e62d7b0))
* merge plugin/plugins, fix status/gain, add tests ([4f4182a](https://github.com/GrayCodeAI/shrike/commit/4f4182a3d7dec611d41519ecbe2b49d5545f0744))
* organize code following Go industry standards ([0b7b359](https://github.com/GrayCodeAI/shrike/commit/0b7b359274f3c6edc3f6c386d7615489110ac4ea))
* remove 33 dead code files across 16 unused packages ([9c64633](https://github.com/GrayCodeAI/shrike/commit/9c646331ac5a6a1991ea505fb1d7137b7edbef72))
* remove all external tool references from code ([7a81c09](https://github.com/GrayCodeAI/shrike/commit/7a81c09d5a1492f1903c4b695af7ec4317f41d45))
* remove dead code and cleanup codebase ([ea34956](https://github.com/GrayCodeAI/shrike/commit/ea34956c14671a132c7a5862876cf3d978ae23f6))
* remove orphan internal packages and unused bfcl cmd ([d4a5eb0](https://github.com/GrayCodeAI/shrike/commit/d4a5eb0928c7bd0e4b0e48801cf8a40d663f08f1))
* remove task IDs from code comments ([47284fa](https://github.com/GrayCodeAI/shrike/commit/47284fa50a0b7fb08477cca05c950d2da9a194ad))
* remove unused internal agent/hook/quality/tokenizer/undo packages ([2a91f70](https://github.com/GrayCodeAI/shrike/commit/2a91f708d4522235d2da31955844bc6f6a755523))
* rename 56 files to meaningful descriptive names ([09381f3](https://github.com/GrayCodeAI/shrike/commit/09381f3c48c5eb14a3327e69a604efb06144bb90))
* rename tfidf stage label to pre_tfidf ([9e5bf81](https://github.com/GrayCodeAI/shrike/commit/9e5bf8117f6d62d0f4ce436c5cfae455a4a6b9b8))
* rename ShrikeStatus/ShrikeRule to ShrikeStatus/ShrikeRule ([b49d3cd](https://github.com/GrayCodeAI/shrike/commit/b49d3cd0f000349196ec2c4427d2cfb351e05eaf))
* renumber late pipeline layer IDs to 20-29 ([8435f32](https://github.com/GrayCodeAI/shrike/commit/8435f3296364013615855d7b1fd066c690206b2a))
* replace all Shrike references with Shrike ([3427f61](https://github.com/GrayCodeAI/shrike/commit/3427f61c1e82bd8789fa988819cfcc25325e8bba))
* simplify welcome screen and status bar ([e87569d](https://github.com/GrayCodeAI/shrike/commit/e87569d2cc732fde264fa75fd45f462c90817041))
* split god files into focused files and extract embedded HTML ([99881c3](https://github.com/GrayCodeAI/shrike/commit/99881c39120926848992a6ef92b10ed8d8fe7d07))
* unexport internal functions, add interfaces ([f77e04a](https://github.com/GrayCodeAI/shrike/commit/f77e04a56d62d6002138f18aa07a17482cdedab8))
* update module path to GrayCodeAI org ([9d382ba](https://github.com/GrayCodeAI/shrike/commit/9d382ba17801fa69dffae9ce8bfa7b7165fa7baa))


### Tests

* add 6 more inline tests (kotlinc, jest, vitest, npm, cargo) ([e8eb477](https://github.com/GrayCodeAI/shrike/commit/e8eb4772dc4984720b8ea821e945769b7ab66a43))
* add 8 more inline tests (gradle, mvn, mix, make) ([8100c5d](https://github.com/GrayCodeAI/shrike/commit/8100c5de4407e66cd92ae7b73a1d4e06a72140e2))
* add comprehensive test coverage (filter, core, commands, tracking) ([52882c0](https://github.com/GrayCodeAI/shrike/commit/52882c0d9606d58cc99740315768cd797863f226))
* add inline tests to 3 more filters (pip-install, tsc, ls) ([b44b864](https://github.com/GrayCodeAI/shrike/commit/b44b864312fc9a78a03be74ef427940d38cc9371))
* add inline tests to 4 more critical filter files ([fcf9772](https://github.com/GrayCodeAI/shrike/commit/fcf9772cc6826b5e3744f7a928c04b5e8f92ebc3))
* add inline tests to 4 more system command filters (grep, find, tree, df) ([c4a1964](https://github.com/GrayCodeAI/shrike/commit/c4a196444be5778ab0113fbe82efa56528719de8))
* add inline tests to docker.toml and go.toml ([db8f85e](https://github.com/GrayCodeAI/shrike/commit/db8f85ef4ff824dd733c9864b6599520c631cb1c))
* add inline tests to jest.toml and vitest.toml ([7f18c1d](https://github.com/GrayCodeAI/shrike/commit/7f18c1d65357286df5ac48ab19b0a314ed877d0d))
* add inline tests to npm, aws, kubectl-get, trivy filters ([3f23dbc](https://github.com/GrayCodeAI/shrike/commit/3f23dbcec158cdea20f1f21669f6119de85ce876))
* add inline tests to pip, curl, rustc, basedpyright ([5f52944](https://github.com/GrayCodeAI/shrike/commit/5f52944549f930a25df4bdecca591f785a8ef8a9))
* add inline tests to playwright.toml and trivy.toml ([6ae3e71](https://github.com/GrayCodeAI/shrike/commit/6ae3e7155ad20c683e5c190e10fd7799a3a2fed8))
* add inline tests to pnpm and du filters ([1b89852](https://github.com/GrayCodeAI/shrike/commit/1b8985234b5e45f6b9e12edb65460bf18f795f5d))
* add inline tests to rg, fd, brew-install filters ([d08718c](https://github.com/GrayCodeAI/shrike/commit/d08718c43d7a9fde3a3e953f6a9760bcc520596f))
* add inline tests to ruff.toml (Python linting) ([876f764](https://github.com/GrayCodeAI/shrike/commit/876f764e6df2d1a9e1d26651ea2208c459e303ae))
* add inline tests to terraform-apply.toml ([266d189](https://github.com/GrayCodeAI/shrike/commit/266d189cffa9fd5da6982f81b4b83288c7e4bbfe))
* add inline tests to terraform-init.toml ([fc1c588](https://github.com/GrayCodeAI/shrike/commit/fc1c588606dd27468554bd479081336d5b4bfca4))
* add inline tests to webpack, helm, ansible-playbook, gcc ([c365e16](https://github.com/GrayCodeAI/shrike/commit/c365e168475ec4285a1637c642bd21a2fa0e6943))
* add inline tests to yarn, bundle-install, kubectl-logs ([bdcb727](https://github.com/GrayCodeAI/shrike/commit/bdcb72757179ffc9430eb7a10308ae9df8e346a6))
* add integration test suite for 20-layer pipeline ([ffc6e6b](https://github.com/GrayCodeAI/shrike/commit/ffc6e6b13fb3087dcad739bc9f12cfbec58441b9))
* add integration tests for new commands ([f3f4269](https://github.com/GrayCodeAI/shrike/commit/f3f42696878477eddacad49f935fd6ca19fa8e59))
* **ci:** harden audit stability with regression fixtures and migration compatibility checks ([63314ad](https://github.com/GrayCodeAI/shrike/commit/63314ad03b912118f99ee85f5355125c1742f6ce))
* **commands:** add root registration guard and refresh layer docs ([34d5232](https://github.com/GrayCodeAI/shrike/commit/34d523272ffb482a75abbcff45d3dee880951022))
* comprehensive utils package coverage ([382a67b](https://github.com/GrayCodeAI/shrike/commit/382a67bc545c737aa72afb01b07fb7ddcca96e2b))
* cover wenyan + commit-msg + review-diff ([7a84c22](https://github.com/GrayCodeAI/shrike/commit/7a84c22bb152c6d52e7fcce8d228931b5362d878))
* expand core package test coverage ([e82d53c](https://github.com/GrayCodeAI/shrike/commit/e82d53cdd925a854b27dcad17b00962680207e1c))
* fix slack token pattern to avoid secret scanning false positive ([488e2b8](https://github.com/GrayCodeAI/shrike/commit/488e2b865c6717b2c30375aff26154d60eb95080))
* reach 100 inline tests milestone! (+2 in wc, watch) ([bd1bb53](https://github.com/GrayCodeAI/shrike/commit/bd1bb532f783ec2894ded62b5f28c2de4387c63e))


### Documentation

* acknowledge 15+ real OSS token reduction competitors ([a06a516](https://github.com/GrayCodeAI/shrike/commit/a06a5163fa9cc3ca422f140e00b16654ce8b3893))
* add CHANGELOG and update README for v1.1.0 release ([4a506c3](https://github.com/GrayCodeAI/shrike/commit/4a506c37998f9929c4b744b9c0ad03bc8fc50f77))
* add CHANGELOG for v2.0.0 - SIMD and 20-layer release ([38da3ed](https://github.com/GrayCodeAI/shrike/commit/38da3ed5ec1501c52b71830907222ea633042bb0))
* add CHANGELOG for v2.1.0 - MCP server, proxy mode, T12/T17/T35 ([c9f0c4a](https://github.com/GrayCodeAI/shrike/commit/c9f0c4adf4443f089da770c01ccc8b8cfedfd4dd))
* add competitor comparison table, improve README structure ([5f149af](https://github.com/GrayCodeAI/shrike/commit/5f149aff129fe9c88e5647cd1d6f2177672d9d8f))
* add comprehensive ARCHITECTURE.md ([d132793](https://github.com/GrayCodeAI/shrike/commit/d132793326dbf3f3c77c5c32a44a70cd4cedfb55))
* add comprehensive benchmark dashboard ([d7c6e0b](https://github.com/GrayCodeAI/shrike/commit/d7c6e0baa3b746ef4e4500f53d9d8e20be782ec9))
* add comprehensive comparison with top 20 competitors ([43ce8f1](https://github.com/GrayCodeAI/shrike/commit/43ce8f1837987f1ff5275e9fb44bc94fe9bc71e8))
* add comprehensive completion report for Quick Wins ([e68b2f9](https://github.com/GrayCodeAI/shrike/commit/e68b2f94fc48a60a475f76a3bc06429f75782d95))
* add comprehensive documentation site ([11e835b](https://github.com/GrayCodeAI/shrike/commit/11e835bf4e83c70eac5c199b7c9faef23e193355))
* add comprehensive feature checklist ([fb81094](https://github.com/GrayCodeAI/shrike/commit/fb81094ab4a3fd7c3acf6a991f800c657bf11886))
* add comprehensive usage guide for competitive features ([841b8d9](https://github.com/GrayCodeAI/shrike/commit/841b8d9bf3f7c33a800edbe8f02d596852e3f5a1))
* add detailed feature-by-feature comparison table for top 20 competitors ([ff1dc07](https://github.com/GrayCodeAI/shrike/commit/ff1dc07ed646b71ba4f33b57425342760ba2a308))
* add Discord badge and link ([be96259](https://github.com/GrayCodeAI/shrike/commit/be9625962e066711fe0be19596ae4a86650560dc))
* add LAYERS.md documentation for Layers 15-20 ([d5e1562](https://github.com/GrayCodeAI/shrike/commit/d5e1562da0c8748087bfe7678d547c8185915651))
* add live demo examples to README ([a3c3296](https://github.com/GrayCodeAI/shrike/commit/a3c32966761a6551ebebb7ad07b71db3bef4ed5a))
* add Phase 2 completion report ([9567389](https://github.com/GrayCodeAI/shrike/commit/9567389997568b9adde41fc935e9c438e4f2125b))
* add Phase 9 testing and documentation ([badea13](https://github.com/GrayCodeAI/shrike/commit/badea13310aad1f320bfe43f2362507b3efd54a2))
* add progress report in Chinese ([902e12c](https://github.com/GrayCodeAI/shrike/commit/902e12c43a387c50ac970b8fa18cc341f6576788))
* add README translations (Chinese, Japanese) ([373ed5b](https://github.com/GrayCodeAI/shrike/commit/373ed5be122fec5d03c23be92a8cc6f31a3baf1d))
* add v1.2.0 changelog for 14-layer pipeline ([bd1981a](https://github.com/GrayCodeAI/shrike/commit/bd1981aef0c88b2f0d5bc2cacb58ae533ba0b545))
* clarify what shrike actually does — honest token savings breakdown ([48f726d](https://github.com/GrayCodeAI/shrike/commit/48f726de63346da6a38b323f3aaaa49a83cd60d2))
* complete Phase 8 of compression migration plan ([2acc505](https://github.com/GrayCodeAI/shrike/commit/2acc505a647d72b2dfc3348799bfffed73f18cb1))
* complete README translations for all 7 languages ([98ec19e](https://github.com/GrayCodeAI/shrike/commit/98ec19e2ca629ec5ffb77b5b8d2e957970be3ad3))
* comprehensive documentation update for v0.1.0 release ([5945d38](https://github.com/GrayCodeAI/shrike/commit/5945d3896c585b7b0fed12385c051f3d7635fe81))
* comprehensive implementation plan from competitor analysis ([8b324c9](https://github.com/GrayCodeAI/shrike/commit/8b324c930984aa0b84e21acdcfd6bc824b236cf6))
* comprehensive OSS competitor research (honest, in-progress) ([f6ca6bb](https://github.com/GrayCodeAI/shrike/commit/f6ca6bbcfe80b2bc7d8a7ad93aaee9284c09e917))
* consolidate 51 layers to 20 essential layers ([1889f3c](https://github.com/GrayCodeAI/shrike/commit/1889f3c2308475af4cc60a48390fa83a061370a7))
* correct research paper count to 30+ ([70b2052](https://github.com/GrayCodeAI/shrike/commit/70b20529e4677a75886dfb58b9ce3be07d700a61))
* create framework for deep competitor analysis ([05f913e](https://github.com/GrayCodeAI/shrike/commit/05f913e5c107f34761db6e67dcb600180f16b13b))
* deep check functionalities in shrike ([9eae3bb](https://github.com/GrayCodeAI/shrike/commit/9eae3bbc55e60370b66d529e4c9342855c7f1ed5))
* **filter:** align project to strict practical 20-layer core ([251dcf2](https://github.com/GrayCodeAI/shrike/commit/251dcf2fddf29213ce0f4b2ed06e965f620a6c09))
* fix layer count to actual 31 layers, add all layers to table ([24b313d](https://github.com/GrayCodeAI/shrike/commit/24b313db104d43f1e31733caa274afe2b7cb4cd5))
* fix README discrepancies - correct dashboard command and SIMD status ([d13d857](https://github.com/GrayCodeAI/shrike/commit/d13d857a147ae77d3b23444faa8910b7008ec4e3))
* harmonize layer architecture and naming across guides ([c01711f](https://github.com/GrayCodeAI/shrike/commit/c01711fa633940e22eefc74e950a5028b401f3de))
* honest analysis of real competitors vs adjacent tools ([e7b91c5](https://github.com/GrayCodeAI/shrike/commit/e7b91c5fcfdec1c13a1a9f264c7a649f75ff45ed))
* modernize documentation and remove unnecessary files ([7df0532](https://github.com/GrayCodeAI/shrike/commit/7df0532c3ee8fdba5d835a1f27e2ce23be4862b1))
* modernize README, CONTRIBUTING, SECURITY, CHANGELOG, AUTHORS ([f36fbac](https://github.com/GrayCodeAI/shrike/commit/f36fbac233ec50919f62554a8c654b0673f5b47c))
* overhaul README with competitor analysis, token savings table, research links ([8e5476c](https://github.com/GrayCodeAI/shrike/commit/8e5476c52e654e82ee344592ebca8bbc7d5145a5))
* redesign README with cleaner layout, real examples, and better visual hierarchy ([dc85029](https://github.com/GrayCodeAI/shrike/commit/dc850294892bdf1b1da0393ea10d1d4876987384))
* remove 10 stale files (CLAW_*, PRE_TUI_*, DASHBOARD_*, TUI_*) ([9c31cfd](https://github.com/GrayCodeAI/shrike/commit/9c31cfdbdd475af979c530bb29e36f8414f4f6c6))
* remove references from README ([74edaaa](https://github.com/GrayCodeAI/shrike/commit/74edaaaf629f83fd52a51b86635d1cab0d7288f6))
* start research on real OSS token reduction competitors ([6fc1ea6](https://github.com/GrayCodeAI/shrike/commit/6fc1ea6eb0f38a18ad523df8eb985e33305fff09))
* update AGENTS.md files to reflect renamed files ([b0a9e0a](https://github.com/GrayCodeAI/shrike/commit/b0a9e0a0e79ed67c87037d1515ef93d06dbbff0e))
* update clone URL to GrayCodeAI org ([017bb4f](https://github.com/GrayCodeAI/shrike/commit/017bb4f567ef58dc6ff50661b47a9dd438b5f05c))
* update LAYERS.md for 14-layer architecture ([84d3859](https://github.com/GrayCodeAI/shrike/commit/84d3859d02931b6d95dd67a407fb0ea6159c6a04))
* update README for 14-layer compression pipeline ([5786925](https://github.com/GrayCodeAI/shrike/commit/578692521264969ffa2e72304ce23b5930611f68))
* update README for 20-layer pipeline architecture ([29929a1](https://github.com/GrayCodeAI/shrike/commit/29929a14b84ae68e187f4c6d2ec04e6a23bebf36))
* update README with 40+ enterprise packages and v1.5.0 changelog ([cd8611d](https://github.com/GrayCodeAI/shrike/commit/cd8611dffe93c743fb14df735fec2598cd74933f))
* update README with all new commands and features ([81481bd](https://github.com/GrayCodeAI/shrike/commit/81481bdf33c5ddf01cccf1cadfc44de16d30062c))
* update compression migration plan to reflect actual 87% completion ([28bb224](https://github.com/GrayCodeAI/shrike/commit/28bb22422b94aa6f5e3b66bcee5646d129f2614e))

## [0.29.0] - 2025-04-19

> **Historical note.** Several entries below were written while shrike was being
> prototyped alongside an experimental command-line front end. shrike ships today as
> a **Go library** (`github.com/GrayCodeAI/shrike`) plus an optional HTTP server
> (`tokd`, in `./server`). It does **not** install a standalone `shrike` CLI, shell
> hooks, agent rule files, or a TUI. The CLI verbs some users remember
> (`shrike compress`, `shrike estimate`, ...) are provided by **Hawk**
> (`github.com/GrayCodeAI/hawk`), which embeds this library. The library-facing
> features listed here — the compression pipeline, token tracking, and TOML
> filters — remain real and are reachable through the Go API.

### Added
- Unified the input-compression and output-filtering work into a single Go
  package importable as `github.com/GrayCodeAI/shrike`
- 31-layer compression pipeline with research-backed algorithms, driven via
  `shrike.Compress(text, opts...)`
- SQLite-based token usage tracking via `shrike.NewTracker(ctx)`
- TOML-based declarative filter rules, loaded with `shrike.LoadFilterRules` and
  applied with `shrike.WithCustomFilters`
- Optional HTTP server `tokd` (`./server`) exposing `POST /compress`,
  `POST /estimate`, and `GET /health`

### Changed
- Module path settled on `github.com/GrayCodeAI/shrike`
- Tracker/filter state stored under `~/.shrike/`

[Unreleased]: https://github.com/GrayCodeAI/shrike/compare/v1.1.0...HEAD
[0.29.0]: https://github.com/GrayCodeAI/shrike/releases/tag/v0.29.0
