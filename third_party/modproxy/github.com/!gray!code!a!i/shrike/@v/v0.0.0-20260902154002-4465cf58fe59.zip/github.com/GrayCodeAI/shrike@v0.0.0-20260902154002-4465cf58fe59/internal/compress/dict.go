package compress

// engV1Dictionary is the "eng/v1" phrase-substitution dictionary.
// Source: skills/prompt-compression/SKILL.md, "Dictionary" section.
//
// Keys are case-insensitive verbose phrases. Values are terse equivalents.
// Multi-word keys are matched as whole phrases (whitespace-normalized).
// Substitutions are applied longest-match-first to avoid partial replacements
// (e.g. "as a result of" must be replaced before "as a" if both were present).
var engV1Dictionary = map[string]string{
	// Conjunction substitutions
	"in order to":                 "to",
	"in order for":                "for",
	"in order that":               "so",
	"due to the fact that":        "because",
	"owing to the fact that":      "because",
	"on account of the fact that": "because",
	"as a result of":              "because of",
	"as a consequence of":         "because of",
	"in spite of the fact that":   "despite",
	"in spite of":                 "despite",
	"despite the fact that":       "although",
	"in light of the fact that":   "since",
	"in view of the fact that":    "since",
	"for the reason that":         "because",
	"for the purpose of":          "to",
	"with the aim of":             "to",
	"with the goal of":            "to",
	"with the intention of":       "to",
	"with a view to":              "to",
	"in the event that":           "if",
	"in the case of":              "if",
	"in case of":                  "if",
	"on the condition that":       "if",
	"provided that":               "if",
	"assuming that":               "if",
	"given that":                  "if",
	"with regard to":              "about",
	"with regards to":             "about",
	"with respect to":             "about",
	"in regards to":               "about",
	"in regard to":                "about",
	"in respect of":               "about",
	"concerning the matter of":    "about",
	"pertaining to":               "about",
	"with reference to":           "about",
	"in reference to":             "about",
	"with respect to the":         "about the",
	"with regard to the":          "about the",

	// Quantity / amount
	"a number of":              "some",
	"a large number of":        "many",
	"a small number of":        "few",
	"a great number of":        "many",
	"a wide variety of":        "many",
	"a wide range of":          "many",
	"a variety of":             "various",
	"the majority of":          "most",
	"the minority of":          "few",
	"the vast majority of":     "most",
	"a significant number of":  "many",
	"a considerable amount of": "much",
	"a great deal of":          "much",
	"a substantial amount of":  "much",
	"plenty of":                "many",

	// Time
	"at this point in time":         "now",
	"at this moment in time":        "now",
	"at the present time":           "now",
	"at the current time":           "now",
	"at this moment":                "now",
	"at this point":                 "now",
	"in the near future":            "soon",
	"in the not too distant future": "soon",
	"in the foreseeable future":     "soon",
	"on a regular basis":            "regularly",
	"on a daily basis":              "daily",
	"on a weekly basis":             "weekly",
	"on a monthly basis":            "monthly",
	"on an annual basis":            "annually",
	"prior to":                      "before",
	"previous to":                   "before",
	"in advance of":                 "before",
	"subsequent to":                 "after",
	"following":                     "after",
	"in the aftermath of":           "after",

	// Modifiers
	"is able to":                  "can",
	"are able to":                 "can",
	"was able to":                 "could",
	"were able to":                "could",
	"has the ability to":          "can",
	"have the ability to":         "can",
	"had the ability to":          "could",
	"is in the process of":        "is",
	"are in the process of":       "are",
	"is going to":                 "will",
	"are going to":                "will",
	"was going to":                "would",
	"were going to":               "would",
	"make use of":                 "use",
	"makes use of":                "uses",
	"made use of":                 "used",
	"carry out":                   "do",
	"carries out":                 "does",
	"carried out":                 "did",
	"perform an analysis of":      "analyze",
	"perform a review of":         "review",
	"conduct an investigation of": "investigate",
	"conduct an examination of":   "examine",
	"make a decision":             "decide",
	"make a determination":        "determine",
	"make an attempt to":          "try to",
	"make an effort to":           "try to",
	"take into consideration":     "consider",
	"take into account":           "consider",
	"give consideration to":       "consider",
	"give rise to":                "cause",
	"give an indication of":       "indicate",
	"have a tendency to":          "tend to",

	// Discourse markers
	"it is important to note that":      "note:",
	"it should be noted that":           "note:",
	"it is worth noting that":           "note:",
	"it is interesting to note that":    "note:",
	"it is worth mentioning that":       "note:",
	"it is important to mention that":   "note:",
	"it is crucial to note that":        "note:",
	"it is essential to note that":      "note:",
	"it must be noted that":             "note:",
	"it is necessary to point out that": "note:",
	"it goes without saying that":       "obviously",
	"needless to say":                   "obviously",
	"as a matter of fact":               "actually",
	"in point of fact":                  "actually",
	"in fact":                           "actually",
	"as things stand":                   "currently",
	"as it stands":                      "currently",
	"at the present moment":             "currently",
	"in the present case":               "here",
	"in this case":                      "here",
	"in the case at hand":               "here",

	// Connectors
	"in addition to": "besides",
	"in addition":    "also",
	"as well as":     "and",
	"on top of that": "also",
	"what's more":    "also",
	"not only":       "both",
	"not just":       "both",
	"but also":       "and",
	"either or":      "or",
	"neither nor":    "nor",

	// Conclusion phrases
	"in conclusion":            "summary:",
	"to conclude":              "summary:",
	"to summarize":             "summary:",
	"in summary":               "summary:",
	"to sum up":                "summary:",
	"to wrap up":               "summary:",
	"all in all":               "overall",
	"taken as a whole":         "overall",
	"on the whole":             "overall",
	"by and large":             "mostly",
	"for the most part":        "mostly",
	"in the main":              "mostly",
	"in most cases":            "usually",
	"in the majority of cases": "usually",
	"in most instances":        "usually",
}

// SubstituteDict applies the eng/v1 dictionary to s, replacing verbose
// phrases with terse equivalents. Case-insensitive on keys; preserves
// the original casing of the first character of the match.
//
// Multi-word keys are matched as whole phrases. The longest match is
// preferred to avoid partial replacements.
func SubstituteDict(s string) string {
	if s == "" {
		return s
	}
	// Sort keys longest-first so multi-word phrases match before single words.
	keys := make([]string, 0, len(engV1Dictionary))
	for k := range engV1Dictionary {
		keys = append(keys, k)
	}
	sortByLengthDesc(keys)

	out := s
	for _, k := range keys {
		out = replacePhraseCI(out, k, engV1Dictionary[k])
	}
	return out
}

// sortByLengthDesc sorts strings longest-first.
func sortByLengthDesc(s []string) {
	// simple O(n^2) — fine for the ~150 entries we have
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && len(s[j-1]) < len(s[j]); j-- {
			s[j-1], s[j] = s[j], s[j-1]
		}
	}
}

// replacePhraseCI replaces all case-insensitive occurrences of needle in s
// with repl, preserving the case of the first character of each match.
func replacePhraseCI(s, needle, repl string) string {
	if needle == "" {
		return s
	}
	lowerS := toLowerASCII(s)
	lowerN := toLowerASCII(needle)
	if len(lowerN) > len(lowerS) {
		return s
	}
	var out []byte
	i := 0
	for i < len(s) {
		if i+len(lowerN) <= len(lowerS) && lowerS[i:i+len(lowerN)] == lowerN {
			// Check word boundary: previous char is non-alphanumeric or start
			if i > 0 && isWordByte(s[i-1]) {
				out = append(out, s[i])
				i++
				continue
			}
			// Check word boundary: next char (if exists) is non-alphanumeric or end
			if i+len(lowerN) < len(s) && isWordByte(s[i+len(lowerN)]) {
				out = append(out, s[i])
				i++
				continue
			}
			// Match found — emit replacement, preserve first-char case
			if isUpper(s[i]) {
				if len(repl) > 0 {
					out = append(out, toUpper(repl[0]))
					out = append(out, repl[1:]...)
				}
			} else {
				out = append(out, repl...)
			}
			i += len(lowerN)
		} else {
			out = append(out, s[i])
			i++
		}
	}
	return string(out)
}

func toLowerASCII(b string) string {
	out := make([]byte, len(b))
	for i := 0; i < len(b); i++ {
		c := b[i]
		if c >= 'A' && c <= 'Z' {
			c += 32
		}
		out[i] = c
	}
	return string(out)
}

func toUpper(b byte) byte {
	if b >= 'a' && b <= 'z' {
		return b - 32
	}
	return b
}

func isUpper(b byte) bool {
	return b >= 'A' && b <= 'Z'
}

func isWordByte(b byte) bool {
	return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '_'
}
