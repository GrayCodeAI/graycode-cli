// Package compress implements the prompt-compression algorithm
// GrayCode native prompt-compression implementation.
//
// The algorithm is a pure text-rewrite engine. Three intensity levels
// (Lite, Full, Ultra) progressively drop articles, filler words,
// pleasantries, hedging, and redundant conjunctions. A built-in
// dictionary (eng/v1) substitutes verbose phrases with terse equivalents.
//
// Auto-clarity rules (see safety.go) prevent compression of security
// warnings, destructive operations, and code-bearing segments.
package compress

// Intensity controls the aggressiveness of prompt compression.
//
// The intensity ordering is Lite < Full < Ultra. Higher intensity drops
// more word classes and applies more aggressive dictionary substitutions.
type Intensity int

const (
	// Lite drops only pleasantries and obvious filler; preserves articles.
	Lite Intensity = iota
	// Full drops articles, filler, pleasantries, and hedging.
	// This is the default.
	Full
	// Ultra additionally drops conjunctions and forces sentence fragments.
	Ultra
)

// String returns the canonical name of the intensity level.
func (i Intensity) String() string {
	switch i {
	case Lite:
		return "lite"
	case Full:
		return "full"
	case Ultra:
		return "ultra"
	default:
		return "unknown"
	}
}

// dropLists maps each intensity to the set of words/phrases to drop.
// Source: skills/prompt-compression/SKILL.md, "Intensity" section.
//
// Multi-word phrases ("of course", "feel free") are matched case-insensitive
// as whole phrases, not as individual words.
var dropLists = map[Intensity]map[string]bool{
	Lite: {
		// Lite drops only pleasantries, leaving articles + filler alone.
		"sure":           true,
		"certainly":      true,
		"of course":      true,
		"happy to":       true,
		"feel free":      true,
		"no problem":     true,
		"you're welcome": true,
		"thank you":      true,
		"thanks":         true,
		"please":         true,
	},
	Full: {
		// Articles
		"a": true, "an": true, "the": true,
		// Filler
		"just": true, "really": true, "basically": true,
		"actually": true, "simply": true, "literally": true,
		"totally": true, "completely": true, "absolutely": true,
		"definitely": true, "certainly": true, "obviously": true,
		"clearly": true, "essentially": true, "particularly": true,
		"specifically": true, "generally": true, "usually": true,
		// Pleasantries
		"sure": true, "of course": true, "happy to": true,
		"feel free": true, "no problem": true, "you're welcome": true,
		"thank you": true, "thanks": true, "please": true,
		// Hedging
		"perhaps": true, "maybe": true, "i think": true,
		"i believe": true, "in my opinion": true,
		"it seems": true, "it appears": true,
		"somewhat": true, "kind of": true, "sort of": true,
	},
	Ultra: {
		// Everything in Full
		"a": true, "an": true, "the": true,
		"just": true, "really": true, "basically": true,
		"actually": true, "simply": true, "literally": true,
		"totally": true, "completely": true, "absolutely": true,
		"definitely": true, "certainly": true, "obviously": true,
		"clearly": true, "essentially": true, "particularly": true,
		"specifically": true, "generally": true, "usually": true,
		"sure": true, "of course": true, "happy to": true,
		"feel free": true, "no problem": true, "you're welcome": true,
		"thank you": true, "thanks": true, "please": true,
		"perhaps": true, "maybe": true, "i think": true,
		"i believe": true, "in my opinion": true,
		"it seems": true, "it appears": true,
		"somewhat": true, "kind of": true, "sort of": true,
		// Ultra additions: conjunctions
		"however": true, "moreover": true, "furthermore": true,
		"nevertheless": true, "nonetheless": true,
		"therefore": true, "thus": true, "hence": true,
		"accordingly": true, "consequently": true,
		"additionally": true, "alternatively": true,
		"likewise": true, "similarly": true,
		"subsequently": true, "previously": true,
		// Filler words (intensity/intensifiers). "somewhat" is already in
		// the Full hedge list; do not duplicate.
		"very": true, "quite": true, "rather": true,
		"fairly": true, "pretty": true,
		// Pronouns when redundant
		"it is": true, "there is": true, "there are": true,
		"this is": true, "that is": true,
	},
}
