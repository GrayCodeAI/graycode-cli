package shrike_test

import (
	"sync"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestCompress(t *testing.T) {
	input := "This is a test string that should be processed by the compression pipeline."
	output, stats := shrike.Compress(input)

	if output == "" {
		t.Fatal("expected non-empty output")
	}
	if stats.OriginalTokens == 0 {
		t.Error("expected non-zero original tokens")
	}
}

func TestCompress_Empty(t *testing.T) {
	output, stats := shrike.Compress("")
	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if stats.OriginalTokens != 0 {
		t.Errorf("expected zero tokens, got %d", stats.OriginalTokens)
	}
}

func TestCompress_Aggressive(t *testing.T) {
	input := "func main() {\n\tfmt.Println(\"hello\")\n}\n// comment\n// another comment\n"
	output, stats := shrike.Compress(input, shrike.Aggressive)

	if output == "" {
		t.Fatal("expected non-empty output")
	}
	if stats.OriginalTokens == 0 {
		t.Error("expected non-zero original tokens")
	}
}

func TestCompress_WithBudget(t *testing.T) {
	input := ""
	for i := 0; i < 200; i++ {
		input += "word "
	}

	_, stats := shrike.Compress(input, shrike.WithBudget(50))
	if stats.FinalTokens > 60 {
		t.Errorf("expected tokens near budget 50, got %d", stats.FinalTokens)
	}
}

func TestCompress_WithTier(t *testing.T) {
	input := "import os\nimport sys\n\ndef main():\n    print('hello')\n"
	output, _ := shrike.Compress(input, shrike.Code)

	if output == "" {
		t.Fatal("expected non-empty output")
	}
}

func TestCompress_WithQuery(t *testing.T) {
	input := "[ERROR] connection refused\n[INFO] retrying...\n[INFO] connected\n"
	output, _ := shrike.Compress(input, shrike.WithQuery("debug"))

	if output == "" {
		t.Fatal("expected non-empty output")
	}
}

func TestEstimateTokens(t *testing.T) {
	n := shrike.EstimateTokens("hello world")
	if n == 0 {
		t.Error("expected non-zero token estimate")
	}
}

func TestNewCompressor(t *testing.T) {
	c := shrike.NewCompressor(shrike.Adaptive)

	out1, s1 := c.Compress("first input text")
	out2, s2 := c.Compress("second input text")

	if out1 == "" || out2 == "" {
		t.Error("expected non-empty outputs")
	}
	if s1.OriginalTokens == 0 || s2.OriginalTokens == 0 {
		t.Error("expected non-zero token counts")
	}
}

func TestCompress_Concurrent(t *testing.T) {
	input := "concurrent test data with enough content to compress."
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			output, _ := shrike.Compress(input)
			if output == "" {
				t.Error("expected non-empty output")
			}
		}()
	}
	wg.Wait()
}
