---
name: shrike-help
description: >
  Quick-reference card for all shrike modes, skills, and commands.
  One-shot display, not a persistent mode. Trigger: /shrike-help,
  "shrike help", "what shrike commands", "how do I use shrike".
---

# Shrike Help

Display this reference card when invoked. One-shot — do NOT change mode, write flag files, or persist anything. Output in shrike style.

## Modes

| Mode | Trigger | What change |
|------|---------|-------------|
| **Lite** | `/shrike lite` | Drop filler. Keep sentence structure. |
| **Full** | `/shrike` | Drop articles, filler, pleasantries, hedging. Fragments OK. Default. |
| **Ultra** | `/shrike ultra` | Extreme compression. Bare fragments. Tables over prose. |
| **Wenyan-Lite** | `/shrike wenyan-lite` | Classical Chinese style, light compression. |
| **Wenyan-Full** | `/shrike wenyan` | Full 文言文. Maximum classical terseness. |
| **Wenyan-Ultra** | `/shrike wenyan-ultra` | Extreme. Ancient scholar on a budget. |

Mode stick until changed or session end.

## Skills

| Skill | Trigger | What it do |
|-------|---------|-----------|
| **shrike-commit** | `/shrike-commit` | Terse commit messages. Conventional Commits. ≤50 char subject. |
| **shrike-review** | `/shrike-review` | One-line PR comments: `L42: bug: user null. Add guard.` |
| **shrike-compress** | `/shrike:compress <file>` | Compress .md files to shrike prose. Saves ~46% input tokens. |
| **shrike-help** | `/shrike-help` | This card. |

## Deactivate

Say "stop shrike" or "normal mode". Resume anytime with `/shrike`.

## Configure Default Mode

Default mode = `full`. Change it:

**Environment variable** (highest priority):
```bash
export TOK_DEFAULT_MODE=ultra
```

**Config file** (`~/.config/shrike/config.json`):
```json
{ "defaultMode": "lite" }
```

Set `"off"` to disable auto-activation on session start. User can still activate manually with `/shrike`.

Resolution: env var > config file > `full`.

## More

Full docs: https://github.com/GrayCodeAI/shrike
