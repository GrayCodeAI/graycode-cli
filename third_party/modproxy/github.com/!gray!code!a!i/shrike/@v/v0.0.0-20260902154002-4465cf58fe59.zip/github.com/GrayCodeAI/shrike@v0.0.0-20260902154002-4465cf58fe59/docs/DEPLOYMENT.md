# Deployment Guide

## Overview

`shrike` is a **Go library** (module `github.com/GrayCodeAI/shrike`). It ships no
standalone binary — you integrate it by importing the package into your own
Go program. "Deployment" therefore means adding it as a Go module dependency;
there is nothing to host or run on its own.

If you are looking for `shrike ...` subcommands (compress, estimate, gain, etc.),
those are provided by **Hawk** (`github.com/GrayCodeAI/hawk`), a CLI that embeds
this library — e.g. `hawk shrike compress`. Hawk vendors `shrike`, so deploying the
features to end users means shipping Hawk.

This guide covers:

1. **As a library dependency** — adding `shrike` to a Go project.
2. **Custom filters & profiles** — distributing shared configuration.
3. **CI/CD** — building, testing, and benchmarking.

---

## Library Deployment

### Install

```bash
go get github.com/GrayCodeAI/shrike
```

Then import it:

```go
import "github.com/GrayCodeAI/shrike"
```

### Basic Usage

```go
// Prompt compression (Lite / Full / Ultra intensities).
out, _ := shrike.PromptCompress("Please implement authentication", shrike.IntensityUltra)

// Full output pipeline with options.
out, _ := shrike.Compress(verboseOutput, shrike.Aggressive)

// Model-aware token counting and pricing.
n    := shrike.EstimateTokensForModel(text, "gpt-4o")
cost := shrike.EstimateCost(text, "gpt-4o")
```

### Public API Surface

| Function / option | Purpose |
| --- | --- |
| `shrike.Compress(text, opts...)` | Full output pipeline (31 layers) with options. |
| `shrike.PromptCompress(text, intensity)` | Prompt compression at `IntensityLite` / `IntensityFull` / `IntensityUltra`. |
| `shrike.EstimateTokensForModel(text, model)` | Model-aware token count. |
| `shrike.EstimateCost(text, model)` | Estimated cost for the given model. |
| `shrike.SmartTruncate(content, maxLines, lang)` | Code-aware truncation that preserves signatures and reports exact drop counts. |
| `shrike.ExtractJSON(text)` | Pull JSON out of mixed output. |
| `shrike.NewSecretDetector()` | Content-based secret detection. |
| `shrike.IsSensitiveFilename(path)` | Filename-based sensitive-file detection. |
| `shrike.NewTracker(ctx)` | Persistent SQLite-backed gain tracker. |
| `shrike.LoadFilterRules(path)` | Load custom TOML filter rules. |
| `shrike.LoadProfile(path)` | Load a TOML profile. |

Compression options: `shrike.Aggressive`, `shrike.WithCustomFilters(rules)`,
`shrike.WithCodeAware(lang)`, `shrike.WithPerplexityGuided(scorer, ratio)`.
Intensities: `shrike.IntensityLite`, `shrike.IntensityFull`, `shrike.IntensityUltra`.

### Pinning a Version

```bash
# Latest release
go get github.com/GrayCodeAI/shrike@latest

# Specific version
go get github.com/GrayCodeAI/shrike@v0.1.0

# Rollback to a prior version
go get github.com/GrayCodeAI/shrike@v0.1.0
```

`go.mod` records the chosen version; `go mod tidy` keeps it consistent.

---

## Custom Filters & Profiles

Custom filters are **TOML files** loaded at runtime via `shrike.LoadFilterRules`,
and profiles via `shrike.LoadProfile`. This is a real, supported library feature —
distribute a shared TOML to give a team consistent compression behavior.

```go
rules, _ := shrike.LoadFilterRules("filters.toml")
out, _   := shrike.Compress(text, shrike.WithCustomFilters(rules))

p, _ := shrike.LoadProfile(".shrike/profiles/code-safe.toml")
```

To share configuration across a team, commit the `.toml` files to your repo (or
a shared location) and load them from your application.

---

## CI/CD Integration

Because `shrike` is a library, CI integration means building, testing, and
benchmarking it as a normal Go module — there is no binary to install into a
runner.

### GitHub Actions

```yaml
# .github/workflows/shrike.yml
name: shrike

on: [push, pull_request]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.24'

      - name: Build (library)
        run: ./scripts/build.sh

      - name: Test
        run: go test ./...

      - name: Benchmarks
        run: ./benchmarks/run.sh
```

### GitLab CI

```yaml
# .gitlab-ci.yml
shrike:
  image: golang:1.24
  stage: test
  script:
    - go build ./...
    - go test ./...
    - ./benchmarks/run.sh
```

---

## Benchmarks

Benchmarks run through the Go toolchain — both scripts wrap `go test -bench`:

```bash
# Compression benchmarks (raw vs shrike.Compress(..., shrike.Aggressive))
./benchmarks/run.sh

# Pipeline / eval benchmarks
./evals/pipeline-bench.sh
```

Measured results are recorded in `benchmarks/results.md`.

---

## Releasing

Releases are tagged Go module versions; consumers pull them with `go get`.

```bash
# Tag the release
git tag -a v0.1.0 -m "Release v0.1.0"
git push origin v0.1.0
```

There is no binary to publish — once tagged, the module is available to any
consumer (including Hawk) via `go get`.

---

## Upgrade & Rollback

Upgrading and rolling back are ordinary Go module operations:

```bash
# Upgrade
go get github.com/GrayCodeAI/shrike@latest && go mod tidy

# Rollback
go get github.com/GrayCodeAI/shrike@v0.1.0 && go mod tidy
```

---

## Troubleshooting

**Module not found / version mismatch:**
```bash
go mod tidy
go clean -cache
```

**Build fails:**
```bash
# Verify the library compiles on its own
go build ./...
```

---

## Security Considerations

1. **Secret handling:** Use `shrike.NewSecretDetector()` and
   `shrike.IsSensitiveFilename` to keep secrets out of compressed output before it
   re-enters an LLM context.
2. **Filter/profile TOML:** Treat shared `.toml` config as code — review it
   before loading.
3. **Updates:** Keep the dependency current for security fixes
   (`go get ...@latest`).

See [SECURITY.md](../SECURITY.md) for the full security policy.
