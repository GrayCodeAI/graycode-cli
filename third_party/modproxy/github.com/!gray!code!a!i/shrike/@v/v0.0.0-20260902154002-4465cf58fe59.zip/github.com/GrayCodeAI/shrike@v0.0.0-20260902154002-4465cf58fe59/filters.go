// Custom filter DSL — user-defined compression rules.
//
// This file exposes a small, public rule format that lets users define their
// own regex-based find/replace rules in a TOML file (e.g. ~/.shrike/filters.toml)
// and apply them as an early or late stage of the compression pipeline.
//
// The file format reuses TOML (already a dependency via BurntSushi/toml). Each
// rule is a [[rule]] array-of-tables entry:
//
//	# ~/.shrike/filters.toml
//	[[rule]]
//	name        = "collapse-uuids"
//	pattern     = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
//	replacement = "<uuid>"
//	priority    = 10
//	enabled     = true
//	applies_to  = "*.log"   # optional content-type or glob hint
//
//	[[rule]]
//	name        = "strip-timestamps"
//	pattern     = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z\\s*"
//	replacement = ""
//	priority    = 20
//
// Rules are applied in ascending priority order (lower priority numbers run
// first). Invalid regex patterns are skipped with a logged warning rather than
// crashing the whole load — a single bad rule never disables the rest.
//
// Usage:
//
//	rules, _ := shrike.LoadFilterRules(filepath.Join(home, ".shrike", "filters.toml"))
//	out, stats := shrike.Compress(text, shrike.WithCustomFilters(rules))
package shrike

import (
	"fmt"
	"log/slog"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"github.com/BurntSushi/toml"
)

// FilterRule is a single user-defined find/replace rule.
//
// Pattern is a Go (RE2) regular expression. Replacement may reference capture
// groups using the $1 / ${name} syntax accepted by regexp.ReplaceAllString.
type FilterRule struct {
	// Name is a human-readable identifier (used in logged warnings).
	Name string `toml:"name"`
	// Pattern is the regex to match.
	Pattern string `toml:"pattern"`
	// Replacement is substituted for each match.
	Replacement string `toml:"replacement"`
	// Priority orders rule application: lower runs first. Defaults to 0.
	Priority int `toml:"priority"`
	// Enabled gates the rule. Rules default to enabled when the field is
	// omitted from the TOML (see LoadFilterRules).
	Enabled bool `toml:"enabled"`
	// AppliesTo is an optional content-type label or filename glob (e.g.
	// "*.log", "json"). Empty means the rule applies to all input. The glob,
	// when set, is matched against the content-type hint passed to
	// CustomFilter.ApplyTo (callers that compress raw text without a hint get
	// all enabled rules).
	AppliesTo string `toml:"applies_to"`
}

// filterRuleFile is the on-disk shape: a top-level array of [[rule]] tables.
type filterRuleFile struct {
	Rules []rawFilterRule `toml:"rule"`
}

// rawFilterRule mirrors FilterRule but tracks whether `enabled` was present so
// an omitted field can default to true (opt-out) instead of false.
type rawFilterRule struct {
	Name        string `toml:"name"`
	Pattern     string `toml:"pattern"`
	Replacement string `toml:"replacement"`
	Priority    int    `toml:"priority"`
	Enabled     *bool  `toml:"enabled"`
	AppliesTo   string `toml:"applies_to"`
}

// LoadFilterRules parses a TOML rules file at path and returns the rules in
// ascending priority order.
//
// A rule with `enabled` omitted defaults to enabled. Rules with an empty
// pattern are dropped with a logged warning. Regex validity is NOT checked
// here — it is checked (once) when building a CustomFilter, so that an invalid
// pattern is skipped rather than failing the whole load. A malformed TOML file
// returns a non-nil error.
func LoadFilterRules(path string) ([]FilterRule, error) {
	var file filterRuleFile
	if _, err := toml.DecodeFile(path, &file); err != nil {
		return nil, fmt.Errorf("shrike: load filter rules %s: %w", path, err)
	}

	rules := make([]FilterRule, 0, len(file.Rules))
	for _, r := range file.Rules {
		enabled := true
		if r.Enabled != nil {
			enabled = *r.Enabled
		}
		if strings.TrimSpace(r.Pattern) == "" {
			slog.Warn("shrike: skipping custom filter rule with empty pattern",
				"name", r.Name, "path", path)
			continue
		}
		rules = append(rules, FilterRule{
			Name:        r.Name,
			Pattern:     r.Pattern,
			Replacement: r.Replacement,
			Priority:    r.Priority,
			Enabled:     enabled,
			AppliesTo:   r.AppliesTo,
		})
	}

	sortRulesByPriority(rules)
	return rules, nil
}

// sortRulesByPriority sorts in place by ascending Priority, stable so that
// equal-priority rules keep their file order.
func sortRulesByPriority(rules []FilterRule) {
	sort.SliceStable(rules, func(i, j int) bool {
		return rules[i].Priority < rules[j].Priority
	})
}

// compiledRule pairs a FilterRule with its compiled regex.
type compiledRule struct {
	rule     FilterRule
	compiled *regexp.Regexp
}

// CustomFilter applies a set of user-defined FilterRules to text in priority
// order. Regexes are compiled once at construction; rules whose pattern fails
// to compile are skipped with a logged warning so a single bad rule never
// disables the rest.
//
// CustomFilter is read-only after construction and safe for concurrent use.
type CustomFilter struct {
	rules []compiledRule
}

// NewCustomFilter compiles rules into an applicable filter. Disabled rules and
// rules with invalid patterns are dropped (the latter with a logged warning).
// Rules are stored in ascending priority order regardless of input ordering.
func NewCustomFilter(rules []FilterRule) *CustomFilter {
	ordered := make([]FilterRule, len(rules))
	copy(ordered, rules)
	sortRulesByPriority(ordered)

	compiled := make([]compiledRule, 0, len(ordered))
	for _, r := range ordered {
		if !r.Enabled {
			continue
		}
		re, err := regexp.Compile(r.Pattern)
		if err != nil {
			slog.Warn("shrike: skipping custom filter rule with invalid pattern",
				"name", r.Name, "pattern", r.Pattern, "error", err)
			continue
		}
		compiled = append(compiled, compiledRule{rule: r, compiled: re})
	}
	return &CustomFilter{rules: compiled}
}

// Len reports how many compiled (enabled, valid) rules the filter holds.
func (f *CustomFilter) Len() int {
	if f == nil {
		return 0
	}
	return len(f.rules)
}

// Apply runs every compiled rule against text in priority order and returns
// the transformed result. It is equivalent to ApplyTo(text, "").
func (f *CustomFilter) Apply(text string) string {
	return f.ApplyTo(text, "")
}

// ApplyTo runs the compiled rules against text in priority order, skipping any
// rule whose AppliesTo glob does not match the supplied contentType hint.
//
// An empty contentType means "no hint": only rules with an empty AppliesTo are
// applied. A rule with an empty AppliesTo always applies regardless of hint.
func (f *CustomFilter) ApplyTo(text, contentType string) string {
	if f == nil || text == "" {
		return text
	}
	out := text
	for _, cr := range f.rules {
		if !ruleApplies(cr.rule.AppliesTo, contentType) {
			continue
		}
		out = cr.compiled.ReplaceAllString(out, cr.rule.Replacement)
	}
	return out
}

// ruleApplies reports whether a rule with the given AppliesTo glob should run
// for the supplied contentType hint.
//
//   - empty appliesTo: always applies.
//   - non-empty appliesTo, empty contentType: does not apply (no hint to match).
//   - otherwise: applies if appliesTo equals contentType or matches it as a
//     filepath glob (e.g. "*.log" matches "server.log").
func ruleApplies(appliesTo, contentType string) bool {
	if appliesTo == "" {
		return true
	}
	if contentType == "" {
		return false
	}
	if appliesTo == contentType {
		return true
	}
	if ok, err := filepath.Match(appliesTo, contentType); err == nil && ok {
		return true
	}
	return false
}
