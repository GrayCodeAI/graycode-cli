package shrike

import (
	"encoding/json"
	"hash/fnv"
	"math/rand"
	"strings"
)

// CompressJSON samples large JSON arrays, keeping error/failure items,
// first 2, last 2, and a random sample of the middle. If maxItems <= 0,
// defaults to 20. Non-array input is returned unchanged.
//
// Elided items are replaced by one trailing sentinel record stating only
// verified facts about them (see invariants.go) — a bare silent drop forces
// the reader to guess what was removed and re-retrieve.
func CompressJSON(text string, maxItems int) string {
	if maxItems <= 0 {
		maxItems = 20
	}
	text = strings.TrimSpace(text)
	var arr []json.RawMessage
	if err := json.Unmarshal([]byte(text), &arr); err != nil || len(arr) == 0 {
		return text
	}
	if len(arr) <= maxItems {
		return text
	}

	keep := make(map[int]bool)
	// first 2, last 2
	for i := 0; i < 2 && i < len(arr); i++ {
		keep[i] = true
	}
	for i := len(arr) - 2; i < len(arr); i++ {
		if i >= 0 {
			keep[i] = true
		}
	}
	// error/failure items
	for i, raw := range arr {
		s := strings.ToLower(string(raw))
		if strings.Contains(s, "error") || strings.Contains(s, "failure") || strings.Contains(s, "fail") {
			keep[i] = true
		}
	}
	// random sample from middle to fill up to maxItems (deterministic via content hash)
	if len(keep) < maxItems {
		var middle []int
		for i := 2; i < len(arr)-2; i++ {
			if !keep[i] {
				middle = append(middle, i)
			}
		}
		h := fnv.New64a()
		_, _ = h.Write([]byte(text))                      // #nosec G104 -- hash.Hash.Write never returns an error
		rng := rand.New(rand.NewSource(int64(h.Sum64()))) // #nosec G404 G115 -- non-cryptographic use (deterministic shuffle seed from content hash); hash-mixing conversion, overflow is harmless
		rng.Shuffle(len(middle), func(i, j int) { middle[i], middle[j] = middle[j], middle[i] })
		need := maxItems - len(keep)
		if need > len(middle) {
			need = len(middle)
		}
		for _, i := range middle[:need] {
			keep[i] = true
		}
	}

	dropped := make([]json.RawMessage, 0, len(arr)-len(keep))
	result := make([]json.RawMessage, 0, len(keep)+1)
	for i := 0; i < len(arr); i++ {
		if keep[i] {
			result = append(result, arr[i])
		} else {
			dropped = append(dropped, arr[i])
		}
	}
	if facts := JSONInvariants(dropped); facts != "" {
		sentinel, err := json.Marshal(map[string]interface{}{
			"_tok_elided": map[string]interface{}{
				"count": len(dropped),
				"facts": facts,
			},
		})
		if err == nil {
			result = append(result, sentinel)
		}
	}
	out, _ := json.Marshal(result)
	return string(out)
}
