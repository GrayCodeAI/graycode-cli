package secrets_test

import (
	"testing"

	"github.com/GrayCodeAI/shrike/internal/secrets"
)

func TestIsSensitiveFilename_ExactBasename(t *testing.T) {
	tests := []struct {
		name     string
		path     string
		category secrets.Category
	}{
		{".env", ".env", secrets.CatExactBasename},
		{".env variant", ".env.local", secrets.CatExactBasename},
		{".env case-insensitive", ".ENV.production", secrets.CatExactBasename},
		{"credentials", "credentials", secrets.CatExactBasename},
		{"credentials.json", "credentials.json", secrets.CatExactBasename},
		{"secrets.yaml", "secrets.yaml", secrets.CatExactBasename},
		{"passwords.txt", "passwords.txt", secrets.CatExactBasename},
		{"passwd", "passwd", secrets.CatExactBasename},
		{"id_rsa", "id_rsa", secrets.CatExactBasename},
		{"id_ed25519", "id_ed25519", secrets.CatExactBasename},
		{"authorized_keys", "authorized_keys", secrets.CatExactBasename},
		{"known_hosts", "known_hosts", secrets.CatExactBasename},
		{"pem file", "private.pem", secrets.CatExactBasename},
		{"key file", "server.key", secrets.CatExactBasename},
		{"p12 file", "client.p12", secrets.CatExactBasename},
		{"pfx file", "client.pfx", secrets.CatExactBasename},
		{"crt file", "server.crt", secrets.CatExactBasename},
		{"jks file", "keystore.jks", secrets.CatExactBasename},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ok, m := secrets.IsSensitiveFilename(tc.path)
			if !ok {
				t.Errorf("expected %q to be sensitive", tc.path)
			}
			if m.Category != tc.category {
				t.Errorf("expected category %v, got %v", tc.category, m.Category)
			}
			if m.Reason == "" {
				t.Error("expected non-empty reason")
			}
		})
	}
}

func TestIsSensitiveFilename_SensitiveDirectory(t *testing.T) {
	// Use cases where the basename is NOT itself in the exact-basename
	// list, so the directory match is the only thing that fires.
	// (Cases like "/.ssh/id_rsa" are tested separately for the
	// CatExactBasename layer.)
	tests := []struct {
		name string
		path string
	}{
		{".ssh directory", "/home/user/.ssh/random.txt"},
		{".ssh nested", "/home/user/.ssh/config.d/notes"},
		{".aws", "/home/user/.aws/config"},
		{".gnupg", "/root/.gnupg/trustdb.gpg"},
		{".kube", "/home/user/.kube/config"},
		{".docker", "/home/user/.docker/config.json"},
		{".config/gcloud", "/home/user/.config/gcloud/notes.db"},
		{".config/gh", "/home/user/.config/gh/notes.yml"},
		{"relative .ssh", "./.ssh/notes"},
		{"deeply nested", "/a/b/c/.aws/random"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ok, m := secrets.IsSensitiveFilename(tc.path)
			if !ok {
				t.Errorf("expected %q to be sensitive (sensitive directory)", tc.path)
			}
			if m.Category != secrets.CatSensitiveDirectory {
				t.Errorf("expected CatSensitiveDirectory, got %v (%s)", m.Category, m.Reason)
			}
		})
	}
}

func TestIsSensitiveFilename_NameToken(t *testing.T) {
	tests := []struct {
		name string
		path string
	}{
		{"secret in name", "my_secret_file.txt"},
		{"credential in name", "test_credentials.json"},
		{"password in name", "db_password.txt"},
		{"apikey in name", "google_apikey.json"},
		{"api-key in name", "aws-api-key.txt"},
		{"access_key in name", "access_key.txt"},
		{"access-key in name", "my-access-key.txt"},
		{"token in name", "auth_token.txt"},
		{"private_key in name", "my_private_key.txt"},
		{"private-key in name", "my-private-key.txt"},
		{"case-insensitive SECRET", "UPPERCASE_SECRET.txt"},
		{"case-insensitive PASSWORD", "MIXEDCase_Password.txt"},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ok, m := secrets.IsSensitiveFilename(tc.path)
			if !ok {
				t.Errorf("expected %q to be sensitive (name token)", tc.path)
			}
			if m.Category != secrets.CatNameToken {
				t.Errorf("expected CatNameToken, got %v (%s)", m.Category, m.Reason)
			}
		})
	}
}

func TestIsSensitiveFilename_NotSensitive(t *testing.T) {
	tests := []string{
		"",
		"   ",
		"main.go",
		"README.md",
		"index.html",
		"package.json",
		"go.mod",
		"go.sum",
		"Makefile",
		"Dockerfile",
		"src/main.go",
		"docs/api.md",
		"tests/foo_test.go",
		"data.txt",
		"image.png",
		"video.mp4",
		"config.yaml", // 'config' alone is not sensitive
		"notes.txt",
		"document.pdf",
	}

	for _, path := range tests {
		t.Run("not_sensitive:"+path, func(t *testing.T) {
			ok, m := secrets.IsSensitiveFilename(path)
			if ok {
				t.Errorf("expected %q to NOT be sensitive, but got match: %v", path, m)
			}
			if m.Category != secrets.CatNone {
				t.Errorf("expected CatNone, got %v", m.Category)
			}
		})
	}
}

func TestIsSensitiveFilename_PreferExactOverToken(t *testing.T) {
	// "credentials.json" matches both the exact-basename list AND the
	// "credential" name token. The exact match should win.
	ok, m := secrets.IsSensitiveFilename("credentials.json")
	if !ok {
		t.Fatal("expected sensitive")
	}
	if m.Category != secrets.CatExactBasename {
		t.Errorf("expected CatExactBasename to take precedence over CatNameToken, got %v", m.Category)
	}
}

func TestIsSensitiveFilename_DirectoryPreferredOverToken(t *testing.T) {
	// A file in .ssh/ should match the directory layer, not the token layer.
	ok, m := secrets.IsSensitiveFilename("/home/user/.ssh/random.txt")
	if !ok {
		t.Fatal("expected sensitive")
	}
	if m.Category != secrets.CatSensitiveDirectory {
		t.Errorf("expected CatSensitiveDirectory, got %v", m.Category)
	}
}

func TestIsSensitiveFilename_EmptyAndWhitespace(t *testing.T) {
	ok, m := secrets.IsSensitiveFilename("")
	if ok {
		t.Error("expected empty path to be non-sensitive")
	}
	if m.Category != secrets.CatNone {
		t.Errorf("expected CatNone, got %v", m.Category)
	}

	ok, m = secrets.IsSensitiveFilename("   ")
	if ok {
		t.Error("expected whitespace path to be non-sensitive")
	}
	if m.Category != secrets.CatNone {
		t.Errorf("expected CatNone, got %v", m.Category)
	}
}

func TestIsSensitiveBasename(t *testing.T) {
	if !secrets.IsSensitiveBasename(".env") {
		t.Error("expected .env to be sensitive")
	}
	if !secrets.IsSensitiveBasename("id_rsa") {
		t.Error("expected id_rsa to be sensitive")
	}
	if secrets.IsSensitiveBasename("main.go") {
		t.Error("expected main.go to NOT be sensitive")
	}
}

func TestCategoryString(t *testing.T) {
	tests := []struct {
		c    secrets.Category
		want string
	}{
		{secrets.CatNone, "none"},
		{secrets.CatExactBasename, "exact-basename"},
		{secrets.CatSensitiveDirectory, "sensitive-directory"},
		{secrets.CatNameToken, "name-token"},
	}
	for _, tc := range tests {
		if got := tc.c.String(); got != tc.want {
			t.Errorf("Category(%d).String() = %q, want %q", tc.c, got, tc.want)
		}
	}
}
