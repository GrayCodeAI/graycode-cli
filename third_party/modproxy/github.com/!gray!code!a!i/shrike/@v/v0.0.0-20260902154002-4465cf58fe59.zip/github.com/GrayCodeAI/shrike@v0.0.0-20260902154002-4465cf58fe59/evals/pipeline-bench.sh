#!/usr/bin/env bash
# Repro for docs/PERFORMANCE.md pipeline numbers.
#
# shrike is a library (no CLI), so this drives the pipeline through Go
# benchmarks rather than a binary. It runs the filter-pipeline benchmarks
# at small/medium/large fixture sizes and prints ns/op + allocations, so
# you can verify the latency the docs claim or update them when the
# pipeline changes.
#
# Usage: ./evals/pipeline-bench.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$REPO_ROOT"

echo "==> shrike pipeline benchmarks (internal/filter)"
echo

# ProcessSmall / ProcessMedium / ProcessWithBudget + per-layer timings.
go test -run='^$' \
  -bench='BenchmarkPipeline_Process|BenchmarkLayer_|BenchmarkEstimateTokens_' \
  -benchmem \
  ./internal/filter/

echo
echo "pipeline-bench: complete (see ns/op + B/op + allocs/op above)"
