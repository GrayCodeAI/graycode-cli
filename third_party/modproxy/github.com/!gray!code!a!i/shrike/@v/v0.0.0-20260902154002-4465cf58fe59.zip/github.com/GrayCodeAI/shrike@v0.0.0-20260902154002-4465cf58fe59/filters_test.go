package shrike

import (
	"os"
	"path/filepath"
	"testing"
)

// writeTempRules writes content to a temp filters.toml and returns its path.
func writeTempRules(t *testing.T, content string) string {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "filters.toml")
	if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
		t.Fatalf("write temp rules: %v", err)
	}
	return path
}

func TestLoadFilterRules(t *testing.T) {
	t.Parallel()

	const content = `
[[rule]]
name        = "second"
pattern     = "b"
replacement = "B"
priority    = 20
enabled     = true

[[rule]]
name        = "first"
pattern     = "a"
replacement = "A"
priority    = 10

[[rule]]
name        = "disabled"
pattern     = "c"
replacement = "C"
priority    = 5
enabled     = false

[[rule]]
name        = "empty-pattern"
pattern     = ""
replacement = "x"
priority    = 1
`

	path := writeTempRules(t, content)
	rules, err := LoadFilterRules(path)
	if err != nil {
		t.Fatalf("LoadFilterRules: %v", err)
	}

	// empty-pattern dropped at load; 3 remain.
	if len(rules) != 3 {
		t.Fatalf("got %d rules, want 3: %+v", len(rules), rules)
	}

	// Sorted ascending by priority: disabled(5), first(10), second(20).
	wantOrder := []string{"disabled", "first", "second"}
	for i, w := range wantOrder {
		if rules[i].Name != w {
			t.Errorf("rule[%d].Name = %q, want %q", i, rules[i].Name, w)
		}
	}

	// `enabled` omitted defaults to true (the "first" rule).
	for _, r := range rules {
		if r.Name == "first" && !r.Enabled {
			t.Errorf("rule %q: enabled should default to true", r.Name)
		}
		if r.Name == "disabled" && r.Enabled {
			t.Errorf("rule %q: enabled should be false", r.Name)
		}
	}
}

func TestLoadFilterRules_MalformedTOML(t *testing.T) {
	t.Parallel()
	path := writeTempRules(t, "this is = = not valid toml [[[")
	if _, err := LoadFilterRules(path); err == nil {
		t.Fatal("expected error for malformed TOML, got nil")
	}
}

func TestLoadFilterRules_MissingFile(t *testing.T) {
	t.Parallel()
	if _, err := LoadFilterRules(filepath.Join(t.TempDir(), "nope.toml")); err == nil {
		t.Fatal("expected error for missing file, got nil")
	}
}

func TestCustomFilterApply(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		rules []FilterRule
		input string
		want  string
	}{
		{
			name: "single replacement",
			rules: []FilterRule{
				{Name: "r", Pattern: "foo", Replacement: "bar", Enabled: true},
			},
			input: "foo and foo",
			want:  "bar and bar",
		},
		{
			name: "priority ordering: lower priority runs first",
			rules: []FilterRule{
				// Higher priority number => runs later. "A"->"B" must run
				// after "a"->"A" to produce "B".
				{Name: "late", Pattern: "A", Replacement: "B", Priority: 20, Enabled: true},
				{Name: "early", Pattern: "a", Replacement: "A", Priority: 10, Enabled: true},
			},
			input: "a",
			want:  "B",
		},
		{
			name: "disabled rule skipped",
			rules: []FilterRule{
				{Name: "off", Pattern: "x", Replacement: "y", Enabled: false},
			},
			input: "x",
			want:  "x",
		},
		{
			name: "invalid pattern skipped, valid still applies",
			rules: []FilterRule{
				{Name: "bad", Pattern: "(unclosed", Replacement: "z", Priority: 1, Enabled: true},
				{Name: "good", Pattern: "ok", Replacement: "OK", Priority: 2, Enabled: true},
			},
			input: "ok (unclosed",
			want:  "OK (unclosed",
		},
		{
			name: "capture group replacement",
			rules: []FilterRule{
				{Name: "swap", Pattern: `(\w+)=(\w+)`, Replacement: "$2=$1", Enabled: true},
			},
			input: "key=val",
			want:  "val=key",
		},
		{
			name:  "no rules is identity",
			rules: nil,
			input: "unchanged",
			want:  "unchanged",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			f := NewCustomFilter(tt.rules)
			if got := f.Apply(tt.input); got != tt.want {
				t.Errorf("Apply(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}

func TestCustomFilterInvalidPatternResilience(t *testing.T) {
	t.Parallel()
	// Two bad, one good — Len should report only the compiled (good) rule.
	f := NewCustomFilter([]FilterRule{
		{Name: "bad1", Pattern: "(", Enabled: true},
		{Name: "bad2", Pattern: "[z-a]", Enabled: true},
		{Name: "good", Pattern: "hi", Replacement: "bye", Enabled: true},
	})
	if f.Len() != 1 {
		t.Fatalf("Len() = %d, want 1 (only valid rule compiled)", f.Len())
	}
	if got := f.Apply("hi there"); got != "bye there" {
		t.Errorf("Apply = %q, want %q", got, "bye there")
	}
}

func TestCustomFilterAppliesTo(t *testing.T) {
	t.Parallel()

	rules := []FilterRule{
		{Name: "logs-only", Pattern: "ts", Replacement: "T", Enabled: true, AppliesTo: "*.log"},
		{Name: "all", Pattern: "x", Replacement: "Y", Enabled: true},
	}
	f := NewCustomFilter(rules)

	tests := []struct {
		name        string
		contentType string
		input       string
		want        string
	}{
		{
			name:        "matching glob applies both",
			contentType: "server.log",
			input:       "ts x",
			want:        "T Y",
		},
		{
			name:        "non-matching hint applies only unscoped rule",
			contentType: "data.json",
			input:       "ts x",
			want:        "ts Y",
		},
		{
			name:        "empty hint applies only unscoped rule",
			contentType: "",
			input:       "ts x",
			want:        "ts Y",
		},
		{
			name:        "exact content-type label match",
			contentType: "*.log",
			input:       "ts x",
			want:        "T Y",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := f.ApplyTo(tt.input, tt.contentType); got != tt.want {
				t.Errorf("ApplyTo(%q, %q) = %q, want %q", tt.input, tt.contentType, got, tt.want)
			}
		})
	}
}

func TestCustomFilterNilSafe(t *testing.T) {
	t.Parallel()
	var f *CustomFilter
	if f.Len() != 0 {
		t.Errorf("nil.Len() = %d, want 0", f.Len())
	}
	if got := f.Apply("text"); got != "text" {
		t.Errorf("nil.Apply = %q, want %q", got, "text")
	}
}

func TestLoadAndApplyEndToEnd(t *testing.T) {
	t.Parallel()

	const content = `
[[rule]]
name        = "uuid"
pattern     = "[0-9a-f]{8}-[0-9a-f]{4}"
replacement = "<id>"
priority    = 10

[[rule]]
name        = "trailing-ws"
pattern     = " +$"
replacement = ""
priority    = 20
`
	path := writeTempRules(t, content)
	rules, err := LoadFilterRules(path)
	if err != nil {
		t.Fatalf("LoadFilterRules: %v", err)
	}
	f := NewCustomFilter(rules)

	in := "id=deadbeef-1234   "
	want := "id=<id>"
	if got := f.Apply(in); got != want {
		t.Errorf("Apply(%q) = %q, want %q", in, got, want)
	}
}
