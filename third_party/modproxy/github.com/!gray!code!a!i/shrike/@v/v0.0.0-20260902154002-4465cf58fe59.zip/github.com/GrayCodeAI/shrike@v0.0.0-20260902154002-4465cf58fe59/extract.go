// JSON extraction from prose — public API.
//
// Wraps internal/extract to expose brace-balanced JSON object and
// array extraction as a top-level shrike API. Useful for parsing LLM
// output that contains JSON embedded in surrounding prose.
package shrike

import "github.com/GrayCodeAI/shrike/internal/extract"

// JSONExtract is the result of an extraction attempt.
type JSONExtract = extract.Result

// ExtractJSON returns the first complete JSON object found in text,
// or JSONExtract{Found: false} if no balanced object exists.
//
// Handles nested objects, arrays, escaped quotes, and double-quoted
// strings. Skips preceding and trailing prose. Apostrophes in English
// prose (e.g. "Here's the JSON:") are NOT treated as string delimiters
// (only standard JSON double-quotes are).
//
// Example:
//
//	out := shrike.ExtractJSON(`Sure! Here's the data: {"name": "alice"}`)
//	// out.JSON = `{"name": "alice"}`, out.Found = true
func ExtractJSON(text string) JSONExtract {
	return extract.ExtractJSONObject(text)
}

// ExtractJSONArray is the array counterpart of ExtractJSON. It looks
// for a balanced `[...]` instead of `{...}`.
func ExtractJSONArray(text string) JSONExtract {
	return extract.ExtractJSONArray(text)
}

// ExtractAllJSON returns every top-level balanced JSON object in
// text, in source order. Useful for parsing LLM output that contains
// multiple JSON snippets.
func ExtractAllJSON(text string) []JSONExtract {
	return extract.ExtractAllJSONObjects(text)
}
