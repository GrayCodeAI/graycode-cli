package shrike

import "github.com/GrayCodeAI/shrike/internal/filter"

// Compressor is a reusable compression instance.
// Reuses internal caches across calls for better performance.
type Compressor struct {
	pipeline      *filter.PipelineCoordinator
	customFilters *CustomFilter
}

// NewCompressor creates a reusable compressor.
func NewCompressor(opts ...Option) *Compressor {
	cfg := buildConfig(opts)
	pipelineCfg := cfg.toPipelineConfig()
	p := filter.NewPipelineCoordinator(&pipelineCfg)

	return &Compressor{pipeline: p, customFilters: cfg.customFilters}
}

// Compress applies the compression pipeline to the input text.
func (c *Compressor) Compress(text string) (string, Stats) {
	if text == "" {
		return "", Stats{}
	}
	output, pStats := c.pipeline.Process(text)
	if c.customFilters.Len() > 0 {
		output = c.customFilters.Apply(output)
	}
	return output, newStats(pStats)
}
