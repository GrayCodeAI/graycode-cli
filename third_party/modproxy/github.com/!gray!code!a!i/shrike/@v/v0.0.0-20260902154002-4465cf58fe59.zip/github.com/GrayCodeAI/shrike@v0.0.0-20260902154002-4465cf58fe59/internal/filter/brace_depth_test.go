package filter

import (
	"strings"
	"testing"
)

func TestNewBodyFilter(t *testing.T) {
	f := NewBodyFilter()
	if f == nil {
		t.Fatal("NewBodyFilter returned nil")
	}
}

func TestBodyFilterName(t *testing.T) {
	f := NewBodyFilter()
	if f.Name() != "body" {
		t.Errorf("expected name %q, got %q", "body", f.Name())
	}
}

func TestBodyFilterNonAggressive(t *testing.T) {
	f := NewBodyFilter()
	input := "func main() {\n\tfmt.Println(\"hello\")\n}"
	output, saved := f.Apply(input, ModeMinimal)
	if saved != 0 {
		t.Errorf("expected 0 tokens saved in non-aggressive mode, got %d", saved)
	}
	if output != input {
		t.Errorf("expected unchanged output in non-aggressive mode, got %q", output)
	}
}

func TestBodyFilterNonCode(t *testing.T) {
	f := NewBodyFilter()
	input := "This is just some regular text."
	output, saved := f.Apply(input, ModeAggressive)
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for non-code, got %d", saved)
	}
	if output != input {
		t.Errorf("expected unchanged output for non-code, got %q", output)
	}
}

func TestBodyFilterAddsPlaceholder(t *testing.T) {
	f := NewBodyFilter()
	input := `package main

func main() {
	fmt.Println("hello")
	fmt.Println("world")
}`
	output, _ := f.Apply(input, ModeAggressive)
	if !strings.Contains(output, "body stripped") {
		t.Error("expected body stripped marker to appear")
	}
	if !strings.Contains(output, "func main") {
		t.Error("function signature should be preserved")
	}
}

func TestBodyFilterEmptyInput(t *testing.T) {
	f := NewBodyFilter()
	output, saved := f.Apply("", ModeAggressive)
	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for empty input, got %d", saved)
	}
}

func TestBodyFilterIsFunctionStart(t *testing.T) {
	f := NewBodyFilter()
	tests := []struct {
		line     string
		lang     string
		expected bool
	}{
		{"func main() {", "go", true},
		{"func add(a, b int) int {", "go", true},
		{"fn main() {", "rust", true},
		{"def main():", "python", true},
		{"function main() {", "javascript", true},
		{"console.log(\"hello\")", "javascript", false},
		{"package main", "go", false},
	}

	for _, tt := range tests {
		t.Run(tt.line, func(t *testing.T) {
			result := f.isFunctionStart(tt.line, tt.lang)
			if result != tt.expected {
				t.Errorf("isFunctionStart(%q, %q) = %v, expected %v", tt.line, tt.lang, result, tt.expected)
			}
		})
	}
}
