package core

import (
	"reflect"
	"strings"
	"sync/atomic"
	"testing"
)

func TestEstimateTokensExact(t *testing.T) {
	t.Parallel()
	tests := []struct {
		input       string
		minExpected int // BPE is more accurate than heuristic, use minimum
	}{
		{"", 0},
		{"a", 1},
		{"ab", 1},
		{"abc", 1},
		{"abcd", 1},
		{"abcde", 1},
		{"abcd ef", 1},
		{"hello world", 2},
		{"abcdefghijklmnop", 1}, // BPE treats as single token
		{"The quick brown fox jumps over the lazy dog", 8}, // Longer text
	}
	for _, tt := range tests {
		got := EstimateTokens(tt.input)
		if got < tt.minExpected {
			t.Errorf("EstimateTokens(%q) = %d, want >= %d", tt.input, got, tt.minExpected)
		}
	}
}

func TestEstimateTokensPositive(t *testing.T) {
	t.Parallel()
	// Non-empty strings should always return >= 1 token
	inputs := []string{"a", "hello", "test string", "func main() {}"}
	for _, input := range inputs {
		got := EstimateTokens(input)
		if got < 1 {
			t.Errorf("EstimateTokens(%q) = %d, want >= 1", input, got)
		}
	}
}

func TestCalculateTokensSavedPositive(t *testing.T) {
	t.Parallel()
	saved := CalculateTokensSaved("hello world test", "hello")
	if saved <= 0 {
		t.Errorf("expected positive savings, got %d", saved)
	}
}

func TestCalculateTokensSavedZero(t *testing.T) {
	t.Parallel()
	zero := CalculateTokensSaved("hi", "hello world test more")
	if zero != 0 {
		t.Errorf("expected 0 for negative savings, got %d", zero)
	}
}

func TestCalculateTokensSavedEqual(t *testing.T) {
	t.Parallel()
	saved := CalculateTokensSaved("same", "same")
	if saved != 0 {
		t.Errorf("expected 0 for equal length, got %d", saved)
	}
}

func TestEstimateTokensConsistency(t *testing.T) {
	t.Parallel()
	text := "repeated calculation test"
	for i := 0; i < 100; i++ {
		a := EstimateTokens(text)
		b := EstimateTokens(text)
		if a != b {
			t.Fatalf("EstimateTokens not deterministic: %d != %d", a, b)
		}
	}
}

// TestEstimateTokensPreciseMatchesBPE pins EstimateTokensPrecise to exact
// tiktoken cl100k_base reference counts. If tiktoken-go is swapped or
// upgraded, these must stay stable — otherwise every `shrike gain` number
// in the wild becomes retroactively wrong.
func TestEstimateTokensPreciseMatchesBPE(t *testing.T) {
	t.Parallel()
	tests := []struct {
		text string
		want int
	}{
		{"", 0},
		{"a", 1},
		{"hello world", 2},
		{"The quick brown fox jumps over the lazy dog", 9},
		{"function main() { return 42; }", 9},
	}
	for _, tt := range tests {
		got := EstimateTokensPrecise(tt.text)
		if got != tt.want {
			t.Errorf("EstimateTokensPrecise(%q) = %d, want %d (BPE cl100k_base)",
				tt.text, got, tt.want)
		}
	}
}

// TestEstimateTokensPreciseShortString guards the bug that EstimateTokens
// takes a 200-char heuristic fast path, which silently undercounts short
// memory-file snippets. EstimateTokensPrecise must skip that fast path.
func TestEstimateTokensPreciseShortString(t *testing.T) {
	t.Parallel()
	short := "hello" // 5 chars — would trigger <30 heuristic in EstimateTokens
	fast := EstimateTokensFast(short)
	precise := EstimateTokensPrecise(short)
	if precise == 0 {
		t.Fatal("EstimateTokensPrecise returned 0 for non-empty input")
	}
	// They may disagree; that's the whole point.
	t.Logf("short=%q fast=%d precise=%d (difference acceptable; precise is authoritative)",
		short, fast, precise)
}

// TestTokenCacheHitAcrossCalls verifies the LRU cache returns a cached count
// for identical text across separate calls (and bumps the hit counter).
func TestTokenCacheHitAcrossCalls(t *testing.T) {
	t.Parallel()
	c := newTokenCache(64)
	c.set("hello token cache world", 5)

	got, ok := c.get("hello token cache world")
	if !ok {
		t.Fatal("expected cache hit for identical text")
	}
	if got != 5 {
		t.Errorf("cached count = %d, want 5", got)
	}
	if hits := atomic.LoadInt64(&c.hits); hits != 1 {
		t.Errorf("hits = %d, want 1", hits)
	}
}

// TestTokenCacheSameLengthDifferentTextMisses verifies hit validation:
// two distinct texts of identical length must not collide.
func TestTokenCacheSameLengthDifferentTextMisses(t *testing.T) {
	t.Parallel()
	c := newTokenCache(64)
	a := "aaaa first text"
	b := "bbbb second one" // same length, different content
	if len(a) != len(b) {
		t.Fatalf("test bug: lengths differ (%d vs %d)", len(a), len(b))
	}
	c.set(a, 7)

	if _, ok := c.get(b); ok {
		t.Error("different text with same length must be a cache miss")
	}
	if _, ok := c.get(a); !ok {
		t.Error("original text must still hit after miss probe")
	}
}

// TestTokenCacheOversizeTextBypassed verifies texts above the size cutoff
// never enter the LRU, so giant inputs cannot pin cache memory.
func TestTokenCacheOversizeTextBypassed(t *testing.T) {
	t.Parallel()
	c := newTokenCache(64)
	huge := strings.Repeat("x", maxCacheableTextBytes+1)

	c.set(huge, 12345)
	if _, ok := c.get(huge); ok {
		t.Errorf("text of %d bytes (> cutoff %d) must bypass the cache",
			len(huge), maxCacheableTextBytes)
	}

	// The boundary itself must still be cacheable.
	boundary := strings.Repeat("y", maxCacheableTextBytes)
	c.set(boundary, 42)
	if got, ok := c.get(boundary); !ok || got != 42 {
		t.Errorf("text exactly at cutoff must hit, got (count=%d, ok=%v)", got, ok)
	}
}

// TestCacheEntryDoesNotRetainText pins the memory fix: cacheEntry must not
// carry any string field. Storing the original text meant the 8192-entry LRU
// retained full prompts and every intermediate layer output.
func TestCacheEntryDoesNotRetainText(t *testing.T) {
	t.Parallel()
	typ := reflect.TypeOf(cacheEntry{})
	for i := 0; i < typ.NumField(); i++ {
		if typ.Field(i).Type.Kind() == reflect.String {
			t.Errorf("cacheEntry field %q is a string — the cache must not retain text",
				typ.Field(i).Name)
		}
	}
}
