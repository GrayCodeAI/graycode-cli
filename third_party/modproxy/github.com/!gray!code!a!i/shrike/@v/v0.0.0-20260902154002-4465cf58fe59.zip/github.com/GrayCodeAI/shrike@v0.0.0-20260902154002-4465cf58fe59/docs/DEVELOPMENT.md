# Development Guide

`shrike` is a **Go library** (module `github.com/GrayCodeAI/shrike`) for high-performance
text compression for LLM context windows. There is **no standalone `shrike` CLI binary**
and **no runnable artifact** — the public surface is the Go API. The familiar
`shrike ...` verbs that users may remember are exposed *through* [Hawk](https://github.com/GrayCodeAI/hawk),
which embeds this library (e.g. `hawk shrike compress`).

## Prerequisites

- **Go 1.24+** (the module targets a recent toolchain)
- **Git** (version control)
- **Make** (build automation)
- SQLite is **not** required — the tracker uses `modernc.org/sqlite` (pure Go)

### Recommended Tools

- **gopls** - Go language server (IDE support)
- **golangci-lint** - Meta linter
- **goimports** - Import management
- **staticcheck** - Static analysis

```bash
# Install development tools
go install golang.org/x/tools/cmd/goimports@latest
go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest
go install honnef.co/go/tools/cmd/staticcheck@latest
```

## Installation (as a consumer)

```bash
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

## Project Structure

```
shrike/
├── *.go                 # Public library API (package shrike): shrike.go, compress.go,
│                        #   options.go, secrets.go, extract.go, profile.go,
│                        #   filters.go, tracker.go, cost.go, perplexity.go, ...
├── internal/            # Private implementation packages
│   ├── filter/          # 31-layer compression pipeline (PipelineCoordinator)
│   ├── core/            # Tokenization / estimation core
│   ├── compress/        # Prompt-compression algorithm (PromptCompress)
│   ├── secrets/         # Secret detection & sensitive-filename rules
│   ├── extract/         # JSON extraction
│   └── tracking/        # SQLite gain tracking
├── rules/               # Bundled rule assets
├── benchmarks/          # Performance benchmarks (run.sh wraps `go test -bench`)
├── evals/               # Quality/eval pipeline (pipeline-bench.sh wraps `go test -bench`)
├── scripts/             # Build & dev scripts (build.sh, etc.)
├── examples/            # Runnable usage examples
└── docs/                # Documentation
```

## Getting Started

### 1. Clone

```bash
# Fork on GitHub, then clone
git clone https://github.com/YOUR_USERNAME/shrike.git
cd shrike

# Download dependencies
go mod download

# Build the library (and verify it compiles)
go build ./...
```

### 2. Run Tests

```bash
# All tests with race detector
make test

# Tests with coverage
make test-cover
open coverage.html

# Specific package
go test ./internal/filter/ -v

# Run with verbose
go test ./... -v
```

### 3. Run Linters

```bash
# Format code
make fmt

# Run go vet
make vet

# Type check
make typecheck

# Run golangci-lint
make lint

# Run all checks
make check
```

## Using the Library

All public entry points live in package `shrike` at the module root.

### Compression

```go
import "github.com/GrayCodeAI/shrike"

// Default (quality-first) compression.
compressed, stats := shrike.Compress(text)

// Aggressive mode.
compressed, stats := shrike.Compress(text, shrike.Aggressive)

// Hard token budget.
compressed, stats := shrike.Compress(text, shrike.WithBudget(4000))

// Code-aware: preserve function/type signatures for a language.
compressed, stats := shrike.Compress(src, shrike.WithCodeAware("go"))

// Perplexity-guided selective token dropping (LLMLingua-style, opt-in).
compressed, stats := shrike.Compress(text, shrike.WithPerplexityGuided(scorer, 0.3))
```

### Prompt Compression

A self-contained, deterministic prose compressor (independent of the main
pipeline) with three intensity levels:

```go
out, stats := shrike.PromptCompress(prompt, shrike.IntensityLite)
out, stats := shrike.PromptCompress(prompt, shrike.IntensityFull)
out, stats := shrike.PromptCompress(prompt, shrike.IntensityUltra)
```

### Token Estimation & Cost

```go
n := shrike.EstimateTokensForModel(text, "gpt-4o")
saved := shrike.EstimateCostSavings(stats, "gpt-4o")
human := shrike.FormatCostSavings(stats, "claude-4")
```

### Secrets & Sensitive Filenames

```go
det := shrike.NewSecretDetector()
matches := det.DetectSecrets(text)
clean := det.RedactSecrets(text)

sensitive, match := shrike.IsSensitiveFilename("/home/user/.ssh/id_rsa")
```

### JSON Extraction

```go
out := shrike.ExtractJSON(`Sure! Here's the data: {"name": "alice"}`)
// out.JSON = `{"name": "alice"}`, out.Found = true
```

### Persistent Gain Tracking

```go
tr, err := shrike.NewTracker(ctx) // ~/.shrike/tracker.db, WAL, 90-day retention
defer tr.Close()
_ = tr.Record(ctx, ev)
agg, _ := tr.Aggregate(ctx, 30)
```

### Custom Filters & Profiles

Custom filters are user-defined regex find/replace rules loaded from a TOML
file and applied as a post-pipeline stage:

```go
rules, _ := shrike.LoadFilterRules(filepath.Join(home, ".shrike", "filters.toml"))
out, stats := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

Profiles are named, shareable bundles of settings (mode/tier/budget/filters):

```go
p, _ := shrike.LoadProfile(".shrike/profiles/code-safe.toml")
out, stats := shrike.Compress(text, p.Options()...)
```

## Development Workflow

### Feature Development

```bash
# 1. Create feature branch
git checkout -b feat/my-new-feature

# 2. Make changes
# ... edit code ...

# 3. Run checks
make check

# 4. Commit
git commit -m "feat: add my new feature"

# 5. Push
git push origin feat/my-new-feature
```

### Bug Fix Workflow

```bash
# 1. Create bug branch from main
git checkout -b fix/bug-description

# 2. Add test that reproduces bug
# ... write failing test ...

# 3. Fix code
# ... implement fix ...

# 4. Verify test passes
make test

# 5. Run full check suite
make check

# 6. Commit and push
git add .
git commit -m "fix: resolve bug description"
git push origin fix/bug-description
```

## Code Style

### Formatting

Follow standard Go formatting:

```bash
# Auto-format
go fmt ./...

# Use goimports for imports
goimports -w .
```

### Import Organization

```go
// Standard library first
import (
    "context"
    "fmt"
    "os"
    "time"

    // Third-party second
    "github.com/BurntSushi/toml"

    // Internal packages last
    "github.com/GrayCodeAI/shrike/internal/core"
    "github.com/GrayCodeAI/shrike/internal/filter"
)
```

### Naming Conventions

**Packages:** Lowercase, short, no underscores
```go
package filter       // ✓
package filter_manager  // ✗ (too long)
package filters      // ✗ (plural)
```

**Types:** PascalCase
```go
type PipelineCoordinator struct { }    // ✓
type pipeline_coordinator struct { }   // ✗
```

**Interfaces:** -er suffix for action interfaces
```go
type Runner interface { }        // ✓
type Reader interface { }        // ✓
type Filterable interface { }    // ✓
```

**Constants:** PascalCase or ALL_CAPS for special values
```go
const DefaultTimeout = 30 * time.Second   // ✓
const MAX_BUFFER_SIZE = 65536             // ✓ (special values)
```

**Variables:** camelCase
```go
var filteredOutput string   // ✓
var OutputFiltered string   // ✗
```

### Function Design

**Single responsibility:**
```go
// ✓ Good: Does one thing well
func FilterOutput(input string, mode filter.Mode) (string, int) {
    // Filter implementation
}

// ✗ Bad: Does too many things
func ProcessAndFilterAndSave(input string) {
    // ...
}
```

**Return errors properly:**
```go
// ✓ Good: Named errors for checking
var ErrConfigNotFound = errors.New("config file not found")

func LoadConfig(path string) (*Config, error) {
    if _, err := os.Stat(path); os.IsNotExist(err) {
        return nil, fmt.Errorf("load config: %w", ErrConfigNotFound)
    }
    // ...
}
```

**Use context for cancellable operations:**
```go
// ✓ Good: Context for cancellation
func RunWork(ctx context.Context) (string, error) {
    // ...
}
```

### Error Handling Pattern

```go
// 1. Define error variables
var (
    ErrFilterNotFound   = errors.New("filter not found")
    ErrBudgetExceeded   = errors.New("token budget exceeded")
    ErrInvalidInput     = errors.New("invalid input")
)

// 2. Wrap errors with context
func Process(input string) error {
    if err := validate(input); err != nil {
        return fmt.Errorf("process input: %w", err)
    }
    // ...
}

// 3. Check specific errors
func HandleError(err error) {
    if errors.Is(err, ErrFilterNotFound) {
        // Handle specific case
        return
    }
    // ...
}
```

### Testing Standards

#### Table-Driven Tests

```go
func TestFilterApply(t *testing.T) {
    tests := []struct {
        name          string
        input         string
        mode          filter.Mode
        expected      string
        expectError   bool
    }{
        {
            name:        "empty input",
            input:       "",
            mode:        filter.ModeMinimal,
            expected:    "",
            expectError: false,
        },
        {
            name:        "simple case",
            input:       "hello world\nline 2",
            mode:        filter.ModeMinimal,
            expected:    "hello world\nline 2",
            expectError: false,
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            f := NewFilter()
            result, err := f.Apply(tt.input, tt.mode)

            if tt.expectError {
                assert.Error(t, err)
                return
            }

            assert.NoError(t, err)
            assert.Equal(t, tt.expected, result)
        })
    }
}
```

#### Golden File Tests

```go
func TestFilterGoldenOutput(t *testing.T) {
    input := loadFile(t, "testdata/input.txt")
    expected := loadFile(t, "testdata/golden_output.txt")

    filter := NewFilter()
    result, _ := filter.Apply(input, filter.ModeMinimal)

    if result != expected {
        // Update golden file with -update flag
        if *update {
            os.WriteFile("testdata/golden_output.txt", []byte(result), 0644)
            return
        }
        t.Errorf("output mismatch")
    }
}
```

#### Benchmark Tests

```go
func BenchmarkCompress(b *testing.B) {
    input := generateLargeInput(10000)  // 10K tokens

    b.ResetTimer()
    for i := 0; i < b.N; i++ {
        shrike.Compress(input)
    }
}

func BenchmarkCompress_Parallel(b *testing.B) {
    input := generateLargeInput(10000)

    b.ResetTimer()
    b.RunParallel(func(pb *testing.PB) {
        for pb.Next() {
            shrike.Compress(input)
        }
    })
}
```

### Logging

Use the internal utils logger from within the implementation packages:

```go
import "github.com/GrayCodeAI/shrike/internal/utils"

// Different log levels
utils.Logger.Debug("Debug message with values", "key", value)
utils.Logger.Info("Operation successful")
utils.Logger.Warn("Potential issue detected")
utils.Logger.Error("Something went wrong", "error", err)

// Structured logging
utils.Logger.Info("Pipeline processed",
    "tokens_in", inputTokens,
    "tokens_out", outputTokens,
    "saved", saved,
    "duration", duration,
)
```

### Adding a Public Option

The library's behavior is configured through functional options
(`shrike.Option`) defined in `options.go`. To add one:

```go
// options.go

// WithExample documents what the option does.
func WithExample(v int) Option {
    return optFunc(func(c *config) { c.example = v })
}
```

1. Add the backing field to the `config` struct in `options.go`.
2. Add the `WithX` constructor returning an `Option`.
3. Thread the field into `config.toPipelineConfig()` (or apply it as a
   post-pipeline stage in `Compress`, as `WithCustomFilters` /
   `WithPerplexityGuided` do).
4. Add a table-driven test covering the new behavior.

### Filter Layer Development

The 31-layer pipeline lives in `internal/filter`. Adding a new layer:

```go
// internal/filter/my_layer.go

package filter

// MyLayer implements the Layer interface.
type MyLayer struct {
    threshold float64
}

// NewMyLayer creates a new MyLayer.
func NewMyLayer() *MyLayer {
    return &MyLayer{threshold: 0.5}
}

// Name returns the layer name.
func (l *MyLayer) Name() string { return "my_layer" }

// Apply processes the input and returns filtered text and tokens saved.
func (l *MyLayer) Apply(input string, mode Mode) (string, int) {
    output := doFiltering(input, mode)
    tokensSaved := EstimateTokens(input) - EstimateTokens(output)
    return output, tokensSaved
}

// ShouldSkip checks if this layer would provide value.
func (l *MyLayer) ShouldSkip(input string, config PipelineConfig) bool {
    return len(input) < 50 // Skip for short inputs
}
```

Then wire it into the pipeline:

1. Add a config flag to `PipelineConfig`
2. Add a field to `PipelineCoordinator`
3. Initialize in `NewPipelineCoordinator()`
4. Add a `processLayer()` method
5. Add it to the `Process()` execution order

## Build Commands

This is a library, so there is no application binary to produce. Common targets:

```bash
# Compile everything (library, examples) and verify it builds
go build ./...

# Verify the library compiles and run go vet
./scripts/build.sh

# Run all checks (fmt, vet, lint, test)
make check
```

## Performance Profiling

### CPU Profiling

```bash
# Generate CPU profile
go test -cpuprofile=cpu.prof -bench=BenchmarkCompress ./internal/filter/

# Analyze
go tool pprof cpu.prof

# Top functions
(pprof) top

# Web visualization
(pprof) web
```

### Memory Profiling

```bash
# Generate memory profile
go test -memprofile=mem.prof -bench=BenchmarkCompress ./internal/filter/

# Analyze
go tool pprof mem.prof

# Top allocations
(pprof) top
```

### Benchmarking

Benchmarks and evals are plain `go test -bench` runs, wrapped by scripts:

```bash
# Library benchmarks
./benchmarks/run.sh

# End-to-end eval/quality pipeline
./evals/pipeline-bench.sh

# Detailed benchmarks for a single package
go test -bench=. -benchmem ./internal/filter/

# Compare benchmarks
benchstat old.txt new.txt
```

## Debugging

### Debug with Delve

```bash
# Install Delve
go install github.com/go-delve/delve/cmd/dlv@latest

# Debug tests
dlv test ./internal/filter/

# Breakpoints
(dlv) break internal/filter/pipeline.go:42
(dlv) continue
```

### Debug Logging

```bash
# Enable debug logging for tests
export TOK_LOG=debug
```

## Common Tasks

### Adding a New Dependency

```bash
# Get the package
go get github.com/example/package

# Tidy up
go mod tidy

# Verify
go mod verify
```

### Updating Dependencies

```bash
# Check for updates
go list -u -m all

# Update specific package
go get github.com/example/package@latest

# Update all
go get -u ./...
go mod tidy
```

### Creating a Release

```bash
# 1. Update CHANGELOG.md
# 2. Bump the version in VERSION (and version.go if applicable)
# 3. Run all checks
make check

# 4. Tag release
git tag v0.29.0
git push origin v0.29.0

# 5. Publish the GitHub release (e.g. via goreleaser)
goreleaser release --clean
```

Because shrike is a library, "releasing" is primarily tagging a new module
version that consumers can `go get`.

## Troubleshooting

### Build Fails

```bash
# Clean module cache state and re-fetch
go clean -cache
go mod download

# Check Go version
go version  # Must be 1.24+

# Recompile
go build ./...
```

### Tests Fail

```bash
# Run with verbose
go test ./... -v

# Specific package
go test ./internal/filter/ -v

# Skip race detector (faster)
go test ./...

# Update golden files
go test ./... -update
```

### Linter Errors

```bash
# See all issues
golangci-lint run

# Auto-fix
golangci-lint run --fix

# Check specific linter
golangci-lint run --enable=staticcheck
```

## CI/CD Integration

### GitHub Actions

The project uses GitHub Actions for:

- Running tests on push/PR
- Linting and type checking
- Building the library across platforms

### Local CI Simulation

```bash
# Simulate CI checks locally
make check

# Cross-compile to catch platform issues
GOOS=linux   GOARCH=amd64 go build ./...
GOOS=darwin  GOARCH=arm64 go build ./...
GOOS=windows GOARCH=amd64 go build ./...
```

## Best Practices

1. **Write tests** for new functionality and bug fixes
2. **Document changes** in CHANGELOG.md
3. **Follow Go conventions** (Effective Go)
4. **Keep PRs focused** — one change per PR
5. **Keep the public API stable** — new behavior should be opt-in via `WithX` options
6. **Update docs** when behavior changes
7. **Comment the why**, not the what
8. **Handle errors** properly — don't ignore them
9. **Avoid globals** — pass dependencies explicitly
10. **Optimize last** — first correct, then clear, then fast

---

**Happy coding!** 🚀

See also: the consumer-facing CLI verbs (`hawk shrike compress`, etc.) live in
[Hawk](https://github.com/GrayCodeAI/hawk), which embeds this library.
