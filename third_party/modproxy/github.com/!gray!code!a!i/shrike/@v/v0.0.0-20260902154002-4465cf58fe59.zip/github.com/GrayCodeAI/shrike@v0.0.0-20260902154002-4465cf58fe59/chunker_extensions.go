package shrike

import (
	"path/filepath"
	"strings"
)

// extensionLanguageMap maps file extensions to language names.
var extensionLanguageMap = map[string]string{
	// Go
	".go": "go",
	// Python
	".py":  "python",
	".pyw": "python",
	// TypeScript / JavaScript
	".ts":  "typescript",
	".tsx": "tsx",
	".js":  "javascript",
	".jsx": "jsx",
	// Rust
	".rs": "rust",
	// Java
	".java": "java",
	// Ruby
	".rb": "ruby",
	// PHP
	".php": "php",
	// C
	".c": "c",
	".h": "c",
	// C++
	".cpp": "cpp",
	".cc":  "cpp",
	".cxx": "cpp",
	".hpp": "cpp",
	// C#
	".cs": "csharp",
	// Kotlin
	".kt":  "kotlin",
	".kts": "kotlin",
	// Swift
	".swift": "swift",
	// Dart
	".dart": "dart",
	// Shell
	".sh":   "bash",
	".bash": "bash",
	// SQL
	".sql": "sql",
	// HTML
	".html": "html",
	".htm":  "html",
	// CSS
	".css": "css",
	// Vue
	".vue": "vue",
	// Zig
	".zig": "zig",
	// Elixir
	".ex":  "elixir",
	".exs": "elixir",
	// Scala
	".scala": "scala",
	// Lua
	".lua": "lua",
	// R
	".r": "r",
	".R": "r",
	// Markdown
	".md": "markdown",
	// Objective-C / Objective-C++
	".m":  "objective-c",
	".mm": "objective-cpp",
	// Perl
	".pl": "perl",
	".pm": "perl",
	// Haskell
	".hs":  "haskell",
	".lhs": "haskell",
	// Erlang
	".erl": "erlang",
	".hrl": "erlang",
	// Clojure
	".clj":  "clojure",
	".cljs": "clojure",
	// F#
	".fs":  "fsharp",
	".fsx": "fsharp",
	// OCaml
	".ml":  "ocaml",
	".mli": "ocaml",
	// Julia
	".jl": "julia",
	// Nim
	".nim": "nim",
	// Crystal
	".cr": "crystal",
	// V
	".v": "v",
	// VHDL
	".vhdl": "vhdl",
	// Solidity
	".sol": "solidity",
	// Protobuf
	".proto": "protobuf",
	// GraphQL
	".graphql": "graphql",
	".gql":     "graphql",
	// Terraform / HCL
	".tf":  "terraform",
	".hcl": "hcl",
	// CMake
	".cmake": "cmake",
	// Gradle
	".gradle": "gradle",
	// Groovy
	".groovy": "groovy",
	// PowerShell
	".ps1":  "powershell",
	".psm1": "powershell",
	// Batch
	".bat": "batch",
	".cmd": "batch",
	// Fish
	".fish": "fish",
	// Vim
	".vim": "vim",
	// Emacs Lisp
	".el": "elisp",
	// Racket
	".rkt": "racket",
	// Pascal
	".pas": "pascal",
	// D
	".d": "d",
	// Ada
	".ada": "ada",
	".adb": "ada",
	// Fortran
	".f90": "fortran",
	".f95": "fortran",
	// COBOL
	".cob": "cobol",
	// Svelte
	".svelte": "svelte",
	// Astro
	".astro": "astro",
	// Prisma
	".prisma": "prisma",
	// dotenv
	".env": "dotenv",
	// INI / Config
	".ini": "ini",
	".cfg": "ini",
	// Config files
	".conf": "conf",
	// Nginx
	".nginx": "nginx",
	// Dockerfile
	".dockerfile":    "dockerfile",
	".containerfile": "dockerfile",
	// Nix
	".nix": "nix",
	// Dhall
	".dhall": "dhall",
	// Jsonnet
	".jsonnet": "jsonnet",
	// Starlark
	".starlark": "starlark",
	".bzl":      "starlark",
	// WebAssembly
	".wasm": "wasm",
	".wat":  "wat",
	// YAML
	".yaml": "yaml",
	".yml":  "yaml",
	// JSON
	".json": "json",
	// TOML
	".toml": "toml",
	// XML
	".xml": "xml",
	// SCSS / SASS / LESS
	".scss": "scss",
	".sass": "sass",
	".less": "less",
	// CoffeeScript
	".coffee": "coffeescript",
	// Elm
	".elm": "elm",
	// PureScript
	".purs": "purescript",
	// Assembly
	".asm": "assembly",
	".s":   "assembly",
	// Makefile
	".mk": "makefile",
	// Diff / Patch
	".diff":  "diff",
	".patch": "diff",
	// LaTeX
	".tex": "latex",
	// reStructuredText
	".rst": "rst",
	// Org-mode
	".org": "org",
	// CSV / TSV
	".csv": "csv",
	".tsv": "tsv",
	// Dockerfile special
	".Dockerfile": "dockerfile",
	// Scheme
	".scm": "scheme",
	// Common Lisp
	".lisp": "commonlisp",
	".cl":   "commonlisp",
	// Prolog
	".pro": "prolog",
	// Tcl
	".tcl": "tcl",
	// R Markdown
	".rmd": "rmarkdown",
	// Jupyter
	".ipynb": "jupyter",
	// Terraform vars
	".tfvars": "terraform",
	// Protocol Buffers
	".pb": "protobuf",
	// Thrift
	".thrift": "thrift",
	// Avro
	".avsc": "avro",
	// GLSL / HLSL
	".glsl": "glsl",
	".hlsl": "hlsl",
	// Cuda
	".cu":  "cuda",
	".cuh": "cuda",
	// CMakeLists
	".cmake.in": "cmake",
	// Vagrant
	".vagrantfile": "ruby",
	// Puppet
	".pp": "puppet",
	// Chef
	".erb": "erb",
	// Ansible
	".j2": "jinja2",
	// Svelte
	".svx": "svelte",
	// MDX
	".mdx": "mdx",
}

// DetectLanguageByExtension returns the programming language name for a file
// path based on its extension. Returns "" for unknown extensions.
func DetectLanguageByExtension(path string) string {
	ext := filepath.Ext(path)
	if ext == "" {
		return ""
	}
	if lang, ok := extensionLanguageMap[ext]; ok {
		return lang
	}
	// Try lowercase for case-insensitive matching (except .R which is special)
	if lang, ok := extensionLanguageMap[strings.ToLower(ext)]; ok {
		return lang
	}
	return ""
}
