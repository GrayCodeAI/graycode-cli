package filter

import (
	"math"
	"strings"
	"unicode"

	"github.com/GrayCodeAI/shrike/internal/core"
)

// Paper: "LLMLingua" — Jiang et al., Microsoft, 2023 (https://arxiv.org/abs/2310.05736)
// Paper: "LongLLMLingua" — Jiang et al., Microsoft, 2024 (https://arxiv.org/abs/2310.06839)
//
// LLMLinguaProseFilter is an OPT-IN prose compressor that approximates the
// coarse-to-fine token dropping of LLMLingua using purely local statistics —
// no model calls, keeping shrike a zero-dependency leaf. It estimates a per-token
// "surprise" (a perplexity proxy from corpus n-gram statistics), then drops the
// least-informative sentences, the same intuition LLMLingua uses to prune
// predictable filler while preserving information-dense spans.
//
// It is deliberately conservative: it only runs on natural-language prose
// (never code), skips short inputs, and always preserves the first and last
// sentence for narrative continuity.
type LLMLinguaProseFilter struct {
	enabled bool

	// keepRatio is the fraction of sentences to retain in ModeNone. Aggressive
	// modes scale this down. Clamped to (0, 1].
	keepRatio float64

	// minLength is the minimum input size (bytes) before the filter activates.
	minLength int

	// Importance keywords mirror SemanticFilter: their presence boosts a
	// sentence's score so we never drop error/decision-bearing lines.
	highImportanceKeywords []string
}

// NewLLMLinguaProseFilter creates a prose compressor with default tuning.
func NewLLMLinguaProseFilter() *LLMLinguaProseFilter {
	return &LLMLinguaProseFilter{
		enabled:   true,
		keepRatio: 0.6,
		minLength: 200,
		highImportanceKeywords: []string{
			"error", "failed", "failure", "fatal", "panic", "exception",
			"critical", "warning", "must", "required", "important", "note",
			"because", "therefore", "however", "decision", "result",
		},
	}
}

// NewLLMLinguaProseFilterWithConfig builds the filter with explicit tuning.
// Non-positive values fall back to defaults.
func NewLLMLinguaProseFilterWithConfig(keepRatio float64, minLength int) *LLMLinguaProseFilter {
	f := NewLLMLinguaProseFilter()
	if keepRatio > 0 && keepRatio <= 1 {
		f.keepRatio = keepRatio
	}
	if minLength > 0 {
		f.minLength = minLength
	}
	return f
}

// Name returns the filter name.
func (f *LLMLinguaProseFilter) Name() string {
	return "llmlingua_prose"
}

// IsEnabled reports whether the filter is active (EnableCheck interface).
func (f *LLMLinguaProseFilter) IsEnabled() bool {
	return f.enabled
}

// IsApplicable gates the filter to natural-language prose only
// (ApplicabilityCheck interface). Code and short inputs are passed through.
func (f *LLMLinguaProseFilter) IsApplicable(input string) bool {
	if len(input) < f.minLength {
		return false
	}
	return isProseText(input)
}

// Apply drops the least-informative sentences from prose input.
func (f *LLMLinguaProseFilter) Apply(input string, mode Mode) (string, int) {
	if !f.enabled || mode == ModeNone {
		return input, 0
	}
	if len(input) < f.minLength || !isProseText(input) {
		return input, 0
	}

	sentences := splitProseSentences(input)
	if len(sentences) < 4 {
		// Too little structure to prune safely.
		return input, 0
	}

	// Build a corpus bigram model to estimate per-token surprise.
	model := newProseLM(input)

	scores := make([]float64, len(sentences))
	for i, s := range sentences {
		scores[i] = f.scoreSentence(s, model)
	}

	keepRatio := f.keepRatio
	if mode == ModeAggressive {
		keepRatio *= 0.6
	}

	threshold := percentileThreshold(scores, 1.0-keepRatio)

	var kept []string
	for i, s := range sentences {
		// Always keep the first and last sentence for continuity, and any
		// sentence scoring at or above the threshold.
		if i == 0 || i == len(sentences)-1 || scores[i] >= threshold {
			kept = append(kept, s)
		}
	}

	output := strings.Join(kept, " ")
	saved := core.CalculateTokensSaved(input, output)
	if saved < 0 {
		// Never report negative savings or risk growing the input.
		return input, 0
	}
	return output, saved
}

// scoreSentence estimates the information value of a sentence: a perplexity
// proxy (mean token surprise) combined with importance-keyword and
// unique-token signals. Higher is more worth keeping.
func (f *LLMLinguaProseFilter) scoreSentence(sentence string, model *proseLM) float64 {
	words := tokenize(strings.ToLower(sentence))
	if len(words) == 0 {
		return 0.0
	}

	surprise := model.meanSurprise(words)

	// Keyword boost: information-bearing words protect a sentence.
	lower := strings.ToLower(sentence)
	keywordBoost := 0.0
	for _, kw := range f.highImportanceKeywords {
		if strings.Contains(lower, kw) {
			keywordBoost += 0.5
		}
	}

	// Vocabulary diversity rewards dense, non-repetitive sentences.
	unique := uniqueWordRatio(words)

	return 0.6*surprise + 0.3*unique + keywordBoost
}

// proseLM is a tiny bigram language model over the input corpus used to
// approximate token perplexity locally.
type proseLM struct {
	unigram map[string]int
	bigram  map[string]int
	total   int
}

func newProseLM(input string) *proseLM {
	m := &proseLM{
		unigram: make(map[string]int),
		bigram:  make(map[string]int),
	}
	words := tokenize(strings.ToLower(input))
	m.total = len(words)
	for i, w := range words {
		m.unigram[w]++
		if i > 0 {
			m.bigram[words[i-1]+"\x00"+w]++
		}
	}
	return m
}

// meanSurprise returns the average negative log-probability of the tokens in
// words under the bigram model (backing off to unigram). Rare/surprising
// sequences score higher, mirroring LLMLingua's perplexity signal.
func (m *proseLM) meanSurprise(words []string) float64 {
	if len(words) == 0 || m.total == 0 {
		return 0.0
	}
	vocab := float64(len(m.unigram)) + 1.0
	var sum float64
	for i, w := range words {
		var prob float64
		if i > 0 {
			prevCount := m.unigram[words[i-1]]
			bi := m.bigram[words[i-1]+"\x00"+w]
			// Laplace-smoothed bigram probability.
			prob = (float64(bi) + 1.0) / (float64(prevCount) + vocab)
		} else {
			prob = (float64(m.unigram[w]) + 1.0) / (float64(m.total) + vocab)
		}
		if prob <= 0 {
			prob = 1.0 / (float64(m.total) + vocab)
		}
		sum += -math.Log2(prob)
	}
	// Normalize roughly into [0, 1]: log2(vocab) is the worst-case surprise.
	mean := sum / float64(len(words))
	norm := mean / (math.Log2(vocab) + 1.0)
	if norm > 1.0 {
		norm = 1.0
	}
	return norm
}

// splitProseSentences splits prose into sentences on terminal punctuation while
// keeping the punctuation attached. Newlines are treated as soft boundaries.
func splitProseSentences(input string) []string {
	var sentences []string
	var b strings.Builder
	flush := func() {
		s := strings.TrimSpace(b.String())
		if s != "" {
			sentences = append(sentences, s)
		}
		b.Reset()
	}

	runes := []rune(input)
	for i, r := range runes {
		b.WriteRune(r)
		switch r {
		case '.', '!', '?':
			// Sentence boundary when followed by space/EOL.
			if i+1 >= len(runes) || unicode.IsSpace(runes[i+1]) {
				flush()
			}
		case '\n':
			flush()
		}
	}
	flush()
	return sentences
}

// isProseText reports whether input looks like natural-language prose rather
// than source code. It uses symbol density and letter ratio instead of the
// substring-based IsCode heuristic, which yields false positives on prose
// (e.g. "use " inside "because ").
func isProseText(input string) bool {
	var letters, codeSymbols, total int
	for _, r := range input {
		if r == ' ' || r == '\n' || r == '\t' || r == '\r' {
			continue
		}
		total++
		switch {
		case unicode.IsLetter(r):
			letters++
		case strings.ContainsRune("{}[]()<>=+*/\\|&;`#$@~_", r):
			codeSymbols++
		}
	}
	if total == 0 {
		return false
	}
	letterRatio := float64(letters) / float64(total)
	symbolRatio := float64(codeSymbols) / float64(total)
	// Prose is letter-dominant with few code symbols.
	return letterRatio >= 0.7 && symbolRatio < 0.05
}

// uniqueWordRatio measures vocabulary diversity for a token slice.
func uniqueWordRatio(words []string) float64 {
	if len(words) == 0 {
		return 0.0
	}
	seen := make(map[string]struct{}, len(words))
	for _, w := range words {
		seen[w] = struct{}{}
	}
	return float64(len(seen)) / float64(len(words))
}

// percentileThreshold returns the value at the given fraction (0..1) of the
// sorted scores, i.e. the cutoff that drops that fraction of the lowest scores.
func percentileThreshold(scores []float64, fraction float64) float64 {
	if len(scores) == 0 {
		return 0.0
	}
	if fraction <= 0 {
		return math.Inf(-1)
	}
	if fraction >= 1 {
		return math.Inf(1)
	}
	sorted := make([]float64, len(scores))
	copy(sorted, scores)
	// Simple insertion sort — sentence counts are small.
	for i := 1; i < len(sorted); i++ {
		v := sorted[i]
		j := i - 1
		for j >= 0 && sorted[j] > v {
			sorted[j+1] = sorted[j]
			j--
		}
		sorted[j+1] = v
	}
	idx := int(fraction * float64(len(sorted)))
	if idx >= len(sorted) {
		idx = len(sorted) - 1
	}
	return sorted[idx]
}
