package graph_test

import (
	"encoding/json"
	"testing"
	"time"

	graph "github.com/GrayCodeAI/shrike/graph"
)

// TestSchemaParity locks the vendored graph contract to the upstream JSON
// shape so hawk's facade aliases and JSON round-trips keep working.
func TestSchemaParity(t *testing.T) {
	n := graph.Node{
		ID:        "n1",
		Kind:      graph.NodeOperations,
		Scope:     graph.Scope{RepositoryID: "repo"},
		CreatedAt: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Provenance: graph.Provenance{
			Producer: "test",
		},
	}
	payload, err := json.Marshal(n)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	if got := string(payload); got != `{"id":"n1","kind":"operations","scope":{"repository_id":"repo"},"created_at":"2024-01-01T00:00:00Z","effective_at":"0001-01-01T00:00:00Z","provenance":{"producer":"test"}}` {
		t.Fatalf("unexpected JSON shape: %s", got)
	}
	if err := n.Validate(); err != nil {
		t.Fatalf("validate: %v", err)
	}
}
