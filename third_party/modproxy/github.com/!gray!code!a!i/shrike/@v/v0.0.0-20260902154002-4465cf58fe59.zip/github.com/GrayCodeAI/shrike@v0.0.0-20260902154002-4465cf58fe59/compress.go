// Prompt compression — public API.
//
// This file exposes the algorithm (port from prompt-compression algorithm)
// as a top-level shrike API. It is independent of the main compression pipeline
// and does not use tiers/modes/budgets; it is a self-contained, deterministic
// prose compression function with three intensity levels.
//
// Usage:
//
//	out, stats := shrike.PromptCompress("Sure, I can help you with that.", shrike.IntensityLite)
//	out, stats := shrike.PromptCompress(prompt, shrike.IntensityUltra)
//
// The function NEVER modifies sensitive segments (security warnings, destructive
// commands, credential mentions) — those are passed through verbatim regardless
// of intensity. CJK text is also passed through unchanged (the rules assume
// Latin grammar).
package shrike

import "github.com/GrayCodeAI/shrike/internal/compress"

// Intensity selects how aggressive prompt compression should be.
//
//   - IntensityLite:   drops pleasantries only ("Sure", "Of course", "Please").
//   - IntensityFull:   Lite + articles ("a", "an", "the") + filler + hedging.
//   - IntensityUltra:  Full + conjunctions + intensifiers + redundant pronouns.
//
// Each level is a superset of the previous; higher intensity never produces
// a longer output than a lower intensity on the same input.
type Intensity = compress.Intensity

// Intensity preset constants. Use as a direct argument to PromptCompress.
const (
	IntensityLite  Intensity = compress.Lite
	IntensityFull  Intensity = compress.Full
	IntensityUltra Intensity = compress.Ultra
)

// PromptStats is the statistics struct returned from PromptCompress.
type PromptStats = compress.Stats

// PromptCompress applies the prompt-compression algorithm to text.
//
// Behavior:
//   - Empty input returns ("", zero stats).
//   - Sensitive segments (security/destructive keywords) are preserved verbatim.
//   - CJK text is passed through unchanged.
//   - Multi-word drop-list entries are matched as whole phrases.
//   - Dictionary substitutions preserve the case of the first character.
//
// This is independent of shrike.Compress() and does not consume options/presets.
func PromptCompress(text string, intensity Intensity) (string, PromptStats) {
	return compress.Compress(text, intensity)
}
