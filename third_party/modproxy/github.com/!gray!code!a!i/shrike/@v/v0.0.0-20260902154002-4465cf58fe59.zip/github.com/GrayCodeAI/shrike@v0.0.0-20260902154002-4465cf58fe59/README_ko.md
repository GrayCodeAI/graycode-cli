# shrike

[![Go](https://img.shields.io/badge/Go-1.22+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> LLM 토큰 압축, 필터링, 추정 및 시크릿 스캐닝을 위한 Go 라이브러리.

## 설치

```bash
go get github.com/GrayCodeAI/shrike
```

## 문서

전체 문서는 [영문 README](README.md)를 참조하세요.

## 'shrike' 서브커맨드

'shrike' 서브커맨드는 Hawk([github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk))를 통해 제공됩니다.

## 라이선스

[MIT](LICENSE)
