//go:build amd64 && !race

package fastops

func init() {
	f := Detect()
	if f.HasAVX2 {
		avx2HasANSI = hasANSIavx2
		avx2CountBytes = countBytesAVX2
	}
}
