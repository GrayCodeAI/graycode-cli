# Published Shrike Benchmark Runs

This directory is reserved for benchmark runs that are important enough to treat as evidence.

Expected per-run files:

- `report.md`
- `result.txt`
- `notes.md`

Only commit runs that are intended to serve as:

- baselines
- release notes evidence
- comparison evidence in docs

Current published runs:

- `shrike-quality-core/2026-06-27/`
- `shrike-pipeline-microbench/2026-06-27/`
