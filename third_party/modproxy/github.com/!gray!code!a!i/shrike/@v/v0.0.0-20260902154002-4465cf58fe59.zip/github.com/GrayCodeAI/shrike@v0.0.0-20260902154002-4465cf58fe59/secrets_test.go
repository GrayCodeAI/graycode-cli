package shrike

import (
	"strings"
	"testing"
)

func TestSecretDetector_AWSAccessKey(t *testing.T) {
	sd := NewSecretDetector()
	text := "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "AWS Access Key" && m.Value == "AKIAIOSFODNN7EXAMPLE" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect AWS Access Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_AWSSecretKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `aws_secret_access_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "AWS Secret Key" && m.Value == "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect AWS Secret Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_GitHubToken(t *testing.T) {
	sd := NewSecretDetector()
	tests := []struct {
		name  string
		input string
	}{
		{"ghp token", "token: ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"},
		{"gho token", "GITHUB_TOKEN=gho_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"},
		{"ghs token", "secret: ghs_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"},
		{"ghr token", "ref: ghr_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			matches := sd.DetectSecrets(tt.input)
			found := false
			for _, m := range matches {
				if m.Type == "GitHub Token" {
					found = true
					break
				}
			}
			if !found {
				t.Errorf("expected to detect GitHub Token in %q, got matches: %+v", tt.input, matches)
			}
		})
	}
}

func TestSecretDetector_GitLabToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "GitLab Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect GitLab Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_SlackBotToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "SLACK_TOKEN=xoxb-" + "1234567890123-0987654321098-AbCdEfGhIjKlMn"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Slack Bot Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Slack Bot Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_SlackUserToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "token=xoxp-1234567890123-1234567890123-AbCdEfGhIjKlMnOpQrStUvWx"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Slack User Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Slack User Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_JWTToken(t *testing.T) {
	sd := NewSecretDetector()
	// A fake JWT-like token with three base64url segments
	text := "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "JWT Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect JWT Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_RSAPrivateKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA04up8hoqzS1+APIB0RhjXyObwHQnOzhAk
-----END RSA PRIVATE KEY-----`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "RSA Private Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect RSA Private Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_ECPrivateKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `-----BEGIN EC PRIVATE KEY-----
MHQCAQEEIBkg4LVWM9nuwNSk3yByxZpYRTBnVfOGDBfbQBkMjr5QoAcGBSuBBAAi
-----END EC PRIVATE KEY-----`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "EC Private Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect EC Private Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_OpenSSHPrivateKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAAB
-----END OPENSSH PRIVATE KEY-----`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "OpenSSH Private Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect OpenSSH Private Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_DatabaseConnectionString(t *testing.T) {
	sd := NewSecretDetector()
	tests := []struct {
		name  string
		input string
	}{
		{"postgres", "DATABASE_URL=postgres://user:pass@localhost:5432/mydb"},
		{"mysql", "DB=mysql://root:secret@127.0.0.1:3306/app"},
		{"mongodb", "MONGO_URI=mongodb://admin:password123@mongo.example.com:27017/prod"},
		{"redis", "REDIS_URL=redis://default:mysecret@redis.example.com:6379/0"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			matches := sd.DetectSecrets(tt.input)
			found := false
			for _, m := range matches {
				if m.Type == "Database Connection String" {
					found = true
					break
				}
			}
			if !found {
				t.Errorf("expected to detect Database Connection String in %q, got matches: %+v", tt.input, matches)
			}
		})
	}
}

func TestSecretDetector_StripeKeys(t *testing.T) {
	sd := NewSecretDetector()
	text := "STRIPE_KEY=sk_" + "live_FAKETESTONLY000000000000"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Stripe Secret Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Stripe Secret Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_StripePublishableKey(t *testing.T) {
	sd := NewSecretDetector()
	text := "STRIPE_PK=pk_live_4eC39HqLyjWDarjtT1zdp7dc"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Stripe Publishable Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Stripe Publishable Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_SendGridAPIKey(t *testing.T) {
	sd := NewSecretDetector()
	text := "SENDGRID_API_KEY=SG." + "abcdefghij1234567890AB.abcdefghijklmnopqrstuvwxyz01234567890ABCDEF"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "SendGrid API Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect SendGrid API Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_TwilioAccountSID(t *testing.T) {
	sd := NewSecretDetector()
	text := "TWILIO_SID=AC" + "1234567890abcdef1234567890abcdef"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Twilio Account SID" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Twilio Account SID, got matches: %+v", matches)
	}
}

func TestSecretDetector_HerokuAPIKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `HEROKU_API_KEY="12345678-abcd-1234-abcd-1234567890ab"`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Heroku API Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Heroku API Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_DigitalOceanToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "DO_TOKEN=dop_v1_" + strings.Repeat("a1b2c3d4", 8)
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "DigitalOcean Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect DigitalOcean Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_AnthropicAPIKey(t *testing.T) {
	sd := NewSecretDetector()
	// Construct a key that matches the pattern: sk-ant-api03- followed by 93 word chars then AA
	keyBody := strings.Repeat("abcdefghij", 9) + "abcAA" // 90+5=95 chars
	text := "ANTHROPIC_KEY=sk-ant-api03-" + keyBody[:93] + "AA"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Anthropic API Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Anthropic API Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_GoogleAPIKey(t *testing.T) {
	sd := NewSecretDetector()
	text := "GOOGLE_API_KEY=AIzaSyC-EXAMPLE_KEY-abcdefghijklmnopqrs"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Google API Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Google API Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_NpmToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "NPM_TOKEN=npm_abcdefghijklmnopqrstuvwxyz1234567890"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "npm Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect npm Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_PyPIToken(t *testing.T) {
	sd := NewSecretDetector()
	text := "PYPI_TOKEN=pypi-AgEIcHlwaS5vcmcCJGI1NjE1YjA0LWY0ZDAtNDYxZS1hMjBhZXhh"
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "PyPI Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect PyPI Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_DockerRegistryToken(t *testing.T) {
	sd := NewSecretDetector()
	text := `{"auths":{"https://index.docker.io/v1/":{"auth":"dXNlcjpwYXNzd29yZDEyMzQ1Ng=="}}}`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Docker Registry Token" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Docker Registry Token, got matches: %+v", matches)
	}
}

func TestSecretDetector_GenericAPIKey(t *testing.T) {
	sd := NewSecretDetector()
	text := `api_key = "sk_1234567890abcdefghijklmn"`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Generic API Key" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Generic API Key, got matches: %+v", matches)
	}
}

func TestSecretDetector_GenericSecret(t *testing.T) {
	sd := NewSecretDetector()
	text := `client_secret = "mySuperS3cretPassw0rd!"`
	matches := sd.DetectSecrets(text)

	found := false
	for _, m := range matches {
		if m.Type == "Generic Secret" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected to detect Generic Secret, got matches: %+v", matches)
	}
}

func TestSecretDetector_RedactSecrets(t *testing.T) {
	sd := NewSecretDetector()
	text := "My AWS key is AKIAIOSFODNN7EXAMPLE and my GitHub token is ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"
	redacted := sd.RedactSecrets(text)

	if strings.Contains(redacted, "AKIAIOSFODNN7EXAMPLE") {
		t.Errorf("AWS key was not redacted: %s", redacted)
	}
	if strings.Contains(redacted, "ghp_ABCDEFGH") {
		t.Errorf("GitHub token was not redacted: %s", redacted)
	}
	if !strings.Contains(redacted, "[REDACTED:AWS Access Key]") {
		t.Errorf("expected [REDACTED:AWS Access Key] placeholder, got: %s", redacted)
	}
	if !strings.Contains(redacted, "[REDACTED:GitHub Token]") {
		t.Errorf("expected [REDACTED:GitHub Token] placeholder, got: %s", redacted)
	}
}

func TestSecretDetector_RedactSecrets_NoSecrets(t *testing.T) {
	sd := NewSecretDetector()
	text := "This is a normal log line with no secrets"
	redacted := sd.RedactSecrets(text)

	if redacted != text {
		t.Errorf("expected unchanged text, got: %s", redacted)
	}
}

func TestSecretDetector_RedactSecrets_EmptyInput(t *testing.T) {
	sd := NewSecretDetector()
	redacted := sd.RedactSecrets("")

	if redacted != "" {
		t.Errorf("expected empty string, got: %s", redacted)
	}
}

func TestSecretDetector_DetectSecrets_MultipleSecrets(t *testing.T) {
	sd := NewSecretDetector()
	text := `export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
export GITHUB_TOKEN=ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn
export STRIPE_KEY=sk_test_FakeTestOnly00000000000000`

	matches := sd.DetectSecrets(text)
	types := make(map[string]bool)
	for _, m := range matches {
		types[m.Type] = true
	}

	expected := []string{"AWS Access Key", "GitHub Token", "Stripe Secret Key"}
	for _, e := range expected {
		if !types[e] {
			t.Errorf("expected to find %s in matches, found types: %v", e, types)
		}
	}
}

func TestSecretDetector_DetectAndRedactWithEntropy(t *testing.T) {
	sd := NewSecretDetector()
	// A high-entropy string that looks like a secret assigned to a key-like variable
	text := `token = "aB3kR9mN2xPqL7wY5vFhJ4cT8gU1dE6s"`
	redacted := sd.DetectAndRedactWithEntropy(text, 4.5)

	// The generic patterns should catch this, or entropy should
	if strings.Contains(redacted, "aB3kR9mN2xPqL7wY5vFhJ4cT8gU1dE6s") {
		t.Errorf("high entropy string was not redacted: %s", redacted)
	}
}

func TestSecretDetector_MaskSecret(t *testing.T) {
	tests := []struct {
		value      string
		secretType string
		wantPrefix string
	}{
		{"ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn", "GitHub Token", "ghp_ABCD"},
		{"AKIAIOSFODNN7EXAMPLE", "AWS Access Key", "AKIAIОСF"},
		{"sk_" + "live_FAKETESTONLY000000000000", "Stripe Secret Key", "sk_" + "live_FAKETESTONLY000000000000"},
	}

	for _, tt := range tests {
		t.Run(tt.secretType, func(t *testing.T) {
			masked := MaskSecret(tt.value, tt.secretType)
			if masked == tt.value {
				t.Errorf("MaskSecret should not return the original value unchanged")
			}
			if len(masked) == 0 {
				t.Errorf("MaskSecret should not return empty string for non-empty input")
			}
		})
	}
}

func TestSecretDetector_PrivateKeyMask(t *testing.T) {
	key := "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAK...\n-----END RSA PRIVATE KEY-----"
	masked := MaskSecret(key, "RSA Private Key")

	if !strings.HasPrefix(masked, "-----BEGIN RSA PRIVATE KEY-----") {
		t.Errorf("expected masked key to start with header, got: %s", masked)
	}
	if !strings.Contains(masked, "[REDACTED]") {
		t.Errorf("expected masked key to contain [REDACTED], got: %s", masked)
	}
}

func TestDefaultSecretDetector_Singleton(t *testing.T) {
	sd1 := DefaultSecretDetector()
	sd2 := DefaultSecretDetector()

	if sd1 != sd2 {
		t.Error("DefaultSecretDetector should return the same instance")
	}
}

func TestSecretDetector_MatchPositions(t *testing.T) {
	sd := NewSecretDetector()
	text := "key is AKIAIOSFODNN7EXAMPLE here"
	matches := sd.DetectSecrets(text)

	if len(matches) == 0 {
		t.Fatal("expected at least one match")
	}

	m := matches[0]
	if m.StartPos < 0 || m.EndPos <= m.StartPos {
		t.Errorf("invalid match positions: start=%d, end=%d", m.StartPos, m.EndPos)
	}
	if text[m.StartPos:m.EndPos] != m.Value {
		t.Errorf("position mismatch: text[%d:%d]=%q but Value=%q", m.StartPos, m.EndPos, text[m.StartPos:m.EndPos], m.Value)
	}
}

func TestShannonEntropy(t *testing.T) {
	tests := []struct {
		name   string
		input  string
		minEnt float64
		maxEnt float64
	}{
		{"empty string", "", 0, 0},
		{"single char repeated", "aaaaaaaaaa", 0, 0.01},
		{"lowercase alphabet", "abcdefghijklmnopqrstuvwxyz", 4.5, 5.0},
		{"hex string", "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6", 3.5, 5.0},
		{"base64 random", "aB3kR9mN2xPqL7wY5vFhJ4cT8gU1dE6s", 4.5, 6.0},
		{"english word", "hello", 1.5, 2.5},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ent := ShannonEntropy(tt.input)
			if ent < tt.minEnt || ent > tt.maxEnt {
				t.Errorf("ShannonEntropy(%q) = %f, want in range [%f, %f]", tt.input, ent, tt.minEnt, tt.maxEnt)
			}
		})
	}
}

func TestIsHighEntropy(t *testing.T) {
	tests := []struct {
		name      string
		input     string
		threshold float64
		want      bool
	}{
		{"random base64 above threshold", "aB3kR9mN2xPqL7wY5vFhJ4cT8gU1dE6s", 4.5, true},
		{"repeated chars below threshold", "aaaaaaaabbbbbbbb", 4.5, false},
		{"short string always false", "aB3k", 4.5, false},
		{"english text", "this is a normal sentence", 4.5, false},
		{"hex key high entropy", "4a8f2c9d1e7b3a5f6c0d8e2b4a9f1c7d", 3.5, true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := IsHighEntropy(tt.input, tt.threshold)
			if got != tt.want {
				ent := ShannonEntropy(tt.input)
				t.Errorf("IsHighEntropy(%q, %f) = %v, want %v (actual entropy: %f)", tt.input, tt.threshold, got, tt.want, ent)
			}
		})
	}
}

func BenchmarkSecretDetector_DetectSecrets(b *testing.B) {
	sd := NewSecretDetector()
	text := strings.Repeat("Normal log output line here\n", 100) +
		"AKIAIOSFODNN7EXAMPLE\n" +
		strings.Repeat("More normal output\n", 100)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sd.DetectSecrets(text)
	}
}

func BenchmarkSecretDetector_RedactSecrets(b *testing.B) {
	sd := NewSecretDetector()
	text := strings.Repeat("Normal log output line here\n", 100) +
		"AWS_KEY=AKIAIOSFODNN7EXAMPLE GITHUB=ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn\n" +
		strings.Repeat("More normal output\n", 100)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sd.RedactSecrets(text)
	}
}
