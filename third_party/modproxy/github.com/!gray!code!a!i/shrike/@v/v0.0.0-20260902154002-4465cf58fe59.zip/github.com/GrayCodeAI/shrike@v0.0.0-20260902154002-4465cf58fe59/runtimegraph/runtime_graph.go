// Package runtimegraph provides runtime performance graph analysis for shrike.
package runtimegraph

import (
	"fmt"
	"sort"
	"sync"
	"time"

	graphcontracts "github.com/GrayCodeAI/shrike/graph"
)

// RuntimeMetric represents a runtime performance metric.
type RuntimeMetric struct {
	Name      string    `json:"name"`
	Value     float64   `json:"value"`
	Threshold float64   `json:"threshold"`
	Status    string    `json:"status"` // "pass", "warn", "fail"
	UpdatedAt time.Time `json:"updated_at"`
}

// RuntimeNode represents a runtime component with performance metrics.
type RuntimeNode struct {
	ID       string                 `json:"id"`
	Type     string                 `json:"type"` // "model", "endpoint", "pipeline", "service"
	Name     string                 `json:"name"`
	Metrics  []RuntimeMetric        `json:"metrics"`
	Children []string               `json:"children,omitempty"`
	Attrs    map[string]interface{} `json:"attrs,omitempty"`
}

// RuntimeEdge represents a runtime relationship between components.
type RuntimeEdge struct {
	From   string  `json:"from"`
	To     string  `json:"to"`
	Kind   string  `json:"kind"` // "calls", "produces", "consumes", "depends_on"
	Weight float64 `json:"weight"`
}

// RuntimeGraph represents a runtime performance graph.
type RuntimeGraph struct {
	mu    sync.RWMutex
	nodes map[string]*RuntimeNode
	edges []RuntimeEdge
}

// NewRuntimeGraph creates a new runtime graph.
func NewRuntimeGraph() *RuntimeGraph {
	return &RuntimeGraph{
		nodes: make(map[string]*RuntimeNode),
	}
}

// AddNode adds a runtime node to the graph.
func (g *RuntimeGraph) AddNode(node *RuntimeNode) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.nodes[node.ID] = node
}

// AddEdge adds a runtime edge to the graph.
func (g *RuntimeGraph) AddEdge(edge RuntimeEdge) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.edges = append(g.edges, edge)
}

// GetNode retrieves a node by ID.
func (g *RuntimeGraph) GetNode(id string) (*RuntimeNode, bool) {
	g.mu.RLock()
	defer g.mu.RUnlock()
	node, ok := g.nodes[id]
	return node, ok
}

// GetNodes returns all nodes.
func (g *RuntimeGraph) GetNodes() []*RuntimeNode {
	g.mu.RLock()
	defer g.mu.RUnlock()
	result := make([]*RuntimeNode, 0, len(g.nodes))
	for _, node := range g.nodes {
		result = append(result, node)
	}
	return result
}

// GetEdges returns all edges.
func (g *RuntimeGraph) GetEdges() []RuntimeEdge {
	g.mu.RLock()
	defer g.mu.RUnlock()
	return g.edges
}

// GetFailedMetrics returns all metrics that failed their threshold.
func (g *RuntimeGraph) GetFailedMetrics() []RuntimeMetric {
	g.mu.RLock()
	defer g.mu.RUnlock()
	result := []RuntimeMetric{}
	for _, node := range g.nodes {
		for _, metric := range node.Metrics {
			if metric.Status == "fail" {
				result = append(result, metric)
			}
		}
	}
	return result
}

// GetTopIssues returns the top N issues by severity.
func (g *RuntimeGraph) GetTopIssues(n int) []RuntimeMetric {
	failed := g.GetFailedMetrics()
	sort.Slice(failed, func(i, j int) bool {
		return failed[i].Value > failed[j].Value
	})
	if len(failed) > n {
		failed = failed[:n]
	}
	return failed
}

// ToGraphSpec converts the runtime graph to a portable graph spec.
func (g *RuntimeGraph) ToGraphSpec() *graphcontracts.GraphSpec {
	g.mu.RLock()
	defer g.mu.RUnlock()

	nodes := make([]graphcontracts.NodeSpec, 0, len(g.nodes))
	for id, node := range g.nodes {
		config := map[string]string{
			"name":    node.Name,
			"type":    node.Type,
			"metrics": fmt.Sprintf("%d", len(node.Metrics)),
		}
		for _, m := range node.Metrics {
			config["metric_"+m.Name] = fmt.Sprintf("%.2f", m.Value)
		}

		nodes = append(nodes, graphcontracts.NodeSpec{
			ID:     id,
			Type:   graphcontracts.NodeTypeExecution,
			Name:   node.Name,
			Config: config,
		})
	}

	edges := make([]graphcontracts.EdgeSpec, 0, len(g.edges))
	for _, edge := range g.edges {
		edges = append(edges, graphcontracts.EdgeSpec{
			From:   edge.From,
			To:     edge.To,
			Weight: edge.Weight,
		})
	}

	return &graphcontracts.GraphSpec{
		ID:    "runtime-graph",
		Name:  "Runtime Performance Graph",
		Nodes: nodes,
		Edges: edges,
	}
}
