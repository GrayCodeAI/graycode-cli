package shrike_test

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

// benchmarkText returns a repeat of the base pattern sized to approximately targetSize bytes.
func benchmarkText(targetSize int) string {
	base := "The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs. "
	repeat := targetSize/len(base) + 1
	text := strings.Repeat(base, repeat)
	if len(text) > targetSize {
		text = text[:targetSize]
	}
	return text
}

func BenchmarkCountTokens(b *testing.B) {
	sizes := []struct {
		name string
		size int
	}{
		{"100B", 100},
		{"1KB", 1024},
		{"10KB", 10 * 1024},
		{"100KB", 100 * 1024},
	}

	for _, tc := range sizes {
		text := benchmarkText(tc.size)
		b.Run(tc.name, func(b *testing.B) {
			b.SetBytes(int64(len(text)))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				shrike.EstimateTokens(text)
			}
		})
	}
}

func BenchmarkCompress(b *testing.B) {
	sizes := []struct {
		name string
		size int
	}{
		{"100B", 100},
		{"1KB", 1024},
		{"10KB", 10 * 1024},
		{"100KB", 100 * 1024},
	}

	modes := []struct {
		name string
		opt  shrike.Option
	}{
		{"Minimal", shrike.Minimal},
		{"Aggressive", shrike.Aggressive},
	}

	for _, sz := range sizes {
		text := benchmarkText(sz.size)
		for _, mode := range modes {
			b.Run(sz.name+"/"+mode.name, func(b *testing.B) {
				b.SetBytes(int64(len(text)))
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					shrike.Compress(text, mode.opt)
				}
			})
		}
	}
}

func BenchmarkEstimateCost(b *testing.B) {
	models := []string{
		"gpt-4o",
		"claude-sonnet",
		"gemini-pro",
	}

	// Pre-build stats to isolate cost estimation from compression.
	stats := shrike.Stats{
		OriginalTokens:   10000,
		FinalTokens:      6000,
		TokensSaved:      4000,
		ReductionPercent: 40.0,
	}

	for _, model := range models {
		b.Run(model, func(b *testing.B) {
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				shrike.EstimateCostSavings(stats, model)
			}
		})
	}
}

func BenchmarkBPEEncode(b *testing.B) {
	sizes := []struct {
		name string
		size int
	}{
		{"100B", 100},
		{"1KB", 1024},
		{"10KB", 10 * 1024},
		{"100KB", 100 * 1024},
	}

	for _, tc := range sizes {
		text := benchmarkText(tc.size)
		b.Run(tc.name, func(b *testing.B) {
			b.SetBytes(int64(len(text)))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				shrike.EstimateTokensPrecise(text)
			}
		})
	}
}

func BenchmarkStats(b *testing.B) {
	sizes := []struct {
		name string
		size int
	}{
		{"100B", 100},
		{"1KB", 1024},
		{"10KB", 10 * 1024},
		{"100KB", 100 * 1024},
	}

	for _, tc := range sizes {
		text := benchmarkText(tc.size)
		b.Run(tc.name, func(b *testing.B) {
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				_, stats := shrike.Compress(text, shrike.Minimal)
				_ = stats.ReductionPercent
			}
		})
	}
}
