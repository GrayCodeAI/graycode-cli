package shrike

import "github.com/GrayCodeAI/shrike/internal/filter"

// Stats contains compression statistics.
type Stats struct {
	OriginalTokens   int
	FinalTokens      int
	TokensSaved      int
	ReductionPercent float64
	Layers           map[string]LayerStat
	Model            string  // Model used for cost calculation
	CostSavings      float64 // Dollar savings from compression
}

// LayerStat contains per-layer statistics.
type LayerStat struct {
	TokensSaved int
	DurationMs  int64
}

// HardTruncated reports whether the final budget enforcer did the bulk of the
// token reduction — i.e. the output is mostly the input cut short at the
// budget boundary — rather than the structural compression layers (dedupe,
// compaction, gist, ...). A hard-truncated output is NOT a rewrite of the
// content and must not be treated as a summary by callers.
func (s Stats) HardTruncated() bool {
	if s.TokensSaved <= 0 {
		return false
	}
	budgetSaved := s.Layers[filter.LayerBudget].TokensSaved
	return budgetSaved > 0 && budgetSaved*2 > s.TokensSaved
}

func newStats(ps *filter.PipelineStats) Stats {
	if ps == nil {
		return Stats{}
	}

	layers := make(map[string]LayerStat, len(ps.LayerStats))
	for name, ls := range ps.LayerStats {
		layers[name] = LayerStat{
			TokensSaved: ls.TokensSaved,
			DurationMs:  ls.Duration,
		}
	}

	return Stats{
		OriginalTokens:   ps.OriginalTokens,
		FinalTokens:      ps.FinalTokens,
		TokensSaved:      ps.TotalSaved,
		ReductionPercent: ps.ReductionPercent,
		Layers:           layers,
	}
}
