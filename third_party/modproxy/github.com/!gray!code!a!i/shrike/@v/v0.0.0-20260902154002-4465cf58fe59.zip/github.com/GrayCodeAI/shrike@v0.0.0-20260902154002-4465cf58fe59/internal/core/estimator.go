package core

import (
	"container/list"
	"fmt"
	"hash/maphash"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/GrayCodeAI/shrike/internal/utils"
	tiktoken "github.com/tiktoken-go/tokenizer"
)

// BPETokenizer wraps tiktoken for accurate BPE token counting.
// P1.1: Replaces heuristic len/4 with real BPE tokenization.
// ~20-30% more accurate than heuristic estimation.
type BPETokenizer struct {
	codec tiktoken.Codec
	cache *tokenCache
}

// cacheEntry stores cached token counts with LRU metadata.
// It deliberately does NOT retain the original text: Compress estimates the
// original prompt plus every intermediate layer output, so pinning full texts
// in the LRU could retain hundreds of MB. Hit validation relies on the
// 64-bit maphash plus the text length (see hashText).
type cacheEntry struct {
	count  int
	length int           // text length, secondary collision check
	elem   *list.Element // pointer to list element for O(1) removal
}

// cacheSeed is generated once per process. The token cache is purely
// in-process, so a random seed is sufficient for correctness and avoids
// fixed-seed hash-flooding concerns.
var cacheSeed = maphash.MakeSeed()

// maxCacheableTextBytes is the size cutoff above which texts bypass the
// cache entirely. Giant inputs are rare in steady state, dominate the cache's
// memory footprint if admitted, and their Count cost is dominated by the BPE
// encode itself, so caching them buys little. 1 MiB bounds the worst case
// while still covering every realistic prompt, layer output, or file read.
const maxCacheableTextBytes = 1 << 20 // 1 MiB

// lruItem holds the key for list element tracking.
type lruItem struct {
	key uint64
}

// tokenCacheShard is a single shard of the sharded token cache.
type tokenCacheShard struct {
	mu    sync.Mutex
	items map[uint64]*cacheEntry
	ll    *list.List
	max   int
}

// tokenCache caches BPE token counts for frequently seen strings.
// Phase 2.8: Avoids repeated BPE encoding for identical content.
// P2: Uses LRU eviction with doubly-linked list for O(1) operations.
// P3: Sharded into 64 independent caches to reduce lock contention.
type tokenCache struct {
	shards [64]tokenCacheShard
	hits   int64 // For statistics
}

func newTokenCache(maxSize int) *tokenCache {
	c := &tokenCache{}
	shardMax := maxSize / 64
	if shardMax < 1 {
		shardMax = 1
	}
	for i := range c.shards {
		c.shards[i] = tokenCacheShard{
			items: make(map[uint64]*cacheEntry),
			ll:    list.New(),
			max:   shardMax,
		}
	}
	return c
}

func (c *tokenCache) getShard(key uint64) *tokenCacheShard {
	return &c.shards[key%64]
}

// hashText returns a 64-bit hash of text without copying it.
// maphash.String reads the string's backing bytes directly (no []byte(text)
// conversion) and is seeded per process. Collision handling: entries are
// additionally validated by text length, so a false hit requires two distinct
// texts with identical length AND identical 64-bit hash. With <=8192 cached
// entries the birthday-bound probability of that is ~1e-12 per process —
// negligible next to the heuristic fallback path — so no stronger check
// (e.g. content prefix) is retained.
func hashText(text string) uint64 {
	return maphash.String(cacheSeed, text)
}

// get retrieves a cached token count and promotes the entry in the LRU list.
// Uses per-shard locking to reduce contention across concurrent goroutines.
// Validates (hash, length) — the cache never stores the text itself.
// Texts larger than maxCacheableTextBytes always miss.
func (c *tokenCache) get(text string) (int, bool) {
	if len(text) > maxCacheableTextBytes {
		return 0, false
	}
	key := hashText(text)
	shard := c.getShard(key)
	shard.mu.Lock()
	entry, ok := shard.items[key]
	if !ok || entry.length != len(text) {
		shard.mu.Unlock()
		return 0, false
	}
	count := entry.count
	shard.ll.MoveToFront(entry.elem)
	shard.mu.Unlock()

	atomic.AddInt64(&c.hits, 1)
	return count, true
}

func (c *tokenCache) set(text string, count int) {
	if len(text) > maxCacheableTextBytes {
		return // giant inputs never enter the LRU
	}
	key := hashText(text)
	shard := c.getShard(key)
	shard.mu.Lock()
	defer shard.mu.Unlock()

	if entry, ok := shard.items[key]; ok && entry.length == len(text) {
		entry.count = count
		shard.ll.MoveToFront(entry.elem)
		return
	}

	if shard.ll.Len() >= shard.max {
		c.evictLRUShard(shard)
	}

	elem := shard.ll.PushFront(&lruItem{key: key})
	shard.items[key] = &cacheEntry{
		count:  count,
		length: len(text),
		elem:   elem,
	}
}

// evictLRUShard removes the least recently used entry from a shard (called with shard lock held).
// O(1) operation using doubly-linked list.
func (c *tokenCache) evictLRUShard(shard *tokenCacheShard) {
	// Remove 25% of entries (the oldest ones)
	toRemove := shard.max / 4
	if toRemove < 1 {
		toRemove = 1
	}

	for i := 0; i < toRemove && shard.ll.Len() > 0; i++ {
		back := shard.ll.Back() // O(1) get oldest
		if back == nil {
			break
		}
		item, _ := back.Value.(*lruItem)
		shard.ll.Remove(back)         // O(1) remove from list
		delete(shard.items, item.key) // O(1) remove from map
	}
}

var (
	bpeInstance *BPETokenizer
	bpeOnce     sync.Once
	bpeReady    atomic.Bool
	bpeErr      error
	bpeFailed   atomic.Bool
)

// tokenizerPool caches tokenizers by encoding to avoid repeated initialization.
var tokenizerPool sync.Map

// getBPETokenizer returns the singleton BPE tokenizer, loading it if needed.
// The codec is loaded lazily but subsequent calls block only on initialization.
func getBPETokenizer() (*BPETokenizer, error) {
	bpeOnce.Do(func() {
		defer func() {
			if r := recover(); r != nil {
				bpeErr = fmt.Errorf("BPE tokenizer panic: %v", r)
				bpeFailed.Store(true)
			}
		}()
		codec, err := tiktoken.Get(tiktoken.Cl100kBase)
		if err != nil {
			bpeErr = err
			bpeFailed.Store(true)
			return
		}
		bpeInstance = &BPETokenizer{
			codec: codec,
			cache: newTokenCache(8192),
		}
		bpeReady.Store(true)
	})
	return bpeInstance, bpeErr
}

// GetTokenizerForEncoding returns a BPE tokenizer for the specified encoding.
// Uses a pool to cache tokenizers and avoid repeated initialization.
func GetTokenizerForEncoding(encoding string) (*BPETokenizer, error) {
	// Check pool first
	if shrike, ok := tokenizerPool.Load(encoding); ok {
		bpe, _ := shrike.(*BPETokenizer)
		return bpe, nil
	}

	// Map encoding string to tiktoken constant
	var tiktokenEnc tiktoken.Encoding
	switch encoding {
	case "o200k_base":
		tiktokenEnc = tiktoken.O200kBase
	case "cl100k_base":
		tiktokenEnc = tiktoken.Cl100kBase
	case "r50k_base":
		tiktokenEnc = tiktoken.R50kBase
	case "p50k_base":
		tiktokenEnc = tiktoken.P50kBase
	case "p50k_edit":
		tiktokenEnc = tiktoken.P50kEdit
	default:
		return nil, fmt.Errorf("unsupported encoding: %s", encoding)
	}

	codec, err := tiktoken.Get(tiktokenEnc)
	if err != nil {
		return nil, err
	}

	shrike := &BPETokenizer{
		codec: codec,
		cache: newTokenCache(8192),
	}

	// Store in pool (may race, but that's fine - both will work)
	tokenizerPool.Store(encoding, shrike)
	return shrike, nil
}

// WarmupBPETokenizer preloads the codec in a background goroutine.
// Call this during application startup to avoid latency on the first
// token estimation. Safe to call multiple times.
func WarmupBPETokenizer() {
	go func() {
		defer func() {
			if r := recover(); r != nil {
				bpeFailed.Store(true)
				utils.Warn("BPE tokenizer warmup panicked", "panic", r)
			}
		}()
		_, err := getBPETokenizer()
		if err != nil {
			bpeFailed.Store(true)
			utils.Warn("BPE tokenizer warmup failed", "error", err)
		}
	}()
}

// Count returns the accurate BPE token count with caching.
func (b *BPETokenizer) Count(text string) int {
	if text == "" {
		return 0
	}

	// Check cache first (Phase 2.8 optimization)
	if val, ok := b.cache.get(text); ok {
		return val
	}

	count, err := b.codec.Count(text)
	if err != nil {
		return (len(text) + 3) / 4 // Fallback to heuristic
	}

	// Cache result for future lookups
	b.cache.set(text, count)
	return count
}

// fastEstimateTokens uses a quick heuristic for short strings.
// Avoids BPE overhead for small content.
func fastEstimateTokens(text string) int {
	length := len(text)

	// Very short strings: assume 1 token per 3 chars
	if length < 30 {
		return (length + 2) / 3
	}

	// Short strings: use standard heuristic
	if length < 100 {
		return (length + 3) / 4
	}

	// Medium strings: account for whitespace tokens being single tokens
	spaces := 0
	sample := length
	if sample > 200 {
		sample = 200
	}
	for i := 0; i < sample; i++ {
		if text[i] == ' ' || text[i] == '\n' || text[i] == '\t' {
			spaces++
		}
	}
	spaceRatio := float64(spaces) / float64(sample)
	nonSpaceChars := float64(length) * (1 - spaceRatio)
	spaceTokens := float64(length) * spaceRatio
	return int(nonSpaceChars/3.5 + spaceTokens)
}

// EstimateTokens is the single source of truth for token estimation.
// Delegates to EstimateTokensPrecise for consistent BPE-based counting.
// Falls back to heuristic only when BPE initialization fails.
func EstimateTokens(text string) int {
	return EstimateTokensPrecise(text)
}

// EstimateTokensFast provides a fast estimate without BPE.
// Use this when exact count isn't critical.
func EstimateTokensFast(text string) int {
	return fastEstimateTokens(text)
}

// EstimateTokensPrecise always uses BPE, skipping the short-string heuristic.
// Use this for user-visible counts (savings dashboards, compression reports)
// where a 200-char heuristic bypass would produce misleading numbers.
// Falls back to fastEstimateTokens only if BPE initialization fails.
func EstimateTokensPrecise(text string) int {
	if text == "" {
		return 0
	}
	if bpeFailed.Load() {
		return fastEstimateTokens(text)
	}
	shrike, err := getBPETokenizer()
	if err != nil || shrike == nil {
		return fastEstimateTokens(text)
	}
	return shrike.Count(text)
}

// CalculateTokensSaved computes token savings between original and filtered.
func CalculateTokensSaved(original, filtered string) int {
	origTokens := EstimateTokens(original)
	filterTokens := EstimateTokens(filtered)
	if origTokens > filterTokens {
		return origTokens - filterTokens
	}
	return 0
}

// EstimateTokensWithEncoding returns the estimated token count using the specified encoding.
// Falls back to default estimation if the encoding is invalid.
func EstimateTokensWithEncoding(text string, encoding string) int {
	if text == "" {
		return 0
	}

	shrike, err := GetTokenizerForEncoding(encoding)
	if err != nil {
		// Fallback to default estimation
		return EstimateTokens(text)
	}
	return shrike.Count(text)
}

// EstimateTokensForModel returns the estimated token count for a specific model.
// Uses the model-aware encoding selection.
func EstimateTokensForModel(text string, model string) int {
	if text == "" {
		return 0
	}

	// Import cycle prevention: use the encoding mapping directly
	encoding := getEncodingForModel(model)
	return EstimateTokensWithEncoding(text, encoding)
}

// getEncodingForModel returns the encoding name for a given model.
// This is a local implementation to avoid import cycles with the shrike package.
func getEncodingForModel(model string) string {
	model = strings.ToLower(strings.TrimSpace(model))

	// OpenAI o-series
	if strings.HasPrefix(model, "o1") || strings.HasPrefix(model, "o3") || strings.HasPrefix(model, "o4") {
		return "o200k_base"
	}

	// OpenAI GPT-4.1 and GPT-4o
	if strings.HasPrefix(model, "gpt-4.1") || strings.HasPrefix(model, "gpt-4o") || strings.HasPrefix(model, "chatgpt-4o") {
		return "o200k_base"
	}

	// OpenAI GPT-4
	if strings.HasPrefix(model, "gpt-4") {
		return "cl100k_base"
	}

	// OpenAI GPT-3.5
	if strings.HasPrefix(model, "gpt-3.5") || strings.HasPrefix(model, "gpt-35") {
		return "cl100k_base"
	}

	// Anthropic Claude
	if strings.HasPrefix(model, "claude") {
		return "cl100k_base"
	}

	// Google Gemini
	if strings.HasPrefix(model, "gemini") {
		return "cl100k_base"
	}

	// Default fallback
	return "cl100k_base"
}
