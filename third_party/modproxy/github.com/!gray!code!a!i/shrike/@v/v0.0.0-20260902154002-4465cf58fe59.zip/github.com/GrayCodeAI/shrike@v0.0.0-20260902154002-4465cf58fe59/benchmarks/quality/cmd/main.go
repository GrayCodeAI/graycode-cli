// Command quality-bench runs the offline compression-quality harness and emits
// a markdown report (and optionally CSV) into benchmarks/.
//
// Usage:
//
//	go run ./benchmarks/quality/cmd \
//	    --samples benchmarks/samples.json \
//	    --out benchmarks/quality-results.md \
//	    --csv benchmarks/quality-results.csv
//
// It is fully offline: no network access or model calls.
package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/GrayCodeAI/shrike/benchmarks/quality"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}

func run() error {
	samplesPath := flag.String("samples", "benchmarks/samples.json", "path to samples JSON")
	outPath := flag.String("out", "benchmarks/quality-results.md", "markdown report output path")
	csvPath := flag.String("csv", "", "optional CSV output path")
	includeLongBench := flag.Bool("longbench", true, "append embedded LongBench-style prose samples")
	flag.Parse()

	samples, err := quality.LoadSamples(*samplesPath)
	if err != nil {
		return err
	}
	if *includeLongBench {
		samples = append(samples, quality.LongBenchSamples()...)
	}

	tiers := quality.DefaultTiers()
	results := quality.Evaluate(samples, tiers)
	summaries := quality.Summarize(results, tiers)

	mdFile, err := os.Create(*outPath)
	if err != nil {
		return err
	}
	defer func() { _ = mdFile.Close() }()
	if err := quality.WriteMarkdown(mdFile, summaries, results); err != nil {
		return err
	}

	if *csvPath != "" {
		csvFile, err := os.Create(*csvPath)
		if err != nil {
			return err
		}
		defer func() { _ = csvFile.Close() }()
		if err := quality.WriteCSV(csvFile, results); err != nil {
			return err
		}
	}

	fmt.Printf("quality benchmark: %d samples x %d tiers -> %s\n",
		len(samples), len(tiers), *outPath)
	return nil
}
