package shrike

import (
	"math"
	"unicode/utf8"
)

// ShannonEntropy calculates the Shannon entropy of a string in bits per character.
// Higher values indicate more randomness, which is characteristic of secrets and keys.
func ShannonEntropy(s string) float64 {
	if len(s) == 0 {
		return 0
	}

	// Count character frequencies
	freq := make(map[rune]int)
	for _, c := range s {
		freq[c]++
	}

	length := float64(utf8.RuneCountInString(s))
	entropy := 0.0

	for _, count := range freq {
		if count == 0 {
			continue
		}
		p := float64(count) / length
		entropy -= p * math.Log2(p)
	}

	return entropy
}

// IsHighEntropy returns true if the string's Shannon entropy exceeds the given threshold.
// A threshold of 4.5 is generally a good indicator for detecting random secrets/keys.
// Most English text has entropy around 3.5-4.0, while random base64/hex strings
// typically have entropy above 4.5.
func IsHighEntropy(s string, threshold float64) bool {
	if len(s) < 8 {
		// Short strings can have misleadingly high entropy
		return false
	}
	return ShannonEntropy(s) > threshold
}
