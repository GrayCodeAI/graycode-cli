package shrike_test

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestExtractJSON_TopLevel(t *testing.T) {
	tests := []struct {
		name  string
		input string
		want  string
		found bool
	}{
		{"bare", `{"a": 1}`, `{"a": 1}`, true},
		{"with prose", `Sure! {"a": 1} done`, `{"a": 1}`, true},
		{"not found", "no braces", "", false},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			r := shrike.ExtractJSON(tc.input)
			if r.Found != tc.found {
				t.Errorf("found mismatch: got %v want %v", r.Found, tc.found)
			}
			if r.JSON != tc.want {
				t.Errorf("JSON mismatch: got %q want %q", r.JSON, tc.want)
			}
		})
	}
}

func TestExtractJSON_ApostropheInProse(t *testing.T) {
	// Regression: apostrophes in English prose must not be confused
	// with string delimiters.
	in := "Here's the JSON: {\"a\": 1}"
	r := shrike.ExtractJSON(in)
	if !r.Found {
		t.Fatal("expected to find JSON")
	}
	if !strings.Contains(r.JSON, `"a"`) {
		t.Errorf("unexpected extraction: %q", r.JSON)
	}
}

func TestExtractJSONArray_TopLevel(t *testing.T) {
	r := shrike.ExtractJSONArray(`Result: [1, 2, 3]`)
	if !r.Found {
		t.Fatal("expected to find array")
	}
	if r.JSON != "[1, 2, 3]" {
		t.Errorf("unexpected array: %q", r.JSON)
	}
}

func TestExtractAllJSON_TopLevel(t *testing.T) {
	in := `First: {"a": 1} middle {"b": 2} tail`
	out := shrike.ExtractAllJSON(in)
	if len(out) != 2 {
		t.Fatalf("expected 2 objects, got %d", len(out))
	}
}
