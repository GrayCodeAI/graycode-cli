package filter

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike/internal/core"
)

// representativeInputs returns named sample inputs spanning the content types the
// pipeline routes differently (code, prose, JSON, empty, very long).
func representativeInputs() []struct {
	name  string
	input string
} {
	code := `package main

import "fmt"

// add returns the sum of two integers.
func add(a int, b int) int {
	return a + b
}

func main() {
	for i := 0; i < 10; i++ {
		fmt.Println(add(i, i*2))
	}
}
`
	prose := strings.Repeat("The quick brown fox jumps over the lazy dog. "+
		"Natural language prose contains redundant filler words and phrases. ", 20)
	jsonInput := `{"name":"widget","version":"1.2.3","tags":["a","b","c"],` +
		`"nested":{"x":1,"y":2,"z":{"deep":true}},"items":[{"id":1},{"id":2},{"id":3}]}`
	veryLong := strings.Repeat("line of repeated content with some words and numbers 12345\n", 2000)

	return []struct {
		name  string
		input string
	}{
		{"code", code},
		{"prose", prose},
		{"json", jsonInput},
		{"empty", ""},
		{"veryLong", veryLong},
	}
}

// modeConfigs builds a coordinator config for each pipeline mode the package exposes.
func modeConfigs() []struct {
	name string
	cfg  PipelineConfig
} {
	return []struct {
		name string
		cfg  PipelineConfig
	}{
		{"none", PipelineConfig{Mode: ModeNone}},
		{"minimal", PipelineConfig{Mode: ModeMinimal}},
		{"aggressive", PipelineConfig{Mode: ModeAggressive}},
	}
}

// TestProcess_OutputAndStatsAcrossModes drives Process across the representative
// inputs and modes, asserting the contract documented in pipeline_process.go and
// finalizeStats: non-empty output for non-empty input, OriginalTokens reflecting
// the input, FinalTokens populated, and bounded reduction stats.
func TestProcess_OutputAndStatsAcrossModes(t *testing.T) {
	for _, mc := range modeConfigs() {
		for _, in := range representativeInputs() {
			t.Run(mc.name+"/"+in.name, func(t *testing.T) {
				cfg := mc.cfg
				coord := NewPipelineCoordinator(&cfg)

				output, stats := coord.Process(in.input)
				if stats == nil {
					t.Fatal("expected non-nil stats")
				}

				// OriginalTokens must equal core.EstimateTokens(input) per Process().
				wantOrig := core.EstimateTokens(in.input)
				if stats.OriginalTokens != wantOrig {
					t.Errorf("OriginalTokens = %d, want %d", stats.OriginalTokens, wantOrig)
				}

				// FinalTokens must equal core.EstimateTokens(output) per finalizeStats().
				wantFinal := core.EstimateTokens(output)
				if stats.FinalTokens != wantFinal {
					t.Errorf("FinalTokens = %d, want %d (matching output)", stats.FinalTokens, wantFinal)
				}

				if in.input == "" {
					// Empty input: empty output, zero token counts.
					if output != "" {
						t.Errorf("empty input produced non-empty output %q", output)
					}
					if stats.OriginalTokens != 0 || stats.FinalTokens != 0 {
						t.Errorf("empty input tokens orig=%d final=%d, want 0/0",
							stats.OriginalTokens, stats.FinalTokens)
					}
					return
				}

				// Non-empty input must yield non-empty output (no corruption to empty).
				if len(output) == 0 {
					t.Fatalf("non-empty input compressed to empty output")
				}
				if stats.OriginalTokens == 0 {
					t.Error("expected non-zero OriginalTokens for non-empty input")
				}

				// finalizeStats clamps these: TotalSaved >= 0 and ReductionPercent in [0,100].
				if stats.TotalSaved < 0 {
					t.Errorf("TotalSaved = %d, want >= 0", stats.TotalSaved)
				}
				if stats.ReductionPercent < 0 || stats.ReductionPercent > 100 {
					t.Errorf("ReductionPercent = %f, want within [0,100]", stats.ReductionPercent)
				}

				// Compression never increases token count beyond original (TotalSaved>=0
				// implies FinalTokens<=OriginalTokens given the finalizeStats formula).
				if stats.FinalTokens > stats.OriginalTokens {
					t.Errorf("FinalTokens %d > OriginalTokens %d (compression should not inflate)",
						stats.FinalTokens, stats.OriginalTokens)
				}

				if stats.LayerStats == nil {
					t.Error("expected initialized LayerStats map")
				}
			})
		}
	}
}

// TestProcess_NilCoordinator verifies the nil-receiver guard in Process: it
// returns the input verbatim with stats whose token counts equal the input's.
func TestProcess_NilCoordinator(t *testing.T) {
	var p *PipelineCoordinator
	input := "some passthrough content for the nil coordinator path"

	output, stats := p.Process(input)
	if output != input {
		t.Errorf("nil coordinator should pass input through: got %q", output)
	}
	if stats == nil {
		t.Fatal("expected non-nil stats from nil coordinator")
	}
	want := core.EstimateTokens(input)
	if stats.OriginalTokens != want || stats.FinalTokens != want {
		t.Errorf("nil coordinator stats orig=%d final=%d, want %d/%d",
			stats.OriginalTokens, stats.FinalTokens, want, want)
	}
}

// TestProcess_SmallInputNotCorrupted ensures small inputs (below most layer skip
// thresholds in pipeline_early_exit.go) are not destroyed by the pipeline.
func TestProcess_SmallInputNotCorrupted(t *testing.T) {
	smallInputs := []string{
		"hi",
		"hello world",
		"x = 1",
		`{"a":1}`,
		"a",
	}
	for _, mc := range modeConfigs() {
		for _, in := range smallInputs {
			t.Run(mc.name+"/"+in, func(t *testing.T) {
				cfg := mc.cfg
				coord := NewPipelineCoordinator(&cfg)
				output, stats := coord.Process(in)
				if len(output) == 0 {
					t.Fatalf("small input %q compressed to empty", in)
				}
				if stats == nil || stats.OriginalTokens == 0 {
					t.Errorf("expected non-zero OriginalTokens for %q", in)
				}
			})
		}
	}
}

// TestProcess_BudgetEnforced verifies layer 6 / final budget enforcement: when a
// Budget is configured, the final token count must respect it for inputs that
// start well above the budget. Exercises pipeline_early_exit + budget enforcer.
func TestProcess_BudgetEnforced(t *testing.T) {
	input := strings.Repeat("alpha beta gamma delta epsilon zeta eta theta iota kappa\n", 500)
	const budget = 50

	cfg := PipelineConfig{Mode: ModeAggressive, Budget: budget}
	coord := NewPipelineCoordinator(&cfg)

	output, stats := coord.Process(input)
	if len(output) == 0 {
		t.Fatal("budgeted compression produced empty output for non-empty input")
	}
	if stats.OriginalTokens <= budget {
		t.Fatalf("test input too small: OriginalTokens=%d, need > budget %d",
			stats.OriginalTokens, budget)
	}
	// Process() applies a final TruncateToBudget when FinalTokens > Budget.
	if stats.FinalTokens > budget {
		t.Errorf("FinalTokens = %d exceeds configured Budget %d", stats.FinalTokens, budget)
	}
}

// TestProcess_Deterministic asserts Process is deterministic: two fresh
// coordinators with identical config produce identical output and token stats
// for the same input. This indirectly covers the runLayerN sequence stability.
func TestProcess_Deterministic(t *testing.T) {
	for _, mc := range modeConfigs() {
		for _, in := range representativeInputs() {
			if in.input == "" {
				continue
			}
			t.Run(mc.name+"/"+in.name, func(t *testing.T) {
				cfg1 := mc.cfg
				cfg2 := mc.cfg
				c1 := NewPipelineCoordinator(&cfg1)
				c2 := NewPipelineCoordinator(&cfg2)

				out1, st1 := c1.Process(in.input)
				out2, st2 := c2.Process(in.input)

				if out1 != out2 {
					t.Errorf("non-deterministic output:\n  first len=%d\n  second len=%d",
						len(out1), len(out2))
				}
				if st1.OriginalTokens != st2.OriginalTokens || st1.FinalTokens != st2.FinalTokens {
					t.Errorf("non-deterministic stats: (%d,%d) vs (%d,%d)",
						st1.OriginalTokens, st1.FinalTokens, st2.OriginalTokens, st2.FinalTokens)
				}
			})
		}
	}
}

// TestProcess_Idempotent verifies that re-processing already-compressed output
// does not corrupt it to empty and does not inflate the token count. A second
// pass over compressed text should be a fixed-point-like no-growth operation.
func TestProcess_Idempotent(t *testing.T) {
	for _, mc := range modeConfigs() {
		for _, in := range representativeInputs() {
			if in.input == "" {
				continue
			}
			t.Run(mc.name+"/"+in.name, func(t *testing.T) {
				cfg := mc.cfg
				coord := NewPipelineCoordinator(&cfg)

				once, _ := coord.Process(in.input)
				if len(once) == 0 {
					t.Fatalf("first pass produced empty output")
				}

				twice, stats := coord.Process(once)
				if len(twice) == 0 {
					t.Fatalf("second pass corrupted output to empty")
				}
				// Re-compressing must not grow the token count.
				firstTokens := core.EstimateTokens(once)
				if stats.FinalTokens > firstTokens {
					t.Errorf("second pass inflated tokens: %d > %d", stats.FinalTokens, firstTokens)
				}
			})
		}
	}
}

// TestProcess_GuardrailFallbackProducesOutput exercises the quality guardrail
// branch in Process(): with the guardrail enabled the pipeline must still return
// non-empty output (either the validated result or the ModeMinimal fallback).
func TestProcess_GuardrailFallbackProducesOutput(t *testing.T) {
	input := "Critical: database connection failed after 3 retries. " +
		strings.Repeat("Stack frame detail line with context and identifiers. ", 40)

	cfg := PipelineConfig{Mode: ModeAggressive, EnableQualityGuardrail: true}
	coord := NewPipelineCoordinator(&cfg)

	output, stats := coord.Process(input)
	if len(output) == 0 {
		t.Fatal("guardrail-enabled pipeline produced empty output")
	}
	if stats == nil {
		t.Fatal("expected non-nil stats")
	}
	if stats.FinalTokens != core.EstimateTokens(output) {
		t.Errorf("FinalTokens %d does not match output token count %d",
			stats.FinalTokens, core.EstimateTokens(output))
	}
}

// TestRunGuardrailFallback_Direct covers runGuardrailFallback in isolation: it
// must build a ModeMinimal coordinator and return non-empty output for non-empty
// input without recursing (guardrail disabled in the fallback config).
func TestRunGuardrailFallback_Direct(t *testing.T) {
	cfg := PipelineConfig{Mode: ModeAggressive, EnableQualityGuardrail: true, Budget: 0}
	coord := NewPipelineCoordinator(&cfg)

	input := "important content that must survive the minimal fallback path"
	output, stats := coord.runGuardrailFallback(input)
	if len(output) == 0 {
		t.Fatal("fallback produced empty output")
	}
	if stats == nil {
		t.Fatal("expected non-nil fallback stats")
	}
	if stats.OriginalTokens != core.EstimateTokens(input) {
		t.Errorf("fallback OriginalTokens = %d, want %d", stats.OriginalTokens, core.EstimateTokens(input))
	}
}
