# shrike

[![Go](https://img.shields.io/badge/Go-1.22+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> Biblioteca de Go para compresión, filtrado y estimación de tokens de LLM, y escaneo de secretos.

## Instalación

```bash
go get github.com/GrayCodeAI/shrike
```

## Documentación

Consulta el [README en inglés](README.md) para la documentación completa.

## Subcomandos `shrike`

Los subcomandos `shrike` se proporcionan a través de Hawk ([github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk)).

## Licencia

[MIT](LICENSE)
