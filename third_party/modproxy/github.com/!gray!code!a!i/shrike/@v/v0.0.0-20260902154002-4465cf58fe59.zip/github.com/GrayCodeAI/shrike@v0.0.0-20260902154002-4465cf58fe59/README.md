# shrike

[![Go](https://img.shields.io/badge/Go-1.26+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![CI](https://github.com/GrayCodeAI/shrike/actions/workflows/ci.yml/badge.svg)](https://github.com/GrayCodeAI/shrike/actions/workflows/ci.yml)
[![Go Report Card](https://goreportcard.com/badge/github.com/GrayCodeAI/shrike)](https://goreportcard.com/report/github.com/GrayCodeAI/shrike)
[![Go Reference](https://pkg.go.dev/badge/github.com/GrayCodeAI/shrike.svg)](https://pkg.go.dev/github.com/GrayCodeAI/shrike)

> **Cut LLM token costs by 60–90%.** A Go **library** for prompt compression, output filtering, token estimation, and secrets scanning — built for AI coding agents.

---

## What shrike Is

shrike is a **library**, not a CLI. It exposes token-efficiency primitives as a clean Go API:

- **Prompt compression** — `shrike.PromptCompress` / `shrike.Compress` shrink verbose prompts 20–70% (six modes).
- **Output filtering** — a 31-layer pipeline (entropy pruning, perplexity filtering, AST-aware compression, H2O heavy-hitter, …) that strips noise from command output before it re-enters an LLM context.
- **Token estimation** — `shrike.EstimateTokens*` and `shrike.EstimateCost` give model-aware token counts and pricing.
- **Secrets scanning** — `shrike.SecretDetector` and `shrike.IsSensitiveFilename` catch credentials before they leak into prompts.
- **Usage limits & tracking** — thread-safe token/cost windows (`shrike.NewUsageTracker`) plus persistent SQLite-backed gain tracking (`shrike.NewTracker`).
- **Runtime graph projection** — privacy-safe compression, usage, budget, and redaction summaries (`runtimegraph.Build`).

It is consumed directly as a Go module, and it powers the `shrike` commands inside [Hawk](https://github.com/GrayCodeAI/hawk) (`hawk shrike ...`), which imports it as a library.

## Ecosystem Boundaries

shrike is a Hawk support engine. Keep the dependency edge one-way:

- use `eagle` for any cross-repo shared contracts
- do not import `hawk/internal/*`
- do not import removed legacy path `hawk/shared/types`; use `eagle/types`
- do not import other engines (`eyrie`, `harrier`, `swift`, `kestrel`, `merlin`) — engines are peers, not dependencies

---

## Install

```bash
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

> shrike ships no standalone `shrike` CLI binary. Its CLI surface is exposed through [Hawk](https://github.com/GrayCodeAI/hawk), which embeds this library: `hawk shrike compress`, `hawk shrike estimate`, and `hawk shrike scan`.

---

## Quick Start

### Compress a prompt

```go
out, _ := shrike.PromptCompress("Please implement authentication", shrike.IntensityUltra)
// → "Implement auth."
```

### Filter command output

```go
out, _ := shrike.Compress(verboseOutput, shrike.Aggressive)
// 200 lines → a few lines: pass/fail + failures
```

### Estimate tokens & cost

```go
n    := shrike.EstimateTokensForModel(text, "gpt-4o")
cost := shrike.EstimateCost(text, "gpt-4o")
```

### Scan for secrets

```go
d := shrike.NewSecretDetector()
findings := d.DetectSecrets(text)
redacted := d.RedactSecrets(text)
```

### Track usage and enforce a budget

```go
usage := shrike.NewUsageTracker()
usage.SetLimits(shrike.UsageLimits{
    HourlyTokens:  100_000,
    SessionTokens: 500_000,
    CostUSD:       10,
})

if allowed, _ := usage.CanProceed(); allowed {
    usage.Record(promptTokens+completionTokens, requestCostUSD, provider, model)
}

allowed, reason := usage.CanProceed()
snapshot := usage.GetUsage()
```

`SetLimits` and `GetLimits` are safe to use while requests are being recorded.
Callers own request deduplication and decide whether a failed decision blocks
the current request or the next one.

---

## Library API Highlights

- **`shrike.PromptCompress(text, intensity)`** — prompt compression (Lite / Full / Ultra). ~150 phrase substitutions, drop-lists for articles / filler / pleasantries, and auto-clarity (security/destructive segments pass through verbatim). `intensity` is monotonic: `len(ultra) <= len(full) <= len(lite)`.
- **`shrike.Compress(text, opts...)`** — the full output pipeline with options: `WithCustomFilters`, `WithCodeAware(lang)`, `WithPerplexityGuided(scorer, ratio)`, profile options, and more.
- **`shrike.IsSensitiveFilename(path)`** — 3-layer filename detection (exact basename, sensitive directory, name token). Companion to the content-based `SecretDetector`. Catches `.env`, `id_rsa`, `~/.ssh/...`, `test_credentials.json`, etc.
- **`shrike.SmartTruncate(content, maxLines, lang)`** — code truncation that preserves function signatures and **always reports the exact drop count** (`kept + dropped == total`).
- **`shrike.ExtractJSON / ExtractJSONArray / ExtractAllJSON`** — brace-balanced JSON extraction from LLM output with surrounding prose, markdown fences, and unterminated objects.
- **`shrike.NewTracker(ctx)`** — persistent gain tracker (SQLite + WAL, 90-day retention, pure-Go via `modernc.org/sqlite`). `Aggregate`, `Recent`, `Prune` queries.
- **`shrike.NewUsageTracker()`** — in-memory hourly, daily, session, and cost accounting with atomic limit snapshots and threshold decisions.
- **`shrike.EstimateTokensFast / WithEncoding / ForModel`** — model-aware token estimation.
- **`filter.CompressWithRetry`** — validate-fix-retry loop: caller supplies a `Validator` and `AdjustFunc`; the loop escalates mode/intensity and retries up to N times.
- **`filter.NewTOMLFilter` / `LoadTOMLFilterFile`** — full 8-stage TOML pipeline as a pluggable `Filter`.

Full reference: [pkg.go.dev/github.com/GrayCodeAI/shrike](https://pkg.go.dev/github.com/GrayCodeAI/shrike).

---

## Compression Modes

| Mode | Style | Savings |
|------|-------|---------|
| `lite` | Drop filler, keep grammar | ~20% |
| `full` | Drop articles, fragments OK | ~40% _(default)_ |
| `ultra` | Telegraphic, abbreviations | ~60% |
| `wenyan-lite` | Classical Chinese light | ~30% |
| `wenyan` | Classical Chinese standard | ~50% |
| `wenyan-ultra` | Classical Chinese max | ~70% |

### Output Filtering (31-Layer Pipeline)

Research-backed algorithms: entropy pruning, perplexity filtering, AST-aware compression, H2O heavy-hitter, attention sink preservation, semantic chunking, and 25+ more.

### Custom Filter DSL

Define regex find/replace rules in a TOML file and plug them into the pipeline. Opt-in — no rules, no change.

```toml
# filters.toml
[[rule]]
name        = "collapse-uuids"
pattern     = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
replacement = "<uuid>"
priority    = 10
```

```go
rules, _ := shrike.LoadFilterRules("filters.toml")
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

### Team / Shared Compression Profiles

Bundle mode + tier + budget into a named, versioned TOML profile teams can share. Built-ins: `default`, `aggressive`, `code-safe`.

```go
p, _ := shrike.LoadProfile(".shrike/profiles/code-safe.toml")
out, _ := shrike.Compress(text, p.Options()...)
```

### Code-Aware (Symbol-Preserving) Compression

`shrike.WithCodeAware(lang)` marks input as source code and guards function/type/export signatures so compression can never strip them. Defaults to a dependency-light regex symbol provider; swap in an LSP-backed one via `WithSymbolProvider`.

### Perplexity-Guided Token Dropping

`shrike.WithPerplexityGuided(scorer, ratio)` (LLMLingua-style) drops the lowest-importance tokens first. Default `HeuristicPerplexityScorer` is zero-dependency; plug in your own `PerplexityScorer`, or shrike's experimental `OllamaScorer` when built with `-tags experimental_ollama`. Opt-in.

---

## Benchmarks

Measured on this repo via `benchmarks/run.sh` (raw vs `shrike.Compress(..., shrike.Aggressive)`):

| fixture   | raw bytes | raw tokens | shrike bytes | shrike tokens | saved |
|-----------|----------:|-----------:|----------:|-----------:|------:|
| git log   |     2,873 |        718 |       298 |         74 |  89 % |
| git diff  |   385,051 |     96,262 |     1,117 |        279 |  99 % |
| ls -la    |    66,341 |     16,585 |       148 |         37 |  99 % |
| find .go  |    19,145 |      4,786 |       147 |         36 |  99 % |

Profile the hot paths with `./scripts/profile.sh [compress|tokens|filter|secrets|all]`.

---

## Architecture

```
shrike
├── shrike.go, *.go         Public library API (top-level package)
├── runtimegraph/        Privacy-safe operations/policy/quality projection
├── internal/
│   ├── compress/        Input compression engine (6 modes)
│   ├── filter/          Output pipeline (31 layers)
│   ├── secrets/         Secret detection + redaction
│   ├── tracking/        SQLite token-usage database
│   ├── fastops/         Hot-path primitives (entropy, etc.)
│   └── core/            Token estimation & cost
├── benchmarks/          Token-savings benchmarks
└── evals/               Eval harness
```

Pure-Go, zero CGO, no runtime dependencies.

`runtimegraph.Build` projects completed compression statistics, usage
snapshots, budget decisions, and redaction summaries into `shrike.graph/v1`.
Input text, model names, budget reasons, secret types, and secret values are
digest-only. Shrike remains the source of truth for compression, limits, and
redaction; graph consumers receive immutable summaries.

---

## Contributing

```bash
git clone https://github.com/GrayCodeAI/shrike.git && cd shrike
make test && make lint
./scripts/build.sh        # verifies the library compiles (go build ./... + go vet)
```

See [CONTRIBUTING.md](CONTRIBUTING.md).

---

## License

[MIT](LICENSE)
