# shrike

[![Go](https://img.shields.io/badge/Go-1.22+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

shrike 是一个 Go 库，用于 LLM 令牌压缩、过滤、估算以及密钥扫描。

## 安装

```bash
go get github.com/GrayCodeAI/shrike
```

## 更多文档

请参阅[英文 README](README.md) 获取完整文档。

## CLI 子命令

`shrike` 子命令由 Hawk 提供（[github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk)）。

## 许可证

[MIT](LICENSE)
