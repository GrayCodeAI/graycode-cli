package filter

import (
	"strings"
	"testing"
)

// Regression tests for budget enforcement edge cases.

func TestTruncateToBudgetNeverReturnsEmptyForNonEmptyInput(t *testing.T) {
	f := NewBudgetEnforcer(50)
	// A single word that dominates the whole budget: the old binary search
	// returned "" because it could not fit even one word.
	in := strings.Repeat("supercalifragilistic", 2000) // ~72k chars, way over 50 tokens
	out := f.TruncateToBudget(in, 50)
	if out == "" {
		t.Fatal("TruncateToBudget returned empty string for non-empty input")
	}
	if strings.Contains(out, " ") {
		t.Fatalf("expected a fragment of the single word, got %q", out)
	}
	if len(out) > len(in) {
		t.Fatalf("output longer than input")
	}
}

func TestTruncateToBudgetFitsBudget(t *testing.T) {
	f := NewBudgetEnforcer(40)
	in := strings.Join(strings.Fields("word one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen"), " ")
	in = strings.Repeat(in+" ", 100)
	out := f.TruncateToBudget(in, 40)
	if out == "" {
		t.Fatal("expected non-empty truncation")
	}
	// Allow a small slack: the fast estimator drives the search, then the
	// precise trim-back guarantees compliance.
	if EstimateTokens(out) > 45 {
		t.Fatalf("truncated output exceeds budget: %d tokens for budget 40", EstimateTokens(out))
	}
	if !strings.HasPrefix(in, out) {
		t.Fatalf("truncation must be a prefix of the input")
	}
}

func TestBudgetZeroIsNoOp(t *testing.T) {
	// Budget 0 (or negative) disables enforcement entirely: input passes
	// through untouched, even when far over any plausible budget.
	f := NewBudgetEnforcer(0)
	in := strings.Repeat("this is a fairly long sentence with useful facts. ", 500)
	out, saved := f.Apply(in, ModeMinimal)
	if out != in {
		t.Fatalf("budget 0 must be a no-op, got %d/%d chars", len(out), len(in))
	}
	if saved != 0 {
		t.Fatalf("expected 0 tokens saved, got %d", saved)
	}
}

func TestTruncateToBudgetBudgetZero(t *testing.T) {
	f := NewBudgetEnforcer(0)
	// Guard: budget <= 0 returns "" (callers must not pass 0 as a real limit).
	out := f.TruncateToBudget("some words here", 0)
	if out != "" {
		t.Fatalf("expected empty for zero budget, got %q", out)
	}
}
