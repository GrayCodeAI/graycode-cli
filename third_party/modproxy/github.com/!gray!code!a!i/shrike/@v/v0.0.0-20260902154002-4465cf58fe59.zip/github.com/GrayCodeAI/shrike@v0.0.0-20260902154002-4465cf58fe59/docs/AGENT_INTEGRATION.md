# Integrating shrike with AI Coding Agents

`shrike` is a Go **library** (`github.com/GrayCodeAI/shrike`) for compressing text
before it enters an LLM context window. It ships no `shrike` CLI binary and installs
no shell hooks or agent plugins. If you remember verbs like `shrike compress`,
`shrike gain`, or `shrike init`, those live in **Hawk**
(`github.com/GrayCodeAI/hawk`), which embeds this library and exposes them as
`hawk shrike ...` subcommands.

This guide shows the supported ways to wire shrike into an agent: call the Go API
directly from a Go agent, or use the `hawk shrike ...` subcommands from any
language by shelling out to the Hawk CLI.

```
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

---

## How agents use shrike

There are two integration surfaces, neither of which rewrites your shell:

1. **In-process (Go agents):** import the package and call `shrike.Compress` /
   `shrike.PromptCompress` on noisy tool output, file contents, or prompts before
   you send them to the model.
2. **Out-of-process (any language):** shell out to `hawk shrike ...`, which embeds
   this library and exposes its functionality as CLI subcommands.

A typical pattern: an agent runs a command like `git status` itself, captures the
output, and passes that text through shrike to shrink it (~2000 tokens down to
~200) before adding it to the model's context. shrike never intercepts or rewrites
the command; the agent decides what text to compress.

---

## In-process Go API

### Compress tool output or context

```go
out, stats := shrike.Compress(rawOutput, shrike.Aggressive)
// stats.OriginalTokens, stats.FinalTokens, stats.TokensSaved
```

Common options:

```go
shrike.Compress(text, shrike.WithBudget(4000))        // hard output token cap
shrike.Compress(text, shrike.WithCodeAware("go"))     // preserve symbols/signatures
shrike.Compress(text, shrike.WithMode(shrike.ModeAggressive))
```

### Compress a prompt

```go
out, _ := shrike.PromptCompress(prompt, shrike.IntensityFull)
// IntensityLite | IntensityFull | IntensityUltra
```

### Estimate tokens and cost

```go
cost := shrike.EstimateCost(text, "gpt-4o")
```

### Redact secrets before sending context to a model

```go
det := shrike.NewSecretDetector()
clean := det.Redact(text)

if shrike.IsSensitiveFilename(path) {
    // skip or mask this file
}
```

### Truncate and extract structured data

```go
short := shrike.SmartTruncate(text, maxTokens)
obj, ok := shrike.ExtractJSON(modelReply)
```

### Track token usage across a session

```go
tr := shrike.NewTracker(ctx)
// record compressions / estimates as the agent runs
```

### Custom filters (TOML)

User-defined regex find/replace rules live in TOML files and load via
`shrike.LoadFilterRules`, then attach with `shrike.WithCustomFilters`:

```go
rules, _ := shrike.LoadFilterRules("filters/agent.toml")
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

Profiles bundle option presets and are loaded with `shrike.LoadProfile`.

### Perplexity-guided dropping

```go
out, _ := shrike.Compress(text, shrike.WithPerplexityGuided(scorer, 0.3))
```

---

## Using shrike through Hawk

If you want CLI verbs rather than code, Hawk (`github.com/GrayCodeAI/hawk`)
embeds this library and exposes its functionality as subcommands, e.g.:

```bash
hawk shrike compress ...
hawk shrike estimate ...
```

Refer to the Hawk documentation for the full set of `hawk shrike` verbs and for any
agent-facing wiring Hawk provides on top of this library.

---

## Compression modes and tiers

`Compress` accepts a mode (aggressiveness) and an optional tier (pipeline
profile):

| Setting | Value | Notes |
|---------|-------|-------|
| Mode | `shrike.ModeMinimal` (default) | Conservative, lossless-leaning |
| Mode | `shrike.ModeAggressive` / `shrike.Aggressive` | Maximum reduction |
| Tier | `surface` | 4 layers, fast |
| Tier | `trim` | 8 layers, balanced |
| Tier | `extract` | 20 layers, max compression |
| Tier | `core` | 20 layers, quality-first (default) |
| Tier | `code` | code-aware |
| Tier | `log` | log-aware |
| Tier | `thread` | conversation-aware |
| Tier | `adaptive` | auto-detect content type |

Prompt-level compression uses intensity instead: `shrike.IntensityLite`,
`shrike.IntensityFull`, `shrike.IntensityUltra`.

---

## Benchmarks

Benchmarks are plain Go benchmarks driven by wrapper scripts:

```bash
./benchmarks/run.sh          # wraps `go test -bench`
./evals/pipeline-bench.sh    # pipeline evaluation, also `go test -bench`
```

---

## Architecture notes

- The public API lives in the package root (`shrike.go`, `compress.go`,
  `options.go`, `cost.go`, `secrets.go`, `extract.go`, `tracker.go`,
  `profile.go`, `filters.go`, `perplexity.go`).
- The compression pipeline itself lives under `internal/`.
- Example usage lives under `examples/` and in `example_test.go`.
- Custom filter TOML rules live under `filters/` and `rules/`.
