package secrets

import (
	"strings"
	"testing"
)

func TestDetectSecrets_CommonProviderTokens(t *testing.T) {
	sd := NewDetector()

	cases := []struct {
		name     string
		text     string
		wantType string
		wantVal  string
	}{
		{"AWS access key", "key=AKIAIOSFODNN7EXAMPLE here", "AWS Access Key", "AKIAIOSFODNN7EXAMPLE"},
		{"GitHub token", "token ghp_0123456789abcdefghijklmnopqrstuvwxyz end", "GitHub Token", "ghp_0123456789abcdefghijklmnopqrstuvwxyz"},
		{"GitLab token", "glpat-ABCDEFGHIJ1234567890 x", "GitLab Token", "glpat-ABCDEFGHIJ1234567890"},
		// NOTE: deliberately a fake test-mode key with a non-secret body so GitHub
		// Push Protection does not flag the fixture as a live credential.
		{"Stripe secret", "sk_test_EXAMPLEEXAMPLEEXAMPLE0000 end", "Stripe Secret Key", "sk_test_EXAMPLEEXAMPLEEXAMPLE0000"},
		{"Google API key", "AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ0123456 x", "Google API Key", "AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ0123456"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			matches := sd.DetectSecrets(tc.text)
			if len(matches) == 0 {
				t.Fatalf("expected a secret match in %q, got none", tc.text)
			}
			found := false
			for _, m := range matches {
				if m.Value == tc.wantVal {
					found = true
					if m.Type != tc.wantType {
						t.Errorf("value %q classified as %q, want %q", tc.wantVal, m.Type, tc.wantType)
					}
					// Position must point at the actual value in the text.
					if tc.text[m.StartPos:m.EndPos] != m.Value {
						t.Errorf("StartPos/EndPos (%d:%d) does not slice to the value %q (got %q)",
							m.StartPos, m.EndPos, m.Value, tc.text[m.StartPos:m.EndPos])
					}
				}
			}
			if !found {
				t.Errorf("did not find expected value %q among matches %+v", tc.wantVal, matches)
			}
		})
	}
}

func TestDetectSecrets_NoFalsePositiveOnPlainText(t *testing.T) {
	sd := NewDetector()
	clean := "The quick brown fox jumps over the lazy dog. Total: 42 items."
	if got := sd.DetectSecrets(clean); len(got) != 0 {
		t.Errorf("expected no secrets in plain text, got %+v", got)
	}
}

func TestDetectSecrets_MatchesAreSortedByPosition(t *testing.T) {
	sd := NewDetector()
	text := "first AKIAIOSFODNN7EXAMPLE then ghp_0123456789abcdefghijklmnopqrstuvwxyz last"
	matches := sd.DetectSecrets(text)
	if len(matches) < 2 {
		t.Fatalf("expected at least 2 matches, got %d", len(matches))
	}
	for i := 1; i < len(matches); i++ {
		if matches[i].StartPos < matches[i-1].StartPos {
			t.Errorf("matches not sorted by StartPos: %d before %d", matches[i-1].StartPos, matches[i].StartPos)
		}
	}
}

func TestRedactSecrets(t *testing.T) {
	sd := NewDetector()

	t.Run("redacts a token and labels its type", func(t *testing.T) {
		in := "export GITHUB_TOKEN=ghp_0123456789abcdefghijklmnopqrstuvwxyz"
		out := sd.RedactSecrets(in)
		if strings.Contains(out, "ghp_0123456789abcdefghijklmnopqrstuvwxyz") {
			t.Errorf("raw secret leaked into redacted output: %q", out)
		}
		if !strings.Contains(out, "[REDACTED:") {
			t.Errorf("expected a [REDACTED:...] marker, got %q", out)
		}
	})

	t.Run("returns text unchanged when no secrets", func(t *testing.T) {
		in := "just some ordinary configuration text"
		if out := sd.RedactSecrets(in); out != in {
			t.Errorf("clean text was modified: %q -> %q", in, out)
		}
	})

	t.Run("preserves non-secret surroundings", func(t *testing.T) {
		in := "BEGIN ghp_0123456789abcdefghijklmnopqrstuvwxyz END"
		out := sd.RedactSecrets(in)
		if !strings.HasPrefix(out, "BEGIN ") || !strings.HasSuffix(out, " END") {
			t.Errorf("surrounding text not preserved: %q", out)
		}
	})
}

func TestRedactSecrets_PrivateKeyBlock(t *testing.T) {
	sd := NewDetector()
	in := "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAabc123\nlinetwo\n-----END RSA PRIVATE KEY-----"
	out := sd.RedactSecrets(in)
	if strings.Contains(out, "MIIEpAIBAAKCAQEAabc123") {
		t.Errorf("private key body leaked: %q", out)
	}
	if !strings.Contains(out, "[REDACTED:") {
		t.Errorf("expected redaction marker, got %q", out)
	}
}

func TestMaskSecret(t *testing.T) {
	cases := []struct {
		name  string
		value string
		want  string
	}{
		{"long value shows first/last 4", "ghp_0123456789abcdef", "ghp_************cdef"},
		{"short value fully masked", "abc123", "******"},
		{"exactly 8 chars fully masked", "12345678", "********"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := MaskSecret(tc.value, "Generic"); got != tc.want {
				t.Errorf("MaskSecret(%q) = %q, want %q", tc.value, got, tc.want)
			}
		})
	}
}

func TestMaskSecret_PrivateKeyKeepsHeader(t *testing.T) {
	// The header-preserving branch only triggers when both BEGIN and END markers
	// are present and the value contains a newline after the header line.
	in := "-----BEGIN RSA PRIVATE KEY-----\nbodybodybody\n-----END RSA PRIVATE KEY-----"
	got := MaskSecret(in, "RSA Private Key")
	if !strings.HasPrefix(got, "-----BEGIN RSA PRIVATE KEY-----") {
		t.Errorf("expected header preserved, got %q", got)
	}
	if strings.Contains(got, "bodybodybody") {
		t.Errorf("key body leaked: %q", got)
	}
	if !strings.Contains(got, "[REDACTED]") {
		t.Errorf("expected [REDACTED] body marker, got %q", got)
	}
}

func TestDefaultDetector_IsSingleton(t *testing.T) {
	a := DefaultDetector()
	b := DefaultDetector()
	if a != b {
		t.Error("DefaultDetector should return the same singleton instance")
	}
	if a == nil {
		t.Fatal("DefaultDetector returned nil")
	}
	// And it should actually detect.
	if got := a.DetectSecrets("AKIAIOSFODNN7EXAMPLE"); len(got) == 0 {
		t.Error("singleton detector failed to detect a known secret")
	}
}

func TestDetectAndRedactWithEntropy(t *testing.T) {
	sd := NewDetector()

	t.Run("high-entropy long string is redacted", func(t *testing.T) {
		// A long, random-looking string with no pattern match should trip entropy.
		highEntropy := "Zk9bX2qWp7mLrT4vNc8dHsYfJ1aBeUoQ"
		out := sd.DetectAndRedactWithEntropy("value "+highEntropy, 3.5)
		if strings.Contains(out, highEntropy) {
			t.Errorf("expected high-entropy token to be redacted, got %q", out)
		}
		if !strings.Contains(out, "[REDACTED:HIGH_ENTROPY]") {
			t.Errorf("expected HIGH_ENTROPY marker, got %q", out)
		}
	})

	t.Run("low-entropy words survive", func(t *testing.T) {
		in := "the cat sat on the mat"
		out := sd.DetectAndRedactWithEntropy(in, 3.5)
		if out != in {
			t.Errorf("low-entropy text should be unchanged: %q -> %q", in, out)
		}
	})

	t.Run("short high-entropy strings are not redacted", func(t *testing.T) {
		// Under the 16-char length guard, even high entropy should be kept.
		in := "aB3dEf"
		out := sd.DetectAndRedactWithEntropy(in, 1.0)
		if out != in {
			t.Errorf("short string should not be redacted: %q -> %q", in, out)
		}
	})
}
