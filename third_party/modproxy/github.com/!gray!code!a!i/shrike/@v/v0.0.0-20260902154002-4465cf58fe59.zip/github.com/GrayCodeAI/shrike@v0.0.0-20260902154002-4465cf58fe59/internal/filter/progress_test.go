package filter

import (
	"testing"
)

func TestSetProgressCallback(t *testing.T) {
	called := false
	cb := func(layerName string, inputTokens, outputTokens int, progressPercent float64) {
		called = true
	}

	SetProgressCallback(cb)
	got := GetProgressCallback()
	if got == nil {
		t.Fatal("GetProgressCallback returned nil")
	}

	got("layer1", 100, 80, 50.0)
	if !called {
		t.Error("progress callback should have been called")
	}
}

func TestGetProgressCallbackDefault(t *testing.T) {
	SetProgressCallback(nil)
	cb := GetProgressCallback()
	if cb != nil {
		t.Error("GetProgressCallback should return nil when not set")
	}
}

func TestProgressCallbackInvocation(t *testing.T) {
	var capturedLayer string
	var capturedInputTokens, capturedOutputTokens int
	var capturedProgress float64

	cb := func(layerName string, inputTokens, outputTokens int, progressPercent float64) {
		capturedLayer = layerName
		capturedInputTokens = inputTokens
		capturedOutputTokens = outputTokens
		capturedProgress = progressPercent
	}

	SetProgressCallback(cb)
	GetProgressCallback()("test-layer", 500, 300, 75.5)

	if capturedLayer != "test-layer" {
		t.Errorf("expected layer name %q, got %q", "test-layer", capturedLayer)
	}
	if capturedInputTokens != 500 {
		t.Errorf("expected input tokens %d, got %d", 500, capturedInputTokens)
	}
	if capturedOutputTokens != 300 {
		t.Errorf("expected output tokens %d, got %d", 300, capturedOutputTokens)
	}
	if capturedProgress != 75.5 {
		t.Errorf("expected progress %f, got %f", 75.5, capturedProgress)
	}
}

func TestProgressCallbackNilAfterClear(t *testing.T) {
	SetProgressCallback(func(layerName string, inputTokens, outputTokens int, progressPercent float64) {})
	SetProgressCallback(nil)

	cb := GetProgressCallback()
	if cb != nil {
		t.Error("progress callback should be nil after clearing")
	}
}

func TestProgressCallbackGoroutineSafety(t *testing.T) {
	done := make(chan bool)

	for i := 0; i < 10; i++ {
		go func(n int) {
			SetProgressCallback(func(layerName string, inputTokens, outputTokens int, progressPercent float64) {})
			GetProgressCallback()
			done <- true
		}(i)
	}

	for i := 0; i < 10; i++ {
		<-done
	}
}
