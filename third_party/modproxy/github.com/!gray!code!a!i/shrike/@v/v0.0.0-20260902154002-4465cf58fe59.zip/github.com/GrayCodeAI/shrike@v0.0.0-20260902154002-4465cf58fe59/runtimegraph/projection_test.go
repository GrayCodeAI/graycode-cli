package runtimegraph_test

import (
	"encoding/json"
	"strings"
	"testing"
	"time"

	graphcontracts "github.com/GrayCodeAI/shrike/graph"
	"github.com/GrayCodeAI/shrike"
	"github.com/GrayCodeAI/shrike/runtimegraph"
)

func TestBuildMixedPrivacySafeProjection(t *testing.T) {
	t.Parallel()
	at := time.Date(2026, 7, 25, 14, 0, 0, 0, time.UTC)
	stats := shrike.Stats{OriginalTokens: 100, FinalTokens: 40, TokensSaved: 60, Model: "private-model"}
	usage := shrike.UsageSummary{HourlyTokens: 10, SessionTokens: 20, DailyCostUSD: .5}
	export, err := runtimegraph.Build(runtimegraph.Input{
		Compression: &stats, Usage: &usage,
		Budget:    &runtimegraph.BudgetDecision{Allowed: false, Reason: "private budget reason", HourlyLimit: 10},
		Redaction: &runtimegraph.RedactionSummary{MatchCount: 2, Types: map[string]int{"OpenAI API Key": 2}},
		Source:    "private source with sk-secret", ObservedAt: at,
		Scope: graphcontracts.Scope{RepositoryID: "repo"}, CorrelationID: "session-1",
	})
	if err != nil {
		t.Fatalf("Build() error = %v", err)
	}
	if len(export.Nodes) != 4 || len(export.Edges) != 1 || len(export.Events) != 4 {
		t.Fatalf("unexpected sizes: nodes=%d edges=%d events=%d", len(export.Nodes), len(export.Edges), len(export.Events))
	}
	payload, _ := json.Marshal(export)
	for _, secret := range []string{"private source with sk-secret", "private budget reason", "private-model", "OpenAI API Key"} {
		if strings.Contains(string(payload), secret) {
			t.Fatalf("projection leaked %q", secret)
		}
	}
	kinds := map[graphcontracts.NodeKind]bool{}
	for _, node := range export.Nodes {
		kinds[node.Kind] = true
		if err := node.Validate(); err != nil {
			t.Fatalf("invalid node: %v", err)
		}
	}
	for _, want := range []graphcontracts.NodeKind{graphcontracts.NodeOperations, graphcontracts.NodePolicy, graphcontracts.NodeQuality} {
		if !kinds[want] {
			t.Fatalf("missing node kind %q", want)
		}
	}
}

func TestBuildRequiresSummary(t *testing.T) {
	t.Parallel()
	if _, err := runtimegraph.Build(runtimegraph.Input{}); err == nil {
		t.Fatal("expected empty input error")
	}
}
