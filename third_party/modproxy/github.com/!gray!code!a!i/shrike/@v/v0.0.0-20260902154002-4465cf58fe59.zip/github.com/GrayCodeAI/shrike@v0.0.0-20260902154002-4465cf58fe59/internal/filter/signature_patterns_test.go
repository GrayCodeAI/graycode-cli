package filter

import (
	"testing"
)

func TestSignaturePatterns(t *testing.T) {
	if len(SignaturePatterns) == 0 {
		t.Fatal("SignaturePatterns should not be empty")
	}

	// Test that patterns match expected code
	tests := []struct {
		patternIdx  int
		input       string
		shouldMatch bool
	}{
		{0, "fn main()", true},          // Rust fn (index 0)
		{1, "struct Point", true},       // Rust struct (index 1)
		{6, "func main()", true},        // Go func (index 6)
		{7, "type Point struct", true},  // Go type struct (index 7)
		{9, "def hello()", true},        // Python def (index 9)
		{10, "async def hello()", true}, // Python async def (index 10)
		{11, "class MyClass", true},     // Python class (index 11)
		{12, "function hello()", true},  // JS function (index 12)
		{16, "interface User", true},    // TS interface (index 16)
		{17, "type MyType =", true},     // TS type alias (index 17)
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			if tt.patternIdx >= len(SignaturePatterns) {
				t.Skip("pattern index out of range")
			}
			result := SignaturePatterns[tt.patternIdx].MatchString(tt.input)
			if result != tt.shouldMatch {
				t.Errorf("pattern[%d].MatchString(%q) = %v, expected %v", tt.patternIdx, tt.input, result, tt.shouldMatch)
			}
		})
	}
}

func TestImportPatterns(t *testing.T) {
	if len(ImportPatterns) == 0 {
		t.Fatal("ImportPatterns should not be empty")
	}

	tests := []struct {
		input       string
		shouldMatch bool
	}{
		{"use std::io;", true},
		{"import os", true},
		{"from pathlib import Path", true},
		{"require('fs')", true},
		{"import (", true},
		{`import "fmt"`, true},
		{"#include <stdio.h>", true},
		{`#include "local.h"`, true},
		{"package main", true},
		{"not an import", false},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			matched := false
			for _, pattern := range ImportPatterns {
				if pattern.MatchString(tt.input) {
					matched = true
					break
				}
			}
			if matched != tt.shouldMatch {
				t.Errorf("ImportPatterns match for %q = %v, expected %v", tt.input, matched, tt.shouldMatch)
			}
		})
	}
}

func TestBlockDelimiters(t *testing.T) {
	if len(BlockDelimiters) != 3 {
		t.Errorf("expected 3 block delimiters, got %d", len(BlockDelimiters))
	}

	if BlockDelimiters['{'] != '}' {
		t.Error("expected '{' -> '}' mapping")
	}
	if BlockDelimiters['['] != ']' {
		t.Error("expected '[' -> ']' mapping")
	}
	if BlockDelimiters['('] != ')' {
		t.Error("expected '(' -> ')' mapping")
	}
}

func TestSignaturePatternsMatchVariousCode(t *testing.T) {
	codeSamples := []string{
		"fn main() {",
		"pub fn hello() -> String {",
		"struct Point { x: i32 }",
		"enum Color { Red, Green }",
		"trait Display { fn fmt(&self); }",
		"type MyType = String;",
		"impl MyStruct { fn method(&self) {} }",
		"func main() {}",
		"func (r Receiver) Method() {}",
		"type Point struct { X, Y int }",
		"type Handler interface { Serve() }",
		"def greet():",
		"async def fetch():",
		"class MyClass:",
		"function hello() {",
		"export default function() {",
		"export class MyComponent {",
		"const handler = async () => {",
		"interface User {",
		"type MyType = string;",
		"public class MainClass {",
		"private static void main(String[] args) {",
	}

	for _, sample := range codeSamples {
		t.Run(sample, func(t *testing.T) {
			matched := false
			for _, pattern := range SignaturePatterns {
				if pattern.MatchString(sample) {
					matched = true
					break
				}
			}
			if !matched {
				t.Errorf("no signature pattern matched: %q", sample)
			}
		})
	}
}

func TestImportPatternsMatchVariousImports(t *testing.T) {
	importSamples := []string{
		"use std::io;",
		"use std::fs::{File, OpenOptions};",
		"import os",
		"import sys, json",
		"from pathlib import Path",
		"from . import module",
		"require('fs')",
		"import { readFile } from 'fs';",
		"import * as path from 'path';",
		"import 'styles.css';",
		"#include <stdio.h>",
		"#include \"local.h\"",
		"package main",
		"package com.example.app",
	}

	for _, sample := range importSamples {
		t.Run(sample, func(t *testing.T) {
			matched := false
			for _, pattern := range ImportPatterns {
				if pattern.MatchString(sample) {
					matched = true
					break
				}
			}
			if !matched {
				t.Errorf("no import pattern matched: %q", sample)
			}
		})
	}
}
