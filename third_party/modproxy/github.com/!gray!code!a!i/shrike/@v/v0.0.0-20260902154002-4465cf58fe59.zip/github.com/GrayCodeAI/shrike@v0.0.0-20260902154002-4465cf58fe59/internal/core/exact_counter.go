package core

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// exactCountClient is used for opt-in exact-count API calls. It is a var
// (not embedded per-call) so tests can override it, and is only ever
// touched by CountTokensExact — never by EstimateTokens/EstimateTokensPrecise,
// which remain fully offline and unchanged.
var exactCountClient = &http.Client{Timeout: 10 * time.Second}

// anthropicCountTokensURL and googleCountTokensURL are vars (not consts) so
// tests can point them at a local mock server.
var (
	anthropicCountTokensURL = "https://api.anthropic.com/v1/messages/count_tokens"
	googleCountTokensURL    = "https://generativelanguage.googleapis.com/v1beta/models/%s:countTokens"
)

// CountTokensExact returns the exact token count for text under the real
// tokenizer of the model's provider (Anthropic or Google), by calling that
// provider's live count-tokens API. This exists because neither Anthropic
// nor Google publish an offline BPE tokenizer library — EstimateTokens and
// friends only approximate Claude/Gemini counts via OpenAI's cl100k_base
// encoding (see ClaudeBase/GeminiBase in the shrike package).
//
// apiKey is required and is never read from the environment implicitly:
// this function makes a real network call using the given text and key, and
// is never invoked by any other function in this package — callers must opt
// in explicitly. model must have a "claude" or "gemini" prefix (case
// insensitive); any other prefix returns an error rather than silently
// falling back to an approximation.
func CountTokensExact(ctx context.Context, apiKey, model, text string) (int, error) {
	if apiKey == "" {
		return 0, fmt.Errorf("shrike: CountTokensExact: apiKey is required")
	}
	lower := strings.ToLower(strings.TrimSpace(model))
	switch {
	case strings.HasPrefix(lower, "claude"):
		return countTokensAnthropic(ctx, apiKey, model, text)
	case strings.HasPrefix(lower, "gemini"):
		return countTokensGoogle(ctx, apiKey, model, text)
	default:
		return 0, fmt.Errorf("shrike: CountTokensExact: unsupported model %q (must be a claude* or gemini* model)", model)
	}
}

func countTokensAnthropic(ctx context.Context, apiKey, model, text string) (int, error) {
	body, err := json.Marshal(map[string]any{
		"model": model,
		"messages": []map[string]string{
			{"role": "user", "content": text},
		},
	})
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: marshal request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, anthropicCountTokensURL, bytes.NewReader(body))
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	resp, err := exactCountClient.Do(req)
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: request failed: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		data, _ := io.ReadAll(resp.Body)
		return 0, fmt.Errorf("shrike: CountTokensExact: anthropic API returned %d: %s", resp.StatusCode, string(data))
	}

	var out struct {
		InputTokens int `json:"input_tokens"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: decode response: %w", err)
	}
	return out.InputTokens, nil
}

func countTokensGoogle(ctx context.Context, apiKey, model, text string) (int, error) {
	body, err := json.Marshal(map[string]any{
		"contents": []map[string]any{
			{"parts": []map[string]string{{"text": text}}},
		},
	})
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: marshal request: %w", err)
	}

	endpoint := fmt.Sprintf(googleCountTokensURL, url.PathEscape(model)) + "?key=" + url.QueryEscape(apiKey)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := exactCountClient.Do(req)
	if err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: request failed: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		data, _ := io.ReadAll(resp.Body)
		return 0, fmt.Errorf("shrike: CountTokensExact: google API returned %d: %s", resp.StatusCode, string(data))
	}

	var out struct {
		TotalTokens int `json:"totalTokens"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return 0, fmt.Errorf("shrike: CountTokensExact: decode response: %w", err)
	}
	return out.TotalTokens, nil
}
