// Persistent gain tracking — public API.
//
// Wraps internal/tracking to expose a top-level shrike.Tracker type that
// records compression events to a local SQLite database and supports
// aggregate queries for dashboards, budgets, and self-tuning.
//
// Default location: ~/.shrike/tracker.db (WAL mode, 90-day retention).
package shrike

import (
	"context"

	"github.com/GrayCodeAI/shrike/internal/tracking"
)

// TrackerEvent is a single compression event recorded by the tracker.
type TrackerEvent = tracking.Event

// TrackerAggregate is the result of an aggregate query.
type TrackerAggregate = tracking.Aggregate

// Tracker is a persistent gain tracker. Safe for concurrent use.
type Tracker struct {
	inner *tracking.Tracker
}

// NewTracker creates a tracker at the default path (~/.shrike/tracker.db).
func NewTracker(ctx context.Context) (*Tracker, error) {
	tr, err := tracking.New(ctx)
	if err != nil {
		return nil, err
	}
	return &Tracker{inner: tr}, nil
}

// NewTrackerAt creates a tracker at a custom path.
func NewTrackerAt(ctx context.Context, path string) (*Tracker, error) {
	tr, err := tracking.NewAt(ctx, path)
	if err != nil {
		return nil, err
	}
	return &Tracker{inner: tr}, nil
}

// WithRetention overrides the default 90-day retention period.
func (t *Tracker) WithRetention(days int) *Tracker {
	t.inner.WithRetention(days)
	return t
}

// Record adds a new compression event. SavingsPct in the event is
// ignored; it's computed from byte counts.
func (t *Tracker) Record(ctx context.Context, ev TrackerEvent) error {
	return t.inner.Record(ctx, ev)
}

// Aggregate returns aggregate stats over the last `days` days (or
// the configured retention period if days is 0).
func (t *Tracker) Aggregate(ctx context.Context, days int) (TrackerAggregate, error) {
	return t.inner.Aggregate(ctx, days)
}

// Recent returns the most recent n events, newest first.
func (t *Tracker) Recent(ctx context.Context, n int) ([]TrackerEvent, error) {
	return t.inner.Recent(ctx, n)
}

// Prune deletes events older than the configured retention period.
func (t *Tracker) Prune(ctx context.Context) (int64, error) {
	return t.inner.Prune(ctx)
}

// Close releases the underlying DB. Safe to call multiple times.
func (t *Tracker) Close() error {
	return t.inner.Close()
}
