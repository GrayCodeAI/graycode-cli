#!/bin/bash
set -e

# Shrike build script.
#
# shrike is a Go LIBRARY (see AGENTS.md) — there is no `shrike` CLI binary and no
# runnable artifact. It is consumed as a Go module and its features surface
# through the hawk CLI (`hawk shrike ...`).
# This script verifies the library compiles and passes `go vet`.
#
# Usage: ./scripts/build.sh

PROJECT_NAME="shrike"
VERSION=$(git describe --tags --always --dirty 2>/dev/null || echo "dev")
BUILD_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "Building ${PROJECT_NAME} (library)..."
echo "Version: ${VERSION}"
echo "Build Time: ${BUILD_TIME}"

# Verify the whole module compiles.
echo "Verifying library compiles..."
CGO_ENABLED=0 go build ./...

# Run static analysis.
echo "Running go vet..."
go vet ./...

echo "Build complete! shrike library verified."
