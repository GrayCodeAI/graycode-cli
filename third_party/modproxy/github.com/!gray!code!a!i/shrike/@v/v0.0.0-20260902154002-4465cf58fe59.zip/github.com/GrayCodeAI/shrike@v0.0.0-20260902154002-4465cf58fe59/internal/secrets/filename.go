// Package secrets: filename-based sensitive path detection.
//
// This is a companion to content-based SecretDetector. While SecretDetector
// scans the *contents* of text for credential patterns (API keys, tokens),
// IsSensitiveFilename() inspects the file *name* and path to determine
// whether a file is likely to contain secrets and should therefore be
// protected from redaction, summarization, or agent editing.
//
// GrayCode native path-based sensitive file detection.
// scripts/compress.py (is_sensitive_path). Ported to native Go.
package secrets

import (
	"path/filepath"
	"regexp"
	"strings"
)

// Category is the broad class of sensitivity that triggered a match.
type Category int

const (
	// CatNone means the path is not sensitive.
	CatNone Category = iota
	// CatExactBasename: matches a known dangerous basename exactly
	// (e.g. ".env", "id_rsa", "credentials.json").
	CatExactBasename
	// CatSensitiveDirectory: contains a sensitive directory component
	// (e.g. ".ssh/", ".aws/", ".gnupg/", ".kube/").
	CatSensitiveDirectory
	// CatNameToken: filename contains a sensitivity keyword
	// (e.g. "secret", "credential", "password", "apikey").
	CatNameToken
)

// String returns a human-readable category name.
func (c Category) String() string {
	switch c {
	case CatExactBasename:
		return "exact-basename"
	case CatSensitiveDirectory:
		return "sensitive-directory"
	case CatNameToken:
		return "name-token"
	default:
		return "none"
	}
}

// FilenameMatch is the result of a successful IsSensitiveFilename call.
type FilenameMatch struct {
	Path     string   // the input path
	Category Category // which rule matched
	Reason   string   // human-readable reason
	Pattern  string   // which regex pattern matched
}

// basenameRegex matches filenames whose basename is itself known to be
// sensitive. Matched case-insensitively.
//
// Covers: dotenv files, credential files, SSH private keys, GitHub/GitLab
// tokens, and common PKI extensions. A trailing extension is allowed on
// most patterns so "credentials.json", "secrets.yaml" still match.
var basenameRegex = regexp.MustCompile(
	`(?i)^(?:` +
		`\.env(?:\..+)?` + // .env, .env.local, .env.production
		`|credentials?(?:\..+)?` + // credentials, credential, credentials.json
		`|secrets?(?:\..+)?` + // secrets, secret, secrets.yaml
		`|passwords?(?:\..+)?` + // passwords, password, passwords.txt
		`|passwd(?:\..+)?` + // passwd, passwd.bak
		`|id_(?:rsa|dsa|ec|ed25519)` + // id_rsa, id_dsa, id_ec, id_ed25519
		`|authorized_keys` + // SSH authorized_keys
		`|known_hosts` + // SSH known_hosts
		`|.+\.(?:pem|key|p12|pfx|crt|cer|p7b|p7c|der|jks|keystore|truststore)` + // PKI files
		`)$`,
)

// dirComponentRegex matches sensitive directory path components.
// A path containing any of these (as a complete path segment) is sensitive.
var dirComponentRegex = regexp.MustCompile(
	`(^|/)(` +
		`\.ssh` +
		`|\.aws` +
		`|\.gnupg` +
		`|\.kube` +
		`|\.docker` +
		`|\.config/gcloud` +
		`|\.config/gh` +
		`)(/|$)`,
)

// nameTokenRegex matches keywords within a filename that indicate
// sensitivity, even when the basename itself is not in the exact list.
//
// e.g. "test_credentials.json", "my_secret.txt", "staging_passwd" all match.
var nameTokenRegex = regexp.MustCompile(
	`(?i)(secret|credential|password|passwd|api[_-]?key|access[_-]?key|token|private[_-]?key)`,
)

// IsSensitiveFilename reports whether path is likely to contain secrets,
// based on the basename, directory components, and name tokens.
//
// It returns (false, zero) if the path is empty, contains only whitespace,
// or matches none of the three detection layers. The first match wins;
// the function is short-circuited in order of strictness (basename →
// directory → token), so a precise match is preferred over a fuzzy one.
//
// All matching is case-insensitive.
func IsSensitiveFilename(path string) (bool, FilenameMatch) {
	path = strings.TrimSpace(path)
	if path == "" {
		return false, FilenameMatch{Path: path, Category: CatNone}
	}

	// Clean the path so "." and ".." don't fool the regexes.
	cleaned := filepath.ToSlash(filepath.Clean(path))

	base := filepath.Base(cleaned)

	// Layer 1: exact basename match
	if basenameRegex.MatchString(base) {
		return true, FilenameMatch{
			Path:     path,
			Category: CatExactBasename,
			Reason:   "basename matches known sensitive filename: " + base,
			Pattern:  basenameRegex.String(),
		}
	}

	// Layer 2: sensitive directory component
	if dirComponentRegex.MatchString(cleaned) {
		return true, FilenameMatch{
			Path:     path,
			Category: CatSensitiveDirectory,
			Reason:   "path contains a sensitive directory (.ssh, .aws, .gnupg, .kube, .docker, .config/gcloud, .config/gh)",
			Pattern:  dirComponentRegex.String(),
		}
	}

	// Layer 3: name token (last resort — false-positive prone)
	if nameTokenRegex.MatchString(base) {
		return true, FilenameMatch{
			Path:     path,
			Category: CatNameToken,
			Reason:   "filename contains a sensitivity token (secret, credential, password, apikey, token, etc.)",
			Pattern:  nameTokenRegex.String(),
		}
	}

	return false, FilenameMatch{Path: path, Category: CatNone}
}

// IsSensitiveBasename is a convenience wrapper that operates on a
// bare filename (no directory). Useful when the caller already has the
// basename and no path context.
func IsSensitiveBasename(name string) bool {
	ok, _ := IsSensitiveFilename(name)
	return ok
}
