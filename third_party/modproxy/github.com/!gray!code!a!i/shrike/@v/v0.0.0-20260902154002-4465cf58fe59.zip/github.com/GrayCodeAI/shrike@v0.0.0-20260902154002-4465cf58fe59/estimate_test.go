package shrike_test

import (
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestEstimateTokens_AllVariants(t *testing.T) {
	in := "The quick brown fox jumps over the lazy dog"
	tests := []struct {
		name string
		fn   func() int
	}{
		{"EstimateTokens", func() int { return shrike.EstimateTokens(in) }},
		{"EstimateTokensFast", func() int { return shrike.EstimateTokensFast(in) }},
		{"EstimateTokensPrecise", func() int { return shrike.EstimateTokensPrecise(in) }},
		{"EstimateTokensWithEncoding_cl100k", func() int { return shrike.EstimateTokensWithEncoding(in, "cl100k_base") }},
		{"EstimateTokensWithEncoding_o200k", func() int { return shrike.EstimateTokensWithEncoding(in, "o200k_base") }},
		{"EstimateTokensForModel_gpt4o", func() int { return shrike.EstimateTokensForModel(in, "gpt-4o") }},
		{"EstimateTokensForModel_claude", func() int { return shrike.EstimateTokensForModel(in, "claude-3") }},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			n := tc.fn()
			if n <= 0 {
				t.Errorf("expected positive token count, got %d", n)
			}
		})
	}
}

func TestEstimateTokens_Empty(t *testing.T) {
	if n := shrike.EstimateTokens(""); n != 0 {
		t.Errorf("expected 0 for empty string, got %d", n)
	}
	if n := shrike.EstimateTokensFast(""); n != 0 {
		t.Errorf("expected 0 for empty string, got %d", n)
	}
	if n := shrike.EstimateTokensPrecise(""); n != 0 {
		t.Errorf("expected 0 for empty string, got %d", n)
	}
}
