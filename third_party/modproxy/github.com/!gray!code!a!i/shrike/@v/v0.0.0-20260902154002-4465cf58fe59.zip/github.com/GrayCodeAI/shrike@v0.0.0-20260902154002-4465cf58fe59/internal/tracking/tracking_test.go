package tracking_test

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/GrayCodeAI/shrike/internal/tracking"
)

func newTestTracker(t *testing.T) (*tracking.Tracker, string) {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "test_tracker.db")
	tr, err := tracking.NewAt(context.Background(), path)
	if err != nil {
		t.Fatalf("NewAt: %v", err)
	}
	t.Cleanup(func() { _ = tr.Close() })
	return tr, path
}

func TestNewAt_CreatesDB(t *testing.T) {
	_, path := newTestTracker(t)
	if _, err := os.Stat(path); err != nil {
		t.Errorf("expected db file at %s: %v", path, err)
	}
}

func TestRecord_AndAggregate(t *testing.T) {
	tr, _ := newTestTracker(t)
	ctx := context.Background()
	events := []tracking.Event{
		{Command: "npm test", OriginalBytes: 1000, CompressedBytes: 400, OriginalTokens: 250, CompressedTokens: 100, Mode: "aggressive", Tier: "code"},
		{Command: "npm test", OriginalBytes: 2000, CompressedBytes: 800, OriginalTokens: 500, CompressedTokens: 200, Mode: "aggressive", Tier: "code"},
		{Command: "go build", OriginalBytes: 500, CompressedBytes: 250, OriginalTokens: 125, CompressedTokens: 60, Mode: "minimal", Tier: "core"},
	}
	for _, ev := range events {
		if err := tr.Record(ctx, ev); err != nil {
			t.Fatalf("Record: %v", err)
		}
	}
	agg, err := tr.Aggregate(ctx, 30)
	if err != nil {
		t.Fatalf("Aggregate: %v", err)
	}
	if agg.EventCount != 3 {
		t.Errorf("expected 3 events, got %d", agg.EventCount)
	}
	// Total saved: 600 + 1200 + 250 = 2050
	if agg.TotalBytesSaved != 2050 {
		t.Errorf("expected 2050 bytes saved, got %d", agg.TotalBytesSaved)
	}
	// Average savings: 60% + 60% + 50% = 170/3 ≈ 56.67
	if agg.AvgSavingsPct < 56.0 || agg.AvgSavingsPct > 57.0 {
		t.Errorf("expected avg savings ~56.67%%, got %f", agg.AvgSavingsPct)
	}
}

func TestRecent_OrderedByID(t *testing.T) {
	tr, _ := newTestTracker(t)
	ctx := context.Background()
	for i := 0; i < 5; i++ {
		_ = tr.Record(ctx, tracking.Event{
			Command:         "test",
			OriginalBytes:   100,
			CompressedBytes: 50,
		})
		time.Sleep(2 * time.Millisecond) // ensure distinct ts
	}
	recent, err := tr.Recent(ctx, 3)
	if err != nil {
		t.Fatalf("Recent: %v", err)
	}
	if len(recent) != 3 {
		t.Fatalf("expected 3 recent events, got %d", len(recent))
	}
	if recent[0].ID <= recent[1].ID {
		t.Errorf("expected descending ID order, got %d, %d", recent[0].ID, recent[1].ID)
	}
}

func TestPrune_OldEvents(t *testing.T) {
	tr, _ := newTestTracker(t)
	ctx := context.Background()
	// Insert an event with a timestamp 100 days ago
	old := time.Now().Add(-100 * 24 * time.Hour)
	if err := tr.Record(ctx, tracking.Event{
		Timestamp:       old,
		Command:         "old",
		OriginalBytes:   100,
		CompressedBytes: 50,
	}); err != nil {
		t.Fatalf("Record old: %v", err)
	}
	// Insert a recent event
	if err := tr.Record(ctx, tracking.Event{
		Command:         "new",
		OriginalBytes:   100,
		CompressedBytes: 50,
	}); err != nil {
		t.Fatalf("Record new: %v", err)
	}
	deleted, err := tr.Prune(ctx)
	if err != nil {
		t.Fatalf("Prune: %v", err)
	}
	if deleted != 1 {
		t.Errorf("expected 1 pruned, got %d", deleted)
	}
	// After prune, only the new event remains
	agg, _ := tr.Aggregate(ctx, 30)
	if agg.EventCount != 1 {
		t.Errorf("expected 1 event after prune, got %d", agg.EventCount)
	}
}

func TestWithRetention_OverridesDefault(t *testing.T) {
	tr, _ := newTestTracker(t)
	tr.WithRetention(7) // 1 week
	if tr == nil {
		t.Fatal("nil tracker")
	}
	// Just verify it doesn't crash on Aggregate
	_, err := tr.Aggregate(context.Background(), 0)
	if err != nil {
		t.Errorf("Aggregate after WithRetention: %v", err)
	}
}

func TestAggregate_EmptyDB(t *testing.T) {
	tr, _ := newTestTracker(t)
	agg, err := tr.Aggregate(context.Background(), 30)
	if err != nil {
		t.Fatalf("Aggregate on empty db: %v", err)
	}
	if agg.EventCount != 0 {
		t.Errorf("expected 0 events, got %d", agg.EventCount)
	}
	if agg.TotalBytesSaved != 0 {
		t.Errorf("expected 0 bytes saved, got %d", agg.TotalBytesSaved)
	}
	if agg.AvgSavingsPct != 0 {
		t.Errorf("expected 0 avg savings, got %f", agg.AvgSavingsPct)
	}
}

func TestRecord_ConcurrentSafety(t *testing.T) {
	tr, _ := newTestTracker(t)
	ctx := context.Background()
	done := make(chan error, 10)
	for i := 0; i < 10; i++ {
		go func(i int) {
			done <- tr.Record(ctx, tracking.Event{
				Command:         "concurrent",
				OriginalBytes:   100,
				CompressedBytes: 50,
			})
		}(i)
	}
	for i := 0; i < 10; i++ {
		if err := <-done; err != nil {
			t.Errorf("concurrent Record: %v", err)
		}
	}
	agg, _ := tr.Aggregate(ctx, 30)
	if agg.EventCount != 10 {
		t.Errorf("expected 10 events, got %d", agg.EventCount)
	}
}

func TestClose_Idempotent(t *testing.T) {
	tr, _ := newTestTracker(t)
	if err := tr.Close(); err != nil {
		t.Errorf("first Close: %v", err)
	}
	if err := tr.Close(); err != nil {
		t.Errorf("second Close: %v", err)
	}
}

func TestEvent_SavingsPctComputedInRecent(t *testing.T) {
	tr, _ := newTestTracker(t)
	ctx := context.Background()
	_ = tr.Record(ctx, tracking.Event{
		Command:         "pct",
		OriginalBytes:   200,
		CompressedBytes: 50,
	})
	recent, err := tr.Recent(ctx, 1)
	if err != nil {
		t.Fatalf("Recent: %v", err)
	}
	if len(recent) != 1 {
		t.Fatalf("expected 1 event, got %d", len(recent))
	}
	// 200 -> 50 = 75% saved
	if recent[0].SavingsPct != 75.0 {
		t.Errorf("expected SavingsPct=75.0, got %f", recent[0].SavingsPct)
	}
}

func TestDefaultPath(t *testing.T) {
	p, err := tracking.DefaultPath()
	if err != nil {
		t.Fatalf("DefaultPath: %v", err)
	}
	if !strings.HasSuffix(p, ".shrike/tracker.db") {
		t.Errorf("expected path to end with .shrike/tracker.db, got %q", p)
	}
	// Should be an absolute path.
	if !filepath.IsAbs(p) {
		t.Errorf("expected absolute path, got %q", p)
	}
}

func TestDefaultPath_FallbackToHOME(t *testing.T) {
	// HOME is set in test env by default, so DefaultPath uses it.
	// Verify the path actually lives under HOME.
	p, err := tracking.DefaultPath()
	if err != nil {
		t.Fatal(err)
	}
	home, _ := os.UserHomeDir()
	if !strings.HasPrefix(p, home) {
		t.Errorf("expected path under HOME %q, got %q", home, p)
	}
}

func TestDefaultPath_FallbackToUSERPROFILE(t *testing.T) {
	// When HOME is empty and USERPROFILE is set (Windows-style),
	// DefaultPath should still succeed via the fallback chain.
	origHome := os.Getenv("HOME")
	origUserProfile := os.Getenv("USERPROFILE")
	t.Cleanup(func() {
		_ = os.Setenv("HOME", origHome)
		_ = os.Setenv("USERPROFILE", origUserProfile)
	})
	_ = os.Unsetenv("HOME")
	profileDir := t.TempDir()
	_ = os.Setenv("USERPROFILE", profileDir)

	p, err := tracking.DefaultPath()
	if err != nil {
		t.Fatalf("DefaultPath: %v", err)
	}
	if !strings.HasPrefix(p, profileDir) {
		t.Errorf("expected path under USERPROFILE %q, got %q", profileDir, p)
	}
}

func TestNew_DefaultPath(t *testing.T) {
	// Point HOME at a temp dir so New uses an isolated path.
	origHome := os.Getenv("HOME")
	t.Cleanup(func() { _ = os.Setenv("HOME", origHome) })
	tmp := t.TempDir()
	_ = os.Setenv("HOME", tmp)

	ctx := context.Background()
	tr, err := tracking.New(ctx)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	t.Cleanup(func() { _ = tr.Close() })

	// Verify the DB file was created.
	expectedDir := filepath.Join(tmp, ".shrike")
	if _, err := os.Stat(expectedDir); err != nil {
		t.Errorf("expected dir %s to exist: %v", expectedDir, err)
	}

	// And basic operations work.
	if err := tr.Record(ctx, tracking.Event{
		Command: "new", OriginalBytes: 100, CompressedBytes: 50,
	}); err != nil {
		t.Fatalf("Record: %v", err)
	}
}

func TestNewAt_CreateDirError(t *testing.T) {
	// If mkdirAll fails, NewAt returns an error.
	// Use a path under a file (not a dir) so MkdirAll fails.
	tmp := t.TempDir()
	blocker := filepath.Join(tmp, "blocker")
	if err := os.WriteFile(blocker, []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	bad := filepath.Join(blocker, "tracker.db")
	_, err := tracking.NewAt(context.Background(), bad)
	if err == nil {
		t.Error("expected error for nested dir under a file")
	}
	if !strings.Contains(err.Error(), "create dir") {
		t.Errorf("expected 'create dir' in error, got %v", err)
	}
}

func TestNewAt_EmptyPath(t *testing.T) {
	_, err := tracking.NewAt(context.Background(), "")
	if err == nil {
		t.Error("expected error for empty path")
	}
}
