package filter

import (
	"strings"
	"testing"
)

func TestTokenize(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected int
	}{
		{"empty string", "", 0},
		{"single word", "hello", 1},
		{"two words", "hello world", 2},
		{"with punctuation", "hello, world!", 2},
		{"with whitespace", "  hello   world  ", 2},
		{"with newlines", "hello\nworld", 2},
		{"with tabs", "hello\tworld", 2},
		{"with mixed separators", "hello, world; foo: bar", 4},
		{"only punctuation", ".,;:!?\"", 0},
		{"only whitespace", "   \t\n  ", 0},
		{"code-like", "func main() { fmt.Println(\"hello\") }", 5},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := tokenize(tt.input)
			if len(result) != tt.expected {
				t.Errorf("tokenize(%q) returned %d tokens, expected %d. Got: %v", tt.input, len(result), tt.expected, result)
			}
		})
	}
}

func TestTokenizeReturnsNoEmptyStrings(t *testing.T) {
	input := "hello,,,world!!!foo"
	result := tokenize(input)
	for _, token := range result {
		if token == "" {
			t.Error("tokenize should not return empty strings")
		}
	}
}

func TestTokenizeHandlesUnicode(t *testing.T) {
	input := "hello 世界 world"
	result := tokenize(input)
	if len(result) != 3 {
		t.Errorf("expected 3 tokens for unicode input, got %d: %v", len(result), result)
	}
}

func TestTokenizeLongInput(t *testing.T) {
	input := strings.Repeat("word ", 1000)
	result := tokenize(input)
	if len(result) != 1000 {
		t.Errorf("expected 1000 tokens, got %d", len(result))
	}
}
