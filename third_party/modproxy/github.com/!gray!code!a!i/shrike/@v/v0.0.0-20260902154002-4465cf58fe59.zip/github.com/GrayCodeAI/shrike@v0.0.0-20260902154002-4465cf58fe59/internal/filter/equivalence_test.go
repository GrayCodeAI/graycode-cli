package filter

import (
	"testing"
)

func TestNewSemanticEquivalence(t *testing.T) {
	s := NewSemanticEquivalence()
	if s == nil {
		t.Fatal("NewSemanticEquivalence returned nil")
	}
}

func TestSemanticEquivalenceCheck(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Error: something failed", "Error: something failed")

	if !report.ErrorPreserved {
		t.Error("errors should be preserved")
	}
	if !report.IsGood() {
		t.Error("report should be good for identical content")
	}
}

func TestSemanticEquivalenceCheckErrorLost(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Error: something failed", "Everything is fine")

	if report.ErrorPreserved {
		t.Error("error should not be preserved if it's missing from compressed output")
	}
}

func TestSemanticEquivalenceCheckNumbers(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Error at line 42", "Error at line 42")

	if !report.NumbersPreserved {
		t.Error("numbers should be preserved")
	}
}

func TestSemanticEquivalenceCheckNumbersLost(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Error at line 42", "Error at line")

	if report.NumbersPreserved {
		t.Error("numbers should not be preserved if missing")
	}
}

func TestSemanticEquivalenceCheckURLs(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("See https://example.com for details", "See https://example.com for details")

	if !report.URLsPreserved {
		t.Error("URLs should be preserved")
	}
}

func TestSemanticEquivalenceCheckURLsLost(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("See https://example.com for details", "See for details")

	if report.URLsPreserved {
		t.Error("URLs should not be preserved if missing")
	}
}

func TestSemanticEquivalenceCheckPaths(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("File /home/user/test.go not found", "File /home/user/test.go not found")

	if !report.FilePathsPreserved {
		t.Error("file paths should be preserved")
	}
}

func TestSemanticEquivalenceCheckPathsLost(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("File /home/user/test.go not found", "File not found")

	if report.FilePathsPreserved {
		t.Error("file paths should not be preserved if missing")
	}
}

func TestSemanticEquivalenceCheckExitCodes(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Process exited with exit code 1", "Process exited with exit code 1")

	if !report.ExitCodesPreserved {
		t.Error("exit codes should be preserved")
	}
}

func TestSemanticEquivalenceCheckExitCodesLost(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("Process exited with exit code 1", "Process exited")

	if report.ExitCodesPreserved {
		t.Error("exit codes should not be preserved if missing")
	}
}

func TestSemanticEquivalenceCheckNoErrorsInOriginal(t *testing.T) {
	s := NewSemanticEquivalence()
	report := s.Check("All good", "All good")

	if !report.ErrorPreserved {
		t.Error("should be preserved when no errors in original")
	}
}

func TestEquivalenceReportIsGood(t *testing.T) {
	tests := []struct {
		name     string
		report   EquivalenceReport
		expected bool
	}{
		{
			name:     "good score and error preserved",
			report:   EquivalenceReport{Score: 0.8, ErrorPreserved: true},
			expected: true,
		},
		{
			name:     "good score but error not preserved",
			report:   EquivalenceReport{Score: 0.8, ErrorPreserved: false},
			expected: false,
		},
		{
			name:     "low score and error preserved",
			report:   EquivalenceReport{Score: 0.5, ErrorPreserved: true},
			expected: false,
		},
		{
			name:     "perfect score and error preserved",
			report:   EquivalenceReport{Score: 1.0, ErrorPreserved: true},
			expected: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := tt.report.IsGood()
			if result != tt.expected {
				t.Errorf("IsGood() = %v, expected %v", result, tt.expected)
			}
		})
	}
}

func TestCheckErrorsPreserved(t *testing.T) {
	tests := []struct {
		original   string
		compressed string
		expected   bool
	}{
		{"Error: failed", "Error: failed", true},
		{"error occurred", "error occurred", true},
		{"FAIL: something", "FAIL: something", true},
		{"Error: failed", "success", false},
		{"no errors here", "no errors here", true},
		{"everything working fine", "all good", true},
	}

	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			result := checkErrorsPreserved(tt.original, tt.compressed)
			if result != tt.expected {
				t.Errorf("checkErrorsPreserved(%q, %q) = %v, expected %v", tt.original, tt.compressed, result, tt.expected)
			}
		})
	}
}

func TestCheckURLsPreserved(t *testing.T) {
	tests := []struct {
		original   string
		compressed string
		expected   bool
	}{
		{"See https://example.com", "See https://example.com", true},
		{"See http://test.org", "See http://test.org", true},
		{"See https://example.com", "See", false},
		{"no urls here", "no urls here", true},
	}

	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			result := checkURLsPreserved(tt.original, tt.compressed)
			if result != tt.expected {
				t.Errorf("checkURLsPreserved(%q, %q) = %v, expected %v", tt.original, tt.compressed, result, tt.expected)
			}
		})
	}
}

func TestExtractCriticalNumbers(t *testing.T) {
	tests := []struct {
		input    string
		expected int
	}{
		{"line 42", 1},
		{"lines 1, 2, 3", 3},
		{"exit code 1", 1},
		{"no numbers", 0},
		{"12345", 1},
		{"12345678901234567890", 0}, // too long (>5 digits)
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			result := extractCriticalNumbers(tt.input)
			if len(result) != tt.expected {
				t.Errorf("extractCriticalNumbers(%q) returned %d numbers, expected %d", tt.input, len(result), tt.expected)
			}
		})
	}
}

func TestExtractURLs(t *testing.T) {
	tests := []struct {
		input    string
		expected int
	}{
		{"https://example.com", 1},
		{"http://test.org path", 1},
		{"https://a.com and https://b.com", 2},
		{"no urls here", 0},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			result := extractURLs(tt.input)
			if len(result) != tt.expected {
				t.Errorf("extractURLs(%q) returned %d URLs, expected %d", tt.input, len(result), tt.expected)
			}
		})
	}
}

func TestExtractPaths(t *testing.T) {
	tests := []struct {
		input    string
		expected int
	}{
		{"/home/user/file.txt", 1},
		{"./relative/path", 1},
		{"../parent/path", 1},
		{"~/home/path", 1},
		{"no paths here", 0},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			result := extractPaths(tt.input)
			if len(result) != tt.expected {
				t.Errorf("extractPaths(%q) returned %d paths, expected %d", tt.input, len(result), tt.expected)
			}
		})
	}
}

func TestComputeEquivalenceScore(t *testing.T) {
	// Identical content should score 1.0
	score := computeEquivalenceScore("hello world", "hello world")
	if score != 1.0 {
		t.Errorf("expected score 1.0 for identical content, got %f", score)
	}
}
