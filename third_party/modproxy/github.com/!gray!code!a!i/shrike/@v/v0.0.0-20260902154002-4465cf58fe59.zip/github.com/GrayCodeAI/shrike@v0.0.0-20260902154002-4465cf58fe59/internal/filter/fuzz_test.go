package filter

import (
	"strings"
	"testing"
)

func FuzzPipelineProcess(f *testing.F) {
	seeds := []string{
		"ERROR: something failed\n  at line 42\n  in file.go",
		"warning: deprecated function used",
		"ok  	github.com/example/pkg	0.123s",
		"PASS",
		"FAIL",
		"",
		strings.Repeat("x", 10000),
		strings.Repeat("a\n", 1000),
	}
	for _, s := range seeds {
		f.Add(s)
	}

	f.Fuzz(func(t *testing.T, input string) {
		p := NewPipelineCoordinator(&PipelineConfig{})
		_, _ = p.Process(input)
	})
}

func FuzzNgram(f *testing.F) {
	f.Add("hello world this is a test of ngram abbreviation")
	f.Add("")
	f.Add("a")
	f.Add(strings.Repeat("word ", 500))

	f.Fuzz(func(t *testing.T, input string) {
		n := NewNgramAbbreviator()
		result, _ := n.Apply(input, ModeNone)
		// Should not produce output longer than input
		if len(result) > len(input)+100 {
			t.Errorf("ngram output (%d) much longer than input (%d)", len(result), len(input))
		}
	})
}

func FuzzEntropyFilter(f *testing.F) {
	f.Add("normal text with some entropy")
	f.Add("")
	f.Add(strings.Repeat("a", 1000))
	f.Add("H4sIAAAAAAAAA3NxcA==")

	f.Fuzz(func(t *testing.T, input string) {
		e := NewEntropyFilter()
		result, _ := e.Apply(input, ModeNone)
		if len(result) > len(input)+100 {
			t.Errorf("entropy output (%d) much longer than input (%d)", len(result), len(input))
		}
	})
}
