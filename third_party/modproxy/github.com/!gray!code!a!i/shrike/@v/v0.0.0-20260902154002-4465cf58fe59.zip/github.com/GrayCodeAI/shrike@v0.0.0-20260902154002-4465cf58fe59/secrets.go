package shrike

import (
	"context"
	"net/http"
	"sync"

	"github.com/GrayCodeAI/shrike/internal/secrets"
)

// SecretMatch represents a detected secret within text.
type SecretMatch = secrets.SecretMatch

// SecretDetector detects and redacts secrets from text using compiled regex patterns.
type SecretDetector struct {
	inner *secrets.SecretDetector
}

var (
	defaultDetector     *SecretDetector
	defaultDetectorOnce sync.Once
)

// DefaultSecretDetector returns the singleton SecretDetector instance with all built-in patterns.
// It is safe for concurrent use.
func DefaultSecretDetector() *SecretDetector {
	defaultDetectorOnce.Do(func() {
		defaultDetector = &SecretDetector{inner: secrets.DefaultDetector()}
	})
	return defaultDetector
}

// NewSecretDetector creates a SecretDetector with all built-in patterns compiled and ready.
func NewSecretDetector() *SecretDetector {
	return &SecretDetector{inner: secrets.NewDetector()}
}

// DetectSecrets finds all secrets in the given text.
func (sd *SecretDetector) DetectSecrets(text string) []SecretMatch {
	return sd.inner.DetectSecrets(text)
}

// DetectSecretsVerified is like DetectSecrets, but additionally makes a live
// network call per detected secret (where a verifier exists for its type)
// to confirm whether the credential is actually active — following
// TruffleHog's live-verification model. This is the only method on
// SecretDetector that makes network calls; DetectSecrets never does, and
// callers must opt into this explicitly. client may be nil to use a default
// 5-second-timeout client.
func (sd *SecretDetector) DetectSecretsVerified(ctx context.Context, client *http.Client, text string) []SecretMatch {
	return sd.inner.DetectSecretsVerified(ctx, client, text)
}

// RedactSecrets replaces detected secrets with [REDACTED] markers.
func (sd *SecretDetector) RedactSecrets(text string) string {
	return sd.inner.RedactSecrets(text)
}

// DetectAndRedactWithEntropy detects secrets using both pattern matching and entropy analysis.
func (sd *SecretDetector) DetectAndRedactWithEntropy(text string, entropyThreshold float64) string {
	return sd.inner.DetectAndRedactWithEntropy(text, entropyThreshold)
}

// MaskSecret masks a secret value for safe display.
func MaskSecret(value, secretType string) string {
	return secrets.MaskSecret(value, secretType)
}

// IsSensitiveFilename reports whether path is likely to contain secrets
// (e.g. ".env", "id_rsa", "/home/user/.ssh/...", "test_credentials.json").
// Companion to SecretDetector which inspects file *content*; this function
// inspects file *names and paths*.
//
// Returns (sensitive, match). The match contains the category that fired
// (CatExactBasename, CatSensitiveDirectory, or CatNameToken) and a
// human-readable reason.
//
// All matching is case-insensitive. The function is safe to call from
// multiple goroutines and never returns false positives for ordinary
// source files (main.go, README.md, etc.).
func IsSensitiveFilename(path string) (bool, secrets.FilenameMatch) {
	return secrets.IsSensitiveFilename(path)
}

// IsSensitiveBasename is a convenience wrapper for the common case where
// the caller already has just the basename (no directory). Equivalent
// to IsSensitiveFilename(name) and discarding the match details.
func IsSensitiveBasename(name string) bool {
	return secrets.IsSensitiveBasename(name)
}
