package filter

import (
	"testing"
)

func TestNewBytePool(t *testing.T) {
	pool := NewBytePool()
	if pool == nil {
		t.Fatal("NewBytePool returned nil")
	}
	if pool.smallPool.New == nil {
		t.Error("smallPool.New should not be nil")
	}
	if pool.mediumPool.New == nil {
		t.Error("mediumPool.New should not be nil")
	}
	if pool.largePool.New == nil {
		t.Error("largePool.New should not be nil")
	}
	if pool.hugePool.New == nil {
		t.Error("hugePool.New should not be nil")
	}
}

func TestBytePoolGetSmall(t *testing.T) {
	pool := NewBytePool()
	buf := pool.Get(512)
	if buf == nil {
		t.Fatal("Get returned nil for small buffer")
	}
	if cap(*buf) != 1024 {
		t.Errorf("expected capacity 1024, got %d", cap(*buf))
	}
}

func TestBytePoolGetMedium(t *testing.T) {
	pool := NewBytePool()
	buf := pool.Get(5000)
	if buf == nil {
		t.Fatal("Get returned nil for medium buffer")
	}
	if cap(*buf) != 10240 {
		t.Errorf("expected capacity 10240, got %d", cap(*buf))
	}
}

func TestBytePoolGetLarge(t *testing.T) {
	pool := NewBytePool()
	buf := pool.Get(50000)
	if buf == nil {
		t.Fatal("Get returned nil for large buffer")
	}
	if cap(*buf) != 102400 {
		t.Errorf("expected capacity 102400, got %d", cap(*buf))
	}
}

func TestBytePoolGetHuge(t *testing.T) {
	pool := NewBytePool()
	buf := pool.Get(200000)
	if buf == nil {
		t.Fatal("Get returned nil for huge buffer")
	}
	if cap(*buf) != 1048576 {
		t.Errorf("expected capacity 1048576, got %d", cap(*buf))
	}
}

func TestBytePoolPutNil(t *testing.T) {
	pool := NewBytePool()
	pool.Put(nil) // should not panic
}

func TestBytePoolPutAndReuse(t *testing.T) {
	pool := NewBytePool()
	buf := pool.Get(512)
	*buf = append(*buf, []byte("test data")...)
	pool.Put(buf)

	// Get again — should get a reset buffer
	buf2 := pool.Get(512)
	if buf2 == nil {
		t.Fatal("Get returned nil after Put")
	}
	if len(*buf2) != 0 {
		t.Errorf("expected reset buffer (length 0), got length %d", len(*buf2))
	}
}

func TestBytePoolPutWrongSize(t *testing.T) {
	pool := NewBytePool()
	buf := make([]byte, 0, 5000)
	pool.Put(&buf) // should go to medium pool
}

func TestGlobalBytePoolFunctions(t *testing.T) {
	buf := GetBytes(512)
	if buf == nil {
		t.Fatal("GetBytes returned nil")
	}
	*buf = append(*buf, 'x')
	PutBytes(buf)

	buf2 := GetBytes(512)
	if buf2 == nil {
		t.Fatal("GetBytes returned nil after PutBytes")
	}
	if len(*buf2) != 0 {
		t.Errorf("expected reset buffer, got length %d", len(*buf2))
	}
}

func TestAcquireStringBuilder(t *testing.T) {
	pool := NewBytePool()
	buf := pool.AcquireStringBuilder(512)
	if buf == nil {
		t.Fatal("AcquireStringBuilder returned nil")
	}
	if buf.Len() != 0 {
		t.Errorf("expected empty buffer, got length %d", buf.Len())
	}
}

func TestReleaseStringBuilder(t *testing.T) {
	pool := NewBytePool()
	buf := pool.AcquireStringBuilder(512)
	buf.WriteString("test")
	pool.ReleaseStringBuilder(buf)
}

func TestReleaseStringBuilderNil(t *testing.T) {
	pool := NewBytePool()
	pool.ReleaseStringBuilder(nil) // should not panic
}

func TestFastStringBuilder(t *testing.T) {
	builder := NewFastStringBuilder(1024)
	if builder == nil {
		t.Fatal("NewFastStringBuilder returned nil")
	}

	builder.WriteString("Hello, ")
	builder.WriteString("world!")
	result := builder.String()
	if result != "Hello, world!" {
		t.Errorf("expected %q, got %q", "Hello, world!", result)
	}

	if builder.Len() != 13 {
		t.Errorf("expected length 13, got %d", builder.Len())
	}

	if builder.Cap() < 1024 {
		t.Errorf("expected capacity >= 1024, got %d", builder.Cap())
	}
}

func TestFastStringBuilderWriteByte(t *testing.T) {
	builder := NewFastStringBuilder(10)
	err := builder.WriteByte('A')
	if err != nil {
		t.Errorf("WriteByte returned error: %v", err)
	}
	if builder.String() != "A" {
		t.Errorf("expected %q, got %q", "A", builder.String())
	}
}

func TestFastStringBuilderWrite(t *testing.T) {
	builder := NewFastStringBuilder(10)
	builder.Write([]byte("test"))
	if builder.String() != "test" {
		t.Errorf("expected %q, got %q", "test", builder.String())
	}
}

func TestFastStringBuilderReset(t *testing.T) {
	builder := NewFastStringBuilder(1024)
	builder.WriteString("test data")
	builder.Reset()
	if builder.Len() != 0 {
		t.Errorf("expected length 0 after reset, got %d", builder.Len())
	}
	if builder.String() != "" {
		t.Errorf("expected empty string after reset, got %q", builder.String())
	}
}

func TestFastStringBuilderGrow(t *testing.T) {
	builder := NewFastStringBuilder(10)
	initialCap := builder.Cap()
	builder.Grow(100)
	if builder.Cap() < initialCap+100 {
		t.Errorf("expected capacity >= %d, got %d", initialCap+100, builder.Cap())
	}
}

func TestFastStringBuilderGrowNoOp(t *testing.T) {
	builder := NewFastStringBuilder(1000)
	initialCap := builder.Cap()
	builder.Grow(10) // should not grow since there's enough capacity
	if builder.Cap() != initialCap {
		t.Errorf("expected capacity to remain %d, got %d", initialCap, builder.Cap())
	}
}

func TestFastStringBuilderMultipleOperations(t *testing.T) {
	builder := NewFastStringBuilder(100)
	builder.WriteString("Hello")
	builder.WriteByte(' ')
	builder.WriteString("World")
	builder.Write([]byte("!"))

	result := builder.String()
	if result != "Hello World!" {
		t.Errorf("expected %q, got %q", "Hello World!", result)
	}

	builder.Reset()
	builder.WriteString("New content")
	if builder.String() != "New content" {
		t.Errorf("expected %q after reset, got %q", "New content", builder.String())
	}
}

func TestGlobalBufferPools(t *testing.T) {
	if globalBufferPools == nil {
		t.Fatal("globalBufferPools should not be nil")
	}
	if globalBufferPools.small.New == nil {
		t.Error("small pool New function should not be nil")
	}
	if globalBufferPools.medium.New == nil {
		t.Error("medium pool New function should not be nil")
	}
	if globalBufferPools.large.New == nil {
		t.Error("large pool New function should not be nil")
	}
}
