# Shrike Quality Core Baseline

## Metadata

- Suite: `shrike-quality-core`
- Date: `2026-06-27`
- Model: none
- Provider: none
- Commit: current workspace snapshot
- Command: `/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./benchmarks/run.sh'`

## Headline Metrics

- CountTokens 100B: `97.64 ns/op`, `1024.19 MB/s`
- CountTokens 100KB: `133845 ns/op`, `765.06 MB/s`
- Compress 100B Minimal: `43500 ns/op`, `63080 B/op`, `222 allocs/op`
- Compress 100B Aggressive: `31372 ns/op`, `62684 B/op`, `221 allocs/op`
- Compress 100KB Minimal: `1485713 ns/op`, `1190139 B/op`, `244 allocs/op`
- Compress 100KB Aggressive: `1492485 ns/op`, `1184748 B/op`, `236 allocs/op`
- BPEEncode 100KB: `131183 ns/op`, `780.59 MB/s`
- Offline quality harness summary:
  - `surface`: ratio `0.921`, char retention `0.950`, fidelity `0.973`
  - `trim`: ratio `0.922`, char retention `0.950`, fidelity `0.975`
  - `extract`: ratio `0.456`, char retention `0.382`, fidelity `0.368`

## Notes

- This is the first committed repo-owned baseline artifact for `shrike-quality-core`.
- The root-package benchmark section and offline quality harness both completed successfully in the same command.
- The quality harness remains fully offline and uses the checked-in sample corpus.

## Comparison Summary

- Previous baseline: none committed
- Change since baseline: initial published baseline
- Interpretation: Shrike’s core token-count and encode paths stay sub-millisecond at large input sizes, while the offline quality harness shows that `extract` delivers the strongest compression with a clear fidelity tradeoff versus `surface` and `trim`.
