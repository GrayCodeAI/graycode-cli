# Shrike Examples

Shrike is a Go **library** (`github.com/GrayCodeAI/shrike`) that compresses prompts and
filters text to reduce LLM token costs by 60-90%. There is no standalone `shrike`
binary — you call it from Go code, or use the CLI verbs exposed through
[Hawk](https://github.com/GrayCodeAI/hawk), which embeds this library.

```bash
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

## Basic Usage

### Compress a prompt

```go
in := "Hey, could you please help me figure out why this React component keeps " +
    "re-rendering every time the props change?"

out, stats := shrike.Compress(in, shrike.Aggressive)
// out: "React component re-renders on prop change. Why?"
// stats: compression ratio, token savings, etc.
```

`PromptCompress` lets you pick an intensity level directly:

```go
out, stats := shrike.PromptCompress(in, shrike.IntensityFull)
// intensities: shrike.IntensityLite, shrike.IntensityFull, shrike.IntensityUltra
```

### Estimate tokens and cost

```go
cost := shrike.EstimateCost(out, "claude-3-5-sonnet")
```

## Advanced Examples

### Custom compression rules

Filter rules are TOML files loaded with `shrike.LoadFilterRules` and applied via
`shrike.WithCustomFilters`:

```go
rules, err := shrike.LoadFilterRules("rules.toml")
if err != nil {
    log.Fatal(err)
}

out, _ := shrike.Compress(in, shrike.WithCustomFilters(rules))
```

### Code-aware and perplexity-guided compression

```go
// Preserve code structure for a given language.
out, _ := shrike.Compress(src, shrike.WithCodeAware("go"))

// Drop the lowest-information tokens using your own scorer.
out, _ = shrike.Compress(in, shrike.WithPerplexityGuided(scorer, 0.5))
```

### Profiles

```go
profile, err := shrike.LoadProfile("profile.toml")
out, _ := shrike.Compress(in, profile.Options()...)
```

### Secret detection and sensitive files

```go
det := shrike.NewSecretDetector()
findings := det.Scan(text)

if shrike.IsSensitiveFilename(".env") {
    // skip or redact
}
```

### Truncation and JSON extraction

```go
short := shrike.SmartTruncate(longText, 500)
payload, err := shrike.ExtractJSON(mixedOutput)
```

### Usage tracking

```go
tracker := shrike.NewTracker(ctx)
// record and report token/cost usage over a run
```

## Using the CLI verbs (via Hawk)

The `shrike ...` subcommands you may remember (compress, estimate, etc.) are
provided by Hawk, which embeds this library:

```bash
hawk shrike compress < prompt.txt
hawk shrike estimate < prompt.txt
```

See [Hawk](https://github.com/GrayCodeAI/hawk) for the full command surface.

## Benchmarks

```bash
./benchmarks/run.sh
./evals/pipeline-bench.sh
```

Both wrap `go test -bench`.

See the [main README](../README.md) for full documentation.
