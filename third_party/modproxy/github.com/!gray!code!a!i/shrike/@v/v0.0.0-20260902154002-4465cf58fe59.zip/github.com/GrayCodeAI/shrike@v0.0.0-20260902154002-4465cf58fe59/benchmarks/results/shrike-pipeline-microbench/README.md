# `shrike-pipeline-microbench` Published Runs

Current published runs:

- `2026-06-27/`

Each published run includes:

- `report.md`
- `result.txt`
- `notes.md`

Reference manifest: `../../manifests/shrike-pipeline-microbench.yaml`
