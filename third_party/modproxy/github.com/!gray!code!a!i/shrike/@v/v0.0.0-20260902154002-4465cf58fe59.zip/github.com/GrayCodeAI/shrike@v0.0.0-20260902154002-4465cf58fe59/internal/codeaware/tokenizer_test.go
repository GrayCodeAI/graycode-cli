package codeaware

import (
	"strings"
	"testing"
)

func TestNewCodeAwareTokenizer_Defaults(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	if !tk.PreserveStructure {
		t.Error("PreserveStructure should default to true")
	}
	if !tk.CollapseWhitespace {
		t.Error("CollapseWhitespace should default to true")
	}
	if tk.ExtractSignatures {
		t.Error("ExtractSignatures should default to false")
	}
	if tk.RemoveComments {
		t.Error("RemoveComments should default to false")
	}
	if tk.MaxLineLength != 200 {
		t.Errorf("MaxLineLength = %d, want 200", tk.MaxLineLength)
	}
}

func TestTokenizeCode_ClassifiesGoConstructs(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	code := `import "fmt"
type User struct {
func Greet(name string) string {
if name == "" {
return fmt.Sprintf("hi %s", name)`
	tokens := tk.TokenizeCode(code, "go")

	// Map line content -> type for assertions.
	byType := map[string]string{}
	for _, shrike := range tokens {
		byType[shrike.Value] = shrike.Type
	}

	checks := []struct{ value, wantType string }{
		{`import "fmt"`, "import"},
		{"type User struct {", "definition"},
		{"func Greet(name string) string {", "signature"},
		{`if name == "" {`, "control"},
		{`return fmt.Sprintf("hi %s", name)`, "call"},
	}
	for _, c := range checks {
		got, ok := byType[c.value]
		if !ok {
			t.Errorf("line %q not tokenized", c.value)
			continue
		}
		if got != c.wantType {
			t.Errorf("line %q classified as %q, want %q", c.value, got, c.wantType)
		}
	}
}

func TestTokenizeCode_SkipsEmptyLines(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	code := "func a() {}\n\n\nfunc b() {}"
	tokens := tk.TokenizeCode(code, "go")
	if len(tokens) != 2 {
		t.Fatalf("expected 2 tokens (empty lines skipped), got %d: %+v", len(tokens), tokens)
	}
}

func TestTokenizeCode_LineNumbersAreOneBased(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	code := "func a() {}\nfunc b() {}"
	tokens := tk.TokenizeCode(code, "go")
	if tokens[0].Line != 1 {
		t.Errorf("first token line = %d, want 1", tokens[0].Line)
	}
	if tokens[1].Line != 2 {
		t.Errorf("second token line = %d, want 2", tokens[1].Line)
	}
}

func TestTokenizeCode_SingleLineComments(t *testing.T) {
	t.Run("kept by default and marked noise", func(t *testing.T) {
		tk := NewCodeAwareTokenizer()
		tokens := tk.TokenizeCode("// a comment\nfunc x() {}", "go")
		if len(tokens) != 2 {
			t.Fatalf("expected comment + code, got %d tokens", len(tokens))
		}
		if tokens[0].Type != "comment" || !tokens[0].IsNoise {
			t.Errorf("comment token = %+v, want type=comment IsNoise=true", tokens[0])
		}
	})

	t.Run("stripped when RemoveComments", func(t *testing.T) {
		tk := NewCodeAwareTokenizer()
		tk.RemoveComments = true
		tokens := tk.TokenizeCode("// a comment\n# also a comment\nfunc x() {}", "go")
		for _, shrike := range tokens {
			if shrike.Type == "comment" {
				t.Errorf("comment should have been removed: %+v", shrike)
			}
		}
		if len(tokens) != 1 {
			t.Errorf("expected only the code line, got %d tokens", len(tokens))
		}
	})
}

func TestTokenizeCode_BlockComments(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	code := "/* start\nmiddle\nend */\nfunc x() {}"
	tokens := tk.TokenizeCode(code, "go")
	// All three comment lines kept as noise, plus the func line.
	comments := 0
	var hasFunc bool
	for _, shrike := range tokens {
		if shrike.Type == "comment" {
			comments++
		}
		if shrike.Value == "func x() {}" {
			hasFunc = true
		}
	}
	if comments != 3 {
		t.Errorf("expected 3 block-comment tokens, got %d", comments)
	}
	if !hasFunc {
		t.Error("function line after block comment was lost")
	}
}

func TestTokenizeCode_ExtractSignaturesOnly(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	tk.ExtractSignatures = true
	code := `func Greet() {
x := 1
type T struct {
doSomething()`
	tokens := tk.TokenizeCode(code, "go")
	for _, shrike := range tokens {
		if shrike.Type != "signature" && shrike.Type != "definition" {
			t.Errorf("ExtractSignatures kept a non-signature line: %+v", shrike)
		}
	}
	if len(tokens) != 2 { // func signature + type definition
		t.Errorf("expected 2 signature/definition tokens, got %d: %+v", len(tokens), tokens)
	}
}

func TestTokenizeCode_TruncatesLongLines(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	tk.MaxLineLength = 10
	long := "abcdefghijklmnopqrstuvwxyz()" // a call, > 10 chars
	tokens := tk.TokenizeCode(long, "go")
	if len(tokens) != 1 {
		t.Fatalf("expected 1 token, got %d", len(tokens))
	}
	if !strings.HasSuffix(tokens[0].Value, "...") {
		t.Errorf("expected truncation marker, got %q", tokens[0].Value)
	}
	if len(tokens[0].Value) != 13 { // 10 chars + "..."
		t.Errorf("truncated length = %d, want 13", len(tokens[0].Value))
	}
}

func TestEstimateTokens(t *testing.T) {
	tk := NewCodeAwareTokenizer()
	if got := tk.EstimateTokens(""); got != 0 {
		t.Errorf("empty code estimate = %d, want 0", got)
	}
	// Comments are noise and must not contribute to the estimate.
	withComment := tk.EstimateTokens("// big long noisy comment line\nx()")
	codeOnly := tk.EstimateTokens("x()")
	if withComment != codeOnly {
		t.Errorf("comment contributed to token estimate: with=%d codeOnly=%d", withComment, codeOnly)
	}
	if codeOnly <= 0 {
		t.Errorf("expected positive estimate for code, got %d", codeOnly)
	}
}

func TestCompressCode(t *testing.T) {
	tk := NewCodeAwareTokenizer()

	t.Run("truncates when over budget", func(t *testing.T) {
		code := "func a() {}\nfunc b() {}\nfunc c() {}\nfunc d() {}"
		out := tk.CompressCode(code, 3, "go")
		if !strings.Contains(out, "truncated") {
			t.Errorf("expected truncation marker in output: %q", out)
		}
	})

	t.Run("keeps everything under a large budget", func(t *testing.T) {
		code := "func a() {}\nfunc b() {}"
		out := tk.CompressCode(code, 10000, "go")
		if strings.Contains(out, "truncated") {
			t.Errorf("did not expect truncation: %q", out)
		}
		if !strings.Contains(out, "func a() {}") || !strings.Contains(out, "func b() {}") {
			t.Errorf("expected both functions in output: %q", out)
		}
	})

	t.Run("drops comments when RemoveComments", func(t *testing.T) {
		tk2 := NewCodeAwareTokenizer()
		tk2.RemoveComments = true
		out := tk2.CompressCode("// noise\nfunc a() {}", 10000, "go")
		if strings.Contains(out, "noise") {
			t.Errorf("comment should be dropped: %q", out)
		}
	})
}

func TestClassifyCodeLine_AcrossLanguages(t *testing.T) {
	cases := []struct {
		line, lang, want string
	}{
		{"def greet():", "python", "signature"},
		{"class Foo:", "python", "definition"},
		{"from os import path", "python", "import"},
		{"function run() {", "typescript", "signature"},
		{"interface Shape {", "typescript", "definition"},
		{"fn main() {", "rust", "signature"},
		{"struct Point {", "rust", "definition"},
		{"use std::io;", "rust", "import"},
		{"for x in items {", "rust", "control"},
		{"plainStatement = 1", "go", "other"},
	}
	for _, c := range cases {
		t.Run(c.lang+"/"+c.want, func(t *testing.T) {
			if got := classifyCodeLine(c.line, c.lang); got != c.want {
				t.Errorf("classifyCodeLine(%q, %q) = %q, want %q", c.line, c.lang, got, c.want)
			}
		})
	}
}

func TestIsFunctionCall(t *testing.T) {
	if !isFunctionCall("doThing()") {
		t.Error("doThing() should be detected as a call")
	}
	if !isFunctionCall("obj.method(arg)") {
		t.Error("obj.method(arg) should be detected as a call")
	}
	if isFunctionCall("(grouped + expr)") {
		t.Error("a leading paren without an identifier is not a call")
	}
	if isFunctionCall("no parens here") {
		t.Error("text without parens is not a call")
	}
}
