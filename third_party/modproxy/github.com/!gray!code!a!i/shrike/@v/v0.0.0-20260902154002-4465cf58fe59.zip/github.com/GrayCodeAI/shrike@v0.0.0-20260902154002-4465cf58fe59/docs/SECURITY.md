# Security Best Practices

**Version:** 1.0.0
**Last Updated:** 2026-06-06

## Overview

shrike is a Go library (`github.com/GrayCodeAI/shrike`) for token-aware text
compression and estimation. This document outlines security considerations for
embedding the shrike library in your own Go programs.

Most CLI verbs people associate with shrike (`compress`, `estimate`, etc.) are
surfaced through [Hawk](https://github.com/GrayCodeAI/hawk), which embeds this
library. Use Hawk (`hawk shrike ...`) when you want a command-line surface.

## Library Security Features

shrike ships helpers that are useful for keeping sensitive data out of compressed
output and out of logs:

```go
import "github.com/GrayCodeAI/shrike"

// Detect secrets (API keys, tokens, private keys) in text before sending it.
det := shrike.NewSecretDetector()
findings := det.Detect(text)

// Decide whether a filename is sensitive (.env, id_rsa, credentials, etc.).
if shrike.IsSensitiveFilename(path) {
    // skip or redact
}
```

**Best Practices:**
- Run `shrike.NewSecretDetector()` over content before it leaves your process.
- Use `shrike.IsSensitiveFilename` to avoid ingesting credential files.
- Never commit secrets to version control; store them in environment variables
  or a secrets manager.

## Custom Filter Rules

Compression filtering is configurable via TOML rule files loaded with
`shrike.LoadFilterRules`, then applied through `shrike.WithCustomFilters`:

```go
rules, err := shrike.LoadFilterRules("filters.toml")
if err != nil {
    log.Fatal(err)
}
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

Treat filter rule files as part of your trusted configuration. Set restrictive
permissions on any TOML rule or profile file that encodes sensitive policy:

```bash
chmod 600 filters.toml
```

## Dependency Security

### Vulnerability Scanning

```bash
# Check for vulnerable dependencies
govulncheck ./...
gosec ./...
```

### Dependency Updates

```bash
# Update dependencies
go get -u ./...
go mod tidy
```

## Incident Response

### Security Incident Checklist

1. **Identify**: Detect the incident via logs or alerts
2. **Contain**: Stop the affected process and isolate impacted hosts
3. **Eradicate**: Rotate any leaked credentials, remove compromised configs
4. **Recover**: Restore from trusted backup
5. **Report**: Document incident and notify stakeholders

## Security Checklist

- [ ] Secrets scanned with `shrike.NewSecretDetector()` before egress
- [ ] Sensitive filenames screened with `shrike.IsSensitiveFilename`
- [ ] Filter/profile TOML file permissions restricted (600)
- [ ] Dependencies scanned for vulnerabilities

## Reporting Security Issues

If you discover a security vulnerability, please report it responsibly:

1. Email: security@shrike.dev
2. Do not disclose publicly until patched
3. Include steps to reproduce
4. We aim to respond within 48 hours

## Security Updates

Subscribe to security advisories:
- GitHub Security Advisories: https://github.com/GrayCodeAI/shrike/security/advisories
- Release notes include security fixes
