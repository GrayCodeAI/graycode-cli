package core

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestCountTokensExact_RequiresAPIKey(t *testing.T) {
	if _, err := CountTokensExact(context.Background(), "", "claude-3-5-sonnet", "hello"); err == nil {
		t.Fatal("expected an error when apiKey is empty, got nil")
	}
}

func TestCountTokensExact_UnsupportedModel(t *testing.T) {
	if _, err := CountTokensExact(context.Background(), "sk-fake", "gpt-4o", "hello"); err == nil {
		t.Fatal("expected an error for a non-claude/gemini model, got nil")
	}
}

func TestCountTokensExact_Anthropic(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.Header.Get("x-api-key"); got != "sk-ant-fake" {
			t.Errorf("x-api-key = %q, want %q", got, "sk-ant-fake")
		}
		if got := r.Header.Get("anthropic-version"); got == "" {
			t.Error("anthropic-version header missing")
		}
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatalf("decode request body: %v", err)
		}
		if body["model"] != "claude-3-5-sonnet-20241022" {
			t.Errorf("model = %v, want claude-3-5-sonnet-20241022", body["model"])
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]int{"input_tokens": 7})
	}))
	defer srv.Close()

	orig := anthropicCountTokensURL
	anthropicCountTokensURL = srv.URL
	defer func() { anthropicCountTokensURL = orig }()

	got, err := CountTokensExact(context.Background(), "sk-ant-fake", "claude-3-5-sonnet-20241022", "hello world")
	if err != nil {
		t.Fatalf("CountTokensExact() error: %v", err)
	}
	if got != 7 {
		t.Errorf("CountTokensExact() = %d, want 7", got)
	}
}

func TestCountTokensExact_AnthropicError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
		_, _ = w.Write([]byte(`{"error": "invalid api key"}`))
	}))
	defer srv.Close()

	orig := anthropicCountTokensURL
	anthropicCountTokensURL = srv.URL
	defer func() { anthropicCountTokensURL = orig }()

	if _, err := CountTokensExact(context.Background(), "bad-key", "claude-3-5-sonnet", "hi"); err == nil {
		t.Fatal("expected an error for a 401 response, got nil")
	} else if !strings.Contains(err.Error(), "401") {
		t.Errorf("error = %v, want it to mention status 401", err)
	}
}

func TestCountTokensExact_Google(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got := r.URL.Query().Get("key"); got != "goog-fake" {
			t.Errorf("key query param = %q, want %q", got, "goog-fake")
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]int{"totalTokens": 5})
	}))
	defer srv.Close()

	orig := googleCountTokensURL
	googleCountTokensURL = srv.URL + "/%s"
	defer func() { googleCountTokensURL = orig }()

	got, err := CountTokensExact(context.Background(), "goog-fake", "gemini-2.5-pro", "hello world")
	if err != nil {
		t.Fatalf("CountTokensExact() error: %v", err)
	}
	if got != 5 {
		t.Errorf("CountTokensExact() = %d, want 5", got)
	}
}

func TestCountTokensExact_NeverCalledByEstimateTokens(t *testing.T) {
	// EstimateTokens and friends must remain fully offline. This test
	// doesn't hit the network by construction (no http.Client involved),
	// which is the point: there is no code path from EstimateTokens into
	// CountTokensExact or exactCountClient.
	if got := EstimateTokens("hello world"); got <= 0 {
		t.Errorf("EstimateTokens() = %d, want > 0", got)
	}
}
