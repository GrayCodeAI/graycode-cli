package filter

import (
	"strings"
	"testing"
)

func TestEngineProcess(t *testing.T) {
	engine := NewEngine(ModeMinimal)
	input := "Hello, world!"
	output, saved := engine.Process(input)
	if output == "" {
		t.Error("expected non-empty output")
	}
	if saved < 0 {
		t.Errorf("expected non-negative tokens saved, got %d", saved)
	}
}

func TestEngineProcessWithANSI(t *testing.T) {
	engine := NewEngine(ModeMinimal)
	input := "\x1b[32mGreen text\x1b[0m and normal text"
	output, saved := engine.Process(input)
	if strings.Contains(output, "\x1b[") {
		t.Error("ANSI codes should be stripped from output")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved from ANSI stripping")
	}
}

func TestEngineSetMode(t *testing.T) {
	engine := NewEngine(ModeMinimal)
	engine.SetMode(ModeAggressive)
	if engine.mode != ModeAggressive {
		t.Errorf("expected mode %q, got %q", ModeAggressive, engine.mode)
	}
}

func TestEngineProcessMinimalSkipsBody(t *testing.T) {
	engine := NewEngine(ModeMinimal)
	input := "func main() {\n    fmt.Println(\"hello\")\n}\nSome body text here"
	output, _ := engine.Process(input)
	if !strings.Contains(output, "func main") {
		t.Error("expected function signature to be preserved in minimal mode")
	}
}

func TestDetectLanguage(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected string
	}{
		{
			name:     "Go code",
			input:    "package main\n\nfunc main() {\n    fmt.Println(\"hello\")\n}",
			expected: "go",
		},
		{
			name:     "Rust code",
			input:    "fn main() {\n    println!(\"hello\");\n}",
			expected: "rust",
		},
		{
			name:     "Python code",
			input:    "def greet():\n    print(\"hello\")",
			expected: "python",
		},
		{
			name:     "JavaScript code",
			input:    "function hello() {\n    console.log('hello');\n}",
			expected: "javascript",
		},
		{
			name:     "TypeScript code",
			input:    "interface User {\n    name: string;\n}",
			expected: "typescript",
		},
		{
			name:     "Java code",
			input:    "public class Main {\n    public static void main(String[] args) {}\n}",
			expected: "java",
		},
		{
			name:     "C++ code",
			input:    "std::cout << \"hello\" << std::endl;",
			expected: "cpp",
		},
		{
			name:     "C code",
			input:    "printf(\"hello\");",
			expected: "c",
		},
		{
			name:     "Ruby code",
			input:    "puts 'hello'",
			expected: "ruby",
		},
		{
			name:     "Shell code",
			input:    "chmod +x script.sh",
			expected: "shell",
		},
		{
			name:     "SQL code",
			input:    "SELECT * FROM users WHERE id = 1",
			expected: "sql",
		},
		{
			name:     "Unknown content",
			input:    "Hello, world!",
			expected: "unknown",
		},
		{
			name:     "Empty string",
			input:    "",
			expected: "unknown",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := DetectLanguage(tt.input)
			if result != tt.expected {
				t.Errorf("DetectLanguage(%q) = %q, expected %q", tt.input, result, tt.expected)
			}
		})
	}
}

func TestDetectLanguageFromInput(t *testing.T) {
	result := DetectLanguageFromInput("func main() {}")
	if result != LangGo {
		t.Errorf("expected %q, got %q", LangGo, result)
	}
}

func TestDetectLanguageLargeInput(t *testing.T) {
	largeInput := strings.Repeat("func main() { fmt.Println(\"hello\") } ", 1000)
	result := DetectLanguage(largeInput)
	if result != "go" {
		t.Errorf("expected %q for large Go input, got %q", "go", result)
	}
}

func TestDetectLanguagePythonWithCurlyBracePenalty(t *testing.T) {
	input := "def hello():\n    print(\"hello\")\n{ this is not python }"
	result := DetectLanguage(input)
	if result == "python" {
		t.Error("Python should be penalized when curly braces are present")
	}
}
