package shrike

import (
	"fmt"
	"strings"
	"testing"
)

func TestStatsHardTruncated(t *testing.T) {
	tests := []struct {
		name   string
		layers map[string]LayerStat
		saved  int
		want   bool
	}{
		{
			name:   "budget layer dominant -> hard truncation",
			layers: map[string]LayerStat{"10_budget": {TokensSaved: 800}},
			saved:  1000,
			want:   true,
		},
		{
			name:   "budget layer absent -> not hard truncation",
			layers: map[string]LayerStat{"11_compaction": {TokensSaved: 800}},
			saved:  1000,
			want:   false,
		},
		{
			name:   "structural layers dominant -> not hard truncation",
			layers: map[string]LayerStat{"10_budget": {TokensSaved: 100}, "11_compaction": {TokensSaved: 900}},
			saved:  1000,
			want:   false,
		},
		{
			name:   "nothing saved -> not hard truncation",
			layers: map[string]LayerStat{},
			saved:  0,
			want:   false,
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			s := Stats{TokensSaved: tc.saved, Layers: tc.layers}
			if got := s.HardTruncated(); got != tc.want {
				t.Errorf("HardTruncated() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestCompressWithBudgetZeroDisablesTruncation(t *testing.T) {
	// WithBudget(0) must mean "no budget cap": the budget-enforcer layer must
	// be inert (record no savings), while a real budget activates it.
	var sb strings.Builder
	for i := 0; i < 500; i++ {
		fmt.Fprintf(&sb, "Distinct sentence number %d adds factual informative content here. ", i)
	}
	in := sb.String()

	out, stats := Compress(in, WithBudget(0), WithMode(ModeMinimal))
	if out == "" {
		t.Fatal("WithBudget(0) must not produce empty output")
	}
	if saved := stats.Layers["10_budget"].TokensSaved; saved != 0 {
		t.Fatalf("budget enforcer must be inert with budget 0, saved %d tokens", saved)
	}

	out2, stats2 := Compress(in, WithBudget(60), WithMode(ModeMinimal))
	if out2 == "" {
		t.Fatal("budgeted compress must not produce empty output")
	}
	if stats2.Layers["10_budget"].TokensSaved <= 0 {
		t.Fatalf("budget enforcer must cut with a real budget, layer savings = %d", stats2.Layers["10_budget"].TokensSaved)
	}
	if stats2.FinalTokens > 60 {
		t.Fatalf("budgeted output exceeds budget: %d tokens", stats2.FinalTokens)
	}
}
