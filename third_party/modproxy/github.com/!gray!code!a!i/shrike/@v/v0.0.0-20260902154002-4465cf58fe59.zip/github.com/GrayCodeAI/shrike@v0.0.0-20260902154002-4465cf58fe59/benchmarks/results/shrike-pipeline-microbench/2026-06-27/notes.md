# Provenance Notes

- Command:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./evals/pipeline-bench.sh'`
- Verification:
  benchmark command exited successfully with `PASS`
- Environment:
  local workspace run on `2026-06-27`
  `goos=darwin`
  `goarch=arm64`
  `cpu=Apple M1`
- Caveats:
  pipeline timings are local benchmark measurements rather than CI medians
  this suite measures the internal filter pipeline, not end-to-end answer quality
