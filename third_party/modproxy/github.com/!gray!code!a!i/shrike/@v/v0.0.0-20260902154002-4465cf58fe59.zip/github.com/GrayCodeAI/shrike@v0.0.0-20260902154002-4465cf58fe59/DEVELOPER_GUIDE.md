# Shrike Developer Quick Reference

## Library API

Shrike is a Go library for LLM token compression. Import it directly:

```go
import "github.com/GrayCodeAI/shrike"
```

### Basic Compression

```go
// One-shot compression
compressed, stats := shrike.Compress(text, shrike.Aggressive)

// Reusable compressor instance
c := shrike.NewCompressor(shrike.Adaptive)
output, stats := c.Compress(text)
```

### Token Estimation

```go
// Fast estimate
count := shrike.EstimateTokens(text)

// Precise BPE-based count
count := shrike.EstimateTokensPrecise(text)
```

### Compression Modes

```go
shrike.Minimal    // ~20% savings, preserve most content
shrike.Aggressive // ~60% savings, aggressive filtering
shrike.Adaptive   // Auto-selects based on input characteristics
shrike.Surface    // Light surface-level cleanup
shrike.Trim       // Remove whitespace and formatting
shrike.Extract    // Keep only key information
shrike.Core       // Distill to essential meaning
shrike.Code       // Code-aware compression
shrike.Log        // Optimized for log output
shrike.Thread     // Optimized for conversation threads
```

### Pipeline Coordinator Pooling

```go
import "github.com/GrayCodeAI/shrike/internal/filter"

// Use default pool for repeated compression
pool := filter.GetDefaultPool()
coord := pool.Get()
defer pool.Put(coord)

output, stats := coord.Process(input)

// Or create custom pool
customPool := filter.NewCoordinatorPool(myConfig)
```

### Code-Aware Chunking

```go
// Get language-specific patterns for semantic chunking
patterns := shrike.GetLanguagePatterns("go")
```

## Internal Packages

| Package | Purpose |
|---------|---------|
| `internal/filter` | 31-layer compression pipeline |
| `internal/core` | Token estimation, pipeline runner |
| `internal/cache` | Multi-level caching with git-aware watcher |
| `internal/config` | Configuration management |
| `internal/fastops` | Performance-optimized string operations (manual loop unrolling) |
| `internal/utils` | Shared utilities |

## Testing

```bash
# Run all tests
make test

# Run with race detector
make test-race

# Run benchmarks
make benchmark

# Run adaptive benchmark comparison
make benchmark-adaptive

# Run scenario benchmark suite
make benchmark-suite

# Run ablation tests
make ablation
```

## Performance Tips

1. **Always use coordinator pooling** — 10-20x faster than creating new coordinators
2. **Choose the right mode** — `Adaptive` auto-selects; manual modes save overhead
3. **Reuse Compressor instances** — amortizes setup cost across calls
4. **Use EstimateTokens for budgeting** — fast heuristic for token counting
5. **Use EstimateTokensPrecise for billing** — accurate BPE count
