package secrets

import (
	"context"
	"math"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"sync"
)

// SecretMatch represents a detected secret within text.
type SecretMatch struct {
	Type     string
	Value    string
	Masked   string
	StartPos int
	EndPos   int

	// Verified reports whether a live-credential check confirmed this
	// secret is an active credential. nil means verification was not
	// attempted — this is always the case for DetectSecrets, which never
	// makes network calls. A non-nil value means DetectSecretsVerified
	// attempted a live check for this match's type; verification errors
	// (network failures, timeouts, etc.) also leave this nil rather than
	// reporting a false negative.
	Verified *bool
}

type secretPattern struct {
	Type    string
	Pattern *regexp.Regexp
	// Verify is optional; nil means no live verifier exists for this type.
	Verify Verifier
}

// SecretDetector detects and redacts secrets from text using compiled regex patterns.
type SecretDetector struct {
	patterns []secretPattern
}

var (
	defaultDetector     *SecretDetector
	defaultDetectorOnce sync.Once
)

// DefaultDetector returns the singleton SecretDetector instance with all built-in patterns.
func DefaultDetector() *SecretDetector {
	defaultDetectorOnce.Do(func() {
		defaultDetector = NewDetector()
	})
	return defaultDetector
}

// NewDetector creates a SecretDetector with all built-in patterns compiled and ready.
func NewDetector() *SecretDetector {
	sd := &SecretDetector{}
	sd.patterns = compilePatterns()
	return sd
}

func compilePatterns() []secretPattern {
	raw := []struct {
		Type    string
		Pattern string
	}{
		{"AWS Access Key", `\b((?:AKIA|ASIA)[A-Z0-9]{16})\b`},
		{"AWS Secret Key", `(?i)(?:aws_secret_access_key|aws_secret)\s*[:=]\s*['"]?([A-Za-z0-9/+=]{40})['"]?`},
		{"GitHub Token", `\b(gh[oprs]_[A-Za-z0-9_]{36,})\b`},
		{"GitHub Fine-grained Token", `\b(github_pat_[A-Za-z0-9_]{22,})\b`},
		{"GitLab Token", `\b(glpat-[A-Za-z0-9_-]{20,})\b`},
		{"Slack Bot Token", `\b(xoxb-[A-Za-z0-9-]{10,})\b`},
		{"Slack User Token", `\b(xoxp-[A-Za-z0-9-]{10,})\b`},
		{"Slack Token", `\b(xox[bprs]-[A-Za-z0-9-]{10,})\b`},
		{"Slack Webhook", `https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+`},
		{"Google API Key", `\b(AIza[A-Za-z0-9_-]{35})\b`},
		{"Google OAuth", `\b([0-9]+-[A-Za-z0-9_]{32}\.apps\.googleusercontent\.com)\b`},
		{"Stripe Secret Key", `\b(sk_(?:live|test)_[A-Za-z0-9]{24,})\b`},
		{"Stripe Publishable Key", `\b(pk_(?:live|test)_[A-Za-z0-9]{24,})\b`},
		{"OpenAI API Key", `\b(sk-[A-Za-z0-9]{20,})\b`},
		{"Anthropic API Key", `\b(sk-ant-[A-Za-z0-9_-]{20,})\b`},
		{"Azure AD Client Secret", `(?i)(?:client_secret|clientsecret)\s*[:=]\s*([A-Za-z0-9~._-]{34,})`},
		{"JWT Token", `\b(eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*)\b`},
		{"RSA Private Key", `(-----BEGIN RSA PRIVATE KEY-----[\s\S]*?-----END RSA PRIVATE KEY-----)`},
		{"EC Private Key", `(-----BEGIN EC PRIVATE KEY-----[\s\S]*?-----END EC PRIVATE KEY-----)`},
		{"OpenSSH Private Key", `(-----BEGIN OPENSSH PRIVATE KEY-----[\s\S]*?-----END OPENSSH PRIVATE KEY-----)`},
		{"Private Key", `(-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----)`},
		{"SendGrid API Key", `\b(SG\.[A-Za-z0-9_-]{22,}\.[A-Za-z0-9_-]{43,})\b`},
		{"Twilio Account SID", `\b(AC[a-f0-9]{32})\b`},
		{"Heroku API Key", `(?i)heroku[_-]?api[_-]?key\s*[:=]\s*['"]?([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})['"]?`},
		{"DigitalOcean Token", `\b(dop_v1_[a-f0-9]{64})\b`},
		{"npm Token", `\b(npm_[A-Za-z0-9]{36,})\b`},
		{"PyPI Token", `\b(pypi-[A-Za-z0-9_-]{50,})\b`},
		{"Docker Registry Token", `(?i)"auth"\s*:\s*"([A-Za-z0-9+/=]{20,})"`},
		{"Generic API Key", `(?i)(?:api_key|apikey|api-key|access_token|auth_token|secret_key)\s*[:=]\s*['"]?([A-Za-z0-9_\-]{20,})['"]?`},
		{"Generic Password", `(?i)(?:password|passwd|pwd)\s*[:=]\s*['"]?([^\s'"]{8,})['"]?`},
		{"Generic Secret", `(?i)(?:secret|client_secret)\s*[:=]\s*['"]?([^\s'"]{8,})['"]?`},
		{"Database Connection String", `(?i)((?:mongodb|postgres|mysql|redis|amqp|mssql)://[^\s]+)`},
		{"Bearer Token", `(?i)bearer\s+([A-Za-z0-9_\-\.]+)`},
	}

	var patterns []secretPattern
	for _, r := range raw {
		compiled, err := regexp.Compile(r.Pattern)
		if err != nil {
			continue
		}
		patterns = append(patterns, secretPattern{Type: r.Type, Pattern: compiled, Verify: patternVerifiers[r.Type]})
	}
	return patterns
}

// DetectSecrets finds all secrets in the given text.
func (sd *SecretDetector) DetectSecrets(text string) []SecretMatch {
	var matches []SecretMatch
	for _, p := range sd.patterns {
		for _, loc := range p.Pattern.FindAllStringSubmatchIndex(text, -1) {
			if len(loc) < 4 {
				// No capture group — use the full match
				if len(loc) >= 2 {
					groupStart, groupEnd := loc[0], loc[1]
					value := text[groupStart:groupEnd]
					masked := maskSecretValue(value, p.Type)
					matches = append(matches, SecretMatch{
						Type:     p.Type,
						Value:    value,
						Masked:   masked,
						StartPos: groupStart,
						EndPos:   groupEnd,
					})
				}
				continue
			}
			groupStart, groupEnd := loc[2], loc[3]
			if groupStart < 0 {
				groupStart, groupEnd = loc[0], loc[1]
			}
			value := text[groupStart:groupEnd]
			masked := maskSecretValue(value, p.Type)
			matches = append(matches, SecretMatch{
				Type:     p.Type,
				Value:    value,
				Masked:   masked,
				StartPos: groupStart,
				EndPos:   groupEnd,
			})
		}
	}
	sort.Slice(matches, func(i, j int) bool { return matches[i].StartPos < matches[j].StartPos })
	return matches
}

// DetectSecretsVerified is like DetectSecrets, but additionally makes a live
// network call per detected secret (where a verifier exists for its type)
// to confirm whether the credential is actually an active one — following
// TruffleHog's live-verification model. This is the only function in this
// package that makes network calls; DetectSecrets and RedactSecrets never
// do, and remain unchanged whether or not this function is ever called.
//
// client may be nil, in which case a default 5-second-timeout client is
// used. AWS Access Keys are only verified when a paired AWS Secret Key was
// also matched in the same text — an access key ID alone can't be signed,
// so without a pair the match's Verified field stays nil, identical to
// DetectSecrets.
func (sd *SecretDetector) DetectSecretsVerified(ctx context.Context, client *http.Client, text string) []SecretMatch {
	if client == nil {
		client = defaultVerifyClient
	}
	matches := sd.DetectSecrets(text)

	var awsSecretKey string
	for _, m := range matches {
		if m.Type == "AWS Secret Key" {
			awsSecretKey = m.Value
			break
		}
	}

	for i := range matches {
		m := &matches[i]
		if m.Type == "AWS Access Key" {
			if awsSecretKey == "" {
				continue
			}
			ok, err := verifyAWSKeyPair(ctx, client, m.Value, awsSecretKey)
			if err != nil {
				continue
			}
			m.Verified = &ok
			continue
		}

		verify := patternVerifiers[m.Type]
		if verify == nil {
			continue
		}
		ok, err := verify(ctx, client, m.Value)
		if err != nil {
			continue
		}
		m.Verified = &ok
	}
	return matches
}

// RedactSecrets replaces detected secrets with [REDACTED] markers.
func (sd *SecretDetector) RedactSecrets(text string) string {
	matches := sd.DetectSecrets(text)
	if len(matches) == 0 {
		return text
	}

	var sb strings.Builder
	lastIdx := 0
	for _, m := range matches {
		if m.EndPos <= lastIdx {
			// Fully covered by a previously redacted match; nothing left to hide.
			continue
		}
		start := m.StartPos
		if start < lastIdx {
			// Overlaps a previously redacted match but extends further right:
			// redact only the un-redacted tail so no part of the secret leaks.
			start = lastIdx
		}
		sb.WriteString(text[lastIdx:start])
		sb.WriteString("[REDACTED:")
		sb.WriteString(m.Type)
		sb.WriteString("]")
		lastIdx = m.EndPos
	}
	sb.WriteString(text[lastIdx:])
	return sb.String()
}

// maskSecretValue masks a secret value for safe display.
// For private keys, preserves the header/footer and replaces body with [REDACTED].
// For other secrets, shows first/last 4 chars with asterisks in between.
func maskSecretValue(value, secretType string) string {
	// Private keys: preserve header, mask body
	if strings.Contains(value, "-----BEGIN") && strings.Contains(value, "-----END") {
		lines := strings.SplitN(value, "\n", 2)
		if len(lines) == 2 {
			header := lines[0]
			return header + "\n[REDACTED]"
		}
		return "[REDACTED]"
	}
	return maskString(value)
}

func maskString(s string) string {
	if len(s) <= 8 {
		return strings.Repeat("*", len(s))
	}
	return s[:4] + strings.Repeat("*", len(s)-8) + s[len(s)-4:]
}

// wordPattern matches whitespace-delimited words, used to locate entropy
// candidates without disturbing the original whitespace around them.
var wordPattern = regexp.MustCompile(`\S+`)

// DetectAndRedactWithEntropy detects secrets using both pattern matching and entropy analysis.
func (sd *SecretDetector) DetectAndRedactWithEntropy(text string, entropyThreshold float64) string {
	result := sd.RedactSecrets(text)
	// Also check for high-entropy strings that might be secrets. Replace matched
	// words in place (rather than splitting on whitespace and rejoining with a
	// single space) so original spacing/newlines are preserved.
	var sb strings.Builder
	lastIdx := 0
	for _, loc := range wordPattern.FindAllStringIndex(result, -1) {
		start, end := loc[0], loc[1]
		word := result[start:end]
		sb.WriteString(result[lastIdx:start])
		if calculateShannonEntropy(word) > entropyThreshold && len(word) > 16 {
			sb.WriteString("[REDACTED:HIGH_ENTROPY]")
		} else {
			sb.WriteString(word)
		}
		lastIdx = end
	}
	sb.WriteString(result[lastIdx:])
	return sb.String()
}

// calculateShannonEntropy calculates the Shannon entropy of a string.
func calculateShannonEntropy(s string) float64 {
	if len(s) == 0 {
		return 0
	}
	freq := make(map[rune]int)
	for _, r := range s {
		freq[r]++
	}
	entropy := 0.0
	length := float64(len([]rune(s)))
	for _, count := range freq {
		p := float64(count) / length
		if p > 0 {
			entropy -= p * math.Log2(p)
		}
	}
	return entropy
}

// MaskSecret masks a secret value for safe display.
func MaskSecret(value, secretType string) string {
	return maskSecretValue(value, secretType)
}
