package shrike_test

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestLoadProfile(t *testing.T) {
	tests := []struct {
		name        string
		filename    string
		contents    string
		wantName    string
		wantMode    shrike.Mode
		wantTier    shrike.Tier
		wantBudget  int
		wantRules   string
		wantOptsLen int
		wantErr     bool
	}{
		{
			name:     "full profile",
			filename: "team.toml",
			contents: `
name = "team"
version = "2"
mode = "aggressive"
tier = "extract"
budget = 4000
filter_rules_path = ".shrike/rules.toml"
notes = "shared team profile"
`,
			wantName:    "team",
			wantMode:    shrike.ModeAggressive,
			wantTier:    shrike.TierExtract,
			wantBudget:  4000,
			wantRules:   ".shrike/rules.toml",
			wantOptsLen: 3, // mode + tier + budget
		},
		{
			name:     "name defaults to filename",
			filename: "code-safe.toml",
			contents: `
mode = "minimal"
tier = "code"
`,
			wantName:    "code-safe",
			wantMode:    shrike.ModeMinimal,
			wantTier:    shrike.TierCode,
			wantOptsLen: 2, // mode + tier (budget 0 omitted)
		},
		{
			name:     "invalid mode",
			filename: "bad.toml",
			contents: `mode = "ludicrous"`,
			wantErr:  true,
		},
		{
			name:     "negative budget",
			filename: "neg.toml",
			contents: `budget = -1`,
			wantErr:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dir := t.TempDir()
			path := filepath.Join(dir, tt.filename)
			if err := os.WriteFile(path, []byte(tt.contents), 0o600); err != nil {
				t.Fatalf("write temp profile: %v", err)
			}

			p, err := shrike.LoadProfile(path)
			if tt.wantErr {
				if err == nil {
					t.Fatalf("expected error, got profile %+v", p)
				}
				return
			}
			if err != nil {
				t.Fatalf("LoadProfile: %v", err)
			}

			if p.Name != tt.wantName {
				t.Errorf("Name = %q, want %q", p.Name, tt.wantName)
			}
			if p.Mode != tt.wantMode {
				t.Errorf("Mode = %q, want %q", p.Mode, tt.wantMode)
			}
			if p.Tier != tt.wantTier {
				t.Errorf("Tier = %q, want %q", p.Tier, tt.wantTier)
			}
			if p.Budget != tt.wantBudget {
				t.Errorf("Budget = %d, want %d", p.Budget, tt.wantBudget)
			}
			if p.FilterRulesPath != tt.wantRules {
				t.Errorf("FilterRulesPath = %q, want %q", p.FilterRulesPath, tt.wantRules)
			}
			if got := len(p.Options()); got != tt.wantOptsLen {
				t.Errorf("len(Options()) = %d, want %d", got, tt.wantOptsLen)
			}
		})
	}
}

func TestProfileOptionsRoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "rt.toml")
	contents := `
name = "rt"
mode = "aggressive"
tier = "surface"
budget = 1000
`
	if err := os.WriteFile(path, []byte(contents), 0o600); err != nil {
		t.Fatalf("write profile: %v", err)
	}

	p, err := shrike.LoadProfile(path)
	if err != nil {
		t.Fatalf("LoadProfile: %v", err)
	}

	// Options must apply cleanly to Compress without error/panic and produce output.
	in := "The quick brown fox jumps over the lazy dog. " +
		"This is a longer sentence with redundant filler words to compress."
	out, stats := shrike.Compress(in, p.Options()...)
	if out == "" {
		t.Fatal("expected non-empty output from profile options")
	}
	if stats.OriginalTokens == 0 {
		t.Error("expected non-zero original token count in stats")
	}
}

func TestLoadProfiles(t *testing.T) {
	dir := t.TempDir()

	files := map[string]string{
		"alpha.toml": "name = \"alpha\"\nmode = \"minimal\"\ntier = \"core\"\n",
		"beta.toml":  "name = \"beta\"\nmode = \"aggressive\"\ntier = \"extract\"\n",
		"ignore.txt": "name = \"ignored\"\n", // non-toml must be skipped
	}
	for name, body := range files {
		if err := os.WriteFile(filepath.Join(dir, name), []byte(body), 0o600); err != nil {
			t.Fatalf("write %s: %v", name, err)
		}
	}

	profiles, err := shrike.LoadProfiles(dir)
	if err != nil {
		t.Fatalf("LoadProfiles: %v", err)
	}
	if len(profiles) != 2 {
		t.Fatalf("expected 2 profiles, got %d: %v", len(profiles), keys(profiles))
	}
	if _, ok := profiles["alpha"]; !ok {
		t.Error("missing profile 'alpha'")
	}
	if _, ok := profiles["beta"]; !ok {
		t.Error("missing profile 'beta'")
	}
	if _, ok := profiles["ignored"]; ok {
		t.Error("non-toml file should not be loaded")
	}
}

func TestLoadProfilesMissingDir(t *testing.T) {
	profiles, err := shrike.LoadProfiles(filepath.Join(t.TempDir(), "does-not-exist"))
	if err != nil {
		t.Fatalf("expected no error for missing dir, got %v", err)
	}
	if len(profiles) != 0 {
		t.Errorf("expected empty map, got %d entries", len(profiles))
	}
}

func TestBuiltinProfiles(t *testing.T) {
	all := shrike.BuiltinProfiles()
	for _, name := range []string{"default", "aggressive", "code-safe"} {
		p, ok := all[name]
		if !ok {
			t.Errorf("built-in %q not present in BuiltinProfiles()", name)
			continue
		}
		if p.Name != name {
			t.Errorf("built-in %q has Name %q", name, p.Name)
		}
		if err := p.Validate(); err != nil {
			t.Errorf("built-in %q failed validation: %v", name, err)
		}
		// Built-ins must resolve to usable options.
		if len(p.Options()) == 0 {
			t.Errorf("built-in %q resolved to zero options", name)
		}
	}

	// BuiltinProfile returns an independent copy.
	a, ok := shrike.BuiltinProfile("default")
	if !ok {
		t.Fatal("BuiltinProfile(default) not found")
	}
	a.Budget = 99999
	b, _ := shrike.BuiltinProfile("default")
	if b.Budget == 99999 {
		t.Error("mutating a returned built-in profile leaked into the registry")
	}

	if _, ok := shrike.BuiltinProfile("nope"); ok {
		t.Error("BuiltinProfile returned ok for unknown profile")
	}
}

func keys(m map[string]*shrike.Profile) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}
