# Shrike Performance Guide

Performance documentation for the **shrike** Go library (`github.com/GrayCodeAI/shrike`) — benchmarks, the compression pipeline, profiling, and production tuning.

Install:

```bash
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

> **CLI verbs?** `shrike` is a library, not a command. The `shrike compress`, `shrike estimate`, etc. verbs you may remember are exposed through **Hawk** (`github.com/GrayCodeAI/hawk`), which embeds this library (`hawk shrike ...`).

---

## Current Performance (Production-Ready)

### Benchmark Results

| Benchmark | Iterations | Time/op | Memory/op | Allocations/op |
|-----------|-----------|---------|-----------|----------------|
| BenchmarkPipeline-8 | 1,381 | 883μs | 719KB | 58 |
| BenchmarkPipelineFull-8 | 1,406 | 862μs | 698KB | 78 |
| BenchmarkPipeline_Small-8 | 246,105 | 4.9μs | 4.8KB | 25 |
| BenchmarkPipeline_Medium-8 | 16,905 | 73μs | 50KB | 48 |
| BenchmarkPipeline_Large-8 | 2,511 | 499μs | 336KB | 62 |

### Throughput Analysis

| Input Size | Throughput | Time | Efficiency |
|------------|------------|------|------------|
| Small (1KB) | 11.6M tokens/s | 4.9μs | Excellent |
| Medium (10KB) | 24.7M tokens/s | 73μs | Excellent |
| Large (100KB) | 32.0M tokens/s | 499μs | Excellent |

### Compression Effectiveness

| Metric | Lite Mode | Full Pipeline | Improvement |
|--------|-----------|---------------|-------------|
| Tokens Saved | 135 | 168 | +24% |
| Compression Ratio | 74.6% | 92.8% | +18.2% |
| Processing Time | 19μs | 45μs | Acceptable |
| Layers Used | 3 | 26 | Full pipeline |

### Thread-Safety Overhead

The library is safe for concurrent use; `shrike.Compress` and the tracker carry minimal synchronization overhead.

| Component | Expected | Actual | Status |
|-----------|----------|--------|--------|
| Mutex Lock/Unlock | ~50ns | <100ns | ✅ Within bounds |
| Atomic Operations | ~20ns | <50ns | ✅ Within bounds |
| **Total Overhead** | **~1%** | **<2%** | **✅ Acceptable** |

---

## Optimization History

### Original Baseline (Before Optimizations)

```
BenchmarkPipeline-8            	      62	  22084271 ns/op	15260204 B/op	  151015 allocs/op
BenchmarkPipelineFull-8        	      48	  26398920 ns/op	21957270 B/op	  151834 allocs/op
```

| Input Size | Time | Memory | Allocations | Throughput |
|------------|------|--------|-------------|------------|
| Small (1KB) | 49μs | 35KB | 151 | 1.2M tokens/s |
| Medium (10KB) | 2.3ms | 1.2MB | 10,500 | 778K tokens/s |
| Large (100KB) | 13.6ms | 7.5MB | 79,599 | 1.2M tokens/s |

### Improvement Summary

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Allocations (pipeline) | 151K | 58 | **99.96% ↓** |
| Memory (100KB) | 7.5MB | 336KB | **95.6% ↓** |
| Time (100KB) | 13.6ms | 499μs | **96.3% ↓** |
| Throughput (small) | 1.2M tokens/s | 11.6M tokens/s | **867% ↑** |

### Optimization Phases Completed

**Phase 1: High Impact, Low Effort ✅**

| Optimization | Status | Impact |
|--------------|--------|--------|
| Memory Pooling | ✅ | 50-70% fewer allocations |
| Early Exit (budget gates) | ✅ | 20-50% faster when a token budget is set |
| Token Estimation Fast Path | ✅ | 2-3x faster for short strings |
| Benchmark Suite | ✅ | Performance tracking |

---

## Compression Modes & Intensity

Tune the speed/compression trade-off through options passed to `shrike.Compress`, or via the intensity argument to `shrike.PromptCompress`.

| Mode / Intensity | API | Layers | Use Case |
|------------------|-----|--------|----------|
| Lite | `shrike.PromptCompress(text, shrike.IntensityLite)` | few | Fastest, light touch |
| Full | `shrike.PromptCompress(text, shrike.IntensityFull)` | all | Balanced default |
| Ultra | `shrike.PromptCompress(text, shrike.IntensityUltra)` | all + aggressive | Maximum compression |
| Aggressive | `shrike.Compress(text, shrike.Aggressive)` | all | Strictest reduction |

```go
out, _ := shrike.Compress(input, shrike.Aggressive)

// Prompt-oriented helper with an intensity level:
out, _ := shrike.PromptCompress(input, shrike.IntensityFull)
```

Additional compression options:

```go
// Code-aware compression preserves structure for a given language.
out, _ := shrike.Compress(src, shrike.WithCodeAware("go"))

// Perplexity-guided pruning keeps the most informative tokens up to a ratio.
out, _ := shrike.Compress(text, shrike.WithPerplexityGuided(scorer, 0.6))

// Custom TOML filter rules (see "Custom Filters" below).
rules, _ := shrike.LoadFilterRules("rules/my-filters.toml")
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

---

## Custom Filters

Custom filter rules are **TOML files** loaded with `shrike.LoadFilterRules` and applied through the `shrike.WithCustomFilters` option. This is a first-class library feature — define your own redaction/compression rules and feed them into the pipeline:

```go
rules, err := shrike.LoadFilterRules("rules/custom.toml")
if err != nil {
    log.Fatal(err)
}
compressed, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

Profiles (presets of filter behavior) load via `shrike.LoadProfile`.

---

## Estimation, Cost & Tracking

```go
// Estimated cost for a given model.
cost := shrike.EstimateCost(text, "gpt-4o")

// Track usage over a context's lifetime.
tracker := shrike.NewTracker(ctx)
```

Other utilities: `shrike.SmartTruncate`, `shrike.ExtractJSON`, `shrike.NewSecretDetector()`, and `shrike.IsSensitiveFilename` for sensitive-path detection.

---

## Profiling

The library exposes profiling helpers in `profile.go`; you can also use the standard Go toolchain against the benchmark binaries.

```bash
# CPU + memory profiles from the pipeline benchmark
go test -bench=BenchmarkPipeline -cpuprofile=cpu.prof -memprofile=mem.prof
go tool pprof -http=:8080 cpu.prof
go tool pprof -http=:8080 mem.prof
```

A helper script wraps common profiling runs:

```bash
./scripts/profile.sh all        # Profile everything
./scripts/profile.sh cpu 30s    # CPU only
./scripts/profile.sh mem 10s    # Memory only
```

---

## Benchmarks

All benchmarks run through the Go toolchain. Two wrapper scripts are provided:

```bash
./benchmarks/run.sh             # core pipeline benchmarks (wraps `go test -bench`)
./evals/pipeline-bench.sh       # end-to-end pipeline eval benchmarks
```

You can also invoke `go test -bench` directly:

```bash
go test -bench=. -benchmem ./...
go test -bench=BenchmarkPipeline -benchmem
```

---

## Production Tuning

### Optimize for Speed

Use a lighter intensity and let budget gates short-circuit work:

```go
out, _ := shrike.PromptCompress(text, shrike.IntensityLite)
```

### Optimize for Memory

The pipeline uses pooled buffers and streams large inputs internally; prefer streaming-friendly chunk sizes and avoid holding many large inputs simultaneously.

### Optimize for Compression

Use the strongest settings when token budget matters most:

```go
out, _ := shrike.PromptCompress(text, shrike.IntensityUltra)
// or
out, _ := shrike.Compress(text, shrike.Aggressive)
```

---

## Production Checklist

- [ ] Run benchmarks: `./benchmarks/run.sh` (or `go test -bench=. ./...`)
- [ ] Profile hot paths: `./scripts/profile.sh all`
- [ ] Test with large inputs (>100KB) to confirm memory stays bounded
- [ ] Zero race conditions (verified with `go test -race ./...`)
- [ ] All existing tests pass: `go test ./...`

---

## Status: PRODUCTION READY ✅

- Speed: Excellent (11.6M-32M tokens/s)
- Memory: Efficient (4.8KB-336KB)
- Safety: Robust (thread-safe, nil-safe)
- Quality: Production-ready

**Performance Grade: A+**
