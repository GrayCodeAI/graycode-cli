package shrike

import (
	"fmt"
	"strings"
)

// formatNumber adds comma separators to integers for display.
// Used by both rate limiting summaries and optimizer output.
func formatNumber(n int) string {
	if n < 0 {
		return "-" + formatNumber(-n)
	}
	s := fmt.Sprintf("%d", n)
	if len(s) <= 3 {
		return s
	}

	var result strings.Builder
	remainder := len(s) % 3
	if remainder > 0 {
		result.WriteString(s[:remainder])
	}
	for i := remainder; i < len(s); i += 3 {
		if result.Len() > 0 {
			result.WriteByte(',')
		}
		result.WriteString(s[i : i+3])
	}
	return result.String()
}

// FormatStats returns a human-readable summary of compression statistics.
// If a model is specified, includes dollar-based cost savings.
func FormatStats(stats Stats) string {
	var b strings.Builder

	fmt.Fprintf(&b, "Tokens: %s → %s (%.1f%% reduction)\n",
		formatNumber(stats.OriginalTokens),
		formatNumber(stats.FinalTokens),
		stats.ReductionPercent)

	fmt.Fprintf(&b, "Saved: %s tokens", formatNumber(stats.TokensSaved))

	if stats.Model != "" {
		costStr := FormatCostSavings(stats, stats.Model)
		if costStr != "" {
			fmt.Fprintf(&b, " | %s", costStr)
		}
	}

	return b.String()
}
