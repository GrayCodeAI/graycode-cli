package shrike

import (
	"container/list"
	"sort"
	"sync"
	"time"
)

const (
	DefaultMaxBudget  = 50000
	DefaultBudgetPct  = 0.15
	PriorityWriteEdit = 100
	PrioritySkill     = 80
	PriorityRead      = 50

	// DefaultRetainedTokenBudget caps the total token cost of tracked
	// content held in memory between Clear() calls. 200_000 matches the
	// default context window: the tracker can never usefully re-inject more
	// than one context window of material, so retaining more is pure memory
	// waste (~800 KB of text). When the budget is exceeded the least
	// recently tracked entries are evicted first.
	DefaultRetainedTokenBudget = 200_000
)

// RestorationTracker tracks file operations for selective context re-injection
// after compaction. When a conversation is compacted, important context (recent
// writes, skill activations, file reads) can be lost. The tracker records these
// operations and, after compaction, selects the highest-priority items to
// re-inject within a token budget.
//
// Memory is bounded: deduplication is O(1) via a path-indexed map, and the
// total retained content is capped by the retained token budget (see
// DefaultRetainedTokenBudget and WithRetainedTokenBudget), evicting the least
// recently tracked entries when exceeded.
type RestorationTracker struct {
	mu             sync.Mutex
	entries        *list.List // *RestorationEntry, front = most recently tracked
	index          map[string]*list.Element
	totalTokens    int
	maxBudget      int
	budgetPct      float64
	contextWindow  int
	retainedBudget int
}

// RestorationEntry represents a tracked file operation.
type RestorationEntry struct {
	Path      string
	Content   string
	Tokens    int
	Priority  int    // writes/edits=100, skills=80, reads=50
	OpType    string // "write", "edit", "read", "skill"
	Timestamp time.Time
}

// NewRestorationTracker creates a tracker with default settings.
func NewRestorationTracker() *RestorationTracker {
	return &RestorationTracker{
		entries:        list.New(),
		index:          make(map[string]*list.Element),
		maxBudget:      DefaultMaxBudget,
		budgetPct:      DefaultBudgetPct,
		contextWindow:  200000, // default 200K tokens
		retainedBudget: DefaultRetainedTokenBudget,
	}
}

// WithMaxBudget sets the maximum token budget for restoration.
func (rt *RestorationTracker) WithMaxBudget(tokens int) *RestorationTracker {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	rt.maxBudget = tokens
	return rt
}

// WithBudgetPct sets the percentage of context window for restoration.
func (rt *RestorationTracker) WithBudgetPct(pct float64) *RestorationTracker {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	rt.budgetPct = pct
	return rt
}

// WithContextWindow sets the context window size in tokens.
func (rt *RestorationTracker) WithContextWindow(tokens int) *RestorationTracker {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	rt.contextWindow = tokens
	return rt
}

// WithRetainedTokenBudget caps the total tokens of content retained in memory.
// Once exceeded, the least recently tracked entries are evicted.
func (rt *RestorationTracker) WithRetainedTokenBudget(tokens int) *RestorationTracker {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	rt.retainedBudget = tokens
	rt.evictOverBudgetLocked()
	return rt
}

// Track records a file operation. Deduplicates by path in O(1) (latest wins,
// and the entry is refreshed as most recently tracked). When the retained
// token budget is exceeded, the least recently tracked entries are evicted;
// the entry just tracked is always kept, even if it alone exceeds the budget.
func (rt *RestorationTracker) Track(path, content, opType string) {
	rt.mu.Lock()
	defer rt.mu.Unlock()

	priority := PriorityRead
	switch opType {
	case "write", "edit":
		priority = PriorityWriteEdit
	case "skill":
		priority = PrioritySkill
	}

	entry := RestorationEntry{
		Path:      path,
		Content:   content,
		Tokens:    EstimateTokens(content),
		Priority:  priority,
		OpType:    opType,
		Timestamp: time.Now(),
	}

	// Deduplicate: replace existing entry for same path, refresh recency.
	if elem, ok := rt.index[path]; ok {
		if old, ok := elem.Value.(*RestorationEntry); ok {
			rt.totalTokens -= old.Tokens
		}
		elem.Value = &entry
		rt.entries.MoveToFront(elem)
	} else {
		rt.index[path] = rt.entries.PushFront(&entry)
	}
	rt.totalTokens += entry.Tokens

	rt.evictOverBudgetLocked()
}

// evictOverBudgetLocked drops least recently tracked entries until the total
// retained tokens fit the budget. Caller must hold rt.mu. The most recently
// tracked entry is always kept so a single over-budget Track is not a no-op.
func (rt *RestorationTracker) evictOverBudgetLocked() {
	for rt.totalTokens > rt.retainedBudget && rt.entries.Len() > 1 {
		back := rt.entries.Back()
		if back == nil {
			break
		}
		old, ok := back.Value.(*RestorationEntry)
		if !ok {
			rt.entries.Remove(back)
			continue
		}
		rt.totalTokens -= old.Tokens
		delete(rt.index, old.Path)
		rt.entries.Remove(back)
	}
}

// ComputeBudget calculates the available restoration budget.
// Formula: min(maxBudget, contextWindow * budgetPct, contextWindow - usedTokens - reserveTokens)
func (rt *RestorationTracker) ComputeBudget(usedTokens, reserveTokens int) int {
	rt.mu.Lock()
	defer rt.mu.Unlock()

	byMax := rt.maxBudget
	byPct := int(float64(rt.contextWindow) * rt.budgetPct)
	byRemaining := rt.contextWindow - usedTokens - reserveTokens

	budget := byMax
	if byPct < budget {
		budget = byPct
	}
	if byRemaining < budget {
		budget = byRemaining
	}
	if budget < 0 {
		return 0
	}
	return budget
}

// GetRestorations returns the highest-priority entries that fit within the given budget.
// Entries are sorted by priority (desc) then timestamp (desc, most recent first).
func (rt *RestorationTracker) GetRestorations(budget int) []RestorationEntry {
	rt.mu.Lock()
	defer rt.mu.Unlock()

	if rt.entries.Len() == 0 || budget <= 0 {
		return nil
	}

	sorted := make([]RestorationEntry, 0, rt.entries.Len())
	for e := rt.entries.Front(); e != nil; e = e.Next() {
		if entry, ok := e.Value.(*RestorationEntry); ok {
			sorted = append(sorted, *entry)
		}
	}
	sort.Slice(sorted, func(i, j int) bool {
		if sorted[i].Priority != sorted[j].Priority {
			return sorted[i].Priority > sorted[j].Priority
		}
		return sorted[i].Timestamp.After(sorted[j].Timestamp)
	})

	var result []RestorationEntry
	used := 0
	for _, entry := range sorted {
		if used+entry.Tokens > budget {
			continue
		}
		result = append(result, entry)
		used += entry.Tokens
	}
	return result
}

// Entries returns a snapshot of all tracked entries, most recently tracked
// first (for testing/debugging).
func (rt *RestorationTracker) Entries() []RestorationEntry {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	result := make([]RestorationEntry, 0, rt.entries.Len())
	for e := rt.entries.Front(); e != nil; e = e.Next() {
		if entry, ok := e.Value.(*RestorationEntry); ok {
			result = append(result, *entry)
		}
	}
	return result
}

// Clear removes all tracked entries.
func (rt *RestorationTracker) Clear() {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	rt.entries.Init()
	rt.index = make(map[string]*list.Element)
	rt.totalTokens = 0
}

// Len returns the number of tracked entries.
func (rt *RestorationTracker) Len() int {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	return rt.entries.Len()
}
