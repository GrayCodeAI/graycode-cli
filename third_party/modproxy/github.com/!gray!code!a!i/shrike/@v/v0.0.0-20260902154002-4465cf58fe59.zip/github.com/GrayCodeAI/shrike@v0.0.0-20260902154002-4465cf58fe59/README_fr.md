# shrike

[![Go](https://img.shields.io/badge/Go-1.22+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> **shrike** est une **bibliothèque Go** pour la compression de prompts, le filtrage de sorties, l'estimation de tokens et la détection de secrets, destinée aux agents de codage IA.

## Installation

```bash
go get github.com/GrayCodeAI/shrike
```

## Documentation

Consultez le [README en anglais](README.md) pour la documentation complète.

## Sous-commandes `shrike`

shrike ne fournit pas de binaire CLI autonome. Les sous-commandes `shrike` sont exposées via [Hawk](https://github.com/GrayCodeAI/hawk) (`hawk shrike ...`), qui intègre cette bibliothèque.

## Licence

[MIT](LICENSE)
