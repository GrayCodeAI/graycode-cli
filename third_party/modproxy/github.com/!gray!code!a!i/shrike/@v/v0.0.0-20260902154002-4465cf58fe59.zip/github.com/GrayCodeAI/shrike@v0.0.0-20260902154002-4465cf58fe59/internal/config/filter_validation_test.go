package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestValidateFilterFile_Valid(t *testing.T) {
	dir := t.TempDir()
	content := `schema_version = 1

[filter]
match_command = "jest|npm.*test"
strip_ansi = true
strip_lines_matching = ["^PASS\\s+", "^\\s*$"]
keep_lines_matching = ["FAIL\\s+.*", "Error:.*"]
max_lines = 100
`
	path := filepath.Join(dir, "test.toml")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}

	errors := ValidateFilterFile(path)
	if len(errors) != 0 {
		for _, e := range errors {
			t.Errorf("unexpected error: %v", e)
		}
	}
}

func TestValidateFilterFile_MissingSchemaVersion(t *testing.T) {
	dir := t.TempDir()
	content := `[filter]
match_command = "jest"
`
	path := filepath.Join(dir, "test.toml")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}

	errors := ValidateFilterFile(path)
	found := false
	for _, e := range errors {
		if e.Field == "schema_version" {
			found = true
		}
	}
	if !found {
		t.Error("expected error for missing schema_version")
	}
}

func TestValidateFilterFile_MissingMatchCommand(t *testing.T) {
	dir := t.TempDir()
	content := `schema_version = 1

[filter]
strip_ansi = true
`
	path := filepath.Join(dir, "test.toml")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}

	errors := ValidateFilterFile(path)
	found := false
	for _, e := range errors {
		if e.Field == "match_command" {
			found = true
		}
	}
	if !found {
		t.Error("expected error for missing match_command")
	}
}

func TestValidateFilterFile_InvalidTOML(t *testing.T) {
	dir := t.TempDir()
	content := `this is not valid toml [[[`
	path := filepath.Join(dir, "test.toml")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}

	errors := ValidateFilterFile(path)
	if len(errors) == 0 {
		t.Error("expected error for invalid TOML")
	}
}

func TestValidateFilterFile_InvalidMaxLines(t *testing.T) {
	dir := t.TempDir()
	content := `schema_version = 1

[filter]
match_command = "jest"
max_lines = -1
`
	path := filepath.Join(dir, "test.toml")
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}

	errors := ValidateFilterFile(path)
	found := false
	for _, e := range errors {
		if e.Field == "max_lines" {
			found = true
		}
	}
	if !found {
		t.Error("expected error for negative max_lines")
	}
}

func TestValidateAllFilters(t *testing.T) {
	dir := t.TempDir()

	// Valid file
	validContent := `schema_version = 1

[filter]
match_command = "jest"
`
	if err := os.WriteFile(filepath.Join(dir, "valid.toml"), []byte(validContent), 0o644); err != nil {
		t.Fatal(err)
	}

	// Invalid file
	invalidContent := `[filter]
match_command = "jest"
`
	if err := os.WriteFile(filepath.Join(dir, "invalid.toml"), []byte(invalidContent), 0o644); err != nil {
		t.Fatal(err)
	}

	// Non-TOML file (should be ignored)
	if err := os.WriteFile(filepath.Join(dir, "readme.txt"), []byte("hello"), 0o644); err != nil {
		t.Fatal(err)
	}

	errors, err := ValidateAllFilters(dir)
	if err != nil {
		t.Fatal(err)
	}

	if len(errors) == 0 {
		t.Error("expected validation errors for invalid.toml")
	}

	// Check that errors are only from invalid.toml
	for _, e := range errors {
		if e.File != "invalid.toml" {
			t.Errorf("unexpected error from file %s: %v", e.File, e)
		}
	}
}
