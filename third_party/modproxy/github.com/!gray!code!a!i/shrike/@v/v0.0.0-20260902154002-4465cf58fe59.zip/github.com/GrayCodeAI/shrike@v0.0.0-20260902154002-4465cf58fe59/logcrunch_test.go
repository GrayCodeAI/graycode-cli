package shrike_test

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestCompressLog_PreservesErrors(t *testing.T) {
	input := "2024-01-01 ERROR something broke\n2024-01-01 WARN disk full\n2024-01-01 FATAL crash"
	out := shrike.CompressLog(input)
	for _, kw := range []string{"ERROR", "WARN", "FATAL"} {
		if !strings.Contains(out, kw) {
			t.Errorf("expected %s line preserved", kw)
		}
	}
}

func TestCompressLog_CollapsesInfoRuns(t *testing.T) {
	var lines []string
	for i := 0; i < 10; i++ {
		lines = append(lines, "2024-01-01 INFO processing item")
	}
	input := strings.Join(lines, "\n")
	out := shrike.CompressLog(input)
	if !strings.Contains(out, "similar lines collapsed") {
		t.Fatal("expected collapsed summary")
	}
	if strings.Count(out, "INFO") != 2 {
		t.Errorf("expected first and last INFO lines kept, got %d", strings.Count(out, "INFO"))
	}
}

func TestCompressLog_NoLogs(t *testing.T) {
	input := "just some plain text\nno log lines here"
	out := shrike.CompressLog(input)
	if out != input {
		t.Errorf("expected unchanged output for non-log text")
	}
}
