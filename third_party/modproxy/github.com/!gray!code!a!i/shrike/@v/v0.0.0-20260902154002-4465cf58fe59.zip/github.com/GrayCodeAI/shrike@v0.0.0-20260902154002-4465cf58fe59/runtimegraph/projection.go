// Package runtimegraph projects Shrike compression, usage, budget, and redaction
// summaries into the portable hawk-eco graph contract.
package runtimegraph

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	graphcontracts "github.com/GrayCodeAI/shrike/graph"
	"github.com/GrayCodeAI/shrike"
)

const SchemaVersion = "shrike.graph/v1"

type BudgetDecision struct {
	Allowed      bool
	Reason       string
	HourlyLimit  int
	DailyLimit   int
	SessionLimit int
	CostLimitUSD float64
}

type RedactionSummary struct {
	MatchCount    int
	VerifiedCount int
	Types         map[string]int
}

type Input struct {
	Compression     *shrike.Stats
	Usage           *shrike.UsageSummary
	Budget          *BudgetDecision
	Redaction       *RedactionSummary
	Source          string
	ObservedAt      time.Time
	Scope           graphcontracts.Scope
	CorrelationID   string
	ProducerVersion string
}

type Export struct {
	SchemaVersion string                 `json:"schema_version"`
	GeneratedAt   time.Time              `json:"generated_at"`
	Scope         graphcontracts.Scope   `json:"scope,omitempty"`
	Nodes         []graphcontracts.Node  `json:"nodes"`
	Edges         []graphcontracts.Edge  `json:"edges"`
	Events        []graphcontracts.Event `json:"events"`
}

func Build(input Input) (*Export, error) {
	if input.Compression == nil && input.Usage == nil && input.Budget == nil && input.Redaction == nil {
		return nil, errors.New("runtimegraph: at least one summary is required")
	}
	at := input.ObservedAt.UTC()
	if at.IsZero() {
		at = time.Now().UTC()
	}
	sourceDigest := digest(input.Source)
	export := &Export{
		SchemaVersion: SchemaVersion, GeneratedAt: at, Scope: input.Scope,
		Nodes: []graphcontracts.Node{}, Edges: []graphcontracts.Edge{}, Events: []graphcontracts.Event{},
	}
	var usageRef graphcontracts.Ref
	if input.Compression != nil {
		attrs := map[string]string{
			"entity": "compression", "source_digest": sourceDigest,
			"original_tokens":   strconv.Itoa(input.Compression.OriginalTokens),
			"final_tokens":      strconv.Itoa(input.Compression.FinalTokens),
			"tokens_saved":      strconv.Itoa(input.Compression.TokensSaved),
			"reduction_percent": formatFloat(input.Compression.ReductionPercent),
			"cost_savings_usd":  formatFloat(input.Compression.CostSavings),
			"model_digest":      digest(input.Compression.Model),
			"layer_count":       strconv.Itoa(len(input.Compression.Layers)),
		}
		if _, err := addNode(export, graphcontracts.NodeOperations, "compression", attrs, input, at, sourceDigest); err != nil {
			return nil, err
		}
	}
	if input.Usage != nil {
		attrs := map[string]string{
			"entity": "usage", "hourly_tokens": strconv.Itoa(input.Usage.HourlyTokens),
			"hourly_remaining":   strconv.Itoa(input.Usage.HourlyRemaining),
			"daily_tokens":       strconv.Itoa(input.Usage.DailyTokens),
			"daily_remaining":    strconv.Itoa(input.Usage.DailyRemaining),
			"session_tokens":     strconv.Itoa(input.Usage.SessionTokens),
			"session_remaining":  strconv.Itoa(input.Usage.SessionRemaining),
			"daily_cost_usd":     formatFloat(input.Usage.DailyCostUSD),
			"cost_remaining_usd": formatFloat(input.Usage.CostRemaining),
			"hourly_percent":     formatFloat(input.Usage.HourlyPct),
			"daily_percent":      formatFloat(input.Usage.DailyPct),
		}
		ref, err := addNode(export, graphcontracts.NodeOperations, "usage", attrs, input, at, sourceDigest)
		if err != nil {
			return nil, err
		}
		usageRef = ref
	}
	if input.Budget != nil {
		attrs := map[string]string{
			"entity": "budget_decision", "allowed": strconv.FormatBool(input.Budget.Allowed),
			"reason_digest":  digest(input.Budget.Reason),
			"hourly_limit":   strconv.Itoa(input.Budget.HourlyLimit),
			"daily_limit":    strconv.Itoa(input.Budget.DailyLimit),
			"session_limit":  strconv.Itoa(input.Budget.SessionLimit),
			"cost_limit_usd": formatFloat(input.Budget.CostLimitUSD),
		}
		ref, err := addNode(export, graphcontracts.NodePolicy, "budget", attrs, input, at, sourceDigest)
		if err != nil {
			return nil, err
		}
		if usageRef.ID != "" {
			if err := addEdge(export, ref, usageRef, graphcontracts.EdgeDependsOn, input, at); err != nil {
				return nil, err
			}
		}
	}
	if input.Redaction != nil {
		typeNames := make([]string, 0, len(input.Redaction.Types))
		for name := range input.Redaction.Types {
			typeNames = append(typeNames, name)
		}
		sort.Strings(typeNames)
		attrs := map[string]string{
			"entity": "redaction", "source_digest": sourceDigest,
			"match_count":    strconv.Itoa(max(input.Redaction.MatchCount, 0)),
			"verified_count": strconv.Itoa(max(input.Redaction.VerifiedCount, 0)),
			"type_count":     strconv.Itoa(len(typeNames)),
			"types_digest":   digest(strings.Join(typeNames, "\x00")),
		}
		if _, err := addNode(export, graphcontracts.NodeQuality, "redaction", attrs, input, at, sourceDigest); err != nil {
			return nil, err
		}
	}
	sort.Slice(export.Nodes, func(i, j int) bool { return export.Nodes[i].ID < export.Nodes[j].ID })
	sort.Slice(export.Edges, func(i, j int) bool { return export.Edges[i].ID < export.Edges[j].ID })
	sort.Slice(export.Events, func(i, j int) bool { return export.Events[i].ID < export.Events[j].ID })
	return export, nil
}

func addNode(export *Export, kind graphcontracts.NodeKind, entity string, attrs map[string]string, input Input, at time.Time, sourceDigest string) (graphcontracts.Ref, error) {
	id := "shrike/" + entity + "/" + digest(sourceDigest, at.Format(time.RFC3339Nano))
	ref := graphcontracts.Ref{Kind: kind, ID: id}
	provenance := graphcontracts.Provenance{
		Producer: "shrike", Version: strings.TrimSpace(input.ProducerVersion), SourceID: sourceDigest,
		Evidence: []graphcontracts.ArtifactRef{{URI: "shrike://" + entity + "/" + digest(sourceDigest)}},
	}
	node := graphcontracts.Node{ID: id, Kind: kind, Scope: input.Scope, CreatedAt: at, Provenance: provenance, Attributes: attrs}
	if err := node.Validate(); err != nil {
		return graphcontracts.Ref{}, fmt.Errorf("runtimegraph: %s node: %w", entity, err)
	}
	event := graphcontracts.Event{
		ID: "shrike/observed/" + digest(id, at.Format(time.RFC3339Nano)), Type: graphcontracts.EventObserved,
		Subject: ref, Scope: input.Scope, OccurredAt: at, CorrelationID: strings.TrimSpace(input.CorrelationID),
		IdempotencyKey: digest(id, at.Format(time.RFC3339Nano)), Provenance: provenance,
	}
	export.Nodes = append(export.Nodes, node)
	export.Events = append(export.Events, event)
	return ref, nil
}

func addEdge(export *Export, from, to graphcontracts.Ref, kind graphcontracts.EdgeKind, input Input, at time.Time) error {
	edge := graphcontracts.Edge{
		ID: "shrike/edge/" + digest(from.ID, to.ID, string(kind)), Kind: kind, From: from, To: to,
		Scope: input.Scope, CreatedAt: at,
		Provenance: graphcontracts.Provenance{Producer: "shrike", Version: strings.TrimSpace(input.ProducerVersion), SourceID: digest(input.Source)},
	}
	if err := edge.Validate(); err != nil {
		return fmt.Errorf("runtimegraph: edge: %w", err)
	}
	export.Edges = append(export.Edges, edge)
	return nil
}

func formatFloat(value float64) string { return strconv.FormatFloat(value, 'f', -1, 64) }

func digest(parts ...string) string {
	hash := sha256.New()
	for _, part := range parts {
		_, _ = hash.Write([]byte(strconv.Itoa(len(part))))
		_, _ = hash.Write([]byte{':'})
		_, _ = hash.Write([]byte(part))
	}
	return hex.EncodeToString(hash.Sum(nil))
}
