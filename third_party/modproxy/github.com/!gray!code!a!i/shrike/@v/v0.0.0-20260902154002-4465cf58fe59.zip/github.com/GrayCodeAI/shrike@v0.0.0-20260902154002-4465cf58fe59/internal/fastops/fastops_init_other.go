//go:build !amd64

package fastops

func init() {
	// No AVX2 available — avx2HasANSI and avx2CountBytes remain nil.
}
