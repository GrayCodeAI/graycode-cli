# Shrike Quick Start Guide

**Get started in under 30 seconds**

Shrike is a Go **library** (`github.com/GrayCodeAI/shrike`) for token-aware text
compression, estimation, and redaction. There is no standalone `shrike` CLI — the
`shrike ...` verbs you may remember are exposed through
[Hawk](https://github.com/GrayCodeAI/hawk) (`hawk shrike compress`, …), which embeds
this library.

## Install

```bash
go get github.com/GrayCodeAI/shrike
```

```go
import "github.com/GrayCodeAI/shrike"
```

## Compress in One Call

```go
out, _ := shrike.Compress(text)
```

`Compress` uses an adaptive system that selects the right compression depth based
on content size and type:

| Tier | Layers | When | Speed |
|------|--------|------|-------|
| 0 (Trivial) | 0 | Empty content | Instant |
| 1 (Simple) | 3 | <50 tokens, simple commands | <0.5ms |
| 2 (Medium) | 8 | Git diffs, tests, builds | <2ms |
| 3 (Full) | 20 | Large output, code, logs | <15ms |

You don't need to configure anything — Shrike auto-detects content size and type.

## Options (Optional)

If you want explicit control, pass options to `Compress`:

```go
// Aggressive mode: deepest available compression path
out, _ := shrike.Compress(text, shrike.Aggressive)

// Code-aware compression: preserve structure for a given language
out, _ := shrike.Compress(src, shrike.WithCodeAware("go"))

// Perplexity-guided pruning at a target retention ratio
out, _ := shrike.Compress(text, shrike.WithPerplexityGuided(scorer, 0.5))

// Custom TOML filter rules (see "Custom Filters" below)
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

For prompt-style input there is a dedicated entry point with intensity levels:

```go
out, _ := shrike.PromptCompress(prompt, shrike.IntensityLite)
out, _ = shrike.PromptCompress(prompt, shrike.IntensityFull)
out, _ = shrike.PromptCompress(prompt, shrike.IntensityUltra)
```

## Token & Cost Estimation

```go
cost := shrike.EstimateCost(text, "gpt-4o")
```

## Redaction & Extraction Helpers

```go
det := shrike.NewSecretDetector()
findings := det.Detect(text)

if shrike.IsSensitiveFilename("id_rsa") { /* skip or redact */ }

truncated := shrike.SmartTruncate(text, maxTokens)
jsonText, ok := shrike.ExtractJSON(text)
```

## Tracking

```go
tracker := shrike.NewTracker(ctx)
// record compression events / token savings over time
```

## Custom Filters

Custom filters are TOML files loaded via `shrike.LoadFilterRules`, then applied with
`shrike.WithCustomFilters`:

```go
rules, err := shrike.LoadFilterRules("filters.toml")
if err != nil {
    // handle error
}
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

You can also load a named profile:

```go
profile, err := shrike.LoadProfile("balanced")
```

## How It Works

The full pipeline runs up to 20 compression layers, drawn from research across
120+ papers:

- **Entropy filtering** — Remove low-information tokens
- **Perplexity pruning** — Iterative token removal (Microsoft LLMLingua)
- **AST preservation** — Keep code structure intact
- **H2O filter** — Heavy-hitter detection (NeurIPS 2023)
- **And 16 more...**

Typical end result: 60–90% fewer tokens on verbose output such as diffs, logs,
and build output.

## Benchmarks

Benchmarks run via Go and wrap `go test -bench`:

```bash
./benchmarks/run.sh
./evals/pipeline-bench.sh
```

## Using the `shrike` CLI Verbs (via Hawk)

The compression/estimation verbs are available through Hawk, which embeds this
library:

```bash
hawk shrike compress < input.txt
```

See [github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk) for the CLI.

## Need Help?

- [Documentation](./docs/) — Full docs
- [GitHub Issues](https://github.com/GrayCodeAI/shrike/issues) — Bug reports
