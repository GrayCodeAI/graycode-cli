package shrike

import (
	_ "embed"
	"strings"
)

// versionFile is the canonical version, embedded at compile time from the
// VERSION file at the repo root — the single source of truth used by
// release tooling (release-please, goreleaser), CI, and the runtime
// Version variable.
//
//go:embed VERSION
var versionFile string

// Version of the shrike library. Sourced from the VERSION file at the repo
// root. Release builds may override it via ldflags:
//
//	-X github.com/GrayCodeAI/shrike.Version={{.Version}}
//
// Do not edit this variable directly — bump the VERSION file instead, or
// let release-please/goreleaser do it.
var Version = strings.TrimSpace(versionFile)
