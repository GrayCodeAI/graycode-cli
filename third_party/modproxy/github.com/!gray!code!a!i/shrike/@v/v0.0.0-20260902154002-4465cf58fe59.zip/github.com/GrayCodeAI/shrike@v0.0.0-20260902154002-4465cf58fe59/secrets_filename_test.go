package shrike_test

import (
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestIsSensitiveFilename_TopLevel(t *testing.T) {
	tests := []struct {
		name string
		path string
		want bool
	}{
		{".env", ".env", true},
		{"id_rsa", "id_rsa", true},
		{"credentials.json", "credentials.json", true},
		{".ssh", "/home/user/.ssh/random.txt", true},
		{"main.go", "main.go", false},
		{"README.md", "README.md", false},
		{"empty", "", false},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			ok, _ := shrike.IsSensitiveFilename(tc.path)
			if ok != tc.want {
				t.Errorf("IsSensitiveFilename(%q) = %v, want %v", tc.path, ok, tc.want)
			}
		})
	}
}

func TestIsSensitiveBasename_TopLevel(t *testing.T) {
	if !shrike.IsSensitiveBasename(".env") {
		t.Error("expected .env to be sensitive")
	}
	if shrike.IsSensitiveBasename("main.go") {
		t.Error("expected main.go to NOT be sensitive")
	}
}
