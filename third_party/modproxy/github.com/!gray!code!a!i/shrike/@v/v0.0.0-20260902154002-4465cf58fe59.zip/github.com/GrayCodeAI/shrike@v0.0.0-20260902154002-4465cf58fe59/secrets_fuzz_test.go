package shrike_test

import (
	"regexp"
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

// redactionMarkerPattern matches the "[REDACTED:<type>]" markers RedactSecrets
// substitutes in place of detected secrets.
var redactionMarkerPattern = regexp.MustCompile(`\[REDACTED:[^\]]*\]`)

// stripRedactionMarkers removes "[REDACTED:<type>]" markers from s. Used to
// check for leaked secret values outside of the markers themselves, since a
// short captured value can coincidentally be a substring of a fixed type
// label (e.g. "Bearer Token") without that being an actual leak.
func stripRedactionMarkers(s string) string {
	return redactionMarkerPattern.ReplaceAllString(s, "")
}

// FuzzRedactSecrets exercises the secrets redactor with arbitrary input.
//
// It asserts the security-relevant invariants that hold for the current
// redactor implementation:
//
//  1. No panic — the redactor (and the underlying detector) must tolerate
//     any byte sequence, including invalid UTF-8, unbalanced delimiters,
//     and pathological key-like fragments.
//  2. Redaction reduces exposure — when a secret is detected, the redacted
//     output is not byte-identical to the input, carries a [REDACTED:...]
//     marker, and contains strictly fewer verbatim occurrences of each
//     detected value than the input did. (A plain check for total absence
//     would false-positive when the same byte sequence also appears as
//     non-secret text elsewhere in the input.)
//  3. Idempotence on a clean fixed point — redacting an input that contains
//     no detectable secret returns that input unchanged.
//  4. Position validity — reported match offsets stay within bounds.
//
// Note: full string-level idempotence (Redact(Redact(x)) == Redact(x)) does
// NOT hold for this implementation, because a substituted marker such as
// "password = [REDACTED:Generic Password]" can itself re-match a generic
// "password = <value>" pattern on a second pass. That is a property of the
// production redactor, not of this test; the invariants above are the ones
// that are both meaningful and actually guaranteed.
func FuzzRedactSecrets(f *testing.F) {
	seeds := []string{
		"",
		"hello world",
		"AKIAIOSFODNN7EXAMPLE",
		"github token ghp_0123456789abcdefghijklmnopqrstuvwxyz",
		"password = hunter2hunter2",
		"sk-ant-0123456789abcdefghijklmno secret",
		"-----BEGIN RSA PRIVATE KEY-----\nMIIabc\n-----END RSA PRIVATE KEY-----",
		"api_key: 'abcdefghijklmnopqrstuvwxyz'",
		"bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.sig",
		"\x00\xff\xfe invalid utf8 \xc3\x28",
		"[REDACTED:OpenAI API Key]",
	}
	for _, s := range seeds {
		f.Add(s)
	}

	det := shrike.NewSecretDetector()

	f.Fuzz(func(t *testing.T, input string) {
		// Invariant 1: never panics.
		matches := det.DetectSecrets(input)
		out := det.RedactSecrets(input)

		// Invariant 4: reported positions stay within bounds.
		for _, m := range matches {
			if m.StartPos < 0 || m.EndPos > len(input) || m.StartPos > m.EndPos {
				t.Fatalf("match position out of range: %+v (len=%d) input=%q", m, len(input), input)
			}
		}

		// Invariant 2: redaction reduces exposure.
		if len(matches) > 0 {
			if out == input {
				t.Fatalf("redactor returned input unchanged despite %d match(es)\ninput: %q", len(matches), input)
			}
			if !strings.Contains(out, "[REDACTED:") {
				t.Fatalf("redacted output carries no [REDACTED:] marker\ninput: %q\nout:   %q", input, out)
			}
			outsideMarkers := stripRedactionMarkers(out)
			for _, m := range matches {
				if len(m.Value) < 4 {
					continue
				}
				// Count occurrences outside of "[REDACTED:<type>]" markers only:
				// a short captured value can coincidentally be a substring of a
				// *type label* (e.g. captured value "eare" is a substring of the
				// fixed marker text "[REDACTED:Bearer Token]"), which is a
				// spurious match against our own marker text, not a leak of the
				// original secret.
				if after, before := strings.Count(outsideMarkers, m.Value), strings.Count(input, m.Value); after >= before {
					t.Fatalf("detected secret value not reduced by redaction (before=%d after=%d)\ntype:  %s\nvalue: %q\ninput: %q\nout:   %q",
						before, after, m.Type, m.Value, input, out)
				}
			}
		}

		// Invariant 3: idempotent on a clean fixed point — redacting an input
		// with no detectable secret must leave it unchanged.
		if len(matches) == 0 && out != input {
			t.Fatalf("redactor altered secret-free input\ninput: %q\nout:   %q", input, out)
		}
	})
}
