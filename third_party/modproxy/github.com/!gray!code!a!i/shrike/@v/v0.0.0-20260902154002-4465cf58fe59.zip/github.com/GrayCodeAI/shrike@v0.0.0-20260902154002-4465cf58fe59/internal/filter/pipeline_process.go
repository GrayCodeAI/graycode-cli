package filter

import (
	"github.com/GrayCodeAI/shrike/internal/core"
)

// Process runs the six-layer compression pipeline.
//
// Layers run in order; each exits early if the token budget is already met.
// The quality guardrail runs after all six layers and may trigger a fallback
// to ModeMinimal if the output fails semantic validation.
func (p *PipelineCoordinator) Process(input string) (string, *PipelineStats) {
	if p == nil {
		return input, &PipelineStats{
			OriginalTokens: core.EstimateTokens(input),
			FinalTokens:    core.EstimateTokens(input),
			LayerStats:     make(map[string]LayerStat, 6),
		}
	}

	stats := &PipelineStats{
		OriginalTokens: core.EstimateTokens(input),
		LayerStats:     make(map[string]LayerStat, 6),
	}

	output := input

	type layerRun struct {
		name string
		fn   func(string, *PipelineStats) string
	}

	// Run layers 1-5 with early exit. Budget enforcement (layer 6) runs after
	// the loop to ensure it is never skipped by shouldEarlyExit.
	for _, l := range [5]layerRun{
		{"preprocess", p.runLayer1Preprocess},
		{"structural", p.runLayer2Structural},
		{"semantic", p.runLayer3Semantic},
		{"llm_specific", p.runLayer4LLMSpecific},
		{"content_type", p.runLayer5ContentType},
	} {
		output = l.fn(output, stats)
		if p.shouldEarlyExit(stats) {
			break
		}
	}

	// Always run budget enforcement — it must not be skipped by early exit.
	output = p.runLayer6BudgetQuality(output, stats)

	// KV-size post-compensation (applied after budget so it doesn't inflate token count)
	if p.smallKVCompensator != nil {
		output = p.smallKVCompensator.Compensate(input, output, p.config.Mode)
	}

	// Quality feedback loop — informs adaptive learning for future runs
	p.recordFeedback(input, output, stats)

	// Quality guardrail — falls back to ModeMinimal if output fails semantic validation
	if p.qualityGuardrail != nil {
		gr := p.qualityGuardrail.Validate(input, output)
		if !gr.Passed {
			safeOutput, safeStats := p.runGuardrailFallback(input)
			safeStats.AddLayerStatSafe(LayerGuardrailFallback, LayerStat{TokensSaved: 0})
			safeStats.AddLayerStatSafe("guardrail_reason_"+gr.Reason, LayerStat{TokensSaved: 0})
			return safeOutput, safeStats
		}
	}

	// Final budget enforcement: ensure output respects the budget after all
	// post-processing steps (smallKVCompensator, guardrail, etc.).
	if p.budgetEnforcer != nil && p.config.Budget > 0 {
		finalTokens := core.EstimateTokens(output)
		if finalTokens > p.config.Budget {
			before := finalTokens
			output = p.budgetEnforcer.TruncateToBudget(output, p.config.Budget)
			// Record the budget layer so Stats.HardTruncated() can tell a
			// hard cut-off from structural compression.
			saved := before - core.EstimateTokens(output)
			if saved > 0 {
				stats.AddLayerStatSafe(LayerBudget, LayerStat{TokensSaved: saved})
			}
		}
	}

	return output, p.finalizeStats(stats, output)
}

func (p *PipelineCoordinator) runGuardrailFallback(input string) (string, *PipelineStats) {
	// Build a minimal fallback config to avoid copying the full 100+ field struct
	fallbackCfg := &PipelineConfig{
		Mode:                   ModeMinimal,
		EnableQualityGuardrail: false, // prevent infinite recursion
		QueryIntent:            p.config.QueryIntent,
		Budget:                 p.config.Budget,
		LLMEnabled:             p.config.LLMEnabled,
		SessionTracking:        p.config.SessionTracking,
		NgramEnabled:           p.config.NgramEnabled,
		MultiFileEnabled:       p.config.MultiFileEnabled,
		EnableEntropy:          p.config.EnableEntropy,
		EnablePerplexity:       p.config.EnablePerplexity,
		EnableAST:              p.config.EnableAST,
		EnableGist:             p.config.EnableGist,
		EnableHierarchical:     p.config.EnableHierarchical,
		EnableCompaction:       p.config.EnableCompaction,
		EnableAttribution:      p.config.EnableAttribution,
		EnableH2O:              p.config.EnableH2O,
		EnableAttentionSink:    p.config.EnableAttentionSink,
		EnableTOMLFilter:       p.config.EnableTOMLFilter,
		CacheEnabled:           p.config.CacheEnabled,
		CacheMaxSize:           p.config.CacheMaxSize,
	}
	fallback := NewPipelineCoordinator(fallbackCfg)
	return fallback.Process(input)
}

func (p *PipelineCoordinator) recordFeedback(input, output string, stats *PipelineStats) {
	if p.feedback != nil && p.qualityEstimator != nil {
		quality := p.qualityEstimator.EstimateQuality(input, output)
		p.feedback.RecordSignal(FeedbackSignal{
			LayerName:           "pipeline",
			QualityScore:        quality,
			CompressionRatio:    stats.ReductionPercent / 100.0,
			SuggestedAdjustment: (quality - 0.8) * 0.5,
		})
	}
}
