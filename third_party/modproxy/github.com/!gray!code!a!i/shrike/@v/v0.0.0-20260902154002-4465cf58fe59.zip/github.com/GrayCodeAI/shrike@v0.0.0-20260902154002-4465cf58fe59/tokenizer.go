package shrike

import "strings"

// Encoding represents a BPE encoding scheme.
type Encoding string

const (
	// Cl100kBase is used by GPT-4, GPT-3.5-turbo, and text-embedding-ada-002.
	Cl100kBase Encoding = "cl100k_base"
	// O200kBase is used by GPT-4o, GPT-4.1, o1, o3, o4-mini.
	O200kBase Encoding = "o200k_base"
	// ClaudeBase is an approximation only: Anthropic publishes no offline
	// BPE tokenizer, so counts using this encoding are OpenAI's cl100k_base
	// token boundaries, not Claude's real tokenizer, and will diverge from
	// the real count. For an exact count, use CountTokensExact, which calls
	// Anthropic's /v1/messages/count_tokens API (requires an API key).
	ClaudeBase Encoding = "cl100k_base"
	// GeminiBase is an approximation only: Google publishes no offline BPE
	// tokenizer for Gemini, so counts using this encoding are OpenAI's
	// cl100k_base token boundaries, not Gemini's real tokenizer, and will
	// diverge from the real count. For an exact count, use
	// CountTokensExact, which calls Google's countTokens API (requires an
	// API key).
	GeminiBase Encoding = "cl100k_base"
	// R50kBase is used by older GPT-3 models.
	R50kBase Encoding = "r50k_base"
	// P50kBase is used by code-davinci and text-davinci-002/003.
	P50kBase Encoding = "p50k_base"
)

// ModelToEncoding maps model name prefixes to their BPE encoding.
// Longer prefixes should come first for correct matching.
var ModelToEncoding = map[string]Encoding{
	// OpenAI - o-series
	"o1-":         O200kBase,
	"o1":          O200kBase,
	"o3-":         O200kBase,
	"o3":          O200kBase,
	"o4-":         O200kBase,
	"o4":          O200kBase,
	"chatgpt-4o-": O200kBase,
	// OpenAI - GPT-4.1 series
	"gpt-4.1-": O200kBase,
	"gpt-4.1":  O200kBase,
	// OpenAI - GPT-4o series
	"gpt-4o-": O200kBase,
	"gpt-4o":  O200kBase,
	// OpenAI - GPT-4 series
	"gpt-4-": Cl100kBase,
	"gpt-4":  Cl100kBase,
	// OpenAI - GPT-3.5 series
	"gpt-3.5-turbo-": Cl100kBase,
	"gpt-3.5-turbo":  Cl100kBase,
	"gpt-35-turbo-":  Cl100kBase,
	"gpt-35-turbo":   Cl100kBase,
	// OpenAI - fine-tuned
	"ft:gpt-4":         Cl100kBase,
	"ft:gpt-3.5-turbo": Cl100kBase,
	"ft:davinci-002":   Cl100kBase,
	"ft:babbage-002":   Cl100kBase,
	// Anthropic - Claude models
	"claude-4-":   ClaudeBase,
	"claude-4":    ClaudeBase,
	"claude-3.5-": ClaudeBase,
	"claude-3.5":  ClaudeBase,
	"claude-3-":   ClaudeBase,
	"claude-3":    ClaudeBase,
	"claude-":     ClaudeBase,
	"claude":      ClaudeBase,
	// Google - Gemini models
	"gemini-2.5-": GeminiBase,
	"gemini-2.5":  GeminiBase,
	"gemini-2.0-": GeminiBase,
	"gemini-2.0":  GeminiBase,
	"gemini-1.5-": GeminiBase,
	"gemini-1.5":  GeminiBase,
	"gemini-":     GeminiBase,
	"gemini":      GeminiBase,
}

// GetEncodingForModel returns the BPE encoding for the given model name.
// If the model is not recognized, it falls back to Cl100kBase.
func GetEncodingForModel(model string) Encoding {
	model = strings.ToLower(strings.TrimSpace(model))

	// Try exact match first
	if enc, ok := ModelToEncoding[model]; ok {
		return enc
	}

	// Try prefix match, longer prefixes first
	bestPrefix := ""
	bestEnc := Cl100kBase
	for prefix, enc := range ModelToEncoding {
		if strings.HasPrefix(model, prefix) && len(prefix) > len(bestPrefix) {
			bestPrefix = prefix
			bestEnc = enc
		}
	}

	return bestEnc
}

// WithModelEncoding sets a specific BPE encoding for tokenization.
// Use this when you need direct control over the encoding, bypassing model detection.
func WithModelEncoding(encoding Encoding) Option {
	return optFunc(func(c *config) {
		c.encoding = string(encoding)
	})
}
