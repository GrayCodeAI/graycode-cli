package shrike

import (
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
)

// CodeChunk represents a semantically meaningful chunk of source code.
type CodeChunk struct {
	Content   string `json:"content"`
	StartLine int    `json:"start_line"`
	EndLine   int    `json:"end_line"`
	Symbol    string `json:"symbol,omitempty"`
	Tokens    int    `json:"tokens"`
}

// SeparatorKeep controls what happens to boundary separators during splitting.
type SeparatorKeep int

const (
	SepLeft    SeparatorKeep = iota // separator stays with preceding chunk (default)
	SepRight                        // separator stays with following chunk
	SepDiscard                      // separator is removed from output
)

// ChunkOptions configures the code chunking behavior.
type ChunkOptions struct {
	MaxTokens     int
	MinTokens     int
	MinChunkSize  int // hard minimum; chunks below this get heavy DP penalty (default: DefaultMinChunkSize)
	Language      string
	Overlap       int           // number of tokens worth of content to repeat from previous chunk
	KeepSeparator SeparatorKeep // controls boundary line placement (default: SepLeft)
}

// DefaultMinChunkSize is the default minimum chunk size in tokens.
const DefaultMinChunkSize = 250

// DefaultChunkOptions returns sensible defaults for code chunking.
func DefaultChunkOptions() ChunkOptions {
	return ChunkOptions{MaxTokens: 500, MinTokens: 50, MinChunkSize: DefaultMinChunkSize, Language: "", Overlap: 50, KeepSeparator: SepLeft}
}

// Language boundary patterns.
var (
	goBoundary   = regexp.MustCompile(`^(?:func |type \w+ (?:struct|interface))`)
	pyBoundary   = regexp.MustCompile(`^(?:def |class |async def )`)
	tsBoundary   = regexp.MustCompile(`^(?:function |class |export |const \w+ = )`)
	rustBoundary = regexp.MustCompile(`^(?:fn |pub fn |struct |impl |trait )`)
	javaBoundary = regexp.MustCompile(`(?:public |private |protected ).*(?:class |interface |enum |\w+\s*\()`)
)

// symbolNamePatterns extract the symbol name from the first boundary line.
var (
	goSymbolRe   = regexp.MustCompile(`^(?:func\s+(?:\([^)]+\)\s+)?(\w+)|type\s+(\w+))`)
	pySymbolRe   = regexp.MustCompile(`^(?:async\s+def|def|class)\s+(\w+)`)
	tsSymbolRe   = regexp.MustCompile(`^(?:export\s+)?(?:function|class|const)\s+(\w+)`)
	rustSymbolRe = regexp.MustCompile(`^(?:pub\s+)?(?:fn|struct|impl|trait)\s+(\w+)`)
	javaSymbolRe = regexp.MustCompile(`(?:class|interface|enum)\s+(\w+)`)
)

// ---- Feature 5: Custom Language Regex Config ----

var (
	customLanguagePatterns   = map[string][]string{} // lang -> boundary regexes
	customLanguagePatternsMu sync.RWMutex
	compiledCustomBoundary   sync.Map // lang -> *regexp.Regexp
)

// RegisterLanguagePatterns registers custom boundary patterns for a language.
// These override the built-in patterns when looking up boundaries.
func RegisterLanguagePatterns(lang string, patterns []string) {
	customLanguagePatternsMu.Lock()
	customLanguagePatterns[strings.ToLower(lang)] = patterns
	customLanguagePatternsMu.Unlock()

	// Invalidate cached compiled regex for this language
	compiledCustomBoundary.Delete(strings.ToLower(lang))
}

// GetLanguagePatterns returns custom patterns if registered, else built-in pattern strings.
func GetLanguagePatterns(lang string) []string {
	customLanguagePatternsMu.RLock()
	defer customLanguagePatternsMu.RUnlock()
	lower := strings.ToLower(lang)
	if patterns, ok := customLanguagePatterns[lower]; ok {
		return patterns
	}
	// Return built-in pattern string representation
	b := builtinBoundaryForLang(lower)
	if b != nil {
		return []string{b.String()}
	}
	return nil
}

// ---- Feature 1: Six-Level Separator Hierarchy ----

// separatorsByLevel groups separators into their hierarchical levels.
var separatorsByLevel = [][]string{
	{"\n\n"},
	{"\n"},
	{". ", "? ", "! ", "。", "？", "！"},
	{"; ", ": ", "— ", "；", "："},
	{", ", "，"},
	{" "},
}

// splitBySeparatorLevels splits content using a multi-level separator hierarchy.
// It tries level 0 first, then for any piece that exceeds maxTokens, splits
// with the next level, recursively.
func splitBySeparatorLevels(content string, maxTokens int) []string {
	return splitBySepLevel(content, maxTokens, 0)
}

func splitBySepLevel(content string, maxTokens int, level int) []string {
	if level >= len(separatorsByLevel) {
		// No more levels; return as-is
		return []string{content}
	}

	tokens := EstimateTokensPrecise(content)
	if tokens <= maxTokens {
		return []string{content}
	}

	seps := separatorsByLevel[level]
	pieces := splitByAnySeparator(content, seps)

	if len(pieces) <= 1 {
		// This level didn't help; try the next level
		return splitBySepLevel(content, maxTokens, level+1)
	}

	// Greedily merge pieces to stay within maxTokens
	// Use fast estimate for intermediate decisions to avoid O(n²) BPE cost.
	var result []string
	current := pieces[0]
	for i := 1; i < len(pieces); i++ {
		combined := current + pieces[i]
		if EstimateTokensFast(combined) <= maxTokens {
			current = combined
		} else {
			result = append(result, current)
			current = pieces[i]
		}
	}
	if current != "" {
		result = append(result, current)
	}

	// For any piece still too large, recurse to next level
	var final []string
	for _, piece := range result {
		if EstimateTokensPrecise(piece) > maxTokens {
			final = append(final, splitBySepLevel(piece, maxTokens, level+1)...)
		} else {
			final = append(final, piece)
		}
	}

	return final
}

// splitByAnySeparator splits content at any of the given separators,
// keeping the separator attached to the left piece.
func splitByAnySeparator(content string, seps []string) []string {
	if len(seps) == 0 {
		return []string{content}
	}

	type splitPoint struct {
		index int
		sep   string
	}

	// Find all split points
	var points []splitPoint
	for _, sep := range seps {
		start := 0
		for {
			idx := strings.Index(content[start:], sep)
			if idx < 0 {
				break
			}
			absIdx := start + idx
			points = append(points, splitPoint{absIdx, sep})
			start = absIdx + len(sep)
		}
	}

	if len(points) == 0 {
		return []string{content}
	}

	// Sort split points by index
	sort.Slice(points, func(i, j int) bool {
		return points[i].index < points[j].index
	})

	// Split content at these points, keeping separator with left piece
	var pieces []string
	prev := 0
	for _, sp := range points {
		end := sp.index + len(sp.sep)
		if end > len(content) {
			end = len(content)
		}
		if end > prev {
			pieces = append(pieces, content[prev:end])
			prev = end
		}
	}
	if prev < len(content) {
		pieces = append(pieces, content[prev:])
	}

	return pieces
}

// ---- Feature 4: DP Cost-Optimized Chunk Merging ----

const (
	costTooSmall       = 1000    // penalty for chunk below MinTokens
	costTooLarge       = 2000    // penalty for chunk above MaxTokens
	costBelowMinChunk  = 1000000 // heavy penalty for chunk below MinChunkSize
	costMissingOverlap = 512     // penalty for missing overlap
	costBoundarySplit  = 300     // penalty for splitting mid-syntax
	dpMaxAtoms         = 100     // fall back to greedy above this
)

func chunkCost(tokens int, opts ChunkOptions) int {
	cost := 0
	if tokens < opts.MinTokens {
		cost += costTooSmall
	}
	if tokens > opts.MaxTokens {
		cost += costTooLarge
	}
	return cost
}

// dpSegmentCost computes the DP cost for merging atoms[i..j) into one chunk.
func dpSegmentCost(chunks []rawChunk, i, j int, tokenSums []int, opts ChunkOptions) int {
	tokens := tokenSums[j] - tokenSums[i]
	cost := 0
	// Hard constraint: never exceed MaxTokens
	if tokens > opts.MaxTokens {
		cost += costBelowMinChunk
	}
	// Penalize chunks below MinTokens (strong — these should be merged)
	if tokens < opts.MinTokens {
		cost += costTooSmall
	}
	// Penalize merging across boundaries (preserves semantic structure)
	numBoundaries := j - i - 1
	if numBoundaries > 0 {
		cost += numBoundaries * costBoundarySplit
	}
	return cost
}

// optimizeMerging uses dynamic programming to find the minimum-cost partition
// of chunks. Falls back to greedy for large inputs.
func optimizeMerging(chunks []rawChunk, opts ChunkOptions) []rawChunk {
	if len(chunks) <= 1 {
		return chunks
	}
	if len(chunks) > dpMaxAtoms {
		return greedyMerging(chunks, opts)
	}

	n := len(chunks)
	// Precompute prefix sums of token counts
	tokenSums := make([]int, n+1)
	for i, c := range chunks {
		tokenSums[i+1] = tokenSums[i] + EstimateTokensPrecise(c.content)
	}

	const inf = 1<<31 - 1
	// dp[i] = min cost to partition chunks[0..i)
	dp := make([]int, n+1)
	split := make([]int, n+1) // split[i] = start of last segment ending at i
	for i := 1; i <= n; i++ {
		dp[i] = inf
	}

	// Cache dpSegmentCost results to avoid redundant recomputation.
	// Key is (start, end) encoded as start*n+end.
	segCostCache := make(map[int]int, n*n/4)

	for i := 1; i <= n; i++ {
		for j := 0; j < i; j++ {
			key := j*n + i
			segCost, ok := segCostCache[key]
			if !ok {
				segCost = dpSegmentCost(chunks, j, i, tokenSums, opts)
				segCostCache[key] = segCost
			}
			total := dp[j] + segCost
			if total < dp[i] {
				dp[i] = total
				split[i] = j
			}
		}
	}

	// Reconstruct segments
	var segments [][2]int // [start, end) pairs
	pos := n
	for pos > 0 {
		s := split[pos]
		segments = append(segments, [2]int{s, pos})
		pos = s
	}
	// Reverse
	for l, r := 0, len(segments)-1; l < r; l, r = l+1, r-1 {
		segments[l], segments[r] = segments[r], segments[l]
	}

	// Build merged chunks
	result := make([]rawChunk, 0, len(segments))
	for _, seg := range segments {
		merged := mergeRawChunks(chunks[seg[0]:seg[1]])
		result = append(result, merged)
	}
	return result
}

// mergeRawChunks combines a slice of rawChunks into one.
func mergeRawChunks(chunks []rawChunk) rawChunk {
	if len(chunks) == 1 {
		return chunks[0]
	}
	var parts []string
	sym := ""
	for _, c := range chunks {
		parts = append(parts, c.content)
		if sym == "" {
			sym = c.symbol
		}
	}
	return rawChunk{
		content:   strings.Join(parts, "\n"),
		startLine: chunks[0].startLine,
		endLine:   chunks[len(chunks)-1].endLine,
		symbol:    sym,
	}
}

// greedyMerging is the original greedy fallback for large inputs.
func greedyMerging(chunks []rawChunk, opts ChunkOptions) []rawChunk {
	if len(chunks) <= 1 {
		return chunks
	}

	result := make([]rawChunk, len(chunks))
	copy(result, chunks)

	changed := true
	for changed {
		changed = false
		var next []rawChunk
		i := 0
		for i < len(result) {
			if i+1 >= len(result) {
				next = append(next, result[i])
				i++
				continue
			}

			combined := result[i].content + "\n" + result[i+1].content
			combinedTokens := EstimateTokensFast(combined)
			if combinedTokens > opts.MaxTokens {
				next = append(next, result[i])
				i++
				continue
			}

			curTokens := EstimateTokensFast(result[i].content)
			nextTokens := EstimateTokensFast(result[i+1].content)

			costSeparate := chunkCost(curTokens, opts) + chunkCost(nextTokens, opts)
			costMerged := chunkCost(combinedTokens, opts)

			if costMerged < costSeparate {
				merged := rawChunk{
					content:   combined,
					startLine: result[i].startLine,
					endLine:   result[i+1].endLine,
					symbol:    result[i].symbol,
				}
				if merged.symbol == "" {
					merged.symbol = result[i+1].symbol
				}
				next = append(next, merged)
				i += 2
				changed = true
			} else {
				next = append(next, result[i])
				i++
			}
		}
		result = next
	}

	return result
}

// ---- Pluggable Chunker Registry ----

// ChunkerFunc is a custom chunker that takes a file path and content, returning
// the detected language and code chunks.
type ChunkerFunc func(path, content string) (language string, chunks []CodeChunk)

var (
	chunkerRegistry   = map[string]ChunkerFunc{}
	chunkerRegistryMu sync.RWMutex
)

// RegisterChunker registers a custom chunker for a file extension (e.g. ".go").
func RegisterChunker(ext string, fn ChunkerFunc) {
	chunkerRegistryMu.Lock()
	defer chunkerRegistryMu.Unlock()
	chunkerRegistry[ext] = fn
}

// ChunkCode splits source code into semantically meaningful chunks based on
// language-aware boundary detection (function/class/method definitions).
// If a custom chunker is registered for the file extension in opts.Language,
// it is used instead of the default pipeline.
func ChunkCode(source string, opts ChunkOptions) []CodeChunk {
	return ChunkCodePath("", source, opts)
}

// ChunkCodePath is like ChunkCode but accepts a file path for registry lookup.
func ChunkCodePath(path, source string, opts ChunkOptions) []CodeChunk {
	if source == "" {
		return nil
	}

	// Check pluggable registry by file extension
	if path != "" {
		ext := filepath.Ext(path)
		chunkerRegistryMu.RLock()
		fn, ok := chunkerRegistry[ext]
		chunkerRegistryMu.RUnlock()
		if ok {
			_, chunks := fn(path, source)
			return chunks
		}
	}

	if opts.MaxTokens <= 0 {
		opts.MaxTokens = 500
	}
	if opts.MinTokens <= 0 {
		opts.MinTokens = 50
	}
	if opts.MinChunkSize <= 0 {
		opts.MinChunkSize = DefaultMinChunkSize
	}

	lang := opts.Language
	if lang == "" {
		lang = detectLanguage(source)
	}

	boundary := boundaryForLang(lang)
	symbolRe := symbolReForLang(lang)

	lines := strings.Split(source, "\n")
	rawChunks := splitAtBoundaries(lines, boundary, opts.KeepSeparator)

	// Split oversized chunks: first try blank lines, then separator hierarchy
	var splitChunks []rawChunk
	for _, rc := range rawChunks {
		tokens := EstimateTokensPrecise(rc.content)
		if tokens > opts.MaxTokens {
			blankSplit := splitAtBlankLines(rc, opts.MaxTokens)
			// Check if any piece is still too large; apply separator hierarchy
			for _, piece := range blankSplit {
				if EstimateTokensPrecise(piece.content) > opts.MaxTokens {
					subPieces := splitBySeparatorLevels(piece.content, opts.MaxTokens)
					lineOffset := piece.startLine
					for _, sp := range subPieces {
						lineCount := strings.Count(sp, "\n") + 1
						splitChunks = append(splitChunks, rawChunk{
							content:   sp,
							startLine: lineOffset,
							endLine:   lineOffset + lineCount - 1,
						})
						lineOffset += lineCount
					}
				} else {
					splitChunks = append(splitChunks, piece)
				}
			}
		} else {
			splitChunks = append(splitChunks, rc)
		}
	}

	// Cost-optimized merging (Feature 4) replaces the old greedy merge
	merged := optimizeMerging(splitChunks, opts)

	// Apply overlap: for each chunk after the first, prepend trailing content
	// from the previous chunk worth up to opts.Overlap tokens.
	overlap := opts.Overlap
	if overlap < 0 {
		overlap = 0
	}
	if overlap > 0 && len(merged) > 1 {
		for i := 1; i < len(merged); i++ {
			prevLines := strings.Split(merged[i-1].content, "\n")
			// Collect lines from the end of previous chunk until we reach overlap tokens
			var overlapLines []string
			tokenCount := 0
			for j := len(prevLines) - 1; j >= 0; j-- {
				lineTokens := EstimateTokensPrecise(prevLines[j])
				if tokenCount+lineTokens > overlap && len(overlapLines) > 0 {
					break
				}
				overlapLines = append([]string{prevLines[j]}, overlapLines...)
				tokenCount += lineTokens
			}
			if len(overlapLines) > 0 {
				merged[i].content = strings.Join(overlapLines, "\n") + "\n" + merged[i].content
			}
		}
	}

	// Build final CodeChunks with token counts and symbol extraction
	var result []CodeChunk
	for _, rc := range merged {
		tokens := EstimateTokensPrecise(rc.content)
		symbol := rc.symbol
		if symbol == "" && symbolRe != nil {
			symbol = extractSymbol(rc.content, symbolRe)
		}
		result = append(result, CodeChunk{
			Content:   rc.content,
			StartLine: rc.startLine,
			EndLine:   rc.endLine,
			Symbol:    symbol,
			Tokens:    tokens,
		})
	}

	return result
}

type rawChunk struct {
	content   string
	startLine int
	endLine   int
	symbol    string
}

func splitAtBoundaries(lines []string, boundary *regexp.Regexp, keepSep SeparatorKeep) []rawChunk {
	if boundary == nil {
		// No boundary pattern: treat the entire source as one chunk.
		content := strings.Join(lines, "\n")
		return []rawChunk{{content: content, startLine: 1, endLine: len(lines)}}
	}

	var chunks []rawChunk
	var currentLines []string
	startLine := 1

	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if boundary.MatchString(trimmed) && len(currentLines) > 0 {
			switch keepSep {
			case SepDiscard:
				// Flush accumulated lines without the boundary line
				chunks = append(chunks, rawChunk{
					content:   strings.Join(currentLines, "\n"),
					startLine: startLine,
					endLine:   i,
				})
				currentLines = nil
				startLine = i + 2 // skip the boundary line
				// Do not add the boundary line to currentLines
				continue
			case SepRight:
				// Flush accumulated lines; boundary goes to next chunk
				chunks = append(chunks, rawChunk{
					content:   strings.Join(currentLines, "\n"),
					startLine: startLine,
					endLine:   i,
				})
				currentLines = nil
				startLine = i + 1
				// Fall through to add boundary line to next chunk
			default: // SepLeft
				// Default behavior: flush, boundary starts the next chunk
				chunks = append(chunks, rawChunk{
					content:   strings.Join(currentLines, "\n"),
					startLine: startLine,
					endLine:   i,
				})
				currentLines = nil
				startLine = i + 1
			}
		}
		currentLines = append(currentLines, line)
	}

	// Flush remaining
	if len(currentLines) > 0 {
		chunks = append(chunks, rawChunk{
			content:   strings.Join(currentLines, "\n"),
			startLine: startLine,
			endLine:   len(lines),
		})
	}

	return chunks
}

func splitAtBlankLines(rc rawChunk, maxTokens int) []rawChunk {
	lines := strings.Split(rc.content, "\n")
	var result []rawChunk
	var currentLines []string
	startLine := rc.startLine

	for i, line := range lines {
		currentLines = append(currentLines, line)
		content := strings.Join(currentLines, "\n")
		tokens := EstimateTokensPrecise(content)

		if tokens > maxTokens && len(currentLines) > 1 {
			// Try to find a blank line to split at
			splitIdx := -1
			for j := len(currentLines) - 2; j >= 0; j-- {
				if strings.TrimSpace(currentLines[j]) == "" {
					splitIdx = j
					break
				}
			}

			if splitIdx >= 0 {
				before := strings.Join(currentLines[:splitIdx], "\n")
				result = append(result, rawChunk{
					content:   before,
					startLine: startLine,
					endLine:   startLine + splitIdx - 1,
				})
				currentLines = currentLines[splitIdx:]
				startLine += splitIdx
			} else {
				// No blank line found; force split at current position minus 1
				before := strings.Join(currentLines[:len(currentLines)-1], "\n")
				result = append(result, rawChunk{
					content:   before,
					startLine: startLine,
					endLine:   rc.startLine + i - 1,
				})
				currentLines = []string{line}
				startLine = rc.startLine + i
			}
		}
	}

	if len(currentLines) > 0 {
		result = append(result, rawChunk{
			content:   strings.Join(currentLines, "\n"),
			startLine: startLine,
			endLine:   rc.endLine,
		})
	}

	return result
}

func extractSymbol(content string, re *regexp.Regexp) string {
	// Look at the first few lines for a symbol
	lines := strings.SplitN(content, "\n", 5)
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if m := re.FindStringSubmatch(trimmed); m != nil {
			// Return first non-empty submatch
			for _, g := range m[1:] {
				if g != "" {
					return g
				}
			}
		}
	}
	return ""
}

func detectLanguage(source string) string {
	lines := strings.SplitN(source, "\n", 20)
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "package ") {
			return "go"
		}
		if strings.HasPrefix(trimmed, "import ") && strings.Contains(source, "def ") {
			return "python"
		}
		if strings.HasPrefix(trimmed, "def ") || strings.HasPrefix(trimmed, "class ") && strings.Contains(trimmed, ":") {
			return "python"
		}
		if strings.HasPrefix(trimmed, "fn ") || strings.HasPrefix(trimmed, "pub fn ") {
			return "rust"
		}
		if strings.Contains(trimmed, "function ") || strings.Contains(trimmed, "import {") {
			return "typescript"
		}
	}
	return ""
}

// builtinBoundaryForLang returns the built-in boundary regex for a language,
// ignoring custom patterns.
func builtinBoundaryForLang(lang string) *regexp.Regexp {
	switch strings.ToLower(lang) {
	case "go":
		return goBoundary
	case "python", "py":
		return pyBoundary
	case "typescript", "ts", "javascript", "js", "tsx", "jsx":
		return tsBoundary
	case "rust", "rs":
		return rustBoundary
	case "java":
		return javaBoundary
	default:
		return nil
	}
}

// boundaryForLang returns the boundary regex for a language, checking custom
// patterns first before falling back to built-in patterns.
func boundaryForLang(lang string) *regexp.Regexp {
	customLanguagePatternsMu.RLock()
	patterns, ok := customLanguagePatterns[strings.ToLower(lang)]
	customLanguagePatternsMu.RUnlock()

	if ok && len(patterns) > 0 {
		if cached, found := compiledCustomBoundary.Load(lang); found {
			if re, ok := cached.(*regexp.Regexp); ok {
				return re
			}
		}
		combined := strings.Join(patterns, "|")
		re, err := regexp.Compile(combined)
		if err == nil {
			compiledCustomBoundary.Store(lang, re)
			return re
		}
	}

	return builtinBoundaryForLang(lang)
}

func symbolReForLang(lang string) *regexp.Regexp {
	switch strings.ToLower(lang) {
	case "go":
		return goSymbolRe
	case "python", "py":
		return pySymbolRe
	case "typescript", "ts", "javascript", "js", "tsx", "jsx":
		return tsSymbolRe
	case "rust", "rs":
		return rustSymbolRe
	case "java":
		return javaSymbolRe
	default:
		return nil
	}
}

// extensionLanguageMap and DetectLanguageByExtension moved to chunker_extensions.go.
