# shrike

[![Go](https://img.shields.io/badge/Go-1.22+-00ADD8?logo=go)](https://go.dev/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

shrike は、LLM 向けのトークン圧縮・フィルタリング・推定・シークレットスキャンを提供する Go ライブラリです。

## インストール

```bash
go get github.com/GrayCodeAI/shrike
```

## ドキュメント

完全なドキュメントは [英語の README](README.md) を参照してください。

## CLI（`shrike` サブコマンド）

`shrike` のサブコマンドは Hawk（[github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk)）を通じて提供されます。

## ライセンス

[MIT](LICENSE)
