package compress

import (
	"strings"
	"unicode"
)

// safetyKeywords are substrings that, if present, force the compressor
// to fall back to "normal" prose (no compression) for that segment.
//
// Source: skills/prompt-compression/SKILL.md, "Auto-clarity rules":
//
//	"Drop to normal prose for security warnings, destructive ops,
//	ambiguous sequences."
//
// Matching is case-insensitive substring on the segment.
var safetyKeywords = []string{
	// Security / destructive
	"rm -rf",
	"rm -fr",
	"del /",
	"delete from",
	"drop table",
	"drop database",
	"truncate table",
	"format c:",
	"format /",
	"mkfs.",
	"dd if=",
	"shutdown",
	"reboot",
	"halt",
	"poweroff",
	":(){:|:&};:", // fork bomb
	"chmod -r 777 /",
	"chmod 777 /",
	"chown -r",
	"> /dev/sd",
	"curl ", "wget ",
	"sudo ",
	"su -",
	"doas ",

	// Security warnings
	"warning: ",
	"warning:",
	"caution: ",
	"caution:",
	"danger: ",
	"danger:",
	"security alert",
	"vulnerability",
	"exploit",
	"cve-",
	"0day",
	"zero-day",
	"security advisory",
	"private key",
	"secret key",
	"api key",
	"password",
	"passphrase",
	"credential",
	"auth token",
	"access token",
	"bearer token",
	"do not commit",
	"do not push",
	"do not share",
	"do not distribute",
	"do not publish",
	"do not store",
	"do not log",
	"do not print",
	"do not echo",
	"do not include",
	"do not paste",
	"do not upload",
	"do not download",
	"do not run",

	// Ambiguous / dangerous contexts
	"force push",
	"force-push",
	"--force",
	"-f ",
	"reset --hard",
	"clean -fd",
	"clean -fdx",
	"git push --force",
	"git push -f",
	"drop database",
	"production",
	"prod ",
	"live ",
	"master ",
	"main branch",
}

// IsSafeSegment returns true if s contains no safety keywords.
// A segment with safety keywords must be passed through unchanged.
func IsSafeSegment(s string) bool {
	lower := strings.ToLower(s)
	for _, kw := range safetyKeywords {
		if strings.Contains(lower, kw) {
			return false
		}
	}
	return true
}

// SplitSafeSegments splits s into segments that are safe to compress and
// segments that must be preserved verbatim. Returns a slice of (text, safe)
// pairs. Adjacent safe/unsafe segments are merged by their flag.
//
// Each segment keeps its original, untrimmed text (Raw) so re-joins preserve
// the whitespace between sentences; Text holds the trimmed form used for
// classification and compression.
func SplitSafeSegments(s string) []segment {
	if s == "" {
		return nil
	}
	// Split on sentence boundaries; the rule operates per sentence.
	segs := splitSentences(s)
	out := make([]segment, 0, len(segs))
	for _, seg := range segs {
		trimmed := strings.TrimSpace(seg)
		if trimmed == "" {
			// Whitespace-only segment (e.g. blank lines between sentences):
			// keep the raw text and pass it through untouched.
			out = append(out, segment{Text: "", Raw: seg, Safe: false})
			continue
		}
		out = append(out, segment{Text: trimmed, Raw: seg, Safe: IsSafeSegment(trimmed)})
	}
	return out
}

type segment struct {
	Text string // trimmed text used for classification and compression
	Raw  string // original (untrimmed) text, preserved for the re-join
	Safe bool   // true if safe to compress; false = preserve verbatim
}

// splitSentences splits s on sentence-ending punctuation (`.`, `!`, `?`,
// `\n`) while preserving URLs, code, and decimal numbers.
//
// This is a heuristic. It does not handle every edge case (e.g. abbreviations
// like "e.g.", "i.e.") but it is good enough for prose compression.
func splitSentences(s string) []string {
	var out []string
	var cur strings.Builder
	inCode := false  // inside backticks
	inFence := false // inside ``` fence
	i := 0
	for i < len(s) {
		c := s[i]

		// Detect code fences
		if i+2 < len(s) && s[i] == '`' && s[i+1] == '`' && s[i+2] == '`' {
			inFence = !inFence
			cur.WriteByte(c)
			i++
			continue
		}

		// Inside a fence, never split
		if inFence {
			cur.WriteByte(c)
			i++
			continue
		}

		// Toggle backtick code spans
		if c == '`' {
			inCode = !inCode
			cur.WriteByte(c)
			i++
			continue
		}

		// Inside inline code, never split
		if inCode {
			cur.WriteByte(c)
			i++
			continue
		}

		// Split on sentence punctuation if followed by whitespace + uppercase
		// (English-style sentence break) or end-of-string.
		if c == '.' || c == '!' || c == '?' || c == '\n' {
			// Don't split on '.' inside decimal numbers (digit before + after)
			if c == '.' && i > 0 && i+1 < len(s) &&
				isDigit(s[i-1]) && isDigit(s[i+1]) {
				cur.WriteByte(c)
				i++
				continue
			}
			// Don't split on '.' inside acronyms (e.g. U.S.A.) - heuristic:
			// single capital letter before + single capital after
			if c == '.' && i > 0 && i+1 < len(s) &&
				isUpperLetter(s[i-1]) && isUpperLetter(s[i+1]) {
				cur.WriteByte(c)
				i++
				continue
			}
			// Split here: emit current buffer
			cur.WriteByte(c)
			out = append(out, cur.String())
			cur.Reset()
			i++
			continue
		}

		cur.WriteByte(c)
		i++
	}
	if cur.Len() > 0 {
		out = append(out, cur.String())
	}
	return out
}

func isDigit(b byte) bool {
	return b >= '0' && b <= '9'
}

func isUpperLetter(b byte) bool {
	return b >= 'A' && b <= 'Z'
}

// isCJK reports whether s is primarily CJK characters (Chinese/Japanese/Korean).
// Used to decide if the compression rules even apply — CJK text doesn't have
// articles/filler to drop.
func isCJK(s string) bool {
	cjk := 0
	total := 0
	for _, r := range s {
		if unicode.Is(unicode.Han, r) || unicode.Is(unicode.Hiragana, r) ||
			unicode.Is(unicode.Katakana, r) || unicode.Is(unicode.Hangul, r) {
			cjk++
		}
		total++
	}
	return total > 0 && cjk*2 > total
}
