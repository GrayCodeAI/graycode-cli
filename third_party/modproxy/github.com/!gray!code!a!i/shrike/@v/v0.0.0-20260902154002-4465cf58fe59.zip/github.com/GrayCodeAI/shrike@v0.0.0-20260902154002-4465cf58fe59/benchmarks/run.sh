#!/usr/bin/env bash
# benchmarks/run.sh — run the offline compression-quality harness.
#
# shrike is a library (no CLI), so benchmarks run through the Go harness in
# benchmarks/quality, which exercises shrike.Compress against sample prompts
# and reports compression ratio, char retention, and a ROUGE-1 fidelity
# proxy. Fully offline — no network, no model calls.
#
# Usage: ./benchmarks/run.sh
# Output: benchmarks/quality-results.md (+ optional CSV)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "shrike Benchmark Runner"
echo "===================="
echo ""

cd "$REPO_ROOT"

# Library micro-benchmarks (token counting, compression, BPE).
echo "==> Go benchmarks (root package)"
go test -run='^$' -bench='BenchmarkCompress|BenchmarkCountTokens|BenchmarkBPEEncode' -benchmem .

echo ""
echo "==> Compression-quality harness"
go run ./benchmarks/quality/cmd \
  --samples benchmarks/samples.json \
  --out benchmarks/quality-results.md \
  --csv benchmarks/quality-results.csv

echo ""
echo "Results written to benchmarks/quality-results.md"
