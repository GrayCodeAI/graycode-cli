// Package filter: validate-fix-retry loop for compression with quality guarantees.
//
// When a caller wants compression to satisfy an external invariant (e.g. the
// output must contain a required term, or stay under a budget, or include a
// specific JSON key), the simplest approach is to compress once and hope.
// A more robust approach is:
//
//  1. compress
//  2. validate
//  3. if invalid, escalate aggressiveness and try again
//  4. repeat up to MaxRetries times
//
// This module provides that pattern. The validator is caller-supplied so
// any policy can be expressed (key-term retention, budget, JSON schema,
// structural integrity, etc.). The escalation function is also
// caller-supplied, defaulting to "switch from Minimal to Aggressive mode".
//
// GrayCode native validate-fix-retry compression loop.
// scripts/compress.py (validate_fix_retry). Ported to native Go.
package filter

import (
	"context"
	"errors"
)

// Validator reports whether a compressed output satisfies an external
// invariant. It returns (true, "") on success or (false, reason) on
// failure. The reason is reported via Stats.LastFailureReason for
// observability. Accepts a pointer to avoid copying sync.RWMutex.
type Validator func(output string, stats *PipelineStats) (ok bool, reason string)

// AdjustFunc escalates a (mode, intensity) pair on retry. The default
// escalator (DefaultAdjust) flips Minimal -> Aggressive.
type AdjustFunc func(mode Mode, intensity int) (Mode, int)

// DefaultAdjust is the canonical escalation: Minimal -> Aggressive on the
// first retry, then any further retries bump intensity by 1.
func DefaultAdjust(mode Mode, intensity int) (Mode, int) {
	if mode == ModeMinimal {
		return ModeAggressive, intensity
	}
	return mode, intensity + 1
}

// ErrNoValidator is returned by CompressWithRetry when no validator is
// supplied. The caller should either pass a validator or use Compress()
// directly.
var ErrNoValidator = errors.New("filter: CompressWithRetry requires a non-nil Validator")

// RetryStats is the per-call accounting for CompressWithRetry.
type RetryStats struct {
	Attempts             int            // total attempts made (1..MaxRetries)
	LastFailureReason    string         // reason from the last failed attempt
	EscalatedAtLeastOnce bool           // true if at least one retry used a different config than the first attempt
	FinalOutput          string         // the output that was returned
	FinalPipelineStats   *PipelineStats // pointer to avoid copying sync.RWMutex
}

// CompressOnceFunc is the signature of a single compression call.
// Implementations are typically bound to a specific (mode, intensity) pair
// built from the config. Returns a pointer to avoid copying sync.RWMutex.
type CompressOnceFunc func(ctx context.Context, text string, mode Mode, intensity int) (string, *PipelineStats)

// CompressWithRetry applies the validate-fix-retry loop. It calls compress
// up to maxRetries times; if validator returns false, it calls adjust to
// get a new (mode, intensity) and tries again. The first attempt that
// validates succeeds; if all attempts fail, the last output is returned
// and LastFailureReason is set.
//
// maxRetries is the maximum number of attempts (>=1). A value of 1 means
// "no retries" — the loop runs at most once. A value of 3 means up to
// three total attempts (1 initial + 2 retries).
//
// validator must be non-nil; passing nil returns ErrNoValidator.
// adjust may be nil, in which case DefaultAdjust is used.
//
// This function is safe to call from multiple goroutines (no shared
// mutable state beyond the provided closures).
func CompressWithRetry(
	ctx context.Context,
	text string,
	mode Mode,
	intensity int,
	maxRetries int,
	compress CompressOnceFunc,
	validator Validator,
	adjust AdjustFunc,
) (string, RetryStats, error) {
	if validator == nil {
		return "", RetryStats{}, ErrNoValidator
	}
	if maxRetries < 1 {
		maxRetries = 1
	}
	if adjust == nil {
		adjust = DefaultAdjust
	}

	rs := RetryStats{}

	for attempt := 1; attempt <= maxRetries; attempt++ {
		rs.Attempts = attempt
		if ctx.Err() != nil {
			return "", rs, ctx.Err()
		}
		out, ps := compress(ctx, text, mode, intensity)
		ok, reason := validator(out, ps)
		if ok {
			rs.FinalOutput = out
			rs.FinalPipelineStats = ps
			return out, rs, nil
		}
		rs.LastFailureReason = reason
		if attempt == maxRetries {
			// Out of attempts; return the last output anyway.
			rs.FinalOutput = out
			rs.FinalPipelineStats = ps
			return out, rs, nil
		}
		// Escalate and retry.
		mode, intensity = adjust(mode, intensity)
		rs.EscalatedAtLeastOnce = true
	}
	return rs.FinalOutput, rs, nil
}

// MustContainsValidator returns a Validator that fails if any of the
// required substrings are missing from the output. Useful for ensuring
// that key terms (e.g. a function name, a config key) survive compression.
func MustContainsValidator(required ...string) Validator {
	return func(output string, _ *PipelineStats) (bool, string) {
		for _, r := range required {
			if !contains(output, r) {
				return false, "required term missing: " + r
			}
		}
		return true, ""
	}
}

// MaxTokensValidator returns a Validator that fails if EstimateTokens(output)
// exceeds max. Returns (true, "") for empty output.
func MaxTokensValidator(max int) Validator {
	return func(output string, _ *PipelineStats) (bool, string) {
		if max <= 0 {
			return true, ""
		}
		shrike := EstimateTokens(output)
		if shrike > max {
			return false, "token budget exceeded"
		}
		return true, ""
	}
}

// CompressWithBudgetRetry is a convenience wrapper that retries
// compression until the output fits in a token budget or the retry
// budget is exhausted. It uses MaxTokensValidator internally.
//
// maxRetries is the max number of attempts (>=1). On each retry the
// DefaultAdjust escalator is invoked.
func CompressWithBudgetRetry(
	ctx context.Context,
	text string,
	initialMode Mode,
	budget int,
	maxRetries int,
	compress CompressOnceFunc,
) (string, RetryStats, error) {
	return CompressWithRetry(
		ctx, text, initialMode, 0, maxRetries,
		compress,
		MaxTokensValidator(budget),
		nil,
	)
}

// _ ensures the package is not flagged for unused imports if a future
// refactor removes all callers; the placeholder is a no-op.
var _ = errors.New
