package filter

import (
	"testing"
	"time"
)

func TestNewLRUCache(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)
	if cache == nil {
		t.Fatal("NewLRUCache returned nil")
	}
}

func TestLRUCacheSetAndGet(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)

	cache.Set("test-key", CachedResult{Output: "test output", Tokens: 50})
	got, ok := cache.Get("test-key")
	if !ok {
		t.Fatal("expected to find cached value")
	}

	result, ok := got.(CachedResult)
	if !ok {
		t.Fatal("expected CachedResult type")
	}
	if result.Output != "test output" {
		t.Errorf("expected output %q, got %q", "test output", result.Output)
	}
	if result.Tokens != 50 {
		t.Errorf("expected tokens %d, got %d", 50, result.Tokens)
	}
}

func TestLRUCacheMiss(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)

	_, ok := cache.Get("nonexistent")
	if ok {
		t.Error("expected cache miss for nonexistent key")
	}
}

func TestLRUCacheEviction(t *testing.T) {
	cache := NewLRUCache(2, 5*time.Minute)

	cache.Set("key1", CachedResult{Output: "output1"})
	cache.Set("key2", CachedResult{Output: "output2"})

	cache.Get("key1")

	cache.Set("key3", CachedResult{Output: "output3"})

	if cache.Len() != 2 {
		t.Errorf("expected cache size 2 after eviction, got %d", cache.Len())
	}

	_, ok := cache.Get("key2")
	if ok {
		t.Error("expected key2 to be evicted")
	}

	_, ok = cache.Get("key1")
	if !ok {
		t.Error("expected key1 to still be in cache")
	}

	_, ok = cache.Get("key3")
	if !ok {
		t.Error("expected key3 to be in cache")
	}
}

func TestLRUCacheDelete(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)

	cache.Set("key1", CachedResult{Output: "output1"})
	cache.Set("key2", CachedResult{Output: "output2"})

	cache.Delete("key1")

	_, ok := cache.Get("key1")
	if ok {
		t.Error("expected key1 to be deleted")
	}
	_, ok = cache.Get("key2")
	if !ok {
		t.Error("expected key2 to still be accessible")
	}

	if cache.Len() != 1 {
		t.Errorf("expected length 1 after delete, got %d", cache.Len())
	}
}

func TestLRUCacheMaxSizeZero(t *testing.T) {
	cache := NewLRUCache(0, 5*time.Minute)
	if cache.Len() != 0 {
		t.Errorf("expected empty cache, got size %d", cache.Len())
	}
}

func TestLRUCacheOverwrite(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)

	cache.Set("key1", CachedResult{Output: "old"})
	cache.Set("key1", CachedResult{Output: "new"})

	got, ok := cache.Get("key1")
	if !ok {
		t.Fatal("expected to find key1")
	}
	result, ok := got.(CachedResult)
	if !ok {
		t.Fatal("expected CachedResult type")
	}
	if result.Output != "new" {
		t.Errorf("expected overwritten output %q, got %q", "new", result.Output)
	}
}

func TestLRUCacheLen(t *testing.T) {
	cache := NewLRUCache(100, 5*time.Minute)

	if cache.Len() != 0 {
		t.Errorf("expected empty cache, got size %d", cache.Len())
	}

	cache.Set("key1", CachedResult{Output: "output1"})
	if cache.Len() != 1 {
		t.Errorf("expected size 1, got %d", cache.Len())
	}

	cache.Set("key2", CachedResult{Output: "output2"})
	if cache.Len() != 2 {
		t.Errorf("expected size 2, got %d", cache.Len())
	}

	cache.Delete("key1")
	if cache.Len() != 1 {
		t.Errorf("expected size 1 after delete, got %d", cache.Len())
	}
}

func TestLRUCacheConcurrent(t *testing.T) {
	cache := NewLRUCache(1000, 5*time.Minute)
	done := make(chan bool)

	for i := 0; i < 20; i++ {
		go func(n int) {
			key := string(rune('a' + n))
			cache.Set(key, CachedResult{Output: key})
			cache.Get(key)
			done <- true
		}(i)
	}

	for i := 0; i < 20; i++ {
		<-done
	}
}
