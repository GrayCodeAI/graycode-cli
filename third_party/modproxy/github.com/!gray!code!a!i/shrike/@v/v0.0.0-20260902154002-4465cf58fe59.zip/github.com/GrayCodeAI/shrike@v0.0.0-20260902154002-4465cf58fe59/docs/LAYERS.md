# Shrike Layer Compression Pipeline (Core + Experimental)

Shrike is a Go library (`github.com/GrayCodeAI/shrike`) that implements a world-class
token reduction system based on 120+ research papers from top institutions
worldwide (2023-2026).

This document focuses on foundational layers `1..20`. The production pipeline
includes additional core and experimental stages (31 layers in total).

> The pipeline is driven through the Go API — there is no standalone `shrike` CLI.
> CLI-style verbs (`compress`, `estimate`, etc.) are exposed by **Hawk**
> (`github.com/GrayCodeAI/hawk`), which embeds this library.

## Architecture Overview

```
Input → [Research Compression Layers] → [Budget + Recovery Layers] → [Experimental Layers] → Output
         ↓
    Streaming for large inputs (up to 2M tokens)
```

## Compression Performance

Measured on a realistic code-review prose fixture (not repetitive Lorem
Ipsum) via `evals/pipeline-bench.sh` (which wraps `go test -bench`). Run the
script yourself to reproduce — numbers update as the pipeline changes:

| Input Size | Reduction | Latency | Quality score |
|------------|-----------|---------|---------------|
| 18 lines   | 64.3%     | ~3 ms   | 0.73 |
| 180 lines  | 83.0%     | ~2.7 ms | 0.60 |
| 900 lines  | 87.5%     | ~1.5 ms | 0.51 |
| 5400 lines | 88.2%     | ~1.6 ms | 0.50 |

The numbers approach an asymptote around 88% as input grows, not the
99%+ range earlier versions of this doc claimed. Reductions above 95%
are reachable on highly repetitive inputs (log spew, large generated
code, duplicated boilerplate) where the dedup + near-duplicate-collapse
layers dominate; those inputs are not representative of what most shrike
users compress daily.

Quality score 0-1 is the pipeline's own self-assessment of how much
semantic signal survives compression; it trends down as compression
gets more aggressive. Pair with `evals/semantic.py` (judge-model
scored) if you want to validate that downstream answer correctness
stays intact on a specific workload.

## Layer Details

### Layer 1: Entropy Filtering
**Research**: Selective Context (Mila, 2023)  
**Compression**: 2-3x  
**Algorithm**: Removes low-information tokens based on entropy scores. Tokens that appear frequently with little variation are pruned.

**Config**:
```toml
[pipeline]
enable_entropy = true
entropy_threshold = 0.3  # 0.0-1.0, lower = more aggressive
```

---

### Layer 2: Perplexity Pruning
**Research**: LLMLingua (Microsoft/Tsinghua, 2023)  
**Compression**: 20x  
**Algorithm**: Uses iterative perplexity scoring to identify and remove less important tokens while preserving semantic meaning.

**Config**:
```toml
[pipeline]
enable_perplexity = true
perplexity_threshold = 0.5
```

You can also drive this layer directly from Go with a custom scorer via
`shrike.WithPerplexityGuided(scorer, ratio)`.

---

### Layer 3: Goal-Driven Selection
**Research**: SWE-Pruner (Shanghai Jiao Tong, 2025)  
**Compression**: 14.8x  
**Algorithm**: CRF-style line scoring based on query intent. Prioritizes content relevant to the task (debug, review, deploy).

**Config**:
```toml
[pipeline]
enable_goal_driven = true
goal_driven_threshold = 0.4
```

---

### Layer 4: AST Preservation
**Research**: LongCodeZip (NUS, 2025)  
**Compression**: 4-8x  
**Algorithm**: Syntax-aware compression that preserves abstract syntax tree structure while removing redundant code.

**Config**:
```toml
[pipeline]
enable_ast = true
ast_preserve_threshold = 0.6
```

Enable code-aware behaviour from Go with `shrike.WithCodeAware(lang)`.

---

### Layer 5: Contrastive Ranking
**Research**: LongLLMLingua (Microsoft, 2024)  
**Compression**: 4-10x  
**Algorithm**: Question-relevance scoring using n-gram contrastive analysis between query and context.

**Config**:
```toml
[pipeline]
enable_contrastive = true
contrastive_threshold = 0.5
```

---

### Layer 6: N-gram Abbreviation
**Research**: CompactPrompt (2025)  
**Compression**: 2.5x  
**Algorithm**: Lossless compression of repeated n-grams using dictionary-based abbreviation.

**Config**:
```toml
[pipeline]
enable_ngram = true
ngram_min_occurrences = 3
```

---

### Layer 7: Evaluator Heads
**Research**: EHPC (Tsinghua/Huawei, 2025)  
**Compression**: 5-7x  
**Algorithm**: Simulates early-layer attention heads to identify important tokens without full model inference.

**Config**:
```toml
[pipeline]
enable_evaluator = true
evaluator_threshold = 0.4
```

---

### Layer 8: Gist Compression
**Research**: Gisting (Stanford/Berkeley, 2023)  
**Compression**: 20x+  
**Algorithm**: Compresses prompts into "gist tokens" - virtual tokens representing semantic meaning.

**Config**:
```toml
[pipeline]
enable_gist = true
gist_min_chunk_size = 100
```

---

### Layer 9: Hierarchical Summary
**Research**: AutoCompressor (Princeton/MIT, 2023)  
**Compression**: Extreme (depends on summary size)  
**Algorithm**: Recursive summarization that compresses context into hierarchical summary vectors.

**Config**:
```toml
[pipeline]
enable_hierarchical = true
hierarchical_max_levels = 3
hierarchical_ratio = 0.3
```

---

### Layer 10: Budget Enforcement
**Research**: Industry Standard  
**Compression**: Guaranteed  
**Algorithm**: Strict token limit enforcement with intelligent truncation preserving critical content.

**Config**:
```toml
[pipeline]
enable_budget = true
default_budget = 0  # 0 = unlimited
hard_budget_limit = true
```

---

### Layer 11: Compaction Layer
**Research**: MemGPT (UC Berkeley, 2023)  
**Compression**: 98%+ for chat/conversation content  
**Algorithm**: Semantic compression that creates state snapshots with 4 sections: session_history, current_state, context, and pending_plan. Designed for chat history and conversation-style content.

**Config**:
```toml
[pipeline]
enable_compaction = true
compaction_threshold = 500        # Minimum tokens to trigger
compaction_preserve_turns = 10    # Recent turns to keep verbatim
compaction_max_tokens = 5000      # Max summary tokens
compaction_state_snapshot = true  # Use structured format
compaction_auto_detect = true     # Auto-detect conversation content
```

---

### Layer 12: Attribution Filter
**Research**: ProCut (LinkedIn, 2025)  
**Compression**: 78% reduction  
**Algorithm**: Identifies and removes low-attribution content - text that contributes little to the final output. Uses positional bias, frequency analysis, and semantic importance scoring.

**Config**:
```toml
[pipeline]
enable_attribution = true
attribution_threshold = 0.25     # Importance threshold (0.0-1.0)
attribution_positional = true    # Preserve start/end content
attribution_frequency = true     # Reduce repeated content
attribution_semantic = true      # Preserve keywords, numbers, code
```

---

### Layer 13: H2O Filter (Heavy-Hitter Oracle)
**Research**: H2O (Zhang et al., NeurIPS 2023)  
**Compression**: 30x+  
**Algorithm**: Identifies "heavy hitters" - tokens with high cumulative attention scores. Combines attention sinks (initial tokens), recent token window, and heavy hitter preservation for KV cache-style compression.

**Config**:
```toml
[pipeline]
enable_h2o = true
h2o_sink_size = 4                # First N tokens as attention sinks
h2o_recent_size = 20             # Recent tokens to preserve
h2o_heavy_hitter_size = 40       # Top heavy hitters to keep
```

---

### Layer 14: Attention Sink Filter
**Research**: StreamingLLM (Xiao et al., 2023)  
**Compression**: Infinite context stability  
**Algorithm**: Preserves initial tokens as "attention sinks" that absorb excess attention weight due to softmax normalization. Enables infinite-length generation with bounded memory while maintaining coherence.

**Config**:
```toml
[pipeline]
enable_attention_sink = true
attention_sink_count = 4         # Initial lines to preserve as sinks
attention_recent_count = 8       # Recent lines in rolling cache
```

---

### Layer 15: Meta-Token Compression
**Research**: Lossless Token Sequence Compression via Meta-Tokens (arXiv 2506.00307, 2025)  
**Compression**: 27% lossless (= 47% compute reduction due to quadratic attention)  
**Algorithm**: LZ77-style lossless compression operating on token sequences. Scans for repeated patterns and replaces them with meta-tokens that reference the original sequence. Trivially reversible with zero semantic loss.

**Config**:
```toml
[pipeline]
enable_meta_token = true
meta_token_window = 512       # Max sequence length to compress
meta_token_min_pattern = 3    # Minimum tokens to form a pattern
meta_token_max = 1000         # Max meta-tokens to create
```

---

### Layer 16: Semantic Chunk Filter
**Research**: Dynamic Boundary Detection (Context-Aware 2024)  
**Compression**: Context-aware chunking  
**Algorithm**: Detects semantic boundaries using sentence embeddings and discourse markers. Chunks content into semantically coherent units for more intelligent pruning decisions. Prevents mid-sentence or mid-paragraph cuts.

**Config**:
```toml
[pipeline]
enable_semantic_chunk = true
semantic_chunk_min_size = 50     # Minimum chunk size in tokens
semantic_chunk_max_size = 500    # Maximum chunk size
semantic_chunk_threshold = 0.7   # Similarity threshold for boundaries
```

---

### Layer 17: Semantic Cache Layer
**Research**: KVReviver (arXiv, December 2025)  
**Compression**: 90% memory reduction at 10% budget  
**Algorithm**: Sketch-based reversible compression. Creates compressed sketches (quantized/low-rank representations) for evicted content. Stores sketches for on-demand reconstruction when context requires it. Heavy hitters stay uncompressed.

**Config**:
```toml
[pipeline]
enable_sketch_store = true
sketch_budget_ratio = 0.1       # Target compression (10% = 90% reduction)
sketch_enable_recovery = true   # On-demand reconstruction
sketch_max_size = 10000         # Max sketch storage per entry
sketch_heavy_hitter_ratio = 0.2 # Top 20% stay uncompressed
```

---

### Layer 18: Lazy Pruner Filter
**Research**: LazyLLM (arXiv, July 2024)  
**Compression**: 2.34x speedup in prefill phase  
**Algorithm**: Budget-aware dynamic token pruning with layer-wise decay. Defer KV computation for less important tokens. Prune-and-revive mechanism allows recoverable pruning. Each layer gets progressively smaller token budgets.

**Config**:
```toml
[pipeline]
enable_lazy_pruner = true
lazy_base_budget = 4000          # Initial token budget for layer 0
lazy_decay_rate = 0.9            # Budget decay per layer (0.9 = 10% reduction)
lazy_num_layers = 10             # Number of layers to compute budgets for
lazy_revival_budget = 100        # Max tokens to pull back from pruned pool
lazy_attention_threshold = 0.3   # Minimum score to keep a token
lazy_enable_revival = true       # Allow on-demand token recovery
```

---

### Layer 19: Semantic Anchor Filter
**Research**: Attention Gradient Anchor Detection (2024)  
**Compression**: Context preservation  
**Algorithm**: Identifies "anchor" tokens with high attention gradients - content that strongly influences downstream generation. Preserves these anchors to maintain coherence and prevent hallucination. Uses position-weighted scoring.

**Config**:
```toml
[pipeline]
enable_semantic_anchor = true
anchor_threshold = 0.6          # Minimum gradient to be an anchor
anchor_preserve_count = 20      # Minimum anchors to preserve
anchor_position_weight = 0.3    # Weight for position-based scoring
```

---

### Layer 20: Agent Memory Filter
**Research**: Knowledge Graph Extraction for Agents (2024)  
**Compression**: Agent-optimized memory  
**Algorithm**: Extracts and preserves knowledge statements from agent outputs. Identifies "I found", "I learned", "The solution is" patterns. Builds a knowledge graph for agent-specific memory optimization. Removes noise like conversational filler.

**Config**:
```toml
[pipeline]
enable_agent_memory = true
agent_knowledge_threshold = 0.7  # Confidence threshold for knowledge extraction
agent_preserve_insights = true   # Preserve insight statements
agent_remove_noise = true        # Remove conversational filler
```

---

## Large Context Support

Shrike supports inputs up to **2 million tokens** with streaming processing:

```toml
[pipeline]
max_context_tokens = 2000000  # 2M tokens
chunk_size = 100000           # 100K per chunk
stream_threshold = 500000     # Stream if > 500K
```

## Resilience Features

### Fail-Safe Mode
Automatically returns original input if compression produces invalid output:

```toml
[pipeline]
failsafe_mode = true
validate_output = true
```

### Tee-on-Failure
Saves raw output to a file if compression fails:

```toml
[pipeline]
tee_on_failure = true
tee_dir = "/tmp/shrike-tee"
```

### Short-Circuit Budget
Skip remaining layers if budget is already met:

```toml
[pipeline]
short_circuit_budget = true
```

## Performance

### Caching
Enable caching for repeated compressions:

```toml
[pipeline]
cache_enabled = true
cache_max_size = 1000
```

## Custom Filters

The pipeline accepts user-defined filter rules from a TOML file. Load them with
`shrike.LoadFilterRules` and inject them via the `shrike.WithCustomFilters` option:

```go
rules, err := shrike.LoadFilterRules("rules/my-filters.toml")
if err != nil {
    log.Fatal(err)
}

out, stats := shrike.Compress(input, shrike.WithCustomFilters(rules))
```

## Usage

Install the library:

```bash
go get github.com/GrayCodeAI/shrike
```

### Programmatic (Go API)

```go
import "github.com/GrayCodeAI/shrike"

// Basic compression
out, stats := shrike.Compress(input)

// Aggressive mode
out, stats = shrike.Compress(input, shrike.Aggressive)

// Code-aware compression
out, stats = shrike.Compress(input, shrike.WithCodeAware("go"))

// Custom filters + perplexity-guided pruning
out, stats = shrike.Compress(input,
    shrike.WithCustomFilters(rules),
    shrike.WithPerplexityGuided(scorer, 0.5),
)

fmt.Printf("Saved %d tokens (%.1f%%)\n", stats.SavedTokens, stats.ReductionPercent)

// Prompt-oriented compression with an intensity level
compressed, ps := shrike.PromptCompress(prompt, shrike.IntensityFull) // Lite / Full / Ultra

// Token + cost estimation
tokens := shrike.EstimateTokensForModel(input, "gpt-4o")
cost := shrike.EstimateCost(input, "gpt-4o")
```

### CLI (via Hawk)

The `shrike ...` verbs people may remember are provided by **Hawk**
(`github.com/GrayCodeAI/hawk`), which embeds this library:

```bash
hawk shrike compress large_file.txt
hawk shrike estimate large_file.txt
```

### Benchmarks

Benchmarks run through Go (`go test -bench`) via wrapper scripts:

```bash
./benchmarks/run.sh
./evals/pipeline-bench.sh
```

## Research References

1. **Selective Context** - Li et al., Mila (2023)
2. **LLMLingua** - Jiang et al., Microsoft/Tsinghua (2023)
3. **SWE-Pruner** - Zhang et al., Shanghai Jiao Tong (2025)
4. **LongCodeZip** - Liu et al., NUS (2025)
5. **LongLLMLingua** - Jiang et al., Microsoft (2024)
6. **CompactPrompt** - Wang et al. (2025)
7. **EHPC** - Chen et al., Tsinghua/Huawei (2025)
8. **Gisting** - Mu et al., Stanford/Berkeley (2023)
9. **AutoCompressor** - Chevalier et al., Princeton/MIT (2023)
10. **Budget Enforcement** - Industry standard
11. **MemGPT** - Packer et al., UC Berkeley (2023)
12. **ProCut** - LinkedIn Research (2025)
13. **H2O** - Zhang et al., NeurIPS (2023)
14. **StreamingLLM** - Xiao et al. (2023)
15. **Meta-Token Compression** - arXiv 2506.00307 (2025)
16. **Semantic Chunking** - Context-Aware Boundary Detection (2024)
17. **KVReviver** - Sketch-based KV Cache Recovery, arXiv (December 2025)
18. **LazyLLM** - Dynamic Token Pruning, arXiv (July 2024)
19. **Semantic Anchor** - Attention Gradient Detection (2024)
20. **Agent Memory** - Knowledge Graph Extraction (2024)
