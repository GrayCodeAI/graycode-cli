package shrike

import "github.com/GrayCodeAI/shrike/internal/filter"

// Option configures compression behavior.
type Option interface {
	apply(*config)
}

// Pre-built option presets (use directly as options).
var (
	Minimal    Option = WithMode(ModeMinimal)
	Aggressive Option = WithMode(ModeAggressive)
	Surface    Option = WithTier(TierSurface)
	Adaptive   Option = WithTier(TierAdaptive)
	Code       Option = WithTier(TierCode)
	Log        Option = WithTier(TierLog)
)

// Mode controls compression aggressiveness.
type Mode string

const (
	ModeMinimal    Mode = "minimal"
	ModeAggressive Mode = "aggressive"
)

// Tier selects a pre-built pipeline profile.
type Tier string

const (
	TierSurface  Tier = "surface"  // 4 layers, fast
	TierTrim     Tier = "trim"     // 8 layers, balanced
	TierExtract  Tier = "extract"  // 20 layers, max compression
	TierCore     Tier = "core"     // 20 layers, quality-first
	TierCode     Tier = "code"     // code-aware
	TierLog      Tier = "log"      // log-aware
	TierThread   Tier = "thread"   // conversation-aware
	TierAdaptive Tier = "adaptive" // auto-detect content type
)

// WithMode sets the compression mode.
func WithMode(m Mode) Option {
	return optFunc(func(c *config) { c.mode = m })
}

// WithBudget sets a hard token limit for the output.
// A value <= 0 disables the budget cap entirely: no truncation is applied
// (structural compression layers still run). Passing WithBudget(0) therefore
// means "no budget", not "zero-token output".
func WithBudget(tokens int) Option {
	return optFunc(func(c *config) { c.budget = tokens })
}

// WithMetaToken enables the lossless meta-token compression layer for repeated
// token sequences. It is OFF by default: the layer replaces repeated spans
// with [META:...] placeholders whose originals live only inside the pipeline
// instance, so the string returned by the stateless Compress() API would be a
// data-losing digest for repetitive input. Enable it only when the consumer
// can round-trip through a live pipeline that decompresses.
func WithMetaToken() Option {
	return optFunc(func(c *config) { c.metaToken = true })
}

// WithQuery provides intent context for goal-driven filtering.
func WithQuery(intent string) Option {
	return optFunc(func(c *config) { c.query = intent })
}

// WithModel sets the target LLM model and auto-selects the appropriate BPE encoding.
// This configures both the model name (for cost calculations) and the tokenizer encoding.
//
// Supported model prefixes:
//   - OpenAI: gpt-4, gpt-4o, gpt-4.1, gpt-3.5-turbo, o1, o3, o4
//   - Anthropic: claude-3, claude-3.5, claude-4
//   - Google: gemini-1.5, gemini-2.0, gemini-2.5
//
// Unknown models fall back to cl100k_base encoding.
func WithModel(model string) Option {
	return optFunc(func(c *config) {
		c.model = model
		c.encoding = string(GetEncodingForModel(model))
	})
}

// WithTier selects a pipeline profile.
func WithTier(t Tier) Option {
	return optFunc(func(c *config) { c.tier = t })
}

// WithCodeAware marks the input as source code and activates symbol
// preservation. Lines that declare semantically significant symbols
// (function/type/export declarations and their signatures) are identified via
// the configured SymbolProvider and guarded so that downstream compression
// stages can never strip them: any protected line removed by the pipeline is
// re-injected into the output.
//
// The lang argument is a language name as understood by the chunker (e.g.
// "go", "python", "typescript", "rust", "java"). An empty string triggers
// best-effort auto-detection.
//
// The default SymbolProvider is regex-backed (RegexSymbolProvider, using the
// chunker's symbol patterns). Pass a custom provider — e.g. an LSP-backed one —
// with WithSymbolProvider.
func WithCodeAware(language string) Option {
	return optFunc(func(c *config) {
		c.codeAware = true
		c.codeLang = language
	})
}

// WithSymbolProvider overrides the SymbolProvider used by WithCodeAware. It
// lets an embedder (e.g. hawk) inject a real LSP-backed provider in place of
// the default regex implementation. Passing a nil provider is a no-op.
func WithSymbolProvider(p SymbolProvider) Option {
	return optFunc(func(c *config) {
		if p != nil {
			c.symbolProvider = p
		}
	})
}

// WithCustomFilters registers user-defined regex find/replace rules (see
// FilterRule / LoadFilterRules) to run as a post-pipeline stage. The rules are
// compiled once into a CustomFilter and applied in ascending priority order to
// the compressed output; invalid patterns are skipped with a logged warning.
//
// Passing nil or an empty slice is a no-op.
func WithCustomFilters(rules []FilterRule) Option {
	return optFunc(func(c *config) {
		if len(rules) == 0 {
			return
		}
		c.customFilters = NewCustomFilter(rules)
	})
}

// WithLLMLinguaProse enables the opt-in LLMLingua prose compression layer.
// It drops low-information sentences from natural-language prose using a local
// perplexity proxy (no model calls); code and short inputs are passed through
// unchanged. It is disabled unless explicitly requested.
func WithLLMLinguaProse() Option {
	return optFunc(func(c *config) { c.llmLinguaProse = true })
}

type optFunc func(*config)

func (f optFunc) apply(c *config) { f(c) }

type config struct {
	mode           Mode
	budget         int
	query          string
	tier           Tier
	model          string
	encoding       string
	llmLinguaProse bool
	codeAware      bool
	codeLang       string
	symbolProvider SymbolProvider
	customFilters  *CustomFilter
	metaToken      bool

	perplexityEnabled   bool
	perplexityScorer    PerplexityScorer
	perplexityDropRatio float64
}

func buildConfig(opts []Option) config {
	cfg := config{mode: ModeMinimal}
	for _, opt := range opts {
		opt.apply(&cfg)
	}
	return cfg
}

func (c *config) toPipelineConfig() filter.PipelineConfig {
	mode := filter.ModeMinimal
	if c.mode == ModeAggressive {
		mode = filter.ModeAggressive
	}

	var cfg filter.PipelineConfig
	if c.tier != "" {
		cfg = filter.TierConfig(filter.Tier(c.tier), mode)
	} else {
		cfg = filter.TierConfig(filter.TierCore, mode)
	}

	cfg.Budget = c.budget
	cfg.QueryIntent = c.query
	cfg.EnableLLMLinguaProse = c.llmLinguaProse
	cfg.EnableMetaToken = c.metaToken
	return cfg
}
