<!--
  Thanks for your contribution! Please fill out this template so reviewers can
  understand the change quickly. Anything that does not apply can be left in
  place; do not delete unanswered sections — write "n/a".
-->

## Summary

<!--
  One paragraph describing what this PR does and why. Link the related
  issue(s) with `Fixes #N` or `Refs #N` if applicable.
-->

## Changes

<!--
  Bullet list of what changed, grouped by area (filters, pipeline, CLI,
  config, CI, etc.). Reviewers should be able to skim this and know what to
  look at first.
-->

-

## Compression / token-reduction impact

<!--
  If this PR touches a compression filter or the pipeline, paste the
  before/after numbers from `make benchmark-adaptive` or
  `make benchmark-suite`. If it does not affect compression, write "n/a".
-->

```text
$ make benchmark-suite
...
```

## Testing

<!--
  Describe how you tested. Paste output of `make test` and `make lint`. If
  you added new tests, list them.
-->

```text
$ make test
...
$ make lint
...
```

## Checklist

- [ ] Commits follow [Conventional Commits](https://www.conventionalcommits.org/)
      so release-please picks them up correctly (`feat:`, `fix:`, `perf:`,
      `refactor:`, `docs:`, etc.)
- [ ] `make build` passes
- [ ] `make lint` passes (no new lint findings, no `nolint:…` without justification)
- [ ] `make test-race` passes locally
- [ ] New or changed code has tests (table-driven where appropriate)
- [ ] Public APIs in `tok.go` / `internal/...` exported surfaces have godoc
      comments
- [ ] `CHANGELOG.md` updated under `## [Unreleased]` if user-visible
- [ ] No regression in compression ratio for existing scenarios (or a
      deliberate trade-off is documented)
- [ ] No secrets, tokens, or PII added to the repo
- [ ] No `Co-authored-by:` trailers (this is individual-developer work)
