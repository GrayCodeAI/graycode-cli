# Provenance Notes

- Command:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./benchmarks/run.sh'`
- Verification:
  `/bin/zsh -lc 'GOCACHE=$PWD/.gocache go test ./... -count=1'`
- Environment:
  local workspace run on `2026-06-27`
  `goos=darwin`
  `goarch=arm64`
  `cpu=Apple M1`
- Caveats:
  root-package benchmark timings are point-in-time local measurements, not CI medians
  the quality harness uses a checked-in offline sample corpus rather than an external public benchmark dataset
