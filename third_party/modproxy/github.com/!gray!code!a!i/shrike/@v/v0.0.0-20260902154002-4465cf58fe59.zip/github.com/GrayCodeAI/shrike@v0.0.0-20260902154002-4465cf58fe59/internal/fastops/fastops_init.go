// Package fastops — platform-specific dispatch variables.
//
// FastHasANSI and FastCountBytes automatically select the fastest
// implementation based on runtime CPU detection (see detect.go).

package fastops

// avx2HasANSI is set to the AVX2 implementation on amd64 when HasAVX2 is true;
// nil on other platforms or when AVX2 is not available.
var avx2HasANSI func(string) bool

// avx2CountBytes is set to the AVX2 implementation on amd64 when HasAVX2 is true;
// nil on other platforms or when AVX2 is not available.
var avx2CountBytes func(string, byte) int
