package internal

import "errors"

// Sentinel errors for shrike pipeline operations.
var (
	// ErrConfigInvalid indicates a configuration validation failure.
	ErrConfigInvalid = errors.New("invalid configuration")

	// ErrInputTooLarge indicates the input exceeds the maximum context tokens.
	ErrInputTooLarge = errors.New("input exceeds maximum context tokens")

	// ErrPipelineFailed indicates a pipeline processing failure.
	ErrPipelineFailed = errors.New("pipeline processing failed")

	// ErrChunkFailed indicates a chunk processing failure within the pipeline.
	ErrChunkFailed = errors.New("chunk processing failed")

	// ErrCacheMiss indicates a cache lookup miss (not an error, used for control flow).
	ErrCacheMiss = errors.New("cache miss")

	// ErrCommandBlocked indicates a command was blocked by safety checks.
	ErrCommandBlocked = errors.New("command blocked")

	// ErrReversibleNotFound indicates no reversible entry was found for a hash prefix.
	ErrReversibleNotFound = errors.New("reversible entry not found")
)
