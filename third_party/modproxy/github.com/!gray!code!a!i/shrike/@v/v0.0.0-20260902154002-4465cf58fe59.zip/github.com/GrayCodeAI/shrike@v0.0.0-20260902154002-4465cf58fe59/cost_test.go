package shrike

import (
	"sort"
	"testing"
)

func TestModelPricing_Structure(t *testing.T) {
	pricing := ModelPricing{
		InputPricePer1K:  0.0025,
		OutputPricePer1K: 0.01,
	}

	if pricing.InputPricePer1K != 0.0025 {
		t.Errorf("InputPricePer1K = %f, want 0.0025", pricing.InputPricePer1K)
	}
	if pricing.OutputPricePer1K != 0.01 {
		t.Errorf("OutputPricePer1K = %f, want 0.01", pricing.OutputPricePer1K)
	}
}

func TestGetModelPricing_KnownModels(t *testing.T) {
	tests := []struct {
		model      string
		wantFound  bool
		wantInput  float64
		wantOutput float64
	}{
		{"gpt-4o", true, 0.0025, 0.01},
		{"gpt-4o-mini", true, 0.00015, 0.0006},
		{"claude-opus", true, 0.015, 0.075},
		{"claude-sonnet", true, 0.003, 0.015},
		{"claude-haiku", true, 0.00025, 0.00125},
		{"gemini-pro", true, 0.00025, 0.0005},
		{"deepseek-v2", true, 0.00014, 0.00028},
		{"mistral-large", true, 0.004, 0.012},
		{"unknown-model", false, 0, 0},
	}

	for _, tt := range tests {
		t.Run(tt.model, func(t *testing.T) {
			pricing, ok := GetModelPricing(tt.model)
			if ok != tt.wantFound {
				t.Errorf("GetModelPricing(%q) found = %v, want %v", tt.model, ok, tt.wantFound)
			}
			if ok {
				if pricing.InputPricePer1K != tt.wantInput {
					t.Errorf("InputPricePer1K = %f, want %f", pricing.InputPricePer1K, tt.wantInput)
				}
				if pricing.OutputPricePer1K != tt.wantOutput {
					t.Errorf("OutputPricePer1K = %f, want %f", pricing.OutputPricePer1K, tt.wantOutput)
				}
			}
		})
	}
}

func TestGetModelPricing_CaseInsensitive(t *testing.T) {
	tests := []struct {
		model     string
		wantFound bool
	}{
		{"GPT-4O", true},
		{"Gpt-4o", true},
		{"gpt-4o", true},
		{"CLAUDE-OPUS", true},
		{"  gpt-4o  ", true},
	}

	for _, tt := range tests {
		t.Run(tt.model, func(t *testing.T) {
			_, ok := GetModelPricing(tt.model)
			if ok != tt.wantFound {
				t.Errorf("GetModelPricing(%q) found = %v, want %v", tt.model, ok, tt.wantFound)
			}
		})
	}
}

func TestRegisterModelPricing(t *testing.T) {
	// Save original state
	origPricing := make(map[string]ModelPricing)
	for k, v := range modelPricingRegistry {
		origPricing[k] = v
	}
	defer func() { modelPricingRegistry = origPricing }()

	// Register a new model
	RegisterModelPricing("custom-model", 0.005, 0.02)

	pricing, ok := GetModelPricing("custom-model")
	if !ok {
		t.Fatal("expected custom-model to be registered")
	}
	if pricing.InputPricePer1K != 0.005 {
		t.Errorf("InputPricePer1K = %f, want 0.005", pricing.InputPricePer1K)
	}
	if pricing.OutputPricePer1K != 0.02 {
		t.Errorf("OutputPricePer1K = %f, want 0.02", pricing.OutputPricePer1K)
	}
}

func TestRegisterModelPricing_Override(t *testing.T) {
	// Snapshot the registry under the read lock, then restore it under the
	// write lock on cleanup. Capturing the map by reference (without the copy)
	// would not actually undo the override because RegisterModelPricing mutates
	// the map in place.
	pricingMu.RLock()
	origPricing := make(map[string]ModelPricing, len(modelPricingRegistry))
	for k, v := range modelPricingRegistry {
		origPricing[k] = v
	}
	pricingMu.RUnlock()
	t.Cleanup(func() {
		pricingMu.Lock()
		modelPricingRegistry = origPricing
		pricingMu.Unlock()
	})

	// Override existing model
	RegisterModelPricing("gpt-4o", 0.003, 0.012)

	pricing, ok := GetModelPricing("gpt-4o")
	if !ok {
		t.Fatal("expected gpt-4o to be found")
	}
	if pricing.InputPricePer1K != 0.003 {
		t.Errorf("InputPricePer1K = %f, want 0.003", pricing.InputPricePer1K)
	}
}

func TestEstimateCostSavings_KnownModel(t *testing.T) {
	stats := Stats{
		TokensSaved: 10000,
	}

	savings := EstimateCostSavings(stats, "gpt-4o")
	// gpt-4o input: $0.0025 per 1K tokens
	// 10000 tokens = 10 * 0.0025 = $0.025
	expected := 0.025
	if savings != expected {
		t.Errorf("EstimateCostSavings = %f, want %f", savings, expected)
	}
}

func TestEstimateCostSavings_UnknownModel(t *testing.T) {
	stats := Stats{
		TokensSaved: 10000,
	}

	savings := EstimateCostSavings(stats, "unknown-model")
	if savings != 0 {
		t.Errorf("EstimateCostSavings for unknown model = %f, want 0", savings)
	}
}

func TestEstimateCostSavings_ZeroSaved(t *testing.T) {
	stats := Stats{
		TokensSaved: 0,
	}

	savings := EstimateCostSavings(stats, "gpt-4o")
	if savings != 0 {
		t.Errorf("EstimateCostSavings with zero saved = %f, want 0", savings)
	}
}

func TestEstimateCostSavings_TableDriven(t *testing.T) {
	tests := []struct {
		name        string
		tokensSaved int
		model       string
		wantSavings float64
	}{
		{
			name:        "small savings gpt-4o",
			tokensSaved: 1000,
			model:       "gpt-4o",
			wantSavings: 0.0025,
		},
		{
			name:        "large savings claude-opus",
			tokensSaved: 100000,
			model:       "claude-opus",
			wantSavings: 1.5, // 100 * 0.015
		},
		{
			name:        "cheap model deepseek",
			tokensSaved: 50000,
			model:       "deepseek-v2",
			wantSavings: 0.007, // 50 * 0.00014
		},
		{
			name:        "zero saved",
			tokensSaved: 0,
			model:       "gpt-4o",
			wantSavings: 0,
		},
		{
			name:        "unknown model",
			tokensSaved: 10000,
			model:       "nonexistent",
			wantSavings: 0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			stats := Stats{TokensSaved: tt.tokensSaved}
			got := EstimateCostSavings(stats, tt.model)
			if diff := got - tt.wantSavings; diff > 1e-9 || diff < -1e-9 {
				t.Errorf("EstimateCostSavings() = %f, want %f", got, tt.wantSavings)
			}
		})
	}
}

func TestFormatCostSavings(t *testing.T) {
	tests := []struct {
		name         string
		tokensSaved  int
		model        string
		wantEmpty    bool
		wantContains string
	}{
		{
			name:         "normal savings",
			tokensSaved:  10000,
			model:        "gpt-4o",
			wantEmpty:    false,
			wantContains: "saved",
		},
		{
			name:        "unknown model returns empty",
			tokensSaved: 10000,
			model:       "unknown",
			wantEmpty:   true,
		},
		{
			name:        "zero savings returns empty",
			tokensSaved: 0,
			model:       "gpt-4o",
			wantEmpty:   true,
		},
		{
			name:         "large savings",
			tokensSaved:  1000000,
			model:        "claude-opus",
			wantEmpty:    false,
			wantContains: "saved",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			stats := Stats{TokensSaved: tt.tokensSaved}
			result := FormatCostSavings(stats, tt.model)

			if tt.wantEmpty && result != "" {
				t.Errorf("FormatCostSavings() = %q, want empty", result)
			}
			if !tt.wantEmpty && result == "" {
				t.Error("FormatCostSavings() returned empty, want non-empty")
			}
			if !tt.wantEmpty && tt.wantContains != "" {
				if !contains(result, tt.wantContains) {
					t.Errorf("FormatCostSavings() = %q, want to contain %q", result, tt.wantContains)
				}
			}
		})
	}
}

func TestFormatCostSavings_Format(t *testing.T) {
	tests := []struct {
		name        string
		tokensSaved int
		model       string
		wantPrefix  string
	}{
		{
			name:        "small amount uses 4 decimals",
			tokensSaved: 1000,
			model:       "gpt-4o",
			wantPrefix:  "$0.00",
		},
		{
			name:        "normal amount uses 2 decimals",
			tokensSaved: 100000,
			model:       "gpt-4o",
			wantPrefix:  "$0.25",
		},
		{
			name:        "large amount",
			tokensSaved: 1000000,
			model:       "gpt-4o",
			wantPrefix:  "$2.50",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			stats := Stats{TokensSaved: tt.tokensSaved}
			result := FormatCostSavings(stats, tt.model)

			if !contains(result, tt.wantPrefix) {
				t.Errorf("FormatCostSavings() = %q, want to contain %q", result, tt.wantPrefix)
			}
			if !contains(result, "saved") {
				t.Errorf("FormatCostSavings() = %q, want to contain 'saved'", result)
			}
		})
	}
}

func TestListModels(t *testing.T) {
	models := ListModels()

	if len(models) == 0 {
		t.Error("ListModels() returned empty slice")
	}

	// Check that some known models are included
	found := make(map[string]bool)
	for _, m := range models {
		found[m] = true
	}

	expectedModels := []string{"gpt-4o", "claude-opus", "gemini-pro"}
	for _, m := range expectedModels {
		if !found[m] {
			t.Errorf("ListModels() missing expected model %q", m)
		}
	}

	// ListModels must return models in sorted order (deterministic).
	if !sort.StringsAreSorted(models) {
		t.Errorf("ListModels() not sorted: %v", models)
	}
}

func TestListModels_NoDuplicates(t *testing.T) {
	models := ListModels()

	seen := make(map[string]bool)
	for _, m := range models {
		if seen[m] {
			t.Errorf("ListModels() contains duplicate: %q", m)
		}
		seen[m] = true
	}
}

func TestEstimateCost(t *testing.T) {
	// gpt-4o input pricing is $0.0025 per 1K tokens.
	pricing, ok := GetModelPricing("gpt-4o")
	if !ok {
		t.Fatal("expected gpt-4o pricing to be registered")
	}

	text := "Hello, world! This is a test of the EstimateCost function."
	tokens := EstimateTokensForModel(text, "gpt-4o")
	want := float64(tokens) / 1000 * pricing.InputPricePer1K

	got := EstimateCost(text, "gpt-4o")
	if got != want {
		t.Errorf("EstimateCost = %v, want %v", got, want)
	}
	if got == 0 {
		t.Error("expected non-zero cost for gpt-4o")
	}
}

func TestEstimateCost_UnknownModel(t *testing.T) {
	if got := EstimateCost("some text", "totally-fake-model-xyz"); got != 0 {
		t.Errorf("EstimateCost for unknown model = %v, want 0", got)
	}
}

func TestEstimateCost_EmptyText(t *testing.T) {
	if got := EstimateCost("", "gpt-4o"); got != 0 {
		t.Errorf("EstimateCost for empty text = %v, want 0", got)
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || len(s) > 0 && containsSubstring(s, substr))
}

func containsSubstring(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}
