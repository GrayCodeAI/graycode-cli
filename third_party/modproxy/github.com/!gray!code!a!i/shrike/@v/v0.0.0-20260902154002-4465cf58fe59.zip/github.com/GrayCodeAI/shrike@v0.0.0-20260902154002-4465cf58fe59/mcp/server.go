// Package mcp provides a minimal in-memory MCP (Model Context Protocol) server
// pre-loaded with shrike tools.
//
// The implementation is deliberately small: it is an in-process registry +
// dispatcher with no stdio/HTTP/SSE transport. Host applications that need
// transport wire this package's *MCPServer into their own MCP daemon (for
// example, hawk's internal/mcp package exposes it to MCP-compatible agents).
//
// The three default tools wired up by NewTokServer call the real shrike package
// APIs rather than stub implementations:
//
//   - count_tokens      → shrike.EstimateTokensForModel (BPE) or shrike.EstimateTokens
//   - estimate_cost     → shrike.GetModelPricing × (inputTokens + outputTokens)
//   - compress_text     → shrike.Compress with the caller-supplied options
//
// Tool authors can also use the bare NewServer + RegisterTool for custom
// surfaces.
package mcp

import (
	"context"
	"errors"
	"fmt"
	"sync"

	shrike "github.com/GrayCodeAI/shrike"
)

const maxInputSize = 16 << 20 // 16 MiB

type ToolHandler func(ctx context.Context, params map[string]interface{}) (interface{}, error)

type ToolDef struct {
	Name        string                 `json:"name"`
	Description string                 `json:"description"`
	InputSchema map[string]interface{} `json:"inputSchema"`
}

type MCPServer struct {
	name  string
	tools map[string]toolEntry
	mu    sync.RWMutex
}

type toolEntry struct {
	def     ToolDef
	handler ToolHandler
}

// NewServer creates an empty MCP server with the given name. Tools must be
// registered with RegisterTool before the server is useful.
func NewServer(name string) *MCPServer {
	return &MCPServer{name: name, tools: make(map[string]toolEntry)}
}

// RegisterTool adds a tool to the server. Re-registering an existing name
// overwrites the previous definition and handler.
func (s *MCPServer) RegisterTool(name, description string, schema map[string]interface{}, handler ToolHandler) {
	s.mu.Lock()
	s.tools[name] = toolEntry{def: ToolDef{Name: name, Description: description, InputSchema: schema}, handler: handler}
	s.mu.Unlock()
}

// ListTools returns the registered tool definitions. Order is not stable.
func (s *MCPServer) ListTools() []ToolDef {
	s.mu.RLock()
	defs := make([]ToolDef, 0, len(s.tools))
	for _, e := range s.tools {
		defs = append(defs, e.def)
	}
	s.mu.RUnlock()
	return defs
}

var ErrInputTooLarge = errors.New("input exceeds maximum size (16 MiB)")

// checkTextSize validates that a text parameter does not exceed maxInputSize.
func checkTextSize(text string) error {
	if len(text) > maxInputSize {
		return ErrInputTooLarge
	}
	return nil
}

// HandleRequest dispatches a JSON-RPC-style request to the registered tool.
// Supported methods: "tools/list" (no params) and "tools/call" (params must
// include "name" and optional "arguments" map).
func (s *MCPServer) HandleRequest(ctx context.Context, method string, params map[string]interface{}) (interface{}, error) {
	switch method {
	case "tools/list":
		return s.ListTools(), nil
	case "tools/call":
		name, _ := params["name"].(string)
		if name == "" {
			return nil, fmt.Errorf("tools/call: missing tool name")
		}
		s.mu.RLock()
		entry, ok := s.tools[name]
		s.mu.RUnlock()
		if !ok {
			return nil, fmt.Errorf("tools/call: unknown tool %q", name)
		}
		args, _ := params["arguments"].(map[string]interface{})
		if args == nil {
			args = make(map[string]interface{})
		}
		return entry.handler(ctx, args)
	default:
		return nil, fmt.Errorf("unsupported method %q", method)
	}
}

// NewTokServer creates an MCP server pre-registered with the standard shrike
// tool surface. The registered tools call the real shrike package APIs:
//
//   - count_tokens(text, model) → real BPE-backed token count
//   - estimate_cost(model, inputTokens, outputTokens) → real pricing-table cost
//   - compress_text(text, mode) → real 31-layer compression pipeline
//   - redact_secrets(text)      → real 33-pattern secret detector
func NewTokServer() *MCPServer {
	s := NewServer("shrike")

	s.RegisterTool("count_tokens",
		"Count tokens in text using shrike's BPE tokenizer (cl100k/o200k/etc.). Pass model='heuristic' for a fast character-based estimate.",
		map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"text":  map[string]interface{}{"type": "string", "description": "Input text to count tokens for"},
				"model": map[string]interface{}{"type": "string", "description": "Model name (e.g. gpt-4o, claude-sonnet) or 'heuristic' for a fast estimate"},
			},
			"required": []string{"text"},
		},
		countTokensHandler)

	s.RegisterTool("estimate_cost",
		"Estimate the dollar cost for input + output tokens at the model's registered price-per-1K. Returns 0 for unknown models.",
		map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"model":        map[string]interface{}{"type": "string", "description": "Model name (e.g. gpt-4o, claude-sonnet)"},
				"inputTokens":  map[string]interface{}{"type": "number", "description": "Number of input tokens"},
				"outputTokens": map[string]interface{}{"type": "number", "description": "Number of output tokens"},
			},
			"required": []string{"model", "inputTokens", "outputTokens"},
		},
		estimateCostHandler)

	s.RegisterTool("compress_text",
		"Compress text using shrike's full pipeline. Returns the compressed string and per-stage stats. Optional 'mode' parameter selects the compression preset (minimal, aggressive, surface, adaptive, code, log).",
		map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"text": map[string]interface{}{"type": "string", "description": "Text to compress"},
				"mode": map[string]interface{}{
					"type":        "string",
					"description": "Compression preset: minimal | aggressive | surface | adaptive | code | log (default: minimal)",
					"enum":        []string{"minimal", "aggressive", "surface", "adaptive", "code", "log"},
				},
				"budget": map[string]interface{}{"type": "number", "description": "Optional token budget to enforce"},
			},
			"required": []string{"text"},
		},
		compressTextHandler)

	s.RegisterTool("redact_secrets",
		"Detect and redact secrets (API keys, AWS tokens, GitHub tokens, private keys, JWTs, etc.) from text. Returns redacted text and the count of matches found.",
		map[string]interface{}{
			"type": "object",
			"properties": map[string]interface{}{
				"text":             map[string]interface{}{"type": "string", "description": "Text to scan for secrets"},
				"entropyThreshold": map[string]interface{}{"type": "number", "description": "Optional Shannon-entropy threshold (default 4.5) to also catch high-entropy blobs that pattern matching misses"},
			},
			"required": []string{"text"},
		},
		redactSecretsHandler)

	return s
}

// countTokensHandler wires the MCP count_tokens tool to shrike's real estimator.
func countTokensHandler(_ context.Context, p map[string]interface{}) (interface{}, error) {
	text, _ := p["text"].(string)
	if text == "" {
		return nil, fmt.Errorf("count_tokens: text required")
	}
	if err := checkTextSize(text); err != nil {
		return nil, err
	}
	model, _ := p["model"].(string)
	if model == "" || model == "heuristic" {
		return map[string]interface{}{
			"text":  text,
			"model": "heuristic",
			"count": shrike.EstimateTokens(text),
		}, nil
	}
	return map[string]interface{}{
		"text":  text,
		"model": model,
		"count": shrike.EstimateTokensForModel(text, model),
	}, nil
}

// estimateCostHandler wires the MCP estimate_cost tool to shrike's real
// pricing registry. Returns totalCost = input/1000 * inputPrice +
// output/1000 * outputPrice. totalCost is 0 for unknown models.
func estimateCostHandler(_ context.Context, p map[string]interface{}) (interface{}, error) {
	model, _ := p["model"].(string)
	if model == "" {
		return nil, fmt.Errorf("estimate_cost: model required")
	}
	in, okIn := numberFromParams(p, "inputTokens")
	out, okOut := numberFromParams(p, "outputTokens")
	if !okIn || !okOut {
		return nil, fmt.Errorf("estimate_cost: inputTokens and outputTokens required")
	}
	pricing, found := shrike.GetModelPricing(model)
	if !found {
		return map[string]interface{}{
			"model":        model,
			"inputTokens":  in,
			"outputTokens": out,
			"totalCost":    0.0,
			"currency":     "USD",
			"known":        false,
			"warning":      fmt.Sprintf("model %q is not in the pricing registry; call shrike.RegisterModelPricing to add it", model),
		}, nil
	}
	total := (in/1000)*pricing.InputPricePer1K + (out/1000)*pricing.OutputPricePer1K
	return map[string]interface{}{
		"model":            model,
		"inputTokens":      in,
		"outputTokens":     out,
		"inputPricePer1K":  pricing.InputPricePer1K,
		"outputPricePer1K": pricing.OutputPricePer1K,
		"totalCost":        total,
		"currency":         "USD",
		"known":            true,
	}, nil
}

// compressTextHandler wires the MCP compress_text tool to shrike.Compress.
// Optional mode parameter maps to one of the public preset variables.
func compressTextHandler(_ context.Context, p map[string]interface{}) (interface{}, error) {
	text, _ := p["text"].(string)
	if text == "" {
		return nil, fmt.Errorf("compress_text: text required")
	}
	if err := checkTextSize(text); err != nil {
		return nil, err
	}
	mode, _ := p["mode"].(string)
	opts := buildCompressOptions(mode, p)
	out, stats := shrike.Compress(text, opts...)
	return map[string]interface{}{
		"original":       text,
		"compressed":     out,
		"originalTokens": stats.OriginalTokens,
		"finalTokens":    stats.FinalTokens,
		"tokensSaved":    stats.TokensSaved,
		"reductionPct":   stats.ReductionPercent,
		"mode":           mode,
		"model":          stats.Model,
		"costSavingsUSD": stats.CostSavings,
	}, nil
}

// redactSecretsHandler wires the MCP redact_secrets tool to the real
// SecretDetector. If entropyThreshold is set, the detector also runs
// Shannon-entropy analysis to catch blobs the pattern table misses.
func redactSecretsHandler(_ context.Context, p map[string]interface{}) (interface{}, error) {
	text, _ := p["text"].(string)
	if text == "" {
		return nil, fmt.Errorf("redact_secrets: text required")
	}
	if err := checkTextSize(text); err != nil {
		return nil, err
	}
	entropy, hasEntropy := numberFromParams(p, "entropyThreshold")
	det := shrike.NewSecretDetector()
	var matches []shrike.SecretMatch
	var redacted string
	if hasEntropy {
		matches = det.DetectSecrets(text)
		redacted = det.RedactSecrets(text)
		if entropy > 0 {
			redacted = det.DetectAndRedactWithEntropy(text, entropy)
		}
	} else {
		matches = det.DetectSecrets(text)
		redacted = det.RedactSecrets(text)
	}
	return map[string]interface{}{
		"original":   text,
		"redacted":   redacted,
		"matchCount": len(matches),
	}, nil
}

// buildCompressOptions maps the MCP compress_text 'mode' enum to the
// corresponding shrike preset Option, plus an optional budget. Unknown modes
// fall back to the default (no preset) which lets the pipeline use its
// auto-tier selection.
func buildCompressOptions(mode string, p map[string]interface{}) []shrike.Option {
	var opts []shrike.Option
	switch mode {
	case "minimal":
		opts = append(opts, shrike.Minimal)
	case "aggressive":
		opts = append(opts, shrike.Aggressive)
	case "surface":
		opts = append(opts, shrike.Surface)
	case "adaptive":
		opts = append(opts, shrike.Adaptive)
	case "code":
		opts = append(opts, shrike.Code)
	case "log":
		opts = append(opts, shrike.Log)
	}
	if budget, ok := numberFromParams(p, "budget"); ok && budget > 0 {
		opts = append(opts, shrike.WithBudget(int(budget)))
	}
	return opts
}

// numberFromParams returns the float64 value of a key, supporting both
// JSON-number and JSON-decimal inputs as commonly produced by MCP clients.
func numberFromParams(p map[string]interface{}, key string) (float64, bool) {
	v, ok := p[key]
	if !ok {
		return 0, false
	}
	switch n := v.(type) {
	case float64:
		return n, true
	case float32:
		return float64(n), true
	case int:
		return float64(n), true
	case int64:
		return float64(n), true
	}
	return 0, false
}
