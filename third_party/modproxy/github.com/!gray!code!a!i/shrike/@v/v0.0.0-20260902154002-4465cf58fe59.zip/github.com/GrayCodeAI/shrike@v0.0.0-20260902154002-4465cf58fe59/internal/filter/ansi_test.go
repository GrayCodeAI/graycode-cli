package filter

import (
	"strings"
	"testing"
)

func TestNewANSIFilter(t *testing.T) {
	f := NewANSIFilter()
	if f == nil {
		t.Fatal("NewANSIFilter returned nil")
	}
}

func TestANSIFilterName(t *testing.T) {
	f := NewANSIFilter()
	if f.Name() != "ansi" {
		t.Errorf("expected name %q, got %q", "ansi", f.Name())
	}
}

func TestANSIFilterApply(t *testing.T) {
	f := NewANSIFilter()
	input := "\x1b[32mGreen text\x1b[0m and \x1b[1mbold\x1b[0m"
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "\x1b[") {
		t.Error("ANSI codes should be stripped from output")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved from ANSI stripping")
	}
}

func TestANSIFilterApplyNoANSI(t *testing.T) {
	f := NewANSIFilter()
	input := "Plain text without ANSI codes"
	output, saved := f.Apply(input, ModeMinimal)

	if output != input {
		t.Errorf("expected unchanged output for plain text, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for plain text, got %d", saved)
	}
}

func TestANSIFilterApplyEmpty(t *testing.T) {
	f := NewANSIFilter()
	output, saved := f.Apply("", ModeMinimal)

	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for empty input, got %d", saved)
	}
}

func TestANSIFilterApplyVariousCodes(t *testing.T) {
	f := NewANSIFilter()
	tests := []struct {
		name  string
		input string
	}{
		{"color codes", "\x1b[31mRed\x1b[0m \x1b[32mGreen\x1b[0m"},
		{"bold codes", "\x1b[1mBold\x1b[22m"},
		{"cursor codes", "\x1b[2J\x1b[H"},
		{"complex codes", "\x1b[38;5;208mOrange\x1b[0m"},
		{"mixed content", "Before \x1b[34mBlue\x1b[0m After"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			output, _ := f.Apply(tt.input, ModeMinimal)
			if strings.Contains(output, "\x1b[") {
				t.Errorf("ANSI codes not fully stripped from %q", tt.input)
			}
		})
	}
}

func TestStripANSI(t *testing.T) {
	input := "\x1b[32mGreen\x1b[0m text"
	result := StripANSI(input)
	if strings.Contains(result, "\x1b[") {
		t.Error("StripANSI should remove ANSI codes")
	}
	if !strings.Contains(result, "Green") {
		t.Error("StripANSI should preserve text content")
	}
}

func TestStripANSIEmpty(t *testing.T) {
	result := StripANSI("")
	if result != "" {
		t.Errorf("expected empty string, got %q", result)
	}
}

func TestStripANSIPlainText(t *testing.T) {
	input := "Plain text"
	result := StripANSI(input)
	if result != input {
		t.Errorf("expected %q, got %q", input, result)
	}
}

func TestHasANSI(t *testing.T) {
	tests := []struct {
		input    string
		expected bool
	}{
		{"\x1b[32mGreen\x1b[0m", true},
		{"Plain text", false},
		{"", false},
		{"\x1b[1mBold\x1b[0m", true},
		{"No codes here", false},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			result := HasANSI(tt.input)
			if result != tt.expected {
				t.Errorf("HasANSI(%q) = %v, expected %v", tt.input, result, tt.expected)
			}
		})
	}
}

func TestANSIFilterApplyPreservesContent(t *testing.T) {
	f := NewANSIFilter()
	input := "\x1b[32mImportant message\x1b[0m"
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "Important message") {
		t.Error("ANSI filter should preserve text content")
	}
}
