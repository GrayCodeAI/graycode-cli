package fastops

import (
	"math/rand"
	"testing"
)

func BenchmarkEntropyFilter(b *testing.B) {
	sizes := []int{256, 1024, 4096, 16384}
	d := NewDispatcher()

	for _, size := range sizes {
		data := make([]float64, size)
		for i := range data {
			data[i] = rand.Float64()
		}

		b.Run(benchName(size), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				_ = d.EntropyFilter(data)
			}
		})
	}
}

func benchName(size int) string {
	switch {
	case size < 1024:
		return "256B"
	case size < 4096:
		return "1KB"
	case size < 16384:
		return "4KB"
	default:
		return "16KB"
	}
}
