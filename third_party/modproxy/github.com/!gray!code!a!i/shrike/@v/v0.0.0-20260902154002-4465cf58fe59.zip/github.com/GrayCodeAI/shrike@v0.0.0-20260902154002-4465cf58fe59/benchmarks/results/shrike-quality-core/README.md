# `shrike-quality-core` Published Runs

Current published runs:

- `2026-06-27/`

Each published run includes:

- `report.md`
- `result.txt`
- `notes.md`

Reference manifest: `../../manifests/shrike-quality-core.yaml`
