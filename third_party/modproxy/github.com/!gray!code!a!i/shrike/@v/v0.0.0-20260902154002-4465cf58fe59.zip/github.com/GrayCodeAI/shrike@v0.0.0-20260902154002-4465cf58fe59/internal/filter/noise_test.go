package filter

import (
	"strings"
	"testing"
)

func TestFilterProgressBars(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected string
	}{
		{
			name:     "no progress bars",
			input:    "line1\nline2\nline3",
			expected: "line1\nline2\nline3",
		},
		{
			name:     "progress bar at line start",
			input:    "line1\n[####] 50%\nline2",
			expected: "line1\nline2",
		},
		{
			name:     "empty input",
			input:    "",
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := FilterProgressBars(tt.input)
			if result != tt.expected {
				t.Errorf("FilterProgressBars() = %q, expected %q", result, tt.expected)
			}
		})
	}
}

func TestFilterProgressBarsPreservesContent(t *testing.T) {
	input := "line1\n[####] 50%\n\nline2"
	result := FilterProgressBars(input)
	if strings.Contains(result, "[####]") {
		t.Error("progress bar should be removed")
	}
	if !strings.Contains(result, "line1") {
		t.Error("line1 should be preserved")
	}
	if !strings.Contains(result, "line2") {
		t.Error("line2 should be preserved")
	}
}

func TestCleanInlineProgress(t *testing.T) {
	tests := []struct {
		input    string
		expected string
	}{
		{"No progress here", "No progress here"},
		{"", ""},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			result := cleanInlineProgress(tt.input)
			if result != tt.expected {
				t.Errorf("cleanInlineProgress(%q) = %q, expected %q", tt.input, result, tt.expected)
			}
		})
	}
}

func TestFilterNoisyOutput(t *testing.T) {
	tests := []struct {
		name  string
		input string
		check func(string) bool
	}{
		{
			name:  "removes ANSI codes",
			input: "\x1b[32mGreen\x1b[0m text",
			check: func(result string) bool {
				return !strings.Contains(result, "\x1b[")
			},
		},
		{
			name:  "removes carriage returns",
			input: "line1\r\nline2\r\n",
			check: func(result string) bool {
				return !strings.Contains(result, "\r")
			},
		},
		{
			name:  "limits blank lines",
			input: "line1\n\n\n\n\nline2",
			check: func(result string) bool {
				return strings.Count(result, "\n\n\n") == 0
			},
		},
		{
			name:  "preserves content",
			input: "Important message\nError: something failed",
			check: func(result string) bool {
				return strings.Contains(result, "Important message") &&
					strings.Contains(result, "Error: something failed")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := FilterNoisyOutput(tt.input)
			if !tt.check(result) {
				t.Errorf("FilterNoisyOutput(%q) = %q, check failed", tt.input, result)
			}
		})
	}
}

func TestFilterNoisyOutputEmpty(t *testing.T) {
	result := FilterNoisyOutput("")
	if result != "" {
		t.Errorf("expected empty string, got %q", result)
	}
}

func TestFilterNoisyOutputRemovesProgressBars(t *testing.T) {
	input := "line1\n[####] 50%\nline2"
	result := FilterNoisyOutput(input)
	if strings.Contains(result, "[####]") {
		t.Error("FilterNoisyOutput should remove progress bars")
	}
}

func TestProgressRegex(t *testing.T) {
	if progressRegex == nil {
		t.Fatal("progressRegex should be initialized")
	}
}

func TestProgressLineRegex(t *testing.T) {
	if progressLineRegex == nil {
		t.Fatal("progressLineRegex should be initialized")
	}
}
