package cache

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestIsGitRepoNonExistent(t *testing.T) {
	dir := filepath.Join(os.TempDir(), "nonexistent-git-test")
	result := IsGitRepo(dir)
	if result {
		t.Error("expected false for non-existent directory")
	}
}

func TestIsGitRepoPlainDir(t *testing.T) {
	dir := t.TempDir()
	result := IsGitRepo(dir)
	if result {
		t.Error("expected false for plain directory without .git")
	}
}

func TestIsGitRepoWithDotGit(t *testing.T) {
	dir := t.TempDir()
	dotGit := filepath.Join(dir, ".git")
	if err := os.MkdirAll(dotGit, 0o755); err != nil {
		t.Fatal(err)
	}
	result := IsGitRepo(dir)
	if !result {
		t.Error("expected true for directory with .git subdirectory")
	}
}

func TestNewGitWatcher(t *testing.T) {
	qc, err := NewQueryCache("")
	if err != nil {
		t.Fatal(err)
	}
	w := NewGitWatcher(qc)
	if w == nil {
		t.Fatal("NewGitWatcher returned nil")
	}
	if w.repoStates == nil {
		t.Error("repoStates map should be initialized")
	}
	if w.cache != qc {
		t.Error("cache reference should match")
	}
}

func TestGetChangedFilesEmpty(t *testing.T) {
	dir := t.TempDir()
	gitInit(t, dir)
	gitCreateFile(t, dir, "initial.txt", "init")

	files, err := GetChangedFiles(dir, "HEAD", "HEAD")
	if err != nil {
		t.Fatalf("GetChangedFiles returned error: %v", err)
	}
	if len(files) != 0 {
		t.Errorf("expected 0 changed files between same commit, got %d", len(files))
	}
}

func TestGetChangedFilesWithChanges(t *testing.T) {
	dir := t.TempDir()
	gitInit(t, dir)
	gitCreateFile(t, dir, "initial.txt", "init")

	firstCommit := gitHead(t, dir)

	gitCreateFile(t, dir, "test.txt", "content")

	files, err := GetChangedFiles(dir, firstCommit, "HEAD")
	if err != nil {
		t.Fatalf("GetChangedFiles returned error: %v", err)
	}
	if len(files) == 0 {
		t.Error("expected changed files between commits")
	}
}

func TestGetFileHashes(t *testing.T) {
	dir := t.TempDir()
	gitInit(t, dir)
	gitCreateFile(t, dir, "foo.txt", "hello")

	qc, _ := NewQueryCache("")
	w := NewGitWatcher(qc)
	hashes, err := w.GetFileHashes(dir, []string{"foo.txt"})
	if err != nil {
		t.Fatalf("GetFileHashes returned error: %v", err)
	}
	if _, ok := hashes[".git/HEAD"]; !ok {
		t.Error("expected .git/HEAD hash")
	}
}

func TestGetFileHashesNonGitDir(t *testing.T) {
	dir := t.TempDir()
	srcFile := filepath.Join(dir, "test.txt")
	if err := os.WriteFile(srcFile, []byte("content"), 0o644); err != nil {
		t.Fatal(err)
	}

	qc2, _ := NewQueryCache("")
	w2 := NewGitWatcher(qc2)
	hashes, err := w2.GetFileHashes(dir, []string{"test.txt"})
	if err != nil {
		t.Fatalf("GetFileHashes returned error: %v", err)
	}
	if len(hashes) == 0 {
		t.Error("expected file hashes for non-git dir")
	}
}

func TestGetFileHashesWithDirtyFile(t *testing.T) {
	dir := t.TempDir()
	gitInit(t, dir)
	gitCreateFile(t, dir, "clean.txt", "clean content")

	qc3, _ := NewQueryCache("")
	w := NewGitWatcher(qc3)

	dirtyFile := filepath.Join(dir, "clean.txt")
	if err := os.WriteFile(dirtyFile, []byte("dirty content"), 0o644); err != nil {
		t.Fatal(err)
	}

	hashes, err := w.GetFileHashes(dir, []string{"clean.txt"})
	if err != nil {
		t.Fatalf("GetFileHashes returned error: %v", err)
	}
	if _, ok := hashes[".git/HEAD"]; !ok {
		t.Error("expected .git/HEAD hash")
	}
}

func gitInit(t *testing.T, dir string) {
	t.Helper()
	execCommand(t, dir, "git", "init")
	execCommand(t, dir, "git", "config", "user.email", "test@test.com")
	execCommand(t, dir, "git", "config", "user.name", "Test")
}

func gitHead(t *testing.T, dir string) string {
	t.Helper()
	return execCommand(t, dir, "git", "rev-parse", "HEAD")
}

func gitCreateFile(t *testing.T, dir, name, content string) {
	t.Helper()
	path := filepath.Join(dir, name)
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
	execCommand(t, dir, "git", "add", name)
	execCommand(t, dir, "git", "commit", "-m", "add "+name)
}

func execCommand(t *testing.T, dir, cmd string, args ...string) string {
	t.Helper()
	c := exec.Command(cmd, args...)
	c.Dir = dir
	output, err := c.Output()
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			t.Fatalf("%s %v failed: %v\nstdout: %s\nstderr: %s", cmd, args, err, string(output), string(ee.Stderr))
		}
		t.Fatalf("%s %v failed: %v\n%s", cmd, args, err, string(output))
	}
	return strings.TrimSpace(string(output))
}
