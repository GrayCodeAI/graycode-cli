// Package cache provides persistent query caching for shrike.
// Caches filtered command outputs for instant retrieval on repeated commands.
package cache

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	_ "modernc.org/sqlite"
)

// QueryCache provides persistent caching of filtered outputs
type QueryCache struct {
	db     *sql.DB
	mu     sync.RWMutex
	hits   atomic.Int64
	misses atomic.Int64
	done   chan struct{}
	wg     sync.WaitGroup
}

// CacheEntry represents a cached query result
type CacheEntry struct {
	Key              string    `json:"key"`
	Command          string    `json:"command"`
	Args             string    `json:"args"`
	WorkingDir       string    `json:"working_dir"`
	FileHashes       string    `json:"file_hashes"`
	FilteredOutput   string    `json:"filtered_output"`
	OriginalTokens   int       `json:"original_tokens"`
	FilteredTokens   int       `json:"filtered_tokens"`
	CompressionRatio float64   `json:"compression_ratio"`
	CreatedAt        time.Time `json:"created_at"`
	AccessedAt       time.Time `json:"accessed_at"`
	HitCount         int       `json:"hit_count"`
}

// CacheStats holds cache statistics
type CacheStats struct {
	TotalEntries int64   `json:"total_entries"`
	TotalHits    int64   `json:"total_hits"`
	TotalMisses  int64   `json:"total_misses"`
	HitRate      float64 `json:"hit_rate"`
	TotalSaved   int64   `json:"total_tokens_saved"`
}

// NewQueryCache creates a new query cache
func NewQueryCache(dbPath string) (*QueryCache, error) {
	if dbPath == "" {
		dbPath = defaultCachePath()
	}

	// Ensure directory exists
	dir := filepath.Dir(dbPath)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, fmt.Errorf("create cache directory: %w", err)
	}

	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, fmt.Errorf("open cache database: %w", err)
	}

	db.SetMaxOpenConns(1)

	// Set pragmas for performance
	if _, err := db.ExecContext(context.Background(), `
		PRAGMA journal_mode = WAL;
		PRAGMA synchronous = NORMAL;
		PRAGMA cache_size = 10000;
	`); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("configure database: %w", err)
	}

	qc := &QueryCache{db: db, done: make(chan struct{})}
	if err := qc.migrate(); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("migrate cache: %w", err)
	}

	return qc, nil
}

// defaultCachePath returns the default cache database path
func defaultCachePath() string {
	home, err := os.UserHomeDir()
	if err != nil {
		home = os.TempDir()
	}
	return filepath.Join(home, ".local", "share", "shrike", "cache.db")
}

// migrate creates the cache schema
func (c *QueryCache) migrate() error {
	_, err := c.db.ExecContext(context.Background(), `
		CREATE TABLE IF NOT EXISTS query_cache (
			key TEXT PRIMARY KEY,
			command TEXT NOT NULL,
			args TEXT,
			working_dir TEXT NOT NULL,
			file_hashes TEXT,
			filtered_output TEXT NOT NULL,
			original_tokens INTEGER NOT NULL,
			filtered_tokens INTEGER NOT NULL,
			compression_ratio REAL NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			hit_count INTEGER DEFAULT 1
		);

		CREATE INDEX IF NOT EXISTS idx_cache_command ON query_cache(command);
		CREATE INDEX IF NOT EXISTS idx_cache_accessed ON query_cache(accessed_at);
		CREATE INDEX IF NOT EXISTS idx_cache_created ON query_cache(created_at);
	`)
	return err
}

// CacheKeyOptions holds optional context that must be included in the cache key
// to avoid returning wrong cached results for different budget/tier/intent contexts.
type CacheKeyOptions struct {
	Budget      int    // token budget; different budgets produce different filtered outputs
	Tier        string // processing tier (e.g. "minimal", "standard", "aggressive")
	QueryIntent string // the user's query intent / context
}

// GenerateKey creates a cache key from command context.
// IMPORTANT: budget, tier, and query intent are included in the hash so that
// queries with identical files but different filtering parameters never collide.
func GenerateKey(command string, args []string, workingDir string, fileHashes map[string]string, opts ...CacheKeyOptions) string {
	h := sha256.New()

	// Hash command
	h.Write([]byte(command))
	h.Write([]byte("\x00"))

	// Hash args
	h.Write([]byte(strings.Join(args, "\x00")))
	h.Write([]byte("\x00"))

	// Hash working directory
	h.Write([]byte(workingDir))
	h.Write([]byte("\x00"))

	// Hash file hashes (sorted for consistency)
	if len(fileHashes) > 0 {
		keys := make([]string, 0, len(fileHashes))
		for k := range fileHashes {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			h.Write([]byte(k))
			h.Write([]byte("="))
			h.Write([]byte(fileHashes[k]))
			h.Write([]byte("\x00"))
		}
	}

	// Hash budget, tier, and query intent to prevent cross-context cache collisions.
	// Without these, a cached result for budget=5000 could be served for budget=1000,
	// returning insufficiently filtered content.
	if len(opts) > 0 {
		opt := opts[0]
		_, _ = fmt.Fprintf(h, "budget=%d\x00", opt.Budget)
		h.Write([]byte("tier="))
		h.Write([]byte(opt.Tier))
		h.Write([]byte("\x00"))
		h.Write([]byte("intent="))
		h.Write([]byte(opt.QueryIntent))
		h.Write([]byte("\x00"))
	}

	return hex.EncodeToString(h.Sum(nil))
}

// Get retrieves a cached entry
func (c *QueryCache) Get(key string) (*CacheEntry, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	var entry CacheEntry
	err := c.db.QueryRowContext(context.Background(), `
		SELECT key, command, args, working_dir, file_hashes,
		       filtered_output, original_tokens, filtered_tokens,
		       compression_ratio, created_at, accessed_at, hit_count
		FROM query_cache
		WHERE key = ?
	`, key).Scan(
		&entry.Key, &entry.Command, &entry.Args, &entry.WorkingDir,
		&entry.FileHashes, &entry.FilteredOutput, &entry.OriginalTokens,
		&entry.FilteredTokens, &entry.CompressionRatio, &entry.CreatedAt,
		&entry.AccessedAt, &entry.HitCount,
	)
	if err != nil {
		c.misses.Add(1)
		return nil, false
	}

	c.hits.Add(1)

	select {
	case <-c.done:
	default:
		c.wg.Add(1)
		go func() {
			defer c.wg.Done()
			c.updateAccessStats(key)
		}()
	}

	return &entry, true
}

// updateAccessStats updates hit count and access time
func (c *QueryCache) updateAccessStats(key string) {
	_, _ = c.db.ExecContext(context.Background(), `
		UPDATE query_cache
		SET hit_count = hit_count + 1,
		    accessed_at = CURRENT_TIMESTAMP
		WHERE key = ?
	`, key)
}

// Set stores a new cache entry
func (c *QueryCache) Set(key string, command string, args []string, workingDir string,
	fileHashes map[string]string, filteredOutput string,
	originalTokens, filteredTokens int,
) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	argsJSON, err := json.Marshal(args)
	if err != nil {
		return fmt.Errorf("marshal args: %w", err)
	}
	hashesJSON, err := json.Marshal(fileHashes)
	if err != nil {
		return fmt.Errorf("marshal file hashes: %w", err)
	}

	compressionRatio := 0.0
	if originalTokens > 0 {
		compressionRatio = float64(originalTokens-filteredTokens) / float64(originalTokens)
	}

	_, err = c.db.ExecContext(context.Background(), `
		INSERT INTO query_cache (
			key, command, args, working_dir, file_hashes,
			filtered_output, original_tokens, filtered_tokens,
			compression_ratio
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
		ON CONFLICT(key) DO UPDATE SET
			filtered_output = excluded.filtered_output,
			original_tokens = excluded.original_tokens,
			filtered_tokens = excluded.filtered_tokens,
			compression_ratio = excluded.compression_ratio,
			created_at = CURRENT_TIMESTAMP,
			accessed_at = CURRENT_TIMESTAMP,
			hit_count = 1
	`, key, command, string(argsJSON), workingDir, string(hashesJSON),
		filteredOutput, originalTokens, filteredTokens, compressionRatio)

	return err
}

// Invalidate removes entries matching a predicate
func (c *QueryCache) Invalidate(predicate func(*CacheEntry) bool) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	rows, err := c.db.QueryContext(context.Background(), `
		SELECT key, command, args, working_dir, file_hashes,
		       filtered_output, original_tokens, filtered_tokens,
		       compression_ratio, created_at, accessed_at, hit_count
		FROM query_cache
	`)
	if err != nil {
		return err
	}
	defer func() { _ = rows.Close() }()

	var toDelete []string

	for rows.Next() {
		var entry CacheEntry
		err := rows.Scan(
			&entry.Key, &entry.Command, &entry.Args, &entry.WorkingDir,
			&entry.FileHashes, &entry.FilteredOutput, &entry.OriginalTokens,
			&entry.FilteredTokens, &entry.CompressionRatio, &entry.CreatedAt,
			&entry.AccessedAt, &entry.HitCount,
		)
		if err != nil {
			continue
		}

		if predicate(&entry) {
			toDelete = append(toDelete, entry.Key)
		}
	}

	// Batch delete
	if len(toDelete) > 0 {
		placeholders := make([]string, len(toDelete))
		args := make([]interface{}, len(toDelete))
		for i, key := range toDelete {
			placeholders[i] = "?"
			args[i] = key
		}

		// #nosec G201 -- IN clause is placeholder tokens only; values parameterized
		query := fmt.Sprintf("DELETE FROM query_cache WHERE key IN (%s)",
			strings.Join(placeholders, ","))
		_, err = c.db.ExecContext(context.Background(), query, args...)
		return err
	}

	return nil
}

// InvalidateByCommand removes all entries for a command
func (c *QueryCache) InvalidateByCommand(command string) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	_, err := c.db.ExecContext(context.Background(), "DELETE FROM query_cache WHERE command = ?", command)
	return err
}

// InvalidateByPrefix removes entries with working dir prefix
func (c *QueryCache) InvalidateByPrefix(prefix string) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	_, err := c.db.ExecContext(context.Background(), "DELETE FROM query_cache WHERE working_dir LIKE ?", prefix+"%")
	return err
}

// Stats returns cache statistics
func (c *QueryCache) Stats() (*CacheStats, error) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	var stats CacheStats

	// Get entry count and total saved
	err := c.db.QueryRowContext(context.Background(), `
		SELECT
			COUNT(*),
			COALESCE(SUM(original_tokens - filtered_tokens), 0)
		FROM query_cache
	`).Scan(&stats.TotalEntries, &stats.TotalSaved)
	if err != nil {
		return nil, err
	}

	// Get hit counts from entries
	var totalHits int64
	err = c.db.QueryRowContext(context.Background(), `
		SELECT COALESCE(SUM(hit_count - 1), 0)
		FROM query_cache
	`).Scan(&totalHits)
	if err != nil {
		return nil, err
	}

	stats.TotalHits = totalHits
	stats.TotalMisses = stats.TotalEntries // Approximate

	if stats.TotalHits+stats.TotalMisses > 0 {
		stats.HitRate = float64(stats.TotalHits) / float64(stats.TotalHits+stats.TotalMisses)
	}

	return &stats, nil
}

// GetRuntimeStats returns runtime hit/miss stats
func (c *QueryCache) GetRuntimeStats() (hits, misses int64) {
	return c.hits.Load(), c.misses.Load()
}

// Close drains pending background writes and closes the cache database.
// Callers MUST call Close() when they are done using the QueryCache to release
// the underlying database connection and complete any pending writes. Failing
// to call Close() will leak file descriptors and potentially corrupt the WAL.
// Consider using defer qc.Close() immediately after NewQueryCache().
func (c *QueryCache) Close() error {
	// Safely signal shutdown (no-op if already closed)
	select {
	case <-c.done:
		// Already closed; avoid double-close panic on channel
		return nil
	default:
		close(c.done)
	}

	// Wait for in-flight background goroutines to finish
	c.wg.Wait()

	// Close the underlying database
	if c.db != nil {
		return c.db.Close()
	}
	return nil
}

// Cleanup removes old entries
func (c *QueryCache) Cleanup(maxAge time.Duration) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	cutoff := time.Now().Add(-maxAge)
	_, err := c.db.ExecContext(
		context.Background(),
		"DELETE FROM query_cache WHERE accessed_at < ?",
		cutoff.Format("2006-01-02 15:04:05"),
	)
	return err
}

// GetTopQueries returns most frequently accessed queries
func (c *QueryCache) GetTopQueries(limit int) ([]*CacheEntry, error) {
	rows, err := c.db.QueryContext(context.Background(), `
		SELECT key, command, args, working_dir, file_hashes,
		       filtered_output, original_tokens, filtered_tokens,
		       compression_ratio, created_at, accessed_at, hit_count
		FROM query_cache
		ORDER BY hit_count DESC, accessed_at DESC
		LIMIT ?
	`, limit)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	var entries []*CacheEntry
	for rows.Next() {
		var entry CacheEntry
		err := rows.Scan(
			&entry.Key, &entry.Command, &entry.Args, &entry.WorkingDir,
			&entry.FileHashes, &entry.FilteredOutput, &entry.OriginalTokens,
			&entry.FilteredTokens, &entry.CompressionRatio, &entry.CreatedAt,
			&entry.AccessedAt, &entry.HitCount,
		)
		if err != nil {
			continue
		}
		entries = append(entries, &entry)
	}

	return entries, rows.Err()
}
