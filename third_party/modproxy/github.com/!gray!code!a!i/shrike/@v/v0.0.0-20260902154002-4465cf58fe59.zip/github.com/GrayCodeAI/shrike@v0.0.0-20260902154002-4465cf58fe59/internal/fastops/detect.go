// Package fastops CPU feature detection. Detection uses golang.org/x/sys/cpu
// for runtime CPUID queries (amd64) and static defaults (arm64 always has NEON).
//
// SIMD implementations:
//   - amd64 (AVX2): fastops_amd64.s with //go:noescape declarations
//   - arm64 (NEON): deferred — Go's plan9 assembler has limited GP↔NEON register
//     transfer support (VMOV with element indexing and VLD1 addressing are unreliable
//     in user-written assembly). When Go >=1.28 or a future release stabilizes NEON
//     instruction support, add fastops_arm64.s with VLD1/VEOR/VCNT/VUADDLV sequences
//     and wire them through the Dispatcher.
package fastops

import (
	"math"
	"runtime"
	"sync"

	"golang.org/x/sys/cpu"
)

// CPUFeatures holds detected CPU capabilities.
type CPUFeatures struct {
	HasAVX2   bool
	HasAVX512 bool
	HasNEON   bool
}

var (
	features     CPUFeatures
	featuresOnce sync.Once
)

// Detect returns CPU SIMD capabilities
func Detect() CPUFeatures {
	featuresOnce.Do(func() {
		features = detectCPUFeatures()
	})
	return features
}

func detectCPUFeatures() CPUFeatures {
	switch runtime.GOARCH {
	case "amd64":
		return CPUFeatures{
			HasAVX2:   cpu.X86.HasAVX2,
			HasAVX512: cpu.X86.HasAVX512,
		}
	case "arm64":
		return CPUFeatures{
			HasNEON: true, // ARM64 always has NEON
		}
	}
	return CPUFeatures{}
}

// Dispatcher selects optimal implementation. FastHasANSI and FastCountBytes
// dispatch to AVX2 (amd64) when available; EntropyFilter always uses scalar
// (float64 SIMD is a separate concern, deferred).
type Dispatcher struct {
	features CPUFeatures
}

// NewDispatcher creates a new Dispatcher with detected CPU features.
func NewDispatcher() *Dispatcher {
	return &Dispatcher{features: Detect()}
}

// EntropyFilter dispatches to scalar implementation (float64 SIMD deferred).
// SIMD implementations are platform-specific and deferred:
// - AVX2 (amd64): requires VFMADD231PD assembly in entropy_amd64.s
// - NEON (arm64): requires FMLA assembly in entropy_arm64.s
// Current scalar implementation provides baseline performance.
func (d *Dispatcher) EntropyFilter(data []float64) float64 {
	return entropyScalar(data)
}

func entropyScalar(data []float64) float64 {
	if len(data) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range data {
		if v > 0 {
			sum -= v * fastLog2(v)
		}
	}
	return sum
}

func fastLog2(x float64) float64 {
	if x <= 0 {
		return 0
	}
	return math.Log2(x)
}
