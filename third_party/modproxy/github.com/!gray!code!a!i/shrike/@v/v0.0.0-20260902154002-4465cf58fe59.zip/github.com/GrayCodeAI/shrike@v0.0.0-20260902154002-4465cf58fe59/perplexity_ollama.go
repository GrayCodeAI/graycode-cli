//go:build experimental_ollama

package shrike

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"
)

// OllamaScorer is a SKELETON for a real model-backed PerplexityScorer that
// queries a local Ollama server (http://localhost:11434) for per-token
// logprobs and converts them into importance scores (higher surprise =
// higher score = more important).
//
// It is NOT wired in by default: WithPerplexityGuided / CompressPerplexityGuided
// fall back to HeuristicPerplexityScorer unless an OllamaScorer is explicitly
// passed. It compiles and degrades gracefully; real per-token logprob extraction
// is pending Ollama API stabilization — the /api/generate response shape for
// logprobs varies by version.
//
// Example (once implemented):
//
//	scorer := shrike.NewOllamaScorer("llama3.2")
//	out, _ := shrike.CompressPerplexityGuided(text, scorer, 0.4)
type OllamaScorer struct {
	// Model is the Ollama model tag (e.g. "llama3.2", "qwen2.5:0.5b").
	Model string
	// Endpoint is the Ollama generate endpoint. Defaults to the local server.
	Endpoint string
	// HTTPClient is used for requests; defaults to a client with a short timeout.
	HTTPClient *http.Client
}

// NewOllamaScorer constructs an OllamaScorer for the given model, pointing at
// the default local Ollama endpoint with a sane timeout.
func NewOllamaScorer(model string) *OllamaScorer {
	return &OllamaScorer{
		Model:      model,
		Endpoint:   "http://localhost:11434/api/generate",
		HTTPClient: &http.Client{Timeout: 30 * time.Second},
	}
}

// ollamaGenerateRequest is the request body for Ollama's /api/generate.
type ollamaGenerateRequest struct {
	Model   string         `json:"model"`
	Prompt  string         `json:"prompt"`
	Stream  bool           `json:"stream"`
	Options map[string]any `json:"options,omitempty"`
}

// ollamaGenerateResponse is the (partial) response body. Newer Ollama builds
// can expose per-token logprobs; the exact field is version-dependent, hence
// the graceful fallback in Score.
//
// When Ollama stabilizes its logprob API, extend this struct with:
//
//	Logprobs []struct{ Token string; Logprob float64 } `json:"logprobs"`
type ollamaGenerateResponse struct {
	Response string `json:"response"`
	Done     bool   `json:"done"`
}

// Score implements PerplexityScorer by asking Ollama to evaluate the tokens.
//
// Ollama's /api/generate does not yet expose stable per-token logprobs across
// versions. When that API stabilizes, send the joined tokens as the prompt with
// options like {"logprobs": true} and map each returned logprob L to an
// importance score of -L (lower probability => higher surprise => higher score).
// Until then this method probes the endpoint for reachability and returns an
// error so callers transparently fall back to the heuristic scorer.
func (o *OllamaScorer) Score(ctx context.Context, tokens []string) ([]float64, error) {
	if len(tokens) == 0 {
		return nil, nil
	}
	client := o.HTTPClient
	if client == nil {
		client = &http.Client{Timeout: 30 * time.Second}
	}
	endpoint := o.Endpoint
	if endpoint == "" {
		endpoint = "http://localhost:11434/api/generate"
	}

	reqBody := ollamaGenerateRequest{
		Model:  o.Model,
		Prompt: strings.Join(tokens, " "),
		Stream: false,
		// When Ollama stabilizes logprob output, set:
		// Options: map[string]any{"logprobs": true},
	}
	buf, err := json.Marshal(reqBody)
	if err != nil {
		return nil, fmt.Errorf("ollama: marshal request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(buf))
	if err != nil {
		return nil, fmt.Errorf("ollama: build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("ollama: request failed (is the server running on %s?): %w", endpoint, err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("ollama: unexpected status %d from %s", resp.StatusCode, endpoint)
	}

	var parsed ollamaGenerateResponse
	if err := json.NewDecoder(resp.Body).Decode(&parsed); err != nil {
		return nil, fmt.Errorf("ollama: decode response: %w", err)
	}

	// Per-token logprob extraction is pending Ollama API stabilization.
	// Signal unavailability so callers fall back to the heuristic scorer.
	return nil, fmt.Errorf("ollama: per-token logprobs not yet available for model %q", o.Model)
}
