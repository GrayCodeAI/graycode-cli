package filter

import (
	"testing"
)

func TestConstantsValues(t *testing.T) {
	tests := []struct {
		name  string
		value int
		min   int
		max   int
	}{
		{"TightBudgetThreshold", TightBudgetThreshold, 100, 10000},
		{"MinimalBudgetThreshold", MinimalBudgetThreshold, 10, 500},
		{"MinContentLength", MinContentLength, 10, 200},
		{"SmallContentThreshold", SmallContentThreshold, 100, 1000},
		{"MediumContentThreshold", MediumContentThreshold, 500, 5000},
		{"LargeContentThreshold", LargeContentThreshold, 5000, 50000},
		{"StreamingThreshold", StreamingThreshold, 100000, 1000000},
		{"DefaultCacheSize", DefaultCacheSize, 100, 10000},
		{"HighCompressionRatio", int(HighCompressionRatio * 100), 90, 100},
		{"TargetCompressionRatio", int(TargetCompressionRatio * 100), 50, 90},
		{"MinCompressionRatio", int(MinCompressionRatio * 100), 0, 50},
		{"MinTokenEstimate", MinTokenEstimate, 1, 10},
		{"NumLayerIndices", NumLayerIndices, 20, 30},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.value < tt.min || tt.value > tt.max {
				t.Errorf("%s = %d, expected between %d and %d", tt.name, tt.value, tt.min, tt.max)
			}
		})
	}
}

func TestLayerIndexConstants(t *testing.T) {
	// Check that all layer indices are unique by verifying the last index + 1 == count
	if LayerIdxAdvanced+1 != NumLayerIndices {
		t.Errorf("last index (%d) + 1 should equal NumLayerIndices (%d)", LayerIdxAdvanced, NumLayerIndices)
	}

	// Check ordering: each index should be unique and sequential
	indices := allLayerIndices
	for i, idx := range indices {
		if i != idx {
			t.Errorf("allLayerIndices[%d] = %d, expected %d", i, idx, i)
		}
	}
}

func TestFirstLayerIndex(t *testing.T) {
	if LayerIdxEntropy != 0 {
		t.Errorf("LayerIdxEntropy should be 0, got %d", LayerIdxEntropy)
	}
}

func TestLayerIndexCount(t *testing.T) {
	if len(allLayerIndices) != NumLayerIndices {
		t.Errorf("len(allLayerIndices) = %d, NumLayerIndices = %d", len(allLayerIndices), NumLayerIndices)
	}
}

func TestCompressionRatiosOrdering(t *testing.T) {
	if MinCompressionRatio >= TargetCompressionRatio {
		t.Errorf("MinCompressionRatio (%f) should be < TargetCompressionRatio (%f)", MinCompressionRatio, TargetCompressionRatio)
	}
	if TargetCompressionRatio >= HighCompressionRatio {
		t.Errorf("TargetCompressionRatio (%f) should be < HighCompressionRatio (%f)", TargetCompressionRatio, HighCompressionRatio)
	}
}

func TestBudgetThresholdsOrdering(t *testing.T) {
	if MinimalBudgetThreshold >= TightBudgetThreshold {
		t.Errorf("MinimalBudgetThreshold (%d) should be < TightBudgetThreshold (%d)", MinimalBudgetThreshold, TightBudgetThreshold)
	}
}

func TestContentThresholdsOrdering(t *testing.T) {
	if MinContentLength >= SmallContentThreshold {
		t.Errorf("MinContentLength (%d) should be < SmallContentThreshold (%d)", MinContentLength, SmallContentThreshold)
	}
	if SmallContentThreshold >= MediumContentThreshold {
		t.Errorf("SmallContentThreshold (%d) should be < MediumContentThreshold (%d)", SmallContentThreshold, MediumContentThreshold)
	}
	if MediumContentThreshold >= LargeContentThreshold {
		t.Errorf("MediumContentThreshold (%d) should be < LargeContentThreshold (%d)", MediumContentThreshold, LargeContentThreshold)
	}
}

func TestTokensPerCharHeuristic(t *testing.T) {
	if TokensPerCharHeuristic <= 0 || TokensPerCharHeuristic >= 1 {
		t.Errorf("TokensPerCharHeuristic (%f) should be between 0 and 1", TokensPerCharHeuristic)
	}
}
