package filter

import (
	"strings"
)

// MemoryAwareCompressor uses project memory context to make smarter
// compression decisions. If a term appears in harrier's memory (conventions,
// decisions, etc), it's preserved during compression.
//
// Integration: hawk passes memory keywords from harrier, shrike preserves them.
type MemoryAwareCompressor struct {
	preserveTerms map[string]bool // terms from harrier that should NEVER be compressed away
	conventions   []string        // project conventions to respect
}

// NewMemoryAwareCompressor creates a compressor with memory context.
func NewMemoryAwareCompressor(preserveTerms []string, conventions []string) *MemoryAwareCompressor {
	terms := make(map[string]bool, len(preserveTerms))
	for _, t := range preserveTerms {
		terms[strings.ToLower(t)] = true
	}
	return &MemoryAwareCompressor{
		preserveTerms: terms,
		conventions:   conventions,
	}
}

// ShouldPreserve returns true if a line contains memory-significant content.
func (mac *MemoryAwareCompressor) ShouldPreserve(line string) bool {
	lower := strings.ToLower(line)
	for term := range mac.preserveTerms {
		if strings.Contains(lower, term) {
			return true
		}
	}
	return false
}

// FilterLines removes non-essential lines while preserving memory-significant ones.
func (mac *MemoryAwareCompressor) FilterLines(lines []string, budget int) []string {
	if budget <= 0 || len(lines) == 0 {
		return lines
	}

	// First pass: mark lines that must be preserved (memory terms)
	type scoredLine struct {
		line     string
		preserve bool
		score    float64
	}

	scored := make([]scoredLine, len(lines))
	for i, l := range lines {
		scored[i] = scoredLine{
			line:     l,
			preserve: mac.ShouldPreserve(l),
			score:    mac.lineScore(l),
		}
	}

	// Always include preserved lines
	var result []string
	tokenCount := 0
	for _, sl := range scored {
		if sl.preserve {
			result = append(result, sl.line)
			tokenCount += len(sl.line) / 4
		}
	}

	// Fill remaining budget with highest-scored non-preserved lines
	if tokenCount < budget {
		for _, sl := range scored {
			if sl.preserve {
				continue
			}
			lineTokens := len(sl.line) / 4
			if tokenCount+lineTokens > budget {
				continue
			}
			result = append(result, sl.line)
			tokenCount += lineTokens
		}
	}

	return result
}

// AdaptConventions applies convention-aware compression rules.
// E.g., if convention says "use jose not jsonwebtoken", preserve "jose" references.
func (mac *MemoryAwareCompressor) AdaptConventions(text string) string {
	for _, conv := range mac.conventions {
		lower := strings.ToLower(conv)
		// If convention mentions "use X", preserve X in output
		if idx := strings.Index(lower, "use "); idx >= 0 {
			after := lower[idx+4:]
			end := strings.IndexAny(after, " .,;")
			if end < 0 {
				end = len(after)
			}
			term := after[:end]
			if term != "" {
				mac.preserveTerms[term] = true
			}
		}
	}
	return text
}

func (mac *MemoryAwareCompressor) lineScore(line string) float64 {
	score := 0.0
	// Lines with code are more important
	if strings.Contains(line, "func ") || strings.Contains(line, "class ") ||
		strings.Contains(line, "import ") || strings.Contains(line, "return ") {
		score += 2.0
	}
	// Error lines are important
	if strings.Contains(strings.ToLower(line), "error") || strings.Contains(line, "FAIL") {
		score += 3.0
	}
	// Short lines are less likely to be noise
	if len(line) < 80 {
		score += 0.5
	}
	return score
}

// ContextBudgetAllocator distributes token budget across content types.
// When piping multiple files or outputs through shrike, this ensures the
// most important content gets the most tokens.
type ContextBudgetAllocator struct {
	totalBudget int
	allocations map[string]float64 // content type → fraction of budget
}

// NewContextBudgetAllocator creates a budget allocator.
func NewContextBudgetAllocator(totalBudget int) *ContextBudgetAllocator {
	return &ContextBudgetAllocator{
		totalBudget: totalBudget,
		allocations: map[string]float64{
			"code":    0.40,
			"error":   0.25,
			"context": 0.20,
			"log":     0.10,
			"other":   0.05,
		},
	}
}

// BudgetFor returns the token budget for a content type.
func (cba *ContextBudgetAllocator) BudgetFor(contentType string) int {
	frac, ok := cba.allocations[contentType]
	if !ok {
		frac = 0.05
	}
	return int(float64(cba.totalBudget) * frac)
}

// DetectContentType classifies text into content types for budget allocation.
func DetectContentType(text string) string {
	lower := strings.ToLower(text)
	switch {
	case strings.Contains(lower, "error:") || strings.Contains(lower, "fail") || strings.Contains(lower, "panic"):
		return "error"
	case strings.Contains(text, "func ") || strings.Contains(text, "class ") || strings.Contains(text, "def "):
		return "code"
	case strings.Contains(lower, "info") || strings.Contains(lower, "debug") || strings.Contains(text, "["):
		return "log"
	case strings.Contains(lower, "context") || strings.Contains(lower, "background"):
		return "context"
	default:
		return "other"
	}
}
