package shrike

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"sync"
	"time"
)

// CompressionAdvisor analyzes compression sessions and recommends optimal strategies.
type CompressionAdvisor struct {
	History    []CompressionEvent
	Strategies map[string]*StrategyStats
	mu         sync.RWMutex
}

// CompressionEvent records a single compression operation.
type CompressionEvent struct {
	Input        string
	Output       string
	Mode         string
	InputTokens  int
	OutputTokens int
	Savings      float64
	Timestamp    time.Time
	ContentType  string
}

// StrategyStats tracks performance statistics for a compression strategy.
type StrategyStats struct {
	Name         string
	TotalEvents  int
	AvgSavings   float64
	BestSavings  float64
	WorstSavings float64
	AvgQuality   float64
}

// Recommendation represents an advisor suggestion for improving compression.
type Recommendation struct {
	Strategy        string
	Reason          string
	ExpectedSavings float64
	ContentType     string
	Priority        int
}

// NewCompressionAdvisor creates a new CompressionAdvisor instance.
func NewCompressionAdvisor() *CompressionAdvisor {
	return &CompressionAdvisor{
		History:    make([]CompressionEvent, 0),
		Strategies: make(map[string]*StrategyStats),
	}
}

// Record records a compression event and updates strategy statistics.
func (ca *CompressionAdvisor) Record(event CompressionEvent) {
	ca.mu.Lock()
	defer ca.mu.Unlock()

	if event.Timestamp.IsZero() {
		event.Timestamp = time.Now()
	}
	if event.ContentType == "" {
		event.ContentType = ClassifyContent(event.Input)
	}
	if event.Savings == 0 && event.InputTokens > 0 {
		event.Savings = 1.0 - float64(event.OutputTokens)/float64(event.InputTokens)
	}

	ca.History = append(ca.History, event)

	key := event.Mode + ":" + event.ContentType
	stats, exists := ca.Strategies[key]
	if !exists {
		stats = &StrategyStats{
			Name:         key,
			WorstSavings: 1.0,
		}
		ca.Strategies[key] = stats
	}

	stats.TotalEvents++
	// Update running average for savings
	stats.AvgSavings += (event.Savings - stats.AvgSavings) / float64(stats.TotalEvents)
	if event.Savings > stats.BestSavings {
		stats.BestSavings = event.Savings
	}
	if event.Savings < stats.WorstSavings {
		stats.WorstSavings = event.Savings
	}
	// Quality is inversely proportional to information loss (1 - savings gives retention)
	quality := 1.0 - event.Savings*0.3 // higher savings slightly reduces quality score
	stats.AvgQuality += (quality - stats.AvgQuality) / float64(stats.TotalEvents)
}

// Analyze examines the history and produces recommendations per content type.
func (ca *CompressionAdvisor) Analyze() []Recommendation {
	ca.mu.RLock()
	defer ca.mu.RUnlock()

	var recs []Recommendation

	contentTypes := ca.contentTypeCounts()

	for ct, count := range contentTypes {
		if count == 0 {
			continue
		}
		rec := ca.recommendForContentType(ct)
		if rec != nil {
			recs = append(recs, *rec)
		}
	}

	// If no history-based recommendations, provide defaults
	if len(recs) == 0 {
		recs = defaultRecommendations()
	}

	sort.Slice(recs, func(i, j int) bool {
		return recs[i].Priority < recs[j].Priority
	})

	return recs
}

func (ca *CompressionAdvisor) contentTypeCounts() map[string]int {
	counts := make(map[string]int)
	for _, e := range ca.History {
		counts[e.ContentType]++
	}
	return counts
}

func (ca *CompressionAdvisor) recommendForContentType(ct string) *Recommendation {
	switch ct {
	case "code":
		return &Recommendation{
			Strategy:        "full",
			Reason:          "Code output benefits from full-mode compression that preserves structure",
			ExpectedSavings: 0.40,
			ContentType:     ct,
			Priority:        2,
		}
	case "natural_language":
		return &Recommendation{
			Strategy:        "ultra",
			Reason:          "Natural language has high redundancy; ultra mode saves most tokens",
			ExpectedSavings: 0.60,
			ContentType:     ct,
			Priority:        3,
		}
	case "error":
		return &Recommendation{
			Strategy:        "lite",
			Reason:          "Error messages need detail preservation; lite mode keeps critical info",
			ExpectedSavings: 0.20,
			ContentType:     ct,
			Priority:        4,
		}
	case "diff":
		return &Recommendation{
			Strategy:        "aggressive",
			Reason:          "Large diffs benefit from aggressive truncation of unchanged context",
			ExpectedSavings: 0.55,
			ContentType:     ct,
			Priority:        1,
		}
	case "test_output":
		return &Recommendation{
			Strategy:        "full",
			Reason:          "Test output has high noise; full mode with noise removal yields best results",
			ExpectedSavings: 0.85,
			ContentType:     ct,
			Priority:        1,
		}
	case "log":
		return &Recommendation{
			Strategy:        "aggressive",
			Reason:          "Log output is highly repetitive; aggressive deduplication works well",
			ExpectedSavings: 0.70,
			ContentType:     ct,
			Priority:        2,
		}
	case "data":
		return &Recommendation{
			Strategy:        "full",
			Reason:          "Structured data compresses well with schema-aware full mode",
			ExpectedSavings: 0.50,
			ContentType:     ct,
			Priority:        3,
		}
	default:
		return &Recommendation{
			Strategy:        "full",
			Reason:          "General content benefits from balanced full-mode compression",
			ExpectedSavings: 0.35,
			ContentType:     ct,
			Priority:        5,
		}
	}
}

func defaultRecommendations() []Recommendation {
	return []Recommendation{
		{Strategy: "full", Reason: "Test output has high noise; full mode with noise removal yields best results", ExpectedSavings: 0.85, ContentType: "test_output", Priority: 1},
		{Strategy: "aggressive", Reason: "Large diffs benefit from aggressive truncation of unchanged context", ExpectedSavings: 0.55, ContentType: "diff", Priority: 1},
		{Strategy: "full", Reason: "Code output benefits from full-mode compression that preserves structure", ExpectedSavings: 0.40, ContentType: "code", Priority: 2},
		{Strategy: "ultra", Reason: "Natural language has high redundancy; ultra mode saves most tokens", ExpectedSavings: 0.60, ContentType: "natural_language", Priority: 3},
		{Strategy: "lite", Reason: "Error messages need detail preservation; lite mode keeps critical info", ExpectedSavings: 0.20, ContentType: "error", Priority: 4},
	}
}

// ClassifyContent determines the content type of a text string.
func ClassifyContent(text string) string {
	if text == "" {
		return "natural_language"
	}

	lines := strings.Split(text, "\n")

	// Check for diff format
	if isDiff(lines) {
		return "diff"
	}

	// Check for test output
	if isTestOutput(lines) {
		return "test_output"
	}

	// Check for error/stack traces
	if isError(lines) {
		return "error"
	}

	// Check for log format
	if isLog(lines) {
		return "log"
	}

	// Check for structured data (JSON, CSV, tabular)
	if isData(text, lines) {
		return "data"
	}

	// Check for code
	if isCode(lines) {
		return "code"
	}

	return "natural_language"
}

func isDiff(lines []string) bool {
	diffMarkers := 0
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "diff --git") || strings.HasPrefix(trimmed, "@@") {
			diffMarkers++
			continue
		}
		// Only count +++ and --- if they look like diff headers (not test output)
		if strings.HasPrefix(trimmed, "+++ ") || strings.HasPrefix(trimmed, "--- ") {
			// Exclude test output patterns like "--- PASS" or "--- FAIL"
			if !strings.HasPrefix(trimmed, "--- PASS") && !strings.HasPrefix(trimmed, "--- FAIL") &&
				!strings.HasPrefix(trimmed, "--- SKIP") {
				diffMarkers++
			}
			continue
		}
		if len(trimmed) > 0 && (trimmed[0] == '+' || trimmed[0] == '-') {
			diffMarkers++
		}
	}
	threshold := len(lines) / 4
	if threshold < 2 {
		threshold = 2
	}
	return diffMarkers >= threshold
}

func isTestOutput(lines []string) bool {
	testPatterns := []string{
		"PASS", "FAIL", "--- PASS", "--- FAIL", "=== RUN",
		"ok  ", "FAILED", "passed", "failed", "test result",
		"Tests:", "Assertions:", "✓", "✗", "SKIP",
	}
	matches := 0
	for _, line := range lines {
		for _, pattern := range testPatterns {
			if strings.Contains(line, pattern) {
				matches++
				break
			}
		}
	}
	threshold := len(lines) / 5
	if threshold < 2 {
		threshold = 2
	}
	return matches >= threshold
}

func isError(lines []string) bool {
	errorPatterns := []string{
		"Error:", "error:", "panic:", "Exception", "exception",
		"Traceback", "at ", "goroutine", "stack trace",
		"fatal", "Fatal", "FATAL", "caused by",
	}
	matches := 0
	for _, line := range lines {
		for _, pattern := range errorPatterns {
			if strings.Contains(line, pattern) {
				matches++
				break
			}
		}
	}
	threshold := len(lines) / 5
	if threshold < 2 {
		threshold = 2
	}
	return matches >= threshold
}

func isLog(lines []string) bool {
	// Look for timestamp patterns common in logs
	logPatterns := []string{
		"INFO", "WARN", "ERROR", "DEBUG", "TRACE",
		"[info]", "[warn]", "[error]", "[debug]",
	}
	timestampCount := 0
	for _, line := range lines {
		// Heuristic: lines starting with a date/time-like pattern
		if len(line) > 19 {
			// Check for ISO-like timestamps or common log prefixes
			prefix := line[:19]
			if (prefix[4] == '-' && prefix[7] == '-' && prefix[10] == ' ') ||
				(prefix[4] == '-' && prefix[7] == '-' && prefix[10] == 'T') {
				timestampCount++
				continue
			}
		}
		for _, pattern := range logPatterns {
			if strings.Contains(line, pattern) {
				timestampCount++
				break
			}
		}
	}
	threshold := len(lines) / 3
	if threshold < 3 {
		threshold = 3
	}
	return timestampCount >= threshold
}

func isData(text string, lines []string) bool {
	trimmed := strings.TrimSpace(text)
	// JSON object or array
	if (strings.HasPrefix(trimmed, "{") && strings.HasSuffix(trimmed, "}")) ||
		(strings.HasPrefix(trimmed, "[") && strings.HasSuffix(trimmed, "]")) {
		return true
	}
	// CSV-like: check if most lines have the same number of commas
	if len(lines) >= 3 {
		commaCount := strings.Count(lines[0], ",")
		if commaCount >= 2 {
			consistent := 0
			for _, line := range lines {
				if strings.Count(line, ",") == commaCount {
					consistent++
				}
			}
			if float64(consistent)/float64(len(lines)) > 0.7 {
				return true
			}
		}
		// Tab-separated
		tabCount := strings.Count(lines[0], "\t")
		if tabCount >= 2 {
			consistent := 0
			for _, line := range lines {
				if strings.Count(line, "\t") == tabCount {
					consistent++
				}
			}
			if float64(consistent)/float64(len(lines)) > 0.7 {
				return true
			}
		}
	}
	return false
}

func isCode(lines []string) bool {
	codePatterns := []string{
		"func ", "def ", "class ", "import ", "package ",
		"var ", "const ", "type ", "return ", "if ",
		"for ", "while ", "switch ", "case ", "struct ",
		"{", "}", "();", "=>", "->",
	}
	matches := 0
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		for _, pattern := range codePatterns {
			if strings.Contains(trimmed, pattern) {
				matches++
				break
			}
		}
	}
	threshold := len(lines) / 4
	if threshold < 3 {
		threshold = 3
	}
	return matches >= threshold
}

// RecommendMode recommends the best compression mode for a given content type and token budget.
func RecommendMode(contentType string, budget int) string {
	switch contentType {
	case "code":
		if budget < 500 {
			return "aggressive"
		}
		return "full"
	case "natural_language":
		if budget < 200 {
			return "aggressive"
		}
		if budget < 1000 {
			return "ultra"
		}
		return "ultra"
	case "error":
		if budget < 100 {
			return "aggressive"
		}
		return "lite"
	case "diff":
		if budget < 500 {
			return "aggressive"
		}
		return "aggressive"
	case "test_output":
		if budget < 200 {
			return "aggressive"
		}
		return "full"
	case "log":
		if budget < 300 {
			return "aggressive"
		}
		return "aggressive"
	case "data":
		if budget < 500 {
			return "aggressive"
		}
		return "full"
	default:
		if budget < 500 {
			return "aggressive"
		}
		return "full"
	}
}

// OptimalBudget recommends how many tokens to allocate based on content type and importance (0.0-1.0).
func OptimalBudget(contentType string, importance float64) int {
	if importance < 0 {
		importance = 0
	}
	if importance > 1.0 {
		importance = 1.0
	}

	// Base budgets per content type
	baseBudgets := map[string]int{
		"code":             2000,
		"natural_language": 1000,
		"error":            1500,
		"diff":             1000,
		"test_output":      500,
		"log":              500,
		"data":             1500,
	}

	base, ok := baseBudgets[contentType]
	if !ok {
		base = 1000
	}

	// Scale by importance: low importance gets 30% of base, high importance gets 200%
	scale := 0.3 + importance*1.7
	return int(math.Round(float64(base) * scale))
}

// WastedTokens calculates how many tokens could have been saved with optimal compression strategies.
func WastedTokens(events []CompressionEvent) int {
	wasted := 0
	for _, event := range events {
		optimalSavings := optimalSavingsForType(event.ContentType)
		actualSavings := event.Savings
		if optimalSavings > actualSavings && event.InputTokens > 0 {
			// The difference in savings applied to input tokens
			diff := optimalSavings - actualSavings
			wasted += int(math.Round(diff * float64(event.InputTokens)))
		}
	}
	return wasted
}

func optimalSavingsForType(contentType string) float64 {
	switch contentType {
	case "code":
		return 0.40
	case "natural_language":
		return 0.60
	case "error":
		return 0.20
	case "diff":
		return 0.55
	case "test_output":
		return 0.85
	case "log":
		return 0.70
	case "data":
		return 0.50
	default:
		return 0.35
	}
}

// FormatAdvice returns a human-readable report of compression advice.
func (ca *CompressionAdvisor) FormatAdvice() string {
	ca.mu.RLock()
	defer ca.mu.RUnlock()

	if len(ca.History) == 0 {
		return "Compression Advisor:\n" +
			strings.Repeat("─", 35) + "\n" +
			"No compression history available. Record events to get advice.\n"
	}

	// Calculate totals
	totalInput := 0
	totalOutput := 0
	for _, e := range ca.History {
		totalInput += e.InputTokens
		totalOutput += e.OutputTokens
	}

	sessionCount := ca.estimateSessionCount()
	if sessionCount == 0 {
		sessionCount = 1
	}
	avgPerSession := totalInput / sessionCount

	// Calculate optimal output
	optimalOutput := 0
	for _, e := range ca.History {
		optimal := optimalSavingsForType(e.ContentType)
		optimalOutput += int(math.Round(float64(e.InputTokens) * (1.0 - optimal)))
	}
	optimalPerSession := optimalOutput / sessionCount
	savingsPercent := 0.0
	if avgPerSession > 0 {
		savingsPercent = (1.0 - float64(optimalPerSession)/float64(avgPerSession)) * 100
	}

	var sb strings.Builder
	sb.WriteString("Compression Advisor:\n")
	sb.WriteString(strings.Repeat("─", 35) + "\n")
	fmt.Fprintf(&sb, "Your sessions use avg %sK tokens/session.\n", formatK(avgPerSession))
	fmt.Fprintf(&sb, "With optimal compression: ~%sK tokens (%.0f%% savings)\n", formatK(optimalPerSession), savingsPercent)
	sb.WriteString("\n")
	sb.WriteString("By content type:\n")

	// Gather content type stats
	typeStats := ca.contentTypeAvgSavings()
	typeOrder := []struct {
		ct      string
		label   string
		mode    string
		savings float64
		note    string
	}{
		{"code", "Code output", "full mode optimal", 0.40, ""},
		{"test_output", "Test results", "full+noise", 0.85, ""},
		{"natural_language", "Natural lang", "ultra mode", 0.60, ""},
		{"error", "Error messages", "lite mode", 0, "preserve details"},
	}

	for _, ts := range typeOrder {
		if _, present := typeStats[ts.ct]; present {
			if ts.note != "" {
				fmt.Fprintf(&sb, "  %-16s %s (%s)\n", ts.label+":", ts.mode, ts.note)
			} else {
				fmt.Fprintf(&sb, "  %-16s %s (avg %.0f%% savings)\n", ts.label+":", ts.mode, ts.savings*100)
			}
		}
	}

	sb.WriteString("\n")
	sb.WriteString("Top recommendations:\n")

	recs := ca.topRecommendations()
	for i, rec := range recs {
		if i >= 3 {
			break
		}
		fmt.Fprintf(&sb, "%d. %s\n", i+1, rec)
	}

	return sb.String()
}

func formatK(tokens int) string {
	if tokens >= 1000 {
		return fmt.Sprintf("%d", tokens/1000)
	}
	return fmt.Sprintf("%.1f", float64(tokens)/1000.0)
}

func (ca *CompressionAdvisor) estimateSessionCount() int {
	if len(ca.History) == 0 {
		return 0
	}
	// Estimate sessions by grouping events within 30-minute windows
	if len(ca.History) <= 1 {
		return 1
	}

	sessions := 1
	lastTime := ca.History[0].Timestamp
	for i := 1; i < len(ca.History); i++ {
		if ca.History[i].Timestamp.Sub(lastTime) > 30*time.Minute {
			sessions++
		}
		lastTime = ca.History[i].Timestamp
	}
	return sessions
}

func (ca *CompressionAdvisor) contentTypeAvgSavings() map[string]float64 {
	typeTotals := make(map[string]float64)
	typeCounts := make(map[string]int)
	for _, e := range ca.History {
		typeTotals[e.ContentType] += e.Savings
		typeCounts[e.ContentType]++
	}
	result := make(map[string]float64)
	for ct, total := range typeTotals {
		result[ct] = total / float64(typeCounts[ct])
	}
	return result
}

func (ca *CompressionAdvisor) topRecommendations() []string {
	// Calculate potential savings per content type
	type savingsEntry struct {
		contentType string
		tokens      int
	}
	var entries []savingsEntry

	typeTokens := make(map[string]int)
	for _, e := range ca.History {
		optimal := optimalSavingsForType(e.ContentType)
		if optimal > e.Savings {
			diff := optimal - e.Savings
			typeTokens[e.ContentType] += int(math.Round(diff * float64(e.InputTokens)))
		}
	}

	for ct, tokens := range typeTokens {
		entries = append(entries, savingsEntry{ct, tokens})
	}
	sort.Slice(entries, func(i, j int) bool {
		return entries[i].tokens > entries[j].tokens
	})

	sessionCount := ca.estimateSessionCount()
	if sessionCount == 0 {
		sessionCount = 1
	}

	var recs []string
	for _, entry := range entries {
		perSession := entry.tokens / sessionCount
		switch entry.contentType {
		case "test_output":
			recs = append(recs, fmt.Sprintf("Enable auto-compression for test output (saves ~%sK/session)", formatK(perSession)))
		case "diff":
			recs = append(recs, fmt.Sprintf("Switch git diff to aggressive mode (saves ~%sK/session)", formatK(perSession)))
		case "code":
			recs = append(recs, fmt.Sprintf("Compress tool output over 2000 tokens (saves ~%sK/session)", formatK(perSession)))
		case "natural_language":
			recs = append(recs, fmt.Sprintf("Enable ultra compression for prose content (saves ~%sK/session)", formatK(perSession)))
		case "log":
			recs = append(recs, fmt.Sprintf("Deduplicate log output aggressively (saves ~%sK/session)", formatK(perSession)))
		case "error":
			recs = append(recs, fmt.Sprintf("Apply lite compression to error output (saves ~%sK/session)", formatK(perSession)))
		default:
			recs = append(recs, fmt.Sprintf("Compress %s content (saves ~%sK/session)", entry.contentType, formatK(perSession)))
		}
	}

	if len(recs) == 0 {
		recs = append(recs, "Enable auto-compression for test output (saves ~8K/session)")
		recs = append(recs, "Switch git diff to aggressive mode (saves ~5K/session)")
		recs = append(recs, "Compress tool output over 2000 tokens (saves ~3K/session)")
	}

	return recs
}
