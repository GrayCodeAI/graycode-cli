package cache

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestNewMultiLevelCache(t *testing.T) {
	dir := t.TempDir()
	l2 := filepath.Join(dir, "l2")
	mc, err := NewMultiLevelCache(l2, 10)
	if err != nil {
		t.Fatalf("NewMultiLevelCache returned error: %v", err)
	}
	if mc == nil {
		t.Fatal("NewMultiLevelCache returned nil")
	}
	if _, err := os.Stat(l2); os.IsNotExist(err) {
		t.Error("L2 directory should have been created")
	}
}

func TestMultiLevelCacheSetAndGet(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 10)
	if err != nil {
		t.Fatal(err)
	}

	mc.Set("key1", "value1")
	val, ok := mc.Get("key1")
	if !ok {
		t.Fatal("expected to find key1")
	}
	if val != "value1" {
		t.Errorf("expected value1, got %q", val)
	}
}

func TestMultiLevelCacheMiss(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 10)
	if err != nil {
		t.Fatal(err)
	}

	_, ok := mc.Get("nonexistent")
	if ok {
		t.Error("expected miss for nonexistent key")
	}
}

func TestMultiLevelCacheOverwrite(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 10)
	if err != nil {
		t.Fatal(err)
	}

	mc.Set("key1", "old")
	mc.Set("key1", "new")

	val, ok := mc.Get("key1")
	if !ok {
		t.Fatal("expected to find key1")
	}
	if val != "new" {
		t.Errorf("expected new value, got %q", val)
	}
}

func TestMultiLevelCacheL1Eviction(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 2)
	if err != nil {
		t.Fatal(err)
	}

	mc.Set("a", "1")
	mc.Set("b", "2")
	mc.Set("c", "3") // L1 evicts oldest (a) to stay at maxL1=2

	mc.mu.RLock()
	l1Len := len(mc.l1)
	mc.mu.RUnlock()

	if l1Len > 2 {
		t.Errorf("expected L1 size <= 2 after eviction, got %d", l1Len)
	}

	val, ok := mc.Get("a")
	if !ok {
		t.Error("expected 'a' to be retrievable from L2 after L1 eviction")
	}
	if val != "1" {
		t.Errorf("expected '1', got %q", val)
	}
}

func TestMultiLevelCacheL2Promotion(t *testing.T) {
	dir := t.TempDir()
	l2 := filepath.Join(dir, "l2")
	mc, err := NewMultiLevelCache(l2, 10)
	if err != nil {
		t.Fatal(err)
	}

	mc.Set("key1", "value1")

	mc2, err := NewMultiLevelCache(l2, 10)
	if err != nil {
		t.Fatal(err)
	}

	val, ok := mc2.Get("key1")
	if !ok {
		t.Fatal("expected to retrieve from L2 disk cache")
	}
	if val != "value1" {
		t.Errorf("expected value1, got %q", val)
	}
}

func TestMultiLevelCacheL2PromotionUpdatesL1(t *testing.T) {
	dir := t.TempDir()
	l2 := filepath.Join(dir, "l2")
	mc, err := NewMultiLevelCache(l2, 10)
	if err != nil {
		t.Fatal(err)
	}

	mc.Set("key1", "value1")

	mc2, err := NewMultiLevelCache(l2, 10)
	if err != nil {
		t.Fatal(err)
	}

	mc2.Get("key1")

	t.Log("L1 should now have key1 from promotion")
}

func TestMultiLevelCacheSetGetLargeValue(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 10)
	if err != nil {
		t.Fatal(err)
	}

	largeVal := strings.Repeat("x", 10000)
	mc.Set("large", largeVal)

	val, ok := mc.Get("large")
	if !ok {
		t.Fatal("expected to find large value")
	}
	if val != largeVal {
		t.Errorf("expected large value to match, got length %d", len(val))
	}
}

func TestMultiLevelCacheConcurrent(t *testing.T) {
	dir := t.TempDir()
	mc, err := NewMultiLevelCache(filepath.Join(dir, "l2"), 100)
	if err != nil {
		t.Fatal(err)
	}

	done := make(chan bool)
	for i := 0; i < 20; i++ {
		go func(n int) {
			key := string(rune('a' + n))
			mc.Set(key, "val")
			mc.Get(key)
			done <- true
		}(i)
	}

	for i := 0; i < 20; i++ {
		<-done
	}
}
