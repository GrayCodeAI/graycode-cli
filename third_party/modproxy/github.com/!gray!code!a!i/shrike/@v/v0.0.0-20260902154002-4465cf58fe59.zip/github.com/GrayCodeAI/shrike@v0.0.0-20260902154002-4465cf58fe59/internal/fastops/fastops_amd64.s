//go:build amd64

#include "textflag.h"

// hasANSIavx2 checks for ANSI ESC byte (0x1b) using AVX2.
// func hasANSIavx2(data string) bool
TEXT ·hasANSIavx2(SB), NOSPLIT, $0-17
    MOVQ  data_base+0(FP), SI    // SI = data pointer
    MOVQ  data_len+8(FP), CX     // CX = data length
    TESTQ CX, CX
    JEQ   ansi_false

    // Broadcast 0x1b to all 32 bytes of Y1. VPBROADCASTB only has a
    // GPR-source form under AVX-512 (EVEX-encoded); the AVX2 (VEX-encoded)
    // form requires an XMM/memory source, so stage the byte through X1
    // first to avoid emitting an AVX-512 instruction that SIGILLs on
    // AVX2-only hardware.
    MOVB  $0x1b, R8
    MOVQ  R8, X1
    VPBROADCASTB X1, Y1

    // Number of 32-byte chunks → byte offset
    MOVQ  CX, AX
    SHRQ  $5, AX                 // AX = floor(len / 32)
    JEQ   ansi_tail
    SHLQ  $5, AX                 // AX = byte count for aligned chunks

    // Process full 32-byte chunks
ansi_loop:
    SUBQ  $32, AX                // move to next chunk (backwards from end)
    VMOVDQU 0(SI)(AX*1), Y0
    VPCMPEQB Y1, Y0, Y2
    VPMOVMSKB Y2, DX
    TESTL DX, DX
    JNE   ansi_true
    CMPQ  AX, $0
    JNE   ansi_loop

ansi_tail:
    // Handle remaining 0-31 bytes via scalar
    MOVQ  CX, DX
    ANDQ  $31, DX
    JEQ   ansi_false
    // CX = data + CX = end of buffer
    // DX = remaining count
    ADDQ  SI, CX
    SUBQ  DX, CX                 // CX = start of remaining bytes
ansi_tloop:
    CMPB  0(CX), $0x1b
    JEQ   ansi_true
    INCQ  CX
    DECQ  DX
    JNE   ansi_tloop

ansi_false:
    XORQ  AX, AX
    MOVB  AX, ret+16(FP)
    VZEROUPPER
    RET

ansi_true:
    MOVQ  $1, AX
    MOVB  AX, ret+16(FP)
    VZEROUPPER
    RET

// countBytesAVX2 counts occurrences of a specific byte using AVX2.
// func countBytesAVX2(data string, target byte) int
TEXT ·countBytesAVX2(SB), NOSPLIT, $0-32
    MOVQ  data_base+0(FP), SI    // SI = data pointer
    MOVQ  data_len+8(FP), CX     // CX = data length
    MOVB  target+16(FP), R8      // R8 = target byte
    XORQ  R9, R9                 // R9 = total count

    TESTQ CX, CX
    JEQ   count_done

    // Broadcast target byte to all 32 bytes of Y1 via an AVX2-safe (VEX,
    // XMM-source) form; see hasANSIavx2 for why a direct GPR source is
    // avoided.
    MOVQ  R8, X1
    VPBROADCASTB X1, Y1

    MOVQ  CX, AX
    SHRQ  $5, AX                 // AX = floor(len / 32)
    JEQ   count_tail
    SHLQ  $5, AX                 // AX = byte count for aligned chunks

count_loop:
    SUBQ  $32, AX
    VMOVDQU 0(SI)(AX*1), Y0
    VPCMPEQB Y1, Y0, Y2
    VPMOVMSKB Y2, DX
    // Popcount of bitmask = number of matches in this chunk
    POPCNTQ DX, DX
    ADDQ   DX, R9
    CMPQ   AX, $0
    JNE    count_loop

count_tail:
    // Handle remaining 0-31 bytes
    MOVQ  CX, DX
    ANDQ  $31, DX
    JEQ   count_done
    ADDQ  SI, CX
    SUBQ  DX, CX
count_tloop:
    CMPB  0(CX), R8
    JNE   count_tnext
    INCQ  R9
count_tnext:
    INCQ  CX
    DECQ  DX
    JNE   count_tloop

count_done:
    MOVQ  R9, AX
    MOVQ  AX, ret+24(FP)
    VZEROUPPER
    RET
