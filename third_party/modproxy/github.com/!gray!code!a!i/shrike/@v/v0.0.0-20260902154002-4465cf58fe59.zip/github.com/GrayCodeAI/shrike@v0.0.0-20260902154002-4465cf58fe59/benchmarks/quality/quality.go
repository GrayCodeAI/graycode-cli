// Package quality implements an offline compression-quality benchmark harness.
//
// It runs sample prompts through shrike at several tiers and reports, per tier:
//   - compression ratio   (tokens out / tokens in; lower = more compression)
//   - char retention      (chars out / chars in)
//   - a lexical-fidelity proxy (ROUGE-1 unigram recall of key terms between
//     the original and the compressed text)
//
// Because we cannot run a downstream QA model offline, the fidelity proxy
// stands in for end-task quality: it measures how many of the original's
// informative terms survive compression. A "baseline (no-op)" arm is emitted
// alongside the shrike arms as a placeholder for a real LLMLingua comparison
// until one is wired in.
//
// Everything here is offline: no network, no model calls.
package quality

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"regexp"
	"sort"
	"strings"

	"github.com/GrayCodeAI/shrike"
)

// Sample is one benchmark prompt. The shape matches benchmarks/samples.json.
type Sample struct {
	ID          string `json:"id"`
	Category    string `json:"category"`
	Prompt      string `json:"prompt"`
	Description string `json:"description"`
}

// Tier names a shrike pipeline profile to evaluate. The "baseline (no-op)" arm
// is represented by a nil Option slice and passes input through unchanged.
type Tier struct {
	Name string
	Opts []shrike.Option
}

// DefaultTiers returns the arms evaluated by the harness: a no-op baseline
// (LLMLingua placeholder) plus a spread of shrike tiers from light to maximal.
func DefaultTiers() []Tier {
	return []Tier{
		{Name: "baseline (no-op)", Opts: nil},
		{Name: "surface", Opts: []shrike.Option{shrike.WithTier(shrike.TierSurface)}},
		{Name: "trim", Opts: []shrike.Option{shrike.WithTier(shrike.TierTrim), shrike.Aggressive}},
		{Name: "extract", Opts: []shrike.Option{shrike.WithTier(shrike.TierExtract), shrike.Aggressive}},
	}
}

// Result holds the measured metrics for one (sample, tier) pair.
type Result struct {
	SampleID  string
	Tier      string
	InTokens  int
	OutTokens int
	Ratio     float64 // OutTokens / InTokens (lower = more compression)
	CharRet   float64 // len(out) / len(in)
	Fidelity  float64 // ROUGE-1 key-term recall in [0,1]
}

// TierSummary aggregates results across all samples for a single tier.
type TierSummary struct {
	Tier        string
	AvgRatio    float64
	AvgCharRet  float64
	AvgFidelity float64
	Samples     int
}

// LoadSamples reads a samples JSON file (the benchmarks/samples.json shape).
func LoadSamples(path string) ([]Sample, error) {
	data, err := os.ReadFile(path) // #nosec G304 -- path is a benchmark fixture path supplied by the harness caller (e.g. benchmarks/samples.json), not externally supplied
	if err != nil {
		return nil, fmt.Errorf("read samples: %w", err)
	}
	var samples []Sample
	if err := json.Unmarshal(data, &samples); err != nil {
		return nil, fmt.Errorf("parse samples: %w", err)
	}
	return samples, nil
}

// LongBenchSamples returns a few LongBench-style prose/QA entries that exercise
// the prose-compression paths the shell-command samples.json does not. They are
// embedded so the harness stays fully offline.
func LongBenchSamples() []Sample {
	return []Sample{
		{
			ID:       "lb-narrativeqa",
			Category: "longbench-qa",
			Prompt: "The expedition set out from the coastal village at dawn. " +
				"Captain Reyes had spent the better part of a year planning the route through the northern passage. " +
				"The crew, weary but determined, loaded the last of the provisions before the tide turned. " +
				"By midday the fog had lifted and the open water lay ahead, calm and endless. " +
				"Reyes noted in the log that the barometer was steady and the wind favorable. " +
				"What no one aboard knew was that the charts they relied upon were nearly two decades out of date. " +
				"Question: Why was the expedition ultimately at risk despite favorable conditions?",
			Description: "Long narrative passage with a trailing QA question",
		},
		{
			ID:       "lb-multidoc",
			Category: "longbench-qa",
			Prompt: "Document 1: Quarterly revenue rose 12 percent year over year, driven by cloud services. " +
				"Operating margin contracted slightly due to increased data-center investment. " +
				"Document 2: The company announced a new regional data center in Frankfurt, expected online next year. " +
				"Document 3: Analysts noted that competitors have been cutting prices aggressively in the same segment. " +
				"Question: What factors explain the margin contraction this quarter?",
			Description: "Multi-document context with synthesis question",
		},
		{
			ID:       "lb-summarization",
			Category: "longbench-summ",
			Prompt: "The committee convened to review the proposed amendments to the zoning ordinance. " +
				"After three hours of public comment, the members debated the impact on local traffic, school capacity, and green space. " +
				"Several residents expressed concern that increased density would strain existing infrastructure. " +
				"The developer countered that the project included funding for road improvements and a new park. " +
				"Ultimately the committee voted four to two to advance the proposal to the full council with conditions.",
			Description: "Meeting-minutes prose for summarization fidelity",
		},
	}
}

// termRE matches word-like tokens for the key-term fidelity proxy.
var termRE = regexp.MustCompile(`[A-Za-z0-9_]+`)

// stopwords are common, low-information words excluded from the fidelity proxy
// so the metric reflects retention of meaningful terms rather than glue words.
var stopwords = map[string]struct{}{
	"the": {}, "a": {}, "an": {}, "and": {}, "or": {}, "but": {}, "of": {},
	"to": {}, "in": {}, "on": {}, "at": {}, "for": {}, "with": {}, "by": {},
	"is": {}, "was": {}, "were": {}, "be": {}, "been": {}, "are": {}, "as": {},
	"that": {}, "this": {}, "it": {}, "from": {}, "had": {}, "has": {}, "have": {},
}

// keyTerms extracts lowercased informative unigrams from text.
func keyTerms(text string) []string {
	matches := termRE.FindAllString(strings.ToLower(text), -1)
	out := matches[:0]
	for _, m := range matches {
		if _, stop := stopwords[m]; stop {
			continue
		}
		out = append(out, m)
	}
	return out
}

// Rouge1Recall computes ROUGE-1 recall of key terms: the fraction of the
// original's distinct informative unigrams that also appear in the compressed
// text. Recall (not F1) is the right proxy here — compression is allowed to
// drop tokens, and we care how much source signal survives.
func Rouge1Recall(original, compressed string) float64 {
	origTerms := keyTerms(original)
	if len(origTerms) == 0 {
		return 1.0 // nothing to retain; treat as fully faithful
	}
	compSet := make(map[string]struct{})
	for _, t := range keyTerms(compressed) {
		compSet[t] = struct{}{}
	}
	origSet := make(map[string]struct{}, len(origTerms))
	for _, t := range origTerms {
		origSet[t] = struct{}{}
	}
	retained := 0
	for t := range origSet {
		if _, ok := compSet[t]; ok {
			retained++
		}
	}
	return float64(retained) / float64(len(origSet))
}

// Evaluate runs every sample through every tier and returns the raw results.
func Evaluate(samples []Sample, tiers []Tier) []Result {
	var results []Result
	for _, s := range samples {
		inTokens := shrike.EstimateTokens(s.Prompt)
		inChars := len(s.Prompt)
		for _, t := range tiers {
			var out string
			if len(t.Opts) == 0 {
				// baseline (no-op): pass-through placeholder for LLMLingua.
				out = s.Prompt
			} else {
				out, _ = shrike.Compress(s.Prompt, t.Opts...)
			}
			outTokens := shrike.EstimateTokens(out)
			r := Result{
				SampleID:  s.ID,
				Tier:      t.Name,
				InTokens:  inTokens,
				OutTokens: outTokens,
				Ratio:     ratio(outTokens, inTokens),
				CharRet:   ratio(len(out), inChars),
				Fidelity:  Rouge1Recall(s.Prompt, out),
			}
			results = append(results, r)
		}
	}
	return results
}

func ratio(num, den int) float64 {
	if den == 0 {
		return 0
	}
	return float64(num) / float64(den)
}

// Summarize aggregates per-tier averages across samples, preserving the tier
// ordering supplied in tiers.
func Summarize(results []Result, tiers []Tier) []TierSummary {
	type acc struct {
		ratio, charRet, fidelity float64
		n                        int
	}
	byTier := make(map[string]*acc)
	for _, r := range results {
		a := byTier[r.Tier]
		if a == nil {
			a = &acc{}
			byTier[r.Tier] = a
		}
		a.ratio += r.Ratio
		a.charRet += r.CharRet
		a.fidelity += r.Fidelity
		a.n++
	}

	var summaries []TierSummary
	for _, t := range tiers {
		a := byTier[t.Name]
		if a == nil || a.n == 0 {
			continue
		}
		summaries = append(summaries, TierSummary{
			Tier:        t.Name,
			AvgRatio:    a.ratio / float64(a.n),
			AvgCharRet:  a.charRet / float64(a.n),
			AvgFidelity: a.fidelity / float64(a.n),
			Samples:     a.n,
		})
	}
	return summaries
}

// WriteMarkdown emits a human-readable report: a per-tier summary table
// followed by per-sample detail. The baseline (no-op) row is clearly labeled.
func WriteMarkdown(w io.Writer, summaries []TierSummary, results []Result) error {
	var b strings.Builder
	b.WriteString("# shrike Compression-Quality Benchmark\n\n")
	b.WriteString("Offline harness: shrike tiers vs a **baseline (no-op)** arm standing in for\n")
	b.WriteString("LLMLingua until a real comparison is wired in. Metrics:\n\n")
	b.WriteString("- **Ratio** = tokens out / tokens in (lower = more compression)\n")
	b.WriteString("- **Char ret.** = chars out / chars in\n")
	b.WriteString("- **Fidelity** = ROUGE-1 key-term recall vs original (higher = more signal kept)\n\n")

	b.WriteString("## Per-Tier Summary\n\n")
	b.WriteString("| Tier | Samples | Avg Ratio | Avg Char ret. | Avg Fidelity |\n")
	b.WriteString("|------|---------|-----------|---------------|--------------|\n")
	for _, s := range summaries {
		fmt.Fprintf(&b, "| %s | %d | %.3f | %.3f | %.3f |\n",
			s.Tier, s.Samples, s.AvgRatio, s.AvgCharRet, s.AvgFidelity)
	}

	b.WriteString("\n## Per-Sample Detail\n\n")
	b.WriteString("| Sample | Tier | In shrike | Out shrike | Ratio | Char ret. | Fidelity |\n")
	b.WriteString("|--------|------|--------|---------|-------|-----------|----------|\n")
	sorted := append([]Result(nil), results...)
	sort.SliceStable(sorted, func(i, j int) bool {
		if sorted[i].SampleID != sorted[j].SampleID {
			return sorted[i].SampleID < sorted[j].SampleID
		}
		return sorted[i].Tier < sorted[j].Tier
	})
	for _, r := range sorted {
		fmt.Fprintf(&b, "| %s | %s | %d | %d | %.3f | %.3f | %.3f |\n",
			r.SampleID, r.Tier, r.InTokens, r.OutTokens, r.Ratio, r.CharRet, r.Fidelity)
	}

	b.WriteString("\n_Baseline (no-op) is a pass-through placeholder; ratio 1.000 and fidelity 1.000 are expected._\n")
	_, err := io.WriteString(w, b.String())
	return err
}

// WriteCSV emits the per-sample results as CSV for downstream analysis.
func WriteCSV(w io.Writer, results []Result) error {
	var b strings.Builder
	b.WriteString("sample,tier,in_tokens,out_tokens,ratio,char_retention,fidelity\n")
	for _, r := range results {
		fmt.Fprintf(&b, "%s,%s,%d,%d,%.4f,%.4f,%.4f\n",
			r.SampleID, csvField(r.Tier), r.InTokens, r.OutTokens, r.Ratio, r.CharRet, r.Fidelity)
	}
	_, err := io.WriteString(w, b.String())
	return err
}

func csvField(s string) string {
	if strings.ContainsAny(s, ",\"\n") {
		return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
	}
	return s
}
