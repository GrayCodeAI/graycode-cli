package filter

import (
	"context"
	"strings"
	"testing"
)

func TestCompressWithRetry_ValidatesOnFirstTry(t *testing.T) {
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		return "compressed: " + text, &PipelineStats{}
	}
	validator := func(out string, _ *PipelineStats) (bool, string) {
		if !strings.HasPrefix(out, "compressed:") {
			return false, "missing prefix"
		}
		return true, ""
	}
	out, rs, err := CompressWithRetry(
		context.Background(), "hello", ModeMinimal, 0, 3,
		compress, validator, nil,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if out != "compressed: hello" {
		t.Errorf("unexpected output: %q", out)
	}
	if rs.Attempts != 1 {
		t.Errorf("expected 1 attempt, got %d", rs.Attempts)
	}
	if rs.EscalatedAtLeastOnce {
		t.Error("expected no escalation on first-try success")
	}
}

func TestCompressWithRetry_RetriesUntilValid(t *testing.T) {
	attempt := 0
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		attempt++
		// First two attempts produce "bad" output; third produces good.
		if attempt < 3 {
			return "bad output", &PipelineStats{}
		}
		return "good output", &PipelineStats{}
	}
	validator := func(out string, _ *PipelineStats) (bool, string) {
		if out == "good output" {
			return true, ""
		}
		return false, "not good"
	}
	out, rs, err := CompressWithRetry(
		context.Background(), "x", ModeMinimal, 0, 5,
		compress, validator, nil,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if out != "good output" {
		t.Errorf("expected 'good output', got %q", out)
	}
	if rs.Attempts != 3 {
		t.Errorf("expected 3 attempts, got %d", rs.Attempts)
	}
	if !rs.EscalatedAtLeastOnce {
		t.Error("expected at least one escalation")
	}
	if rs.LastFailureReason != "not good" {
		t.Errorf("expected reason 'not good', got %q", rs.LastFailureReason)
	}
}

func TestCompressWithRetry_ExhaustsAndReturnsLast(t *testing.T) {
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		return "always bad", &PipelineStats{}
	}
	validator := func(_ string, _ *PipelineStats) (bool, string) {
		return false, "never good"
	}
	out, rs, err := CompressWithRetry(
		context.Background(), "x", ModeMinimal, 0, 3,
		compress, validator, nil,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if out != "always bad" {
		t.Errorf("expected 'always bad', got %q", out)
	}
	if rs.Attempts != 3 {
		t.Errorf("expected 3 attempts (max), got %d", rs.Attempts)
	}
	if rs.LastFailureReason != "never good" {
		t.Errorf("expected reason 'never good', got %q", rs.LastFailureReason)
	}
}

func TestCompressWithRetry_NilValidatorReturnsError(t *testing.T) {
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		return text, &PipelineStats{}
	}
	_, _, err := CompressWithRetry(
		context.Background(), "x", ModeMinimal, 0, 3,
		compress, nil, nil,
	)
	if err == nil {
		t.Error("expected error for nil validator")
	}
	if err != ErrNoValidator {
		t.Errorf("expected ErrNoValidator, got %v", err)
	}
}

func TestCompressWithRetry_DefaultAdjustEscalates(t *testing.T) {
	calls := []Mode{}
	compress := func(_ context.Context, text string, mode Mode, _ int) (string, *PipelineStats) {
		calls = append(calls, mode)
		// Always fail validation, so we always retry.
		return text, &PipelineStats{}
	}
	validator := func(_ string, _ *PipelineStats) (bool, string) {
		return false, "always fail"
	}
	_, _, _ = CompressWithRetry(
		context.Background(), "x", ModeMinimal, 0, 3,
		compress, validator, nil,
	)
	if len(calls) != 3 {
		t.Fatalf("expected 3 compress calls, got %d", len(calls))
	}
	if calls[0] != ModeMinimal {
		t.Errorf("expected first call ModeMinimal, got %v", calls[0])
	}
	if calls[1] != ModeAggressive {
		t.Errorf("expected second call ModeAggressive (escalated), got %v", calls[1])
	}
	// Third call: mode stays Aggressive, intensity bumped.
	if calls[2] != ModeAggressive {
		t.Errorf("expected third call ModeAggressive, got %v", calls[2])
	}
}

func TestCompressWithRetry_CustomAdjust(t *testing.T) {
	calls := 0
	compress := func(_ context.Context, text string, _ Mode, intensity int) (string, *PipelineStats) {
		calls++
		// First call fails, second call passes.
		if calls >= 2 {
			return "pass", &PipelineStats{}
		}
		return "fail", &PipelineStats{}
	}
	validator := func(out string, _ *PipelineStats) (bool, string) {
		if out == "pass" {
			return true, ""
		}
		return false, "not pass"
	}
	adjust := func(_ Mode, intensity int) (Mode, int) {
		return ModeAggressive, intensity + 10
	}
	_, rs, _ := CompressWithRetry(
		context.Background(), "x", ModeMinimal, 5, 3,
		compress, validator, adjust,
	)
	if rs.Attempts != 2 {
		t.Errorf("expected 2 attempts, got %d", rs.Attempts)
	}
}

func TestCompressWithRetry_ContextCancelled(t *testing.T) {
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		return text, &PipelineStats{}
	}
	validator := func(_ string, _ *PipelineStats) (bool, string) {
		return false, "always fail"
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel() // cancel before call
	_, _, err := CompressWithRetry(
		ctx, "x", ModeMinimal, 0, 3,
		compress, validator, nil,
	)
	if err == nil {
		t.Error("expected context error")
	}
}

func TestMustContainsValidator(t *testing.T) {
	v := MustContainsValidator("foo", "bar")
	if ok, _ := v("the foo and bar are here", &PipelineStats{}); !ok {
		t.Error("expected validator to pass when both terms present")
	}
	if ok, reason := v("only foo here", &PipelineStats{}); ok {
		t.Errorf("expected validator to fail, got ok=true; reason=%q", reason)
	}
	if ok, reason := v("only bar here", &PipelineStats{}); ok {
		t.Errorf("expected validator to fail, got ok=true; reason=%q", reason)
	}
	if ok, reason := v("nothing here", &PipelineStats{}); ok {
		t.Errorf("expected validator to fail, got ok=true; reason=%q", reason)
	}
}

func TestMaxTokensValidator(t *testing.T) {
	v := MaxTokensValidator(10)
	// Empty output
	if ok, _ := v("", &PipelineStats{}); !ok {
		t.Error("expected empty to pass")
	}
	// Tiny output
	if ok, _ := v("hello", &PipelineStats{}); !ok {
		t.Error("expected short to pass")
	}
	// Huge output
	huge := strings.Repeat("word ", 1000)
	if ok, reason := v(huge, &PipelineStats{}); ok {
		t.Errorf("expected huge to fail; got reason=%q", reason)
	}
	// Budget of 0 means no limit
	v0 := MaxTokensValidator(0)
	if ok, _ := v0("anything", &PipelineStats{}); !ok {
		t.Error("expected budget=0 to always pass")
	}
}

func TestCompressWithBudgetRetry(t *testing.T) {
	attempt := 0
	compress := func(_ context.Context, text string, _ Mode, _ int) (string, *PipelineStats) {
		attempt++
		// First call: huge output (fails). Second call: small output (passes).
		if attempt == 1 {
			return strings.Repeat("bigword ", 500), &PipelineStats{}
		}
		return "small", &PipelineStats{}
	}
	out, rs, err := CompressWithBudgetRetry(
		context.Background(), "x", ModeMinimal, 50, 3,
		compress,
	)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if out != "small" {
		t.Errorf("expected 'small', got %q", out)
	}
	if rs.Attempts != 2 {
		t.Errorf("expected 2 attempts, got %d", rs.Attempts)
	}
}
