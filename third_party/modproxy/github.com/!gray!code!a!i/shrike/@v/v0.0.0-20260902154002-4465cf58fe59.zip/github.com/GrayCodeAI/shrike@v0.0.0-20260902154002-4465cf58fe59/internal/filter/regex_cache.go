package filter

import (
	"regexp"
	"sync"
)

const maxRegexCacheSize = 1024

// RegexCache caches compiled regexes with a size limit
type RegexCache struct {
	mu    sync.RWMutex
	cache map[string]*regexp.Regexp
}

var globalRegexCache = &RegexCache{cache: make(map[string]*regexp.Regexp)}

func CompileRegex(pattern string) *regexp.Regexp {
	globalRegexCache.mu.RLock()
	if re, ok := globalRegexCache.cache[pattern]; ok {
		globalRegexCache.mu.RUnlock()
		return re
	}
	globalRegexCache.mu.RUnlock()

	globalRegexCache.mu.Lock()
	defer globalRegexCache.mu.Unlock()

	// Double-check after acquiring write lock
	if re, ok := globalRegexCache.cache[pattern]; ok {
		return re
	}

	// Evict all if at capacity
	if len(globalRegexCache.cache) >= maxRegexCacheSize {
		globalRegexCache.cache = make(map[string]*regexp.Regexp)
	}

	re := regexp.MustCompile(pattern)
	globalRegexCache.cache[pattern] = re
	return re
}
