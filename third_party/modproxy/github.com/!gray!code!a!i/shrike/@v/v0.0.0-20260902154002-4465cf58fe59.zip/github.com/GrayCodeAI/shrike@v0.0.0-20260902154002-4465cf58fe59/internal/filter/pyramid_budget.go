package filter

import "math"

type PyramidBudget struct {
	TotalReduction float64
	LayerCount     int
}

func NewPyramidBudget(totalReduction float64, layerCount int) *PyramidBudget {
	if layerCount < 1 {
		layerCount = 1
	}
	if totalReduction < 0 {
		totalReduction = 0
	}
	if totalReduction > 1 {
		totalReduction = 1
	}
	return &PyramidBudget{
		TotalReduction: totalReduction,
		LayerCount:     layerCount,
	}
}

func (p *PyramidBudget) LayerBudget(layerIndex int) float64 {
	if p.LayerCount <= 1 {
		return p.TotalReduction
	}
	budgets := p.Distribute()
	if layerIndex < 0 {
		layerIndex = 0
	}
	if layerIndex >= len(budgets) {
		layerIndex = len(budgets) - 1
	}
	return budgets[layerIndex]
}

func (p *PyramidBudget) Distribute() []float64 {
	if p.LayerCount <= 0 {
		return nil
	}
	if p.LayerCount == 1 {
		return []float64{p.TotalReduction}
	}

	ratio := 3.0
	weights := make([]float64, p.LayerCount)
	for i := 0; i < p.LayerCount; i++ {
		exponent := float64(i) / float64(p.LayerCount-1)
		weights[i] = math.Pow(ratio, exponent)
	}

	var totalWeight float64
	for _, w := range weights {
		totalWeight += w
	}

	budgets := make([]float64, p.LayerCount)
	for i, w := range weights {
		budgets[i] = (w / totalWeight) * p.TotalReduction
	}

	return budgets
}

func (p *PyramidBudget) CumulativeReduction(throughLayer int) float64 {
	budgets := p.Distribute()
	var total float64
	for i := 0; i <= throughLayer && i < len(budgets); i++ {
		total += budgets[i]
	}
	return total
}
