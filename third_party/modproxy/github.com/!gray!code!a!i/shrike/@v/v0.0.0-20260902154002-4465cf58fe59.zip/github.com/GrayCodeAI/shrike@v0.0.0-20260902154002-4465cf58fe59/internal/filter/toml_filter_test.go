package filter

import (
	"os"
	"strings"
	"testing"
)

func TestTOMLFilter_StripANSI(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:      "test",
		StripANSI: true,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "\x1b[31mERROR\x1b[0m: something failed"
	out, _ := f.Apply(input, ModeMinimal)
	if strings.Contains(out, "\x1b[") {
		t.Errorf("expected ANSI stripped, got %q", out)
	}
	if !strings.Contains(out, "ERROR: something failed") {
		t.Errorf("expected text preserved, got %q", out)
	}
}

func TestTOMLFilter_StripLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:       "test",
		StripLines: []string{`^\s*$`, `^DEBUG`},
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "INFO hello\n\nDEBUG internal\nERROR oh no\n"
	out, _ := f.Apply(input, ModeMinimal)
	if strings.Contains(out, "DEBUG") {
		t.Errorf("expected DEBUG stripped, got %q", out)
	}
	if strings.Contains(out, "\n\n") {
		t.Errorf("expected empty lines stripped, got %q", out)
	}
	if !strings.Contains(out, "ERROR") {
		t.Errorf("expected ERROR preserved, got %q", out)
	}
}

func TestTOMLFilter_KeepLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:      "test",
		KeepLines: []string{`^ERROR`, `^WARN`},
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "INFO hello\nERROR oops\nWARN careful\nDEBUG internal\n"
	out, _ := f.Apply(input, ModeMinimal)
	if strings.Contains(out, "INFO") {
		t.Errorf("expected INFO filtered, got %q", out)
	}
	if strings.Contains(out, "DEBUG") {
		t.Errorf("expected DEBUG filtered, got %q", out)
	}
	if !strings.Contains(out, "ERROR") {
		t.Errorf("expected ERROR kept, got %q", out)
	}
	if !strings.Contains(out, "WARN") {
		t.Errorf("expected WARN kept, got %q", out)
	}
}

func TestTOMLFilter_Replace(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name: "test",
		Replace: []TOMLReplaceRule{
			{Pattern: `\bTODO\b`, Replacement: "DONE"},
			{Pattern: `foo`, Replacement: "bar"},
		},
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "TODO: replace foo with bar"
	out, _ := f.Apply(input, ModeMinimal)
	if !strings.Contains(out, "DONE: replace bar with bar") {
		t.Errorf("expected replace, got %q", out)
	}
}

func TestTOMLFilter_ReplaceLiteral(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name: "test",
		Replace: []TOMLReplaceRule{
			{Pattern: ".", Replacement: "X", Literal: true},
		},
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "a.b.c"
	out, _ := f.Apply(input, ModeMinimal)
	if out != "aXbXc" {
		t.Errorf("expected literal replace aXbXc, got %q", out)
	}
}

func TestTOMLFilter_MatchOutputShortCircuit(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:        "test",
		MatchOutput: `^no changes`,
		OnEmpty:     "nothing to report",
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	out, _ := f.Apply("no changes detected", ModeMinimal)
	if out != "nothing to report" {
		t.Errorf("expected short-circuit to on_empty, got %q", out)
	}
}

func TestTOMLFilter_MaxLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:     "test",
		MaxLines: 4,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	var lines []string
	for i := 0; i < 100; i++ {
		lines = append(lines, "line_"+itoa100(i))
	}
	input := strings.Join(lines, "\n")
	out, _ := f.Apply(input, ModeMinimal)
	if !strings.Contains(out, "lines omitted") {
		t.Errorf("expected marker, got %q", out)
	}
}

func TestTOMLFilter_HeadLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:      "test",
		HeadLines: 3,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "a\nb\nc\nd\ne\nf"
	out, _ := f.Apply(input, ModeMinimal)
	if out != "a\nb\nc" {
		t.Errorf("expected first 3 lines, got %q", out)
	}
}

func TestTOMLFilter_TailLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:      "test",
		TailLines: 3,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "a\nb\nc\nd\ne\nf"
	out, _ := f.Apply(input, ModeMinimal)
	if out != "d\ne\nf" {
		t.Errorf("expected last 3 lines, got %q", out)
	}
}

func TestTOMLFilter_HeadAndTail(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:      "test",
		HeadLines: 2,
		TailLines: 2,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "a\nb\nc\nd\ne\nf\ng\nh"
	out, _ := f.Apply(input, ModeMinimal)
	if !strings.HasPrefix(out, "a\nb") {
		t.Errorf("expected head=a\\nb, got prefix %q", out)
	}
	if !strings.HasSuffix(out, "g\nh") {
		t.Errorf("expected tail=g\\nh, got suffix %q", out)
	}
	if !strings.Contains(out, "lines omitted") {
		t.Errorf("expected marker between head and tail, got %q", out)
	}
}

func TestTOMLFilter_TruncateLines(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:          "test",
		TruncateLines: 5,
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	input := "short\nthisisalongline"
	out, _ := f.Apply(input, ModeMinimal)
	lines := strings.Split(out, "\n")
	if len(lines[0]) != 5 {
		t.Errorf("expected first line 5 chars, got %d", len(lines[0]))
	}
	if !strings.HasSuffix(lines[1], "...") {
		t.Errorf("expected long line truncated with ..., got %q", lines[1])
	}
}

func TestTOMLFilter_OnEmpty(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:    "test",
		OnEmpty: "no output",
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	out, _ := f.Apply("", ModeMinimal)
	if out != "no output" {
		t.Errorf("expected on_empty for empty input, got %q", out)
	}
	out, _ = f.Apply("   \n\n  ", ModeMinimal)
	if out != "no output" {
		t.Errorf("expected on_empty for whitespace input, got %q", out)
	}
}

func TestTOMLFilter_MatchCommand(t *testing.T) {
	cfg := &TOMLFilterConfig{
		Name:         "jest_run",
		MatchCommand: `jest|npm.*test`,
		StripLines:   []string{`^PASS`},
	}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	if !cfg.Match("npm test") {
		t.Error("expected npm test to match")
	}
	if !cfg.Match("jest --coverage") {
		t.Error("expected jest to match")
	}
	if cfg.Match("pytest") {
		t.Error("expected pytest NOT to match")
	}
}

func TestTOMLFilter_LoadTOMLFilterFile(t *testing.T) {
	f, err := LoadTOMLFilterFile(findFilterFile(t, "eslint.toml"))
	if err != nil {
		t.Skipf("filter file not present: %v", err)
	}
	if f.Schema != 1 {
		t.Errorf("expected schema_version=1, got %d", f.Schema)
	}
	if len(f.Filters) == 0 {
		t.Error("expected at least one filter")
	}
	for name, cfg := range f.Filters {
		if cfg.Name != name {
			t.Errorf("name mismatch: %q vs %q", cfg.Name, name)
		}
	}
	hasMatch := false
	for _, cfg := range f.Filters {
		if cfg.MatchCommand != "" {
			hasMatch = true
			break
		}
	}
	if !hasMatch {
		t.Error("expected at least one filter with match_command")
	}
}

func TestTOMLFilter_ApplyRealESLint(t *testing.T) {
	f, err := LoadTOMLFilterFile(findFilterFile(t, "eslint.toml"))
	if err != nil {
		t.Skipf("filter file not present: %v", err)
	}
	cfg, ok := f.Filters["eslint_run"]
	if !ok {
		t.Skip("eslint_run not in file")
	}
	filter := NewTOMLFilter(cfg)
	input := "\x1b[31mError\x1b[0m: unused var\n\n\x1b[32m✓\x1b[0m clean\n"
	out, saved := filter.Apply(input, ModeMinimal)
	if strings.Contains(out, "\x1b[") {
		t.Errorf("expected ANSI stripped, got %q", out)
	}
	if !strings.Contains(out, "Error: unused var") {
		t.Errorf("expected Error preserved, got %q", out)
	}
	if saved < 0 {
		t.Errorf("expected non-negative tokens saved, got %d", saved)
	}
}

func TestTOMLFilter_Name(t *testing.T) {
	cfg := &TOMLFilterConfig{Name: "my_filter"}
	f := NewTOMLFilter(cfg)
	if f.Name() != "my_filter" {
		t.Errorf("expected name 'my_filter', got %q", f.Name())
	}
}

func TestTOMLFilter_ImplementsFilterInterface(t *testing.T) {
	cfg := &TOMLFilterConfig{Name: "test"}
	if err := cfg.compile(); err != nil {
		t.Fatal(err)
	}
	f := NewTOMLFilter(cfg)
	// Compile-time check via assignment
	var _ Filter = f
}

// findFilterFile locates a TOML filter file by name. Tests are run from
// the package directory (internal/filter/), so the filter files live
// ../../filters/ relative to the test binary.
func findFilterFile(t *testing.T, name string) string {
	t.Helper()
	candidates := []string{
		"../../filters/" + name,
		"../../../filters/" + name,
	}
	for _, p := range candidates {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	t.Skipf("filter file %s not found in any of: %v", name, candidates)
	return ""
}

// itoa100 is a simple int-to-string helper for test code.
func itoa100(n int) string {
	if n == 0 {
		return "0"
	}
	var buf [20]byte
	i := len(buf)
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	return string(buf[i:])
}
