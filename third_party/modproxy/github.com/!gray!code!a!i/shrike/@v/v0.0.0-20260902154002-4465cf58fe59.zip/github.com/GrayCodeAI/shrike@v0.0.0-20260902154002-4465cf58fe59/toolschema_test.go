package shrike

import (
	"encoding/json"
	"reflect"
	"strings"
	"testing"
)

const bigDesc = "Reads a file from the local filesystem. " +
	"The path parameter must be an absolute path. " +
	"Lines longer than 2000 characters are truncated. " +
	"You cannot read binary files with this tool. " +
	"At most 100 lines are returned by default. " +
	"The result includes line numbers as a gutter prefix on every line. " +
	"Performance remains fast even on very large inputs of many megabytes. " +
	"Files are read from the workspace sandbox when one is configured. " +
	"Symlinks are followed unless they escape the allowed directories. " +
	"Encoding must be valid UTF-8; ISO-8859-1 input is rejected with a clear error message. " +
	"When the same file is requested repeatedly results are served from an internal cache. " +
	"This tool is great for exploring code quickly."

func sampleCatalog() string {
	catalog := []map[string]interface{}{{
		"type": "function",
		"function": map[string]interface{}{
			"name":        "read_file",
			"description": bigDesc,
			"parameters": map[string]interface{}{
				"$schema":              "http://json-schema.org/draft-07/schema#",
				"title":                "Read file parameters",
				"examples":             []interface{}{map[string]string{"path": "/x"}},
				"type":                 "object",
				"required":             []string{"path"},
				"additionalProperties": false,
				"properties": map[string]interface{}{
					"path": map[string]interface{}{
						"type":        "string",
						"description": "Absolute path to the file. Must exist on disk. Max length 4096 bytes.",
					},
					"limit": map[string]interface{}{
						"type":    "integer",
						"default": 100,
						"maximum": 500,
					},
				},
			},
		},
	}}
	b, _ := json.Marshal(catalog)
	return string(b)
}

// selectionProfile extracts the structural surface that must survive
// byte-for-byte: names, param names, types, enums, required, defaults.
func selectionProfile(t *testing.T, catalog string) interface{} {
	t.Helper()
	var tools []struct {
		Function struct {
			Name       string                 `json:"name"`
			Parameters map[string]interface{} `json:"parameters"`
		} `json:"function"`
	}
	if err := json.Unmarshal([]byte(catalog), &tools); err != nil {
		t.Fatalf("parse catalog: %v", err)
	}
	var profile []interface{}
	for _, tool := range tools {
		props := map[string]interface{}{}
		if params, ok := tool.Function.Parameters["properties"].(map[string]interface{}); ok {
			for name, p := range params {
				pm := p.(map[string]interface{})
				entry := map[string]interface{}{"type": pm["type"]}
				for _, k := range []string{"enum", "required", "default", "maximum", "minimum", "format"} {
					if v, ok := pm[k]; ok {
						entry[k] = v
					}
				}
				props[name] = entry
			}
		}
		req, _ := tool.Function.Parameters["required"].([]interface{})
		profile = append(profile, map[string]interface{}{
			"name":      tool.Function.Name,
			"required":  req,
			"props":     props,
			"addProps":  tool.Function.Parameters["additionalProperties"],
			"paramType": tool.Function.Parameters["type"],
		})
	}
	return profile
}

func TestShrinkKeepsSelectionSurfaceIdentical(t *testing.T) {
	in := sampleCatalog()
	out, ok := ShrinkToolCatalog(in)
	if !ok {
		t.Fatal("expected shrink to change a bloated catalog")
	}
	before := selectionProfile(t, in)
	after := selectionProfile(t, out)
	if !reflect.DeepEqual(before, after) {
		t.Fatalf("selection surface changed:\nbefore=%#v\nafter=%#v", before, after)
	}
}

func TestShrinkReducesLongDescriptions(t *testing.T) {
	out, ok := ShrinkToolCatalog(sampleCatalog())
	if !ok {
		t.Fatal("no reduction")
	}
	var tools []struct {
		Function struct {
			Description string `json:"description"`
			Parameters  struct {
				Properties struct {
					Path struct {
						Description string `json:"description"`
					} `json:"path"`
				} `json:"properties"`
			} `json:"parameters"`
		} `json:"function"`
	}
	if err := json.Unmarshal([]byte(out), &tools); err != nil {
		t.Fatal(err)
	}
	d := tools[0].Function.Description
	if len(d) >= len(bigDesc) {
		t.Fatalf("description not reduced: %q", d)
	}
	if !strings.HasPrefix(d, "Reads a file") {
		t.Fatalf("lead sentence lost: %q", d)
	}
	for _, want := range []string{"must be an absolute path", "cannot read binary", "At most 100"} {
		if !strings.Contains(d, want) {
			t.Fatalf("constraint sentence lost (%q): %q", want, d)
		}
	}
	if strings.Contains(d, "great for exploring") {
		t.Fatalf("flattery should have been dropped: %q", d)
	}
}

func TestShrinkDropsAnnotationsKeepsDefaults(t *testing.T) {
	out, _ := ShrinkToolCatalog(sampleCatalog())
	if strings.Contains(out, "$schema") || strings.Contains(out, `"title"`) || strings.Contains(out, "examples") {
		t.Fatalf("annotation metadata survived: %s", out)
	}
	if !strings.Contains(out, `"default":100`) && !strings.Contains(out, `"default": 100`) {
		t.Fatalf("default dropped: %s", out)
	}
}

func TestShrinkFailOpenOnGarbage(t *testing.T) {
	for _, in := range []string{"", "not json", `{"a":1}`, `[]`} {
		if out, changed := ShrinkToolCatalog(in); changed || out != in {
			t.Fatalf("input %q must pass through unchanged", in)
		}
	}
}

func TestShrinkPassThroughWhenNotSmaller(t *testing.T) {
	in := `[{"type":"function","function":{"name":"tiny","description":"ok","parameters":{"type":"object"}}}]`
	out, changed := ShrinkToolCatalog(in)
	if changed || out != in {
		t.Fatalf("not-smaller catalogs must be returned unchanged (changed=%v)", changed)
	}
}

func TestShrinkShortDescriptionUntouched(t *testing.T) {
	in := `[{"type":"function","function":{"name":"f","description":"Does a thing. Optional: set mode.","parameters":{"type":"object"}}}]`
	out, changed := ShrinkToolCatalog(in)
	_ = out
	if changed {
		t.Fatal("short descriptions must be kept whole (fail-open over-keep)")
	}
}

func TestLintToolCatalogReports(t *testing.T) {
	stats, ok := LintToolCatalog(sampleCatalog())
	if !ok || len(stats) != 1 {
		t.Fatalf("lint = %v %v", stats, ok)
	}
	if stats[0].Name != "read_file" || stats[0].After >= stats[0].Before {
		t.Fatalf("stats = %+v", stats[0])
	}
}
