package utils

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestInitLogger(t *testing.T) {
	dir := t.TempDir()
	logPath := filepath.Join(dir, "test.log")

	err := InitLogger(logPath, LevelInfo)
	if err != nil {
		t.Fatalf("InitLogger returned error: %v", err)
	}
	if Logger == nil {
		t.Fatal("Logger should be initialized")
	}

	_, err = os.Stat(logPath)
	if err != nil {
		t.Errorf("log file should exist: %v", err)
	}

	CloseLogger()
}

func TestInitLoggerCreatesDir(t *testing.T) {
	dir := t.TempDir()
	logPath := filepath.Join(dir, "subdir", "test.log")

	err := InitLogger(logPath, LevelDebug)
	if err != nil {
		t.Fatalf("InitLogger should create parent directory: %v", err)
	}
	CloseLogger()
}

func TestInitLoggerInvalidPath(t *testing.T) {
	err := InitLogger("", LevelInfo)
	if err == nil {
		t.Error("expected error for empty path")
	}
	CloseLogger()
}

func TestInitLoggerAllLevels(t *testing.T) {
	dir := t.TempDir()

	for _, level := range []LogLevel{LevelDebug, LevelInfo, LevelWarn, LevelError} {
		logPath := filepath.Join(dir, string(level)+".log")
		err := InitLogger(logPath, level)
		if err != nil {
			t.Fatalf("InitLogger failed for level %q: %v", level, err)
		}
		CloseLogger()
	}
}

func TestInitLoggerDefaultLevel(t *testing.T) {
	dir := t.TempDir()
	err := InitLogger(filepath.Join(dir, "default.log"), "invalid")
	if err != nil {
		t.Fatalf("InitLogger failed: %v", err)
	}
	if Logger == nil {
		t.Fatal("Logger should be initialized")
	}
	CloseLogger()
}

func TestWarn(t *testing.T) {
	dir := t.TempDir()
	InitLogger(filepath.Join(dir, "warn.log"), LevelWarn)

	Warn("test warning", "key", "value")

	CloseLogger()
}

func TestInfo(t *testing.T) {
	dir := t.TempDir()
	InitLogger(filepath.Join(dir, "info.log"), LevelInfo)

	Info("test info", "count", 42)

	CloseLogger()
}

func TestDebug(t *testing.T) {
	dir := t.TempDir()
	InitLogger(filepath.Join(dir, "debug.log"), LevelDebug)

	Debug("test debug", "detail", "something")

	CloseLogger()
}

func TestError(t *testing.T) {
	dir := t.TempDir()
	InitLogger(filepath.Join(dir, "error.log"), LevelError)

	Error("test error", "err", "something failed")

	CloseLogger()
}

func TestWarnNoLogger(t *testing.T) {
	CloseLogger()
	Warn("should not panic", "key", "value")
}

func TestInfoNoLogger(t *testing.T) {
	CloseLogger()
	Info("should not panic", "key", "value")
}

func TestDebugNoLogger(t *testing.T) {
	CloseLogger()
	Debug("should not panic", "key", "value")
}

func TestErrorNoLogger(t *testing.T) {
	CloseLogger()
	Error("should not panic", "key", "value")
}

func TestCloseLogger(t *testing.T) {
	dir := t.TempDir()
	InitLogger(filepath.Join(dir, "close.log"), LevelInfo)
	if Logger == nil {
		t.Fatal("Logger should be initialized")
	}

	err := CloseLogger()
	if err != nil {
		t.Errorf("CloseLogger returned error: %v", err)
	}
	if Logger != nil {
		t.Error("Logger should be nil after close")
	}
}

func TestCloseLoggerNoFile(t *testing.T) {
	Logger = nil
	err := CloseLogger()
	if err != nil {
		t.Errorf("CloseLogger should return nil when no file: %v", err)
	}
}

func TestLoggerLogsContent(t *testing.T) {
	dir := t.TempDir()
	logPath := filepath.Join(dir, "content.log")
	InitLogger(logPath, LevelInfo)

	Info("hello from test")

	CloseLogger()

	data, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	if !strings.Contains(content, "hello from test") {
		t.Errorf("log content should contain message, got: %s", content)
	}
}

func TestInitLoggerReusesPath(t *testing.T) {
	dir := t.TempDir()
	logPath := filepath.Join(dir, "reuse.log")

	InitLogger(logPath, LevelInfo)
	Info("first message")
	CloseLogger()

	InitLogger(logPath, LevelInfo)
	Info("second message")
	CloseLogger()

	data, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	if !strings.Contains(content, "second message") {
		t.Error("log should contain second message")
	}
}
