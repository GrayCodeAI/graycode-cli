package filter

import (
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// CoreFilters wiring across modes and config flags
// ---------------------------------------------------------------------------

// TestCoreFiltersApply_AllEnabledModes wires every core filter on and runs
// Apply across all three modes. The ModeNone-respecting filters (entropy,
// perplexity, goalDriven, ast, contrastive, evaluator, gist, hierarchical) all
// short-circuit on ModeNone; with ngram disabled the composition is identity.
func TestCoreFiltersApply_AllEnabledModes(t *testing.T) {
	cfg := PipelineConfig{
		EnableEntropy:      true,
		EnablePerplexity:   true,
		EnableGoalDriven:   true,
		EnableAST:          true,
		EnableContrastive:  true,
		EnableEvaluator:    true,
		EnableGist:         true,
		EnableHierarchical: true,
		QueryIntent:        "debug error",
		// NgramEnabled intentionally off: NgramAbbreviator.Apply ignores ModeNone
		// (it only gates on input length), so it would break ModeNone identity.
	}
	cf := NewCoreFilters(cfg)

	input := strings.Repeat("func handler() {\n\treturn err\n}\n", 20)

	// ModeNone: each ModeNone-respecting filter returns input unchanged, so the
	// composition is the identity transform.
	noneOut := cf.Apply(input, ModeNone, nil)
	if noneOut != input {
		t.Errorf("ModeNone should be identity passthrough; input len %d, output len %d", len(input), len(noneOut))
	}

	for _, mode := range []Mode{ModeMinimal, ModeAggressive} {
		out := cf.Apply(input, mode, nil)
		if out == "" {
			t.Errorf("mode %q produced empty output", mode)
		}
	}
}

// TestCoreFiltersApply_NgramRunsRegardlessOfMode documents that the ngram
// abbreviator (unlike the other core filters) does not honor ModeNone: it
// abbreviates whenever the input is at least 100 bytes.
func TestCoreFiltersApply_NgramRunsRegardlessOfMode(t *testing.T) {
	cf := NewCoreFilters(PipelineConfig{NgramEnabled: true})
	// Long CLI-style input with abbreviatable status words, no code markers.
	input := strings.Repeat("Successfully downloaded the package today. ", 6)
	out := cf.Apply(input, ModeNone, nil)
	if out == input {
		t.Error("ngram should abbreviate even under ModeNone (it ignores mode)")
	}
}

// TestCoreFiltersApply_RecordsStats verifies Apply records a LayerStat for each
// enabled filter via applyFilter -> AddLayerStatSafe.
func TestCoreFiltersApply_RecordsStats(t *testing.T) {
	cfg := PipelineConfig{
		EnableEntropy: true,
		EnableGist:    true,
		NgramEnabled:  true,
	}
	cf := NewCoreFilters(cfg)
	stats := &PipelineStats{LayerStats: make(map[string]LayerStat)}

	input := strings.Repeat("import (\n\t\"fmt\"\n)\nfunc main() { return }\n", 10)
	cf.Apply(input, ModeMinimal, stats)

	// Each enabled filter (entropy, gist, ngram) should have registered its name.
	for _, name := range []string{"entropy", "gist", "ngram"} {
		if _, ok := stats.LayerStats[name]; !ok {
			t.Errorf("expected LayerStat recorded for %q, got keys %v", name, statKeys(stats))
		}
	}
}

// TestCoreFiltersApply_GoalDrivenSkippedWithoutIntent confirms goalDriven and
// contrastive are nil (and thus skipped) when QueryIntent is empty, per
// NewCoreFilters guard conditions.
func TestCoreFiltersApply_GoalDrivenSkippedWithoutIntent(t *testing.T) {
	cfg := PipelineConfig{
		EnableGoalDriven:  true,
		EnableContrastive: true,
		// QueryIntent intentionally empty.
	}
	cf := NewCoreFilters(cfg)
	if cf.goalDriven != nil {
		t.Error("goalDriven must be nil when QueryIntent is empty")
	}
	if cf.contrastive != nil {
		t.Error("contrastive must be nil when QueryIntent is empty")
	}
}

func statKeys(s *PipelineStats) []string {
	keys := make([]string, 0, len(s.LayerStats))
	for k := range s.LayerStats {
		keys = append(keys, k)
	}
	return keys
}

// ---------------------------------------------------------------------------
// GoalDrivenFilter
// ---------------------------------------------------------------------------

// TestGoalDrivenFilter_ModeParsing asserts parseGoalMode maps keywords to the
// documented modes.
func TestGoalDrivenFilter_ModeParsing(t *testing.T) {
	cases := map[string]GoalMode{
		"please debug this":  GoalModeDebug,
		"fix the bug":        GoalModeDebug,
		"review the changes": GoalModeReview,
		"deploy to prod":     GoalModeDeploy,
		"search for foo":     GoalModeSearch,
		"build the project":  GoalModeBuild,
		"run the test suite": GoalModeTest,
		"summarize the docs": GoalModeGeneric,
	}
	for goal, want := range cases {
		if got := parseGoalMode(goal); got != want {
			t.Errorf("parseGoalMode(%q) = %d, want %d", goal, got, want)
		}
	}
}

// TestGoalDrivenFilter_ModeNoneIdentity asserts ModeNone returns input verbatim
// with zero savings.
func TestGoalDrivenFilter_ModeNoneIdentity(t *testing.T) {
	f := NewGoalDrivenFilter("debug")
	input := "alpha\nbeta\ngamma\n"
	out, saved := f.Apply(input, ModeNone)
	if out != input {
		t.Errorf("ModeNone should return input unchanged, got %q", out)
	}
	if saved != 0 {
		t.Errorf("ModeNone should save 0 tokens, got %d", saved)
	}
}

// TestGoalDrivenFilter_PrunesIrrelevantLines verifies goal-relevant lines (with
// error/debug terms) survive while a long run of unrelated filler is pruned.
// Per scoreLine + crfDecode, lines below 30% of max score are dropped.
func TestGoalDrivenFilter_PrunesIrrelevantLines(t *testing.T) {
	f := NewGoalDrivenFilter("debug error")

	var b strings.Builder
	b.WriteString("fatal error: nil pointer dereference\n")
	for i := 0; i < 30; i++ {
		b.WriteString("lorem ipsum dolor sit amet consectetur\n")
	}
	b.WriteString("panic: runtime exception occurred\n")
	input := b.String()

	out, saved := f.Apply(input, ModeMinimal)

	if !strings.Contains(out, "fatal error") {
		t.Error("should retain the high-scoring error line")
	}
	if !strings.Contains(out, "panic") {
		t.Error("should retain the high-scoring panic line")
	}
	if len(out) >= len(input) {
		t.Errorf("expected pruning to shrink output: in=%d out=%d", len(input), len(out))
	}
	if saved <= 0 {
		t.Errorf("expected positive tokens saved, got %d", saved)
	}
}

// TestGoalDrivenFilter_NeverNegativeSaved asserts the saved>=0 clamp holds even
// when output is not smaller than input.
func TestGoalDrivenFilter_NeverNegativeSaved(t *testing.T) {
	f := NewGoalDrivenFilter("debug")
	// Single short line: ensureCoherence keeps first non-empty line.
	_, saved := f.Apply("error here", ModeMinimal)
	if saved < 0 {
		t.Errorf("saved must never be negative, got %d", saved)
	}
}

// ---------------------------------------------------------------------------
// ContrastiveFilter
// ---------------------------------------------------------------------------

// TestContrastiveFilter_EmptyQuestionPassthrough asserts an empty question is a
// no-op, per the guard in Apply.
func TestContrastiveFilter_EmptyQuestionPassthrough(t *testing.T) {
	f := NewContrastiveFilter("")
	input := "one\ntwo\nthree\n"
	out, saved := f.Apply(input, ModeAggressive)
	if out != input {
		t.Errorf("empty question must passthrough, got %q", out)
	}
	if saved != 0 {
		t.Errorf("empty question must save 0, got %d", saved)
	}
}

// TestContrastiveFilter_ModeNonePassthrough asserts ModeNone is a no-op.
func TestContrastiveFilter_ModeNonePassthrough(t *testing.T) {
	f := NewContrastiveFilter("find the bug")
	input := "x\ny\nz\n"
	out, _ := f.Apply(input, ModeNone)
	if out != input {
		t.Errorf("ModeNone must passthrough, got %q", out)
	}
}

// TestContrastiveFilter_KeepsFirstAndLast verifies processWithContrastive always
// retains the first and last lines for context, and never grows the output.
func TestContrastiveFilter_KeepsFirstAndLast(t *testing.T) {
	f := NewContrastiveFilter("database connection error")

	lines := []string{"FIRST-LINE-MARKER database connection"}
	for i := 0; i < 40; i++ {
		lines = append(lines, "unrelated filler content here number")
	}
	lines = append(lines, "LAST-LINE-MARKER connection error")
	input := strings.Join(lines, "\n")

	out, saved := f.Apply(input, ModeAggressive)

	if !strings.Contains(out, "FIRST-LINE-MARKER") {
		t.Error("first line must always be kept")
	}
	if !strings.Contains(out, "LAST-LINE-MARKER") {
		t.Error("last line must always be kept")
	}
	if len(out) > len(input) {
		t.Errorf("output must not grow: in=%d out=%d", len(input), len(out))
	}
	if saved < 0 {
		t.Errorf("saved must be >=0, got %d", saved)
	}
}

// TestContrastiveFilter_SetQuestion verifies SetQuestion replaces the question
// and re-extracts ngrams (the new question becomes effective).
func TestContrastiveFilter_SetQuestion(t *testing.T) {
	f := NewContrastiveFilter("")
	f.SetQuestion("payment gateway timeout")
	if f.question != "payment gateway timeout" {
		t.Errorf("question not updated, got %q", f.question)
	}
	if len(f.questionNgrams) == 0 {
		t.Error("expected question ngrams to be re-extracted after SetQuestion")
	}
}

// ---------------------------------------------------------------------------
// NgramAbbreviator
// ---------------------------------------------------------------------------

// TestNgramAbbreviator_ShortInputUntouched asserts inputs under 100 bytes are
// returned unchanged with zero savings, per the early return in Apply.
func TestNgramAbbreviator_ShortInputUntouched(t *testing.T) {
	f := NewNgramAbbreviator()
	input := "Successfully completed the build"
	out, saved := f.Apply(input, ModeMinimal)
	if out != input {
		t.Errorf("short input must be untouched, got %q", out)
	}
	if saved != 0 {
		t.Errorf("short input must save 0, got %d", saved)
	}
}

// TestNgramAbbreviator_CLIPatternsAbbreviated asserts CLI status words are
// replaced (e.g. "Successfully" -> "✓", "Error" -> "ERR") on long-enough,
// non-code input.
func TestNgramAbbreviator_CLIPatternsAbbreviated(t *testing.T) {
	f := NewNgramAbbreviator()
	// Plain CLI log without code indicators; padded over 100 bytes.
	input := strings.Repeat("Successfully downloaded the package. ", 5) +
		strings.Repeat("Error during validation step. ", 3)

	out, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(out, "Successfully") {
		t.Errorf("expected 'Successfully' abbreviated away, got %q", out)
	}
	if !strings.Contains(out, "✓") {
		t.Errorf("expected ✓ abbreviation present, got %q", out)
	}
	if !strings.Contains(out, "ERR") {
		t.Errorf("expected 'Error'->'ERR', got %q", out)
	}
	if saved <= 0 {
		t.Errorf("expected positive tokensSaved for abbreviated CLI text, got %d", saved)
	}
}

// TestNgramAbbreviator_LanguageKeywordGate asserts the langKeywords gate:
// general abbreviations are applied ONLY to words that are reserved keywords of
// the detected language. For Python code, keywords "import"->"imp" and
// "class"->"cls" are abbreviated, while a non-keyword word like "information"
// is left untouched (it is not in Python's keyword set, so the general
// "information"->"info" abbreviation does not fire).
func TestNgramAbbreviator_LanguageKeywordGate(t *testing.T) {
	f := NewNgramAbbreviator()
	// Python code context: detectLanguage needs "def " and "import ".
	input := "import os\n" +
		"def handler():\n" +
		"    class Inner:\n" +
		"        pass\n" +
		strings.Repeat("    # information about the handler routine here\n", 6)

	out, _ := f.Apply(input, ModeMinimal)

	// Python keywords ARE abbreviated.
	if !strings.Contains(out, "imp os") {
		t.Errorf("Python keyword 'import' should abbreviate to 'imp', got %q", out)
	}
	if !strings.Contains(out, "cls Inner") {
		t.Errorf("Python keyword 'class' should abbreviate to 'cls', got %q", out)
	}
	// Non-keyword word is NOT abbreviated (gate blocks "information"->"info").
	if !strings.Contains(out, "information") {
		t.Errorf("non-keyword 'information' must be preserved in Python code, got %q", out)
	}
}

// TestNgramAbbreviator_ReplaceWordBoundaries asserts replaceWord only replaces
// whole words, leaving substrings inside larger identifiers intact.
func TestNgramAbbreviator_ReplaceWordBoundaries(t *testing.T) {
	f := NewNgramAbbreviator()
	// "error" -> "err" only as a whole word; "errorHandler" must be untouched
	// by the whole-word general-abbreviation path. Use unknown-language plain
	// text (no code indicators) so general abbreviations apply.
	out := f.replaceWord("the error in errorHandler is real and error-prone here padding", "error", "err")
	if !strings.Contains(out, "errorHandler") {
		t.Errorf("substring inside identifier must not be replaced, got %q", out)
	}
	if !strings.Contains(out, "the err in") {
		t.Errorf("standalone word should be replaced, got %q", out)
	}
}

// TestNgramAbbreviator_Name asserts the documented filter name.
func TestNgramAbbreviator_Name(t *testing.T) {
	if got := NewNgramAbbreviator().Name(); got != "ngram" {
		t.Errorf("Name() = %q, want \"ngram\"", got)
	}
}

// ---------------------------------------------------------------------------
// EvaluatorHeadsFilter
// ---------------------------------------------------------------------------

// TestEvaluatorHeadsFilter_ModeNonePassthrough asserts ModeNone is a no-op.
func TestEvaluatorHeadsFilter_ModeNonePassthrough(t *testing.T) {
	f := NewEvaluatorHeadsFilter()
	input := "a\nb\nc\n"
	out, saved := f.Apply(input, ModeNone)
	if out != input || saved != 0 {
		t.Errorf("ModeNone must passthrough with 0 saved, got %q saved=%d", out, saved)
	}
}

// TestEvaluatorHeadsFilter_PrunesChunks builds many 10-line chunks where only a
// few contain error keywords. selectTopChunks keeps ~50% (minimal) and always
// the first and last chunk; high-scoring error chunks must survive.
func TestEvaluatorHeadsFilter_PrunesChunks(t *testing.T) {
	f := NewEvaluatorHeadsFilter()

	var b strings.Builder
	// Chunk 0 (first, always kept via keepSet[0]) - filler marker.
	for i := 0; i < 10; i++ {
		b.WriteString("ZEROCHUNK filler line\n")
	}
	// Several low-scoring filler chunks that should be pruned.
	for c := 0; c < 8; c++ {
		for i := 0; i < 10; i++ {
			b.WriteString("plain neutral filler line content\n")
		}
	}
	// A clearly important error chunk - high keyword score, must survive.
	for i := 0; i < 10; i++ {
		b.WriteString("fatal error exception panic ERRORMARKER\n")
	}
	input := b.String()

	out, saved := f.Apply(input, ModeMinimal)

	if !strings.Contains(out, "ERRORMARKER") {
		t.Error("high-scoring error chunk should be retained")
	}
	if !strings.Contains(out, "ZEROCHUNK") {
		t.Error("first chunk should always be kept (keepSet[0])")
	}
	if len(out) >= len(input) {
		t.Errorf("expected pruning to shrink output: in=%d out=%d", len(input), len(out))
	}
	if saved <= 0 {
		t.Errorf("expected positive tokens saved, got %d", saved)
	}
}

// ---------------------------------------------------------------------------
// GistFilter
// ---------------------------------------------------------------------------

// TestGistFilter_ModeNonePassthrough asserts ModeNone is a no-op.
func TestGistFilter_ModeNonePassthrough(t *testing.T) {
	f := NewGistFilter()
	input := "Traceback (most recent call last)\n  file.py line 1\n"
	out, saved := f.Apply(input, ModeNone)
	if out != input || saved != 0 {
		t.Errorf("ModeNone must passthrough with 0 saved, got %q saved=%d", out, saved)
	}
}

// TestGistFilter_GistsStackTrace asserts that an identified stack-trace block is
// collapsed to a gist marker in aggressive mode (chunks are gisted regardless of
// size when mode == ModeAggressive).
func TestGistFilter_GistsStackTrace(t *testing.T) {
	f := NewGistFilter()

	var b strings.Builder
	// Leading non-block line so the stack-trace chunk does not start at line 0
	// (createGist only emits a gist marker when lastGisted < i-1, which is false
	// for a chunk starting at index 0).
	b.WriteString("PREAMBLE before the crash\n")
	b.WriteString("Traceback (most recent call last)\n")
	for i := 0; i < 15; i++ {
		b.WriteString("  File \"app.py\", line 42, in handler frame\n")
	}
	b.WriteString("\n") // blank line ends the stack_trace block
	b.WriteString("done\n")
	input := b.String()

	out, saved := f.Apply(input, ModeAggressive)

	if !strings.Contains(out, "[stack trace]") {
		t.Errorf("expected stack trace gisted to marker, got:\n%s", out)
	}
	if !strings.Contains(out, "PREAMBLE") {
		t.Error("non-block preamble line should be preserved")
	}
	if len(out) >= len(input) {
		t.Errorf("expected gist to shrink output: in=%d out=%d", len(input), len(out))
	}
	if saved <= 0 {
		t.Errorf("expected positive tokens saved, got %d", saved)
	}
}

// TestGistFilter_Name asserts the documented filter name.
func TestGistFilter_Name(t *testing.T) {
	if got := NewGistFilter().Name(); got != "gist" {
		t.Errorf("Name() = %q, want \"gist\"", got)
	}
}

// ---------------------------------------------------------------------------
// HierarchicalSummaryFilter
// ---------------------------------------------------------------------------

// TestHierarchicalSummaryFilter_ModeNonePassthrough asserts ModeNone is a no-op.
func TestHierarchicalSummaryFilter_ModeNonePassthrough(t *testing.T) {
	f := NewHierarchicalSummaryFilter()
	input := "# Heading\nbody line\n"
	out, saved := f.Apply(input, ModeNone)
	if out != input || saved != 0 {
		t.Errorf("ModeNone must passthrough with 0 saved, got %q saved=%d", out, saved)
	}
}

// TestHierarchicalSummaryFilter_PreservesErrorSection verifies an error-bearing
// middle section is preserved verbatim (preserveErrors), while a long benign
// middle section is summarized down. First and last sections are preserved.
func TestHierarchicalSummaryFilter_PreservesErrorSection(t *testing.T) {
	f := NewHierarchicalSummaryFilter()

	var b strings.Builder
	// First section (preserved).
	b.WriteString("# Intro\n")
	b.WriteString("introductory content line\n")
	// Benign middle section: long, no error keywords -> summarized.
	b.WriteString("# Details\n")
	for i := 0; i < 30; i++ {
		b.WriteString("benign neutral detail line of prose content\n")
	}
	// Error middle section -> preserved verbatim.
	b.WriteString("# Failure\n")
	b.WriteString("panic: fatal error occurred during processing\n")
	b.WriteString("ERRORSECTIONMARKER stack trace below\n")
	// Last section (preserved).
	b.WriteString("# Conclusion\n")
	b.WriteString("final summary line\n")
	input := b.String()

	out, saved := f.Apply(input, ModeAggressive)

	if !strings.Contains(out, "ERRORSECTIONMARKER") {
		t.Error("error-bearing section must be preserved verbatim (preserveErrors)")
	}
	// The last section's body is preserved verbatim (preserveLast); note heading
	// lines are section boundaries and are not part of section content.
	if !strings.Contains(out, "final summary line") {
		t.Error("last section body must be preserved")
	}
	// The benign 30-line middle section must be summarized down: its content
	// appears far fewer times than the 30 input occurrences.
	if strings.Count(out, "benign neutral detail line") >= 30 {
		t.Errorf("benign section should be summarized, but %d copies remain", strings.Count(out, "benign neutral detail line"))
	}
	if saved < 0 {
		t.Errorf("saved must be >=0, got %d", saved)
	}
}

// TestHierarchicalSummaryFilter_HeadingLevel asserts headingLevel counts leading
// '#' characters.
func TestHierarchicalSummaryFilter_HeadingLevel(t *testing.T) {
	f := NewHierarchicalSummaryFilter()
	cases := map[string]int{
		"# h1":     1,
		"### h3":   3,
		"no head":  0,
		"   ## h2": 2, // trimmed before counting
	}
	for line, want := range cases {
		if got := f.headingLevel(line); got != want {
			t.Errorf("headingLevel(%q) = %d, want %d", line, got, want)
		}
	}
}
