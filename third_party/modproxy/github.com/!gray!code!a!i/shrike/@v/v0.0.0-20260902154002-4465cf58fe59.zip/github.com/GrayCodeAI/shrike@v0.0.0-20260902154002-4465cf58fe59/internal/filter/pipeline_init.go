package filter

import (
	"github.com/GrayCodeAI/shrike/internal/cache"
)

// NewPipelineCoordinator creates a new pipeline coordinator with all configured layers.
func NewPipelineCoordinator(cfg *PipelineConfig) *PipelineCoordinator {
	p := &PipelineCoordinator{
		config:       *cfg,
		resultCache:  cache.GetGlobalCache(),
		cacheEnabled: true,
		layerCache:   GetGlobalLayerCache(), // Initialize layer cache
	}

	// Apply tier-based defaults if no explicit layers are enabled
	p.applyTierDefaults(cfg)

	// Set legacy defaults - all layers enabled by default when using zero-config.
	if cfg.AllCoreLayersDisabled() && !cfg.HasExplicitSettings() {
		cfg.EnableEntropy = true
		cfg.EnablePerplexity = true
		cfg.EnableGoalDriven = true
		cfg.EnableAST = true
		cfg.EnableContrastive = true
		cfg.EnableEvaluator = true
		cfg.EnableGist = true
		cfg.EnableHierarchical = true
	}
	// Core filters (Layers 1-9)
	p.initCoreFilters(cfg)

	// Semantic filters (Layers 11-20)
	p.initSemanticFilters(cfg)
	if cfg.EnableQualityGuardrail {
		p.qualityGuardrail = NewQualityGuardrail()
	}

	// Feedback mechanism
	p.feedback = NewInterLayerFeedback()
	p.qualityEstimator = NewQualityEstimator()

	// Layer 50: AdaptiveLearning (merged EngramLearner + TieredSummary)
	if cfg.EnableAdaptiveLearning {
		p.adaptiveLearning = NewAdaptiveLearningFilter()
	}

	// New: CrunchBench for comprehensive benchmarking
	if cfg.EnableCrunchBench {
		p.crunchBench = NewCrunchBench()
	}

	// Build layer execution order
	p.buildLayers()
	p.layerRegistry = NewLayerRegistry()
	p.layerGate = NewLayerGate(cfg.LayerGateMode, cfg.LayerGateAllowExperimental, p.layerRegistry)

	return p
}

func (p *PipelineCoordinator) initCoreFilters(cfg *PipelineConfig) {
	// Layer 0: QuantumLock (KV-cache alignment)
	if cfg.EnableQuantumLock {
		p.quantumLockFilter = NewQuantumLockFilter()
	}

	// Layer 0.5: Photon (image compression)
	if cfg.EnablePhoton {
		p.photonFilter = NewPhotonFilter()
	}

	p.entropyFilter = NewEntropyFilter()
	p.perplexityFilter = NewPerplexityFilter()

	if cfg.QueryIntent != "" {
		p.goalDrivenFilter = NewGoalDrivenFilter(cfg.QueryIntent)
	}

	p.astPreserveFilter = NewASTPreserveFilter()

	if cfg.QueryIntent != "" {
		p.contrastiveFilter = NewContrastiveFilter(cfg.QueryIntent)
	}

	if cfg.NgramEnabled {
		p.ngramAbbreviator = NewNgramAbbreviator()
	}

	p.evaluatorHeadsFilter = NewEvaluatorHeadsFilter()
	p.gistFilter = NewGistFilter()
	p.hierarchicalSummaryFilter = NewHierarchicalSummaryFilter()

	if cfg.Budget > 0 {
		p.budgetEnforcer = NewBudgetEnforcer(cfg.Budget)
	}
	if cfg.SessionTracking {
		p.sessionTracker = NewSessionTracker()
	}
}

func (p *PipelineCoordinator) initSemanticFilters(cfg *PipelineConfig) {
	if cfg.EnableCompaction {
		compactionCfg := CompactionConfig{
			Enabled:             true,
			ThresholdTokens:     cfg.CompactionThreshold,
			PreserveRecentTurns: cfg.CompactionPreserveTurns,
			MaxSummaryTokens:    cfg.CompactionMaxTokens,
			StateSnapshotFormat: cfg.CompactionStateSnapshot,
			AutoDetect:          cfg.CompactionAutoDetect,
			CacheEnabled:        true,
		}
		if compactionCfg.ThresholdTokens == 0 {
			compactionCfg.ThresholdTokens = 2000
		}
		if compactionCfg.PreserveRecentTurns == 0 {
			compactionCfg.PreserveRecentTurns = 5
		}
		if compactionCfg.MaxSummaryTokens == 0 {
			compactionCfg.MaxSummaryTokens = 500
		}
		p.compactionLayer = NewCompactionLayer(compactionCfg)
	}

	if cfg.EnableAttribution {
		p.attributionFilter = NewAttributionFilter()
		if cfg.AttributionThreshold > 0 {
			p.attributionFilter.config.ImportanceThreshold = cfg.AttributionThreshold
		}
	}

	if cfg.EnableH2O {
		p.h2oFilter = NewH2OFilter()
		if cfg.H2OSinkSize > 0 {
			p.h2oFilter.config.SinkSize = cfg.H2OSinkSize
		}
		if cfg.H2ORecentSize > 0 {
			p.h2oFilter.config.RecentSize = cfg.H2ORecentSize
		}
		if cfg.H2OHeavyHitterSize > 0 {
			p.h2oFilter.config.HeavyHitterSize = cfg.H2OHeavyHitterSize
		}
	}

	if cfg.EnableAttentionSink {
		p.attentionSinkFilter = NewAdaptiveAttentionSinkFilter(50)
		if cfg.AttentionSinkCount > 0 {
			p.attentionSinkFilter.config.SinkTokenCount = cfg.AttentionSinkCount
		}
		if cfg.AttentionRecentCount > 0 {
			p.attentionSinkFilter.config.RecentTokenCount = cfg.AttentionRecentCount
		}
	}

	if cfg.EnableMetaToken {
		metaCfg := DefaultMetaTokenConfig()
		if cfg.MetaTokenWindow > 0 {
			metaCfg.WindowSize = cfg.MetaTokenWindow
		}
		if cfg.MetaTokenMinSize > 0 {
			metaCfg.MinPattern = cfg.MetaTokenMinSize
		}
		p.metaTokenFilter = NewMetaTokenFilterWithConfig(metaCfg)
	}

	if cfg.EnableSemanticChunk {
		semanticCfg := DefaultSemanticChunkConfig()
		if cfg.SemanticChunkMinSize > 0 {
			semanticCfg.MinChunkSize = cfg.SemanticChunkMinSize
		}
		if cfg.SemanticChunkThreshold > 0 {
			semanticCfg.ImportanceThreshold = cfg.SemanticChunkThreshold
		}
		p.semanticChunkFilter = NewSemanticChunkFilterWithConfig(semanticCfg)
	}

	if cfg.EnableSketchStore {
		sketchCfg := DefaultSketchStoreConfig()
		if cfg.SketchBudgetRatio > 0 {
			sketchCfg.BudgetRatio = cfg.SketchBudgetRatio
		}
		if cfg.SketchMaxSize > 0 {
			sketchCfg.MaxSketchSize = cfg.SketchMaxSize
		}
		if cfg.SketchHeavyHitter > 0 {
			sketchCfg.HeavyHitterRatio = cfg.SketchHeavyHitter
		}
		p.sketchStoreFilter = NewSketchStoreFilterWithConfig(sketchCfg)
	}

	if cfg.EnableLazyPruner {
		lazyCfg := DefaultLazyPrunerConfig()
		if cfg.LazyBaseBudget > 0 {
			lazyCfg.BaseBudget = cfg.LazyBaseBudget
		}
		if cfg.LazyDecayRate > 0 {
			lazyCfg.DecayRate = cfg.LazyDecayRate
		}
		if cfg.LazyRevivalBudget > 0 {
			lazyCfg.RevivalBudget = cfg.LazyRevivalBudget
		}
		p.lazyPrunerFilter = NewLazyPrunerFilterWithConfig(lazyCfg)
	}

	if cfg.EnableSemanticAnchor {
		anchorCfg := DefaultSemanticAnchorConfig()
		if cfg.SemanticAnchorRatio > 0 {
			anchorCfg.AnchorRatio = cfg.SemanticAnchorRatio
		}
		if cfg.SemanticAnchorSpacing > 0 {
			anchorCfg.MinAnchorSpacing = cfg.SemanticAnchorSpacing
		}
		p.semanticAnchorFilter = NewSemanticAnchorFilterWithConfig(anchorCfg)
	}

	if cfg.EnableAgentMemory {
		agentCfg := DefaultAgentMemoryConfig()
		if cfg.AgentKnowledgeRetention > 0 {
			agentCfg.KnowledgeRetentionRatio = cfg.AgentKnowledgeRetention
		}
		if cfg.AgentHistoryPrune > 0 {
			agentCfg.HistoryPruneRatio = cfg.AgentHistoryPrune
		}
		if cfg.AgentConsolidationMax > 0 {
			agentCfg.KnowledgeMaxSize = cfg.AgentConsolidationMax
		}
		p.agentMemoryFilter = NewAgentMemoryFilterWithConfig(agentCfg)
	}

	p.initResearchFilters(cfg)
}

func (p *PipelineCoordinator) initResearchFilters(cfg *PipelineConfig) {
	// Unified L14: Edge cases (merges L21-L25)
	if cfg.EnableEdgeCase {
		p.edgeCaseFilter = NewEdgeCaseFilter()
	}

	// Unified L15: Reasoning (merges L26-L30)
	if cfg.EnableReasoning {
		p.reasoningFilter = NewReasoningFilter()
	}

	// Unified L16: Advanced (merges L31-L45)
	if cfg.EnableAdvanced {
		p.advancedFilter = NewAdvancedFilter()
	}

	// L53: LLMLingua prose layer (opt-in, local perplexity proxy)
	if cfg.EnableLLMLinguaProse {
		p.llmLinguaProseFilter = NewLLMLinguaProseFilterWithConfig(
			cfg.LLMLinguaProseKeepRatio,
			cfg.LLMLinguaProseMinLength,
		)
	}
}

func (p *PipelineCoordinator) buildLayers() {
	p.layers = make([]filterLayer, 0, NumLayerIndices)

	// addLayer appends a filter only if it is non-nil. Nil filters (disabled via
	// config) are skipped with a log warning rather than panicking at runtime.
	addLayer := func(f Filter, name string) {
		if f == nil {
			// Filter not enabled in config; skip silently.
			return
		}
		p.layers = append(p.layers, filterLayer{f, name})
	}

	addLayer(p.entropyFilter, LayerEntropy)
	addLayer(p.perplexityFilter, LayerPerplexity)
	addLayer(p.goalDrivenFilter, LayerGoalDriven)
	addLayer(p.astPreserveFilter, LayerASTPreserve)
	addLayer(p.contrastiveFilter, LayerContrastive)
	addLayer(p.ngramAbbreviator, LayerNgram)
	addLayer(p.evaluatorHeadsFilter, LayerEvaluator)
	addLayer(p.gistFilter, LayerGist)
	addLayer(p.hierarchicalSummaryFilter, LayerHierarchical)
	addLayer(p.compactionLayer, LayerCompaction)
	addLayer(p.attributionFilter, LayerAttribution)
	addLayer(p.h2oFilter, LayerH2O)
	addLayer(p.attentionSinkFilter, LayerAttentionSink)
	addLayer(p.metaTokenFilter, LayerMetaToken)
	addLayer(p.semanticChunkFilter, LayerSemanticChunk)
	addLayer(p.sketchStoreFilter, LayerSemanticCache)
	addLayer(p.lazyPrunerFilter, LayerLazyPruner)
	addLayer(p.semanticAnchorFilter, LayerSemanticAnchor)
	addLayer(p.agentMemoryFilter, LayerAgentMemory)
	// Unified layers
	addLayer(p.edgeCaseFilter, LayerEdgeCase)
	addLayer(p.reasoningFilter, LayerReasoning)
	addLayer(p.advancedFilter, LayerAdvanced)
	// Opt-in prose layer runs last so it only refines remaining natural language.
	addLayer(p.llmLinguaProseFilter, LayerLLMLinguaProse)
}

// applyTierDefaults applies tier-based layer enablement if UseTiers is set.
// This allows automatic tier selection based on content characteristics.
func (p *PipelineCoordinator) applyTierDefaults(cfg *PipelineConfig) {
	// Check if tier-based configuration should be applied
	if !cfg.EnableTiers {
		return
	}

	// If specific tiers are requested, enable them
	if len(cfg.EnabledTiers) > 0 {
		*cfg = BuildConfigFromTiers(cfg.EnabledTiers, *cfg)
		return
	}

	// Auto-select tiers based on mode and budget
	var tiers []AutoTier
	switch cfg.Mode {
	case ModeMinimal:
		tiers = QuickTierEnable("minimal")
	case ModeAggressive:
		if cfg.Budget > 0 && cfg.Budget < 2000 {
			tiers = QuickTierEnable("maximum")
		} else {
			tiers = QuickTierEnable("aggressive")
		}
	default:
		tiers = QuickTierEnable("standard")
	}

	*cfg = BuildConfigFromTiers(tiers, *cfg)
}
