package config

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/BurntSushi/toml"
)

// ValidatedFilterConfig represents a validated TOML filter configuration.
type ValidatedFilterConfig struct {
	SchemaVersion int                               `toml:"schema_version"`
	Filters       map[string]ValidatedFilterSection `toml:"-"`
}

// ValidatedFilterSection represents a single filter section within a TOML file.
type ValidatedFilterSection struct {
	MatchCommand    string   `toml:"match_command"`
	StripAnsi       bool     `toml:"strip_ansi"`
	StripLinesMatch []string `toml:"strip_lines_matching"`
	KeepLinesMatch  []string `toml:"keep_lines_matching"`
	MaxLines        int      `toml:"max_lines"`
	MaxTokens       int      `toml:"max_tokens"`
	Priority        int      `toml:"priority"`
	Enabled         *bool    `toml:"enabled"`
}

// ValidationError represents a single validation error in a filter config.
type ValidationError struct {
	File    string
	Section string
	Field   string
	Message string
}

func (e ValidationError) Error() string {
	return fmt.Sprintf("%s [%s].%s: %s", e.File, e.Section, e.Field, e.Message)
}

// ValidateFilterFile validates a single TOML filter configuration file.
func ValidateFilterFile(path string) []ValidationError {
	var errors []ValidationError
	fileName := filepath.Base(path)

	raw := make(map[string]interface{})
	if _, err := toml.DecodeFile(path, &raw); err != nil {
		errors = append(errors, ValidationError{
			File:    fileName,
			Section: "root",
			Field:   "parse",
			Message: fmt.Sprintf("invalid TOML: %v", err),
		})
		return errors
	}

	// Check schema_version
	if _, ok := raw["schema_version"]; !ok {
		errors = append(errors, ValidationError{
			File:    fileName,
			Section: "root",
			Field:   "schema_version",
			Message: "missing required field schema_version",
		})
	}

	// Validate each section (except schema_version which is top-level)
	for section, data := range raw {
		if section == "schema_version" {
			continue
		}
		sectionMap, ok := data.(map[string]interface{})
		if !ok {
			errors = append(errors, ValidationError{
				File:    fileName,
				Section: section,
				Field:   "type",
				Message: "section must be a table",
			})
			continue
		}
		errors = append(errors, validateSection(fileName, section, sectionMap)...)
	}

	return errors
}

func validateSection(file, section string, data map[string]interface{}) []ValidationError {
	var errors []ValidationError

	// match_command is required
	if _, ok := data["match_command"]; !ok {
		errors = append(errors, ValidationError{
			File:    file,
			Section: section,
			Field:   "match_command",
			Message: "missing required field match_command",
		})
	} else if cmd, ok := data["match_command"].(string); ok {
		if cmd == "" {
			errors = append(errors, ValidationError{
				File:    file,
				Section: section,
				Field:   "match_command",
				Message: "match_command cannot be empty",
			})
		}
	}

	// Validate regex patterns in strip_lines_matching and keep_lines_matching
	for _, field := range []string{"strip_lines_matching", "keep_lines_matching"} {
		if patterns, ok := data[field].([]interface{}); ok {
			for i, p := range patterns {
				if str, ok := p.(string); ok {
					if str == "" {
						errors = append(errors, ValidationError{
							File:    file,
							Section: section,
							Field:   fmt.Sprintf("%s[%d]", field, i),
							Message: "pattern cannot be empty",
						})
					}
				}
			}
		}
	}

	// Validate max_lines is positive if set
	if maxLines, ok := data["max_lines"].(int64); ok {
		if maxLines <= 0 {
			errors = append(errors, ValidationError{
				File:    file,
				Section: section,
				Field:   "max_lines",
				Message: "max_lines must be positive",
			})
		}
	}

	// Validate max_tokens is positive if set
	if maxTokens, ok := data["max_tokens"].(int64); ok {
		if maxTokens <= 0 {
			errors = append(errors, ValidationError{
				File:    file,
				Section: section,
				Field:   "max_tokens",
				Message: "max_tokens must be positive",
			})
		}
	}

	return errors
}

// ValidateAllFilters validates all TOML filter files in a directory.
func ValidateAllFilters(dir string) ([]ValidationError, error) {
	var allErrors []ValidationError

	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("reading filter directory: %w", err)
	}

	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".toml") {
			continue
		}
		path := filepath.Join(dir, entry.Name())
		errors := ValidateFilterFile(path)
		allErrors = append(allErrors, errors...)
	}

	return allErrors, nil
}
