package filter

import "unsafe"

// ZeroCopyBuffer provides zero-copy string operations.
//
// Safety contract: The returned string from String() shares memory with the
// underlying byte slice. Callers MUST NOT modify the buffer (via Append, Reset,
// etc.) after calling String() if they still hold a reference to the returned
// string. Doing so causes undefined behavior (data corruption / use-after-free).
type ZeroCopyBuffer struct {
	data []byte
}

func NewZeroCopyBuffer(capacity int) *ZeroCopyBuffer {
	return &ZeroCopyBuffer{data: make([]byte, 0, capacity)}
}

func (z *ZeroCopyBuffer) Append(s string) {
	z.data = append(z.data, s...)
}

func (z *ZeroCopyBuffer) AppendByte(b byte) {
	z.data = append(z.data, b)
}

// String returns the buffer contents as a string without copying.
// Safety: caller must not modify the underlying buffer after calling this
// if the returned string is still referenced. The returned string shares
// the same memory as the buffer's internal []byte.
func (z *ZeroCopyBuffer) String() string {
	if len(z.data) == 0 {
		return ""
	}
	// safe: the string header aliases z.data's backing array. The invariant
	// (documented above) is that the backing array is not mutated while the
	// returned string is live — Append/Reset after String() violate it.
	return unsafe.String(unsafe.SliceData(z.data), len(z.data)) // #nosec G103 -- audited: aliases z.data's backing array under the documented no-mutation-while-live invariant (see doc comment above)
}

func (z *ZeroCopyBuffer) Reset() {
	z.data = z.data[:0]
}

func (z *ZeroCopyBuffer) Len() int {
	return len(z.data)
}

// StringToBytes converts string to []byte without allocation.
// Safety contract: the caller MUST NOT modify the returned byte slice.
// The returned slice shares memory with the original string, and modifying
// it violates Go's string immutability guarantee, leading to undefined behavior.
func StringToBytes(s string) []byte {
	if len(s) == 0 {
		return nil
	}
	// safe: the slice aliases the string's backing array (len == cap == len(s)).
	// The invariant is that the backing array is never mutated through the
	// returned slice — callers treat it as read-only, preserving string
	// immutability.
	return unsafe.Slice(unsafe.StringData(s), len(s)) // #nosec G103 -- audited: aliases s's backing array under the documented read-only invariant (see doc comment above)
}

// BytesToString converts []byte to string without allocation.
// Safety contract: the caller MUST NOT modify the input byte slice after
// calling this function if the returned string is still referenced.
// The returned string shares memory with the input slice.
func BytesToString(b []byte) string {
	if len(b) == 0 {
		return ""
	}
	// safe: the string header aliases b's backing array. The invariant is that
	// the backing array is not mutated (through b or any other alias) while the
	// returned string is live, preserving string immutability.
	return unsafe.String(unsafe.SliceData(b), len(b)) // #nosec G103 -- audited: aliases b's backing array under the documented no-mutation-while-live invariant (see doc comment above)
}
