# Shrike Pipeline Microbenchmark Baseline

## Metadata

- Suite: `shrike-pipeline-microbench`
- Date: `2026-06-27`
- Model: none
- Provider: none
- Commit: current workspace snapshot
- Command: `/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./evals/pipeline-bench.sh'`

## Headline Metrics

- ProcessSmall: `20342 ns/op`, `8707 B/op`, `90 allocs/op`
- ProcessMedium: `78233 ns/op`, `44992 B/op`, `70 allocs/op`
- ProcessWithBudget: `43841 ns/op`, `24232 B/op`, `45 allocs/op`
- EstimateTokens Small: `18.89 ns/op`
- EstimateTokens Medium: `8442 ns/op`
- EstimateTokens Large: `127261 ns/op`
- Layer Entropy: `3508 ns/op`, `1930 B/op`, `22 allocs/op`
- Layer Perplexity: `3775 ns/op`, `1607 B/op`, `27 allocs/op`
- ProcessParallel: `1637 ns/op`, `3104 B/op`, `19 allocs/op`

## Notes

- This is the first committed repo-owned baseline artifact for `shrike-pipeline-microbench`.
- The runner targets the internal filter pipeline directly through Go benchmark entrypoints.
- The script completed successfully and printed the benchmark summary footer.

## Comparison Summary

- Previous baseline: none committed
- Change since baseline: initial published baseline
- Interpretation: the core filter pipeline stays in the tens-of-microseconds range for small and medium process cases, with low-single-microsecond parallel path timings on this local harness.
