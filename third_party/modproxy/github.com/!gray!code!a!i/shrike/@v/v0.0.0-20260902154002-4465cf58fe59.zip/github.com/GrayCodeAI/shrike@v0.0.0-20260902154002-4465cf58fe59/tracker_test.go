package shrike_test

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestNewTracker_AtCustomPath(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "tok_tracker_test.db")
	tr, err := shrike.NewTrackerAt(context.Background(), path)
	if err != nil {
		t.Fatalf("NewTrackerAt: %v", err)
	}
	defer func() { _ = tr.Close() }()

	ctx := context.Background()
	if err := tr.Record(ctx, shrike.TrackerEvent{
		Command:          "test",
		OriginalBytes:    1000,
		CompressedBytes:  500,
		OriginalTokens:   250,
		CompressedTokens: 125,
		Mode:             "aggressive",
		Tier:             "code",
	}); err != nil {
		t.Fatalf("Record: %v", err)
	}
	agg, err := tr.Aggregate(ctx, 30)
	if err != nil {
		t.Fatalf("Aggregate: %v", err)
	}
	if agg.EventCount != 1 {
		t.Errorf("expected 1 event, got %d", agg.EventCount)
	}
	if agg.TotalBytesSaved != 500 {
		t.Errorf("expected 500 bytes saved, got %d", agg.TotalBytesSaved)
	}
}
