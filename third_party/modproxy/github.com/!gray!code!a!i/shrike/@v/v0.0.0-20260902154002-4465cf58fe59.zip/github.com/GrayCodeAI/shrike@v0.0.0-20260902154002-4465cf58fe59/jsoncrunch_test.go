package shrike_test

import (
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
)

func TestCompressJSON_LargeArray(t *testing.T) {
	var items []string
	for i := 0; i < 50; i++ {
		items = append(items, fmt.Sprintf(`{"id":%d,"status":"ok"}`, i))
	}
	// inject an error item
	items[25] = `{"id":25,"status":"error"}`
	input := "[" + strings.Join(items, ",") + "]"

	out := shrike.CompressJSON(input, 20)
	var result []json.RawMessage
	if err := json.Unmarshal([]byte(out), &result); err != nil {
		t.Fatalf("invalid JSON output: %v", err)
	}
	// maxItems kept records plus at most one _tok_elided sentinel record.
	if len(result) > 21 {
		t.Errorf("expected <= maxItems+1 (sentinel) items, got %d", len(result))
	}
	if len(result) >= 50 {
		t.Error("expected array to be reduced")
	}
	// error item must be kept
	if !strings.Contains(out, `"error"`) {
		t.Error("expected error item preserved")
	}
	// elision must never be silent: the sentinel states count + verified facts
	if !strings.Contains(out, "_tok_elided") {
		t.Error("expected _tok_elided sentinel in output")
	}
}

func TestCompressJSON_SmallArray(t *testing.T) {
	input := `[1,2,3]`
	out := shrike.CompressJSON(input, 20)
	if out != input {
		t.Errorf("expected unchanged, got %s", out)
	}
}

func TestCompressJSON_NotArray(t *testing.T) {
	input := `{"key":"value"}`
	out := shrike.CompressJSON(input, 20)
	if out != input {
		t.Errorf("expected unchanged, got %s", out)
	}
}
