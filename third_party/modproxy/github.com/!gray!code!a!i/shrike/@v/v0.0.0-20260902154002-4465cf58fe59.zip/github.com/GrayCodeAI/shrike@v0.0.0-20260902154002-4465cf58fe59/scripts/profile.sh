#!/bin/bash
# Performance profiling for the shrike library.
#
# shrike is a library (no CLI), so profiling runs against its benchmarks
# rather than a binary. Usage: ./scripts/profile.sh [compress|tokens|filter|secrets|all] [output_dir]

set -e

PROFILE_TARGET=${1:-compress}
OUTPUT_DIR=${2:-./profiles}

echo "🔍 Shrike Library Profiling"
echo "═══════════════════════════════════════════════════════"
echo "Target: $PROFILE_TARGET"
echo "Output Directory: $OUTPUT_DIR"
echo ""

mkdir -p "$OUTPUT_DIR"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# run_bench <name> <bench-regexp> <package>
run_bench() {
    local name="$1" regexp="$2" pkg="$3"
    local cpu="$OUTPUT_DIR/${name}_cpu_${TIMESTAMP}.prof"
    local mem="$OUTPUT_DIR/${name}_mem_${TIMESTAMP}.prof"
    echo "📦 Benchmarking ${name} (${regexp} in ${pkg})..."
    go test -run='^$' -bench="$regexp" -benchmem \
        -cpuprofile="$cpu" -memprofile="$mem" "$pkg"
    echo ""
    echo "📊 CPU hotspots:"
    go tool pprof -top -cum "$cpu" | head -20
    echo ""
    echo "💡 Merlin: go tool pprof -http=:8080 $cpu"
    echo ""
}

case $PROFILE_TARGET in
    compress)
        run_bench compress 'BenchmarkCompress' .
        ;;
    tokens)
        run_bench tokens 'BenchmarkCountTokens|BenchmarkBPEEncode' .
        ;;
    filter)
        run_bench filter 'BenchmarkPipeline' ./internal/filter/
        ;;
    secrets)
        run_bench secrets 'BenchmarkSecretDetector' ./internal/secrets/
        ;;
    all)
        $0 compress "$OUTPUT_DIR"
        $0 tokens "$OUTPUT_DIR"
        $0 filter "$OUTPUT_DIR"
        $0 secrets "$OUTPUT_DIR"
        ;;
    *)
        echo "❌ Unknown target: $PROFILE_TARGET"
        echo "Usage: $0 [compress|tokens|filter|secrets|all] [output_dir]"
        exit 1
        ;;
esac

echo "✅ Profiling complete! Output in: $OUTPUT_DIR"
ls -lh "$OUTPUT_DIR"/*.prof 2>/dev/null || true
