package cache

import (
	"container/list"
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"sync"
)

// MultiLevelCache implements L1 (memory) + L2 (disk) + L3 (optional Redis) caching
type MultiLevelCache struct {
	l1      map[string]string        // In-memory cache
	l1Order *list.List               // LRU order: front=oldest, back=newest
	l1Index map[string]*list.Element // O(1) lookup into l1Order
	l2Dir   string                   // Disk cache directory
	mu      sync.RWMutex
	maxL1   int
}

// NewMultiLevelCache creates a 3-tier cache
func NewMultiLevelCache(l2Dir string, maxL1Size int) (*MultiLevelCache, error) {
	if err := os.MkdirAll(l2Dir, 0o700); err != nil {
		return nil, err
	}
	return &MultiLevelCache{
		l1:      make(map[string]string, maxL1Size),
		l1Order: list.New(),
		l1Index: make(map[string]*list.Element, maxL1Size),
		l2Dir:   l2Dir,
		maxL1:   maxL1Size,
	}, nil
}

// Get retrieves from L1 → L2 → L3
func (mc *MultiLevelCache) Get(key string) (string, bool) {
	// L1: Memory
	mc.mu.RLock()
	if val, ok := mc.l1[key]; ok {
		mc.mu.RUnlock()
		// Promote to back (most recently used) under write lock.
		mc.mu.Lock()
		if elem, ok := mc.l1Index[key]; ok {
			mc.l1Order.MoveToBack(elem)
		}
		mc.mu.Unlock()
		return val, true
	}
	mc.mu.RUnlock()

	// L2: Disk
	hash := hashKey(key)
	path := filepath.Join(mc.l2Dir, hash)
	data, err := os.ReadFile(path) // #nosec G304 -- path is a hash-derived filename under the cache's configured l2Dir, not externally supplied
	if err == nil {
		val := string(data)
		mc.promoteToL1(key, val)
		return val, true
	}

	return "", false
}

// Set stores in all cache levels
func (mc *MultiLevelCache) Set(key, value string) {
	mc.mu.Lock()
	// Update existing key: refresh value, move to back.
	if elem, ok := mc.l1Index[key]; ok {
		mc.l1[key] = value
		mc.l1Order.MoveToBack(elem)
		mc.mu.Unlock()
	} else {
		// Evict oldest entry if at capacity.
		if mc.l1Order.Len() >= mc.maxL1 {
			mc.evictOldestL1()
		}
		mc.l1[key] = value
		elem := mc.l1Order.PushBack(key)
		mc.l1Index[key] = elem
		mc.mu.Unlock()
	}

	// L2: Disk
	hash := hashKey(key)
	path := filepath.Join(mc.l2Dir, hash)
	_ = os.WriteFile(path, []byte(value), 0o600)
}

func (mc *MultiLevelCache) promoteToL1(key, value string) {
	mc.mu.Lock()
	defer mc.mu.Unlock()

	// Update existing key: refresh value, move to back.
	if elem, ok := mc.l1Index[key]; ok {
		mc.l1[key] = value
		mc.l1Order.MoveToBack(elem)
		return
	}

	// Evict oldest entry if at capacity.
	if mc.l1Order.Len() >= mc.maxL1 {
		mc.evictOldestL1()
	}

	elem := mc.l1Order.PushBack(key)
	mc.l1Index[key] = elem
	mc.l1[key] = value
}

// evictOldestL1 removes the least-recently-used entry from L1. Caller must hold mc.mu.
func (mc *MultiLevelCache) evictOldestL1() {
	front := mc.l1Order.Front()
	if front == nil {
		return
	}
	key, _ := front.Value.(string)
	mc.l1Order.Remove(front)
	delete(mc.l1Index, key)
	delete(mc.l1, key)
}

func hashKey(key string) string {
	h := sha256.Sum256([]byte(key))
	return hex.EncodeToString(h[:])
}
