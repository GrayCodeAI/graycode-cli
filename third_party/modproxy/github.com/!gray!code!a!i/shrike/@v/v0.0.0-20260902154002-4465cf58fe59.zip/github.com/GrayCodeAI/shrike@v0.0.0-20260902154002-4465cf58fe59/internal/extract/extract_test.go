package extract_test

import (
	"encoding/json"
	"testing"

	"github.com/GrayCodeAI/shrike/internal/extract"
)

func TestExtractJSONObject_BareObject(t *testing.T) {
	input := `{"name": "alice", "age": 30}`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	if r.JSON != input {
		t.Errorf("expected %q, got %q", input, r.JSON)
	}
	if r.Start != 0 {
		t.Errorf("expected start=0, got %d", r.Start)
	}
	if r.End != len(input) {
		t.Errorf("expected end=%d, got %d", len(input), r.End)
	}
}

func TestExtractJSONObject_WithProseBefore(t *testing.T) {
	input := `Sure! Here's the JSON you asked for:
{"name": "alice", "age": 30}
Hope that helps!`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	expected := `{"name": "alice", "age": 30}`
	if r.JSON != expected {
		t.Errorf("expected %q, got %q", expected, r.JSON)
	}
	// Verify it's valid JSON
	var v map[string]interface{}
	if err := json.Unmarshal([]byte(r.JSON), &v); err != nil {
		t.Errorf("extracted JSON is not valid: %v", err)
	}
	if v["name"] != "alice" {
		t.Errorf("expected name=alice, got %v", v["name"])
	}
}

func TestExtractJSONObject_NestedObjects(t *testing.T) {
	input := `{"user": {"name": "alice", "tags": ["admin", "user"]}, "active": true}`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	if r.JSON != input {
		t.Errorf("expected %q, got %q", input, r.JSON)
	}
	var v map[string]interface{}
	if err := json.Unmarshal([]byte(r.JSON), &v); err != nil {
		t.Errorf("nested JSON is not valid: %v", err)
	}
}

func TestExtractJSONObject_StringsWithBraces(t *testing.T) {
	// The string contains a literal "}" and "{" which must NOT be
	// treated as braces.
	input := `{"msg": "Hello {world}", "tail": "}"}`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	if r.JSON != input {
		t.Errorf("expected %q, got %q", input, r.JSON)
	}
}

func TestExtractJSONObject_EscapedQuotesInStrings(t *testing.T) {
	input := `{"msg": "He said \"hello\"", "ok": true}`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	if r.JSON != input {
		t.Errorf("expected %q, got %q", input, r.JSON)
	}
}

func TestExtractJSONObject_NotFound(t *testing.T) {
	tests := []string{
		"",
		"no braces here",
		`"just a string with a brace { inside"`,
	}
	for _, in := range tests {
		t.Run(in, func(t *testing.T) {
			r := extract.ExtractJSONObject(in)
			if r.Found {
				t.Errorf("expected not found for %q, got %+v", in, r)
			}
		})
	}
}

func TestExtractJSONObject_UnterminatedOpener(t *testing.T) {
	// "just a { and no closer" — there IS an opener but it never closes.
	// Partial JSON objects are reported as Found=true with the partial
	// content (best effort for truncated LLM output).
	in := "just a { and no closer"
	r := extract.ExtractJSONObject(in)
	if !r.Found {
		t.Errorf("expected unterminated opener to be reported as found, got %+v", r)
	}
	// The extracted portion starts at the opener and continues to end of input.
	if r.JSON != "{ and no closer" {
		t.Errorf("expected partial %q, got %q", "{ and no closer", r.JSON)
	}
	if r.Start != 7 {
		t.Errorf("expected start=7, got %d", r.Start)
	}
}

func TestExtractJSONObject_OnlyClosers(t *testing.T) {
	// Sequence of }{}{}{}{}{}{}{}{}{ — the first valid object is `{}`
	// at position 1-2.
	in := "}{}{}{}{}{}{}{}{}{"
	r := extract.ExtractJSONObject(in)
	if !r.Found {
		t.Fatal("expected to find {} in the sequence")
	}
	if r.JSON != "{}" {
		t.Errorf("expected {}, got %q", r.JSON)
	}
}

func TestExtractJSONObject_Unterminated(t *testing.T) {
	// Returns Found=true with partial content if braces never balance.
	input := `{"a": 1, "b": 2`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected partial extraction to be reported as found")
	}
	if r.JSON != input {
		t.Errorf("expected %q, got %q", input, r.JSON)
	}
}

func TestExtractJSONArray(t *testing.T) {
	input := `Here is the array:
[1, 2, {"three": 3}, "four"]
That's it.`
	r := extract.ExtractJSONArray(input)
	if !r.Found {
		t.Fatal("expected to find array")
	}
	expected := `[1, 2, {"three": 3}, "four"]`
	if r.JSON != expected {
		t.Errorf("expected %q, got %q", expected, r.JSON)
	}
}

func TestExtractAllJSONObjects(t *testing.T) {
	input := `First: {"a": 1} middle text Second: {"b": 2} tail`
	results := extract.ExtractAllJSONObjects(input)
	if len(results) != 2 {
		t.Fatalf("expected 2 objects, got %d", len(results))
	}
	if results[0].JSON != `{"a": 1}` {
		t.Errorf("expected first = {\"a\": 1}, got %q", results[0].JSON)
	}
	if results[1].JSON != `{"b": 2}` {
		t.Errorf("expected second = {\"b\": 2}, got %q", results[1].JSON)
	}
}

func TestExtractJSONObject_MarkdownCodeFence(t *testing.T) {
	input := "```json\n{\"a\": 1}\n```"
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object in markdown")
	}
	expected := `{"a": 1}`
	if r.JSON != expected {
		t.Errorf("expected %q, got %q", expected, r.JSON)
	}
}

func TestExtractJSONObject_RealisticLLMOutput(t *testing.T) {
	input := `Sure! Here's the data you requested:

{
  "user": {
    "name": "Alice Smith",
    "email": "alice@example.com",
    "roles": ["admin", "user"],
    "settings": {
      "theme": "dark",
      "notifications": true
    }
  },
  "timestamp": "2026-06-01T12:00:00Z"
}

Let me know if you need anything else!`
	r := extract.ExtractJSONObject(input)
	if !r.Found {
		t.Fatal("expected to find JSON object")
	}
	// Verify it parses
	var v map[string]interface{}
	if err := json.Unmarshal([]byte(r.JSON), &v); err != nil {
		t.Errorf("extracted JSON is not valid: %v", err)
	}
	if v["user"].(map[string]interface{})["name"] != "Alice Smith" {
		t.Errorf("unexpected value: %+v", v)
	}
}
