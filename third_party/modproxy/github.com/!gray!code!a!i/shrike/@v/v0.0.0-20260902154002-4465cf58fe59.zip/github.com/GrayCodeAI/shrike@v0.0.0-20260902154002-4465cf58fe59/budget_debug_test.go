package shrike_test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike"
	"github.com/GrayCodeAI/shrike/internal/core"
)

func TestBudgetDebug(t *testing.T) {
	input := strings.Repeat("word ", 200)
	fmt.Printf("Input tokens: %d\n", core.EstimateTokens(input))

	// Test with different modes
	for _, mode := range []struct {
		name string
		opts []shrike.Option
	}{
		{"WithBudget(50)", []shrike.Option{shrike.WithBudget(50)}},
		{"WithBudget(50)+Aggressive", []shrike.Option{shrike.WithBudget(50), shrike.Aggressive}},
		{"WithBudget(100)", []shrike.Option{shrike.WithBudget(100)}},
		{"WithBudget(200)", []shrike.Option{shrike.WithBudget(200)}},
	} {
		output, stats := shrike.Compress(input, mode.opts...)
		fmt.Printf("%s: output_tokens=%d, output_len=%d\n", mode.name, stats.FinalTokens, len(output))
		_ = output
	}
}
