# Shrike Troubleshooting Guide

**Solutions to common issues when using the shrike Go library**

> **Note:** `shrike` is a Go *library* (`github.com/GrayCodeAI/shrike`). There is no
> standalone `shrike` CLI binary. If you remember CLI verbs like `shrike compress`,
> `shrike gain`, or `shrike tui`, those live in **Hawk**
> ([github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk)), which
> embeds this library (e.g. `hawk shrike compress`). This guide covers the library.

---

## Table of Contents

1. [Installation / Import Issues](#installation--import-issues)
2. [Compression Output Issues](#compression-output-issues)
3. [Performance Issues](#performance-issues)
4. [Custom Filter (TOML) Issues](#custom-filter-toml-issues)
5. [Benchmark Issues](#benchmark-issues)

---

## Installation / Import Issues

### `cannot find module` / `no required module provides package`

**Cause**: The module isn't added to your project.

**Solution**:

```bash
go get github.com/GrayCodeAI/shrike
```

Then import it:

```go
import "github.com/GrayCodeAI/shrike"
```

### Build errors from source

**Cause**: Missing dependencies or an old Go toolchain.

**Solutions**:

1. Ensure Go 1.21+:
   ```bash
   go version
   ```

2. Refresh dependencies:
   ```bash
   go mod tidy
   go mod download
   ```

3. Clean the build cache:
   ```bash
   go clean -cache
   go build ./...
   ```

---

## Compression Output Issues

### Output is not compact enough

**Cause**: The default intensity is conservative.

**Solution**: Raise the intensity, or use the `Aggressive` mode.

```go
// Prompt compression at higher intensity
out, _ := shrike.PromptCompress(text, shrike.IntensityFull)   // or shrike.IntensityUltra

// Generic compression with aggressive mode
out, _ := shrike.Compress(text, shrike.Aggressive)
```

Available levels: `shrike.IntensityLite`, `shrike.IntensityFull`, `shrike.IntensityUltra`.

### Important content is being stripped

**Cause**: A high intensity (or `Aggressive`) is removing detail you need.

**Solutions**:

1. Drop to a lighter intensity:
   ```go
   out, _ := shrike.PromptCompress(text, shrike.IntensityLite)
   ```

2. For source code, use the code-aware option so language structure is preserved:
   ```go
   out, _ := shrike.Compress(code, shrike.WithCodeAware("go"))
   ```

3. If you need structured data kept intact, extract it first:
   ```go
   jsonStr, _ := shrike.ExtractJSON(text)
   ```

### Need to fit within a token budget

Use truncation and estimation helpers rather than guessing:

```go
truncated := shrike.SmartTruncate(text, maxTokens)
cost := shrike.EstimateCost(truncated, "gpt-4o")
```

### Sensitive data appears in compressed output

**Cause**: Secrets in the input are passed through unless you screen them.

**Solution**: Run the secret detector / filename check before compressing.

```go
det := shrike.NewSecretDetector()
findings := det.Scan(text)

if shrike.IsSensitiveFilename(path) {
    // skip or redact
}
```

---

## Performance Issues

### Slow or memory-heavy on very large inputs

**Causes**: Whole-document buffering, or running the full 31-layer pipeline on
inputs that don't need it.

**Solutions**:

1. Pre-truncate before compressing:
   ```go
   text = shrike.SmartTruncate(text, maxTokens)
   out, _ := shrike.Compress(text)
   ```

2. Use a lighter intensity for hot paths:
   ```go
   out, _ := shrike.PromptCompress(text, shrike.IntensityLite)
   ```

3. For perplexity-guided compression, tune the keep ratio (lower = more
   aggressive, less work downstream):
   ```go
   out, _ := shrike.Compress(text, shrike.WithPerplexityGuided(scorer, 0.5))
   ```

### Tracking overhead

The tracker is opt-in. Create it only where you need usage metrics, and reuse it:

```go
tracker := shrike.NewTracker(ctx)
```

---

## Custom Filter (TOML) Issues

Custom filters are **TOML files** loaded via `shrike.LoadFilterRules` and applied
with `shrike.WithCustomFilters`. Profiles are loaded with `shrike.LoadProfile`.

### Filters not being applied

**Cause**: Rules were loaded but not passed into `Compress`.

**Solution**: Load, then wire them in via the option.

```go
rules, err := shrike.LoadFilterRules("filters.toml")
if err != nil {
    log.Fatal(err)
}
out, _ := shrike.Compress(text, shrike.WithCustomFilters(rules))
```

### `LoadFilterRules` returns an error

**Solutions**:

1. Validate the TOML is well-formed (correct tables, quoted strings, escaped
   backslashes in patterns).
2. Confirm the file path is correct relative to the running process.
3. Use Go regular-expression syntax (RE2), not PCRE, in pattern fields —
   features like lookaround are not supported.

### Loading a saved profile

```go
profile, err := shrike.LoadProfile("profile.toml")
if err != nil {
    log.Fatal(err)
}
```

---

## Benchmark Issues

Benchmarks are plain Go benchmarks wrapped by helper scripts:

```bash
./benchmarks/run.sh          # wraps: go test -bench
./evals/pipeline-bench.sh    # wraps: go test -bench
```

### Benchmarks don't run / no output

**Solutions**:

1. Run the underlying command directly to see errors:
   ```bash
   go test -bench=. ./...
   ```

2. Ensure the scripts are executable:
   ```bash
   chmod +x ./benchmarks/run.sh ./evals/pipeline-bench.sh
   ```

3. Confirm your Go toolchain is healthy (`go version`, `go mod tidy`).

---

## Still Having Issues?

1. Reproduce with a minimal Go program calling the relevant API
   (`shrike.Compress`, `shrike.PromptCompress`, etc.).
2. Verify your environment: `go version`, `go env GOPATH`, and that
   `go get github.com/GrayCodeAI/shrike` succeeded.
3. If the problem is with a CLI verb (e.g. `shrike compress`, `shrike gain`, `shrike
   tui`), that surface lives in **Hawk** — see
   [github.com/GrayCodeAI/hawk](https://github.com/GrayCodeAI/hawk).
4. Report library issues at
   [github.com/GrayCodeAI/shrike/issues](https://github.com/GrayCodeAI/shrike/issues).
   Include: a minimal reproduction, Go version, and OS.

---

## Quick Reference

| Issue | Quick Fix |
|-------|-----------|
| Module not found | `go get github.com/GrayCodeAI/shrike` |
| Output not compact | `shrike.PromptCompress(text, shrike.IntensityUltra)` or `shrike.Compress(text, shrike.Aggressive)` |
| Over-compressed | `shrike.PromptCompress(text, shrike.IntensityLite)` |
| Code mangled | `shrike.Compress(code, shrike.WithCodeAware("go"))` |
| Over token budget | `shrike.SmartTruncate(text, max)` + `shrike.EstimateTokensForModel` |
| Secrets leaking | `shrike.NewSecretDetector()` / `shrike.IsSensitiveFilename` |
| Custom filters ignored | `shrike.LoadFilterRules` + `shrike.WithCustomFilters` |
| Want CLI verbs | Use Hawk (`hawk shrike ...`) |
