package filter

import (
	"strings"
	"testing"
)

// TestSmartTruncate_InvariantKeptPlusDroppedEqualsTotal verifies the core
// line-accounting invariant: KeptLines + DroppedLines == OriginalLines for any
// truncation that actually fired. This prevents agents from re-parsing
// the truncation comment as code.
func TestSmartTruncate_InvariantKeptPlusDroppedEqualsTotal(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		maxLines int
		lang     Language
	}{
		{
			name:     "go",
			input:    strings.Repeat("package main\nfunc _() { _ = 1 }\n", 50),
			maxLines: 10,
			lang:     LangGo,
		},
		{
			name:     "rust",
			input:    strings.Repeat("fn x() {}\n", 50),
			maxLines: 8,
			lang:     LangRust,
		},
		{
			name:     "python",
			input:    strings.Repeat("def x(): pass\n", 50),
			maxLines: 6,
			lang:     LangPython,
		},
		{
			name:     "javascript",
			input:    strings.Repeat("function x() {}\n", 50),
			maxLines: 5,
			lang:     LangJavaScript,
		},
		{
			name:     "tiny_maxlines",
			input:    strings.Repeat("a\n", 100),
			maxLines: 1,
			lang:     LangUnknown,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			out, stats := SmartTruncate(tc.input, tc.maxLines, tc.lang)
			if !stats.Truncated {
				t.Fatalf("expected Truncated=true for maxLines=%d and %d-line input", tc.maxLines, stats.OriginalLines)
			}
			if stats.KeptLines+stats.DroppedLines != stats.OriginalLines {
				t.Errorf("invariant broken: kept=%d + dropped=%d != total=%d",
					stats.KeptLines, stats.DroppedLines, stats.OriginalLines)
			}
			if !strings.Contains(out, "lines omitted") {
				t.Errorf("expected marker to mention 'lines omitted', got: %q", out)
			}
			// The dropped count must appear in the marker.
			if !strings.Contains(out, itoa(stats.DroppedLines)) {
				t.Errorf("expected marker to include dropped count %d, got: %q", stats.DroppedLines, out)
			}
		})
	}
}

// TestSmartTruncate_NoTruncationNeeded verifies that under-budget inputs
// return untouched and stats.KeptLines == stats.OriginalLines.
func TestSmartTruncate_NoTruncationNeeded(t *testing.T) {
	in := "line1\nline2\nline3"
	out, stats := SmartTruncate(in, 100, LangGo)
	if out != in {
		t.Errorf("expected unchanged output, got %q", out)
	}
	if stats.Truncated {
		t.Error("expected Truncated=false when under budget")
	}
	if stats.KeptLines != stats.OriginalLines {
		t.Errorf("expected KeptLines==OriginalLines, got kept=%d total=%d", stats.KeptLines, stats.OriginalLines)
	}
	if stats.DroppedLines != 0 {
		t.Errorf("expected DroppedLines=0, got %d", stats.DroppedLines)
	}
}

// TestSmartTruncate_Empty verifies graceful handling of empty input.
func TestSmartTruncate_Empty(t *testing.T) {
	out, stats := SmartTruncate("", 10, LangGo)
	if out != "" {
		t.Errorf("expected empty output, got %q", out)
	}
	if stats.OriginalLines != 0 {
		t.Errorf("expected OriginalLines=0, got %d", stats.OriginalLines)
	}
}

// TestSmartTruncate_MaxLinesZero verifies maxLines<=0 passes through.
func TestSmartTruncate_MaxLinesZero(t *testing.T) {
	in := "a\nb\nc"
	out, stats := SmartTruncate(in, 0, LangGo)
	if out != in {
		t.Errorf("expected unchanged output for maxLines=0, got %q", out)
	}
	if stats.DroppedLines != 0 {
		t.Errorf("expected DroppedLines=0, got %d", stats.DroppedLines)
	}
}

// TestSmartTruncate_HeadAndTail verifies head + tail are preserved.
func TestSmartTruncate_HeadAndTail(t *testing.T) {
	var lines []string
	for i := 0; i < 100; i++ {
		lines = append(lines, "line_"+itoa(i))
	}
	in := strings.Join(lines, "\n")
	out, _ := SmartTruncate(in, 10, LangUnknown)
	if !strings.Contains(out, "line_0") {
		t.Error("expected first line preserved")
	}
	if !strings.Contains(out, "line_99") {
		t.Error("expected last line preserved")
	}
}

// TestSmartTruncate_SignaturesGo verifies Go function signatures are
// extracted and noted in the marker.
func TestSmartTruncate_SignaturesGo(t *testing.T) {
	in := `package main
func Hello(name string) string {
    return "hi " + name
}
func World() {
    _ = 1
    _ = 2
    _ = 3
    _ = 4
    _ = 5
    _ = 6
    _ = 7
    _ = 8
    _ = 9
    _ = 10
    _ = 11
    _ = 12
    _ = 13
    _ = 14
    _ = 15
    _ = 16
    _ = 17
    _ = 18
    _ = 19
    _ = 20
}
`
	out, stats := SmartTruncate(in, 5, LangGo)
	if !stats.HasSignatures {
		t.Error("expected HasSignatures=true for Go file with functions")
	}
	if !strings.Contains(out, "func Hello") {
		t.Error("expected 'func Hello' to appear in signatures")
	}
	if !strings.Contains(out, "signatures preserved") {
		t.Error("expected marker to note signatures preserved")
	}
}

// itoa is provided by columnar_json_encode.go in the same package; reused here.
