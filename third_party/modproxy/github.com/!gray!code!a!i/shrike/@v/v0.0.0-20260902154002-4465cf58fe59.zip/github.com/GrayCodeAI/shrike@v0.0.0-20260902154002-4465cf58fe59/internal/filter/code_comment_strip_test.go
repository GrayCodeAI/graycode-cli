package filter

import (
	"strings"
	"testing"
)

func TestNewCommentFilter(t *testing.T) {
	f := newCommentFilter()
	if f == nil {
		t.Fatal("newCommentFilter returned nil")
	}
	if len(f.patterns) == 0 {
		t.Error("expected patterns to be initialized")
	}
}

func TestCommentFilterName(t *testing.T) {
	f := newCommentFilter()
	if f.Name() != "comment" {
		t.Errorf("expected name %q, got %q", "comment", f.Name())
	}
}

func TestCommentFilterApplyGo(t *testing.T) {
	f := newCommentFilter()
	input := `// This is a comment at line start
package main

/* block comment */
func main() {
	fmt.Println("hello")
}`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "// This is a comment at line start") {
		t.Error("Go line comments at line start should be stripped")
	}
	if strings.Contains(output, "/* block comment */") {
		t.Error("Go block comments should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved from comment stripping")
	}
}

func TestCommentFilterApplyPython(t *testing.T) {
	f := newCommentFilter()
	input := `def main():
# This is a comment at line start
	print("hello")`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "# This is a comment at line start") {
		t.Error("Python line comments at line start should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyRust(t *testing.T) {
	f := newCommentFilter()
	input := `fn main() {
// Comment at line start
	println!("hello");
}`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "// Comment at line start") {
		t.Error("Rust line comments at line start should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyJavaScript(t *testing.T) {
	f := newCommentFilter()
	input := `function main() {
// Comment at line start
	console.log("hello");
}`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "// Comment at line start") {
		t.Error("JS line comments at line start should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplySQL(t *testing.T) {
	f := newCommentFilter()
	input := `SELECT * FROM users
-- SQL comment at line start
WHERE id = 1
/* block */`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "-- SQL comment at line start") {
		t.Error("SQL line comments at line start should be stripped")
	}
	if strings.Contains(output, "/* block */") {
		t.Error("SQL block comments should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyRuby(t *testing.T) {
	f := newCommentFilter()
	input := `puts "hello"
# Ruby comment at line start`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "# Ruby comment at line start") {
		t.Error("Ruby comments at line start should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyShell(t *testing.T) {
	f := newCommentFilter()
	input := `echo "hello"
# Shell comment at line start`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "# Shell comment at line start") {
		t.Error("Shell comments at line start should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyUnknownLanguage(t *testing.T) {
	f := newCommentFilter()
	input := `Some unknown content
// comment at line start
/* block */`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "// comment at line start") {
		t.Error("fallback comment pattern should strip line comments")
	}
	if strings.Contains(output, "/* block */") {
		t.Error("fallback comment pattern should strip block comments")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved")
	}
}

func TestCommentFilterApplyNoComments(t *testing.T) {
	f := newCommentFilter()
	input := `func main() {
	fmt.Println("hello")
}`
	_, saved := f.Apply(input, ModeMinimal)

	if saved != 0 {
		t.Errorf("expected 0 tokens saved for code without comments, got %d", saved)
	}
}

func TestCommentFilterApplyDocstring(t *testing.T) {
	f := newCommentFilter()
	input := `def main():
	"""docstring here"""
	print("hello")`
	output, saved := f.Apply(input, ModeMinimal)

	if strings.Contains(output, "docstring here") {
		t.Error("Python docstrings should be stripped")
	}
	if saved <= 0 {
		t.Error("expected some tokens to be saved from docstring stripping")
	}
}

func TestCommentPatternsMap(t *testing.T) {
	if len(CommentPatternsMap) == 0 {
		t.Fatal("CommentPatternsMap should not be empty")
	}

	expectedLangs := []Language{
		LangRust, LangGo, LangPython, LangJavaScript, LangTypeScript,
		LangJava, LangC, LangCpp, LangRuby, LangShell, LangSQL,
	}

	for _, lang := range expectedLangs {
		if _, ok := CommentPatternsMap[lang]; !ok {
			t.Errorf("CommentPatternsMap missing language %q", lang)
		}
	}
}

func TestCommentFilterApplyEmpty(t *testing.T) {
	f := newCommentFilter()
	output, saved := f.Apply("", ModeMinimal)

	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for empty input, got %d", saved)
	}
}
