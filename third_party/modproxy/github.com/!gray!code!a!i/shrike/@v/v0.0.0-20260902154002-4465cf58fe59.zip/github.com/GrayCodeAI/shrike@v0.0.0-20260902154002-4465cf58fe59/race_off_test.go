//go:build !race

package shrike_test

func raceEnabled() bool { return false }
