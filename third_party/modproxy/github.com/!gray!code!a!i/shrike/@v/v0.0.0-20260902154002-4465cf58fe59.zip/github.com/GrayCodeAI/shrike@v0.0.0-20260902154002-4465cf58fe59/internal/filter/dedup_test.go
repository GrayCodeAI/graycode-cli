package filter

import (
	"testing"
)

func TestSimHash(t *testing.T) {
	tests := []struct {
		name  string
		input string
	}{
		{"empty string", ""},
		{"short text", "hello"},
		{"longer text", "this is a longer piece of text for hashing"},
		{"with special chars", "hello!@#$%^&*()world"},
		{"repeated content", "aaaaaaa"},
		{"unicode", "hello 世界"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			hash := SimHash(tt.input)
			hash2 := SimHash(tt.input)
			if hash != hash2 {
				t.Errorf("SimHash should be deterministic: first=%d, second=%d", hash, hash2)
			}
		})
	}
}

func TestSimHashDifferentInputs(t *testing.T) {
	hash1 := SimHash("hello world")
	hash2 := SimHash("goodbye universe")
	if hash1 == hash2 {
		t.Error("different inputs should produce different hashes")
	}
}

func TestHammingDistance(t *testing.T) {
	tests := []struct {
		a, b     uint64
		expected int
	}{
		{0, 0, 0},
		{0, 1, 1},
		{1, 1, 0},
		{0xFFFFFFFF, 0, 32},
		{^uint64(0), 0, 64},
		{0x5555555555555555, 0xAAAAAAAAAAAAAAAA, 64},
	}

	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			result := HammingDistance(tt.a, tt.b)
			if result != tt.expected {
				t.Errorf("HammingDistance(0x%X, 0x%X) = %d, expected %d", tt.a, tt.b, result, tt.expected)
			}
		})
	}
}

func TestIsNearDuplicate(t *testing.T) {
	tests := []struct {
		name      string
		a, b      string
		threshold int
		expected  bool
	}{
		{
			name:      "identical content",
			a:         "hello world",
			b:         "hello world",
			threshold: 3,
			expected:  true,
		},
		{
			name:      "very different content",
			a:         "hello world",
			b:         "completely different content here",
			threshold: 3,
			expected:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := IsNearDuplicate(tt.a, tt.b, tt.threshold)
			if result != tt.expected {
				t.Errorf("IsNearDuplicate(%q, %q, %d) = %v, expected %v", tt.a, tt.b, tt.threshold, result, tt.expected)
			}
		})
	}
}

func TestNewCrossMessageDedup(t *testing.T) {
	d := NewCrossMessageDedup()
	if d == nil {
		t.Fatal("NewCrossMessageDedup returned nil")
	}
	if d.threshold != 3 {
		t.Errorf("expected default threshold 3, got %d", d.threshold)
	}
	if d.seen == nil {
		t.Error("seen map should be initialized")
	}
}

func TestCrossMessageDedupNewContent(t *testing.T) {
	d := NewCrossMessageDedup()
	isDup, replacement := d.DedupMessage("new unique content")
	if isDup {
		t.Error("new content should not be marked as duplicate")
	}
	if replacement != "new unique content" {
		t.Errorf("expected original content as replacement, got %q", replacement)
	}
}

func TestCrossMessageDedupExactDuplicate(t *testing.T) {
	d := NewCrossMessageDedup()
	d.DedupMessage("hello world")
	isDup, replacement := d.DedupMessage("hello world")
	if !isDup {
		t.Error("exact duplicate should be marked as duplicate")
	}
	if replacement != "[duplicate: previously sent]" {
		t.Errorf("expected duplicate marker, got %q", replacement)
	}
}

func TestCrossMessageDedupClear(t *testing.T) {
	d := NewCrossMessageDedup()
	d.DedupMessage("hello world")
	if d.Count() != 1 {
		t.Errorf("expected count 1, got %d", d.Count())
	}
	d.Clear()
	if d.Count() != 0 {
		t.Errorf("expected count 0 after Clear, got %d", d.Count())
	}
}

func TestCrossMessageDedupCount(t *testing.T) {
	d := NewCrossMessageDedup()
	d.DedupMessage("first message")
	d.DedupMessage("second message")
	d.DedupMessage("third message")
	if d.Count() != 3 {
		t.Errorf("expected count 3, got %d", d.Count())
	}
}

func TestCrossMessageDedupAfterClear(t *testing.T) {
	d := NewCrossMessageDedup()
	d.DedupMessage("hello world")
	d.Clear()
	isDup, _ := d.DedupMessage("hello world")
	if isDup {
		t.Error("content should not be duplicate after Clear")
	}
}

func TestGenerateDiff(t *testing.T) {
	tests := []struct {
		name     string
		old, new string
		expected string
	}{
		{
			name:     "added line",
			old:      "line1\nline2",
			new:      "line1\nline2\nline3",
			expected: "[diff]",
		},
		{
			name:     "removed line",
			old:      "line1\nline2\nline3",
			new:      "line1\nline2",
			expected: "[diff]",
		},
		{
			name:     "identical",
			old:      "same content",
			new:      "same content",
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := generateDiff(tt.old, tt.new)
			if tt.expected == "" {
				if result != "" {
					t.Errorf("expected empty diff for identical content, got %q", result)
				}
			} else {
				if !strContains(result, tt.expected) {
					t.Errorf("expected diff to contain %q, got %q", tt.expected, result)
				}
			}
		})
	}
}

func strContains(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

func TestSimHashConsistency(t *testing.T) {
	input := "the quick brown fox jumps over the lazy dog"
	h1 := SimHash(input)
	h2 := SimHash(input)
	if h1 != h2 {
		t.Error("SimHash should be consistent")
	}
}

func TestSimHashEmptyString(t *testing.T) {
	hash := SimHash("")
	if hash != 0 {
		t.Errorf("expected hash 0 for empty string, got %d", hash)
	}
}

func TestCrossMessageDedupConcurrent(t *testing.T) {
	d := NewCrossMessageDedup()
	done := make(chan bool)

	for i := 0; i < 10; i++ {
		go func(n int) {
			content := "message " + string(rune('a'+n))
			d.DedupMessage(content)
			done <- true
		}(i)
	}

	for i := 0; i < 10; i++ {
		<-done
	}

	if d.Count() < 1 {
		t.Error("expected at least 1 unique message after concurrent access")
	}
}
