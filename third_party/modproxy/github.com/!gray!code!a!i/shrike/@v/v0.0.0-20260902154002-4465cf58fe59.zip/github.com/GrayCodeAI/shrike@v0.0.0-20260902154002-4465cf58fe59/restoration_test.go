package shrike

import (
	"fmt"
	"strings"
	"testing"
	"time"
)

func TestRestorationTracker_Track(t *testing.T) {
	rt := NewRestorationTracker()
	rt.Track("/main.go", "package main", "read")
	rt.Track("/util.go", "func helper() {}", "write")

	if rt.Len() != 2 {
		t.Errorf("expected 2 entries, got %d", rt.Len())
	}
}

func TestRestorationTracker_DedupByPath(t *testing.T) {
	rt := NewRestorationTracker()
	rt.Track("/main.go", "v1", "read")
	rt.Track("/main.go", "v2", "write")

	if rt.Len() != 1 {
		t.Errorf("expected 1 entry after dedup, got %d", rt.Len())
	}
	entries := rt.Entries()
	if entries[0].Content != "v2" {
		t.Errorf("expected latest content 'v2', got %q", entries[0].Content)
	}
	if entries[0].OpType != "write" {
		t.Errorf("expected latest opType 'write', got %q", entries[0].OpType)
	}
}

func TestRestorationTracker_Priority(t *testing.T) {
	rt := NewRestorationTracker()
	rt.Track("/read.go", strings.Repeat("x ", 100), "read")
	rt.Track("/write.go", strings.Repeat("y ", 100), "write")
	rt.Track("/skill.md", strings.Repeat("z ", 100), "skill")

	entries := rt.Entries()
	priorities := map[string]int{}
	for _, e := range entries {
		priorities[e.OpType] = e.Priority
	}
	if priorities["write"] != PriorityWriteEdit {
		t.Errorf("expected write priority %d, got %d", PriorityWriteEdit, priorities["write"])
	}
	if priorities["skill"] != PrioritySkill {
		t.Errorf("expected skill priority %d, got %d", PrioritySkill, priorities["skill"])
	}
	if priorities["read"] != PriorityRead {
		t.Errorf("expected read priority %d, got %d", PriorityRead, priorities["read"])
	}
}

func TestRestorationTracker_GetRestorations_PriorityOrder(t *testing.T) {
	rt := NewRestorationTracker()
	// Track in reverse priority order
	rt.Track("/read.go", "a", "read")
	time.Sleep(time.Millisecond)
	rt.Track("/write.go", "b", "write")
	time.Sleep(time.Millisecond)
	rt.Track("/skill.md", "c", "skill")

	// Get with large budget — should return all, sorted by priority
	all := rt.GetRestorations(100000)
	if len(all) != 3 {
		t.Fatalf("expected 3 entries, got %d", len(all))
	}
	// write(100) > skill(80) > read(50)
	if all[0].OpType != "write" {
		t.Errorf("first should be write, got %s", all[0].OpType)
	}
	if all[1].OpType != "skill" {
		t.Errorf("second should be skill, got %s", all[1].OpType)
	}
	if all[2].OpType != "read" {
		t.Errorf("third should be read, got %s", all[2].OpType)
	}
}

func TestRestorationTracker_GetRestorations_BudgetLimit(t *testing.T) {
	rt := NewRestorationTracker()
	// Each entry is ~10 tokens (10 words)
	rt.Track("/a.go", "word word word word word word word word word word", "write")
	rt.Track("/b.go", "word word word word word word word word word word", "write")
	rt.Track("/c.go", "word word word word word word word word word word", "write")

	// Budget allows ~15 tokens (1.5 entries)
	restored := rt.GetRestorations(15)
	if len(restored) > 2 {
		t.Errorf("expected at most 2 entries within budget, got %d", len(restored))
	}
}

func TestRestorationTracker_GetRestorations_EmptyBudget(t *testing.T) {
	rt := NewRestorationTracker()
	rt.Track("/a.go", "content", "write")

	if got := rt.GetRestorations(0); got != nil {
		t.Errorf("expected nil for 0 budget, got %v", got)
	}
	if got := rt.GetRestorations(-1); got != nil {
		t.Errorf("expected nil for negative budget, got %v", got)
	}
}

func TestRestorationTracker_ComputeBudget(t *testing.T) {
	rt := NewRestorationTracker().WithMaxBudget(50000).WithBudgetPct(0.15).WithContextWindow(200000)

	// min(50000, 200000*0.15=30000, 200000-100000-20000=80000) = 30000
	got := rt.ComputeBudget(100000, 20000)
	if got != 30000 {
		t.Errorf("expected 30000, got %d", got)
	}
}

func TestRestorationTracker_ComputeBudget_Constrained(t *testing.T) {
	rt := NewRestorationTracker().WithMaxBudget(50000).WithBudgetPct(0.15).WithContextWindow(200000)

	// min(50000, 30000, 200000-180000-10000=10000) = 10000
	got := rt.ComputeBudget(180000, 10000)
	if got != 10000 {
		t.Errorf("expected 10000, got %d", got)
	}
}

func TestRestorationTracker_ComputeBudget_Zero(t *testing.T) {
	rt := NewRestorationTracker().WithMaxBudget(50000).WithBudgetPct(0.15).WithContextWindow(200000)

	// Over budget: remaining < 0
	got := rt.ComputeBudget(200000, 10000)
	if got != 0 {
		t.Errorf("expected 0, got %d", got)
	}
}

func TestRestorationTracker_Clear(t *testing.T) {
	rt := NewRestorationTracker()
	rt.Track("/a.go", "content", "read")
	rt.Track("/b.go", "content", "write")
	rt.Clear()
	if rt.Len() != 0 {
		t.Errorf("expected 0 after clear, got %d", rt.Len())
	}
}

func TestRestorationTracker_EmptyGetRestorations(t *testing.T) {
	rt := NewRestorationTracker()
	if got := rt.GetRestorations(1000); got != nil {
		t.Errorf("expected nil for empty tracker, got %v", got)
	}
}

func TestRestorationTracker_TrackSamePathRepeatedly(t *testing.T) {
	rt := NewRestorationTracker()
	for i := 0; i < 500; i++ {
		rt.Track("/main.go", fmt.Sprintf("revision %d", i), "write")
	}

	if rt.Len() != 1 {
		t.Errorf("expected 1 entry after 500 tracks of the same path, got %d", rt.Len())
	}
	entries := rt.Entries()
	if entries[0].Content != "revision 499" {
		t.Errorf("expected latest content 'revision 499', got %q", entries[0].Content)
	}
}

func TestRestorationTracker_RetainedBudgetEvictsOldest(t *testing.T) {
	// Identical content shape so all three entries cost the same T tokens.
	content := strings.Repeat("word ", 100)
	perEntry := EstimateTokens(content)

	rt := NewRestorationTracker().WithRetainedTokenBudget(2 * perEntry)
	rt.Track("/a.go", content, "read")
	rt.Track("/b.go", content, "read")
	rt.Track("/c.go", content, "read") // over budget: oldest (/a.go) evicted

	if rt.Len() != 2 {
		t.Fatalf("expected 2 entries after eviction, got %d", rt.Len())
	}
	paths := map[string]bool{}
	for _, e := range rt.Entries() {
		paths[e.Path] = true
	}
	if paths["/a.go"] {
		t.Error("oldest entry /a.go should have been evicted")
	}
	if !paths["/b.go"] || !paths["/c.go"] {
		t.Errorf("recent entries should be retained, got %v", paths)
	}

	// Clear still resets everything.
	rt.Clear()
	if rt.Len() != 0 || len(rt.Entries()) != 0 {
		t.Errorf("expected empty tracker after Clear, got len=%d", rt.Len())
	}
}

func TestRestorationTracker_RetainedBudgetEvictsLeastRecentlyTracked(t *testing.T) {
	content := strings.Repeat("token ", 100)
	perEntry := EstimateTokens(content)

	rt := NewRestorationTracker().WithRetainedTokenBudget(2 * perEntry)
	rt.Track("/a.go", content, "read")
	rt.Track("/b.go", content, "read")
	rt.Track("/a.go", content, "write") // refresh /a.go recency; /b.go is now oldest
	rt.Track("/c.go", content, "read")  // over budget: evicts /b.go, not /a.go

	if rt.Len() != 2 {
		t.Fatalf("expected 2 entries after eviction, got %d", rt.Len())
	}
	paths := map[string]bool{}
	for _, e := range rt.Entries() {
		paths[e.Path] = true
	}
	if paths["/b.go"] {
		t.Error("/b.go was least recently tracked and should have been evicted")
	}
	if !paths["/a.go"] || !paths["/c.go"] {
		t.Errorf("expected /a.go and /c.go retained, got %v", paths)
	}
}

func TestRestorationTracker_RetainedBudgetKeepsSingleOversizeEntry(t *testing.T) {
	huge := strings.Repeat("big ", 10000) // far above any tiny budget
	rt := NewRestorationTracker().WithRetainedTokenBudget(10)
	rt.Track("/huge.go", huge, "write")

	if rt.Len() != 1 {
		t.Fatalf("most recent entry must be kept even when over budget, got %d", rt.Len())
	}
	entries := rt.Entries()
	if entries[0].Path != "/huge.go" || entries[0].Content != huge {
		t.Error("oversize entry should be retained verbatim")
	}
}

func TestRestorationTracker_WithRetainedTokenBudgetShrinksExisting(t *testing.T) {
	content := strings.Repeat("data ", 100)
	perEntry := EstimateTokens(content)

	rt := NewRestorationTracker()
	rt.Track("/a.go", content, "read")
	rt.Track("/b.go", content, "read")
	rt.Track("/c.go", content, "read")

	// Lowering the budget evicts immediately down to the new cap.
	rt.WithRetainedTokenBudget(2 * perEntry)
	if rt.Len() != 2 {
		t.Errorf("expected 2 entries after budget reduction, got %d", rt.Len())
	}
	for _, e := range rt.Entries() {
		if e.Path == "/a.go" {
			t.Error("oldest entry /a.go should have been evicted by budget reduction")
		}
	}
}
