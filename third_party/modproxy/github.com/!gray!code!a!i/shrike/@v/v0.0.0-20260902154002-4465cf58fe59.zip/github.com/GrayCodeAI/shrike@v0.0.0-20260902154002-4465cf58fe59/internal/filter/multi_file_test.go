package filter

import (
	"strings"
	"testing"
)

func TestNewMultiFileFilter(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	if f == nil {
		t.Fatal("NewMultiFileFilter returned nil")
	}
	if f.maxCombinedSize != 50000 {
		t.Errorf("expected default maxCombinedSize %d, got %d", 50000, f.maxCombinedSize)
	}
	if f.similarityThreshold != 0.8 {
		t.Errorf("expected default similarityThreshold %f, got %f", 0.8, f.similarityThreshold)
	}
}

func TestMultiFileFilterName(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	if f.Name() != "multi_file" {
		t.Errorf("expected name %q, got %q", "multi_file", f.Name())
	}
}

func TestMultiFileFilterSingleFile(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	input := "just a single file content"
	output, saved := f.Apply(input, ModeMinimal)
	if output != input {
		t.Errorf("expected unchanged output for single file, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for single file, got %d", saved)
	}
}

func TestMultiFileFilterParsesMultipleFiles(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{
		PreserveBoundaries: true,
	})
	input := `=== File: main.go ===
package main

func main() {}

=== File: utils.go ===
package main

func helper() {}`
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "main.go") {
		t.Error("expected file main.go to be preserved")
	}
	if !strings.Contains(output, "utils.go") {
		t.Error("expected file utils.go to be preserved")
	}
	if !strings.Contains(output, "func main") {
		t.Error("expected function content to be preserved")
	}
	if !strings.Contains(output, "func helper") {
		t.Error("expected helper function to be preserved")
	}
}

func TestMultiFileFilterParseFilesNoMarkers(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	files := f.parseFiles("no markers here\njust plain text")
	if len(files) != 1 {
		t.Errorf("expected 1 file for input without markers, got %d", len(files))
	}
	if files[0].name != "output" {
		t.Errorf("expected default name 'output', got %q", files[0].name)
	}
}

func TestMultiFileFilterExtractMetadata(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})

	file := &fileInfo{
		name: "test.go",
		content: `package main

import "fmt"

func main() {
	fmt.Println("hello")
}`,
	}
	f.extractMetadata(file)

	if len(file.imports) == 0 {
		t.Error("expected imports to be extracted")
	}
	if len(file.functions) == 0 {
		t.Error("expected functions to be extracted")
	}
}

func TestMultiFileFilterSameModule(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	if !f.sameModule("foo/bar/main.go", "foo/bar/utils.go") {
		t.Error("files in same directory should be same module")
	}
	if !f.sameModule("main.go", "utils.go") {
		t.Error("root files should be same module")
	}
	if f.sameModule("foo/main.go", "bar/utils.go") {
		t.Error("files in different directories should not be same module")
	}
}

func TestMultiFileFilterCalculateSimilarity(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})

	same := f.calculateSimilarity("hello world", "hello world")
	if same != 1.0 {
		t.Errorf("expected similarity 1.0 for identical strings, got %f", same)
	}

	different := f.calculateSimilarity("hello world", "completely different content")
	if different > 0 {
		t.Errorf("expected similarity 0 for very different strings, got %f", different)
	}
}

func TestMultiFileFilterHasImportRelation(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})

	file1 := fileInfo{
		name:    "main.go",
		imports: []string{"import \"fmt\"", "import \"./utils\""},
	}
	file2 := fileInfo{
		name:    "utils.go",
		content: "package main\nfunc helper() {}",
	}

	if !f.hasImportRelation(file1, file2) {
		t.Error("expected import relation between main.go and utils.go")
	}

	file3 := fileInfo{
		name:    "unrelated.go",
		content: "package main\nfunc something() {}",
	}

	if f.hasImportRelation(file1, file3) {
		t.Error("expected no import relation with unrelated file")
	}
}

func TestMultiFileFilterSetMaxCombinedSize(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	f.SetMaxCombinedSize(1000)
	if f.maxCombinedSize != 1000 {
		t.Errorf("expected maxCombinedSize %d, got %d", 1000, f.maxCombinedSize)
	}
}

func TestMultiFileFilterSetPreserveBoundaries(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	f.SetPreserveBoundaries(false)
	if f.preserveBoundaries {
		t.Error("expected preserveBoundaries to be false")
	}
}

func TestMultiFileFilterSetSimilarityThreshold(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	f.SetSimilarityThreshold(0.5)
	if f.similarityThreshold != 0.5 {
		t.Errorf("expected similarityThreshold %f, got %f", 0.5, f.similarityThreshold)
	}
}

func TestMultiFileFilterEmptyInput(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	output, saved := f.Apply("", ModeMinimal)
	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for empty input, got %d", saved)
	}
}

func TestMultiFileFilterFindSharedImports(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	files := []fileInfo{
		{name: "main.go", imports: []string{"import \"fmt\"", "import \"os\""}},
		{name: "utils.go", imports: []string{"import \"fmt\"", "import \"strings\""}},
	}

	shared := f.findSharedImports(files)
	if len(shared) == 0 {
		t.Error("expected shared imports to be found")
	}

	found := false
	for _, imp := range shared {
		if strings.ToLower(imp) == "import \"fmt\"" {
			found = true
			break
		}
	}
	if !found {
		t.Error("expected 'import \"fmt\"' to be in shared imports")
	}
}

func TestMultiFileFilterRemoveShared(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	items := []string{"import \"fmt\"", "import \"os\"", "import \"net/http\""}
	shared := []string{"import \"fmt\""}

	result := f.removeShared(items, shared)
	if len(result) != 2 {
		t.Errorf("expected 2 items after removal, got %d", len(result))
	}
	for _, item := range result {
		if strings.Contains(item, "fmt") {
			t.Error("shared import should have been removed")
		}
	}
}

func TestMultiFileFilterAggressiveModePreservesStructure(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{
		PreserveBoundaries: true,
	})
	input := `=== File: main.go ===
package main

func main() {
	fmt.Println("hello")
}

=== File: utils.go ===
package main

func helper() {
	return 42
}`
	output, _ := f.Apply(input, ModeAggressive)

	if !strings.Contains(output, "main.go") {
		t.Error("expected file boundaries to be preserved in aggressive mode")
	}
	if !strings.Contains(output, "utils.go") {
		t.Error("expected file boundaries to be preserved in aggressive mode")
	}
}

func TestMultiFileFilterCreateUnifiedOutput(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{
		PreserveBoundaries: true,
	})
	files := []deduplicatedFile{
		{name: "main.go", content: "package main\nfunc main() {}", imports: []string{}, exports: []string{}},
	}
	output := f.createUnifiedOutput(files, ModeMinimal)

	if !strings.Contains(output, "main.go") {
		t.Error("expected file marker in output")
	}
	if !strings.Contains(output, "func main()") {
		t.Error("expected content in output")
	}
}

func TestMultiFileFilterAnalyzeRelationships(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	files := []fileInfo{
		{name: "main.go", content: "package main\nfunc main() {}", imports: []string{}, exports: []string{}, functions: []string{"func main()"}},
		{name: "utils.go", content: "package main\nfunc helper() {}", imports: []string{}, exports: []string{}, functions: []string{"func helper()"}},
	}

	relations := f.analyzeRelationships(files)
	if len(relations) < 1 {
		t.Error("expected at least one relationship between files in same module")
	}
}

func TestMultiFileFilterDeduplicate(t *testing.T) {
	f := NewMultiFileFilter(MultiFileConfig{})
	files := []fileInfo{
		{name: "main.go", content: "unique content", imports: []string{}, exports: []string{}},
	}
	deduped := f.deduplicate(files, nil)
	if len(deduped) != 1 {
		t.Errorf("expected 1 file after dedup, got %d", len(deduped))
	}
}
