// Package tracking: platform-specific helpers.
package tracking

import "os"

// homeDir returns the user's home directory. Falls back to the
// current working directory if HOME is not set, so the tracker
// still works in unusual environments (CI, containers).
func homeDir() (string, error) {
	if h := os.Getenv("HOME"); h != "" {
		return h, nil
	}
	if h := os.Getenv("USERPROFILE"); h != "" { // Windows
		return h, nil
	}
	// Last-resort fallback: use the current directory.
	wd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	return wd, nil
}

// mkdirAll is a thin os.MkdirAll wrapper to keep the main file's
// import list tight.
func mkdirAll(path string, perm os.FileMode) error {
	return os.MkdirAll(path, perm)
}
