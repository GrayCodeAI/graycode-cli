package mcp

import (
	"context"
	"strings"
	"testing"

	shrike "github.com/GrayCodeAI/shrike"
)

func TestNewServer(t *testing.T) {
	s := NewServer("test")
	if s == nil {
		t.Fatal("NewServer returned nil")
	}
	if s.name != "test" {
		t.Fatalf("expected name %q, got %q", "test", s.name)
	}
	if s.tools == nil {
		t.Fatal("tools map is nil")
	}
}

func TestRegisterTool(t *testing.T) {
	s := NewServer("test")
	s.RegisterTool("echo", "echo tool", map[string]interface{}{"type": "object"},
		func(ctx context.Context, params map[string]interface{}) (interface{}, error) {
			return "ok", nil
		})

	if len(s.tools) != 1 {
		t.Fatalf("expected 1 tool, got %d", len(s.tools))
	}
	entry, ok := s.tools["echo"]
	if !ok {
		t.Fatal("tool echo not found")
	}
	if entry.def.Name != "echo" {
		t.Fatalf("expected tool name %q, got %q", "echo", entry.def.Name)
	}
	if entry.def.Description != "echo tool" {
		t.Fatalf("expected description %q, got %q", "echo tool", entry.def.Description)
	}
}

func TestListTools(t *testing.T) {
	s := NewServer("test")
	s.RegisterTool("a", "tool A", nil, nil)
	s.RegisterTool("b", "tool B", nil, nil)

	defs := s.ListTools()
	if len(defs) != 2 {
		t.Fatalf("expected 2 tools, got %d", len(defs))
	}
	names := map[string]bool{}
	for _, d := range defs {
		names[d.Name] = true
	}
	if !names["a"] || !names["b"] {
		t.Fatalf("expected tools a and b, got %v", defs)
	}
}

func TestHandleRequest_ListTools(t *testing.T) {
	s := NewServer("test")
	s.RegisterTool("alpha", "tool alpha", nil, nil)
	s.RegisterTool("beta", "tool beta", nil, nil)

	result, err := s.HandleRequest(context.Background(), "tools/list", nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	defs, ok := result.([]ToolDef)
	if !ok {
		t.Fatalf("expected []ToolDef, got %T", result)
	}
	if len(defs) != 2 {
		t.Fatalf("expected 2 tools, got %d", len(defs))
	}
}

func TestHandleRequest_ToolsCall(t *testing.T) {
	s := NewServer("test")
	s.RegisterTool("add", "add two numbers", nil,
		func(ctx context.Context, params map[string]interface{}) (interface{}, error) {
			a, _ := params["a"].(float64)
			b, _ := params["b"].(float64)
			return map[string]interface{}{"sum": a + b}, nil
		})

	result, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "add",
		"arguments": map[string]interface{}{
			"a": 2.0,
			"b": 3.0,
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	res, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map, got %T", result)
	}
	if res["sum"] != 5.0 {
		t.Fatalf("expected sum 5, got %v", res["sum"])
	}
}

func TestHandleRequest_UnknownMethod(t *testing.T) {
	s := NewServer("test")
	_, err := s.HandleRequest(context.Background(), "unknown/method", nil)
	if err == nil {
		t.Fatal("expected error for unknown method")
	}
	if err.Error() != `unsupported method "unknown/method"` {
		t.Fatalf("unexpected error message: %v", err)
	}
}

// NewTokServer is pre-loaded with real tool handlers that delegate to the shrike
// package. These tests exercise the wire-up so a future regression that
// reintroduces the legacy stub bodies (e.g. count_tokens=len/4,
// estimate_cost=0, compress_text=collapseWS) fails CI.

func TestNewTokServer_RegistersAllTools(t *testing.T) {
	s := NewTokServer()
	defs := s.ListTools()
	got := map[string]bool{}
	for _, d := range defs {
		got[d.Name] = true
	}
	for _, want := range []string{"count_tokens", "estimate_cost", "compress_text", "redact_secrets"} {
		if !got[want] {
			t.Errorf("expected registered tool %q in %v", want, got)
		}
	}
}

func TestNewTokServer_CountTokens_Heuristic(t *testing.T) {
	s := NewTokServer()
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "count_tokens",
		"arguments": map[string]interface{}{
			"text":  "hello world from shrike",
			"model": "heuristic",
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m, ok := res.(map[string]interface{})
	if !ok {
		t.Fatalf("expected map, got %T", res)
	}
	count, ok := m["count"].(int)
	if !ok {
		t.Fatalf("expected int count, got %T", m["count"])
	}
	if count != shrike.EstimateTokens("hello world from shrike") {
		t.Fatalf("heuristic count %d != EstimateTokens %d (stub regression?)",
			count, shrike.EstimateTokens("hello world from shrike"))
	}
	if count <= 0 {
		t.Fatalf("expected positive count, got %d", count)
	}
}

func TestNewTokServer_CountTokens_ForModel(t *testing.T) {
	s := NewTokServer()
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "count_tokens",
		"arguments": map[string]interface{}{
			"text":  "hello world",
			"model": "gpt-4o",
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	if m["model"] != "gpt-4o" {
		t.Fatalf("expected model gpt-4o, got %v", m["model"])
	}
	if _, ok := m["count"].(int); !ok {
		t.Fatalf("expected int count, got %T", m["count"])
	}
}

func TestNewTokServer_CountTokens_MissingText(t *testing.T) {
	s := NewTokServer()
	_, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name":      "count_tokens",
		"arguments": map[string]interface{}{"model": "gpt-4o"},
	})
	if err == nil {
		t.Fatal("expected error when text is missing")
	}
}

func TestNewTokServer_EstimateCost_KnownModel(t *testing.T) {
	s := NewTokServer()
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "estimate_cost",
		"arguments": map[string]interface{}{
			"model":        "gpt-4o",
			"inputTokens":  1000.0,
			"outputTokens": 500.0,
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	if m["known"] != true {
		t.Fatalf("expected known=true, got %v", m["known"])
	}
	cost, ok := m["totalCost"].(float64)
	if !ok {
		t.Fatalf("expected float64 totalCost, got %T", m["totalCost"])
	}
	pricing, _ := shrike.GetModelPricing("gpt-4o")
	want := (1000.0/1000)*pricing.InputPricePer1K + (500.0/1000)*pricing.OutputPricePer1K
	if cost != want {
		t.Fatalf("totalCost = %v, want %v (stub regression?)", cost, want)
	}
	if cost == 0 {
		t.Fatal("expected non-zero cost for gpt-4o, got 0 (legacy stub regression?)")
	}
}

func TestNewTokServer_EstimateCost_UnknownModel(t *testing.T) {
	s := NewTokServer()
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "estimate_cost",
		"arguments": map[string]interface{}{
			"model":        "totally-fake-model-xyz",
			"inputTokens":  100.0,
			"outputTokens": 200.0,
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	if m["known"] != false {
		t.Fatalf("expected known=false, got %v", m["known"])
	}
	if m["warning"] == nil {
		t.Fatal("expected warning for unknown model")
	}
}

func TestNewTokServer_CompressText_RealPipeline(t *testing.T) {
	s := NewTokServer()
	// Aggressive mode on repetitive natural-language prose will drop most
	// filler words. We don't assert specific content survives — we assert
	// the *real* pipeline ran, not the legacy stub (which either no-op'd
	// or only collapsed whitespace). The token-count and length
	// comparison is sufficient evidence.
	input := strings.Repeat(
		"The rain in spain stays mainly in the plain. ", 100,
	)
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "compress_text",
		"arguments": map[string]interface{}{
			"text": input,
			"mode": "aggressive",
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	compressed, _ := m["compressed"].(string)
	if compressed == "" {
		t.Fatal("expected non-empty compressed text")
	}
	if compressed == input {
		t.Fatal("compressed text equals input (stub regression: pipeline not invoked?)")
	}
	origTokens, _ := m["originalTokens"].(int)
	finalTokens, _ := m["finalTokens"].(int)
	if origTokens <= 0 || finalTokens <= 0 {
		t.Fatalf("expected positive token counts, got orig=%d final=%d", origTokens, finalTokens)
	}
	if finalTokens >= origTokens {
		t.Fatalf("aggressive compression should reduce tokens: orig=%d final=%d", origTokens, finalTokens)
	}
	// Stub regression guard: legacy compress_text only collapsed
	// whitespace, which would still drop *some* bytes but leave the
	// final token count close to the original. A 4× reduction is a
	// strong signal the 31-layer pipeline actually ran.
	if finalTokens*4 > origTokens {
		t.Fatalf("expected aggressive mode to reduce tokens by >= 4x, got orig=%d final=%d",
			origTokens, finalTokens)
	}
}

func TestNewTokServer_CompressText_RespectsBudget(t *testing.T) {
	s := NewTokServer()
	// Repetitive filler is exactly what aggressive mode is designed to
	// chew through, so this gives the budget a chance to clamp the result.
	input := strings.Repeat("lorem ipsum dolor sit amet consectetur. ", 200)
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name": "compress_text",
		"arguments": map[string]interface{}{
			"text":   input,
			"mode":   "aggressive",
			"budget": 50.0,
		},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	finalTokens, _ := m["finalTokens"].(int)
	if finalTokens > 60 {
		t.Fatalf("budget not respected: finalTokens=%d, want <= 60", finalTokens)
	}
}

func TestNewTokServer_RedactSecrets(t *testing.T) {
	s := NewTokServer()
	input := "config: AKIAIOSFODNN7EXAMPLE key=ghp_1234567890abcdefghijklmnopqrstuvwxyz"
	res, err := s.HandleRequest(context.Background(), "tools/call", map[string]interface{}{
		"name":      "redact_secrets",
		"arguments": map[string]interface{}{"text": input},
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	m := res.(map[string]interface{})
	redacted, _ := m["redacted"].(string)
	if redacted == input {
		t.Fatal("expected redacted text to differ from input (no secret detected?)")
	}
	if count, _ := m["matchCount"].(int); count < 2 {
		t.Fatalf("expected at least 2 secrets (AWS + GitHub), got %d", count)
	}
}

func TestNumberFromParams(t *testing.T) {
	cases := []struct {
		name   string
		input  map[string]interface{}
		key    string
		want   float64
		wantOK bool
	}{
		{"float64", map[string]interface{}{"x": 1.5}, "x", 1.5, true},
		{"float32", map[string]interface{}{"x": float32(1.5)}, "x", 1.5, true},
		{"int", map[string]interface{}{"x": int(7)}, "x", 7, true},
		{"int64", map[string]interface{}{"x": int64(8)}, "x", 8, true},
		{"missing", map[string]interface{}{}, "x", 0, false},
		{"wrong type", map[string]interface{}{"x": "1.5"}, "x", 0, false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, ok := numberFromParams(c.input, c.key)
			if ok != c.wantOK {
				t.Fatalf("ok=%v, want %v", ok, c.wantOK)
			}
			if ok && got != c.want {
				t.Fatalf("got %v, want %v", got, c.want)
			}
		})
	}
}
