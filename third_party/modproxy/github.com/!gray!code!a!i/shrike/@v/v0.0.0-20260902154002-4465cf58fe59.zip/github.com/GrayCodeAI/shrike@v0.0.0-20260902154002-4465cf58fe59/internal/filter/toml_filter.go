// Package filter: TOML-driven output filter.
//
// A TOML filter is a named text-processing pipeline that runs against
// command output before it enters the main compression layers. Each
// filter is defined as a TOML section with these stages:
//
// staticcheck:ignore SA1019 — toml.PrimitiveDecode is deprecated but has
// no direct replacement in the current go-toml API for this decode pattern.
//
//  1. match_command   - regex that selects this filter for a given command
//  2. strip_ansi      - bool, strip ANSI escape sequences
//  3. replace         - array of {pattern, replacement} regex pairs
//  4. match_output    - regex; if output matches, short-circuit
//     (used to detect trivial output like "no changes")
//  5. strip_lines     - array of regexes; drop lines matching any
//  6. keep_lines      - array of regexes; keep only lines matching any
//     (if non-empty)
//  7. truncate_lines  - int; cap individual line length
//  8. head_lines      - int; keep only the first N lines
//  9. tail_lines      - int; keep only the last N lines
//  10. max_lines       - int; cap the final line count (head+tail combined
//     style: keep first max/2 + last max/2 if exceeded)
//  11. on_empty        - default output when result is empty
//
// The stages run in the order listed above, with short-circuit semantics
// for match_output (if it matches, return the default immediately).
//
// GrayCode TOML filter schema. Superset
// of the existing shrike TOML filters (filters/*.toml) with the addition of
// replace / match_output / head_lines / tail_lines.
package filter

import (
	"bytes"
	"fmt"
	"os"
	"regexp"
	"sort"
	"strings"

	"github.com/BurntSushi/toml"

	"github.com/GrayCodeAI/shrike/internal/fastops"
)

// TOMLReplaceRule is a single regex-based find/replace rule.
type TOMLReplaceRule struct {
	Pattern     string `toml:"pattern"`
	Replacement string `toml:"replacement"`
	Compiled    *regexp.Regexp
	Literal     bool // if true, Pattern is treated as a literal string
}

// TOMLFilterConfig is the parsed definition of a single named filter.
//
// It corresponds to one [[name]] section in a TOML filter file.
type TOMLFilterConfig struct {
	// Name is the section name (e.g. "jest_run"). Auto-populated from
	// the section key when loaded via LoadTOMLFilterFile.
	Name string
	// MatchCommand is a regex matched against the command line.
	MatchCommand string `toml:"match_command"`
	// Stage 1: strip ANSI escape sequences.
	StripANSI bool `toml:"strip_ansi"`
	// Stage 2: regex find/replace pairs.
	Replace []TOMLReplaceRule `toml:"replace"`
	// Stage 3: short-circuit. If the output matches this regex, the
	// filter returns the default (or "" if no default) immediately.
	MatchOutput string `toml:"match_output"`
	// Stage 4: drop lines matching any of these regexes.
	StripLines []string `toml:"strip_lines_matching"`
	// Stage 5: keep only lines matching any of these regexes.
	// If empty, all lines (after strip_lines) are kept.
	KeepLines []string `toml:"keep_lines_matching"`
	// Stage 6: cap individual line length (chars). 0 = unlimited.
	TruncateLines int `toml:"truncate_lines"`
	// Stage 7: keep first N lines after all other transforms. 0 = unlimited.
	HeadLines int `toml:"head_lines"`
	// Stage 8: keep last N lines after all other transforms. 0 = unlimited.
	TailLines int `toml:"tail_lines"`
	// Stage 9: cap total line count. 0 = unlimited.
	// When triggered, output = first max/2 + last max/2 with a marker.
	MaxLines int `toml:"max_lines"`
	// Stage 10: default output when the result is empty.
	OnEmpty string `toml:"on_empty"`

	// Compiled regexes (populated by compile()).
	matchCommandRe *regexp.Regexp
	matchOutputRe  *regexp.Regexp
	stripLinesRes  []*regexp.Regexp
	keepLinesRes   []*regexp.Regexp
}

// TOMLFilterFile represents a single TOML filter file with multiple
// named filter definitions.
type TOMLFilterFile struct {
	Path    string
	Schema  int                          `toml:"schema_version"`
	Filters map[string]*TOMLFilterConfig // section name -> filter
}

// LoadTOMLFilterFile parses a TOML filter file.
func LoadTOMLFilterFile(path string) (*TOMLFilterFile, error) {
	f := &TOMLFilterFile{
		Path:    path,
		Filters: make(map[string]*TOMLFilterConfig),
	}
	// The TOML file has unnamed top-level sections (e.g. [jest_run]).
	// We need to detect them dynamically. Use a generic map first.
	var raw map[string]toml.Primitive
	if _, err := toml.DecodeFile(path, &raw); err != nil {
		return nil, fmt.Errorf("toml_filter: decode %s: %w", path, err)
	}
	if v, ok := raw["schema_version"]; ok {
		//nolint:staticcheck // SA1019: PrimitiveDecode deprecated but needed for this decode flow
		//lint:ignore SA1019 PrimitiveDecode is deprecated but MetaData.PrimitiveDecode requires a different decode flow
		_ = toml.PrimitiveDecode(v, &f.Schema)
		delete(raw, "schema_version")
	}
	for name, prim := range raw {
		cfg := &TOMLFilterConfig{Name: name}
		//nolint:staticcheck // SA1019: PrimitiveDecode deprecated but needed for this decode flow
		//lint:ignore SA1019 PrimitiveDecode is deprecated but MetaData.PrimitiveDecode requires a different decode flow
		if err := toml.PrimitiveDecode(prim, cfg); err != nil {
			return nil, fmt.Errorf("toml_filter: decode section [%s] in %s: %w", name, path, err)
		}
		if err := cfg.compile(); err != nil {
			return nil, fmt.Errorf("toml_filter: compile section [%s] in %s: %w", name, path, err)
		}
		f.Filters[name] = cfg
	}
	return f, nil
}

// LoadTOMLFilterDir loads all *.toml files from dir and returns a flat
// list of all filter configs found across all files.
func LoadTOMLFilterDir(dir string) ([]*TOMLFilterConfig, error) {
	// Use a small inline glob to avoid importing path/filepath
	// unnecessarily in the package init.
	entries, err := readDir(dir)
	if err != nil {
		return nil, err
	}
	var out []*TOMLFilterConfig
	for _, e := range entries {
		if !strings.HasSuffix(e, ".toml") {
			continue
		}
		path := dir + "/" + e
		f, err := LoadTOMLFilterFile(path)
		if err != nil {
			return nil, err
		}
		for _, cfg := range f.Filters {
			out = append(out, cfg)
		}
	}
	return out, nil
}

// compile pre-compiles all regex fields. Called automatically by
// LoadTOMLFilterFile; callers that construct TOMLFilterConfig directly
// must call it before Apply.
func (c *TOMLFilterConfig) compile() error {
	var err error
	if c.MatchCommand != "" {
		if c.matchCommandRe, err = regexp.Compile(c.MatchCommand); err != nil {
			return fmt.Errorf("match_command %q: %w", c.MatchCommand, err)
		}
	}
	if c.MatchOutput != "" {
		if c.matchOutputRe, err = regexp.Compile(c.MatchOutput); err != nil {
			return fmt.Errorf("match_output %q: %w", c.MatchOutput, err)
		}
	}
	for i, p := range c.StripLines {
		re, err := regexp.Compile(p)
		if err != nil {
			return fmt.Errorf("strip_lines[%d] %q: %w", i, p, err)
		}
		c.stripLinesRes = append(c.stripLinesRes, re)
	}
	for i, p := range c.KeepLines {
		re, err := regexp.Compile(p)
		if err != nil {
			return fmt.Errorf("keep_lines[%d] %q: %w", i, p, err)
		}
		c.keepLinesRes = append(c.keepLinesRes, re)
	}
	for i := range c.Replace {
		rule := &c.Replace[i]
		if rule.Literal {
			continue
		}
		re, err := regexp.Compile(rule.Pattern)
		if err != nil {
			return fmt.Errorf("replace[%d].pattern %q: %w", i, rule.Pattern, err)
		}
		rule.Compiled = re
	}
	return nil
}

// Match reports whether the given command line matches this filter's
// MatchCommand regex. Always returns true if no MatchCommand is set.
func (c *TOMLFilterConfig) Match(command string) bool {
	if c == nil || c.matchCommandRe == nil {
		return true
	}
	return c.matchCommandRe.MatchString(command)
}

// TOMLFilter is a Filter implementation that wraps a single
// TOMLFilterConfig. The Name() method returns the section name.
type TOMLFilter struct {
	config *TOMLFilterConfig
}

// NewTOMLFilter creates a new TOMLFilter wrapping the given config.
func NewTOMLFilter(cfg *TOMLFilterConfig) *TOMLFilter {
	return &TOMLFilter{config: cfg}
}

// Name returns the filter's section name.
func (f *TOMLFilter) Name() string {
	if f.config == nil {
		return "toml_filter"
	}
	return f.config.Name
}

// Apply runs the 8-stage pipeline on input. Returns the filtered
// output and an estimate of tokens saved.
func (f *TOMLFilter) Apply(input string, _ Mode) (string, int) {
	if f.config == nil {
		return input, 0
	}
	originalTokens := estimateTOMLFilterTokens(input)
	out := input

	// Stage 1: strip ANSI
	if f.config.StripANSI {
		out = fastops.StripANSI(out)
	}

	// Stage 2: regex replacements
	for i := range f.config.Replace {
		rule := &f.config.Replace[i]
		if rule.Literal {
			out = strings.ReplaceAll(out, rule.Pattern, rule.Replacement)
		} else if rule.Compiled != nil {
			out = rule.Compiled.ReplaceAllString(out, rule.Replacement)
		}
	}

	// Stage 3: short-circuit
	if f.config.matchOutputRe != nil && f.config.matchOutputRe.MatchString(out) {
		// Output matches a "trivial" pattern; return the default.
		return f.config.OnEmpty, originalTokens
	}

	// Stage 4 + 5: strip and keep lines
	out = applyLineFilters(out, f.config.stripLinesRes, f.config.keepLinesRes)

	// Stage 6: truncate individual line length
	if f.config.TruncateLines > 0 {
		out = truncateLineLength(out, f.config.TruncateLines)
	}

	// Stage 7 + 8: head / tail
	if f.config.HeadLines > 0 || f.config.TailLines > 0 {
		out = applyHeadTail(out, f.config.HeadLines, f.config.TailLines)
	}

	// Stage 9: max_lines
	if f.config.MaxLines > 0 {
		out = applyMaxLines(out, f.config.MaxLines)
	}

	// Stage 10: on_empty default
	if strings.TrimSpace(out) == "" && f.config.OnEmpty != "" {
		out = f.config.OnEmpty
	}

	saved := originalTokens - estimateTOMLFilterTokens(out)
	if saved < 0 {
		saved = 0
	}
	return out, saved
}

// applyLineFilters removes lines matching any strip regex, then keeps
// only lines matching any keep regex (if keep is non-empty).
func applyLineFilters(s string, strip, keep []*regexp.Regexp) string {
	lines := strings.Split(s, "\n")
	// Strip pass
	if len(strip) > 0 {
		var kept []string
		for _, line := range lines {
			drop := false
			for _, re := range strip {
				if re.MatchString(line) {
					drop = true
					break
				}
			}
			if !drop {
				kept = append(kept, line)
			}
		}
		lines = kept
	}
	// Keep pass
	if len(keep) > 0 {
		var kept []string
		for _, line := range lines {
			for _, re := range keep {
				if re.MatchString(line) {
					kept = append(kept, line)
					break
				}
			}
		}
		lines = kept
	}
	return strings.Join(lines, "\n")
}

// truncateLineLength caps each individual line to max chars.
func truncateLineLength(s string, max int) string {
	lines := strings.Split(s, "\n")
	for i, line := range lines {
		if len(line) > max {
			lines[i] = line[:max] + "..."
		}
	}
	return strings.Join(lines, "\n")
}

// applyHeadTail keeps the first headLines and last tailLines lines.
// If both are 0, returns s unchanged. The behavior is:
//
//   - head only: keep first headLines
//   - tail only: keep last tailLines
//   - both: keep first headLines and last tailLines (concatenated,
//     with a marker between them if both are set and the original was
//     longer than headLines + tailLines)
func applyHeadTail(s string, headLines, tailLines int) string {
	lines := strings.Split(s, "\n")
	if headLines <= 0 && tailLines <= 0 {
		return s
	}
	if headLines > 0 && tailLines <= 0 {
		if headLines < len(lines) {
			return strings.Join(lines[:headLines], "\n")
		}
		return s
	}
	if headLines <= 0 && tailLines > 0 {
		if tailLines < len(lines) {
			return strings.Join(lines[len(lines)-tailLines:], "\n")
		}
		return s
	}
	// Both set
	if headLines+tailLines >= len(lines) {
		return s
	}
	head := lines[:headLines]
	tail := lines[len(lines)-tailLines:]
	dropped := len(lines) - headLines - tailLines
	marker := fmt.Sprintf("// ... (%d lines omitted) ...", dropped)
	combined := make([]string, 0, len(head)+len(tail)+1)
	combined = append(combined, head...)
	combined = append(combined, marker)
	combined = append(combined, tail...)
	return strings.Join(combined, "\n")
}

// applyMaxLines caps total line count. When exceeded, keeps first
// maxLines/2 + last maxLines/2 with a marker between them.
func applyMaxLines(s string, maxLines int) string {
	lines := strings.Split(s, "\n")
	if len(lines) <= maxLines {
		return s
	}
	half := maxLines / 2
	if half < 1 {
		half = 1
	}
	dropped := len(lines) - 2*half
	if dropped < 0 {
		dropped = 0
	}
	var b bytes.Buffer
	for i := 0; i < half; i++ {
		b.WriteString(lines[i])
		b.WriteByte('\n')
	}
	fmt.Fprintf(&b, "// ... (%d lines omitted) ...", dropped)
	b.WriteByte('\n')
	for i := len(lines) - half; i < len(lines); i++ {
		b.WriteString(lines[i])
		if i < len(lines)-1 {
			b.WriteByte('\n')
		}
	}
	return b.String()
}

// estimateTOMLFilterTokens returns a rough token count for s using
// bytes/4 as a heuristic. This is sufficient for "tokens saved" in
// the Filter.Apply return value — the pipeline will refine the count
// later via the full BPE tokenizer.
func estimateTOMLFilterTokens(s string) int {
	return (len(s) + 3) / 4
}

// readDir is a thin os.ReadDir wrapper to keep this file's imports
// minimal. Returns only the names (sorted lexicographically).
func readDir(dir string) ([]string, error) {
	entries, err := readDirEntries(dir)
	if err != nil {
		return nil, err
	}
	names := make([]string, 0, len(entries))
	names = append(names, entries...)
	return names, nil
}

// readDirEntries wraps os.ReadDir in this file so the test file does
// not need to import os directly.
func readDirEntries(dir string) ([]string, error) {
	f, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	names := make([]string, 0, len(f))
	for _, e := range f {
		if !e.IsDir() {
			names = append(names, e.Name())
		}
	}
	sort.Strings(names)
	return names, nil
}

// (No placeholder needed; all imports are referenced.)
