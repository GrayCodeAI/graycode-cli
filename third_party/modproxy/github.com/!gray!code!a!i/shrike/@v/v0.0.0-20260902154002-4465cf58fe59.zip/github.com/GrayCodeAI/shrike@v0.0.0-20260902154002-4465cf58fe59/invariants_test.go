package shrike

import (
	"encoding/json"
	"strconv"
	"strings"
	"testing"
)

func jsonArr(t *testing.T, items ...string) string {
	t.Helper()
	return "[" + strings.Join(items, ",") + "]"
}

func TestJSONInvariants_ConstantField(t *testing.T) {
	dropped := []json.RawMessage{
		json.RawMessage(`{"status":"charged","amount":5.00}`),
		json.RawMessage(`{"status":"charged","amount":12.50}`),
		json.RawMessage(`{"status":"charged","amount":199.99}`),
	}
	got := JSONInvariants(dropped)
	if !strings.Contains(got, "status=charged×3") {
		t.Fatalf("constant fact missing: %q", got)
	}
	if !strings.Contains(got, "range amount=5..199.99") {
		t.Fatalf("range fact missing: %q", got)
	}
}

func TestJSONInvariants_EnumerationSumsToTotal(t *testing.T) {
	dropped := []json.RawMessage{
		json.RawMessage(`{"id":"ord-1000","state":"shipped"}`),
		json.RawMessage(`{"id":"ord-1001","state":"shipped"}`),
		json.RawMessage(`{"id":"ord-1002","state":"shipped"}`),
		json.RawMessage(`{"id":"ord-1003","state":"processing"}`),
		json.RawMessage(`{"id":"ord-1004","state":"processing"}`),
		json.RawMessage(`{"id":"ord-1005","state":"pending"}`),
	}
	got := JSONInvariants(dropped)
	if !strings.Contains(got, "state: pending×1 processing×2 shipped×3") {
		t.Fatalf("enumeration wrong: %q", got)
	}
	// id is unique per record and densely numbered → dense coverage form
	if !strings.Contains(got, "id: ord-1000..ord-1005 all 6 present") {
		t.Fatalf("coverage missing: %q", got)
	}
}

func TestJSONInvariants_DenseRunUpgrade(t *testing.T) {
	var dropped []json.RawMessage
	for i := 5000; i < 5009; i++ {
		dropped = append(dropped, json.RawMessage(`{"wh":"wh-`+strconv.Itoa(i)+`"}`))
	}
	got := JSONInvariants(dropped)
	if !strings.Contains(got, "all 9 present") {
		t.Fatalf("dense coverage missing: %q", got)
	}
}

func TestJSONInvariants_WithholdsSensitiveAndNoisy(t *testing.T) {
	dropped := []json.RawMessage{
		json.RawMessage(`{"api_key":"abc123","note":"hello world with spaces"}`),
		json.RawMessage(`{"api_key":"def456","note":"another free text value"}`),
		json.RawMessage(`{"api_key":"ghi789","note":"yet another long note"}`),
	}
	got := JSONInvariants(dropped)
	if strings.Contains(got, "api_key") || strings.Contains(got, "note") {
		t.Fatalf("sensitive/noisy fields leaked: %q", got)
	}
}

func TestJSONInvariants_TooFewUnitsSkipped(t *testing.T) {
	dropped := []json.RawMessage{
		json.RawMessage(`{"status":"ok"}`),
		json.RawMessage(`{"status":"ok"}`),
	}
	if got := JSONInvariants(dropped); got != "" {
		t.Fatalf("expected empty for <3 units, got %q", got)
	}
}

func TestJSONInvariants_NonObjectsYieldNothing(t *testing.T) {
	dropped := []json.RawMessage{
		json.RawMessage(`"plain"`),
		json.RawMessage(`42`),
		json.RawMessage(`null`),
	}
	if got := JSONInvariants(dropped); got != "" {
		t.Fatalf("scalars must not produce facts: %q", got)
	}
}

func TestCompressJSON_SentinelKeepsArrayValidAndStatesFacts(t *testing.T) {
	var items []string
	for i := 1000; i < 1040; i++ {
		items = append(items, `{"order_id":"ord-`+strconv.Itoa(i)+`","status":"fulfilled"}`)
	}
	out := CompressJSON(jsonArr(t, items...), 10)

	var result []map[string]json.RawMessage
	if err := json.Unmarshal([]byte(out), &result); err != nil {
		t.Fatalf("output not valid JSON array of objects: %v", err)
	}
	found := false
	for _, m := range result {
		if _, ok := m["_tok_elided"]; ok {
			found = true
			break
		}
	}
	if !found {
		t.Fatal("sentinel missing")
	}
	if !strings.Contains(out, `"status=fulfilled×`) && !strings.Contains(out, "distinct") {
		t.Fatalf("no verified facts in sentinel: %s", out)
	}
}

func TestLogInvariants_LevelDistribution(t *testing.T) {
	lines := []string{
		"2026-08-22T10:00:00Z INFO request served",
		"2026-08-22T10:00:01Z INFO request served",
		"2026-08-22T10:00:02Z DEBUG cache warm",
		"2026-08-22T10:00:03Z INFO request served",
		"2026-08-22T10:00:04Z DEBUG cache warm",
	}
	got := LogInvariants(lines)
	if !strings.Contains(got, "debug×2") || !strings.Contains(got, "info×3") {
		t.Fatalf("level distribution wrong: %q", got)
	}
}

func TestCompressLog_MarkerCarriesInvariants(t *testing.T) {
	lines := make([]string, 0, 8)
	lines = append(lines, "2026-08-22T10:00:00Z INFO start")
	for i := 0; i < 5; i++ {
		lines = append(lines, "2026-08-22T10:00:0"+strconv.Itoa(i+1)+"Z INFO tick "+strconv.Itoa(i))
	}
	lines = append(lines, "2026-08-22T10:00:06Z INFO end")
	out := CompressLog(strings.Join(lines, "\n"))
	if !strings.Contains(out, "collapsed") || !strings.Contains(out, "info×") {
		t.Fatalf("marker lacks invariants: %q", out)
	}
}
