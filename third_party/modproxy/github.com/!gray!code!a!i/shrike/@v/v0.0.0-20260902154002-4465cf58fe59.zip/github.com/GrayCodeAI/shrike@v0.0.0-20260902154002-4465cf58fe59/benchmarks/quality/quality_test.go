package quality

import (
	"strings"
	"testing"
)

func TestRouge1Recall(t *testing.T) {
	tests := []struct {
		name       string
		original   string
		compressed string
		wantMin    float64
		wantMax    float64
	}{
		{
			name:       "identical text is fully faithful",
			original:   "deploy the frankfurt data center next quarter",
			compressed: "deploy the frankfurt data center next quarter",
			wantMin:    1.0,
			wantMax:    1.0,
		},
		{
			name:       "empty original treated as faithful",
			original:   "",
			compressed: "anything",
			wantMin:    1.0,
			wantMax:    1.0,
		},
		{
			name:       "dropping stopwords does not reduce fidelity",
			original:   "the report is on the table and it was good",
			compressed: "report table good",
			wantMin:    1.0,
			wantMax:    1.0,
		},
		{
			name:       "dropping half the key terms gives partial recall",
			original:   "alpha beta gamma delta",
			compressed: "alpha beta",
			wantMin:    0.49,
			wantMax:    0.51,
		},
		{
			name:       "unrelated compression retains nothing",
			original:   "frankfurt revenue margin",
			compressed: "xyzzy plugh",
			wantMin:    0.0,
			wantMax:    0.0,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got := Rouge1Recall(tc.original, tc.compressed)
			if got < tc.wantMin || got > tc.wantMax {
				t.Fatalf("Rouge1Recall = %.3f, want in [%.3f, %.3f]", got, tc.wantMin, tc.wantMax)
			}
		})
	}
}

// TestHarnessEndToEnd runs the full pipeline (evaluate + summarize) on a small
// set of samples and asserts the invariants every run must satisfy. It is fully
// offline.
func TestHarnessEndToEnd(t *testing.T) {
	samples := []Sample{
		{ID: "git-status", Category: "vcs", Prompt: "git status\nOn branch main\nnothing to commit, working tree clean\n"},
		{ID: "lb-summ", Category: "longbench-summ", Prompt: LongBenchSamples()[2].Prompt},
		{ID: "kubectl", Category: "k8s", Prompt: "kubectl get pods -A\nNAMESPACE NAME READY STATUS RESTARTS AGE\nkube-system coredns 1/1 Running 0 5d\n"},
	}
	tiers := DefaultTiers()

	results := Evaluate(samples, tiers)
	if want := len(samples) * len(tiers); len(results) != want {
		t.Fatalf("got %d results, want %d", len(results), want)
	}

	for _, r := range results {
		if r.Ratio < 0 || r.Ratio > 1.5 {
			t.Errorf("%s/%s: ratio %.3f out of sane range", r.SampleID, r.Tier, r.Ratio)
		}
		if r.Fidelity < 0 || r.Fidelity > 1.0 {
			t.Errorf("%s/%s: fidelity %.3f out of [0,1]", r.SampleID, r.Tier, r.Fidelity)
		}
		if r.Tier == "baseline (no-op)" {
			if r.Ratio != 1.0 {
				t.Errorf("%s baseline ratio = %.3f, want 1.0", r.SampleID, r.Ratio)
			}
			if r.Fidelity != 1.0 {
				t.Errorf("%s baseline fidelity = %.3f, want 1.0", r.SampleID, r.Fidelity)
			}
		}
	}

	summaries := Summarize(results, tiers)
	if len(summaries) != len(tiers) {
		t.Fatalf("got %d summaries, want %d", len(summaries), len(tiers))
	}
	// Tier ordering must be preserved with baseline first.
	if summaries[0].Tier != "baseline (no-op)" {
		t.Errorf("first summary tier = %q, want baseline (no-op)", summaries[0].Tier)
	}

	// An aggressive shrike tier should compress more than the no-op baseline.
	var baseRatio, extractRatio float64
	for _, s := range summaries {
		switch s.Tier {
		case "baseline (no-op)":
			baseRatio = s.AvgRatio
		case "extract":
			extractRatio = s.AvgRatio
		}
	}
	if extractRatio >= baseRatio {
		t.Errorf("extract avg ratio %.3f not below baseline %.3f", extractRatio, baseRatio)
	}
}

func TestWriteMarkdownAndCSV(t *testing.T) {
	samples := []Sample{
		{ID: "git-status", Category: "vcs", Prompt: "git status\nOn branch main\n"},
		{ID: "go-test", Category: "testing", Prompt: "go test ./... -v -count=1\nok github.com/x 0.1s\n"},
	}
	tiers := DefaultTiers()
	results := Evaluate(samples, tiers)
	summaries := Summarize(results, tiers)

	var md strings.Builder
	if err := WriteMarkdown(&md, summaries, results); err != nil {
		t.Fatalf("WriteMarkdown: %v", err)
	}
	for _, want := range []string{
		"# shrike Compression-Quality Benchmark",
		"baseline (no-op)",
		"## Per-Tier Summary",
		"## Per-Sample Detail",
		"git-status",
	} {
		if !strings.Contains(md.String(), want) {
			t.Errorf("markdown missing %q", want)
		}
	}

	var csv strings.Builder
	if err := WriteCSV(&csv, results); err != nil {
		t.Fatalf("WriteCSV: %v", err)
	}
	head := "sample,tier,in_tokens,out_tokens,ratio,char_retention,fidelity"
	if !strings.HasPrefix(csv.String(), head) {
		t.Errorf("csv header = %q, want prefix %q", csv.String()[:len(head)], head)
	}
	// Tier names contain commas-free text but the field is quoted defensively;
	// ensure the baseline arm round-trips.
	if !strings.Contains(csv.String(), "baseline (no-op)") {
		t.Errorf("csv missing baseline arm")
	}
}

func TestLoadSamples(t *testing.T) {
	// The shared benchmarks/samples.json lives one directory up.
	samples, err := LoadSamples("../samples.json")
	if err != nil {
		t.Fatalf("LoadSamples: %v", err)
	}
	if len(samples) == 0 {
		t.Fatal("expected non-empty samples from benchmarks/samples.json")
	}
	if samples[0].ID == "" || samples[0].Prompt == "" {
		t.Errorf("first sample malformed: %+v", samples[0])
	}
}
