package shrike

import (
	"fmt"
	"sort"
	"strings"
	"sync"
)

// ModelPricing holds per-token pricing for a model.
type ModelPricing struct {
	InputPricePer1K  float64 // Cost per 1K input tokens in USD
	OutputPricePer1K float64 // Cost per 1K output tokens in USD
}

// modelPricingRegistry provides pricing for popular models.
// Use RegisterModelPricing to add or override entries at runtime.
var modelPricingRegistry = map[string]ModelPricing{
	// OpenAI
	"gpt-4o": {
		InputPricePer1K:  0.0025,
		OutputPricePer1K: 0.01,
	},
	"gpt-4o-mini": {
		InputPricePer1K:  0.00015,
		OutputPricePer1K: 0.0006,
	},
	"gpt-4-turbo": {
		InputPricePer1K:  0.01,
		OutputPricePer1K: 0.03,
	},
	"gpt-4": {
		InputPricePer1K:  0.03,
		OutputPricePer1K: 0.06,
	},
	"gpt-3.5-turbo": {
		InputPricePer1K:  0.0005,
		OutputPricePer1K: 0.0015,
	},

	// Anthropic
	"claude-opus": {
		InputPricePer1K:  0.015,
		OutputPricePer1K: 0.075,
	},
	"claude-sonnet": {
		InputPricePer1K:  0.003,
		OutputPricePer1K: 0.015,
	},
	"claude-haiku": {
		InputPricePer1K:  0.00025,
		OutputPricePer1K: 0.00125,
	},

	// Google
	"gemini-pro": {
		InputPricePer1K:  0.00025,
		OutputPricePer1K: 0.0005,
	},
	"gemini-ultra": {
		InputPricePer1K:  0.007,
		OutputPricePer1K: 0.021,
	},

	// DeepSeek
	"deepseek-v2": {
		InputPricePer1K:  0.00014,
		OutputPricePer1K: 0.00028,
	},
	"deepseek-coder": {
		InputPricePer1K:  0.00014,
		OutputPricePer1K: 0.00028,
	},

	// Mistral
	"mistral-large": {
		InputPricePer1K:  0.004,
		OutputPricePer1K: 0.012,
	},
	"mistral-medium": {
		InputPricePer1K:  0.0027,
		OutputPricePer1K: 0.0081,
	},

	// Meta
	"llama-3-70b": {
		InputPricePer1K:  0.0008,
		OutputPricePer1K: 0.0008,
	},
	"llama-3-8b": {
		InputPricePer1K:  0.0002,
		OutputPricePer1K: 0.0002,
	},
}

var pricingMu sync.RWMutex

// RegisterModelPricing adds or overwrites pricing for a model at runtime.
// This allows users and plugins to keep pricing current without code changes.
func RegisterModelPricing(model string, inputPricePer1K, outputPricePer1K float64) {
	model = strings.ToLower(strings.TrimSpace(model))
	pricingMu.Lock()
	defer pricingMu.Unlock()
	modelPricingRegistry[model] = ModelPricing{
		InputPricePer1K:  inputPricePer1K,
		OutputPricePer1K: outputPricePer1K,
	}
}

// GetModelPricing returns the pricing for a model.
// Returns the pricing and true if found, or zero pricing and false if unknown.
func GetModelPricing(model string) (ModelPricing, bool) {
	model = strings.ToLower(strings.TrimSpace(model))
	pricingMu.RLock()
	defer pricingMu.RUnlock()
	p, ok := modelPricingRegistry[model]
	return p, ok
}

// EstimateCostSavings estimates the dollar savings from compression based on model pricing.
// It assumes saved tokens are input tokens (conservative estimate).
// Returns 0 if the model is unknown.
func EstimateCostSavings(stats Stats, model string) float64 {
	pricing, ok := GetModelPricing(model)
	if !ok {
		return 0
	}

	// Assume saved tokens would have been input tokens
	return float64(stats.TokensSaved) / 1000 * pricing.InputPricePer1K
}

// EstimateCost estimates the USD cost of processing text with a model,
// counting the text as input tokens. It is a convenience wrapper around
// EstimateTokensForModel and GetModelPricing.
//
// Returns 0 if the model is unknown (no pricing registered).
func EstimateCost(text string, model string) float64 {
	pricing, ok := GetModelPricing(model)
	if !ok {
		return 0
	}
	tokens := EstimateTokensForModel(text, model)
	return float64(tokens) / 1000 * pricing.InputPricePer1K
}

// FormatCostSavings returns a human-readable cost savings string.
// Returns "$X.XX saved" if the model is known, or empty string if unknown.
func FormatCostSavings(stats Stats, model string) string {
	savings := EstimateCostSavings(stats, model)
	if savings <= 0 {
		return ""
	}

	if savings < 0.01 {
		return fmt.Sprintf("$%.4f saved", savings)
	}
	return fmt.Sprintf("$%.2f saved", savings)
}

// ListModels returns a sorted list of all known model names.
func ListModels() []string {
	pricingMu.RLock()
	defer pricingMu.RUnlock()

	models := make([]string, 0, len(modelPricingRegistry))
	for name := range modelPricingRegistry {
		models = append(models, name)
	}
	sort.Strings(models)
	return models
}
