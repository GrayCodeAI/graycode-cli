//go:build amd64

package fastops

//go:noescape
func hasANSIavx2(data string) bool

//go:noescape
func countBytesAVX2(data string, target byte) int
