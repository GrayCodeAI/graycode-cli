# Shrike Benchmark Publication Workflow

This directory is the publication surface for Shrike benchmarks.

It complements:

- `shrike/benchmarks/run.sh` for the offline quality and root-package benchmark wrapper
- `shrike/evals/pipeline-bench.sh` for pipeline latency and allocation benchmarks
- `shrike/benchmarks/quality/` for the offline compression-quality harness
- `shrike/benchmarks/manifests/` for machine-readable suite definitions

## Official suite ids

- `shrike-quality-core`
- `shrike-pipeline-microbench`

See the Hawk-side benchmark registry at `hawk/docs/benchmarks/SUITES.md`.

## Current published baselines

- `shrike-quality-core`: `results/shrike-quality-core/2026-06-27/`
- `shrike-pipeline-microbench`: `results/shrike-pipeline-microbench/2026-06-27/`

## Current runnable commands

```bash
/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./benchmarks/run.sh'
/bin/zsh -lc 'GOCACHE=$PWD/.gocache ./evals/pipeline-bench.sh'
```

## Publication layout

Recommended committed layout:

```text
benchmarks/
  README.md
  manifests/
    shrike-quality-core.yaml
    shrike-pipeline-microbench.yaml
  results/
    shrike-quality-core/
      2026-06-27/
        report.md
        result.txt
        notes.md
    shrike-pipeline-microbench/
      2026-06-27/
        report.md
        result.txt
        notes.md
```

## Promotion rule

Do not cite a Shrike benchmark as evidence in cross-project comparison docs unless:

1. the command used is recorded
2. the repo state is identified as a committed snapshot or workspace snapshot
3. the benchmark scope is stated clearly
4. the raw output or generated report is committed
