package core

import (
	"errors"
	"strings"
	"testing"
)

var errMockFailure = errors.New("mock failure")

func TestNewBatchProcessorDefaults(t *testing.T) {
	bp := NewBatchProcessor(nil, 0)
	if bp == nil {
		t.Fatal("NewBatchProcessor returned nil")
	}
	if bp.workers <= 0 {
		t.Error("expected positive worker count")
	}
}

func TestNewBatchProcessorCustomWorkers(t *testing.T) {
	bp := NewBatchProcessor(nil, 4)
	if bp.workers != 4 {
		t.Errorf("expected 4 workers, got %d", bp.workers)
	}
}

func TestNewBatchProcessorCapsWorkers(t *testing.T) {
	bp := NewBatchProcessor(nil, 9999)
	if bp.workers > 0 && bp.workers == 9999 {
		t.Error("expected workers to be capped")
	}
}

type mockProcessor struct{}

func (m *mockProcessor) Process(input string) (string, interface{}, error) {
	return strings.ToUpper(input), nil, nil
}

type failProcessor struct{}

func (f *failProcessor) Process(input string) (string, interface{}, error) {
	return "", nil, errMockFailure
}

func TestProcessBatch(t *testing.T) {
	bp := NewBatchProcessor(&mockProcessor{}, 2)
	inputs := []string{"hello", "world", "foo", "bar"}
	results := bp.ProcessBatch(inputs)

	if len(results) != len(inputs) {
		t.Fatalf("expected %d results, got %d", len(inputs), len(results))
	}

	for i, result := range results {
		if result.Error != nil {
			t.Errorf("result[%d] had error: %v", i, result.Error)
		}
		if result.Output != strings.ToUpper(inputs[i]) {
			t.Errorf("result[%d].Output = %q, want %q", i, result.Output, strings.ToUpper(inputs[i]))
		}
		if result.Index != i {
			t.Errorf("result[%d].Index = %d, want %d", i, result.Index, i)
		}
	}
}

func TestProcessBatchSingleInput(t *testing.T) {
	bp := NewBatchProcessor(&mockProcessor{}, 1)
	results := bp.ProcessBatch([]string{"single"})
	if len(results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(results))
	}
	if results[0].Output != "SINGLE" {
		t.Errorf("expected 'SINGLE', got %q", results[0].Output)
	}
}

func TestProcessBatchEmptyInputs(t *testing.T) {
	bp := NewBatchProcessor(&mockProcessor{}, 2)
	results := bp.ProcessBatch([]string{})
	if len(results) != 0 {
		t.Errorf("expected 0 results for empty input, got %d", len(results))
	}
}

func TestProcessBatchError(t *testing.T) {
	bp := NewBatchProcessor(&failProcessor{}, 2)
	results := bp.ProcessBatch([]string{"test"})
	if len(results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(results))
	}
	if results[0].Error != errMockFailure {
		t.Errorf("expected mock failure error, got %v", results[0].Error)
	}
}
