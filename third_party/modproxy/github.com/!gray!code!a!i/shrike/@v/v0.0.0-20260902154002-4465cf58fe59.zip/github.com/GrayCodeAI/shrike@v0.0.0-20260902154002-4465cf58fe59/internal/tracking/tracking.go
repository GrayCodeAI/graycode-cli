// Package tracking provides persistent gain tracking for shrike
// compression calls via a local SQLite database.
//
// Each compression event is recorded with timestamp, command name,
// original/compressed byte and token counts, savings percentage,
// mode, and model. The tracker exposes aggregate queries for
// dashboards and budget enforcement.
//
// Storage defaults to ~/.shrike/tracker.db with WAL mode and a 90-day
// retention policy (configurable per Tracker instance).
//
// GrayCode native gain-tracking implementation.
// using modernc.org/sqlite (pure Go, no CGO).
package tracking

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"path/filepath"
	"sync"
	"time"

	_ "modernc.org/sqlite" // pure-Go SQLite driver
)

// Event is a single compression event recorded by the tracker.
type Event struct {
	ID               int64
	Timestamp        time.Time
	Command          string
	OriginalBytes    int
	CompressedBytes  int
	OriginalTokens   int
	CompressedTokens int
	Mode             string
	Tier             string
	Model            string
	// Computed in DB query; not stored.
	SavingsPct float64
}

// Tracker is the public type. Construct with New() or NewAt(path).
type Tracker struct {
	db        *sql.DB
	path      string
	mu        sync.Mutex
	retenDays int
	closed    bool
}

// DefaultPath returns the default tracker DB path (~/.shrike/tracker.db).
// Returns the path and a non-nil error only if the home directory
// cannot be determined.
func DefaultPath() (string, error) {
	dir, err := homeDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, ".shrike", "tracker.db"), nil
}

// New creates a tracker at the default path.
func New(ctx context.Context) (*Tracker, error) {
	p, err := DefaultPath()
	if err != nil {
		return nil, err
	}
	return NewAt(ctx, p)
}

// NewAt creates a tracker at the given path. The parent directory
// is created if it does not exist. WAL journal mode is enabled and
// the schema is created on first call.
func NewAt(ctx context.Context, path string) (*Tracker, error) {
	if path == "" {
		return nil, errors.New("tracking: empty path")
	}
	if err := mkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, fmt.Errorf("tracking: create dir %q: %w", filepath.Dir(path), err)
	}
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, fmt.Errorf("tracking: open db at %q: %w", path, err)
	}
	// SQLite is single-writer; use a per-connection mutex to serialize
	// writes without serializing reads.
	db.SetMaxOpenConns(1)
	t := &Tracker{db: db, path: path, retenDays: 90}
	if err := t.initSchema(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	if err := t.enableWAL(ctx); err != nil {
		_ = db.Close()
		return nil, err
	}
	return t, nil
}

// WithRetention overrides the default 90-day retention period.
// Must be called before any Record or Aggregate call.
func (t *Tracker) WithRetention(days int) *Tracker {
	if days > 0 {
		t.retenDays = days
	}
	return t
}

// initSchema creates the events table if it doesn't exist. Safe to
// call multiple times.
func (t *Tracker) initSchema(ctx context.Context) error {
	_, err := t.db.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS events (
			id                INTEGER PRIMARY KEY AUTOINCREMENT,
			ts                INTEGER NOT NULL,
			command           TEXT    NOT NULL DEFAULT '',
			original_bytes    INTEGER NOT NULL,
			compressed_bytes  INTEGER NOT NULL,
			original_tokens   INTEGER NOT NULL,
			compressed_tokens INTEGER NOT NULL,
			mode              TEXT    NOT NULL DEFAULT '',
			tier              TEXT    NOT NULL DEFAULT '',
			model             TEXT    NOT NULL DEFAULT ''
		);
		CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
		CREATE INDEX IF NOT EXISTS idx_events_command ON events(command);
	`)
	if err != nil {
		return fmt.Errorf("tracking: init schema at %q: %w", t.path, err)
	}
	return nil
}

// enableWAL switches the journal mode to WAL for better concurrent
// read performance.
func (t *Tracker) enableWAL(ctx context.Context) error {
	_, err := t.db.ExecContext(ctx, `PRAGMA journal_mode=WAL;`)
	if err != nil {
		return fmt.Errorf("tracking: enable WAL at %q: %w", t.path, err)
	}
	return nil
}

// Record adds a new compression event. The ID and SavingsPct fields
// of ev are ignored; SavingsPct is computed from byte counts.
func (t *Tracker) Record(ctx context.Context, ev Event) error {
	if t == nil || t.db == nil {
		return errors.New("tracking: nil tracker")
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if ev.Timestamp.IsZero() {
		ev.Timestamp = time.Now()
	}
	_, err := t.db.ExecContext(
		ctx, `
		INSERT INTO events
		  (ts, command, original_bytes, compressed_bytes,
		   original_tokens, compressed_tokens, mode, tier, model)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
	`,
		ev.Timestamp.Unix(), ev.Command,
		ev.OriginalBytes, ev.CompressedBytes,
		ev.OriginalTokens, ev.CompressedTokens,
		ev.Mode, ev.Tier, ev.Model,
	)
	if err != nil {
		return fmt.Errorf("tracking: record event in db at %q: %w", t.path, err)
	}
	return nil
}

// Aggregate is the result of a Tracker.Aggregate call.
type Aggregate struct {
	EventCount      int
	TotalBytesSaved int
	AvgSavingsPct   float64
	PeriodStart     time.Time
	PeriodEnd       time.Time
}

// Aggregate returns aggregate stats over the last `days` days (or
// the configured retention period if days is 0). Empty result if no
// events in the window.
func (t *Tracker) Aggregate(ctx context.Context, days int) (Aggregate, error) {
	if t == nil || t.db == nil {
		return Aggregate{}, errors.New("tracking: nil tracker")
	}
	if days <= 0 {
		days = t.retenDays
	}
	if days <= 0 {
		days = 90
	}
	since := time.Now().Add(-time.Duration(days) * 24 * time.Hour).Unix()

	var agg Aggregate
	row := t.db.QueryRowContext(ctx, `
		SELECT
			COUNT(*),
			COALESCE(SUM(original_bytes - compressed_bytes), 0),
			COALESCE(AVG(
				CASE WHEN original_bytes = 0 THEN 0
				     ELSE 100.0 * (original_bytes - compressed_bytes) / original_bytes
				END
			), 0)
		FROM events
		WHERE ts >= ?
	`, since)
	if err := row.Scan(&agg.EventCount, &agg.TotalBytesSaved, &agg.AvgSavingsPct); err != nil {
		return agg, fmt.Errorf("tracking: aggregate query on db at %q: %w", t.path, err)
	}
	agg.PeriodStart = time.Unix(since, 0)
	agg.PeriodEnd = time.Now()
	return agg, nil
}

// Recent returns the most recent n events, newest first.
func (t *Tracker) Recent(ctx context.Context, n int) ([]Event, error) {
	if t == nil || t.db == nil {
		return nil, errors.New("tracking: nil tracker")
	}
	if n <= 0 {
		n = 10
	}
	rows, err := t.db.QueryContext(ctx, `
		SELECT
			id, ts, command,
			original_bytes, compressed_bytes,
			original_tokens, compressed_tokens,
			mode, tier, model
		FROM events
		ORDER BY id DESC
		LIMIT ?
	`, n)
	if err != nil {
		return nil, fmt.Errorf("tracking: recent query on db at %q: %w", t.path, err)
	}
	defer func() { _ = rows.Close() }()
	var out []Event
	for rows.Next() {
		var ev Event
		var ts int64
		if err := rows.Scan(&ev.ID, &ts, &ev.Command,
			&ev.OriginalBytes, &ev.CompressedBytes,
			&ev.OriginalTokens, &ev.CompressedTokens,
			&ev.Mode, &ev.Tier, &ev.Model); err != nil {
			return nil, fmt.Errorf("tracking: scan event row from db at %q: %w", t.path, err)
		}
		ev.Timestamp = time.Unix(ts, 0)
		if ev.OriginalBytes > 0 {
			ev.SavingsPct = 100.0 * float64(ev.OriginalBytes-ev.CompressedBytes) / float64(ev.OriginalBytes)
		}
		out = append(out, ev)
	}
	return out, rows.Err()
}

// Prune deletes events older than the configured retention period.
// Returns the number of rows deleted.
func (t *Tracker) Prune(ctx context.Context) (int64, error) {
	if t == nil || t.db == nil {
		return 0, errors.New("tracking: nil tracker")
	}
	cutoff := time.Now().Add(-time.Duration(t.retenDays) * 24 * time.Hour).Unix()
	res, err := t.db.ExecContext(ctx, `DELETE FROM events WHERE ts < ?`, cutoff)
	if err != nil {
		return 0, fmt.Errorf("tracking: prune db at %q: %w", t.path, err)
	}
	return res.RowsAffected()
}

// Close closes the underlying DB. Safe to call multiple times.
func (t *Tracker) Close() error {
	if t == nil || t.db == nil {
		return nil
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.closed {
		return nil
	}
	t.closed = true
	return t.db.Close()
}
