package filter

import (
	"strings"
	"testing"
)

func TestNewImportFilter(t *testing.T) {
	f := NewImportFilter()
	if f == nil {
		t.Fatal("NewImportFilter returned nil")
	}
	if len(f.patterns) == 0 {
		t.Error("expected patterns to be initialized")
	}
}

func TestImportFilterName(t *testing.T) {
	f := NewImportFilter()
	if f.Name() != "import" {
		t.Errorf("expected name %q, got %q", "import", f.Name())
	}
}

func TestImportFilterApplyNonCode(t *testing.T) {
	f := NewImportFilter()
	input := "This is plain text, not code."
	output, saved := f.Apply(input, ModeMinimal)

	if output != input {
		t.Errorf("expected unchanged output for non-code, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for non-code, got %d", saved)
	}
}

func TestImportFilterCondensesGoImports(t *testing.T) {
	f := NewImportFilter()
	input := `package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Println("hello")
}`
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "imports condensed") || !strings.Contains(output, "package main") {
		t.Error("Go imports should be condensed")
	}
}

func TestImportFilterCondensesPythonImports(t *testing.T) {
	f := NewImportFilter()
	input := `import os
import sys

def main():
    print("hello")
`
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "imports") || !strings.Contains(output, "def main") {
		t.Error("Python imports should be condensed but preserve function")
	}
}

func TestImportFilterCondensesJSImports(t *testing.T) {
	f := NewImportFilter()
	input := `import { readFile } from 'fs';
import path from 'path';

function main() {
    console.log('hello');
}`
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "imports") || !strings.Contains(output, "function main") {
		t.Error("JS imports should be condensed but preserve function")
	}
}

func TestImportFilterCondensesRustImports(t *testing.T) {
	f := NewImportFilter()
	input := `use std::io;
use std::fs::File;

fn main() {
    println!("hello");
}`
	output, _ := f.Apply(input, ModeMinimal)

	if !strings.Contains(output, "imports") || !strings.Contains(output, "fn main") {
		t.Error("Rust imports should be condensed but preserve function")
	}
}

func TestImportFilterApplyNoImports(t *testing.T) {
	f := NewImportFilter()
	input := `func main() {
	fmt.Println("hello")
}`
	_, saved := f.Apply(input, ModeMinimal)

	if saved != 0 {
		t.Errorf("expected 0 tokens saved for code without imports, got %d", saved)
	}
}

func TestImportFilterEmpty(t *testing.T) {
	f := NewImportFilter()
	output, saved := f.Apply("", ModeMinimal)

	if output != "" {
		t.Errorf("expected empty output, got %q", output)
	}
	if saved != 0 {
		t.Errorf("expected 0 tokens saved for empty input, got %d", saved)
	}
}

func TestImportFilterSavesTokensWithManyImports(t *testing.T) {
	f := NewImportFilter()
	input := `package main

import (
	"fmt"
	"os"
	"strings"
	"time"
	"encoding/json"
)

func main() {
	fmt.Println("hello")
}`
	_, saved := f.Apply(input, ModeMinimal)

	if saved <= 0 {
		t.Error("expected tokens saved for code with many imports")
	}
}
