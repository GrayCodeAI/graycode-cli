package core

import (
	"testing"
)

func TestGetModelPricingKnown(t *testing.T) {
	pricing := GetModelPricing("gpt-4o")
	if pricing.Model == "" {
		t.Fatal("expected pricing for gpt-4o")
	}
	if pricing.InputPerMillion <= 0 {
		t.Errorf("expected positive input price, got %f", pricing.InputPerMillion)
	}
	if pricing.OutputPerMillion <= 0 {
		t.Errorf("expected positive output price, got %f", pricing.OutputPerMillion)
	}
}

func TestGetModelPricingUnknown(t *testing.T) {
	pricing := GetModelPricing("nonexistent-model-xyz")
	if pricing.Model == "" {
		t.Fatal("expected fallback pricing for unknown model")
	}
}

func TestGetModelPricingCaseInsensitive(t *testing.T) {
	p1 := GetModelPricing("GPT-4O")
	p2 := GetModelPricing("gpt-4o")
	if p1.InputPerMillion != p2.InputPerMillion {
		t.Error("pricing should be case-insensitive")
	}
}

func TestGetModelPricingTrimmed(t *testing.T) {
	p1 := GetModelPricing("  gpt-4o  ")
	p2 := GetModelPricing("gpt-4o")
	if p1.InputPerMillion != p2.InputPerMillion {
		t.Error("pricing should ignore whitespace")
	}
}

func TestHasModelPricingKnown(t *testing.T) {
	if !HasModelPricing("gpt-4o") {
		t.Error("expected true for known model")
	}
}

func TestHasModelPricingUnknown(t *testing.T) {
	if HasModelPricing("nonexistent") {
		t.Error("expected false for unknown model")
	}
}

func TestHasModelPricingCaseInsensitive(t *testing.T) {
	if !HasModelPricing("CLAUDE-4-OPUS") {
		t.Error("expected true for case-insensitive lookup")
	}
}

func TestRegisterModelPricingNew(t *testing.T) {
	RegisterModelPricing("custom-model", 1.0, 2.0)
	pricing := GetModelPricing("custom-model")
	if pricing.InputPerMillion != 1.0 {
		t.Errorf("expected input price 1.0, got %f", pricing.InputPerMillion)
	}
	if pricing.OutputPerMillion != 2.0 {
		t.Errorf("expected output price 2.0, got %f", pricing.OutputPerMillion)
	}
}

func TestRegisterModelPricingOverride(t *testing.T) {
	original := GetModelPricing("gpt-4o").InputPerMillion
	RegisterModelPricing("gpt-4o", 999.0, 999.0)

	updated := GetModelPricing("gpt-4o")
	if updated.InputPerMillion != 999.0 {
		t.Errorf("expected overridden price 999.0, got %f", updated.InputPerMillion)
	}

	RegisterModelPricing("gpt-4o", original, original)
}

func TestCalculateSavingsZeroTokens(t *testing.T) {
	savings := CalculateSavings(0, "gpt-4o")
	if savings != 0 {
		t.Errorf("expected 0 savings for 0 tokens, got %f", savings)
	}
}

func TestCalculateSavingsUnknownModel(t *testing.T) {
	savings := CalculateSavings(1000000, "nonexistent")
	if savings <= 0 {
		t.Error("expected positive savings for unknown model (falls back to default)")
	}
}

func TestCalculateSavingsLargeTokens(t *testing.T) {
	savings := CalculateSavings(1000000000, "gpt-4o")
	if savings <= 0 {
		t.Error("expected positive savings for large token count")
	}
}

func TestCommonModelPricingAllModels(t *testing.T) {
	for name, pricing := range CommonModelPricing {
		if pricing.Model == "" {
			t.Errorf("model %q has empty name", name)
		}
		if pricing.InputPerMillion <= 0 {
			t.Errorf("model %q has non-positive input price: %f", name, pricing.InputPerMillion)
		}
		if pricing.OutputPerMillion <= 0 {
			t.Errorf("model %q has non-positive output price: %f", name, pricing.OutputPerMillion)
		}
	}
}

func TestCommonModelPricingHasKey(t *testing.T) {
	models := []string{
		"gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
		"claude-3.5-sonnet", "claude-3-haiku", "claude-4-sonnet", "claude-4-opus",
	}
	for _, model := range models {
		if _, ok := CommonModelPricing[model]; !ok {
			t.Errorf("missing pricing for %q", model)
		}
	}
}
