package shrike

import (
	"fmt"
	"regexp"
	"strings"
)

var logLineRe = regexp.MustCompile(`(?i)(?:^[0-9\[\]\s\-T:.Z]{0,35})?\b(INFO|DEBUG|WARN|WARNING|ERROR|FATAL|TRACE)\b`)

func logLevel(line string) string {
	m := logLineRe.FindStringSubmatch(line)
	if m == nil {
		return ""
	}
	return strings.ToUpper(m[1])
}

func isHighPriority(level string) bool {
	return level == "ERROR" || level == "WARN" || level == "WARNING" || level == "FATAL"
}

// CompressLog preserves ERROR/WARN/FATAL lines and stack traces,
// collapsing runs of 3+ similar INFO/DEBUG lines into a summary.
func CompressLog(text string) string {
	lines := strings.Split(text, "\n")
	var out []string
	var run []string

	flushRun := func() {
		if len(run) < 3 {
			out = append(out, run...)
		} else {
			elided := run[1 : len(run)-1]
			marker := fmt.Sprintf("[%d similar lines collapsed", len(elided))
			if facts := LogInvariants(elided); facts != "" {
				marker += ": " + facts
			}
			marker += "]"
			out = append(out, run[0])
			out = append(out, marker)
			out = append(out, run[len(run)-1])
		}
		run = nil
	}

	for _, line := range lines {
		level := logLevel(line)
		if level == "" || isHighPriority(level) {
			flushRun()
			out = append(out, line)
			continue
		}
		// INFO/DEBUG/TRACE — accumulate run
		if len(run) > 0 && logLevel(run[0]) != level {
			flushRun()
		}
		run = append(run, line)
	}
	flushRun()
	return strings.Join(out, "\n")
}
