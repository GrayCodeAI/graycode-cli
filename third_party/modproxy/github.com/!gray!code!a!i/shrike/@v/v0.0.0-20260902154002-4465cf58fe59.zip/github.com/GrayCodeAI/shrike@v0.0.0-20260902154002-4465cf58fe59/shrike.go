// Package shrike provides high-performance text compression for LLM context windows.
//
// Usage:
//
//	compressed, stats := shrike.Compress(text, shrike.Aggressive)
//	compressed, stats := shrike.Compress(text, shrike.WithBudget(4000))
//
//	c := shrike.NewCompressor(shrike.Adaptive)
//	compressed, stats := c.Compress(text)
package shrike

import (
	"context"

	"github.com/GrayCodeAI/shrike/internal/core"
	"github.com/GrayCodeAI/shrike/internal/filter"
)

// Compress applies shrike's compression pipeline to the input text.
func Compress(text string, opts ...Option) (string, Stats) {
	if text == "" {
		return "", Stats{}
	}

	cfg := buildConfig(opts)

	// Code-aware mode: capture protected signature spans before compression so
	// the guard can re-inject any the pipeline drops.
	var protector *codeProtector
	if cfg.codeAware {
		protector = newCodeProtector(text, cfg.codeLang, cfg.symbolProvider)
	}

	pipelineCfg := cfg.toPipelineConfig()
	p := filter.NewPipelineCoordinator(&pipelineCfg)
	output, pStats := p.Process(text)

	if protector != nil {
		output = protector.guard(text, output)
	}

	// Perplexity-guided selective token dropping (opt-in, LLMLingua-style) runs
	// as a final stage on the pipeline output, dropping the lowest-importance
	// tokens while preserving sentence boundaries and protected symbols.
	perplexityRan := cfg.perplexityEnabled && cfg.perplexityDropRatio > 0
	if perplexityRan {
		output = perplexityDrop(context.Background(), output, cfg.perplexityScorer, cfg.perplexityDropRatio)
	}

	// Custom user-defined filter rules run as a final post-pipeline stage,
	// applied in priority order to the compressed output.
	customRan := cfg.customFilters.Len() > 0
	if customRan {
		output = cfg.customFilters.Apply(output)
	}

	stats := newStats(pStats)
	if perplexityRan || customRan {
		// Recompute final/saved so stats reflect the extra drop stage rather
		// than only the internal pipeline's accounting.
		stats.FinalTokens = core.EstimateTokens(output)
		stats.TokensSaved = stats.OriginalTokens - stats.FinalTokens
		if stats.TokensSaved < 0 {
			stats.TokensSaved = 0
		}
		if stats.OriginalTokens > 0 {
			stats.ReductionPercent = float64(stats.TokensSaved) / float64(stats.OriginalTokens) * 100
		}
	}
	if cfg.model != "" {
		stats.Model = cfg.model
		stats.CostSavings = EstimateCostSavings(stats, cfg.model)
	}

	return output, stats
}

// EstimateTokens returns the estimated token count for the given text.
func EstimateTokens(text string) int {
	return core.EstimateTokens(text)
}

// EstimateTokensFast provides a fast estimate without BPE.
// Use this when exact count isn't critical (e.g. internal budget
// checks before doing precise BPE work).
func EstimateTokensFast(text string) int {
	return core.EstimateTokensFast(text)
}

// EstimateTokensPrecise uses BPE tokenization (slower, more accurate).
func EstimateTokensPrecise(text string) int {
	return core.EstimateTokensPrecise(text)
}

// EstimateTokensWithEncoding uses BPE for a specific encoding
// (e.g. "cl100k_base", "o200k_base", "p50k_base"). The encoding
// must be one of the names accepted by the BPE tokenizer.
func EstimateTokensWithEncoding(text string, encoding string) int {
	return core.EstimateTokensWithEncoding(text, encoding)
}

// EstimateTokensForModel uses BPE for the encoding associated with
// a specific model (e.g. "gpt-4o", "claude-3", "gemini-2.5"). See
// WithModel for the supported model prefixes.
func EstimateTokensForModel(text string, model string) int {
	return core.EstimateTokensForModel(text, model)
}

// CountTokensExact returns the exact token count for text under the real
// tokenizer of the model's provider, by calling that provider's live
// count-tokens API. Unlike EstimateTokensForModel (which approximates
// Claude/Gemini counts via OpenAI's cl100k_base encoding, since neither
// provider publishes an offline tokenizer), this makes a real network call
// using apiKey and returns the provider's own exact count.
//
// model must have a "claude" or "gemini" prefix. apiKey is required and is
// never read from the environment implicitly — this is an explicit opt-in;
// no other function in this package makes network calls.
func CountTokensExact(ctx context.Context, apiKey, model, text string) (int, error) {
	return core.CountTokensExact(ctx, apiKey, model, text)
}

// WarmupTokenizer pre-initializes the BPE tokenizer in the background.
// Call at application startup to avoid latency on the first Compress call.
func WarmupTokenizer() {
	core.WarmupBPETokenizer()
}
