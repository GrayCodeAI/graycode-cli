package secrets

import (
	"context"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func TestDetectSecrets_NeverCallsNetwork(t *testing.T) {
	// A client whose transport always fails — if DetectSecrets ever tried to
	// use it, the test would need to observe a failure. Since DetectSecrets
	// doesn't accept an http.Client at all, this test instead asserts the
	// stronger property directly: DetectSecrets returns unverified matches
	// (Verified == nil) with no way to have made a network call.
	sd := NewDetector()
	matches := sd.DetectSecrets("token ghp_0123456789abcdefghijklmnopqrstuvwxyz end")
	if len(matches) == 0 {
		t.Fatal("expected a match")
	}
	for _, m := range matches {
		if m.Verified != nil {
			t.Errorf("DetectSecrets produced a non-nil Verified field for %q; it must never attempt verification", m.Type)
		}
	}
}

func TestVerifyGitHubToken(t *testing.T) {
	cases := []struct {
		name   string
		status int
		want   bool
	}{
		{"live token", http.StatusOK, true},
		{"revoked token", http.StatusUnauthorized, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if got := r.Header.Get("Authorization"); got != "token abc123" {
					t.Errorf("Authorization header = %q, want %q", got, "token abc123")
				}
				w.WriteHeader(tc.status)
			}))
			defer srv.Close()

			// verifyGitHubToken hardcodes the GitHub API host, so exercise
			// the HTTP-mechanics/status-interpretation logic directly
			// against the mock server via a RoundTripper redirect instead
			// of trying to override the URL.
			client := &http.Client{Transport: redirectTransport{target: srv.URL}}
			got, err := verifyGitHubToken(context.Background(), client, "abc123")
			if err != nil {
				t.Fatalf("verifyGitHubToken() error: %v", err)
			}
			if got != tc.want {
				t.Errorf("verifyGitHubToken() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestVerifySlackToken(t *testing.T) {
	cases := []struct {
		name string
		body string
		want bool
	}{
		{"live token", `{"ok": true}`, true},
		{"revoked token", `{"ok": false, "error": "invalid_auth"}`, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "application/json")
				_, _ = w.Write([]byte(tc.body))
			}))
			defer srv.Close()

			client := &http.Client{Transport: redirectTransport{target: srv.URL}}
			got, err := verifySlackToken(context.Background(), client, "xoxb-fake")
			if err != nil {
				t.Fatalf("verifySlackToken() error: %v", err)
			}
			if got != tc.want {
				t.Errorf("verifySlackToken() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestVerifyStripeKey(t *testing.T) {
	cases := []struct {
		name   string
		status int
		want   bool
	}{
		{"live key", http.StatusOK, true},
		{"revoked key", http.StatusUnauthorized, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				user, _, ok := r.BasicAuth()
				if !ok || user != "sk_test_fake" {
					t.Errorf("expected basic auth with key as username, got user=%q ok=%v", user, ok)
				}
				w.WriteHeader(tc.status)
			}))
			defer srv.Close()

			client := &http.Client{Transport: redirectTransport{target: srv.URL}}
			got, err := verifyStripeKey(context.Background(), client, "sk_test_fake")
			if err != nil {
				t.Fatalf("verifyStripeKey() error: %v", err)
			}
			if got != tc.want {
				t.Errorf("verifyStripeKey() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestVerifyAWSKeyPair(t *testing.T) {
	cases := []struct {
		name   string
		status int
		want   bool
	}{
		{"live pair", http.StatusOK, true},
		{"invalid pair", http.StatusForbidden, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var gotAuth string
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				gotAuth = r.Header.Get("Authorization")
				w.WriteHeader(tc.status)
			}))
			defer srv.Close()

			orig := awsSTSBaseURL
			awsSTSBaseURL = srv.URL
			defer func() { awsSTSBaseURL = orig }()

			got, err := verifyAWSKeyPair(context.Background(), srv.Client(), "AKIAIOSFODNN7EXAMPLE", "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
			if err != nil {
				t.Fatalf("verifyAWSKeyPair() error: %v", err)
			}
			if got != tc.want {
				t.Errorf("verifyAWSKeyPair() = %v, want %v", got, tc.want)
			}
			if !strings.HasPrefix(gotAuth, "AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/") {
				t.Errorf("Authorization header = %q, want AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/... prefix", gotAuth)
			}
		})
	}
}

func TestDetectSecretsVerified_AWSRequiresPair(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t.Error("verifier should not be called when no AWS Secret Key is present")
	}))
	defer srv.Close()
	orig := awsSTSBaseURL
	awsSTSBaseURL = srv.URL
	defer func() { awsSTSBaseURL = orig }()

	sd := NewDetector()
	matches := sd.DetectSecretsVerified(context.Background(), srv.Client(), "key=AKIAIOSFODNN7EXAMPLE here, no secret key present")

	for _, m := range matches {
		if m.Type == "AWS Access Key" && m.Verified != nil {
			t.Errorf("AWS Access Key without a paired secret should stay unverified, got Verified=%v", *m.Verified)
		}
	}
}

func TestDetectSecretsVerified_UnknownTypeStaysNil(t *testing.T) {
	sd := NewDetector()
	matches := sd.DetectSecretsVerified(context.Background(), nil, "password=supersecret123")
	for _, m := range matches {
		if m.Type == "Generic Password" && m.Verified != nil {
			t.Errorf("Generic Password has no verifier and should stay unverified, got Verified=%v", *m.Verified)
		}
	}
}

// redirectTransport rewrites every request's scheme+host to target's,
// preserving path/query, so verifier functions that hardcode a real
// external URL can still be exercised against a local httptest.Server.
type redirectTransport struct {
	target string
}

func (rt redirectTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	target, err := url.Parse(rt.target + req.URL.RequestURI())
	if err != nil {
		return nil, err
	}
	clone := req.Clone(req.Context())
	clone.URL = target
	clone.Host = target.Host
	return http.DefaultTransport.RoundTrip(clone)
}
