package compress_test

import (
	"strings"
	"testing"

	"github.com/GrayCodeAI/shrike/internal/compress"
)

// Regression tests for the whitespace-preservation fix: compressed output must
// keep the sentence separation (newlines/spaces) of the input instead of
// concatenating trimmed sentences.

func TestCompressPreservesSentenceWhitespace(t *testing.T) {
	cases := []struct {
		name string
		in   string
		want string // substring that must survive from both sentences
	}{
		{"single newline", "First sentence is here.\nSecond sentence is here.", "here."},
		{"double newline paragraph break", "Paragraph one ends with facts.\n\nParagraph two begins with facts.", "facts."},
		{"trailing newline", "Sentence with facts here.\n\n", "facts"},
		{"leading newline", "\n\nSentence with facts here.", "facts"},
		{"space separated", "First sentence has facts. Second sentence has facts.", "facts"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			out, _ := compress.Compress(tc.in, compress.Full)
			if !strings.Contains(out, "\n\n") && strings.Contains(tc.in, "\n\n") {
				t.Errorf("paragraph break lost: input %q -> output %q", tc.in, out)
			}
			if !strings.Contains(out, "\n") && strings.Contains(tc.in, "\n") {
				t.Errorf("newline lost: input %q -> output %q", tc.in, out)
			}
			// Counts may shift, but the separator must not vanish entirely.
			if !strings.Contains(out, tc.want) {
				t.Errorf("content missing after compression: %q", out)
			}
		})
	}
}

func TestCompressPreservesBlankLinesInsidePassThroughSegments(t *testing.T) {
	in := "SECRET_PASSWORD=abc\n\n\nKeep this line too, it has facts."
	out, _ := compress.Compress(in, compress.Full)
	// The sensitive line is passed through verbatim, including its trailing
	// blank lines, and the next line keeps its own separation.
	if !strings.Contains(out, "Keep this line too") {
		t.Errorf("content lost: %q", out)
	}
	if !strings.Contains(out, "SECRET_PASSWORD=abc\n\n") {
		t.Errorf("pass-through whitespace not preserved: %q", out)
	}
}

func TestCompressMultipleSentencesKeepSpacesBetween(t *testing.T) {
	in := "Alpha has useful facts. Beta has useful facts."
	out, _ := compress.Compress(in, compress.Full)
	// Even when articles are dropped inside sentences, a space must separate
	// the two sentences (no "facts.Beta" concatenation).
	if strings.Contains(out, "facts.Beta") || strings.Contains(out, "sentence.sentence") {
		t.Errorf("sentences concatenated without separator: %q", out)
	}
}
