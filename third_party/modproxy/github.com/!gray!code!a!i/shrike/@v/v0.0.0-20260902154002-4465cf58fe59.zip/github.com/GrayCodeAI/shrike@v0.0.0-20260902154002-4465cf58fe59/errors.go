package shrike

import "errors"

// Sentinel errors for shrike pipeline operations.
// Use errors.Is/As for programmatic error handling.
var (
	// ErrInputTooLarge is returned when input exceeds the configured max context tokens.
	ErrInputTooLarge = errors.New("input exceeds max context tokens")

	// ErrConfigInvalid is returned when configuration validation fails.
	ErrConfigInvalid = errors.New("config validation failed")

	// ErrNoReversibleEntries is returned when no reversible entries are found for decoding.
	ErrNoReversibleEntries = errors.New("no reversible entries found")

	// ErrHashNotFound is returned when a hash prefix is not found in the reversible map.
	ErrHashNotFound = errors.New("hash not found in reversible map")

	// ErrCommandUnsafe is returned when a command contains shell meta-characters.
	ErrCommandUnsafe = errors.New("command contains unsafe shell meta-characters")

	// ErrCacheOpen is returned when the cache database cannot be opened.
	ErrCacheOpen = errors.New("failed to open cache database")

	// ErrChunkFailed is returned when chunk processing fails.
	ErrChunkFailed = errors.New("chunk processing failed")
)
