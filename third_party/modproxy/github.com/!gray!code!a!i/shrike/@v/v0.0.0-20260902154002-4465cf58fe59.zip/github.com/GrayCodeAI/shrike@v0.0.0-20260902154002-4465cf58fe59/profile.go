package shrike

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/BurntSushi/toml"
)

// Profile is a named, versionable bundle of compression settings that teams can
// share. It captures the mode, tier, budget, an optional path to custom filter
// rules, and free-form notes. A Profile resolves to a slice of Option via
// Options, so it can be applied directly:
//
//	p, _ := shrike.LoadProfile(".shrike/profiles/code-safe.toml")
//	out, stats := shrike.Compress(text, p.Options()...)
type Profile struct {
	Name            string `toml:"name"`              // Human-readable profile name.
	Version         string `toml:"version"`           // Profile version (e.g. "1", "2024.1").
	Mode            Mode   `toml:"mode"`              // Compression mode (minimal/aggressive).
	Tier            Tier   `toml:"tier"`              // Pipeline tier (surface/trim/...).
	Budget          int    `toml:"budget"`            // Hard token budget (0 = unlimited).
	FilterRulesPath string `toml:"filter_rules_path"` // Optional path to custom filter rules.
	Notes           string `toml:"notes"`             // Free-form description / changelog.
}

// builtinProfiles holds the in-memory registry of ready-to-use profiles.
var builtinProfiles = map[string]*Profile{
	"default": {
		Name:    "default",
		Version: "1",
		Mode:    ModeMinimal,
		Tier:    TierCore,
		Notes:   "Balanced, quality-first compression suitable for most content.",
	},
	"aggressive": {
		Name:    "aggressive",
		Version: "1",
		Mode:    ModeAggressive,
		Tier:    TierExtract,
		Notes:   "Maximum compression. Favors token savings over fidelity.",
	},
	"code-safe": {
		Name:    "code-safe",
		Version: "1",
		Mode:    ModeMinimal,
		Tier:    TierCode,
		Notes:   "Code-aware, structure-preserving compression for source and diffs.",
	},
}

// BuiltinProfile returns a copy of the named built-in profile and whether it
// exists. Returning a copy keeps the registry immutable to callers.
func BuiltinProfile(name string) (*Profile, bool) {
	p, ok := builtinProfiles[name]
	if !ok {
		return nil, false
	}
	clone := *p
	return &clone, true
}

// BuiltinProfiles returns copies of all registered built-in profiles keyed by
// name.
func BuiltinProfiles() map[string]*Profile {
	out := make(map[string]*Profile, len(builtinProfiles))
	for name, p := range builtinProfiles {
		clone := *p
		out[name] = &clone
	}
	return out
}

// Options resolves the profile into the equivalent slice of Option values, so
// it can be passed to Compress or NewCompressor.
func (p *Profile) Options() []Option {
	if p == nil {
		return nil
	}
	var opts []Option
	if p.Mode != "" {
		opts = append(opts, WithMode(p.Mode))
	}
	if p.Tier != "" {
		opts = append(opts, WithTier(p.Tier))
	}
	if p.Budget > 0 {
		opts = append(opts, WithBudget(p.Budget))
	}
	return opts
}

// Validate checks the profile for obviously invalid field values.
func (p *Profile) Validate() error {
	if p == nil {
		return fmt.Errorf("nil profile")
	}
	if p.Mode != "" && p.Mode != ModeMinimal && p.Mode != ModeAggressive {
		return fmt.Errorf("invalid mode %q (want %q or %q)", p.Mode, ModeMinimal, ModeAggressive)
	}
	if p.Budget < 0 {
		return fmt.Errorf("budget must be non-negative, got %d", p.Budget)
	}
	return nil
}

// LoadProfile reads a single profile from a TOML file. If the profile omits a
// name, the file's base name (without extension) is used.
func LoadProfile(path string) (*Profile, error) {
	var p Profile
	if _, err := toml.DecodeFile(path, &p); err != nil {
		return nil, fmt.Errorf("decode profile %s: %w", path, err)
	}
	if p.Name == "" {
		base := filepath.Base(path)
		p.Name = strings.TrimSuffix(base, filepath.Ext(base))
	}
	if err := p.Validate(); err != nil {
		return nil, fmt.Errorf("invalid profile %s: %w", path, err)
	}
	return &p, nil
}

// LoadProfiles reads every *.toml profile in dir, keyed by profile name. A
// missing directory yields an empty map and no error so callers can treat
// "no shared profiles" as a normal state.
func LoadProfiles(dir string) (map[string]*Profile, error) {
	out := make(map[string]*Profile)

	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return out, nil
		}
		return nil, fmt.Errorf("read profiles dir %s: %w", dir, err)
	}

	// Sort for deterministic loading and stable error reporting.
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		if e.IsDir() {
			continue
		}
		if !strings.EqualFold(filepath.Ext(e.Name()), ".toml") {
			continue
		}
		names = append(names, e.Name())
	}
	sort.Strings(names)

	for _, name := range names {
		p, err := LoadProfile(filepath.Join(dir, name))
		if err != nil {
			return nil, err
		}
		out[p.Name] = p
	}
	return out, nil
}
