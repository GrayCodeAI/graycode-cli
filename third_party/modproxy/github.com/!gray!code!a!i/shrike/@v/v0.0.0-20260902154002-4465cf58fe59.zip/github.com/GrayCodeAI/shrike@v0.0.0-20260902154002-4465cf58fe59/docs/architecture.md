<div align="center">

# ✂️ shrike Architecture

**Tokenizer, Compressor & Secrets Scanner for AI Agents**

[![Go](https://img.shields.io/badge/Go-1.26+-00ADD8?logo=go)](https://go.dev/)
[![Type](https://img.shields.io/badge/Type-Library-green)]()

</div>

---

## 🎯 Overview

shrike is a tokenizer, compression, secrets scanning, and rate limiting library for AI coding agents. It reduces LLM token costs by **60–90%** through input compression, output filtering, and transparent command rewriting.

> 💡 Pure Go library — no network service, no CLI required.

---

## 🧱 Components

```
shrike/
├── api/openapi.yaml          📜 Library API surface reference
├── shrike.go                    📤 Public API: Compress(), EstimateTokens()
├── compressor.go             🔄 Reusable Compressor struct
├── options.go                ⚙️ Option, Mode, Tier, With* functions, presets
├── secrets.go                🔒 SecretDetector, DetectSecrets(), RedactSecrets()
├── stats.go                  📊 Stats returned from Compress()
├── stream.go                 📡 Stream processing
└── internal/
    ├── core/                 🧮 BPE tokenizer, token estimation
    ├── filter/               🔧 31-layer filter pipeline, tier configs
    ├── codeaware/            💻 Language-specific compression rules
    ├── secrets/              🔑 Regex patterns, entropy analysis, allowlists
    ├── cache/                💾 Compression result caching
    ├── fastops/              ⚡ Performance-critical operations
    └── config/               ⚙️ Configuration management
```

---

## 📤 Public API

```go
// 🗜️ One-shot compression
compressed, stats := shrike.Compress(text,
    shrike.WithTier(shrike.TierCode),
    shrike.WithBudget(4000),
    shrike.WithQuery("implement OAuth flow"),
)

// 🔄 Reusable compressor (caches tokenizer state)
c := shrike.NewCompressor(shrike.Aggressive)
compressed, stats := c.Compress(text)

// 📊 Token estimation
approx  := shrike.EstimateTokens(text)         // fast, ±5%
precise := shrike.EstimateTokensPrecise(text)  // BPE-accurate

// 🧮 Warmup (call at startup to avoid first-call latency)
shrike.WarmupTokenizer()

// 🔒 Secret detection
matches  := shrike.DefaultSecretDetector().DetectSecrets(text)
redacted := shrike.DefaultSecretDetector().RedactSecrets(text)
```

---

## 📊 Compression Tiers

| Tier | Description | Savings |
|------|-------------|:-------:|
| 🟢 `TierSurface` | Light deduplication | ~10% |
| 🟡 `TierTrim` | Whitespace + comments | ~20% |
| 🟠 `TierExtract` | Key information extraction | ~35% |
| 🔵 `TierCode` | Code-aware compression | ~45% |
| 🔴 `TierCore` | Semantic core extraction | ~55% |
| 🟣 `TierLog` | Log file optimization | ~70% |
| ⚡ `TierAdaptive` | Adaptive per content type | varies |

---

## 🔒 Secret Detection

| Strategy | Description |
|----------|-------------|
| 🔑 **Pattern-based** | Regex for API keys, JWTs, connection strings, SSH keys |
| 📊 **Entropy-based** | Shannon entropy analysis (threshold: 4.5) |
| 📋 **Allowlists** | Prevent false positives on known-safe patterns |

---

## 🔗 Ecosystem Usage

| Consumer | Usage |
|----------|-------|
| 🦅 **hawk** | Context window management |
| 🦅 **eyrie** | Response compression |
| 🧠 **harrier** | Token budget enforcement in recall |
