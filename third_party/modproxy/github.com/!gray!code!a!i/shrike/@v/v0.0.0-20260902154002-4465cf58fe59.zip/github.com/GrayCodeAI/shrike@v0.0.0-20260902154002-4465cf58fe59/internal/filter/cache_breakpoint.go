package filter

import (
	"fmt"
	"strings"
)

const CacheBreakMarker = "[CACHE_BREAK]"

type CacheBreakpointFilter struct {
	MinCacheableTokens int
	MaxBreakpoints     int
}

func NewCacheBreakpointFilter() *CacheBreakpointFilter {
	return &CacheBreakpointFilter{
		MinCacheableTokens: 2048,
		MaxBreakpoints:     4,
	}
}

func (f *CacheBreakpointFilter) Filter(input string) string {
	lines := strings.Split(input, "\n")
	if len(lines) < 10 {
		return input
	}

	breakpoints := 0
	var result strings.Builder
	tokenEstimate := 0
	lastBreakAt := 0

	for i, line := range lines {
		result.WriteString(line)
		if i < len(lines)-1 {
			result.WriteString("\n")
		}

		tokenEstimate += estimateLineTokens(line)

		if breakpoints >= f.MaxBreakpoints {
			continue
		}
		if tokenEstimate-lastBreakAt < f.MinCacheableTokens {
			continue
		}

		score := CacheBreakpointScore(line)
		nextScore := float64(0)
		if i+1 < len(lines) {
			nextScore = CacheBreakpointScore(lines[i+1])
		}

		if score >= 0.7 && nextScore < 0.5 {
			fmt.Fprintf(&result, "\n%s\n", CacheBreakMarker)
			breakpoints++
			lastBreakAt = tokenEstimate
		}
	}

	return result.String()
}

func CacheBreakpointScore(content string) float64 {
	lower := strings.ToLower(strings.TrimSpace(content))

	if strings.HasPrefix(lower, "you are") || strings.HasPrefix(lower, "instructions:") ||
		strings.HasPrefix(lower, "rules:") || strings.HasPrefix(lower, "# system") ||
		strings.HasPrefix(lower, "## role") {
		return 0.95
	}

	if strings.Contains(lower, "\"input_schema\"") || strings.Contains(lower, "\"parameters\"") ||
		strings.Contains(lower, "\"type\": \"function\"") || strings.Contains(lower, "tool_name") {
		return 0.90
	}

	if strings.HasPrefix(lower, "package ") || strings.HasPrefix(lower, "import ") ||
		strings.HasPrefix(lower, "func ") || strings.HasPrefix(lower, "type ") ||
		strings.HasPrefix(lower, "class ") || strings.HasPrefix(lower, "def ") {
		return 0.80
	}

	if strings.HasPrefix(lower, "assistant:") || strings.HasPrefix(lower, "user:") ||
		strings.HasPrefix(lower, "[conversation") || strings.HasPrefix(lower, "[summary") {
		return 0.70
	}

	if strings.HasPrefix(lower, "> ") || strings.Contains(lower, "now") ||
		strings.Contains(lower, "current") || strings.Contains(lower, "latest") {
		return 0.30
	}

	return 0.50
}

func estimateLineTokens(line string) int {
	words := len(strings.Fields(line))
	if words == 0 {
		return 1
	}
	return int(float64(words) * 1.3)
}
